import { useState, useEffect } from "react";
import { Alert, PermissionsAndroid, Platform } from "react-native";
import { mockBluetoothDevices } from "@/utils/motionCaptureUtils";

export const useBluetoothManager = (setMode) => {
  const [bluetoothEnabled, setBluetoothEnabled] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [availableDevices, setAvailableDevices] = useState([]);
  const [connectedDevice, setConnectedDevice] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [bluetoothPermissions, setBluetoothPermissions] = useState(false);

  useEffect(() => {
    checkBluetoothPermissions();
    simulateBluetoothStatus();
  }, []);

  const checkBluetoothPermissions = async () => {
    if (Platform.OS === "android") {
      try {
        const permissions = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        ]);
        const allGranted = Object.values(permissions).every(
          (status) => status === PermissionsAndroid.RESULTS.GRANTED,
        );
        setBluetoothPermissions(allGranted);
      } catch (error) {
        console.error("Bluetooth permission error:", error);
      }
    } else {
      setBluetoothPermissions(true);
    }
  };

  const simulateBluetoothStatus = () => {
    setTimeout(() => setBluetoothEnabled(true), 1000);
  };

  const scanForDevices = async () => {
    if (!bluetoothPermissions) {
      Alert.alert(
        "Bluetooth Permissions Required",
        "Please grant Bluetooth permissions to scan for devices.",
      );
      return;
    }
    setIsScanning(true);
    setAvailableDevices([]);
    for (let i = 0; i < mockBluetoothDevices.length; i++) {
      setTimeout(
        () => setAvailableDevices((prev) => [...prev, mockBluetoothDevices[i]]),
        (i + 1) * 800,
      );
    }
    setTimeout(() => setIsScanning(false), 4000);
  };

  const connectToDevice = async (device) => {
    setIsConnecting(true);
    setTimeout(() => {
      setConnectedDevice(device);
      setIsConnecting(false);
      setMode("selection");
      Alert.alert(
        "Device Connected",
        `Successfully connected to ${device.name}`,
      );
    }, 2000);
  };

  const disconnectDevice = () => {
    setConnectedDevice(null);
    Alert.alert("Device Disconnected", "Bluetooth camcorder disconnected");
  };

  return {
    bluetoothEnabled,
    isScanning,
    availableDevices,
    connectedDevice,
    isConnecting,
    bluetoothPermissions,
    scanForDevices,
    connectToDevice,
    disconnectDevice,
  };
};
