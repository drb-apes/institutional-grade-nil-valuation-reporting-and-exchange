import { useState, useEffect, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Alert, Platform } from "react-native";
import { useMeshNetwork } from "./useMeshNetwork";

export const useOfflineSync = () => {
  const [offlineMode, setOfflineMode] = useState(false);
  const [pendingUploads, setPendingUploads] = useState([]);
  const [syncInProgress, setSyncInProgress] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState(null);

  const syncRef = useRef({
    retryInterval: null,
    maxRetries: 3,
    retryDelay: 5000,
  });

  const { meshStatus, meshId, broadcastToMesh, getMeshNetworkInfo } =
    useMeshNetwork();

  useEffect(() => {
    loadPendingUploads();
    loadLastSyncTime();

    // Start periodic sync attempts
    syncRef.current.retryInterval = setInterval(() => {
      if (pendingUploads.length > 0 && !syncInProgress) {
        attemptSync();
      }
    }, 30000); // Check every 30 seconds

    return () => {
      if (syncRef.current.retryInterval) {
        clearInterval(syncRef.current.retryInterval);
      }
    };
  }, [pendingUploads.length, syncInProgress]);

  const loadPendingUploads = async () => {
    try {
      const stored = await AsyncStorage.getItem("offline_pending_uploads");
      if (stored) {
        setPendingUploads(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Failed to load pending uploads:", error);
    }
  };

  const loadLastSyncTime = async () => {
    try {
      const stored = await AsyncStorage.getItem("last_sync_time");
      if (stored) {
        setLastSyncTime(new Date(stored));
      }
    } catch (error) {
      console.error("Failed to load last sync time:", error);
    }
  };

  const savePendingUploads = async (uploads) => {
    try {
      await AsyncStorage.setItem(
        "offline_pending_uploads",
        JSON.stringify(uploads),
      );
      setPendingUploads(uploads);
    } catch (error) {
      console.error("Failed to save pending uploads:", error);
    }
  };

  const saveLastSyncTime = async (time) => {
    try {
      await AsyncStorage.setItem("last_sync_time", time.toISOString());
      setLastSyncTime(time);
    } catch (error) {
      console.error("Failed to save last sync time:", error);
    }
  };

  const queueForOfflineUpload = async (data) => {
    try {
      const uploadItem = {
        id: `offline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        data,
        timestamp: Date.now(),
        attempts: 0,
        type: data.type || "motion_data",
        priority: data.priority || "normal", // normal, high, critical
        meshId: meshId,
        deviceId: Platform.OS + "_" + Date.now(),
      };

      const updated = [...pendingUploads, uploadItem];
      await savePendingUploads(updated);

      // Try immediate sync via mesh if available
      if (meshStatus === "connected" || meshStatus === "hosting") {
        await attemptMeshSync(uploadItem);
      }

      return uploadItem.id;
    } catch (error) {
      console.error("Failed to queue offline upload:", error);
      return null;
    }
  };

  const attemptMeshSync = async (item) => {
    try {
      if (!meshId) return false;

      const meshData = {
        type: "offline_sync",
        uploadId: item.id,
        data: item.data,
        timestamp: item.timestamp,
        priority: item.priority,
      };

      const success = await broadcastToMesh(meshData);

      if (success) {
        // Mark as synced via mesh
        item.meshSynced = true;
        item.meshSyncTime = Date.now();

        // Update pending uploads
        const updated = pendingUploads.map((upload) =>
          upload.id === item.id ? item : upload,
        );
        await savePendingUploads(updated);

        return true;
      }

      return false;
    } catch (error) {
      console.error("Mesh sync failed:", error);
      return false;
    }
  };

  const attemptSync = async () => {
    if (syncInProgress || pendingUploads.length === 0) return;

    setSyncInProgress(true);

    try {
      const successful = [];
      const failed = [];

      // Sort by priority and timestamp
      const sortedUploads = [...pendingUploads].sort((a, b) => {
        const priorityOrder = { critical: 3, high: 2, normal: 1 };
        const aPriority = priorityOrder[a.priority] || 1;
        const bPriority = priorityOrder[b.priority] || 1;

        if (aPriority !== bPriority) {
          return bPriority - aPriority; // Higher priority first
        }

        return a.timestamp - b.timestamp; // Older first
      });

      for (const item of sortedUploads) {
        if (item.attempts >= syncRef.current.maxRetries) {
          failed.push(item);
          continue;
        }

        try {
          // First try mesh sync if available
          if (
            (meshStatus === "connected" || meshStatus === "hosting") &&
            !item.meshSynced
          ) {
            const meshSuccess = await attemptMeshSync(item);
            if (meshSuccess) {
              continue; // Don't try server upload if mesh sync worked
            }
          }

          // Try server upload
          const uploadSuccess = await uploadToServer(item);

          if (uploadSuccess) {
            successful.push(item);
          } else {
            item.attempts = (item.attempts || 0) + 1;
            item.lastAttempt = Date.now();
            failed.push(item);
          }
        } catch (error) {
          console.error(`Upload failed for item ${item.id}:`, error);
          item.attempts = (item.attempts || 0) + 1;
          item.lastAttempt = Date.now();
          item.lastError = error.message;
          failed.push(item);
        }
      }

      // Update pending uploads (remove successful ones)
      const remaining = failed.filter(
        (item) => item.attempts < syncRef.current.maxRetries,
      );
      await savePendingUploads(remaining);

      if (successful.length > 0) {
        await saveLastSyncTime(new Date());

        // Show success notification for significant syncs
        if (successful.length >= 5) {
          Alert.alert(
            "Sync Complete",
            `Successfully synced ${successful.length} items to the server.`,
          );
        }
      }

      // Show warning for permanently failed items
      const permanentlyFailed = failed.filter(
        (item) => item.attempts >= syncRef.current.maxRetries,
      );
      if (permanentlyFailed.length > 0) {
        Alert.alert(
          "Sync Warning",
          `${permanentlyFailed.length} items failed to sync after multiple attempts. They will be kept for manual retry.`,
        );
      }
    } catch (error) {
      console.error("Sync attempt failed:", error);
    } finally {
      setSyncInProgress(false);
    }
  };

  const uploadToServer = async (item) => {
    try {
      const endpoint = getEndpointForDataType(item.type);

      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...item.data,
          offline_upload_id: item.id,
          timestamp: item.timestamp,
          mesh_id: item.meshId,
          device_id: item.deviceId,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        return result.success !== false;
      }

      return false;
    } catch (error) {
      console.error("Server upload failed:", error);
      return false;
    }
  };

  const getEndpointForDataType = (type) => {
    switch (type) {
      case "motion_data":
        return "/api/motion-scans/create";
      case "milestone_data":
        return "/api/milestones/create";
      case "mesh_sync":
        return "/api/mesh-network/sync";
      case "video_archive":
        return "/api/video-archives";
      default:
        return "/api/offline-sync/upload";
    }
  };

  const retryFailedUpload = async (uploadId) => {
    const item = pendingUploads.find((upload) => upload.id === uploadId);
    if (!item) return false;

    // Reset attempts for manual retry
    item.attempts = 0;
    item.lastError = null;

    const updated = pendingUploads.map((upload) =>
      upload.id === uploadId ? item : upload,
    );
    await savePendingUploads(updated);

    // Trigger immediate sync attempt
    await attemptSync();

    return true;
  };

  const clearFailedUploads = async () => {
    const remaining = pendingUploads.filter(
      (item) => item.attempts < syncRef.current.maxRetries,
    );
    await savePendingUploads(remaining);

    Alert.alert("Cleared", "All permanently failed uploads have been removed.");
  };

  const manualSync = async () => {
    if (syncInProgress) {
      Alert.alert(
        "Sync in Progress",
        "Please wait for the current sync to complete.",
      );
      return;
    }

    await attemptSync();
  };

  const getOfflineStatus = () => {
    const failedUploads = pendingUploads.filter(
      (item) => item.attempts >= syncRef.current.maxRetries,
    );

    return {
      isOffline: offlineMode,
      pendingCount: pendingUploads.length,
      failedCount: failedUploads.length,
      syncInProgress,
      lastSyncTime,
      meshSyncAvailable: meshStatus === "connected" || meshStatus === "hosting",
    };
  };

  return {
    // State
    offlineMode,
    pendingUploads,
    syncInProgress,
    lastSyncTime,

    // Actions
    queueForOfflineUpload,
    attemptSync,
    manualSync,
    retryFailedUpload,
    clearFailedUploads,

    // Utils
    getOfflineStatus,
  };
};
