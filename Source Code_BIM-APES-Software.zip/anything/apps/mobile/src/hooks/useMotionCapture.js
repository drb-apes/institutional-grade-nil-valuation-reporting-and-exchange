import { useState, useRef, useEffect } from "react";
import { Alert } from "react-native";
import { useCameraPermissions } from "expo-camera";
import * as ImagePicker from "expo-image-picker";

export const useMotionCapture = (mode, setMode, connectedDevice) => {
  const [permission, requestPermission] = useCameraPermissions();
  const [facing, setFacing] = useState("back");
  const [flash, setFlash] = useState("off");
  const [captureType, setCaptureType] = useState("video");

  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [countdown, setCountdown] = useState(0);
  const [recordedVideo, setRecordedVideo] = useState(null);
  const [selectedMedia, setSelectedMedia] = useState(null);

  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);

  const cameraRef = useRef(null);
  const isRecordingRef = useRef(isRecording);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    let interval;
    if (isRecording) {
      interval = setInterval(() => setRecordingTime((prev) => prev + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const toggleCameraFacing = () =>
    setFacing((current) => (current === "back" ? "front" : "back"));
  const toggleFlash = () =>
    setFlash((current) => (current === "off" ? "on" : "off"));

  const startBluetoothRecording = async () => {
    if (!connectedDevice) {
      Alert.alert(
        "No Device Connected",
        "Please connect a Bluetooth camcorder first",
      );
      return;
    }
    setIsRecording(true);
    setRecordingTime(0);
    console.log(`Starting recording on ${connectedDevice.name}`);
    setTimeout(() => {
      if (isRecordingRef.current) stopBluetoothRecording();
    }, 30000);
  };

  const stopBluetoothRecording = () => {
    setIsRecording(false);
    const mockRecording = {
      uri: "bluetooth://recorded-video.mp4",
      type: "video",
      source: connectedDevice?.name || "Bluetooth Device",
      quality: connectedDevice?.quality || "4K",
      duration: recordingTime,
    };
    setSelectedMedia(mockRecording);
    setMode("processing");
    console.log(`Stopped recording on ${connectedDevice?.name}`);
  };

  const startRecording = async () => {
    if (!cameraRef.current) return;
    setIsRecording(true);
    setRecordingTime(0);
    try {
      const video = await cameraRef.current.recordAsync({
        maxDuration: 60,
        quality: "1080p",
        mute: false,
      });
      setRecordedVideo(video);
      setSelectedMedia({ uri: video.uri, type: "video" });
    } catch (error) {
      console.error("Recording failed:", error);
      Alert.alert(
        "Recording Error",
        "Failed to record video. Please try again.",
      );
    }
  };

  const stopRecording = () => {
    if (connectedDevice) {
      stopBluetoothRecording();
    } else if (cameraRef.current && isRecording) {
      cameraRef.current.stopRecording();
      setIsRecording(false);
    }
  };

  const startCountdown = () => {
    setCountdown(3);
    const countInterval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countInterval);
          if (connectedDevice) {
            startBluetoothRecording();
          } else {
            startRecording();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const takePicture = async () => {
    if (!cameraRef.current) return;
    try {
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.8,
        base64: false,
      });
      setSelectedMedia({ uri: photo.uri, type: "photo" });
      setMode("processing");
    } catch (error) {
      console.error("Photo capture failed:", error);
      Alert.alert("Capture Error", "Failed to take photo. Please try again.");
    }
  };

  const pickFromLibrary = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.8,
    });
    if (!result.canceled) {
      const asset = result.assets[0];
      setSelectedMedia({
        uri: asset.uri,
        type: asset.type === "video" ? "video" : "photo",
      });
      setMode("processing");
    }
  };

  const processAnalysis = async () => {
    setIsProcessing(true);
    setTimeout(() => {
      setAnalysisResults({
        sport: "Basketball",
        bim_score: 87.3,
        performance_metrics: {
          technique: 89,
          speed: 85,
          power: 91,
          consistency: 83,
        },
        recommendations: [
          "Optimize shooting form for better consistency",
          "Focus on core stability during movement",
          "Improve follow-through timing",
        ],
      });
      setIsProcessing(false);
      setMode("results");
    }, 3000);
  };

  const resetCapture = () => {
    setMode("selection");
    setSelectedMedia(null);
    setRecordedVideo(null);
    setAnalysisResults(null);
    setRecordingTime(0);
    setCountdown(0);
  };

  return {
    permission,
    requestPermission,
    facing,
    flash,
    captureType,
    setCaptureType,
    isRecording,
    recordingTime,
    countdown,
    selectedMedia,
    isProcessing,
    analysisResults,
    cameraRef,
    toggleCameraFacing,
    toggleFlash,
    stopRecording,
    startCountdown,
    takePicture,
    pickFromLibrary,
    processAnalysis,
    resetCapture,
    startBluetoothRecording,
    stopBluetoothRecording,
  };
};
