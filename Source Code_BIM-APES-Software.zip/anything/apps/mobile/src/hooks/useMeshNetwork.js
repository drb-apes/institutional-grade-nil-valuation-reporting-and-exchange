import { useState, useEffect, useRef } from "react";
import { Alert, Platform, PermissionsAndroid } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const useMeshNetwork = () => {
  const [meshStatus, setMeshStatus] = useState("disconnected"); // disconnected, connecting, connected, hosting
  const [meshDevices, setMeshDevices] = useState([]);
  const [meshId, setMeshId] = useState(null);
  const [isHost, setIsHost] = useState(false);
  const [offlineQueue, setOfflineQueue] = useState([]);
  const [meshPermissions, setMeshPermissions] = useState(false);
  const [hotspotEnabled, setHotspotEnabled] = useState(false);
  const [bluetoothMeshActive, setBluetoothMeshActive] = useState(false);

  const meshRef = useRef({
    connections: new Map(),
    dataBuffer: [],
    syncInterval: null,
    discoveryInterval: null,
  });

  useEffect(() => {
    initializeMeshNetwork();
    return () => {
      cleanupMeshNetwork();
    };
  }, []);

  const initializeMeshNetwork = async () => {
    try {
      await checkMeshPermissions();
      await loadOfflineData();
      discoverNearbyDevices(); // Call discoverNearbyDevices directly instead of undefined startDeviceDiscovery
    } catch (error) {
      console.error("Mesh initialization error:", error);
    }
  };

  const checkMeshPermissions = async () => {
    if (Platform.OS === "android") {
      try {
        const permissions = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          PermissionsAndroid.PERMISSIONS.ACCESS_WIFI_STATE,
          PermissionsAndroid.PERMISSIONS.CHANGE_WIFI_STATE,
          PermissionsAndroid.PERMISSIONS.ACCESS_NETWORK_STATE,
          // Note: HOTSPOT permissions require system-level access
        ]);

        const bluetoothGranted = Object.values(permissions).every(
          (status) => status === PermissionsAndroid.RESULTS.GRANTED,
        );
        setMeshPermissions(bluetoothGranted);
      } catch (error) {
        console.error("Mesh permission error:", error);
      }
    } else {
      setMeshPermissions(true);
    }
  };

  const loadOfflineData = async () => {
    try {
      const storedQueue = await AsyncStorage.getItem("mesh_offline_queue");
      if (storedQueue) {
        setOfflineQueue(JSON.parse(storedQueue));
      }
    } catch (error) {
      console.error("Failed to load offline data:", error);
    }
  };

  const saveOfflineData = async (data) => {
    try {
      const updatedQueue = [...offlineQueue, data];
      await AsyncStorage.setItem(
        "mesh_offline_queue",
        JSON.stringify(updatedQueue),
      );
      setOfflineQueue(updatedQueue);
    } catch (error) {
      console.error("Failed to save offline data:", error);
    }
  };

  const createMeshNetwork = async () => {
    if (!meshPermissions) {
      Alert.alert(
        "Permissions Required",
        "Mesh networking requires Bluetooth and WiFi permissions to create device-to-device connections.",
      );
      return false;
    }

    try {
      setMeshStatus("connecting");
      setIsHost(true);

      // Generate unique mesh ID
      const newMeshId = `MESH-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      setMeshId(newMeshId);

      // Start mesh services
      await startBluetoothMesh();
      await startWiFiDirectMesh();

      setMeshStatus("hosting");

      // Start periodic device discovery
      meshRef.current.discoveryInterval = setInterval(() => {
        discoverNearbyDevices();
      }, 5000);

      Alert.alert(
        "Mesh Network Created",
        `Network ID: ${newMeshId}\nShare this ID with nearby devices to connect.`,
      );
      return true;
    } catch (error) {
      console.error("Failed to create mesh network:", error);
      setMeshStatus("disconnected");
      return false;
    }
  };

  const joinMeshNetwork = async (networkId) => {
    if (!meshPermissions) {
      Alert.alert(
        "Permissions Required",
        "Mesh networking requires Bluetooth and WiFi permissions.",
      );
      return false;
    }

    try {
      setMeshStatus("connecting");
      setIsHost(false);
      setMeshId(networkId);

      // Attempt to discover and connect to the mesh
      const meshFound = await discoverMeshNetwork(networkId);

      if (meshFound) {
        await connectToMesh(networkId);
        setMeshStatus("connected");

        // Start sync process
        startMeshSync();

        Alert.alert(
          "Connected",
          `Successfully joined mesh network: ${networkId}`,
        );
        return true;
      } else {
        throw new Error("Mesh network not found");
      }
    } catch (error) {
      console.error("Failed to join mesh network:", error);
      setMeshStatus("disconnected");
      Alert.alert(
        "Connection Failed",
        "Could not connect to the mesh network. Make sure you're within range.",
      );
      return false;
    }
  };

  const startBluetoothMesh = async () => {
    try {
      // Simulate Bluetooth mesh startup
      // In real implementation, this would:
      // - Enable Bluetooth LE advertising
      // - Start GATT server for data exchange
      // - Set up mesh topology protocols

      setBluetoothMeshActive(true);

      // Mock Bluetooth mesh discovery
      setTimeout(() => {
        const mockDevice = {
          id: "bt_device_1",
          name: "BT Mesh Node",
          type: "bluetooth",
          rssi: -45,
          timestamp: Date.now(),
        };
        addMeshDevice(mockDevice);
      }, 2000);
    } catch (error) {
      console.error("Bluetooth mesh startup failed:", error);
    }
  };

  const startWiFiDirectMesh = async () => {
    try {
      // Simulate WiFi Direct mesh startup
      // In real implementation, this would:
      // - Enable WiFi Direct
      // - Create peer-to-peer connections
      // - Set up local network routing

      setHotspotEnabled(true);

      // Mock WiFi Direct discovery
      setTimeout(() => {
        const mockDevice = {
          id: "wifi_device_1",
          name: "WiFi Direct Node",
          type: "wifi_direct",
          signal: 85,
          timestamp: Date.now(),
        };
        addMeshDevice(mockDevice);
      }, 3000);
    } catch (error) {
      console.error("WiFi Direct mesh startup failed:", error);
    }
  };

  const discoverNearbyDevices = async () => {
    try {
      // Simulate device discovery via multiple protocols
      const discoveredDevices = [
        {
          id: `bt_${Date.now()}_1`,
          name: "iPhone Motion Tracker",
          type: "bluetooth",
          rssi: -38,
          capabilities: ["motion_capture", "data_sync"],
          timestamp: Date.now(),
        },
        {
          id: `wifi_${Date.now()}_2`,
          name: "Android Sync Device",
          type: "wifi_direct",
          signal: 78,
          capabilities: ["motion_capture", "mesh_relay"],
          timestamp: Date.now(),
        },
      ];

      // Filter out existing devices and add new ones
      discoveredDevices.forEach((device) => {
        const exists = meshDevices.find((d) => d.id === device.id);
        if (!exists) {
          addMeshDevice(device);
        }
      });
    } catch (error) {
      console.error("Device discovery failed:", error);
    }
  };

  const discoverMeshNetwork = async (networkId) => {
    try {
      // Simulate mesh network discovery
      // Look for Bluetooth and WiFi Direct advertisements with the network ID

      return new Promise((resolve) => {
        setTimeout(() => {
          // Mock successful discovery
          resolve(true);
        }, 2000);
      });
    } catch (error) {
      console.error("Mesh discovery failed:", error);
      return false;
    }
  };

  const connectToMesh = async (networkId) => {
    try {
      // Simulate mesh connection establishment
      // In real implementation:
      // - Establish Bluetooth connections
      // - Join WiFi Direct group
      // - Exchange mesh topology information

      return new Promise((resolve, reject) => {
        setTimeout(() => {
          // Mock connection success
          resolve();
        }, 1500);
      });
    } catch (error) {
      console.error("Mesh connection failed:", error);
      throw error;
    }
  };

  const addMeshDevice = (device) => {
    setMeshDevices((prev) => {
      const exists = prev.find((d) => d.id === device.id);
      if (!exists) {
        return [...prev, device];
      }
      return prev.map((d) => (d.id === device.id ? { ...d, ...device } : d));
    });
  };

  const removeMeshDevice = (deviceId) => {
    setMeshDevices((prev) => prev.filter((d) => d.id !== deviceId));

    // Clean up connection
    if (meshRef.current.connections.has(deviceId)) {
      meshRef.current.connections.delete(deviceId);
    }
  };

  const startMeshSync = () => {
    if (meshRef.current.syncInterval) {
      clearInterval(meshRef.current.syncInterval);
    }

    meshRef.current.syncInterval = setInterval(() => {
      syncPendingData();
    }, 3000);
  };

  const syncPendingData = async () => {
    try {
      if (offlineQueue.length === 0) return;

      // Attempt to sync queued data with mesh network
      const synced = [];

      for (const item of offlineQueue) {
        const success = await transmitToMesh(item);
        if (success) {
          synced.push(item);
        }
      }

      // Remove successfully synced items
      if (synced.length > 0) {
        const remaining = offlineQueue.filter((item) => !synced.includes(item));
        setOfflineQueue(remaining);
        await AsyncStorage.setItem(
          "mesh_offline_queue",
          JSON.stringify(remaining),
        );
      }
    } catch (error) {
      console.error("Mesh sync failed:", error);
    }
  };

  const transmitToMesh = async (data) => {
    try {
      // Simulate mesh data transmission
      // In real implementation:
      // - Send via Bluetooth mesh
      // - Send via WiFi Direct
      // - Use mesh routing protocols

      return new Promise((resolve) => {
        setTimeout(() => {
          // Mock successful transmission
          resolve(Math.random() > 0.1); // 90% success rate
        }, 500);
      });
    } catch (error) {
      console.error("Mesh transmission failed:", error);
      return false;
    }
  };

  const broadcastToMesh = async (message) => {
    try {
      if (meshStatus !== "connected" && meshStatus !== "hosting") {
        // Queue for offline transmission
        await saveOfflineData({
          type: "broadcast",
          message,
          timestamp: Date.now(),
          deviceId: Platform.OS + "_" + Date.now(),
        });
        return false;
      }

      // Broadcast to all connected mesh devices
      const results = await Promise.allSettled(
        meshDevices.map((device) => transmitToDevice(device.id, message)),
      );

      const successCount = results.filter(
        (r) => r.status === "fulfilled" && r.value,
      ).length;
      return successCount > 0;
    } catch (error) {
      console.error("Mesh broadcast failed:", error);
      return false;
    }
  };

  const transmitToDevice = async (deviceId, data) => {
    try {
      // Simulate device-specific transmission
      return await transmitToMesh({ deviceId, data });
    } catch (error) {
      console.error(`Failed to transmit to device ${deviceId}:`, error);
      return false;
    }
  };

  const startRecordingSync = async (recordingData) => {
    try {
      const syncMessage = {
        type: "recording_start",
        data: recordingData,
        timestamp: Date.now(),
        meshId,
      };

      const success = await broadcastToMesh(syncMessage);

      if (!success) {
        await saveOfflineData(syncMessage);
      }

      return success;
    } catch (error) {
      console.error("Recording sync failed:", error);
      return false;
    }
  };

  const stopRecordingSync = async () => {
    try {
      const syncMessage = {
        type: "recording_stop",
        timestamp: Date.now(),
        meshId,
      };

      const success = await broadcastToMesh(syncMessage);

      if (!success) {
        await saveOfflineData(syncMessage);
      }

      return success;
    } catch (error) {
      console.error("Stop recording sync failed:", error);
      return false;
    }
  };

  const leaveMeshNetwork = async () => {
    try {
      // Notify other devices of departure
      await broadcastToMesh({
        type: "device_leaving",
        deviceId: Platform.OS + "_" + Date.now(),
        timestamp: Date.now(),
      });

      cleanupMeshNetwork();
    } catch (error) {
      console.error("Failed to leave mesh gracefully:", error);
    } finally {
      resetMeshState();
    }
  };

  const cleanupMeshNetwork = () => {
    if (meshRef.current.syncInterval) {
      clearInterval(meshRef.current.syncInterval);
      meshRef.current.syncInterval = null;
    }

    if (meshRef.current.discoveryInterval) {
      clearInterval(meshRef.current.discoveryInterval);
      meshRef.current.discoveryInterval = null;
    }

    meshRef.current.connections.clear();
    meshRef.current.dataBuffer = [];
  };

  const resetMeshState = () => {
    setMeshStatus("disconnected");
    setMeshDevices([]);
    setMeshId(null);
    setIsHost(false);
    setHotspotEnabled(false);
    setBluetoothMeshActive(false);
  };

  const getMeshNetworkInfo = () => {
    return {
      meshId,
      isHost,
      deviceCount: meshDevices.length,
      status: meshStatus,
      offlineQueueSize: offlineQueue.length,
      connections: {
        bluetooth: bluetoothMeshActive,
        wifiDirect: hotspotEnabled,
      },
    };
  };

  return {
    // State
    meshStatus,
    meshDevices,
    meshId,
    isHost,
    offlineQueue,
    meshPermissions,
    hotspotEnabled,
    bluetoothMeshActive,

    // Actions
    createMeshNetwork,
    joinMeshNetwork,
    leaveMeshNetwork,
    broadcastToMesh,
    startRecordingSync,
    stopRecordingSync,
    addMeshDevice,
    removeMeshDevice,

    // Utils
    getMeshNetworkInfo,
    discoverNearbyDevices,
  };
};
