import { View, Text, TouchableOpacity, Linking } from "react-native";
import { ExternalLink } from "lucide-react-native";

export default function LicensingFooter() {
  const openLink = (url) => {
    Linking.openURL(url).catch((err) =>
      console.error("Failed to open URL:", err),
    );
  };

  return (
    <View
      style={{
        backgroundColor: "#0f172a",
        borderTopWidth: 1,
        borderTopColor: "#334155",
        paddingHorizontal: 16,
        paddingTop: 32,
        paddingBottom: 48,
      }}
    >
      {/* Copyright Section */}
      <View style={{ marginBottom: 24 }}>
        <Text
          style={{
            color: "#cbd5e1",
            fontSize: 14,
            fontWeight: "600",
            marginBottom: 8,
          }}
        >
          © {new Date().getFullYear()} Dashawn Ramel Bledsoe / NIBLS Inc. All
          Rights Reserved.
        </Text>
        <Text style={{ color: "#94a3b8", fontSize: 12, lineHeight: 18 }}>
          BIM‑APES Software and all related technologies are developed and
          published by{" "}
          <Text style={{ color: "#60a5fa", fontWeight: "500" }}>
            Bledsoe Investment Management
          </Text>
          , a division of{" "}
          <Text style={{ color: "#60a5fa", fontWeight: "500" }}>
            NIBLS Inc.
          </Text>
        </Text>
      </View>

      {/* License Details */}
      <View style={{ marginBottom: 24 }}>
        {/* Software License */}
        <View
          style={{
            backgroundColor: "rgba(30, 41, 59, 0.5)",
            borderRadius: 12,
            padding: 16,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 8,
                height: 8,
                backgroundColor: "#4ade80",
                borderRadius: 4,
                marginRight: 8,
              }}
            />
            <Text style={{ color: "#ffffff", fontSize: 14, fontWeight: "600" }}>
              Software License
            </Text>
          </View>
          <Text
            style={{
              color: "#cbd5e1",
              fontSize: 12,
              marginBottom: 12,
              lineHeight: 18,
            }}
          >
            Portions of this application are licensed under the Apache License,
            Version 2.0
          </Text>
          <TouchableOpacity
            onPress={() =>
              openLink("https://www.apache.org/licenses/LICENSE-2.0")
            }
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 4 }}
            >
              <Text
                style={{
                  color: "#4ade80",
                  fontSize: 11,
                  textDecorationLine: "underline",
                }}
              >
                View License
              </Text>
              <ExternalLink size={12} color="#4ade80" />
            </View>
          </TouchableOpacity>
        </View>

        {/* Content License */}
        <View
          style={{
            backgroundColor: "rgba(30, 41, 59, 0.5)",
            borderRadius: 12,
            padding: 16,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                width: 8,
                height: 8,
                backgroundColor: "#60a5fa",
                borderRadius: 4,
                marginRight: 8,
              }}
            />
            <Text style={{ color: "#ffffff", fontSize: 14, fontWeight: "600" }}>
              Content License
            </Text>
          </View>
          <Text
            style={{
              color: "#cbd5e1",
              fontSize: 12,
              marginBottom: 12,
              lineHeight: 18,
            }}
          >
            All non‑software content—including reports, visualizations,
            branding, and documentation—is licensed under CC BY-NC-ND 4.0
          </Text>
          <TouchableOpacity
            onPress={() =>
              openLink("https://creativecommons.org/licenses/by-nc-nd/4.0/")
            }
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 4 }}
            >
              <Text
                style={{
                  color: "#60a5fa",
                  fontSize: 11,
                  textDecorationLine: "underline",
                }}
              >
                View License
              </Text>
              <ExternalLink size={12} color="#60a5fa" />
            </View>
          </TouchableOpacity>
        </View>
      </View>

      {/* Trademark Notice */}
      <View
        style={{
          backgroundColor: "rgba(234, 179, 8, 0.1)",
          borderWidth: 1,
          borderColor: "rgba(234, 179, 8, 0.3)",
          borderRadius: 12,
          padding: 16,
          marginBottom: 24,
        }}
      >
        <Text style={{ color: "#fde047", fontSize: 12, lineHeight: 18 }}>
          ⚠️ Use of trademarks, branding, and proprietary valuation models
          requires written permission from NIBLS Inc.
        </Text>
      </View>

      {/* Prior Art Reference */}
      <View
        style={{
          backgroundColor: "rgba(30, 41, 59, 0.5)",
          borderRadius: 12,
          padding: 16,
          borderWidth: 1,
          borderColor: "#334155",
          marginBottom: 24,
        }}
      >
        <Text
          style={{
            color: "#ffffff",
            fontSize: 14,
            fontWeight: "600",
            marginBottom: 12,
          }}
        >
          Prior Art & Reference Documentation
        </Text>
        <View style={{ flexDirection: "row", gap: 12 }}>
          <View
            style={{
              width: 32,
              height: 32,
              backgroundColor: "rgba(59, 130, 246, 0.2)",
              borderRadius: 6,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <ExternalLink size={16} color="#60a5fa" />
          </View>
          <View style={{ flex: 1 }}>
            <Text
              style={{
                color: "#cbd5e1",
                fontSize: 12,
                marginBottom: 8,
                lineHeight: 18,
              }}
            >
              Tech+Ball Genre: Biometric sports technology ball or blockchain
              technology hardware for a blockchain token or cryptocurrency coin
              marketplace application
            </Text>
            <TouchableOpacity
              onPress={() =>
                openLink("https://priorart.ip.com/IPCOM/000271355")
              }
            >
              <Text
                style={{
                  color: "#60a5fa",
                  fontSize: 11,
                  textDecorationLine: "underline",
                  marginBottom: 8,
                }}
              >
                https://priorart.ip.com/IPCOM/000271355
              </Text>
            </TouchableOpacity>
            <View style={{ marginTop: 8 }}>
              <Text style={{ color: "#64748b", fontSize: 10 }}>
                Publication Date: 2022-Nov-30
              </Text>
              <Text style={{ color: "#64748b", fontSize: 10 }}>
                Author: Dashawn Ramel Bledsoe
              </Text>
              <Text style={{ color: "#64748b", fontSize: 10 }}>
                Document: IPCOM000271355D
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Additional Links */}
      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 16,
          marginBottom: 24,
        }}
      >
        <TouchableOpacity onPress={() => openLink("/privacy")}>
          <Text style={{ color: "#94a3b8", fontSize: 12 }}>Privacy Policy</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => openLink("https://github.com/bim-apes")}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Text style={{ color: "#94a3b8", fontSize: 12 }}>GitHub</Text>
            <ExternalLink size={12} color="#94a3b8" />
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => openLink("https://priorart.ip.com/IPCOM/000271355")}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Text style={{ color: "#94a3b8", fontSize: 12 }}>Prior Art</Text>
            <ExternalLink size={12} color="#94a3b8" />
          </View>
        </TouchableOpacity>
      </View>

      {/* Company Info */}
      <View style={{ alignItems: "center" }}>
        <Text style={{ color: "#475569", fontSize: 10, marginBottom: 4 }}>
          NIBLS Inc. · Bledsoe Investment Management · BIM-APES Platform
        </Text>
        <Text style={{ color: "#334155", fontSize: 10, textAlign: "center" }}>
          Advancing athlete NIL valuation through biometric intelligence and
          performance analytics
        </Text>
      </View>
    </View>
  );
}
