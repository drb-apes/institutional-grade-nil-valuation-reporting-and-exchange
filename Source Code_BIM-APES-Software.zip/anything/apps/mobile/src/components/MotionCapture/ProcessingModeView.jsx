import { RotateCcw, Sparkles } from "lucide-react-native";
import React from "react";
import { ActivityIndicator, Text, TouchableOpacity, View } from "react-native";
import { styles } from "./styles";

export function ProcessingModeView({
  selectedMedia,
  processAnalysis,
  isProcessing,
  resetCapture,
}) {
  return (
    <View style={styles.content}>
      <View style={styles.processingCard}>
        <Text style={styles.processingTitle}>Ready for Analysis</Text>
        <Text style={styles.processingSubtitle}>
          {selectedMedia?.type === "video" ? "Video" : "Photo"} captured
          successfully
          {selectedMedia?.source && ` from ${selectedMedia.source}`}
        </Text>

        <TouchableOpacity
          style={styles.analyzeButton}
          onPress={processAnalysis}
          disabled={isProcessing}
        >
          {isProcessing ? (
            <ActivityIndicator color="white" />
          ) : (
            <Sparkles size={20} color="white" />
          )}
          <Text style={styles.analyzeButtonText}>
            {isProcessing ? "Analyzing..." : "Analyze with AI"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.retakeButton} onPress={resetCapture}>
          <RotateCcw size={16} color="#1D2B3D" />
          <Text style={styles.retakeButtonText}>Retake</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
