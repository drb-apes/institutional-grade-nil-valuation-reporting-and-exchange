import { Brain } from "lucide-react-native";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { styles } from "./styles";

export function AuthView({ signIn }) {
  return (
    <View style={styles.authContainer}>
      <View style={styles.authIcon}>
        <Brain size={32} color="#B8860B" />
      </View>
      <Text style={styles.authTitle}>Authentication Required</Text>
      <Text style={styles.authSubtitle}>
        Please sign in to access AI motion analysis
      </Text>
      <TouchableOpacity style={styles.authButton} onPress={() => signIn()}>
        <Text style={styles.authButtonText}>Sign In</Text>
      </TouchableOpacity>
    </View>
  );
}
