import {
  formatTime,
  getSignalStrengthColor,
  getSignalBars,
  getBatteryColor,
} from "@/utils/motionCaptureUtils";
import {
  Activity,
  Bluetooth,
  Camera,
  Target,
  Timer,
  Video,
} from "lucide-react-native";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { styles } from "./styles";

export function SelectionModeView({
  setMode,
  setCaptureType,
  pickFromLibrary,
  connectedDevice,
}) {
  return (
    <View style={styles.content}>
      <View style={styles.modeGrid}>
        <TouchableOpacity
          style={styles.modeCard}
          onPress={() => {
            setMode("camera");
            setCaptureType("video");
          }}
        >
          <View style={[styles.modeIcon, { backgroundColor: "#B8860B20" }]}>
            <Video size={28} color="#B8860B" />
          </View>
          <Text style={styles.modeTitle}>Record Video</Text>
          <Text style={styles.modeDescription}>
            {connectedDevice
              ? `Capture with ${connectedDevice.name}`
              : "Capture live performance for motion analysis"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.modeCard}
          onPress={() => {
            setMode("camera");
            setCaptureType("photo");
          }}
        >
          <View style={[styles.modeIcon, { backgroundColor: "#1D2B3D20" }]}>
            <Camera size={28} color="#1D2B3D" />
          </View>
          <Text style={styles.modeTitle}>Take Photo</Text>
          <Text style={styles.modeDescription}>
            Capture technique for form analysis
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.modeCard} onPress={pickFromLibrary}>
          <View style={[styles.modeIcon, { backgroundColor: "#B8860B20" }]}>
            <Video size={28} color="#B8860B" />
          </View>
          <Text style={styles.modeTitle}>From Library</Text>
          <Text style={styles.modeDescription}>
            Select existing media from your device
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.modeCard}
          onPress={() => setMode("bluetooth")}
        >
          <View style={[styles.modeIcon, { backgroundColor: "#1D2B3D20" }]}>
            <Bluetooth size={28} color="#1D2B3D" />
          </View>
          <Text style={styles.modeTitle}>Bluetooth Camcorder</Text>
          <Text style={styles.modeDescription}>
            Connect external cameras and camcorders
          </Text>
        </TouchableOpacity>
      </View>

      {connectedDevice && (
        <View style={styles.connectedDeviceCard}>
          <View style={styles.deviceHeader}>
            <View style={styles.deviceIcon}>
              <Bluetooth size={20} color="#10B981" />
            </View>
            <View style={styles.deviceInfo}>
              <Text style={styles.deviceName}>{connectedDevice.name}</Text>
              <Text style={styles.deviceDetails}>
                {connectedDevice.quality} • {connectedDevice.battery}% battery
              </Text>
            </View>
            <View style={styles.signalIndicator}>
              {Array.from({ length: 4 }).map((_, i) => (
                <View
                  key={i}
                  style={[
                    styles.signalBar,
                    {
                      backgroundColor:
                        i < getSignalBars(connectedDevice.signal_strength)
                          ? getSignalStrengthColor(
                              connectedDevice.signal_strength,
                            )
                          : "#E5E7EB",
                      height: 8 + i * 3,
                    },
                  ]}
                />
              ))}
            </View>
          </View>
        </View>
      )}

      <View style={styles.featuresSection}>
        <Text style={styles.featuresTitle}>Sport-Specific Analysis</Text>
        <View style={styles.featuresGrid}>
          <View style={styles.featureCard}>
            <Target size={20} color="#B8860B" />
            <Text style={styles.featureText}>Wrestling Technique</Text>
          </View>
          <View style={styles.featureCard}>
            <Activity size={20} color="#B8860B" />
            <Text style={styles.featureText}>Basketball Shooting</Text>
          </View>
          <View style={styles.featureCard}>
            <Timer size={20} color="#B8860B" />
            <Text style={styles.featureText}>Soccer Footwork</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
