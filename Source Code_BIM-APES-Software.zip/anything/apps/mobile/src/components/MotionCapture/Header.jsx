import {
  Bluetooth,
  BluetoothOff,
  Brain,
  RotateCcw,
  Router, // Add mesh network icon
  Wifi, // Add WiFi icon for mesh status
} from "lucide-react-native";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { styles } from "./styles";

export function Header({
  connectedDevice,
  disconnectDevice,
  bluetoothEnabled,
  setMode,
  meshNetworkActive, // Add mesh network prop
  onMeshNetworkPress, // Add mesh network handler
}) {
  return (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <View style={styles.headerBadge}>
          <Brain size={16} color="#B8860B" />
          <Text style={styles.headerBadgeText}>AI Motion Analysis</Text>
        </View>

        <View style={styles.bluetoothControls}>
          {/* Mesh Network Button */}
          <TouchableOpacity
            style={[
              styles.bluetoothButton,
              { marginRight: 8 },
              meshNetworkActive && { backgroundColor: "#10B981" },
            ]}
            onPress={onMeshNetworkPress}
          >
            <Router
              size={16}
              color={meshNetworkActive ? "#FFFFFF" : "#B8860B"}
            />
          </TouchableOpacity>

          {connectedDevice ? (
            <TouchableOpacity
              style={styles.bluetoothConnected}
              onPress={disconnectDevice}
            >
              <Bluetooth size={16} color="#10B981" />
              <Text style={styles.bluetoothConnectedText}>
                {connectedDevice.name.substring(0, 12)}...
              </Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={styles.bluetoothButton}
              onPress={() => setMode("bluetooth")}
            >
              {bluetoothEnabled ? (
                <Bluetooth size={16} color="#B8860B" />
              ) : (
                <BluetoothOff size={16} color="#666" />
              )}
            </TouchableOpacity>
          )}
        </View>
      </View>
      <Text style={styles.headerTitle}>Performance Capture</Text>

      {/* Mesh Network Status Indicator */}
      {meshNetworkActive && (
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            marginTop: 8,
            paddingHorizontal: 12,
            paddingVertical: 4,
            backgroundColor: "#10B98120",
            borderRadius: 16,
            alignSelf: "center",
          }}
        >
          <Wifi size={12} color="#10B981" />
          <Text
            style={{
              color: "#10B981",
              fontSize: 12,
              fontWeight: "600",
              marginLeft: 4,
            }}
          >
            Mesh Network Active
          </Text>
        </View>
      )}
    </View>
  );
}
