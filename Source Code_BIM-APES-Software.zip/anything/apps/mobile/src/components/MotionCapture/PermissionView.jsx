import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { Camera } from "lucide-react-native";
import { styles } from "./styles";

export function PermissionView({ permission, requestPermission }) {
  if (!permission) {
    return (
      <View style={styles.permissionContainer}>
        <Camera size={48} color="#B8860B" />
        <Text style={styles.permissionText}>Setting up camera...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.permissionContainer}>
        <Camera size={48} color="#B8860B" />
        <Text style={styles.permissionTitle}>Camera Permission Required</Text>
        <Text style={styles.permissionText}>
          We need camera access to analyze your performance
        </Text>
        <TouchableOpacity
          style={styles.permissionButton}
          onPress={requestPermission}
        >
          <Text style={styles.permissionButtonText}>Grant Permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return null;
}
