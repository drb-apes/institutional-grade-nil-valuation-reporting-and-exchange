import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { styles } from "./styles";

export function ResultsModeView({ analysisResults, resetCapture }) {
  if (!analysisResults) return null;

  return (
    <View style={styles.content}>
      <View style={styles.resultsCard}>
        <Text style={styles.resultsTitle}>Performance Analysis</Text>
        <Text style={styles.sportLabel}>{analysisResults.sport}</Text>

        <View style={styles.scoreContainer}>
          <Text style={styles.scoreLabel}>BIM Performance Score</Text>
          <Text style={styles.scoreValue}>{analysisResults.bim_score}</Text>
        </View>

        <View style={styles.metricsGrid}>
          {Object.entries(analysisResults.performance_metrics).map(
            ([key, value]) => (
              <View key={key} style={styles.metricCard}>
                <Text style={styles.metricLabel}>{key}</Text>
                <Text style={styles.metricValue}>{value}</Text>
              </View>
            ),
          )}
        </View>

        <TouchableOpacity
          style={styles.newAnalysisButton}
          onPress={resetCapture}
        >
          <Text style={styles.newAnalysisButtonText}>New Analysis</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
