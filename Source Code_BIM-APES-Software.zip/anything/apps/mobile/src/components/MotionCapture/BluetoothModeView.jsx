import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
} from "react-native";
import {
  Bluetooth,
  BluetoothOff,
  Search,
  RotateCcw,
  Video,
  Camera,
  Wifi,
} from "lucide-react-native";
import { styles } from "./styles";
import {
  getBatteryColor,
  getSignalBars,
  getSignalStrengthColor,
} from "@/utils/motionCaptureUtils";

const DeviceCard = ({ item, connectToDevice, isConnecting }) => (
  <TouchableOpacity
    style={styles.deviceCard}
    onPress={() => connectToDevice(item)}
    disabled={isConnecting}
  >
    <View style={styles.deviceCardContent}>
      <View style={styles.deviceTypeIcon}>
        {item.type === "camcorder" && <Video size={20} color="#B8860B" />}
        {item.type === "dslr" && <Camera size={20} color="#B8860B" />}
        {item.type === "action_cam" && <Camera size={20} color="#B8860B" />}
        {item.type === "gimbal_cam" && <Video size={20} color="#B8860B" />}
      </View>

      <View style={styles.deviceCardInfo}>
        <Text style={styles.deviceCardName}>{item.name}</Text>
        <Text style={styles.deviceCardSpecs}>{item.quality}</Text>
        <View style={styles.deviceFeatures}>
          {item.features.slice(0, 2).map((feature, index) => (
            <Text key={index} style={styles.featureTag}>
              {feature.replace("_", " ")}
            </Text>
          ))}
        </View>
      </View>

      <View style={styles.deviceCardStatus}>
        <View style={styles.batteryIndicator}>
          <Text
            style={[
              styles.batteryText,
              { color: getBatteryColor(item.battery) },
            ]}
          >
            {item.battery}%
          </Text>
        </View>

        <View style={styles.signalIndicator}>
          {Array.from({ length: 4 }).map((_, i) => (
            <View
              key={i}
              style={[
                styles.signalBar,
                {
                  backgroundColor:
                    i < getSignalBars(item.signal_strength)
                      ? getSignalStrengthColor(item.signal_strength)
                      : "#E5E7EB",
                  height: 8 + i * 2,
                },
              ]}
            />
          ))}
        </View>

        {isConnecting ? (
          <ActivityIndicator size="small" color="#B8860B" />
        ) : (
          <Wifi size={16} color="#666" />
        )}
      </View>
    </View>
  </TouchableOpacity>
);

export function BluetoothModeView({ bluetooth, setMode }) {
  const {
    bluetoothEnabled,
    isScanning,
    availableDevices,
    connectToDevice,
    isConnecting,
    scanForDevices,
  } = bluetooth;

  return (
    <View style={styles.content}>
      <View style={styles.bluetoothHeader}>
        <View style={styles.bluetoothStatus}>
          {bluetoothEnabled ? (
            <Bluetooth size={24} color="#10B981" />
          ) : (
            <BluetoothOff size={24} color="#EF4444" />
          )}
          <Text style={styles.bluetoothStatusText}>
            {bluetoothEnabled ? "Bluetooth Enabled" : "Bluetooth Disabled"}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.scanButton}
          onPress={scanForDevices}
          disabled={!bluetoothEnabled || isScanning}
        >
          {isScanning ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <Search size={16} color="white" />
          )}
          <Text style={styles.scanButtonText}>
            {isScanning ? "Scanning..." : "Scan Devices"}
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={availableDevices}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <DeviceCard
            item={item}
            connectToDevice={connectToDevice}
            isConnecting={isConnecting}
          />
        )}
        ListEmptyComponent={() => (
          <View style={styles.emptyDeviceList}>
            <Bluetooth size={48} color="#666" />
            <Text style={styles.emptyDeviceText}>
              {isScanning ? "Searching for devices..." : "No devices found"}
            </Text>
            <Text style={styles.emptyDeviceSubtext}>
              {isScanning
                ? "Make sure your camcorder is in pairing mode"
                : 'Tap "Scan Devices" to search for Bluetooth camcorders'}
            </Text>
          </View>
        )}
        style={styles.deviceList}
      />

      <TouchableOpacity
        style={styles.backButton}
        onPress={() => setMode("selection")}
      >
        <RotateCcw size={16} color="#1D2B3D" />
        <Text style={styles.backButtonText}>Back to Capture</Text>
      </TouchableOpacity>
    </View>
  );
}
