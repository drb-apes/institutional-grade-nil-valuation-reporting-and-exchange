import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { CameraView } from "expo-camera";
import {
  RotateCcw,
  ZapOff,
  Zap,
  FlipHorizontal,
  Play,
  StopCircle,
  Camera as CameraIcon,
  Video,
  Settings,
} from "lucide-react-native";
import { styles } from "./styles";
import {
  formatTime,
  getBatteryColor,
  getSignalBars,
  getSignalStrengthColor,
} from "@/utils/motionCaptureUtils";

const PhoneCameraView = ({
  cameraRef,
  facing,
  flash,
  captureType,
  isRecording,
  recordingTime,
  countdown,
  setMode,
  toggleFlash,
  toggleCameraFacing,
  startCountdown,
  stopRecording,
  takePicture,
}) => (
  <CameraView
    ref={cameraRef}
    style={styles.camera}
    facing={facing}
    flash={flash}
    mode={captureType}
  >
    {isRecording && (
      <View style={styles.recordingOverlay}>
        <View style={styles.recordingIndicator}>
          <View style={styles.recordingDot} />
          <Text style={styles.recordingText}>
            REC {formatTime(recordingTime)}
          </Text>
        </View>
      </View>
    )}

    {countdown > 0 && (
      <View style={styles.countdownOverlay}>
        <Text style={styles.countdownText}>{countdown}</Text>
      </View>
    )}

    <View style={styles.cameraControls}>
      <View style={styles.topControls}>
        <TouchableOpacity
          style={styles.controlButton}
          onPress={() => setMode("selection")}
        >
          <RotateCcw size={20} color="white" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.controlButton} onPress={toggleFlash}>
          {flash === "off" ? (
            <ZapOff size={20} color="white" />
          ) : (
            <Zap size={20} color="#FFD700" />
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.controlButton}
          onPress={toggleCameraFacing}
        >
          <FlipHorizontal size={20} color="white" />
        </TouchableOpacity>
      </View>

      <View style={styles.bottomControls}>
        {captureType === "video" ? (
          !isRecording ? (
            <TouchableOpacity
              style={styles.recordButton}
              onPress={startCountdown}
            >
              <Play size={24} color="white" />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={styles.stopButton} onPress={stopRecording}>
              <StopCircle size={24} color="white" />
            </TouchableOpacity>
          )
        ) : (
          <TouchableOpacity style={styles.captureButton} onPress={takePicture}>
            <CameraIcon size={24} color="white" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  </CameraView>
);

const BluetoothCameraView = ({
  connectedDevice,
  isRecording,
  recordingTime,
  setMode,
  stopBluetoothRecording,
  startBluetoothRecording,
  disconnectDevice,
}) => (
  <View style={styles.bluetoothCameraView}>
    <View style={styles.bluetoothCameraHeader}>
      <Text style={styles.bluetoothCameraTitle}>
        Recording with {connectedDevice.name}
      </Text>
      <Text style={styles.bluetoothCameraQuality}>
        {connectedDevice.quality}
      </Text>
    </View>

    <View style={styles.livePreviewPlaceholder}>
      <Video size={64} color="#666" />
      <Text style={styles.livePreviewText}>Live Preview</Text>
      <Text style={styles.livePreviewSubtext}>
        {isRecording
          ? `Recording ${formatTime(recordingTime)}`
          : "Ready to record"}
      </Text>
    </View>

    <View style={styles.bluetoothControls}>
      <TouchableOpacity
        style={styles.controlButton}
        onPress={() => setMode("selection")}
      >
        <RotateCcw size={20} color="white" />
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          styles.bluetoothRecordButton,
          isRecording && styles.bluetoothStopButton,
        ]}
        onPress={isRecording ? stopBluetoothRecording : startBluetoothRecording}
      >
        {isRecording ? (
          <StopCircle size={32} color="white" />
        ) : (
          <Play size={32} color="white" />
        )}
      </TouchableOpacity>
      <TouchableOpacity style={styles.controlButton} onPress={disconnectDevice}>
        <Settings size={20} color="white" />
      </TouchableOpacity>
    </View>

    <View style={styles.deviceStatusBar}>
      <View style={styles.statusItem}>
        <Text style={styles.statusLabel}>Battery</Text>
        <Text
          style={[
            styles.statusValue,
            { color: getBatteryColor(connectedDevice.battery) },
          ]}
        >
          {connectedDevice.battery}%
        </Text>
      </View>
      <View style={styles.statusItem}>
        <Text style={styles.statusLabel}>Signal</Text>
        <View style={styles.signalIndicator}>
          {Array.from({ length: 4 }).map((_, i) => (
            <View
              key={i}
              style={[
                styles.signalBar,
                {
                  backgroundColor:
                    i < getSignalBars(connectedDevice.signal_strength)
                      ? getSignalStrengthColor(connectedDevice.signal_strength)
                      : "#E5E7EB",
                  height: 8 + i * 2,
                },
              ]}
            />
          ))}
        </View>
      </View>
    </View>
  </View>
);

export function CameraModeView({ motion, bluetooth, setMode }) {
  const { connectedDevice, disconnectDevice } = bluetooth;
  const {
    cameraRef,
    facing,
    flash,
    captureType,
    isRecording,
    recordingTime,
    countdown,
    toggleFlash,
    toggleCameraFacing,
    startCountdown,
    stopRecording,
    takePicture,
    startBluetoothRecording,
    stopBluetoothRecording,
  } = motion;

  return (
    <View style={styles.cameraContainer}>
      {!connectedDevice ? (
        <PhoneCameraView
          cameraRef={cameraRef}
          facing={facing}
          flash={flash}
          captureType={captureType}
          isRecording={isRecording}
          recordingTime={recordingTime}
          countdown={countdown}
          setMode={setMode}
          toggleFlash={toggleFlash}
          toggleCameraFacing={toggleCameraFacing}
          startCountdown={startCountdown}
          stopRecording={stopRecording}
          takePicture={takePicture}
        />
      ) : (
        <BluetoothCameraView
          connectedDevice={connectedDevice}
          isRecording={isRecording}
          recordingTime={recordingTime}
          setMode={setMode}
          startBluetoothRecording={startBluetoothRecording}
          stopBluetoothRecording={stopBluetoothRecording}
          disconnectDevice={disconnectDevice}
        />
      )}
    </View>
  );
}
