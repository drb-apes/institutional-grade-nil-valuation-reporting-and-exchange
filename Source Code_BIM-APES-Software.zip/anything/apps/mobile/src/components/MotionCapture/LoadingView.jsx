import React from "react";
import { ActivityIndicator, Text, View } from "react-native";
import { styles } from "./styles";

export function LoadingView() {
  return (
    <View style={styles.loadingContainer}>
      <ActivityIndicator size="large" color="#B8860B" />
      <Text style={styles.loadingText}>Loading...</Text>
    </View>
  );
}
