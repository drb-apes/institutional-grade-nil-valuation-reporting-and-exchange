import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import {
  Trophy,
  Target,
  Zap,
  Shield,
  Clock,
  TrendingUp,
} from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function WrestlingPerformanceTracker({
  athleteId,
  performanceData,
}) {
  const insets = useSafeAreaInsets();
  const [takedownStats, setTakedownStats] = useState(null);
  const [defensiveMetrics, setDefensiveMetrics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (athleteId) {
      fetchWrestlingMetrics();
    }
  }, [athleteId]);

  const fetchWrestlingMetrics = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `/api/bim-performance/wrestling?athlete_id=${athleteId}`,
      );
      if (response.ok) {
        const data = await response.json();
        setTakedownStats(data.takedown_metrics);
        setDefensiveMetrics(data.defensive_metrics);
      }
    } catch (error) {
      console.error("Error fetching wrestling metrics:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0C141E",
          paddingTop: insets.top,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Text style={{ color: "#FFF", fontSize: 16 }}>
          Loading wrestling metrics...
        </Text>
      </View>
    );
  }

  const wrestlingMetrics = [
    {
      title: "Takedown Efficiency",
      value: takedownStats?.efficiency || 0,
      unit: "%",
      icon: Target,
      color: "#B8860B",
      trend: takedownStats?.trend || 0,
    },
    {
      title: "Defensive Stability",
      value: defensiveMetrics?.stability_score || 0,
      unit: "/100",
      icon: Shield,
      color: "#10B981",
      trend: defensiveMetrics?.trend || 0,
    },
    {
      title: "Explosive Power",
      value: performanceData?.spike_score || 0,
      unit: "/100",
      icon: Zap,
      color: "#F59E0B",
      trend: performanceData?.power_trend || 0,
    },
    {
      title: "Match Endurance",
      value: performanceData?.recovery_index || 0,
      unit: "/100",
      icon: Clock,
      color: "#3B82F6",
      trend: performanceData?.endurance_trend || 0,
    },
  ];

  const positionAnalysis = [
    {
      position: "Standing",
      success_rate: takedownStats?.standing_success || 0,
    },
    { position: "Top Control", success_rate: takedownStats?.top_control || 0 },
    {
      position: "Bottom Escape",
      success_rate: defensiveMetrics?.escape_rate || 0,
    },
    {
      position: "Neutral Tie-ups",
      success_rate: takedownStats?.neutral_success || 0,
    },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: "#0C141E" }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            backgroundColor: "#B8860B",
            padding: 20,
            paddingTop: insets.top + 20,
            borderBottomLeftRadius: 20,
            borderBottomRightRadius: 20,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <Trophy size={32} color="#FFF" />
            <Text
              style={{
                fontSize: 24,
                fontWeight: "bold",
                color: "#FFF",
                marginLeft: 12,
              }}
            >
              Wrestling Performance
            </Text>
          </View>
          <Text style={{ color: "#FFF", opacity: 0.9 }}>
            Goal-wrestling focused performance tracking
          </Text>
        </View>

        <View style={{ padding: 20 }}>
          {/* Key Metrics Grid */}
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              justifyContent: "space-between",
              marginBottom: 20,
            }}
          >
            {wrestlingMetrics.map((metric, index) => {
              const IconComponent = metric.icon;
              return (
                <View
                  key={index}
                  style={{
                    width: "48%",
                    backgroundColor: "#1D2B3D",
                    borderRadius: 12,
                    padding: 16,
                    marginBottom: 12,
                    borderWidth: 1,
                    borderColor: "#374151",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      marginBottom: 8,
                    }}
                  >
                    <IconComponent size={24} color={metric.color} />
                    <View
                      style={{ flexDirection: "row", alignItems: "center" }}
                    >
                      <TrendingUp
                        size={16}
                        color={metric.trend >= 0 ? "#10B981" : "#EF4444"}
                        style={{
                          transform: [
                            { rotate: metric.trend < 0 ? "180deg" : "0deg" },
                          ],
                        }}
                      />
                      <Text
                        style={{
                          fontSize: 12,
                          color: metric.trend >= 0 ? "#10B981" : "#EF4444",
                          marginLeft: 4,
                        }}
                      >
                        {Math.abs(metric.trend).toFixed(1)}%
                      </Text>
                    </View>
                  </View>
                  <Text
                    style={{
                      fontSize: 28,
                      fontWeight: "bold",
                      color: "#FFF",
                      marginBottom: 4,
                    }}
                  >
                    {metric.value}
                    {metric.unit}
                  </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      color: "#9CA3AF",
                    }}
                  >
                    {metric.title}
                  </Text>
                </View>
              );
            })}
          </View>

          {/* Position Analysis */}
          <View
            style={{
              backgroundColor: "#1D2B3D",
              borderRadius: 12,
              padding: 20,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: "#374151",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#FFF",
                marginBottom: 16,
              }}
            >
              Position Success Rates
            </Text>
            {positionAnalysis.map((position, index) => (
              <View
                key={index}
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 12,
                }}
              >
                <Text style={{ color: "#D1D5DB", fontWeight: "500", flex: 1 }}>
                  {position.position}
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    flex: 1,
                  }}
                >
                  <View
                    style={{
                      flex: 1,
                      height: 8,
                      backgroundColor: "#374151",
                      borderRadius: 4,
                      marginRight: 12,
                    }}
                  >
                    <View
                      style={{
                        width: `${position.success_rate}%`,
                        height: 8,
                        backgroundColor: "#B8860B",
                        borderRadius: 4,
                      }}
                    />
                  </View>
                  <Text
                    style={{
                      color: "#FFF",
                      fontWeight: "bold",
                      minWidth: 40,
                      textAlign: "right",
                    }}
                  >
                    {position.success_rate}%
                  </Text>
                </View>
              </View>
            ))}
          </View>

          {/* Technique Breakdown */}
          <View
            style={{
              backgroundColor: "#1D2B3D",
              borderRadius: 12,
              padding: 20,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: "#374151",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#FFF",
                marginBottom: 16,
              }}
            >
              Technique Focus Areas
            </Text>
            <View style={{ flexDirection: "row" }}>
              <View style={{ flex: 1, marginRight: 10 }}>
                <Text
                  style={{
                    color: "#B8860B",
                    fontWeight: "600",
                    marginBottom: 12,
                  }}
                >
                  Strengths
                </Text>
                {[
                  "Explosive takedown initiation",
                  "Strong defensive positioning",
                  "Consistent mat awareness",
                ].map((strength, index) => (
                  <View
                    key={index}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 8,
                    }}
                  >
                    <View
                      style={{
                        width: 8,
                        height: 8,
                        backgroundColor: "#10B981",
                        borderRadius: 4,
                        marginRight: 8,
                      }}
                    />
                    <Text style={{ color: "#D1D5DB", fontSize: 12, flex: 1 }}>
                      {strength}
                    </Text>
                  </View>
                ))}
              </View>
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text
                  style={{
                    color: "#F59E0B",
                    fontWeight: "600",
                    marginBottom: 12,
                  }}
                >
                  Improvement Areas
                </Text>
                {[
                  "Chain wrestling combinations",
                  "Bottom position escapes",
                  "Transition speed",
                ].map((area, index) => (
                  <View
                    key={index}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 8,
                    }}
                  >
                    <View
                      style={{
                        width: 8,
                        height: 8,
                        backgroundColor: "#F59E0B",
                        borderRadius: 4,
                        marginRight: 8,
                      }}
                    />
                    <Text style={{ color: "#D1D5DB", fontSize: 12, flex: 1 }}>
                      {area}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          </View>

          {/* AI Recommendations */}
          <View
            style={{
              backgroundColor: "#1D2B3D",
              borderRadius: 12,
              padding: 20,
              borderWidth: 2,
              borderColor: "#B8860B",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#FFF",
                marginBottom: 16,
              }}
            >
              AI Coaching Recommendations
            </Text>
            <TouchableOpacity
              style={{
                backgroundColor: "rgba(184, 134, 11, 0.2)",
                borderRadius: 8,
                padding: 12,
                marginBottom: 12,
                flexDirection: "row",
                alignItems: "flex-start",
              }}
            >
              <Target
                size={20}
                color="#B8860B"
                style={{ marginTop: 2, marginRight: 12 }}
              />
              <View style={{ flex: 1 }}>
                <Text
                  style={{ color: "#FFF", fontWeight: "500", marginBottom: 4 }}
                >
                  Focus on Chain Wrestling
                </Text>
                <Text style={{ color: "#D1D5DB", fontSize: 12 }}>
                  Practice 3-move combinations to improve takedown completion
                  rate by 15%
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                backgroundColor: "rgba(16, 185, 129, 0.2)",
                borderRadius: 8,
                padding: 12,
                flexDirection: "row",
                alignItems: "flex-start",
              }}
            >
              <Shield
                size={20}
                color="#10B981"
                style={{ marginTop: 2, marginRight: 12 }}
              />
              <View style={{ flex: 1 }}>
                <Text
                  style={{ color: "#FFF", fontWeight: "500", marginBottom: 4 }}
                >
                  Defensive Positioning Drills
                </Text>
                <Text style={{ color: "#D1D5DB", fontSize: 12 }}>
                  Work on hip positioning and sprawl mechanics for stronger
                  defense
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
