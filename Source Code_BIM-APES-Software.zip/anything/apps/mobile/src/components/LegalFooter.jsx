import { View, Text, TouchableOpacity, Linking } from "react-native";
import { ExternalLink, Scale, FileText } from "lucide-react-native";

export default function LegalFooter() {
  const openLink = (url) => {
    Linking.openURL(url).catch((err) =>
      console.error("Failed to open URL:", err),
    );
  };

  return (
    <View
      style={{
        backgroundColor: "#0F172A",
        borderTopWidth: 1,
        borderTopColor: "#334155",
        paddingHorizontal: 20,
        paddingVertical: 24,
      }}
    >
      {/* Copyright */}
      <View style={{ marginBottom: 20 }}>
        <Text
          style={{
            color: "#FFFFFF",
            fontSize: 16,
            fontWeight: "600",
            textAlign: "center",
            marginBottom: 8,
          }}
        >
          © {new Date().getFullYear()} Dashawn Ramel Bledsoe / NIBLS Inc.
        </Text>
        <Text
          style={{
            color: "#FFFFFF",
            fontSize: 16,
            fontWeight: "600",
            textAlign: "center",
            marginBottom: 12,
          }}
        >
          All Rights Reserved.
        </Text>
        <Text
          style={{
            color: "#CBD5E1",
            fontSize: 13,
            textAlign: "center",
            lineHeight: 20,
          }}
        >
          BIM‑APES Software and all related technologies are developed and
          published by{" "}
          <Text style={{ fontWeight: "600", color: "#60A5FA" }}>
            Bledsoe Investment Management
          </Text>
          , a division of NIBLS Inc.
        </Text>
      </View>

      {/* License Cards */}
      <View style={{ marginBottom: 20 }}>
        {/* Software License */}
        <View
          style={{
            backgroundColor: "rgba(30, 41, 59, 0.5)",
            borderRadius: 12,
            padding: 16,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <View
            style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}
          >
            <FileText size={20} color="#60A5FA" style={{ marginTop: 2 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  color: "#FFFFFF",
                  fontSize: 14,
                  fontWeight: "600",
                  marginBottom: 6,
                }}
              >
                Software License
              </Text>
              <Text style={{ color: "#CBD5E1", fontSize: 12, lineHeight: 18 }}>
                Portions of this application are licensed under the Apache
                License, Version 2.0.
              </Text>
              <TouchableOpacity
                onPress={() =>
                  openLink("https://www.apache.org/licenses/LICENSE-2.0")
                }
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 4,
                  marginTop: 8,
                }}
              >
                <Text style={{ color: "#60A5FA", fontSize: 12 }}>
                  View License
                </Text>
                <ExternalLink size={12} color="#60A5FA" />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Content License */}
        <View
          style={{
            backgroundColor: "rgba(30, 41, 59, 0.5)",
            borderRadius: 12,
            padding: 16,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <View
            style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}
          >
            <Scale size={20} color="#34D399" style={{ marginTop: 2 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  color: "#FFFFFF",
                  fontSize: 14,
                  fontWeight: "600",
                  marginBottom: 6,
                }}
              >
                Content License
              </Text>
              <Text style={{ color: "#CBD5E1", fontSize: 12, lineHeight: 18 }}>
                All non‑software content—including reports, visualizations,
                branding, and documentation—is licensed under CC BY-NC-ND 4.0.
              </Text>
              <TouchableOpacity
                onPress={() =>
                  openLink("https://creativecommons.org/licenses/by-nc-nd/4.0/")
                }
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 4,
                  marginTop: 8,
                }}
              >
                <Text style={{ color: "#34D399", fontSize: 12 }}>
                  View License
                </Text>
                <ExternalLink size={12} color="#34D399" />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>

      {/* Trademark Notice */}
      <View style={{ marginBottom: 20 }}>
        <Text
          style={{
            color: "#94A3B8",
            fontSize: 12,
            textAlign: "center",
            lineHeight: 18,
          }}
        >
          Use of trademarks, branding, and proprietary valuation models requires
          written permission from NIBLS Inc.
        </Text>
      </View>

      {/* Reference Link */}
      <View
        style={{
          paddingTop: 16,
          borderTopWidth: 1,
          borderTopColor: "#334155",
          marginBottom: 16,
        }}
      >
        <Text
          style={{
            color: "#94A3B8",
            fontSize: 11,
            textAlign: "center",
            marginBottom: 8,
          }}
        >
          Prior Art & Technical Reference
        </Text>
        <TouchableOpacity
          onPress={() => openLink("https://priorart.ip.com/IPCOM/000271355")}
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <ExternalLink size={14} color="#60A5FA" />
          <Text
            style={{ color: "#60A5FA", fontSize: 13, fontFamily: "monospace" }}
          >
            priorart.ip.com/IPCOM/000271355
          </Text>
        </TouchableOpacity>
      </View>

      {/* Additional Links */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "center",
          gap: 20,
          paddingTop: 16,
          borderTopWidth: 1,
          borderTopColor: "#334155",
        }}
      >
        <TouchableOpacity
          onPress={() => openLink("https://github.com/bim-apes")}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Text style={{ color: "#94A3B8", fontSize: 13 }}>GitHub</Text>
            <ExternalLink size={12} color="#94A3B8" />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}
