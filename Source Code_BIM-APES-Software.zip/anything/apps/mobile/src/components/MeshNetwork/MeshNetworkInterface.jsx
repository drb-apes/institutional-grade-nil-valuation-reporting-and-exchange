import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Wifi,
  WifiOff,
  Bluetooth,
  Users,
  Play,
  StopCircle,
  Settings,
  Smartphone,
  Monitor,
  Router,
  Share,
  Clock,
  Activity,
  Target,
  AlertCircle,
  CheckCircle,
  XCircle,
} from "lucide-react-native";
import { useMeshNetwork } from "@/hooks/useMeshNetwork";

const MeshNetworkInterface = () => {
  const insets = useSafeAreaInsets();
  const [joinCode, setJoinCode] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);

  const {
    meshStatus,
    meshDevices,
    meshId,
    isHost,
    offlineQueue,
    meshPermissions,
    hotspotEnabled,
    bluetoothMeshActive,
    createMeshNetwork,
    joinMeshNetwork,
    leaveMeshNetwork,
    broadcastToMesh,
    startRecordingSync,
    stopRecordingSync,
    getMeshNetworkInfo,
    discoverNearbyDevices,
  } = useMeshNetwork();

  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);

  useEffect(() => {
    let interval;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "connected":
        return "#10B981";
      case "hosting":
        return "#B8860B";
      case "connecting":
        return "#F59E0B";
      default:
        return "#6B7280";
    }
  };

  const getDeviceIcon = (type) => {
    switch (type) {
      case "bluetooth":
        return Bluetooth;
      case "wifi_direct":
        return Wifi;
      default:
        return Smartphone;
    }
  };

  const handleStartRecording = async () => {
    if (meshDevices.length === 0) {
      Alert.alert(
        "No Devices",
        "Connect mesh devices before starting recording.",
      );
      return;
    }

    const recordingData = {
      sessionId: `rec_${Date.now()}`,
      quality: "HD",
      deviceCount: meshDevices.length,
      timestamp: Date.now(),
    };

    const success = await startRecordingSync(recordingData);
    if (success || meshStatus === "hosting") {
      setIsRecording(true);
      setRecordingDuration(0);
    }
  };

  const handleStopRecording = async () => {
    await stopRecordingSync();
    setIsRecording(false);
    setRecordingDuration(0);
  };

  const handleCreateMesh = async () => {
    const success = await createMeshNetwork();
    if (success) {
      await discoverNearbyDevices();
    }
  };

  const handleJoinMesh = async () => {
    if (joinCode.length < 6) {
      Alert.alert("Invalid Code", "Please enter a valid mesh network code.");
      return;
    }
    await joinMeshNetwork(joinCode.toUpperCase());
  };

  return (
    <View
      style={{ flex: 1, backgroundColor: "#1D2B3D", paddingTop: insets.top }}
    >
      <StatusBar style="light" />

      {/* Header */}
      <View
        style={{
          padding: 20,
          borderBottomWidth: 1,
          borderBottomColor: "#374151",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 8,
          }}
        >
          <Router size={24} color="#B8860B" />
          <Text
            style={{
              fontSize: 24,
              fontWeight: "bold",
              color: "white",
              marginLeft: 12,
            }}
          >
            Mesh Network
          </Text>
        </View>
        <Text style={{ color: "#9CA3AF", fontSize: 16 }}>
          Connect without Wi-Fi using mesh networking
        </Text>
      </View>

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        {/* Connection Status */}
        <View style={{ margin: 20 }}>
          <View
            style={{
              backgroundColor: "#374151",
              borderRadius: 12,
              padding: 20,
              borderWidth: 2,
              borderColor: getStatusColor(meshStatus),
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 16,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <View
                  style={{
                    width: 12,
                    height: 12,
                    borderRadius: 6,
                    backgroundColor: getStatusColor(meshStatus),
                    marginRight: 8,
                  }}
                />
                <Text
                  style={{
                    color: "white",
                    fontSize: 18,
                    fontWeight: "600",
                  }}
                >
                  {meshStatus.charAt(0).toUpperCase() + meshStatus.slice(1)}
                </Text>
              </View>

              {meshId && (
                <View
                  style={{
                    backgroundColor: "#B8860B",
                    paddingHorizontal: 12,
                    paddingVertical: 6,
                    borderRadius: 8,
                  }}
                >
                  <Text
                    style={{
                      color: "white",
                      fontWeight: "bold",
                      fontFamily: "monospace",
                    }}
                  >
                    {meshId}
                  </Text>
                </View>
              )}
            </View>

            {/* Connection Details */}
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
              }}
            >
              <View style={{ flex: 1 }}>
                <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                  Connected Devices
                </Text>
                <Text
                  style={{ color: "white", fontSize: 20, fontWeight: "bold" }}
                >
                  {meshDevices.length}
                </Text>
              </View>

              <View style={{ flex: 1 }}>
                <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                  Offline Queue
                </Text>
                <Text
                  style={{ color: "white", fontSize: 20, fontWeight: "bold" }}
                >
                  {offlineQueue.length}
                </Text>
              </View>

              <View style={{ flex: 1 }}>
                <Text style={{ color: "#9CA3AF", fontSize: 14 }}>Role</Text>
                <Text
                  style={{ color: "white", fontSize: 16, fontWeight: "600" }}
                >
                  {isHost ? "Host" : "Client"}
                </Text>
              </View>
            </View>

            {/* Connection Methods */}
            <View
              style={{
                flexDirection: "row",
                marginTop: 16,
                paddingTop: 16,
                borderTopWidth: 1,
                borderTopColor: "#4B5563",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginRight: 20,
                }}
              >
                <Bluetooth
                  size={16}
                  color={bluetoothMeshActive ? "#10B981" : "#6B7280"}
                />
                <Text
                  style={{
                    color: bluetoothMeshActive ? "#10B981" : "#6B7280",
                    marginLeft: 4,
                    fontSize: 12,
                  }}
                >
                  Bluetooth
                </Text>
              </View>

              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <Wifi
                  size={16}
                  color={hotspotEnabled ? "#10B981" : "#6B7280"}
                />
                <Text
                  style={{
                    color: hotspotEnabled ? "#10B981" : "#6B7280",
                    marginLeft: 4,
                    fontSize: 12,
                  }}
                >
                  WiFi Direct
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Network Actions */}
        {meshStatus === "disconnected" && (
          <View style={{ margin: 20 }}>
            <View
              style={{
                backgroundColor: "#374151",
                borderRadius: 12,
                padding: 20,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 16,
                }}
              >
                Create or Join Network
              </Text>

              {/* Create Network */}
              <TouchableOpacity
                onPress={handleCreateMesh}
                disabled={!meshPermissions}
                style={{
                  backgroundColor: meshPermissions ? "#B8860B" : "#6B7280",
                  borderRadius: 8,
                  padding: 16,
                  marginBottom: 16,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Users size={20} color="white" />
                <Text
                  style={{
                    color: "white",
                    fontWeight: "600",
                    marginLeft: 8,
                  }}
                >
                  Host New Mesh Network
                </Text>
              </TouchableOpacity>

              {/* Join Network */}
              <View style={{ marginBottom: 16 }}>
                <Text
                  style={{
                    color: "#9CA3AF",
                    fontSize: 14,
                    marginBottom: 8,
                  }}
                >
                  Or join existing network:
                </Text>
                <TextInput
                  value={joinCode}
                  onChangeText={setJoinCode}
                  placeholder="Enter Mesh ID (e.g., MESH-ABC123)"
                  placeholderTextColor="#6B7280"
                  style={{
                    backgroundColor: "#1F2937",
                    borderRadius: 8,
                    padding: 12,
                    color: "white",
                    fontSize: 16,
                    fontFamily: "monospace",
                    textAlign: "center",
                  }}
                  autoCapitalize="characters"
                  maxLength={12}
                />
              </View>

              <TouchableOpacity
                onPress={handleJoinMesh}
                disabled={!meshPermissions || joinCode.length < 6}
                style={{
                  backgroundColor:
                    meshPermissions && joinCode.length >= 6
                      ? "#10B981"
                      : "#6B7280",
                  borderRadius: 8,
                  padding: 16,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Share size={20} color="white" />
                <Text
                  style={{
                    color: "white",
                    fontWeight: "600",
                    marginLeft: 8,
                  }}
                >
                  Join Mesh Network
                </Text>
              </TouchableOpacity>

              {!meshPermissions && (
                <View
                  style={{
                    backgroundColor: "#FEF3C7",
                    borderRadius: 8,
                    padding: 12,
                    marginTop: 16,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                >
                  <AlertCircle size={16} color="#D97706" />
                  <Text
                    style={{
                      color: "#D97706",
                      fontSize: 12,
                      marginLeft: 8,
                      flex: 1,
                    }}
                  >
                    Bluetooth and WiFi permissions required for mesh networking
                  </Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Connected Devices */}
        {meshDevices.length > 0 && (
          <View style={{ margin: 20 }}>
            <View
              style={{
                backgroundColor: "#374151",
                borderRadius: 12,
                padding: 20,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 16,
                }}
              >
                Mesh Devices ({meshDevices.length})
              </Text>

              {meshDevices.map((device, index) => {
                const DeviceIcon = getDeviceIcon(device.type);
                return (
                  <View
                    key={device.id}
                    style={{
                      backgroundColor: "#1F2937",
                      borderRadius: 8,
                      padding: 16,
                      marginBottom: index < meshDevices.length - 1 ? 12 : 0,
                      flexDirection: "row",
                      alignItems: "center",
                    }}
                  >
                    <DeviceIcon size={20} color="#B8860B" />
                    <View style={{ flex: 1, marginLeft: 12 }}>
                      <Text
                        style={{
                          color: "white",
                          fontWeight: "600",
                          fontSize: 16,
                        }}
                      >
                        {device.name}
                      </Text>
                      <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                        {device.type === "bluetooth"
                          ? `RSSI: ${device.rssi}dBm`
                          : `Signal: ${device.signal}%`}
                      </Text>
                    </View>

                    <View
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: 4,
                        backgroundColor: "#10B981",
                      }}
                    />
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Recording Controls */}
        {(meshStatus === "connected" || meshStatus === "hosting") && (
          <View style={{ margin: 20 }}>
            <View
              style={{
                backgroundColor: "#374151",
                borderRadius: 12,
                padding: 20,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 16,
                }}
              >
                Synchronized Recording
              </Text>

              {!isRecording ? (
                <TouchableOpacity
                  onPress={handleStartRecording}
                  style={{
                    backgroundColor: "#10B981",
                    borderRadius: 8,
                    padding: 16,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Play size={20} color="white" />
                  <Text
                    style={{
                      color: "white",
                      fontWeight: "600",
                      marginLeft: 8,
                    }}
                  >
                    Start Mesh Recording
                  </Text>
                </TouchableOpacity>
              ) : (
                <View>
                  <View
                    style={{
                      backgroundColor: "#1F2937",
                      borderRadius: 8,
                      padding: 16,
                      marginBottom: 16,
                      alignItems: "center",
                    }}
                  >
                    <View
                      style={{
                        width: 12,
                        height: 12,
                        borderRadius: 6,
                        backgroundColor: "#EF4444",
                        marginBottom: 8,
                      }}
                    />
                    <Text
                      style={{
                        color: "white",
                        fontSize: 24,
                        fontWeight: "bold",
                        fontFamily: "monospace",
                      }}
                    >
                      {formatTime(recordingDuration)}
                    </Text>
                    <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                      Recording in progress...
                    </Text>
                  </View>

                  <TouchableOpacity
                    onPress={handleStopRecording}
                    style={{
                      backgroundColor: "#EF4444",
                      borderRadius: 8,
                      padding: 16,
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <StopCircle size={20} color="white" />
                    <Text
                      style={{
                        color: "white",
                        fontWeight: "600",
                        marginLeft: 8,
                      }}
                    >
                      Stop Recording
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Advanced Settings */}
        <View style={{ margin: 20 }}>
          <TouchableOpacity
            onPress={() => setShowAdvanced(!showAdvanced)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              backgroundColor: "#374151",
              borderRadius: 12,
              padding: 20,
              marginBottom: showAdvanced ? 16 : 0,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Settings size={20} color="#B8860B" />
              <Text
                style={{
                  color: "white",
                  fontSize: 16,
                  fontWeight: "600",
                  marginLeft: 8,
                }}
              >
                Advanced Settings
              </Text>
            </View>
            <Text style={{ color: "#9CA3AF", fontSize: 16 }}>
              {showAdvanced ? "▼" : "▶"}
            </Text>
          </TouchableOpacity>

          {showAdvanced && (
            <View
              style={{
                backgroundColor: "#374151",
                borderRadius: 12,
                padding: 20,
              }}
            >
              <View style={{ marginBottom: 16 }}>
                <Text
                  style={{
                    color: "white",
                    fontSize: 16,
                    fontWeight: "600",
                    marginBottom: 8,
                  }}
                >
                  Network Information
                </Text>
                <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                  Mesh ID: {meshId || "Not connected"}
                </Text>
                <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                  Device Count: {meshDevices.length}
                </Text>
                <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
                  Offline Queue: {offlineQueue.length} items
                </Text>
              </View>

              {(meshStatus === "connected" || meshStatus === "hosting") && (
                <TouchableOpacity
                  onPress={leaveMeshNetwork}
                  style={{
                    backgroundColor: "#EF4444",
                    borderRadius: 8,
                    padding: 16,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <XCircle size={20} color="white" />
                  <Text
                    style={{
                      color: "white",
                      fontWeight: "600",
                      marginLeft: 8,
                    }}
                  >
                    Leave Mesh Network
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>

        {/* Benefits */}
        <View style={{ margin: 20, marginBottom: 40 }}>
          <Text
            style={{
              color: "white",
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 16,
            }}
          >
            Mesh Network Benefits
          </Text>

          <View
            style={{
              backgroundColor: "#374151",
              borderRadius: 12,
              padding: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <WifiOff size={16} color="#10B981" />
              <Text
                style={{
                  color: "#10B981",
                  marginLeft: 8,
                  fontSize: 14,
                  fontWeight: "600",
                }}
              >
                No Wi-Fi Required
              </Text>
            </View>
            <Text style={{ color: "#9CA3AF", fontSize: 14, marginBottom: 16 }}>
              Direct device-to-device communication using Bluetooth and WiFi
              Direct
            </Text>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <Target size={16} color="#B8860B" />
              <Text
                style={{
                  color: "#B8860B",
                  marginLeft: 8,
                  fontSize: 14,
                  fontWeight: "600",
                }}
              >
                Perfect Synchronization
              </Text>
            </View>
            <Text style={{ color: "#9CA3AF", fontSize: 14, marginBottom: 16 }}>
              Synchronized recording across all connected devices with precision
              timing
            </Text>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <Activity size={16} color="#10B981" />
              <Text
                style={{
                  color: "#10B981",
                  marginLeft: 8,
                  fontSize: 14,
                  fontWeight: "600",
                }}
              >
                Offline Data Sync
              </Text>
            </View>
            <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
              Automatic data synchronization when devices reconnect to the mesh
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default MeshNetworkInterface;
