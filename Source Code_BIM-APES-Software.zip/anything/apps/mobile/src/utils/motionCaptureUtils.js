export const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs
    .toString()
    .padStart(2, "0")}`;
};

export const getSignalStrengthColor = (strength) => {
  if (strength > -40) return "#10B981"; // Strong
  if (strength > -60) return "#F59E0B"; // Medium
  return "#EF4444"; // Weak
};

export const getSignalBars = (strength) => {
  if (strength > -40) return 4;
  if (strength > -50) return 3;
  if (strength > -60) return 2;
  return 1;
};

export const getBatteryColor = (level) => {
  if (level > 60) return "#10B981";
  if (level > 30) return "#F59E0B";
  return "#EF4444";
};

export const mockBluetoothDevices = [
  {
    id: "sony_fx3_001",
    name: "Sony FX3 Camcorder",
    type: "camcorder",
    battery: 85,
    quality: "4K 120fps",
    features: ["remote_control", "live_preview", "auto_focus"],
    signal_strength: -45,
  },
  {
    id: "canon_eos_r5_002",
    name: "Canon EOS R5",
    type: "dslr",
    battery: 92,
    quality: "8K 30fps",
    features: ["remote_control", "live_preview", "manual_controls"],
    signal_strength: -52,
  },
  {
    id: "gopro_hero12_003",
    name: "GoPro Hero12 Black",
    type: "action_cam",
    battery: 78,
    quality: "5.3K 60fps",
    features: ["remote_control", "stabilization", "waterproof"],
    signal_strength: -38,
  },
  {
    id: "dji_pocket2_004",
    name: "DJI Pocket 2",
    type: "gimbal_cam",
    battery: 65,
    quality: "4K 60fps",
    features: ["gimbal_stabilization", "object_tracking", "timelapse"],
    signal_strength: -41,
  },
];
