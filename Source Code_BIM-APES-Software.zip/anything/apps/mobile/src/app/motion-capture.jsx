import React, { useState } from "react";
import { View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useUser } from "@/utils/auth/useUser";
import { useAuth } from "@/utils/auth/useAuth";
import { useBluetoothManager } from "@/hooks/useBluetoothManager";
import { useMotionCapture } from "@/hooks/useMotionCapture";
import { LoadingView } from "@/components/MotionCapture/LoadingView";
import { AuthView } from "@/components/MotionCapture/AuthView";
import { PermissionView } from "@/components/MotionCapture/PermissionView";
import { Header } from "@/components/MotionCapture/Header";
import { SelectionModeView } from "@/components/MotionCapture/SelectionModeView";
import { BluetoothModeView } from "@/components/MotionCapture/BluetoothModeView";
import { CameraModeView } from "@/components/MotionCapture/CameraModeView";
import { ProcessingModeView } from "@/components/MotionCapture/ProcessingModeView";
import { ResultsModeView } from "@/components/MotionCapture/ResultsModeView";
import { styles } from "@/components/MotionCapture/styles";

export default function MotionCapture() {
  const insets = useSafeAreaInsets();
  const { loading: userLoading } = useUser();
  const { isAuthenticated, signIn } = useAuth();

  const [mode, setMode] = useState("selection");

  const bluetooth = useBluetoothManager(setMode);
  const motion = useMotionCapture(mode, setMode, bluetooth.connectedDevice);

  const renderContent = () => {
    switch (mode) {
      case "selection":
        return (
          <SelectionModeView
            setMode={setMode}
            setCaptureType={motion.setCaptureType}
            pickFromLibrary={motion.pickFromLibrary}
            connectedDevice={bluetooth.connectedDevice}
          />
        );
      case "bluetooth":
        return <BluetoothModeView bluetooth={bluetooth} setMode={setMode} />;
      case "camera":
        return (
          <CameraModeView
            motion={motion}
            bluetooth={bluetooth}
            setMode={setMode}
          />
        );
      case "processing":
        return (
          <ProcessingModeView
            selectedMedia={motion.selectedMedia}
            processAnalysis={motion.processAnalysis}
            isProcessing={motion.isProcessing}
            resetCapture={motion.resetCapture}
          />
        );
      case "results":
        return (
          <ResultsModeView
            analysisResults={motion.analysisResults}
            resetCapture={motion.resetCapture}
          />
        );
      default:
        return null;
    }
  };

  const containerStyle = [
    styles.container,
    { paddingTop: insets.top, paddingBottom: insets.bottom },
  ];

  if (userLoading) {
    return (
      <View style={containerStyle}>
        <StatusBar style="dark" />
        <LoadingView />
      </View>
    );
  }

  if (!isAuthenticated) {
    return (
      <View style={containerStyle}>
        <StatusBar style="dark" />
        <AuthView signIn={signIn} />
      </View>
    );
  }

  if (!motion.permission || !motion.permission.granted) {
    return (
      <View style={containerStyle}>
        <StatusBar style="dark" />
        <PermissionView
          permission={motion.permission}
          requestPermission={motion.requestPermission}
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={{ paddingTop: insets.top }}>
        {mode !== "camera" && (
          <Header
            connectedDevice={bluetooth.connectedDevice}
            disconnectDevice={bluetooth.disconnectDevice}
            bluetoothEnabled={bluetooth.bluetoothEnabled}
            setMode={setMode}
          />
        )}
      </View>
      {renderContent()}
    </View>
  );
}
