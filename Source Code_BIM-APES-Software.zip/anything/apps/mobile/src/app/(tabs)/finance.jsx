import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  RefreshCcw,
  FileText,
  Brain,
  Shield,
} from "lucide-react-native";
import useUser from "../../utils/auth/useUser";

export default function FinanceDashboard() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const [financialData, setFinancialData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadFinancialData = async () => {
    try {
      const response = await fetch("/api/club-finance/capital-management");
      if (!response.ok) throw new Error("Failed to fetch financial data");

      const data = await response.json();
      setFinancialData(data.financial_overview);
    } catch (error) {
      Alert.alert("Error", "Failed to load financial data");
      console.error("Financial data error:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadFinancialData();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    loadFinancialData();
  };

  const handleQuickAction = async (action) => {
    switch (action) {
      case "invoice_discount":
        // Navigate to invoice discounting
        Alert.alert(
          "Invoice Discounting",
          "Opening invoice discounting interface...",
        );
        break;
      case "ai_advisor":
        // Open AI advisor
        Alert.alert("AI Advisor", "Connecting to AI financial advisor...");
        break;
      case "new_transaction":
        Alert.alert("New Transaction", "Transaction interface opening...");
        break;
    }
  };

  if (loading) {
    return (
      <View
        style={{ flex: 1, backgroundColor: "#F5F5F0", paddingTop: insets.top }}
      >
        <StatusBar style="dark" />
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <RefreshCcw size={48} color="#B8860B" />
          <Text style={{ marginTop: 16, fontSize: 18, color: "#1D2B3D" }}>
            Loading Financial Data...
          </Text>
        </View>
      </View>
    );
  }

  const currentBalance = financialData?.current_balance || 0;
  const cashFlowHealth =
    financialData?.ai_insights?.cash_flow_health || "stable";
  const riskFactors = financialData?.ai_insights?.risk_factors || [];
  const recommendations = financialData?.ai_insights?.recommendations || [];

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F5F5F0", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingVertical: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text
          style={{
            fontSize: 24,
            fontWeight: "bold",
            color: "#1D2B3D",
            marginBottom: 4,
          }}
        >
          Club Finance
        </Text>
        <Text style={{ fontSize: 14, color: "#6B7280" }}>
          Real-time financial management
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#B8860B"
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Financial Overview Cards */}
        <View style={{ padding: 20 }}>
          {/* Current Balance */}
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <Text
                style={{ fontSize: 16, color: "#6B7280", fontWeight: "500" }}
              >
                Current Balance
              </Text>
              <DollarSign size={24} color="#B8860B" />
            </View>
            <Text
              style={{
                fontSize: 32,
                fontWeight: "bold",
                color: "#1D2B3D",
                marginBottom: 8,
              }}
            >
              ${currentBalance.toLocaleString()}
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              {cashFlowHealth === "stable" ? (
                <>
                  <TrendingUp size={16} color="#10B981" />
                  <Text
                    style={{
                      marginLeft: 4,
                      color: "#10B981",
                      fontWeight: "500",
                    }}
                  >
                    Stable Cash Flow
                  </Text>
                </>
              ) : (
                <>
                  <TrendingDown size={16} color="#EF4444" />
                  <Text
                    style={{
                      marginLeft: 4,
                      color: "#EF4444",
                      fontWeight: "500",
                    }}
                  >
                    Declining Cash Flow
                  </Text>
                </>
              )}
            </View>
          </View>

          {/* Quick Actions */}
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#1D2B3D",
                marginBottom: 16,
              }}
            >
              Quick Actions
            </Text>

            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginBottom: 12,
              }}
            >
              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor: "#B8860B",
                  borderRadius: 12,
                  padding: 16,
                  marginRight: 8,
                  alignItems: "center",
                }}
                onPress={() => handleQuickAction("invoice_discount")}
              >
                <FileText size={24} color="#FFFFFF" />
                <Text
                  style={{
                    marginTop: 8,
                    fontSize: 12,
                    color: "#FFFFFF",
                    fontWeight: "500",
                    textAlign: "center",
                  }}
                >
                  Invoice Discounting
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor: "#1D2B3D",
                  borderRadius: 12,
                  padding: 16,
                  marginLeft: 8,
                  alignItems: "center",
                }}
                onPress={() => handleQuickAction("ai_advisor")}
              >
                <Brain size={24} color="#FFFFFF" />
                <Text
                  style={{
                    marginTop: 8,
                    fontSize: 12,
                    color: "#FFFFFF",
                    fontWeight: "500",
                    textAlign: "center",
                  }}
                >
                  AI Advisor
                </Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: "#F3F4F6",
                borderRadius: 12,
                padding: 16,
                alignItems: "center",
              }}
              onPress={() => handleQuickAction("new_transaction")}
            >
              <DollarSign size={24} color="#1D2B3D" />
              <Text
                style={{
                  marginTop: 8,
                  fontSize: 14,
                  color: "#1D2B3D",
                  fontWeight: "500",
                }}
              >
                New Transaction
              </Text>
            </TouchableOpacity>
          </View>

          {/* AI Insights */}
          {riskFactors.length > 0 && (
            <View
              style={{
                backgroundColor: "#FEF3CD",
                borderRadius: 16,
                padding: 20,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#F59E0B",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 12,
                }}
              >
                <AlertTriangle size={20} color="#F59E0B" />
                <Text
                  style={{
                    marginLeft: 8,
                    fontSize: 16,
                    fontWeight: "bold",
                    color: "#92400E",
                  }}
                >
                  Risk Factors
                </Text>
              </View>
              {riskFactors.map((risk, index) => (
                <Text
                  key={index}
                  style={{ fontSize: 14, color: "#92400E", marginBottom: 4 }}
                >
                  • {risk}
                </Text>
              ))}
            </View>
          )}

          {/* Recommendations */}
          {recommendations.length > 0 && (
            <View
              style={{
                backgroundColor: "#ECFDF5",
                borderRadius: 16,
                padding: 20,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#10B981",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 12,
                }}
              >
                <CheckCircle size={20} color="#10B981" />
                <Text
                  style={{
                    marginLeft: 8,
                    fontSize: 16,
                    fontWeight: "bold",
                    color: "#065F46",
                  }}
                >
                  AI Recommendations
                </Text>
              </View>
              {recommendations.map((rec, index) => (
                <Text
                  key={index}
                  style={{ fontSize: 14, color: "#065F46", marginBottom: 4 }}
                >
                  • {rec}
                </Text>
              ))}
            </View>
          )}

          {/* Recent Transactions */}
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#1D2B3D",
                marginBottom: 16,
              }}
            >
              Recent Transactions
            </Text>

            {financialData?.recent_transactions
              ?.slice(0, 5)
              .map((transaction, index) => (
                <View
                  key={index}
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    paddingVertical: 12,
                    borderBottomWidth: index < 4 ? 1 : 0,
                    borderBottomColor: "#F3F4F6",
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "500",
                        color: "#1D2B3D",
                      }}
                    >
                      {transaction.description || transaction.transaction_type}
                    </Text>
                    <Text
                      style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}
                    >
                      {new Date(transaction.created_at).toLocaleDateString()}
                    </Text>
                  </View>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "bold",
                      color: ["deposit", "dao_allocation"].includes(
                        transaction.transaction_type,
                      )
                        ? "#10B981"
                        : "#EF4444",
                    }}
                  >
                    {["deposit", "dao_allocation"].includes(
                      transaction.transaction_type,
                    )
                      ? "+"
                      : "-"}
                    ${Math.abs(transaction.amount).toLocaleString()}
                  </Text>
                </View>
              ))}
          </View>

          {/* Compliance Status */}
          <View
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              padding: 20,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <Shield size={20} color="#10B981" />
              <Text
                style={{
                  marginLeft: 8,
                  fontSize: 16,
                  fontWeight: "bold",
                  color: "#1D2B3D",
                }}
              >
                Compliance Status
              </Text>
            </View>

            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Text style={{ fontSize: 14, color: "#6B7280" }}>
                GDPR Compliance
              </Text>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <CheckCircle size={16} color="#10B981" />
                <Text
                  style={{
                    marginLeft: 4,
                    fontSize: 14,
                    color: "#10B981",
                    fontWeight: "500",
                  }}
                >
                  Active
                </Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Text style={{ fontSize: 14, color: "#6B7280" }}>
                Data Security
              </Text>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <CheckCircle size={16} color="#10B981" />
                <Text
                  style={{
                    marginLeft: 4,
                    fontSize: 14,
                    color: "#10B981",
                    fontWeight: "500",
                  }}
                >
                  Secure
                </Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Text style={{ fontSize: 14, color: "#6B7280" }}>
                Financial Compliance
              </Text>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <CheckCircle size={16} color="#10B981" />
                <Text
                  style={{
                    marginLeft: 4,
                    fontSize: 14,
                    color: "#10B981",
                    fontWeight: "500",
                  }}
                >
                  Verified
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
