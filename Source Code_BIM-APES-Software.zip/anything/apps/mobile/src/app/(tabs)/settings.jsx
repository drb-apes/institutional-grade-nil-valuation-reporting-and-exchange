import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Settings,
  Info,
  FileText,
  LogOut,
  ChevronRight,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import useUser from "../../utils/auth/useUser";
import { useAuth } from "../../utils/auth";

export default function SettingsPage() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: user, loading } = useUser();
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#0F172A" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 16,
            paddingHorizontal: 20,
            marginBottom: 24,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              marginBottom: 8,
            }}
          >
            <Settings size={32} color="#60A5FA" />
            <Text
              style={{ color: "#FFFFFF", fontSize: 28, fontWeight: "bold" }}
            >
              Settings
            </Text>
          </View>
          {user && (
            <Text style={{ color: "#94A3B8", fontSize: 15 }}>{user.email}</Text>
          )}
        </View>

        {/* Settings Sections */}
        <View style={{ paddingHorizontal: 20 }}>
          {/* Account Section */}
          {user && (
            <View style={{ marginBottom: 24 }}>
              <Text
                style={{
                  color: "#94A3B8",
                  fontSize: 13,
                  fontWeight: "600",
                  textTransform: "uppercase",
                  marginBottom: 12,
                  paddingHorizontal: 4,
                }}
              >
                Account
              </Text>

              <View
                style={{
                  backgroundColor: "rgba(30, 41, 59, 0.5)",
                  borderRadius: 12,
                  overflow: "hidden",
                  borderWidth: 1,
                  borderColor: "#334155",
                }}
              >
                <SettingsItem
                  icon={<LogOut size={22} color="#EF4444" />}
                  label="Sign Out"
                  onPress={handleSignOut}
                  showChevron={false}
                  textColor="#EF4444"
                />
              </View>
            </View>
          )}

          {/* Legal Section */}
          <View style={{ marginBottom: 24 }}>
            <Text
              style={{
                color: "#94A3B8",
                fontSize: 13,
                fontWeight: "600",
                textTransform: "uppercase",
                marginBottom: 12,
                paddingHorizontal: 4,
              }}
            >
              Legal & Licensing
            </Text>

            <View
              style={{
                backgroundColor: "rgba(30, 41, 59, 0.5)",
                borderRadius: 12,
                overflow: "hidden",
                borderWidth: 1,
                borderColor: "#334155",
              }}
            >
              <SettingsItem
                icon={<Info size={22} color="#60A5FA" />}
                label="About BIM‑APES"
                onPress={() => router.push("/about")}
              />
              <View
                style={{
                  height: 1,
                  backgroundColor: "#334155",
                  marginHorizontal: 16,
                }}
              />
              <SettingsItem
                icon={<FileText size={22} color="#60A5FA" />}
                label="Licenses & Attribution"
                subtitle="Apache 2.0 · CC BY-NC-ND 4.0"
                onPress={() => router.push("/about")}
              />
            </View>
          </View>

          {/* Version Info */}
          <View
            style={{
              marginTop: 32,
              paddingTop: 24,
              borderTopWidth: 1,
              borderTopColor: "#334155",
            }}
          >
            <Text
              style={{
                color: "#64748B",
                fontSize: 13,
                textAlign: "center",
                marginBottom: 4,
              }}
            >
              BIM‑APES Platform v2.0
            </Text>
            <Text
              style={{
                color: "#64748B",
                fontSize: 12,
                textAlign: "center",
                marginBottom: 8,
              }}
            >
              PhysiobioFIN Performance Network (RPN)
            </Text>
            <Text
              style={{
                color: "#475569",
                fontSize: 11,
                textAlign: "center",
                lineHeight: 16,
              }}
            >
              © {new Date().getFullYear()} Dashawn Ramel Bledsoe / NIBLS Inc.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function SettingsItem({
  icon,
  label,
  subtitle,
  onPress,
  showChevron = true,
  textColor = "#FFFFFF",
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 16,
      }}
      activeOpacity={0.7}
    >
      <View style={{ marginRight: 12 }}>{icon}</View>
      <View style={{ flex: 1 }}>
        <Text
          style={{
            color: textColor,
            fontSize: 16,
            fontWeight: "600",
            marginBottom: subtitle ? 2 : 0,
          }}
        >
          {label}
        </Text>
        {subtitle && (
          <Text style={{ color: "#94A3B8", fontSize: 13 }}>{subtitle}</Text>
        )}
      </View>
      {showChevron && <ChevronRight size={20} color="#64748B" />}
    </TouchableOpacity>
  );
}
