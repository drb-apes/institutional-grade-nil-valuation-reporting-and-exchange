import { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  TrendingUp,
  Activity,
  Target,
  Award,
  ChevronRight,
} from "lucide-react-native";

const SPORT_MODULES = [
  { label: "Wrestling", icon: "🤼", color: "#4DA6FF", path: "wrestling" },
  { label: "Tactical Sports", icon: "⚽", color: "#3CFF7A", path: "tactical" },
  { label: "Racket Sports", icon: "🎾", color: "#FFCC33", path: "racket" },
  { label: "Live Concert NIL", icon: "🎵", color: "#FF3C9A", path: "concert" },
];

function TierBadge({ tier }) {
  const colors = {
    elite: "#FFCC33",
    advanced: "#3CFF7A",
    competitive: "#4DA6FF",
    developing: "#FF8C33",
    beginner: "#999",
    platinum: "#E5E4E2",
    gold: "#FFCC33",
    silver: "#C0C0C0",
    bronze: "#CD7F32",
  };
  const c = colors[tier?.toLowerCase()] || "#999";
  return (
    <View
      style={{
        backgroundColor: `${c}22`,
        borderRadius: 8,
        paddingHorizontal: 7,
        paddingVertical: 2,
      }}
    >
      <Text
        style={{
          color: c,
          fontSize: 9,
          fontWeight: "800",
          textTransform: "uppercase",
          letterSpacing: 1,
        }}
      >
        {tier || "–"}
      </Text>
    </View>
  );
}

function StatBox({ label, value, color = "#B8860B" }) {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#F8F8F6",
        borderRadius: 12,
        padding: 12,
        marginHorizontal: 4,
      }}
    >
      <Text
        style={{
          color: "#888",
          fontSize: 9,
          textTransform: "uppercase",
          letterSpacing: 1,
          marginBottom: 4,
        }}
      >
        {label}
      </Text>
      <Text
        style={{
          color,
          fontSize: 20,
          fontWeight: "900",
          fontFamily: "monospace",
        }}
      >
        {value}
      </Text>
    </View>
  );
}

export default function AnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const load = async (isRefresh = false) => {
    if (!isRefresh) setLoading(true);
    setError(null);
    try {
      const [histRes, statRes] = await Promise.all([
        fetch("/api/simulations/history?limit=20"),
        fetch("/api/dashboard/stats"),
      ]);
      if (!histRes.ok) throw new Error("History API error");
      if (!statRes.ok) throw new Error("Stats API error");
      const histData = await histRes.json();
      const statData = await statRes.json();
      setHistory(histData.history || []);
      setStats(statData.stats || null);
    } catch (err) {
      console.error(err);
      setError("Could not load analytics data. Check your connection.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    load(true);
  };

  const timeAgo = (dateStr) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F5F5F0", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: "#1D2B3D",
          paddingHorizontal: 20,
          paddingVertical: 16,
        }}
      >
        <Text
          style={{
            color: "#FFCC33",
            fontSize: 11,
            fontWeight: "700",
            letterSpacing: 2,
            textTransform: "uppercase",
            marginBottom: 2,
          }}
        >
          BIM-APES
        </Text>
        <Text style={{ color: "#fff", fontSize: 22, fontWeight: "900" }}>
          Analytics
        </Text>
        <Text style={{ color: "#7A8FA6", fontSize: 12, marginTop: 2 }}>
          Live Performance Intelligence
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#B8860B"
          />
        }
      >
        {/* Stats Row */}
        {stats && (
          <View style={{ flexDirection: "row", margin: 16, marginBottom: 8 }}>
            <StatBox
              label="Athletes"
              value={stats.athleteCount?.toString() || "0"}
              color="#1D2B3D"
            />
            <StatBox
              label="Simulations"
              value={stats.simulationCount?.toString() || "0"}
              color="#B8860B"
            />
            <StatBox
              label="Milestones"
              value={stats.activeMilestones?.toString() || "0"}
              color="#3CFF7A"
            />
          </View>
        )}

        {/* Sport Modules */}
        <View style={{ marginHorizontal: 16, marginBottom: 16 }}>
          <Text
            style={{
              color: "#1D2B3D",
              fontSize: 14,
              fontWeight: "800",
              marginBottom: 10,
              textTransform: "uppercase",
              letterSpacing: 1,
            }}
          >
            Sport Modules
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {SPORT_MODULES.map((mod) => (
              <View
                key={mod.label}
                style={{
                  width: "47%",
                  backgroundColor: "#fff",
                  borderRadius: 14,
                  padding: 14,
                  borderWidth: 1,
                  borderColor: "#E8E8E0",
                }}
              >
                <Text style={{ fontSize: 24, marginBottom: 6 }}>
                  {mod.icon}
                </Text>
                <Text
                  style={{ color: "#1D2B3D", fontSize: 12, fontWeight: "700" }}
                >
                  {mod.label}
                </Text>
                <Text
                  style={{
                    color: mod.color,
                    fontSize: 10,
                    marginTop: 2,
                    fontWeight: "600",
                  }}
                >
                  BIM Tracker
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent BIM Analyses */}
        <View
          style={{
            marginHorizontal: 16,
            backgroundColor: "#fff",
            borderRadius: 16,
            overflow: "hidden",
            borderWidth: 1,
            borderColor: "#E8E8E0",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              padding: 16,
              borderBottomWidth: 1,
              borderColor: "#F0F0F0",
            }}
          >
            <Text style={{ color: "#1D2B3D", fontSize: 14, fontWeight: "800" }}>
              Recent BIM Analyses
            </Text>
            <Text style={{ color: "#888", fontSize: 11 }}>
              {loading ? "Loading…" : `${history.length} results`}
            </Text>
          </View>

          {loading ? (
            <View style={{ padding: 40, alignItems: "center" }}>
              <ActivityIndicator color="#B8860B" />
              <Text style={{ color: "#888", fontSize: 12, marginTop: 8 }}>
                Loading performance data…
              </Text>
            </View>
          ) : error ? (
            <View style={{ padding: 24, alignItems: "center" }}>
              <Activity color="#FF3C3C" size={32} />
              <Text
                style={{
                  color: "#FF3C3C",
                  fontSize: 13,
                  marginTop: 8,
                  textAlign: "center",
                }}
              >
                {error}
              </Text>
            </View>
          ) : history.length === 0 ? (
            <View style={{ padding: 40, alignItems: "center" }}>
              <Activity color="#ccc" size={36} />
              <Text
                style={{
                  color: "#888",
                  fontSize: 14,
                  marginTop: 12,
                  fontWeight: "600",
                }}
              >
                No Analyses Yet
              </Text>
              <Text
                style={{
                  color: "#aaa",
                  fontSize: 12,
                  marginTop: 4,
                  textAlign: "center",
                }}
              >
                Run a sport performance analysis to see your results here
              </Text>
            </View>
          ) : (
            history.map((item, i) => (
              <View
                key={item.id || i}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  borderBottomWidth: i < history.length - 1 ? 1 : 0,
                  borderColor: "#F5F5F0",
                }}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    backgroundColor: "#1D2B3D0D",
                    borderRadius: 10,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Activity color="#1D2B3D" size={16} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      color: "#1D2B3D",
                      fontSize: 13,
                      fontWeight: "700",
                      textTransform: "capitalize",
                    }}
                  >
                    {item.sessionType || item.sport || "Performance"} Analysis
                  </Text>
                  <Text style={{ color: "#888", fontSize: 11, marginTop: 1 }}>
                    Athlete #{item.athleteId} · {timeAgo(item.createdAt)}
                  </Text>
                </View>
                <View style={{ alignItems: "flex-end", gap: 4 }}>
                  <Text
                    style={{
                      color: "#B8860B",
                      fontFamily: "monospace",
                      fontSize: 14,
                      fontWeight: "900",
                    }}
                  >
                    {item.bimScore > 0
                      ? item.bimScore.toFixed(1)
                      : (item.assetValue / 1000).toFixed(1)}
                  </Text>
                  <TierBadge tier={item.tier} />
                </View>
              </View>
            ))
          )}
        </View>

        {/* Performance Insights Banner */}
        <View
          style={{
            margin: 16,
            backgroundColor: "#1D2B3D",
            borderRadius: 16,
            padding: 20,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
              marginBottom: 8,
            }}
          >
            <TrendingUp color="#FFCC33" size={18} />
            <Text
              style={{
                color: "#FFCC33",
                fontSize: 12,
                fontWeight: "800",
                textTransform: "uppercase",
                letterSpacing: 1,
              }}
            >
              BIM Insight
            </Text>
          </View>
          <Text
            style={{
              color: "#fff",
              fontSize: 15,
              fontWeight: "700",
              marginBottom: 4,
            }}
          >
            Performance Analytics Engine
          </Text>
          <Text style={{ color: "#7A8FA6", fontSize: 12, lineHeight: 18 }}>
            Every analysis feeds real-time NIL valuation data to the BIM-APES
            platform. Higher BIM scores correlate directly with sponsor
            activation windows and NIL market value.
          </Text>
          {stats?.simulationCount > 0 && (
            <Text
              style={{
                color: "#FFCC33",
                fontSize: 11,
                marginTop: 10,
                fontWeight: "700",
              }}
            >
              {stats.simulationCount} total analyses run on platform
            </Text>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
