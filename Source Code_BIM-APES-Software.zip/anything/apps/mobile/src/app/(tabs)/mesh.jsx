import React from "react";
import { View } from "react-native";
import { StatusBar } from "expo-status-bar";
import MeshNetworkInterface from "@/components/MeshNetwork/MeshNetworkInterface";

export default function MeshTab() {
  return (
    <View style={{ flex: 1 }}>
      <StatusBar style="light" />
      <MeshNetworkInterface />
    </View>
  );
}
