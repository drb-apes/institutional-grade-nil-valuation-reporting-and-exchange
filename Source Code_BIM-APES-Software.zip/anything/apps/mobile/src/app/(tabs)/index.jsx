import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Activity, Zap, Music, Radio, TrendingUp } from "lucide-react-native";
import { useRouter } from "expo-router";
import useUser from "@/utils/auth/useUser";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: user, loading } = useUser();

  const sportModules = [
    {
      name: "Wrestling",
      icon: Activity,
      color: "#3b82f6",
      route: "/sport/wrestling",
      description: "Takedown efficiency, control time, explosive power",
    },
    {
      name: "Tactical Sports",
      icon: TrendingUp,
      color: "#10b981",
      route: "/sport/tactical",
      description: "Rugby, Soccer, Basketball efficiency",
    },
    {
      name: "Racket Sports",
      icon: Zap,
      color: "#a855f7",
      route: "/sport/racket",
      description: "Tennis, Pickleball spike analysis",
    },
    {
      name: "Concert NIL",
      icon: Music,
      color: "#ec4899",
      route: "/sport/concert",
      description: "Live music performance valuation",
    },
  ];

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0f172a",
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
        }}
      >
        <StatusBar style="light" />
        <Text style={{ color: "#fff", fontSize: 18 }}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#0f172a" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={{ paddingHorizontal: 20, marginBottom: 32 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              marginBottom: 8,
            }}
          >
            <Radio color="#3b82f6" size={40} />
            <Text style={{ fontSize: 32, fontWeight: "bold", color: "#fff" }}>
              BIM-APES
            </Text>
          </View>
          <Text style={{ fontSize: 16, color: "#94a3b8", marginBottom: 12 }}>
            Biometric Intelligence Mobile Platform
          </Text>

          {user && (
            <View
              style={{
                backgroundColor: "#1e293b",
                padding: 16,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: "#334155",
              }}
            >
              <Text style={{ color: "#3b82f6", fontSize: 14, marginBottom: 4 }}>
                Signed in as
              </Text>
              <Text style={{ color: "#fff", fontSize: 16, fontWeight: "600" }}>
                {user.email}
              </Text>
            </View>
          )}
        </View>

        {/* Quick Actions */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "bold",
              color: "#fff",
              marginBottom: 16,
            }}
          >
            Quick Actions
          </Text>

          <TouchableOpacity
            onPress={() => router.push("/mesh-sync")}
            style={{
              backgroundColor: "#1e40af",
              padding: 20,
              borderRadius: 16,
              marginBottom: 12,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                marginBottom: 8,
              }}
            >
              <Radio color="#fff" size={28} />
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "bold",
                  color: "#fff",
                  flex: 1,
                }}
              >
                Start Mesh Session
              </Text>
            </View>
            <Text style={{ color: "#93c5fd", fontSize: 14 }}>
              Create a new wearable mesh network for team training
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/motion-capture")}
            style={{
              backgroundColor: "#7c3aed",
              padding: 20,
              borderRadius: 16,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                marginBottom: 8,
              }}
            >
              <Activity color="#fff" size={28} />
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "bold",
                  color: "#fff",
                  flex: 1,
                }}
              >
                Motion Capture
              </Text>
            </View>
            <Text style={{ color: "#c4b5fd", fontSize: 14 }}>
              Record and analyze performance data
            </Text>
          </TouchableOpacity>
        </View>

        {/* Sport Modules */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "bold",
              color: "#fff",
              marginBottom: 16,
            }}
          >
            Sport Modules
          </Text>

          <View style={{ gap: 12 }}>
            {sportModules.map((module, idx) => {
              const Icon = module.icon;
              return (
                <TouchableOpacity
                  key={idx}
                  onPress={() => router.push(module.route)}
                  style={{
                    backgroundColor: "#1e293b",
                    padding: 18,
                    borderRadius: 12,
                    borderWidth: 1,
                    borderColor: "#334155",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 12,
                      marginBottom: 8,
                    }}
                  >
                    <Icon color={module.color} size={24} />
                    <Text
                      style={{
                        fontSize: 18,
                        fontWeight: "600",
                        color: "#fff",
                        flex: 1,
                      }}
                    >
                      {module.name}
                    </Text>
                  </View>
                  <Text style={{ color: "#94a3b8", fontSize: 13 }}>
                    {module.description}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Licensing Footer */}
        <View
          style={{
            paddingHorizontal: 20,
            paddingTop: 32,
            borderTopWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text
            style={{
              color: "#64748b",
              fontSize: 11,
              marginBottom: 8,
              fontWeight: "600",
            }}
          >
            © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            BIM-APES Software and all related technologies are developed and
            published by Bledsoe Investment Management, a division of NIBLS Inc.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            Software License: Portions licensed under Apache License, Version
            2.0.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            Content License: CC BY-NC-ND 4.0 International License.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 10 }}>
            Use of trademarks, branding, and proprietary valuation models
            requires written permission from NIBLS Inc.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
