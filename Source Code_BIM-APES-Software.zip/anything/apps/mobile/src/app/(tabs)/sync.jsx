import MotionCapture from "../motion-capture";

export default function SyncPage() {
  return <MotionCapture />;
}
