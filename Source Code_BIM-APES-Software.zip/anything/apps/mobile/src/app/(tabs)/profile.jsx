import { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  User,
  LogOut,
  TrendingUp,
  Activity,
  Target,
  Award,
  Shield,
  DollarSign,
} from "lucide-react-native";
import useUser from "@/utils/auth/useUser";
import { useAuth } from "@/utils/auth";

function ProfileStat({ label, value, icon: Icon, color = "#B8860B" }) {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#F8F8F6",
        borderRadius: 12,
        padding: 14,
        alignItems: "center",
      }}
    >
      <Icon color={color} size={20} style={{ marginBottom: 6 }} />
      <Text
        style={{
          color,
          fontSize: 18,
          fontWeight: "900",
          fontFamily: "monospace",
        }}
      >
        {value}
      </Text>
      <Text
        style={{
          color: "#888",
          fontSize: 10,
          textTransform: "uppercase",
          letterSpacing: 1,
          marginTop: 2,
          textAlign: "center",
        }}
      >
        {label}
      </Text>
    </View>
  );
}

function InfoRow({ label, value }) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderColor: "#F0F0F0",
      }}
    >
      <Text style={{ color: "#666", fontSize: 13 }}>{label}</Text>
      <Text style={{ color: "#1D2B3D", fontSize: 13, fontWeight: "600" }}>
        {value || "—"}
      </Text>
    </View>
  );
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { data: user, loading: userLoading } = useUser();
  const { signOut } = useAuth();
  const [userStats, setUserStats] = useState(null);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const res = await fetch("/api/dashboard/stats");
        if (!res.ok) throw new Error("Stats error");
        const data = await res.json();
        setUserStats(data.stats);
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingStats(false);
      }
    };
    loadStats();
  }, []);

  const handleSignOut = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out of BIM-APES?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: () => signOut(),
      },
    ]);
  };

  if (userLoading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#F5F5F0",
          alignItems: "center",
          justifyContent: "center",
          paddingTop: insets.top,
        }}
      >
        <ActivityIndicator color="#B8860B" size="large" />
        <Text style={{ color: "#888", marginTop: 12, fontSize: 13 }}>
          Loading profile…
        </Text>
      </View>
    );
  }

  if (!user) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#1D2B3D",
          alignItems: "center",
          justifyContent: "center",
          paddingTop: insets.top,
          paddingHorizontal: 24,
        }}
      >
        <User color="#FFCC33" size={64} style={{ marginBottom: 20 }} />
        <Text
          style={{
            color: "#fff",
            fontSize: 22,
            fontWeight: "900",
            marginBottom: 8,
          }}
        >
          Sign In Required
        </Text>
        <Text
          style={{
            color: "#7A8FA6",
            fontSize: 14,
            textAlign: "center",
            lineHeight: 20,
            marginBottom: 32,
          }}
        >
          Sign in to access your BIM-APES profile, performance history, and NIL
          valuation data.
        </Text>
        <TouchableOpacity
          onPress={() => {}}
          style={{
            backgroundColor: "#FFCC33",
            paddingHorizontal: 32,
            paddingVertical: 14,
            borderRadius: 14,
          }}
        >
          <Text style={{ color: "#1D2B3D", fontSize: 15, fontWeight: "900" }}>
            Sign In to BIM-APES
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  const initials = (user.name || user.email || "U")
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F5F5F0", paddingTop: insets.top }}
    >
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Header */}
        <View
          style={{
            backgroundColor: "#1D2B3D",
            paddingHorizontal: 24,
            paddingTop: 24,
            paddingBottom: 36,
          }}
        >
          <Text
            style={{
              color: "#FFCC33",
              fontSize: 10,
              fontWeight: "800",
              letterSpacing: 2,
              textTransform: "uppercase",
              marginBottom: 20,
            }}
          >
            BIM-APES · PROFILE
          </Text>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 16 }}>
            {/* Avatar */}
            <View
              style={{
                width: 64,
                height: 64,
                borderRadius: 32,
                backgroundColor: "#FFCC33",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{ color: "#1D2B3D", fontSize: 22, fontWeight: "900" }}
              >
                {initials}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#fff", fontSize: 20, fontWeight: "900" }}>
                {user.name || "Athlete"}
              </Text>
              <Text style={{ color: "#7A8FA6", fontSize: 13, marginTop: 2 }}>
                {user.email}
              </Text>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6,
                  marginTop: 6,
                }}
              >
                <View
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: 3,
                    backgroundColor: "#3CFF7A",
                  }}
                />
                <Text
                  style={{ color: "#3CFF7A", fontSize: 11, fontWeight: "700" }}
                >
                  Active · BIM-APES Platform
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Platform Stats */}
        <View
          style={{
            marginTop: -20,
            marginHorizontal: 16,
            backgroundColor: "#fff",
            borderRadius: 16,
            padding: 16,
            borderWidth: 1,
            borderColor: "#E8E8E0",
            elevation: 3,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.08,
            shadowRadius: 8,
          }}
        >
          <Text
            style={{
              color: "#888",
              fontSize: 10,
              textTransform: "uppercase",
              letterSpacing: 1,
              marginBottom: 12,
              fontWeight: "700",
            }}
          >
            Platform Statistics
          </Text>
          {loadingStats ? (
            <ActivityIndicator color="#B8860B" />
          ) : (
            <View style={{ flexDirection: "row", gap: 8 }}>
              <ProfileStat
                label="Analyses"
                value={userStats?.simulationCount?.toString() || "0"}
                icon={Activity}
                color="#4DA6FF"
              />
              <ProfileStat
                label="Milestones"
                value={userStats?.activeMilestones?.toString() || "0"}
                icon={Target}
                color="#3CFF7A"
              />
              <ProfileStat
                label="Referrals"
                value={userStats?.referralCount?.toString() || "0"}
                icon={Award}
                color="#B8860B"
              />
            </View>
          )}
        </View>

        {/* Account Info */}
        <View
          style={{
            marginHorizontal: 16,
            marginTop: 16,
            backgroundColor: "#fff",
            borderRadius: 16,
            padding: 16,
            borderWidth: 1,
            borderColor: "#E8E8E0",
          }}
        >
          <Text
            style={{
              color: "#888",
              fontSize: 10,
              textTransform: "uppercase",
              letterSpacing: 1,
              marginBottom: 4,
              fontWeight: "700",
            }}
          >
            Account Details
          </Text>
          <InfoRow label="Display Name" value={user.name || "Not set"} />
          <InfoRow label="Email Address" value={user.email} />
          <InfoRow label="User ID" value={`#${user.id}`} />
          <InfoRow label="Platform" value="BIM-APES NIL Intelligence" />
        </View>

        {/* Platform Modules */}
        <View
          style={{
            marginHorizontal: 16,
            marginTop: 16,
            backgroundColor: "#fff",
            borderRadius: 16,
            overflow: "hidden",
            borderWidth: 1,
            borderColor: "#E8E8E0",
          }}
        >
          <View
            style={{
              padding: 16,
              paddingBottom: 8,
              borderBottomWidth: 1,
              borderColor: "#F0F0F0",
            }}
          >
            <Text
              style={{
                color: "#888",
                fontSize: 10,
                textTransform: "uppercase",
                letterSpacing: 1,
                fontWeight: "700",
              }}
            >
              Access Modules
            </Text>
          </View>
          {[
            {
              label: "NIL Valuation Engine",
              sub: "Real-time athlete NIL scoring",
              icon: DollarSign,
              color: "#FFCC33",
            },
            {
              label: "Performance Analytics",
              sub: "BIM score history & trends",
              icon: TrendingUp,
              color: "#4DA6FF",
            },
            {
              label: "Compliance & Governance",
              sub: "NIL compliance attestations",
              icon: Shield,
              color: "#3CFF7A",
            },
          ].map((item, i) => (
            <View
              key={item.label}
              style={{
                flexDirection: "row",
                alignItems: "center",
                padding: 16,
                borderBottomWidth: i < 2 ? 1 : 0,
                borderColor: "#F0F0F0",
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  backgroundColor: `${item.color}18`,
                  borderRadius: 10,
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 12,
                }}
              >
                <item.icon color={item.color} size={18} />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{ color: "#1D2B3D", fontSize: 13, fontWeight: "700" }}
                >
                  {item.label}
                </Text>
                <Text style={{ color: "#888", fontSize: 11, marginTop: 1 }}>
                  {item.sub}
                </Text>
              </View>
              <View
                style={{
                  backgroundColor: "#F0FFF4",
                  borderRadius: 8,
                  paddingHorizontal: 8,
                  paddingVertical: 3,
                }}
              >
                <Text
                  style={{ color: "#3CFF7A", fontSize: 10, fontWeight: "700" }}
                >
                  ACTIVE
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* License Footer */}
        <View
          style={{
            marginHorizontal: 16,
            marginTop: 16,
            backgroundColor: "#1D2B3D",
            borderRadius: 16,
            padding: 16,
          }}
        >
          <Text
            style={{
              color: "#FFCC33",
              fontSize: 10,
              fontWeight: "800",
              letterSpacing: 1,
              textTransform: "uppercase",
              marginBottom: 6,
            }}
          >
            Licensing
          </Text>
          <Text style={{ color: "#7A8FA6", fontSize: 11, lineHeight: 17 }}>
            © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.{"\n"}
            BIM-APES Software licensed under Apache License 2.0.{"\n"}
            All NIL valuation content © NIBLS Inc.
          </Text>
        </View>

        {/* Sign Out */}
        <TouchableOpacity
          onPress={handleSignOut}
          style={{
            marginHorizontal: 16,
            marginTop: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            padding: 16,
            backgroundColor: "#FFF0F0",
            borderRadius: 14,
            borderWidth: 1,
            borderColor: "#FFD0D0",
          }}
        >
          <LogOut color="#FF3C3C" size={18} />
          <Text style={{ color: "#FF3C3C", fontSize: 14, fontWeight: "700" }}>
            Sign Out
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
