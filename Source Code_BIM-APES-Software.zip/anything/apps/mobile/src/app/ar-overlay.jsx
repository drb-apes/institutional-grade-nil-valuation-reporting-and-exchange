import { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Animated,
  Dimensions,
} from "react-native";
import { Eye, Camera, Activity, Zap, AlertCircle } from "lucide-react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Canvas,
  Circle,
  Group,
  Path,
  Skia,
  useValue,
  useComputedValue,
  runTiming,
} from "@shopify/react-native-skia";
import useUser from "@/utils/auth/useUser";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

/**
 * AR BiomechFlow Overlay (Mobile)
 *
 * Real-time AR overlay renderer for athlete biometric capsules
 * Displays BiomechFlow capsules over camera view or 3D skeleton
 */

export default function AROverlay() {
  const insets = useSafeAreaInsets();
  const { data: user, loading } = useUser();
  const [viewMode, setViewMode] = useState("ar"); // 'ar' | 'skeleton' | 'split'
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [capsuleOpacity] = useState(new Animated.Value(1));

  // Mock athlete data
  const athletes = [
    {
      id: 1,
      name: "Jordan Smith",
      sport: "Wrestling",
      bimScore: 87.3,
      position: { x: 0.3, y: 0.4 },
      fatigue: 35,
      stress: 55,
      nilMomentum: 85,
      injuryRisk: 40,
      recovery: 20,
    },
    {
      id: 2,
      name: "Maya Johnson",
      sport: "Basketball",
      bimScore: 92.1,
      position: { x: 0.6, y: 0.5 },
      fatigue: 60,
      stress: 75,
      nilMomentum: 90,
      injuryRisk: 55,
      recovery: 15,
    },
  ];

  useEffect(() => {
    // Pulse animation for capsules
    Animated.loop(
      Animated.sequence([
        Animated.timing(capsuleOpacity, {
          toValue: 0.7,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(capsuleOpacity, {
          toValue: 1.0,
          duration: 800,
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, []);

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.centerContainer}>
          <Activity color="#4DA6FF" size={48} />
          <Text style={styles.loadingText}>Loading AR Viewer...</Text>
        </View>
      </View>
    );
  }

  if (!user) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.centerContainer}>
          <Eye color="#4DA6FF" size={48} />
          <Text style={styles.loadingText}>
            Please sign in to access AR Viewer
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Eye color="#4DA6FF" size={28} />
          <View style={{ marginLeft: 12 }}>
            <Text style={styles.headerTitle}>AR BiomechFlow</Text>
            <Text style={styles.headerSubtitle}>Real-Time Overlay</Text>
          </View>
        </View>
      </View>

      {/* AR View Area */}
      <View style={styles.arViewContainer}>
        {/* Camera placeholder (in production, this would be Expo Camera) */}
        <View style={styles.cameraPlaceholder}>
          <Camera color="#ffffff40" size={64} />
          <Text style={styles.placeholderText}>AR Camera View</Text>
          <Text style={styles.placeholderSubtext}>
            (In production: live camera feed with real-time overlays)
          </Text>
        </View>

        {/* BiomechFlow Capsule Overlays */}
        {athletes.map((athlete) => (
          <Animated.View
            key={athlete.id}
            style={[
              styles.capsuleOverlay,
              {
                left: SCREEN_WIDTH * athlete.position.x,
                top: SCREEN_HEIGHT * athlete.position.y,
                opacity: capsuleOpacity,
              },
            ]}
          >
            <TouchableOpacity
              onPress={() => setSelectedAthlete(athlete)}
              style={styles.capsuleTouchArea}
            >
              {/* Skia BiomechFlow Capsule */}
              <Canvas style={{ width: 120, height: 120 }}>
                <BiomechFlowCapsuleSVG
                  fatigue={athlete.fatigue}
                  stress={athlete.stress}
                  nilMomentum={athlete.nilMomentum}
                  injuryRisk={athlete.injuryRisk}
                />
              </Canvas>

              {/* Athlete Label */}
              <View style={styles.athleteLabel}>
                <Text style={styles.athleteName}>{athlete.name}</Text>
                <Text style={styles.athleteBIM}>BIM: {athlete.bimScore}</Text>
              </View>
            </TouchableOpacity>
          </Animated.View>
        ))}

        {/* Crosshair */}
        <View style={styles.crosshair}>
          <View style={styles.crosshairH} />
          <View style={styles.crosshairV} />
        </View>
      </View>

      {/* Bottom Control Bar */}
      <View style={[styles.controlBar, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          style={
            viewMode === "ar"
              ? styles.controlButtonActive
              : styles.controlButton
          }
          onPress={() => setViewMode("ar")}
        >
          <Camera color={viewMode === "ar" ? "#fff" : "#4DA6FF"} size={20} />
          <Text
            style={
              viewMode === "ar" ? styles.controlTextActive : styles.controlText
            }
          >
            AR View
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={
            viewMode === "skeleton"
              ? styles.controlButtonActive
              : styles.controlButton
          }
          onPress={() => setViewMode("skeleton")}
        >
          <Activity
            color={viewMode === "skeleton" ? "#fff" : "#4DA6FF"}
            size={20}
          />
          <Text
            style={
              viewMode === "skeleton"
                ? styles.controlTextActive
                : styles.controlText
            }
          >
            Skeleton
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={
            viewMode === "split"
              ? styles.controlButtonActive
              : styles.controlButton
          }
          onPress={() => setViewMode("split")}
        >
          <Zap color={viewMode === "split" ? "#fff" : "#4DA6FF"} size={20} />
          <Text
            style={
              viewMode === "split"
                ? styles.controlTextActive
                : styles.controlText
            }
          >
            Split View
          </Text>
        </TouchableOpacity>
      </View>

      {/* Selected Athlete Detail Panel */}
      {selectedAthlete && (
        <View style={styles.detailPanel}>
          <TouchableOpacity
            style={styles.closeDetailButton}
            onPress={() => setSelectedAthlete(null)}
          >
            <Text style={styles.closeDetailText}>✕</Text>
          </TouchableOpacity>

          <Text style={styles.detailTitle}>{selectedAthlete.name}</Text>
          <Text style={styles.detailSubtitle}>
            {selectedAthlete.sport} • BIM {selectedAthlete.bimScore}
          </Text>

          <View style={styles.metricGrid}>
            <MetricCard
              label="Fatigue"
              value={`${selectedAthlete.fatigue}%`}
              color="#FFD93C"
            />
            <MetricCard
              label="Stress"
              value={`${selectedAthlete.stress}%`}
              color="#1E5FA8"
            />
            <MetricCard
              label="NIL Momentum"
              value={`${selectedAthlete.nilMomentum}%`}
              color="#FFCC33"
            />
            <MetricCard
              label="Injury Risk"
              value={`${selectedAthlete.injuryRisk}%`}
              color="#FF8C33"
            />
          </View>

          <View style={styles.insightBox}>
            <AlertCircle color="#FFCC33" size={16} />
            <Text style={styles.insightText}>
              Right shoulder showing elevated stress (75%). Monitor closely
              during next session.
            </Text>
          </View>
        </View>
      )}
    </View>
  );
}

// Skia-based BiomechFlow Capsule (simplified for mobile performance)
function BiomechFlowCapsuleSVG({ fatigue, stress, nilMomentum, injuryRisk }) {
  const centerX = 60;
  const centerY = 60;
  const radius = 45;

  // Determine colors
  const fatigueColor =
    fatigue > 70 ? "#FF3C3C" : fatigue > 40 ? "#FFD93C" : "#3CFF7A";
  const stressColor =
    stress > 70 ? "#002B66" : stress > 40 ? "#1E5FA8" : "#4DA6FF";
  const nilColor =
    nilMomentum > 70 ? "#FFCC33" : nilMomentum > 30 ? "#F2F2F2" : "#6B6B6B";
  const riskColor =
    injuryRisk > 70 ? "#D90000" : injuryRisk > 40 ? "#FF8C33" : "#33FFF3";

  // Create arc paths
  const topArc = Skia.Path.Make();
  topArc.addArc(
    {
      x: centerX - radius,
      y: centerY - radius,
      width: radius * 2,
      height: radius * 2,
    },
    180,
    180,
  );

  const bottomArc = Skia.Path.Make();
  bottomArc.addArc(
    {
      x: centerX - radius,
      y: centerY - radius,
      width: radius * 2,
      height: radius * 2,
    },
    0,
    180,
  );

  return (
    <Group>
      {/* Glow Ring */}
      <Circle
        cx={centerX}
        cy={centerY}
        r={radius + 5}
        color={nilColor + "40"}
        style="stroke"
        strokeWidth={4}
      />
      <Circle
        cx={centerX}
        cy={centerY}
        r={radius}
        color={nilColor}
        style="stroke"
        strokeWidth={2}
      />

      {/* Top Arc (Stress) */}
      <Path
        path={topArc}
        color={stressColor}
        style="stroke"
        strokeWidth={stress > 70 ? 8 : stress > 40 ? 5 : 3}
      />

      {/* Bottom Arc (Fatigue) */}
      <Path
        path={bottomArc}
        color={fatigueColor}
        style="stroke"
        strokeWidth={6}
      />

      {/* Right Bar (Injury Risk) */}
      <Group
        transform={[
          { translateX: centerX + radius + 10 },
          { translateY: centerY - (injuryRisk / 100) * 30 },
        ]}
      >
        <Path
          path={Skia.Path.Make().addRect({
            x: 0,
            y: 0,
            width: 6,
            height: (injuryRisk / 100) * 60,
          })}
          color={riskColor}
        />
      </Group>
    </Group>
  );
}

function MetricCard({ label, value, color }) {
  return (
    <View style={styles.metricCard}>
      <View style={[styles.metricIndicator, { backgroundColor: color }]} />
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={styles.metricValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0a0a0a",
  },
  centerContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    color: "#ffffff",
    fontSize: 18,
    marginTop: 16,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: "#ffffff10",
    borderBottomWidth: 1,
    borderBottomColor: "#ffffff20",
  },
  headerContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#ffffff",
  },
  headerSubtitle: {
    fontSize: 14,
    color: "#4DA6FF",
    marginTop: 2,
  },
  arViewContainer: {
    flex: 1,
    position: "relative",
  },
  cameraPlaceholder: {
    flex: 1,
    backgroundColor: "#1a1a1a",
    justifyContent: "center",
    alignItems: "center",
  },
  placeholderText: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 16,
  },
  placeholderSubtext: {
    color: "#ffffff60",
    fontSize: 12,
    marginTop: 8,
    textAlign: "center",
    paddingHorizontal: 40,
  },
  capsuleOverlay: {
    position: "absolute",
    width: 120,
    height: 120,
  },
  capsuleTouchArea: {
    width: 120,
    height: 120,
    alignItems: "center",
  },
  athleteLabel: {
    backgroundColor: "#00000080",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginTop: 4,
  },
  athleteName: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "bold",
    textAlign: "center",
  },
  athleteBIM: {
    color: "#4DA6FF",
    fontSize: 10,
    textAlign: "center",
  },
  crosshair: {
    position: "absolute",
    top: "50%",
    left: "50%",
    width: 40,
    height: 40,
    marginLeft: -20,
    marginTop: -20,
  },
  crosshairH: {
    position: "absolute",
    top: 19,
    left: 0,
    width: 40,
    height: 2,
    backgroundColor: "#4DA6FF40",
  },
  crosshairV: {
    position: "absolute",
    top: 0,
    left: 19,
    width: 2,
    height: 40,
    backgroundColor: "#4DA6FF40",
  },
  controlBar: {
    flexDirection: "row",
    backgroundColor: "#ffffff10",
    paddingHorizontal: 20,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: "#ffffff20",
    justifyContent: "space-around",
  },
  controlButton: {
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  controlButtonActive: {
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    backgroundColor: "#4DA6FF",
  },
  controlText: {
    color: "#4DA6FF",
    fontSize: 11,
    marginTop: 4,
    fontWeight: "600",
  },
  controlTextActive: {
    color: "#ffffff",
    fontSize: 11,
    marginTop: 4,
    fontWeight: "600",
  },
  detailPanel: {
    position: "absolute",
    bottom: 100,
    left: 20,
    right: 20,
    backgroundColor: "#ffffff15",
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: "#ffffff30",
  },
  closeDetailButton: {
    position: "absolute",
    top: 12,
    right: 12,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#ffffff20",
    justifyContent: "center",
    alignItems: "center",
  },
  closeDetailText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "bold",
  },
  detailTitle: {
    color: "#ffffff",
    fontSize: 20,
    fontWeight: "bold",
  },
  detailSubtitle: {
    color: "#4DA6FF",
    fontSize: 14,
    marginTop: 2,
    marginBottom: 16,
  },
  metricGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 16,
  },
  metricCard: {
    backgroundColor: "#ffffff10",
    borderRadius: 8,
    padding: 12,
    width: "48%",
    borderWidth: 1,
    borderColor: "#ffffff20",
  },
  metricIndicator: {
    width: 16,
    height: 3,
    borderRadius: 2,
    marginBottom: 6,
  },
  metricLabel: {
    color: "#ffffff80",
    fontSize: 11,
    marginBottom: 2,
  },
  metricValue: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "bold",
  },
  insightBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    backgroundColor: "#FFCC3320",
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: "#FFCC3340",
    gap: 8,
  },
  insightText: {
    flex: 1,
    color: "#FFD93C",
    fontSize: 12,
    lineHeight: 18,
  },
});
