import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Linking,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Info,
  ExternalLink,
  Scale,
  FileText,
  ChevronLeft,
} from "lucide-react-native";
import { useRouter } from "expo-router";

export default function AboutPage() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const openLink = (url) => {
    Linking.openURL(url).catch((err) =>
      console.error("Failed to open URL:", err),
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#0F172A" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 16,
            paddingHorizontal: 20,
            marginBottom: 24,
          }}
        >
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
              marginBottom: 20,
            }}
          >
            <ChevronLeft size={24} color="#60A5FA" />
            <Text style={{ color: "#60A5FA", fontSize: 16 }}>Back</Text>
          </TouchableOpacity>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              marginBottom: 8,
            }}
          >
            <Info size={32} color="#60A5FA" />
            <Text
              style={{ color: "#FFFFFF", fontSize: 28, fontWeight: "bold" }}
            >
              About BIM‑APES
            </Text>
          </View>
          <Text style={{ color: "#94A3B8", fontSize: 15 }}>
            Licensing & Legal Information
          </Text>
        </View>

        {/* Main Content */}
        <View style={{ paddingHorizontal: 20 }}>
          {/* Copyright */}
          <View
            style={{
              backgroundColor: "rgba(30, 41, 59, 0.5)",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text
              style={{
                color: "#FFFFFF",
                fontSize: 18,
                fontWeight: "700",
                textAlign: "center",
                marginBottom: 12,
              }}
            >
              © {new Date().getFullYear()} Dashawn Ramel Bledsoe / NIBLS Inc.
            </Text>
            <Text
              style={{
                color: "#FFFFFF",
                fontSize: 16,
                fontWeight: "600",
                textAlign: "center",
                marginBottom: 16,
              }}
            >
              All Rights Reserved.
            </Text>
            <Text
              style={{
                color: "#CBD5E1",
                fontSize: 14,
                textAlign: "center",
                lineHeight: 22,
              }}
            >
              BIM‑APES Software and all related technologies are developed and
              published by{" "}
              <Text style={{ fontWeight: "700", color: "#60A5FA" }}>
                Bledsoe Investment Management
              </Text>
              , a division of{" "}
              <Text style={{ fontWeight: "700", color: "#60A5FA" }}>
                NIBLS Inc.
              </Text>
            </Text>
          </View>

          {/* Software License */}
          <View
            style={{
              backgroundColor: "rgba(30, 41, 59, 0.5)",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 12,
                marginBottom: 12,
              }}
            >
              <FileText size={24} color="#4ADE80" style={{ marginTop: 2 }} />
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    color: "#FFFFFF",
                    fontSize: 17,
                    fontWeight: "700",
                    marginBottom: 8,
                  }}
                >
                  Software License
                </Text>
                <Text
                  style={{
                    color: "#CBD5E1",
                    fontSize: 14,
                    lineHeight: 22,
                    marginBottom: 12,
                  }}
                >
                  Portions of this application are licensed under the Apache
                  License, Version 2.0.
                </Text>
                <TouchableOpacity
                  onPress={() =>
                    openLink("https://www.apache.org/licenses/LICENSE-2.0")
                  }
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 6,
                    backgroundColor: "#166534",
                    paddingHorizontal: 16,
                    paddingVertical: 10,
                    borderRadius: 8,
                  }}
                >
                  <Text
                    style={{
                      color: "#FFFFFF",
                      fontSize: 14,
                      fontWeight: "600",
                    }}
                  >
                    View Apache License 2.0
                  </Text>
                  <ExternalLink size={14} color="#FFFFFF" />
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Content License */}
          <View
            style={{
              backgroundColor: "rgba(30, 41, 59, 0.5)",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 12,
                marginBottom: 12,
              }}
            >
              <Scale size={24} color="#60A5FA" style={{ marginTop: 2 }} />
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    color: "#FFFFFF",
                    fontSize: 17,
                    fontWeight: "700",
                    marginBottom: 8,
                  }}
                >
                  Content License
                </Text>
                <Text
                  style={{
                    color: "#CBD5E1",
                    fontSize: 14,
                    lineHeight: 22,
                    marginBottom: 12,
                  }}
                >
                  All non‑software content—including reports, visualizations,
                  branding, and documentation—is licensed under the Creative
                  Commons Attribution–NonCommercial–NoDerivatives 4.0
                  International License (CC BY-NC-ND 4.0).
                </Text>
                <TouchableOpacity
                  onPress={() =>
                    openLink(
                      "https://creativecommons.org/licenses/by-nc-nd/4.0/",
                    )
                  }
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 6,
                    backgroundColor: "#1E40AF",
                    paddingHorizontal: 16,
                    paddingVertical: 10,
                    borderRadius: 8,
                  }}
                >
                  <Text
                    style={{
                      color: "#FFFFFF",
                      fontSize: 14,
                      fontWeight: "600",
                    }}
                  >
                    View CC BY-NC-ND 4.0 License
                  </Text>
                  <ExternalLink size={14} color="#FFFFFF" />
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Trademark Notice */}
          <View
            style={{
              backgroundColor: "rgba(234, 179, 8, 0.1)",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "rgba(234, 179, 8, 0.3)",
            }}
          >
            <Text
              style={{
                color: "#FDE047",
                fontSize: 15,
                fontWeight: "600",
                textAlign: "center",
                marginBottom: 8,
              }}
            >
              ⚠️ Trademark & Brand Notice
            </Text>
            <Text
              style={{
                color: "#FEF08A",
                fontSize: 13,
                textAlign: "center",
                lineHeight: 20,
              }}
            >
              Use of trademarks, branding, and proprietary valuation models
              requires written permission from NIBLS Inc.
            </Text>
          </View>

          {/* Prior Art Reference */}
          <View
            style={{
              backgroundColor: "rgba(30, 41, 59, 0.5)",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text
              style={{
                color: "#FFFFFF",
                fontSize: 16,
                fontWeight: "700",
                marginBottom: 12,
              }}
            >
              Prior Art & Reference Documentation
            </Text>
            <View
              style={{
                backgroundColor: "rgba(59, 130, 246, 0.1)",
                borderRadius: 12,
                padding: 16,
                marginBottom: 12,
              }}
            >
              <Text
                style={{
                  color: "#CBD5E1",
                  fontSize: 13,
                  lineHeight: 20,
                  marginBottom: 12,
                }}
              >
                Tech+Ball Genre: Biometric sports technology ball or blockchain
                technology hardware for a blockchain token or cryptocurrency
                coin marketplace application
              </Text>
              <TouchableOpacity
                onPress={() =>
                  openLink("https://priorart.ip.com/IPCOM/000271355")
                }
              >
                <Text
                  style={{
                    color: "#60A5FA",
                    fontSize: 12,
                    textDecorationLine: "underline",
                    fontFamily: "monospace",
                    marginBottom: 12,
                  }}
                >
                  https://priorart.ip.com/IPCOM/000271355
                </Text>
              </TouchableOpacity>
              <View style={{ gap: 4 }}>
                <Text style={{ color: "#64748B", fontSize: 11 }}>
                  Publication Date: 2022-Nov-30
                </Text>
                <Text style={{ color: "#64748B", fontSize: 11 }}>
                  Author: Dashawn Ramel Bledsoe
                </Text>
                <Text style={{ color: "#64748B", fontSize: 11 }}>
                  Document: IPCOM000271355D
                </Text>
              </View>
            </View>

            <TouchableOpacity
              onPress={() =>
                openLink("https://priorart.ip.com/IPCOM/000271355")
              }
              style={{
                backgroundColor: "#1E3A8A",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                paddingVertical: 12,
                paddingHorizontal: 16,
                borderRadius: 8,
              }}
            >
              <ExternalLink size={16} color="#60A5FA" />
              <Text
                style={{
                  color: "#60A5FA",
                  fontSize: 13,
                  fontWeight: "600",
                }}
              >
                View Prior Art Publication
              </Text>
            </TouchableOpacity>
          </View>

          {/* GitHub Link */}
          <View
            style={{
              backgroundColor: "rgba(30, 41, 59, 0.5)",
              borderRadius: 16,
              padding: 20,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text
              style={{
                color: "#FFFFFF",
                fontSize: 16,
                fontWeight: "700",
                marginBottom: 12,
              }}
            >
              Open Source Repository
            </Text>
            <TouchableOpacity
              onPress={() => openLink("https://github.com/bim-apes")}
              style={{
                backgroundColor: "#1F2937",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                paddingVertical: 12,
                paddingHorizontal: 16,
                borderRadius: 8,
              }}
            >
              <ExternalLink size={16} color="#FFFFFF" />
              <Text
                style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "600" }}
              >
                github.com/bim-apes
              </Text>
            </TouchableOpacity>
            <Text
              style={{
                color: "#94A3B8",
                fontSize: 12,
                marginTop: 12,
                textAlign: "center",
                lineHeight: 18,
              }}
            >
              View source code, contribute, and explore the BIM-APES ecosystem
            </Text>
          </View>

          {/* Version Info */}
          <View
            style={{
              marginTop: 8,
              paddingTop: 16,
              borderTopWidth: 1,
              borderTopColor: "#334155",
            }}
          >
            <Text
              style={{
                color: "#64748B",
                fontSize: 12,
                textAlign: "center",
                marginBottom: 8,
              }}
            >
              NIBLS Inc. · Bledsoe Investment Management · BIM-APES Platform
            </Text>
            <Text
              style={{
                color: "#475569",
                fontSize: 11,
                textAlign: "center",
                lineHeight: 18,
              }}
            >
              Advancing athlete NIL valuation through biometric intelligence and
              performance analytics
            </Text>
            <Text
              style={{
                color: "#334155",
                fontSize: 10,
                textAlign: "center",
                marginTop: 8,
              }}
            >
              BIM‑APES Platform v2.0 · PhysiobioFIN Performance Network (RPN)
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
