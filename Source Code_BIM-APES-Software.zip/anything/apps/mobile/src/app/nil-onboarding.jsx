import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  User,
  Users,
  Target,
  UserCheck,
  Activity,
  Heart,
  Brain,
  Smartphone,
  Star,
  TrendingUp,
  CheckCircle,
  ArrowRight,
  Loader,
} from "lucide-react-native";
import useHandleStreamResponse from "@/utils/useHandleStreamResponse";

export default function NILOnboardingFlow() {
  const insets = useSafeAreaInsets();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedRole, setSelectedRole] = useState(null);
  const [biometricData, setBiometricData] = useState({
    fatigue: 0,
    stress: 0,
    cohesion: 0,
  });
  const [qaasDecision, setQaasDecision] = useState(null);
  const [socialSync, setSocialSync] = useState({
    tiktok: false,
    instagram: false,
    youtube: false,
  });
  const [isCompleting, setIsCompleting] = useState(false);
  const [completionData, setCompletionData] = useState(null);
  const [error, setError] = useState(null);

  const handleStreamResponse = useHandleStreamResponse();

  const roles = [
    {
      id: "athlete",
      title: "Athlete",
      icon: User,
      color: "#00D4FF",
      desc: "Track performance & NIL value",
    },
    {
      id: "coach",
      title: "Coach",
      icon: Users,
      color: "#00FF88",
      desc: "Manage team biometrics",
    },
    {
      id: "scout",
      title: "Scout",
      icon: Target,
      color: "#FF6B35",
      desc: "Discover talent & insights",
    },
    {
      id: "agent",
      title: "Agent",
      icon: UserCheck,
      color: "#A855F7",
      desc: "Optimize athlete partnerships",
    },
  ];

  const socialPlatforms = [
    { id: "tiktok", name: "TikTok", color: "#FF0050", followers: "12.4K" },
    { id: "instagram", name: "Instagram", color: "#E4405F", followers: "8.7K" },
    { id: "youtube", name: "YouTube", color: "#FF0000", followers: "3.2K" },
  ];

  const steps = [
    "Role Selection",
    "Biometric Calibration",
    "QaaS Decision",
    "Social Sync",
    "NIL Preview",
  ];

  const completeOnboarding = async () => {
    setIsCompleting(true);
    setError(null);

    try {
      const onboardingData = {
        selectedRole,
        biometricData,
        qaasDecision,
        socialSync,
        deviceInfo: {
          platform: "mobile",
          timestamp: new Date().toISOString(),
          appVersion: "1.0.0",
        },
      };

      const response = await fetch("/api/onboarding/complete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(onboardingData),
      });

      const result = await handleStreamResponse(response);

      if (result.success) {
        setCompletionData(result.data);
        Alert.alert(
          "Welcome to NIL!",
          `Your profile is ready! NIL Score: ${result.data.nilScore}`,
          [
            {
              text: "Continue",
              onPress: () => console.log("Navigate to dashboard"),
            },
          ],
        );
      } else {
        throw new Error(result.error || "Onboarding failed");
      }
    } catch (error) {
      console.error("Onboarding error:", error);
      setError(error.message);
      Alert.alert("Error", "Failed to complete onboarding. Please try again.");
    } finally {
      setIsCompleting(false);
    }
  };

  const renderRoleSelection = () => (
    <View style={{ flex: 1, padding: 20 }}>
      <Text
        style={{
          fontSize: 28,
          fontWeight: "bold",
          color: "#FFF",
          marginBottom: 8,
        }}
      >
        Choose Your Role
      </Text>
      <Text style={{ fontSize: 16, color: "#94A3B8", marginBottom: 32 }}>
        Select how you'll engage with the NIL ecosystem
      </Text>

      <View style={{ flex: 1 }}>
        {roles.map((role) => {
          const IconComponent = role.icon;
          return (
            <TouchableOpacity
              key={role.id}
              onPress={() => setSelectedRole(role.id)}
              style={{
                backgroundColor:
                  selectedRole === role.id ? role.color : "#1E293B",
                borderWidth: 2,
                borderColor: selectedRole === role.id ? role.color : "#475569",
                borderRadius: 16,
                padding: 20,
                marginBottom: 16,
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <View
                style={{
                  width: 56,
                  height: 56,
                  backgroundColor:
                    selectedRole === role.id ? "#FFF" : role.color,
                  borderRadius: 28,
                  justifyContent: "center",
                  alignItems: "center",
                  marginRight: 16,
                }}
              >
                <IconComponent
                  size={28}
                  color={selectedRole === role.id ? role.color : "#FFF"}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 20,
                    fontWeight: "bold",
                    color: selectedRole === role.id ? "#FFF" : "#FFF",
                    marginBottom: 4,
                  }}
                >
                  {role.title}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: selectedRole === role.id ? "#FFF" : "#94A3B8",
                  }}
                >
                  {role.desc}
                </Text>
              </View>
              {selectedRole === role.id && (
                <CheckCircle size={24} color="#FFF" />
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const renderBiometricCalibration = () => (
    <View style={{ flex: 1, padding: 20 }}>
      <Text
        style={{
          fontSize: 28,
          fontWeight: "bold",
          color: "#FFF",
          marginBottom: 8,
        }}
      >
        Biometric Calibration
      </Text>
      <Text style={{ fontSize: 16, color: "#94A3B8", marginBottom: 32 }}>
        Help us understand your current state for accurate tracking
      </Text>

      {[
        {
          key: "fatigue",
          label: "Fatigue Level",
          icon: Activity,
          color: "#FF6B35",
        },
        { key: "stress", label: "Stress Level", icon: Heart, color: "#F59E0B" },
        {
          key: "cohesion",
          label: "Team Cohesion",
          icon: Brain,
          color: "#00FF88",
        },
      ].map((metric) => {
        const IconComponent = metric.icon;
        return (
          <View key={metric.key} style={{ marginBottom: 32 }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <IconComponent size={24} color={metric.color} />
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  color: "#FFF",
                  marginLeft: 12,
                }}
              >
                {metric.label}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginBottom: 8,
              }}
            >
              {[1, 2, 3, 4, 5].map((level) => (
                <TouchableOpacity
                  key={level}
                  onPress={() =>
                    setBiometricData((prev) => ({
                      ...prev,
                      [metric.key]: level,
                    }))
                  }
                  style={{
                    width: 56,
                    height: 56,
                    borderRadius: 28,
                    backgroundColor:
                      biometricData[metric.key] >= level
                        ? metric.color
                        : "#475569",
                    justifyContent: "center",
                    alignItems: "center",
                    borderWidth: 2,
                    borderColor:
                      biometricData[metric.key] >= level
                        ? metric.color
                        : "#64748B",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "bold",
                      color:
                        biometricData[metric.key] >= level ? "#FFF" : "#94A3B8",
                    }}
                  >
                    {level}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text
              style={{ fontSize: 12, color: "#64748B", textAlign: "center" }}
            >
              1 = Low • 5 = High
            </Text>
          </View>
        );
      })}
    </View>
  );

  const renderQaasDecision = () => (
    <View style={{ flex: 1, padding: 20 }}>
      <Text
        style={{
          fontSize: 28,
          fontWeight: "bold",
          color: "#FFF",
          marginBottom: 8,
        }}
      >
        QaaS Decision Simulation
      </Text>
      <Text style={{ fontSize: 16, color: "#94A3B8", marginBottom: 32 }}>
        Test your decision-making under pressure
      </Text>

      <View
        style={{
          backgroundColor: "#1E293B",
          borderRadius: 16,
          padding: 24,
          marginBottom: 24,
          borderWidth: 1,
          borderColor: "#475569",
        }}
      >
        <Text
          style={{
            fontSize: 18,
            fontWeight: "600",
            color: "#FFF",
            marginBottom: 16,
          }}
        >
          Scenario: Championship Game - 4th Quarter
        </Text>
        <Text
          style={{
            fontSize: 14,
            color: "#CBD5E1",
            marginBottom: 24,
            lineHeight: 20,
          }}
        >
          Your team is down by 3 points with 2 minutes left. Coach calls a
          timeout and asks for your input on the next play. What's your
          approach?
        </Text>

        {[
          {
            id: "aggressive",
            text: "Go for the big play - all or nothing",
            color: "#FF6B35",
          },
          {
            id: "strategic",
            text: "Execute the practiced play methodically",
            color: "#00D4FF",
          },
          {
            id: "adaptive",
            text: "Read the defense and adapt mid-play",
            color: "#00FF88",
          },
        ].map((option) => (
          <TouchableOpacity
            key={option.id}
            onPress={() => setQaasDecision(option.id)}
            style={{
              backgroundColor:
                qaasDecision === option.id ? option.color : "#0F172A",
              borderWidth: 2,
              borderColor:
                qaasDecision === option.id ? option.color : "#475569",
              borderRadius: 12,
              padding: 16,
              marginBottom: 12,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <View
              style={{
                width: 20,
                height: 20,
                borderRadius: 10,
                backgroundColor:
                  qaasDecision === option.id ? "#FFF" : "transparent",
                borderWidth: 2,
                borderColor: qaasDecision === option.id ? "#FFF" : "#64748B",
                marginRight: 12,
              }}
            />
            <Text
              style={{
                fontSize: 16,
                color: qaasDecision === option.id ? "#FFF" : "#CBD5E1",
                flex: 1,
              }}
            >
              {option.text}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderSocialSync = () => (
    <View style={{ flex: 1, padding: 20 }}>
      <Text
        style={{
          fontSize: 28,
          fontWeight: "bold",
          color: "#FFF",
          marginBottom: 8,
        }}
      >
        Social Media Sync
      </Text>
      <Text style={{ fontSize: 16, color: "#94A3B8", marginBottom: 32 }}>
        Connect your platforms to enhance your NIL profile (optional)
      </Text>

      {socialPlatforms.map((platform) => (
        <TouchableOpacity
          key={platform.id}
          onPress={() =>
            setSocialSync((prev) => ({
              ...prev,
              [platform.id]: !prev[platform.id],
            }))
          }
          style={{
            backgroundColor: socialSync[platform.id]
              ? platform.color
              : "#1E293B",
            borderWidth: 2,
            borderColor: socialSync[platform.id] ? platform.color : "#475569",
            borderRadius: 16,
            padding: 20,
            marginBottom: 16,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 56,
              height: 56,
              backgroundColor: socialSync[platform.id]
                ? "#FFF"
                : platform.color,
              borderRadius: 28,
              justifyContent: "center",
              alignItems: "center",
              marginRight: 16,
            }}
          >
            <Smartphone
              size={28}
              color={socialSync[platform.id] ? platform.color : "#FFF"}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: "bold",
                color: "#FFF",
                marginBottom: 4,
              }}
            >
              {platform.name}
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: socialSync[platform.id] ? "#FFF" : "#94A3B8",
              }}
            >
              {platform.followers} followers
            </Text>
          </View>
          {socialSync[platform.id] && <CheckCircle size={24} color="#FFF" />}
        </TouchableOpacity>
      ))}

      <TouchableOpacity
        style={{
          backgroundColor: "transparent",
          borderWidth: 2,
          borderColor: "#64748B",
          borderRadius: 12,
          padding: 16,
          marginTop: 16,
          alignItems: "center",
        }}
      >
        <Text style={{ fontSize: 16, color: "#94A3B8" }}>Skip for now</Text>
      </TouchableOpacity>
    </View>
  );

  const renderNILPreview = () => {
    // Use real data from completion if available, otherwise show calculated preview
    const nilScore = completionData?.nilScore || 87;
    const brandFit = 92;
    const insights = completionData?.insights || [];

    return (
      <View style={{ flex: 1, padding: 20 }}>
        <Text
          style={{
            fontSize: 28,
            fontWeight: "bold",
            color: "#FFF",
            marginBottom: 8,
          }}
        >
          {completionData ? "NIL Profile Created!" : "Your NIL Profile"}
        </Text>
        <Text style={{ fontSize: 16, color: "#94A3B8", marginBottom: 32 }}>
          {completionData
            ? "Profile successfully created with live valuation"
            : "Here's your projected valuation based on your profile"}
        </Text>

        {/* NIL Score */}
        <View
          style={{
            backgroundColor: "#1E293B",
            borderRadius: 20,
            padding: 24,
            marginBottom: 20,
            borderWidth: 2,
            borderColor: "#00D4FF",
          }}
        >
          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                fontSize: 48,
                fontWeight: "bold",
                color: "#00D4FF",
                marginBottom: 8,
              }}
            >
              {nilScore}
            </Text>
            <Text style={{ fontSize: 16, color: "#FFF", marginBottom: 4 }}>
              NIL Score
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <TrendingUp size={16} color="#00FF88" />
              <Text style={{ fontSize: 14, color: "#00FF88", marginLeft: 4 }}>
                {completionData ? "Live Score Generated" : "+12 from last week"}
              </Text>
            </View>
          </View>
        </View>

        {/* Brand Fit Meter */}
        <View
          style={{
            backgroundColor: "#1E293B",
            borderRadius: 16,
            padding: 20,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: "#475569",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#FFF",
              marginBottom: 16,
            }}
          >
            Brand Fit Meter
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 8,
            }}
          >
            <View
              style={{
                flex: 1,
                height: 8,
                backgroundColor: "#475569",
                borderRadius: 4,
                marginRight: 12,
              }}
            >
              <View
                style={{
                  width: `${brandFit}%`,
                  height: 8,
                  backgroundColor: "#00FF88",
                  borderRadius: 4,
                }}
              />
            </View>
            <Text style={{ fontSize: 16, fontWeight: "bold", color: "#FFF" }}>
              {brandFit}%
            </Text>
          </View>
          <Text style={{ fontSize: 12, color: "#94A3B8" }}>
            Excellent alignment with premium athletic brands
          </Text>
        </View>

        {/* Insights from API */}
        {insights.length > 0 && (
          <View
            style={{
              backgroundColor: "#1E293B",
              borderRadius: 16,
              padding: 20,
              marginBottom: 24,
              borderWidth: 1,
              borderColor: "#475569",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                color: "#FFF",
                marginBottom: 16,
              }}
            >
              Personalized Insights
            </Text>
            {insights.slice(0, 3).map((insight, index) => (
              <View key={index} style={{ marginBottom: 12 }}>
                <Text
                  style={{
                    fontSize: 14,
                    color: getInsightColor(insight.type),
                    fontWeight: "600",
                    marginBottom: 4,
                  }}
                >
                  {insight.type.toUpperCase()}:{" "}
                  {insight.category.replace("_", " ").toUpperCase()}
                </Text>
                <Text style={{ fontSize: 12, color: "#CBD5E1" }}>
                  {insight.message}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* Quick Stats */}
        <View style={{ flexDirection: "row", marginBottom: 32 }}>
          {[
            { label: "Performance", value: "94", color: "#00D4FF" },
            { label: "Engagement", value: "88", color: "#FF6B35" },
            { label: "Marketability", value: "91", color: "#00FF88" },
          ].map((stat, index) => (
            <View
              key={index}
              style={{
                flex: 1,
                backgroundColor: "#1E293B",
                borderRadius: 12,
                padding: 16,
                marginRight: index < 2 ? 8 : 0,
                alignItems: "center",
              }}
            >
              <Text
                style={{ fontSize: 24, fontWeight: "bold", color: stat.color }}
              >
                {stat.value}
              </Text>
              <Text
                style={{ fontSize: 12, color: "#94A3B8", textAlign: "center" }}
              >
                {stat.label}
              </Text>
            </View>
          ))}
        </View>

        {/* Error Display */}
        {error && (
          <View
            style={{
              backgroundColor: "#8B2635",
              borderRadius: 12,
              padding: 16,
              marginBottom: 16,
            }}
          >
            <Text style={{ color: "#FFF", fontSize: 14 }}>{error}</Text>
          </View>
        )}
      </View>
    );
  };

  const getInsightColor = (type) => {
    const colors = {
      recommendation: "#00D4FF",
      alert: "#FF6B35",
      opportunity: "#00FF88",
      strength: "#A855F7",
      guidance: "#94A3B8",
    };
    return colors[type] || "#94A3B8";
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return renderRoleSelection();
      case 1:
        return renderBiometricCalibration();
      case 2:
        return renderQaasDecision();
      case 3:
        return renderSocialSync();
      case 4:
        return renderNILPreview();
      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 0:
        return selectedRole !== null;
      case 1:
        return Object.values(biometricData).every((v) => v > 0);
      case 2:
        return qaasDecision !== null;
      case 3:
        return true; // Optional step
      case 4:
        return true;
      default:
        return false;
    }
  };

  const handleContinue = async () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1);

      // Pre-complete onboarding when reaching final step
      if (currentStep === steps.length - 2 && !completionData) {
        await completeOnboarding();
      }
    } else {
      // Final completion or navigation
      console.log("Navigate to main app");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#0F172A" }}>
      <StatusBar style="light" />

      {/* Progress Header */}
      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 20,
          backgroundColor: "#1E293B",
          borderBottomWidth: 1,
          borderBottomColor: "#475569",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <Text
            style={{ fontSize: 24, fontWeight: "bold", color: "#FFF", flex: 1 }}
          >
            NIL Onboarding
          </Text>
          <Text style={{ fontSize: 14, color: "#94A3B8" }}>
            {currentStep + 1} of {steps.length}
          </Text>
        </View>

        <View style={{ flexDirection: "row" }}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={{
                flex: 1,
                height: 4,
                backgroundColor: index <= currentStep ? "#00D4FF" : "#475569",
                borderRadius: 2,
                marginRight: index < steps.length - 1 ? 4 : 0,
              }}
            />
          ))}
        </View>
      </View>

      {/* Step Content */}
      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        {renderStepContent()}
      </ScrollView>

      {/* Navigation Footer */}
      <View
        style={{
          padding: 20,
          paddingBottom: insets.bottom + 20,
          backgroundColor: "#1E293B",
          borderTopWidth: 1,
          borderTopColor: "#475569",
        }}
      >
        <View style={{ flexDirection: "row", gap: 12 }}>
          {currentStep > 0 && (
            <TouchableOpacity
              onPress={() => setCurrentStep((prev) => prev - 1)}
              style={{
                flex: 1,
                backgroundColor: "#475569",
                borderRadius: 12,
                padding: 16,
                alignItems: "center",
              }}
            >
              <Text style={{ fontSize: 16, fontWeight: "600", color: "#FFF" }}>
                Back
              </Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            onPress={handleContinue}
            disabled={!canProceed() || isCompleting}
            style={{
              flex: 2,
              backgroundColor:
                canProceed() && !isCompleting ? "#00D4FF" : "#475569",
              borderRadius: 12,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {isCompleting ? (
              <Loader size={20} color="#FFF" />
            ) : (
              <>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: canProceed() ? "#FFF" : "#94A3B8",
                    marginRight: 8,
                  }}
                >
                  {currentStep === steps.length - 1 ? "Complete" : "Continue"}
                </Text>
                <ArrowRight
                  size={20}
                  color={canProceed() ? "#FFF" : "#94A3B8"}
                />
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
