import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState } from "react";
import { Zap, ArrowLeft } from "lucide-react-native";
import { useRouter } from "expo-router";
import useUser from "@/utils/auth/useUser";

export default function RacketSportsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: user, loading: userLoading } = useUser();

  const [sport, setSport] = useState("tennis");
  const [athleteId, setAthleteId] = useState("");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const [matchData, setMatchData] = useState({
    firstServePercentage: "65",
    acesCount: "5",
    winnersCount: "25",
    unforcedErrors: "18",
    breakPointsConverted: "3",
    breakPointsTotal: "7",
  });

  const handleSubmit = async () => {
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }

    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/sport-specific/racket-sports/spike-analysis",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            sport,
            matchData: {
              firstServePercentage:
                parseFloat(matchData.firstServePercentage) || 0,
              firstServePointsWon: 70,
              secondServePointsWon: 50,
              acesCount: parseInt(matchData.acesCount) || 0,
              doubleFaults: 3,
              winnersCount: parseInt(matchData.winnersCount) || 0,
              unforcedErrors: parseInt(matchData.unforcedErrors) || 0,
              breakPointsConverted:
                parseInt(matchData.breakPointsConverted) || 0,
              breakPointsTotal: parseInt(matchData.breakPointsTotal) || 0,
              totalPoints: 80,
              pointsWon: 45,
            },
          }),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to process racket sports data");
      }

      const data = await response.json();
      setPerformanceData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (userLoading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0f172a",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <StatusBar style="light" />
        <ActivityIndicator size="large" color="#a855f7" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#581c87" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: 20,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginBottom: 16 }}
        >
          <ArrowLeft color="#a855f7" size={28} />
        </TouchableOpacity>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            marginBottom: 8,
          }}
        >
          <Zap color="#a855f7" size={36} />
          <Text style={{ fontSize: 28, fontWeight: "bold", color: "#fff" }}>
            Racket Sports
          </Text>
        </View>
        <Text style={{ fontSize: 14, color: "#e9d5ff", marginBottom: 24 }}>
          Tennis · Pickleball · Badminton
        </Text>

        {/* Sport Selector */}
        <View
          style={{
            flexDirection: "row",
            gap: 8,
            marginBottom: 20,
            flexWrap: "wrap",
          }}
        >
          {["tennis", "pickleball", "badminton"].map((sportType) => (
            <TouchableOpacity
              key={sportType}
              onPress={() => setSport(sportType)}
              style={{
                backgroundColor: sport === sportType ? "#a855f7" : "#1e293b",
                paddingVertical: 10,
                paddingHorizontal: 16,
                borderRadius: 8,
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontWeight: "bold",
                  textTransform: "uppercase",
                  fontSize: 12,
                }}
              >
                {sportType}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Input Form */}
        <View
          style={{
            backgroundColor: "#1e293b",
            padding: 20,
            borderRadius: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text style={{ color: "#94a3b8", fontSize: 13, marginBottom: 8 }}>
            Athlete ID
          </Text>
          <TextInput
            value={athleteId}
            onChangeText={setAthleteId}
            placeholder="Enter athlete ID"
            placeholderTextColor="#64748b"
            keyboardType="numeric"
            style={{
              backgroundColor: "#0f172a",
              color: "#fff",
              padding: 14,
              borderRadius: 8,
              borderWidth: 1,
              borderColor: "#334155",
              fontSize: 16,
              marginBottom: 16,
            }}
          />

          <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                1st Serve %
              </Text>
              <TextInput
                value={matchData.firstServePercentage}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, firstServePercentage: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Aces
              </Text>
              <TextInput
                value={matchData.acesCount}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, acesCount: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
          </View>

          <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Winners
              </Text>
              <TextInput
                value={matchData.winnersCount}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, winnersCount: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Unforced Errors
              </Text>
              <TextInput
                value={matchData.unforcedErrors}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, unforcedErrors: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
          </View>

          {error && (
            <View
              style={{
                backgroundColor: "#7f1d1d",
                padding: 14,
                borderRadius: 8,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#991b1b",
              }}
            >
              <Text style={{ color: "#fca5a5", fontSize: 13 }}>{error}</Text>
            </View>
          )}

          <TouchableOpacity
            onPress={handleSubmit}
            disabled={loadingData}
            style={{
              backgroundColor: loadingData ? "#475569" : "#a855f7",
              padding: 16,
              borderRadius: 12,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "bold" }}>
              {loadingData ? "Analyzing..." : "Analyze Spike Performance"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Results */}
        {performanceData && (
          <View
            style={{
              backgroundColor: "#1e293b",
              padding: 20,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#fff",
                marginBottom: 16,
              }}
            >
              Spike Analysis
            </Text>

            <View
              style={{
                backgroundColor: "#581c87",
                padding: 20,
                borderRadius: 12,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#a855f7",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 8,
                }}
              >
                <Text style={{ color: "#e9d5ff", fontSize: 14 }}>
                  Spike Score
                </Text>
                <Text
                  style={{ color: "#a855f7", fontSize: 32, fontWeight: "bold" }}
                >
                  {performanceData.spikeScore?.toFixed(1)}
                </Text>
              </View>
              <View
                style={{
                  height: 6,
                  backgroundColor: "#1e293b",
                  borderRadius: 3,
                }}
              >
                <View
                  style={{
                    height: 6,
                    backgroundColor: "#a855f7",
                    borderRadius: 3,
                    width: `${performanceData.spikeScore}%`,
                  }}
                />
              </View>
            </View>

            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
              <SmallMetric
                label="Serve %"
                value={`${performanceData.serve?.firstServePercentage?.toFixed(1)}%`}
              />
              <SmallMetric label="Aces" value={performanceData.serve?.aces} />
              <SmallMetric
                label="Winners"
                value={performanceData.efficiency?.winners}
              />
              <SmallMetric
                label="Break Point %"
                value={`${performanceData.pressure?.breakPointConversion?.toFixed(1)}%`}
              />
            </View>
          </View>
        )}

        {/* Licensing */}
        <View
          style={{
            marginTop: 32,
            paddingTop: 24,
            borderTopWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 9 }}>
            BIM-APES Software licensed under Apache License, Version 2.0.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function SmallMetric({ label, value }) {
  return (
    <View
      style={{
        backgroundColor: "#0f172a",
        padding: 12,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: "#334155",
        minWidth: 100,
      }}
    >
      <Text style={{ color: "#94a3b8", fontSize: 11, marginBottom: 4 }}>
        {label}
      </Text>
      <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>
        {value}
      </Text>
    </View>
  );
}
