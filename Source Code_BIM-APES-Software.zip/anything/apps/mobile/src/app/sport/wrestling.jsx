import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState } from "react";
import { Activity, Target, TrendingUp, ArrowLeft } from "lucide-react-native";
import { useRouter } from "expo-router";
import useUser from "@/utils/auth/useUser";

export default function WrestlingScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: user, loading: userLoading } = useUser();

  const [athleteId, setAthleteId] = useState("");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const [matchData, setMatchData] = useState({
    takedowns: "0",
    takedownAttempts: "0",
    escapes: "0",
    escapeAttempts: "0",
    reversals: "0",
    reversalAttempts: "0",
    nearFalls: "0",
    controlTimeSeconds: "0",
    exposurePoints: "0",
    technicalViolations: "0",
  });

  const handleSubmit = async () => {
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }

    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/sport-specific/wrestling/performance-tracking",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            matchData: {
              takedowns: parseFloat(matchData.takedowns) || 0,
              takedownAttempts: parseFloat(matchData.takedownAttempts) || 0,
              escapes: parseFloat(matchData.escapes) || 0,
              escapeAttempts: parseFloat(matchData.escapeAttempts) || 0,
              reversals: parseFloat(matchData.reversals) || 0,
              reversalAttempts: parseFloat(matchData.reversalAttempts) || 0,
              nearFalls: parseFloat(matchData.nearFalls) || 0,
              controlTimeSeconds: parseFloat(matchData.controlTimeSeconds) || 0,
              totalMatchTimeSeconds: 360,
              exposurePoints: parseFloat(matchData.exposurePoints) || 0,
              technicalViolations:
                parseFloat(matchData.technicalViolations) || 0,
            },
            sessionType: "match",
          }),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to process wrestling performance");
      }

      const data = await response.json();
      setPerformanceData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (userLoading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0f172a",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <StatusBar style="light" />
        <ActivityIndicator size="large" color="#3b82f6" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#0f172a" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: 20,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginBottom: 16 }}
        >
          <ArrowLeft color="#3b82f6" size={28} />
        </TouchableOpacity>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            marginBottom: 8,
          }}
        >
          <Activity color="#eab308" size={36} />
          <Text style={{ fontSize: 28, fontWeight: "bold", color: "#fff" }}>
            Wrestling Tracker
          </Text>
        </View>
        <Text style={{ fontSize: 14, color: "#94a3b8", marginBottom: 24 }}>
          BIM-APES Wrestling Performance Module
        </Text>

        {/* Input Form */}
        <View
          style={{
            backgroundColor: "#1e293b",
            padding: 20,
            borderRadius: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "bold",
              color: "#fff",
              marginBottom: 16,
            }}
          >
            Match Data Input
          </Text>

          <Text style={{ color: "#94a3b8", fontSize: 13, marginBottom: 8 }}>
            Athlete ID
          </Text>
          <TextInput
            value={athleteId}
            onChangeText={setAthleteId}
            placeholder="Enter athlete ID"
            placeholderTextColor="#64748b"
            keyboardType="numeric"
            style={{
              backgroundColor: "#0f172a",
              color: "#fff",
              padding: 14,
              borderRadius: 8,
              borderWidth: 1,
              borderColor: "#334155",
              fontSize: 16,
              marginBottom: 16,
            }}
          />

          <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Takedowns
              </Text>
              <TextInput
                value={matchData.takedowns}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, takedowns: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                TD Attempts
              </Text>
              <TextInput
                value={matchData.takedownAttempts}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, takedownAttempts: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
          </View>

          <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Escapes
              </Text>
              <TextInput
                value={matchData.escapes}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, escapes: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Esc. Attempts
              </Text>
              <TextInput
                value={matchData.escapeAttempts}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, escapeAttempts: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
          </View>

          <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Reversals
              </Text>
              <TextInput
                value={matchData.reversals}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, reversals: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Near Falls
              </Text>
              <TextInput
                value={matchData.nearFalls}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, nearFalls: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
          </View>

          <View style={{ marginBottom: 16 }}>
            <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
              Control Time (seconds)
            </Text>
            <TextInput
              value={matchData.controlTimeSeconds}
              onChangeText={(text) =>
                setMatchData({ ...matchData, controlTimeSeconds: text })
              }
              keyboardType="numeric"
              style={{
                backgroundColor: "#0f172a",
                color: "#fff",
                padding: 12,
                borderRadius: 8,
                borderWidth: 1,
                borderColor: "#334155",
                fontSize: 14,
              }}
            />
          </View>

          {error && (
            <View
              style={{
                backgroundColor: "#7f1d1d",
                padding: 14,
                borderRadius: 8,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#991b1b",
              }}
            >
              <Text style={{ color: "#fca5a5", fontSize: 13 }}>{error}</Text>
            </View>
          )}

          <TouchableOpacity
            onPress={handleSubmit}
            disabled={loadingData}
            style={{
              backgroundColor: loadingData ? "#475569" : "#3b82f6",
              padding: 16,
              borderRadius: 12,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "bold" }}>
              {loadingData ? "Processing..." : "Analyze Performance"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Results */}
        {performanceData && (
          <View
            style={{
              backgroundColor: "#1e293b",
              padding: 20,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#fff",
                marginBottom: 16,
              }}
            >
              Performance Analysis
            </Text>

            {/* BIM Score */}
            <View
              style={{
                backgroundColor: "#713f12",
                padding: 20,
                borderRadius: 12,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#a16207",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 8,
                }}
              >
                <Text style={{ color: "#fef08a", fontSize: 14 }}>
                  BIM Performance Score
                </Text>
                <Text
                  style={{ color: "#eab308", fontSize: 32, fontWeight: "bold" }}
                >
                  {performanceData.bimScore?.toFixed(1)}
                </Text>
              </View>
              <View
                style={{
                  height: 6,
                  backgroundColor: "#44403c",
                  borderRadius: 3,
                  marginBottom: 8,
                }}
              >
                <View
                  style={{
                    height: 6,
                    backgroundColor: "#eab308",
                    borderRadius: 3,
                    width: `${performanceData.bimScore}%`,
                  }}
                />
              </View>
              <Text style={{ color: "#fef08a", fontSize: 12 }}>
                Tier:{" "}
                <Text
                  style={{ fontWeight: "bold", textTransform: "uppercase" }}
                >
                  {performanceData.tier}
                </Text>
              </Text>
            </View>

            {/* Metrics */}
            <View style={{ gap: 10 }}>
              <MetricCard
                label="Takedown Efficiency"
                value={`${performanceData.performanceMetrics?.takedownEfficiency.toFixed(1)}%`}
              />
              <MetricCard
                label="Escape Rate"
                value={`${performanceData.performanceMetrics?.escapeRate.toFixed(1)}%`}
              />
              <MetricCard
                label="Control Percentage"
                value={`${performanceData.performanceMetrics?.controlPercentage.toFixed(1)}%`}
              />
            </View>

            {/* Insights */}
            {performanceData.insights &&
              performanceData.insights.length > 0 && (
                <View style={{ marginTop: 16 }}>
                  <Text
                    style={{
                      color: "#fff",
                      fontSize: 16,
                      fontWeight: "bold",
                      marginBottom: 12,
                    }}
                  >
                    Coaching Insights
                  </Text>
                  {performanceData.insights.map((insight, idx) => (
                    <View
                      key={idx}
                      style={{
                        backgroundColor:
                          insight.type === "strength"
                            ? "#064e3b"
                            : insight.type === "weakness"
                              ? "#7f1d1d"
                              : "#713f12",
                        padding: 14,
                        borderRadius: 8,
                        marginBottom: 10,
                        borderWidth: 1,
                        borderColor:
                          insight.type === "strength"
                            ? "#10b981"
                            : insight.type === "weakness"
                              ? "#ef4444"
                              : "#eab308",
                      }}
                    >
                      <Text
                        style={{
                          color: "#fff",
                          fontWeight: "600",
                          marginBottom: 4,
                        }}
                      >
                        {insight.metric}
                      </Text>
                      <Text
                        style={{
                          color: "#94a3b8",
                          fontSize: 13,
                          marginBottom: 4,
                        }}
                      >
                        {insight.message}
                      </Text>
                      <Text
                        style={{
                          color: "#cbd5e1",
                          fontSize: 12,
                          fontStyle: "italic",
                        }}
                      >
                        {insight.recommendation}
                      </Text>
                    </View>
                  ))}
                </View>
              )}
          </View>
        )}

        {/* Licensing */}
        <View
          style={{
            marginTop: 32,
            paddingTop: 24,
            borderTopWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 9 }}>
            BIM-APES Software licensed under Apache License, Version 2.0.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function MetricCard({ label, value }) {
  return (
    <View
      style={{
        backgroundColor: "#0f172a",
        padding: 14,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: "#334155",
      }}
    >
      <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 4 }}>
        {label}
      </Text>
      <Text style={{ color: "#fff", fontSize: 20, fontWeight: "bold" }}>
        {value}
      </Text>
    </View>
  );
}
