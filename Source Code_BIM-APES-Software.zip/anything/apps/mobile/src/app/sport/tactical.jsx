import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState } from "react";
import { Users, ArrowLeft } from "lucide-react-native";
import { useRouter } from "expo-router";
import useUser from "@/utils/auth/useUser";

export default function TacticalSportsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: user, loading: userLoading } = useUser();

  const [sport, setSport] = useState("soccer");
  const [athleteId, setAthleteId] = useState("");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const [matchData, setMatchData] = useState({
    possessions: "45",
    totalPasses: "50",
    successfulPasses: "42",
    distanceCovered: "11500",
  });

  const handleSubmit = async () => {
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }

    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/sport-specific/tactical-sports/efficiency",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            sport,
            matchData: {
              possessions: parseInt(matchData.possessions) || 0,
              totalPasses: parseInt(matchData.totalPasses) || 0,
              successfulPasses: parseInt(matchData.successfulPasses) || 0,
              distanceCovered: parseInt(matchData.distanceCovered) || 0,
            },
          }),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to process tactical sports data");
      }

      const data = await response.json();
      setPerformanceData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (userLoading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0f172a",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <StatusBar style="light" />
        <ActivityIndicator size="large" color="#10b981" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#064e3b" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: 20,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginBottom: 16 }}
        >
          <ArrowLeft color="#10b981" size={28} />
        </TouchableOpacity>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            marginBottom: 8,
          }}
        >
          <Users color="#10b981" size={36} />
          <Text style={{ fontSize: 28, fontWeight: "bold", color: "#fff" }}>
            Tactical Sports
          </Text>
        </View>
        <Text style={{ fontSize: 14, color: "#d1fae5", marginBottom: 24 }}>
          Rugby · Soccer · Basketball
        </Text>

        {/* Sport Selector */}
        <View
          style={{
            flexDirection: "row",
            gap: 8,
            marginBottom: 20,
            flexWrap: "wrap",
          }}
        >
          {["rugby", "soccer", "basketball"].map((sportType) => (
            <TouchableOpacity
              key={sportType}
              onPress={() => setSport(sportType)}
              style={{
                backgroundColor: sport === sportType ? "#10b981" : "#1e293b",
                paddingVertical: 10,
                paddingHorizontal: 16,
                borderRadius: 8,
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontWeight: "bold",
                  textTransform: "uppercase",
                  fontSize: 12,
                }}
              >
                {sportType}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Input Form */}
        <View
          style={{
            backgroundColor: "#1e293b",
            padding: 20,
            borderRadius: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text style={{ color: "#94a3b8", fontSize: 13, marginBottom: 8 }}>
            Athlete ID
          </Text>
          <TextInput
            value={athleteId}
            onChangeText={setAthleteId}
            placeholder="Enter athlete ID"
            placeholderTextColor="#64748b"
            keyboardType="numeric"
            style={{
              backgroundColor: "#0f172a",
              color: "#fff",
              padding: 14,
              borderRadius: 8,
              borderWidth: 1,
              borderColor: "#334155",
              fontSize: 16,
              marginBottom: 16,
            }}
          />

          <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Possessions
              </Text>
              <TextInput
                value={matchData.possessions}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, possessions: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 6 }}>
                Total Passes
              </Text>
              <TextInput
                value={matchData.totalPasses}
                onChangeText={(text) =>
                  setMatchData({ ...matchData, totalPasses: text })
                }
                keyboardType="numeric"
                style={{
                  backgroundColor: "#0f172a",
                  color: "#fff",
                  padding: 12,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#334155",
                  fontSize: 14,
                }}
              />
            </View>
          </View>

          {error && (
            <View
              style={{
                backgroundColor: "#7f1d1d",
                padding: 14,
                borderRadius: 8,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#991b1b",
              }}
            >
              <Text style={{ color: "#fca5a5", fontSize: 13 }}>{error}</Text>
            </View>
          )}

          <TouchableOpacity
            onPress={handleSubmit}
            disabled={loadingData}
            style={{
              backgroundColor: loadingData ? "#475569" : "#10b981",
              padding: 16,
              borderRadius: 12,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "bold" }}>
              {loadingData ? "Analyzing..." : "Analyze Efficiency"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Results */}
        {performanceData && (
          <View
            style={{
              backgroundColor: "#1e293b",
              padding: 20,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "bold",
                color: "#fff",
                marginBottom: 16,
              }}
            >
              Tactical Analysis
            </Text>

            <View
              style={{
                backgroundColor: "#064e3b",
                padding: 20,
                borderRadius: 12,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#10b981",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 8,
                }}
              >
                <Text style={{ color: "#d1fae5", fontSize: 14 }}>
                  Tactical Efficiency Score
                </Text>
                <Text
                  style={{ color: "#10b981", fontSize: 32, fontWeight: "bold" }}
                >
                  {performanceData.tacticalScore?.toFixed(1)}
                </Text>
              </View>
              <View
                style={{
                  height: 6,
                  backgroundColor: "#1e293b",
                  borderRadius: 3,
                }}
              >
                <View
                  style={{
                    height: 6,
                    backgroundColor: "#10b981",
                    borderRadius: 3,
                    width: `${performanceData.tacticalScore}%`,
                  }}
                />
              </View>
            </View>

            {/* Efficiency Metrics */}
            {performanceData.efficiency && (
              <View style={{ gap: 10 }}>
                <EfficiencyRow
                  label="Possession"
                  value={performanceData.efficiency.possession}
                />
                <EfficiencyRow
                  label="Passing"
                  value={performanceData.efficiency.passing}
                />
                <EfficiencyRow
                  label="Decision Making"
                  value={performanceData.efficiency.decisionMaking}
                />
                <EfficiencyRow
                  label="Spatial Awareness"
                  value={performanceData.efficiency.spatial}
                />
              </View>
            )}
          </View>
        )}

        {/* Licensing */}
        <View
          style={{
            marginTop: 32,
            paddingTop: 24,
            borderTopWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 9 }}>
            BIM-APES Software licensed under Apache License, Version 2.0.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function MetricCard({ label, value }) {
  return (
    <View
      style={{
        backgroundColor: "#0f172a",
        padding: 14,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: "#334155",
      }}
    >
      <Text style={{ color: "#94a3b8", fontSize: 12, marginBottom: 4 }}>
        {label}
      </Text>
      <Text style={{ color: "#fff", fontSize: 20, fontWeight: "bold" }}>
        {value}
      </Text>
    </View>
  );
}

function EfficiencyRow({ label, value }) {
  const percentage = Math.min(100, Math.max(0, value));

  return (
    <View>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginBottom: 6,
        }}
      >
        <Text style={{ color: "#d1fae5", fontSize: 13 }}>{label}</Text>
        <Text style={{ color: "#fff", fontSize: 13, fontWeight: "600" }}>
          {percentage.toFixed(1)}%
        </Text>
      </View>
      <View style={{ height: 6, backgroundColor: "#1e293b", borderRadius: 3 }}>
        <View
          style={{
            height: 6,
            backgroundColor: "#10b981",
            borderRadius: 3,
            width: `${percentage}%`,
          }}
        />
      </View>
    </View>
  );
}
