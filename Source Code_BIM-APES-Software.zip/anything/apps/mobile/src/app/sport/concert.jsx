import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState } from "react";
import { Music, DollarSign, ArrowLeft } from "lucide-react-native";
import { useRouter } from "expo-router";
import useUser from "@/utils/auth/useUser";

export default function ConcertNILScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: user, loading: userLoading } = useUser();

  const [artistId, setArtistId] = useState("");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const [concertData] = useState({
    venueCapacity: 5000,
    ticketRevenue: 250000,
    songs: [
      {
        vocalClean: true,
        errors: false,
        duration: 240,
        verses: [{ clarity: 85, timing: 90, wpm: 120 }],
        hooks: [{ pitchAccuracy: 92, powerOutput: 88, crowdSing: 90 }],
        intensity: 85,
      },
      {
        vocalClean: true,
        errors: false,
        duration: 220,
        verses: [{ clarity: 88, timing: 88, wpm: 125 }],
        hooks: [{ pitchAccuracy: 90, powerOutput: 85, crowdSing: 88 }],
        intensity: 80,
      },
    ],
    crowdEngagement: [
      { level: 85, timestamp: Date.now() - 3600000 },
      { level: 92, timestamp: Date.now() - 3000000 },
    ],
    socialSpikes: [{ platform: "TikTok", growthRate: 150 }],
    technicalIssues: [],
  });

  const handleSubmit = async () => {
    if (!artistId) {
      setError("Please enter an artist ID");
      return;
    }

    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch("/api/music-nil/live-concert-performance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          artistId: parseInt(artistId),
          concertData,
          venueCapacity: concertData.venueCapacity,
          ticketRevenue: concertData.ticketRevenue,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to process concert performance");
      }

      const data = await response.json();
      setPerformanceData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (userLoading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0f172a",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <StatusBar style="light" />
        <ActivityIndicator size="large" color="#ec4899" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#831843" }}>
      <StatusBar style="light" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: insets.top + 20,
          paddingBottom: 20,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginBottom: 16 }}
        >
          <ArrowLeft color="#ec4899" size={28} />
        </TouchableOpacity>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            marginBottom: 8,
          }}
        >
          <Music color="#ec4899" size={36} />
          <Text style={{ fontSize: 28, fontWeight: "bold", color: "#fff" }}>
            Concert NIL
          </Text>
        </View>
        <Text style={{ fontSize: 14, color: "#fce7f3", marginBottom: 24 }}>
          Live Music Performance Valuation
        </Text>

        {/* Input Form */}
        <View
          style={{
            backgroundColor: "#1e293b",
            padding: 20,
            borderRadius: 16,
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "bold",
              color: "#fff",
              marginBottom: 16,
            }}
          >
            Concert Setup
          </Text>

          <Text style={{ color: "#94a3b8", fontSize: 13, marginBottom: 8 }}>
            Artist ID
          </Text>
          <TextInput
            value={artistId}
            onChangeText={setArtistId}
            placeholder="Enter artist ID"
            placeholderTextColor="#64748b"
            keyboardType="numeric"
            style={{
              backgroundColor: "#0f172a",
              color: "#fff",
              padding: 14,
              borderRadius: 8,
              borderWidth: 1,
              borderColor: "#334155",
              fontSize: 16,
              marginBottom: 16,
            }}
          />

          <View
            style={{
              backgroundColor: "#0f172a",
              padding: 14,
              borderRadius: 8,
              marginBottom: 16,
              borderWidth: 1,
              borderColor: "#334155",
            }}
          >
            <Text style={{ color: "#ec4899", fontSize: 12, marginBottom: 8 }}>
              Sample Data Loaded:
            </Text>
            <Text style={{ color: "#fff", fontSize: 12 }}>
              • {concertData.songs.length} songs in setlist
            </Text>
            <Text style={{ color: "#fff", fontSize: 12 }}>
              • {concertData.crowdEngagement.length} engagement checkpoints
            </Text>
            <Text style={{ color: "#fff", fontSize: 12 }}>
              • Venue capacity: {concertData.venueCapacity.toLocaleString()}
            </Text>
          </View>

          {error && (
            <View
              style={{
                backgroundColor: "#7f1d1d",
                padding: 14,
                borderRadius: 8,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#991b1b",
              }}
            >
              <Text style={{ color: "#fca5a5", fontSize: 13 }}>{error}</Text>
            </View>
          )}

          <TouchableOpacity
            onPress={handleSubmit}
            disabled={loadingData}
            style={{
              backgroundColor: loadingData ? "#475569" : "#ec4899",
              padding: 16,
              borderRadius: 12,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 16, fontWeight: "bold" }}>
              {loadingData ? "Processing..." : "Calculate NIL Value"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Results */}
        {performanceData && (
          <>
            <View
              style={{
                backgroundColor: "#1e293b",
                padding: 20,
                borderRadius: 16,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#334155",
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "bold",
                  color: "#fff",
                  marginBottom: 16,
                }}
              >
                Artist Performance Score (APS)
              </Text>

              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 12,
                }}
              >
                <Text style={{ color: "#fce7f3", fontSize: 16 }}>
                  Overall Score
                </Text>
                <Text
                  style={{ color: "#ec4899", fontSize: 40, fontWeight: "bold" }}
                >
                  {performanceData.artistPerformanceScore?.toFixed(1)}
                </Text>
              </View>

              <View
                style={{
                  height: 8,
                  backgroundColor: "#0f172a",
                  borderRadius: 4,
                  marginBottom: 12,
                }}
              >
                <View
                  style={{
                    height: 8,
                    backgroundColor: "#ec4899",
                    borderRadius: 4,
                    width: `${performanceData.artistPerformanceScore}%`,
                  }}
                />
              </View>

              <Text style={{ color: "#fce7f3", fontSize: 13 }}>
                Tier:{" "}
                <Text
                  style={{ fontWeight: "bold", textTransform: "uppercase" }}
                >
                  {performanceData.tier}
                </Text>
              </Text>
            </View>

            {/* NIL Valuation */}
            <View
              style={{
                backgroundColor: "#064e3b",
                padding: 20,
                borderRadius: 16,
                marginBottom: 16,
                borderWidth: 1,
                borderColor: "#10b981",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 8,
                  marginBottom: 16,
                }}
              >
                <DollarSign color="#10b981" size={24} />
                <Text
                  style={{ fontSize: 18, fontWeight: "bold", color: "#fff" }}
                >
                  Real-Time NIL Valuation
                </Text>
              </View>

              <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{ color: "#d1fae5", fontSize: 12, marginBottom: 4 }}
                  >
                    Base NIL Value
                  </Text>
                  <Text
                    style={{ color: "#fff", fontSize: 20, fontWeight: "bold" }}
                  >
                    ${performanceData.nilValuation?.baseValue.toLocaleString()}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{ color: "#d1fae5", fontSize: 12, marginBottom: 4 }}
                  >
                    Current NIL Value
                  </Text>
                  <Text
                    style={{
                      color: "#10b981",
                      fontSize: 20,
                      fontWeight: "bold",
                    }}
                  >
                    $
                    {performanceData.nilValuation?.currentValue.toLocaleString()}
                  </Text>
                </View>
              </View>

              <View
                style={{
                  borderTopWidth: 1,
                  borderColor: "#10b981",
                  paddingTop: 12,
                }}
              >
                <Text style={{ color: "#d1fae5", fontSize: 12 }}>
                  Change from Base:{" "}
                  <Text
                    style={{
                      fontWeight: "bold",
                      color:
                        performanceData.nilValuation?.changeFromBase >= 0
                          ? "#10b981"
                          : "#ef4444",
                    }}
                  >
                    {performanceData.nilValuation?.changeFromBase >= 0
                      ? "+"
                      : ""}
                    {performanceData.nilValuation?.changeFromBase}%
                  </Text>
                </Text>
              </View>
            </View>

            {/* Performance Metrics */}
            <View
              style={{
                backgroundColor: "#1e293b",
                padding: 20,
                borderRadius: 16,
                borderWidth: 1,
                borderColor: "#334155",
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "bold",
                  color: "#fff",
                  marginBottom: 12,
                }}
              >
                Song Metrics
              </Text>
              <View style={{ gap: 8 }}>
                <MetricRow
                  label="Song Accuracy"
                  value={`${performanceData.performanceMetrics?.songMetrics.songAccuracy.toFixed(1)}%`}
                />
                <MetricRow
                  label="Total Songs"
                  value={
                    performanceData.performanceMetrics?.songMetrics.totalSongs
                  }
                />
                <MetricRow
                  label="Avg Engagement"
                  value={`${performanceData.performanceMetrics?.crowdMetrics.averageEngagement.toFixed(1)}%`}
                />
              </View>
            </View>
          </>
        )}

        {/* Licensing */}
        <View
          style={{
            marginTop: 32,
            paddingTop: 24,
            borderTopWidth: 1,
            borderColor: "#334155",
          }}
        >
          <Text style={{ color: "#64748b", fontSize: 10, marginBottom: 6 }}>
            © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.
          </Text>
          <Text style={{ color: "#64748b", fontSize: 9 }}>
            BIM-APES Software licensed under Apache License, Version 2.0.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function MetricRow({ label, value }) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <Text style={{ color: "#94a3b8", fontSize: 13 }}>{label}</Text>
      <Text style={{ color: "#fff", fontSize: 13, fontWeight: "600" }}>
        {value}
      </Text>
    </View>
  );
}
