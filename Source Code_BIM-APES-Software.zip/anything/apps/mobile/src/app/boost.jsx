import { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  TrendingUp,
  Zap,
  DollarSign,
  Bitcoin,
  Award,
  Lock,
  Unlock,
} from "lucide-react-native";
import useUser from "@/utils/auth/useUser";

export default function BoostScreen() {
  const insets = useSafeAreaInsets();
  const { data: user, loading: userLoading } = useUser();

  const [boostBalance, setBoostBalance] = useState(0);
  const [currentTier, setCurrentTier] = useState("tier_1");
  const [featuredAthletes, setFeaturedAthletes] = useState([]);
  const [tenantConfig, setTenantConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [boosting, setBoosting] = useState(null);

  useEffect(() => {
    if (user?.id) {
      loadBoostData();
    }
  }, [user]);

  const loadBoostData = async () => {
    try {
      setLoading(true);

      // Load tenant configuration
      const configRes = await fetch("/api/boost/config");
      const config = await configRes.json();
      setTenantConfig(config);

      // Load user boost balance
      const balanceRes = await fetch(`/api/boost/balance?userId=${user.id}`);
      const balanceData = await balanceRes.json();
      setBoostBalance(balanceData.boostCredits || 0);
      setCurrentTier(balanceData.currentTier || "tier_1");

      // Load featured athletes
      const athletesRes = await fetch("/api/boost/featured-athletes");
      const athletes = await athletesRes.json();
      setFeaturedAthletes(athletes);
    } catch (error) {
      console.error("Error loading boost data:", error);
      Alert.alert("Error", "Failed to load boost data");
    } finally {
      setLoading(false);
    }
  };

  const handleBoost = async (athlete) => {
    if (!user?.id) {
      Alert.alert("Sign In Required", "Please sign in to boost athletes");
      return;
    }

    setBoosting(athlete.id);

    try {
      const layer = tenantConfig?.engagement_layer || "free";

      if (layer === "free") {
        // Free tier - just award points
        const res = await fetch("/api/boost/tap", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fanId: user.id,
            athleteId: athlete.id,
            paymentLayer: "free",
          }),
        });

        if (!res.ok) throw new Error("Boost failed");

        const result = await res.json();
        setBoostBalance(result.newBalance);
        setCurrentTier(result.currentTier);

        Alert.alert(
          "⚡ Boost Sent!",
          `+${result.boostCreditsEarned} Boost Credits\nNew Balance: ${result.newBalance}`,
          [{ text: "Nice!", style: "default" }],
        );
      } else if (layer === "crypto") {
        // Crypto tier - would integrate wallet
        Alert.alert("Crypto Payment", "Wallet integration coming soon");
      } else if (layer === "fiat") {
        // Fiat tier - would integrate Stripe
        Alert.alert("Card Payment", "Stripe integration coming soon");
      }
    } catch (error) {
      console.error("Boost error:", error);
      Alert.alert("Error", "Failed to send boost. Please try again.");
    } finally {
      setBoosting(null);
    }
  };

  const getTierInfo = (tier) => {
    const tiers = {
      tier_1: { name: "Bronze", color: "#CD7F32", nextAt: 100 },
      tier_2: { name: "Silver", color: "#C0C0C0", nextAt: 500 },
      tier_3: { name: "Gold", color: "#FFD700", nextAt: 2000 },
      vault: { name: "Vault", color: "#9333EA", nextAt: null },
    };
    return tiers[tier] || tiers.tier_1;
  };

  const getLayerBadge = () => {
    if (!tenantConfig) return null;

    const layer = tenantConfig.engagement_layer;
    const badges = {
      free: { icon: Zap, color: "#10B981", text: "Free Boost" },
      crypto: { icon: Bitcoin, color: "#F59E0B", text: "Crypto Boost" },
      fiat: { icon: DollarSign, color: "#3B82F6", text: "USD Boost" },
    };

    return badges[layer] || badges.free;
  };

  if (userLoading || loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0A0A0A",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color="#10B981" />
        <Text style={{ color: "#9CA3AF", marginTop: 16 }}>
          Loading boost data...
        </Text>
        <StatusBar style="light" />
      </View>
    );
  }

  if (!user) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0A0A0A",
          justifyContent: "center",
          alignItems: "center",
          padding: 20,
        }}
      >
        <Lock size={64} color="#6B7280" />
        <Text
          style={{
            color: "#F3F4F6",
            fontSize: 20,
            fontWeight: "700",
            marginTop: 20,
            textAlign: "center",
          }}
        >
          Sign In to Boost Athletes
        </Text>
        <Text
          style={{
            color: "#9CA3AF",
            fontSize: 14,
            marginTop: 8,
            textAlign: "center",
          }}
        >
          Connect to start earning Boost Credits and supporting athletes
        </Text>
        <StatusBar style="light" />
      </View>
    );
  }

  const tierInfo = getTierInfo(currentTier);
  const layerBadge = getLayerBadge();
  const LayerIcon = layerBadge?.icon;

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0A0A" }}>
      <StatusBar style="light" />

      {/* Header with Balance */}
      <View
        style={{
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 20,
          backgroundColor: "#111827",
          borderBottomWidth: 1,
          borderBottomColor: "#1F2937",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View>
            <Text style={{ color: "#9CA3AF", fontSize: 12, fontWeight: "600" }}>
              BOOST CREDITS
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "baseline",
                marginTop: 4,
              }}
            >
              <Text
                style={{ color: "#F3F4F6", fontSize: 36, fontWeight: "800" }}
              >
                {boostBalance}
              </Text>
              <Text
                style={{
                  color: "#6B7280",
                  fontSize: 16,
                  fontWeight: "600",
                  marginLeft: 8,
                }}
              >
                pts
              </Text>
            </View>
          </View>

          <View style={{ alignItems: "flex-end" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: tierInfo.color + "20",
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 12,
              }}
            >
              <Award size={16} color={tierInfo.color} />
              <Text
                style={{
                  color: tierInfo.color,
                  fontSize: 14,
                  fontWeight: "700",
                  marginLeft: 6,
                }}
              >
                {tierInfo.name}
              </Text>
            </View>
            {tierInfo.nextAt && (
              <Text style={{ color: "#6B7280", fontSize: 11, marginTop: 4 }}>
                {tierInfo.nextAt - boostBalance} to next tier
              </Text>
            )}
          </View>
        </View>

        {/* Layer Badge */}
        {layerBadge && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: layerBadge.color + "15",
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderRadius: 8,
              marginTop: 16,
            }}
          >
            <LayerIcon size={18} color={layerBadge.color} />
            <Text
              style={{
                color: layerBadge.color,
                fontSize: 13,
                fontWeight: "600",
                marginLeft: 8,
              }}
            >
              {layerBadge.text}
            </Text>
            {tenantConfig?.engagement_layer === "fiat" && (
              <Text style={{ color: "#9CA3AF", fontSize: 12, marginLeft: 8 }}>
                • ${tenantConfig.boost_cost || "0.10"} per boost
              </Text>
            )}
            {tenantConfig?.engagement_layer === "crypto" && (
              <Text style={{ color: "#9CA3AF", fontSize: 12, marginLeft: 8 }}>
                • {tenantConfig.boost_cost || "0.00001"} ETH per boost
              </Text>
            )}
          </View>
        )}
      </View>

      {/* Featured Athletes */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ padding: 20 }}>
          <Text
            style={{
              color: "#F3F4F6",
              fontSize: 18,
              fontWeight: "700",
              marginBottom: 16,
            }}
          >
            🔥 Featured Athletes
          </Text>

          {featuredAthletes.map((athlete) => (
            <View
              key={athlete.id}
              style={{
                backgroundColor: "#111827",
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: "#1F2937",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                }}
              >
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      color: "#F3F4F6",
                      fontSize: 16,
                      fontWeight: "700",
                    }}
                  >
                    {athlete.name}
                  </Text>
                  <Text
                    style={{ color: "#9CA3AF", fontSize: 13, marginTop: 2 }}
                  >
                    {athlete.sport} • {athlete.position}
                  </Text>

                  {athlete.recentMilestone && (
                    <View
                      style={{
                        backgroundColor: "#10B98120",
                        paddingHorizontal: 10,
                        paddingVertical: 4,
                        borderRadius: 6,
                        marginTop: 8,
                        alignSelf: "flex-start",
                      }}
                    >
                      <Text
                        style={{
                          color: "#10B981",
                          fontSize: 11,
                          fontWeight: "600",
                        }}
                      >
                        🎯 {athlete.recentMilestone}
                      </Text>
                    </View>
                  )}

                  <View
                    style={{ flexDirection: "row", marginTop: 12, gap: 16 }}
                  >
                    <View>
                      <Text style={{ color: "#6B7280", fontSize: 11 }}>
                        Total Boosts
                      </Text>
                      <Text
                        style={{
                          color: "#F3F4F6",
                          fontSize: 15,
                          fontWeight: "700",
                          marginTop: 2,
                        }}
                      >
                        {athlete.totalBoosts || 0}
                      </Text>
                    </View>
                    <View>
                      <Text style={{ color: "#6B7280", fontSize: 11 }}>
                        BIM Score
                      </Text>
                      <Text
                        style={{
                          color: "#10B981",
                          fontSize: 15,
                          fontWeight: "700",
                          marginTop: 2,
                        }}
                      >
                        {athlete.bimScore || "N/A"}
                      </Text>
                    </View>
                  </View>
                </View>

                <TouchableOpacity
                  onPress={() => handleBoost(athlete)}
                  disabled={boosting === athlete.id}
                  style={{
                    backgroundColor:
                      boosting === athlete.id ? "#374151" : "#10B981",
                    paddingHorizontal: 20,
                    paddingVertical: 12,
                    borderRadius: 12,
                    marginLeft: 12,
                    minWidth: 100,
                    alignItems: "center",
                  }}
                >
                  {boosting === athlete.id ? (
                    <ActivityIndicator size="small" color="#9CA3AF" />
                  ) : (
                    <>
                      <Zap size={20} color="#FFFFFF" fill="#FFFFFF" />
                      <Text
                        style={{
                          color: "#FFFFFF",
                          fontSize: 13,
                          fontWeight: "700",
                          marginTop: 4,
                        }}
                      >
                        BOOST
                      </Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          ))}

          {featuredAthletes.length === 0 && (
            <View style={{ alignItems: "center", paddingVertical: 40 }}>
              <TrendingUp size={48} color="#374151" />
              <Text
                style={{
                  color: "#6B7280",
                  fontSize: 14,
                  marginTop: 12,
                  textAlign: "center",
                }}
              >
                No featured athletes yet.{"\n"}Check back soon!
              </Text>
            </View>
          )}
        </View>

        {/* Tier Progression Info */}
        <View style={{ paddingHorizontal: 20, marginTop: 12 }}>
          <Text
            style={{
              color: "#F3F4F6",
              fontSize: 16,
              fontWeight: "700",
              marginBottom: 12,
            }}
          >
            🏆 Tier Benefits
          </Text>

          <View
            style={{
              backgroundColor: "#111827",
              borderRadius: 12,
              padding: 16,
              borderWidth: 1,
              borderColor: "#1F2937",
            }}
          >
            <TierBenefitRow
              tier="Bronze"
              unlocked={true}
              benefit="Basic metadata access"
            />
            <TierBenefitRow
              tier="Silver"
              unlocked={
                currentTier === "tier_2" ||
                currentTier === "tier_3" ||
                currentTier === "vault"
              }
              benefit="Enhanced insights + 1.5x multiplier"
            />
            <TierBenefitRow
              tier="Gold"
              unlocked={currentTier === "tier_3" || currentTier === "vault"}
              benefit="Premium content + 2x multiplier"
            />
            <TierBenefitRow
              tier="Vault"
              unlocked={currentTier === "vault"}
              benefit="Exclusive access + 3x multiplier"
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function TierBenefitRow({ tier, unlocked, benefit }) {
  const Icon = unlocked ? Unlock : Lock;
  const color = unlocked ? "#10B981" : "#6B7280";

  return (
    <View
      style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}
    >
      <Icon size={16} color={color} />
      <Text
        style={{
          color: unlocked ? "#F3F4F6" : "#6B7280",
          fontSize: 13,
          marginLeft: 10,
          fontWeight: "600",
        }}
      >
        {tier}:
      </Text>
      <Text style={{ color: "#9CA3AF", fontSize: 13, marginLeft: 6, flex: 1 }}>
        {benefit}
      </Text>
    </View>
  );
}
