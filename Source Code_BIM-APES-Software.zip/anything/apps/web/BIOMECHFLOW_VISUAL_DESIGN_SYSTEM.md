# 🎨 BiomechFlow Capsule — Visual Design System
### **Designer-Ready Specification for AR/3D Overlays**

**Version:** 1.0  
**Last Updated:** March 14, 2026  
**Classification:** Production Visual Spec  
**Maintained By:** PhysiobioFIN Design Team

---

## **📋 EXECUTIVE SUMMARY**

The **BiomechFlow Capsule** is a real-time biomechanical intelligence visualization system designed for:
- **AR overlays** during live sports events
- **3D spatial environments** in training facilities
- **Broadcast graphics** for TV/streaming
- **Mobile coach dashboards** for sideline decisions
- **NIL valuation interfaces** for sponsor activations

This document provides the complete visual specification for designers, motion graphics artists, and 3D modelers.

---

## **🎨 1. COLOR SYSTEM (MASTER PALETTE)**

All colors use a **tri-tier intensity system** optimized for:
- AR headsets (HoloLens, Magic Leap, Apple Vision Pro)
- Low-light arenas (basketball courts, wrestling mats)
- Broadcast overlays (ESPN, TNT, NBC Sports)
- Mobile screens (iOS, Android)

### **1.1 Fatigue Gradient (Bottom Arc)**

| State | Color Name | Hex | RGB | Usage Notes |
|-------|------------|-----|-----|-------------|
| **Low Fatigue** | Fresh Green | `#3CFF7A` | `60, 255, 122` | High visibility, signals readiness, safe for play |
| **Moderate Fatigue** | Caution Yellow | `#FFD93C` | `255, 217, 60` | Load management window, monitor closely |
| **High Fatigue** | Risk Red | `#FF3C3C` | `255, 60, 60` | Triggers substitution & medical alert protocols |

**Gradient Behavior:**
- Direction: **Left → Right**
- Transition Speed: **0.4s ease-in**
- High Fatigue Pulse: **1.2 Hz red edge pulse**

---

### **1.2 Stress Load (Top Arc)**

| State | Color Name | Hex | RGB | Notes |
|-------|------------|-----|-----|-------|
| **Low Stress** | Cool Blue | `#4DA6FF` | `77, 166, 255` | Thin arc (2-3px), low torque/impact |
| **Moderate Stress** | Steel Blue | `#1E5FA8` | `30, 95, 168` | Medium arc (4-6px), moderate load |
| **High Stress** | Deep Navy | `#002B66` | `0, 43, 102` | Thick arc (7-10px), high collision load |

**Animation Behavior:**
- **High Stress:** Micro-shake (0.3px jitter), darkens on impact, expands 5% on collision
- **Moderate Stress:** Static
- **Low Stress:** Slight blue glow

---

### **1.3 NIL Momentum (Glow Ring)**

| State | Color Name | Hex | RGB | Glow Intensity |
|-------|------------|-----|-----|----------------|
| **High Momentum** | Electric Gold | `#FFCC33` | `255, 204, 51` | 150–200% bloom |
| **Neutral** | Soft White | `#F2F2F2` | `242, 242, 242` | 80–100% bloom |
| **Low Momentum** | Dim Grey | `#6B6B6B` | `107, 107, 107` | 20–40% bloom |

**Pulse Frequencies:**
- **High:** 1.5 Hz (rapid pulse)
- **Neutral:** 0.5 Hz (slow pulse)
- **Low:** 0 Hz (no pulse)

**Special Modes:**
- **Clutch Mode:** Gold/White strobe at 2 Hz
- **Elimination Mode:** Red/Gold alternating pulse at 1.5 Hz

---

### **1.4 Injury-Risk Premium (Right Bar)**

| State | Color Name | Hex | RGB | Notes |
|-------|------------|-----|-----|-------|
| **Low Risk** | Aqua | `#33FFF3` | `51, 255, 243` | Minimal NIL drag, safe for full load |
| **Medium Risk** | Orange | `#FF8C33` | `255, 140, 51` | Manage exposure, monitor trends |
| **High Risk** | Crimson | `#D90000` | `217, 0, 0` | Hedge-fund trigger, consider insurance |

---

## **📏 2. THICKNESS, HEIGHT & SLOPE SPECIFICATIONS**

### **2.1 Top Arc (Stress Load) Thickness**

| State | Pixel Thickness | AR Scaling Factor | Use Case |
|-------|-----------------|-------------------|----------|
| **Low** | 2–3 px | 1.0× | Recovery sessions, light training |
| **Moderate** | 4–6 px | 1.25× | Normal game load |
| **High** | 7–10 px | 1.5× | High-impact collisions, playoff games |

---

### **2.2 Bottom Arc (Fatigue) Gradient Rules**

- **Gradient Direction:** Left → Right
- **Transition Speed:** 0.4s ease-in
- **High Fatigue Pulse:** 1.2 Hz frequency with red edge
- **Gradient Stops:**
  - `0%`: Color + 40% opacity
  - `50%`: Color at full opacity
  - `100%`: Color + 40% opacity

---

### **2.3 Center Line (Recovery Velocity) Slope**

| State | Angle Range | Animation | Meaning |
|-------|-------------|-----------|---------|
| **Positive** | +15° to +45° | Upward sweep (0.8s) | Fast recovery, ready to play |
| **Neutral** | 0° | Static | Stable recovery rate |
| **Negative** | –15° to –45° | Downward sweep (0.8s) | Delayed recovery, monitor closely |

**Trail Effect:**
- **Positive Recovery:** 20% opacity white trail
- **Negative Recovery:** 20% opacity red trail
- **Neutral:** No trail

---

### **2.4 Left & Right Bars (Sub Probability & Injury Risk)**

| Height Level | Pixel Height | Motion | Trigger Threshold |
|--------------|---------------|---------|-------------------|
| **Low** | 10–20 px | Static | 0-40% |
| **Medium** | 25–40 px | Soft pulse (0.5 Hz) | 40-70% |
| **High** | 45–60 px | Hard pulse (1 Hz) | 70-100% |

---

## **🎬 3. ANIMATION CUES (MOTION LANGUAGE)**

These cues define capsule behavior in **live AR overlays**, **3D spatial environments**, and **broadcast graphics**.

### **3.1 Glow Ring (NIL Momentum) Animations**

#### **High Momentum State**
```
Bloom: 200%
Pulse: 1.5 Hz
Color Shift: Gold → White micro-flicker (subtle, 2-3 Hz)
Trigger: NIL acceleration, sponsor activation window
```

#### **Neutral State**
```
Bloom: 100%
Pulse: 0.5 Hz
Color: Soft White (#F2F2F2)
```

#### **Low Momentum State**
```
Bloom: 40%
Pulse: None
Color: Dim Grey (#6B6B6B)
```

---

### **3.2 Stress Load Arc Animations**

#### **High Stress**
```
Effect: Micro-shake (0.3px jitter)
Darkening: On impact events (10% opacity drop for 0.2s)
Expansion: 5% radial expansion on collision detection
```

#### **Moderate Stress**
```
Effect: Static (no animation)
```

#### **Low Stress**
```
Effect: Slight blue glow (20% emission)
```

---

### **3.3 Fatigue Arc Animations**

#### **High Fatigue (>70%)**
```
Effect: Red pulse at 1 Hz
Gradient Ripple: Outward ripple effect
Opacity Range: 30-70% (pulsing)
```

#### **Moderate Fatigue (40-70%)**
```
Effect: Yellow steady glow
No pulse
```

#### **Low Fatigue (<40%)**
```
Effect: None (static green gradient)
```

---

### **3.4 Recovery Line Animations**

#### **Positive Slope**
```
Animation: Upward sweep (0.8s duration)
Trail: 20% opacity white trail
Easing: ease-out
```

#### **Negative Slope**
```
Animation: Downward sweep (0.8s duration)
Trail: 20% opacity red trail
Easing: ease-in
```

#### **Neutral**
```
Animation: Static (no movement)
```

---

## **🌐 4. AR/3D SPATIAL BEHAVIOR**

### **4.1 Capsule Placement Rules**

**Anchor Points:**
- **Player Torso:** Primary anchor for full-body capsules
- **Joint Clusters:** Secondary anchors for localized capsules
- **Spatial Offset:** 0.1m above joint position to avoid occlusion

**Auto-Scaling Based on Distance:**
| Distance | Scale Factor | Use Case |
|----------|--------------|----------|
| 3–5 ft | 1.0× | Courtside, sideline, close coaching |
| 10–15 ft | 1.5× | Mid-court, player bench |
| 20+ ft | 2.0× | Broadcast mode, arena screens |

---

### **4.2 Environmental Adaptation**

**Lighting Adaptation:**
```javascript
if (arenaLightingLevel < 30%) {
  capsuleBrightness *= 1.5;
  glowBloom *= 1.3;
}
```

**Occlusion Awareness:**
- Capsule fades to 30% opacity when **player/ref/object** passes between capsule and camera
- Full opacity restored within 0.3s after occlusion clears

**Depth-Aware Rotation:**
- Capsule rotates **±15°** to match camera angle
- Ensures readability from any viewing angle

---

### **4.3 Interaction Rules**

#### **Tap Interaction**
```
Action: Tap capsule
Result: Expands to full metrics panel
Animation: 0.3s scale-up to 1.5×
Panel Contents:
  - Stress Load: 75%
  - Fatigue: 60%
  - NIL Momentum: 85%
  - Recovery Velocity: +15
  - Sub Probability: 25%
  - Injury Risk: 65%
```

#### **Hover Interaction** (Desktop/Web)
```
Action: Hover cursor over capsule
Result: Highlight component (glow ring emphasized)
Animation: 0.2s glow bloom increase to 150%
```

#### **Gaze Interaction** (AR Headsets)
```
Action: Gaze focus for 1.5s
Result: Same as tap interaction
```

---

### **4.4 Critical Event Triggers**

| Event Type | Visual Effect | Duration | Trigger Condition |
|------------|---------------|----------|-------------------|
| **Injury Risk Alert** | Red flash | 0.2s | Injury Risk > 85% |
| **NIL Surge** | Gold flash | 0.2s | NIL Momentum increases >15% in 30s |
| **Recovery Spike** | Blue flash | 0.2s | Recovery Velocity shifts from negative to +20 |

---

## **📦 5. TREND CAPSULE VISUAL PACKAGES**

### **5.1 Uptrend Capsule (Bull Package)**

**Use Case:** Athlete performing above baseline, NIL accelerating

```yaml
Glow Ring:
  Color: Electric Gold (#FFCC33)
  Bloom: 200%
  Pulse: 1.5 Hz
  Effect: Upward sweep + gold pulse

Stress Arc:
  Color: Cool Blue (#4DA6FF)
  Thickness: Thin (2-3px)

Fatigue Arc:
  Color: Fresh Green (#3CFF7A)
  Pulse: None

Recovery Line:
  Slope: +35° (positive)
  Animation: Upward sweep
  Trail: White

Bars:
  Sub Probability: Low (10-20px)
  Injury Risk: Low (10-20px)
```

---

### **5.2 Downtrend Capsule (Bear Package)**

**Use Case:** Athlete underperforming, fatigue accumulating

```yaml
Glow Ring:
  Color: Dim Grey (#6B6B6B)
  Bloom: 40%
  Pulse: None

Stress Arc:
  Color: Deep Navy (#002B66)
  Thickness: Thick (7-10px)

Fatigue Arc:
  Color: Risk Red (#FF3C3C)
  Pulse: 1 Hz red pulse

Recovery Line:
  Slope: -35° (negative)
  Animation: Downward sweep
  Trail: Red

Bars:
  Sub Probability: High (45-60px, pulsing)
  Injury Risk: High (45-60px, pulsing)
```

---

### **5.3 Sideways Capsule (Neutral Package)**

**Use Case:** Baseline performance, no significant change

```yaml
Glow Ring:
  Color: Soft White (#F2F2F2)
  Bloom: 100%
  Pulse: 0.5 Hz

Stress Arc:
  Color: Steel Blue (#1E5FA8)
  Thickness: Medium (4-6px)

Fatigue Arc:
  Color: Caution Yellow (#FFD93C)
  Pulse: None

Recovery Line:
  Slope: 0° (flat)
  Animation: Static

Bars:
  Sub Probability: Medium (25-40px)
  Injury Risk: Medium (25-40px)
```

---

## **🏀 6. PLAYOFF CAPSULE VISUAL ENHANCEMENTS**

### **6.1 Clutch Capsule (NBA Postseason Mode)**

**Use Case:** Final minutes of close playoff game

```yaml
Glow Ring:
  Color: Gold/White strobe
  Bloom: 200%
  Pulse: 2 Hz (rapid)
  Pattern: Alternates Gold → White every 0.5s

Stress Arc:
  Color: Deep Navy (#002B66)
  Thickness: Thick (7-10px)

Fatigue Arc:
  Color: Risk Red (#FF3C3C)
  Pulse: 1 Hz

Recovery Line:
  Slope: +25° (positive but stressed)

Bars:
  Sub Probability: Low (20px) – player staying in
  Injury Risk: High (45px) – high physical cost
```

---

### **6.2 Elimination Capsule (Do-or-Die Moments)**

**Use Case:** Elimination game, must-win scenario

```yaml
Glow Ring:
  Color: Red/Gold alternating
  Bloom: 200%
  Pulse: 1.5 Hz
  Pattern: Red → Gold → Red (2/3s cycle)

Stress Arc:
  Color: Deep Navy (#002B66)
  Thickness: Max (10px)

Fatigue Arc:
  Color: Deep Red (#D90000)
  Pulse: 1.2 Hz

Recovery Line:
  Slope: -25° (negative – cumulative fatigue)

Bars:
  Sub Probability: Max (60px) – high sub risk
  Injury Risk: Max (60px) – critical risk
```

---

### **6.3 Momentum Swing Capsule (Run/Burst Events)**

**Use Case:** 10-0 run, game-changing sequence

```yaml
Glow Ring:
  Color: Electric Gold (#FFCC33)
  Bloom: 200%
  Effect: Gold burst animation (radial pulse outward)

Recovery Line:
  Slope: Sharp positive (+40°)
  Animation: Rapid upward sweep (0.5s)

Fatigue Arc:
  Color: Green → Yellow ripple
  Effect: Color transition wave (left to right, 1s)
```

---

## **🖥️ 7. EXPORT-READY DESIGNER NOTES**

### **7.1 File Types for Production**

| Use Case | File Format | Software | Notes |
|----------|-------------|----------|-------|
| **Vector Graphics** | SVG | Illustrator, Figma | Arcs, bars, rings |
| **3D AR Overlays** | GLB / FBX | Blender, Maya, Cinema 4D | Full capsule mesh |
| **Motion Graphics** | After Effects | After Effects | Animation presets |
| **Mobile/Web** | Lottie JSON | Bodymovin | Lightweight animations |
| **Game Engines** | Unity Prefab | Unity | Real-time AR integration |
| **Broadcast** | MOV (ProRes) | After Effects, Premiere | Broadcast overlays |

---

### **7.2 Layer Structure (AE/Figma/Blender)**

**Recommended Layer Hierarchy:**
```
1. Glow Ring (top layer, blend mode: Add)
2. Stress Arc (stroke layer)
3. Fatigue Arc (stroke layer with gradient)
4. Recovery Line (vector line with trail mask)
5. Left Bar (shape layer)
6. Right Bar (shape layer)
7. Data Labels (optional, text layers)
```

---

### **7.3 Animation Timing Standards**

| Animation Type | Duration | Easing | FPS |
|----------------|----------|--------|-----|
| **Pulse animations** | 0.66–2.0s (0.5–1.5 Hz) | ease-in-out | 60 |
| **Sweep animations** | 0.6–1.0s | ease-out | 60 |
| **Impact flashes** | 0.2s | linear | 60 |
| **State transitions** | 0.4s | ease-in | 60 |

---

## **📱 8. PLATFORM-SPECIFIC IMPLEMENTATIONS**

### **8.1 Web (React + Canvas)**

**Component:** `/apps/web/src/components/BiomechFlowCapsule/BiomechFlowCapsule.jsx`

**Features:**
- Real-time Canvas 2D rendering
- Automatic DPR scaling
- Interactive hover tooltips
- Click to expand metrics
- Responsive sizing (small/medium/large/broadcast)

**Usage:**
```jsx
import BiomechFlowCapsule, { CAPSULE_MODES } from '@/components/BiomechFlowCapsule/BiomechFlowCapsule';

<BiomechFlowCapsule
  mode={CAPSULE_MODES.UPTREND}
  size="large"
  interactive={true}
  onTap={(data) => console.log(data)}
/>
```

---

### **8.2 3D Skeleton Renderer (Three.js)**

**Component:** `/apps/web/src/components/BiomechFlowCapsule/ThreeDSkeletonRenderer.jsx`

**Features:**
- Full biomechanical skeleton (15 joints, 14 bones)
- Real-time capsule overlays at joint positions
- Auto-rotation mode
- Highlight joints on demand
- Custom lighting for depth perception

**Usage:**
```jsx
import ThreeDSkeletonRenderer from '@/components/BiomechFlowCapsule/ThreeDSkeletonRenderer';

<ThreeDSkeletonRenderer
  jointData={JOINT_POSITIONS}
  capsuleData={{
    shoulderRight: { injuryRisk: 75, fatigue: 60, nilMomentum: 85 },
    kneeLeft: { injuryRisk: 80, fatigue: 80, nilMomentum: 70 },
  }}
  highlightJoints={['shoulderRight', 'kneeLeft']}
  showCapsules={true}
  autoRotate={true}
  width={600}
  height={800}
/>
```

---

### **8.3 AR Viewer Dashboard**

**Page:** `/ar-biomech-viewer`

**Modes:**
1. **Capsule Gallery** – View all preset modes side-by-side
2. **3D Skeleton** – Full body visualization with capsule overlays
3. **Coach Comparison** – Side-by-side athlete comparison

**Access:** Requires authentication  
**URL:** `https://your-domain.com/ar-biomech-viewer`

---

## **🎯 9. USE CASE SCENARIOS**

### **9.1 Courtside Coaching (Live Game)**

**Setup:**
- Coach iPad with AR overlay app
- Live capsule feed from wearable mesh network
- Real-time injury risk monitoring

**Capsule Behavior:**
- Auto-updates every 2 seconds
- Flashes red when injury risk > 85%
- Triggers substitution recommendation notification

---

### **9.2 Broadcast Integration (ESPN/TNT)**

**Setup:**
- Broadcast control room with capsule feed
- Overlay renderer synced to camera feed
- Commentator-triggered capsule display

**Capsule Behavior:**
- Scales to 2.0× for arena screens
- Simplified labels for TV readability
- Auto-hides during critical game moments (to avoid distraction)

---

### **9.3 Training Facility Review**

**Setup:**
- Large wall-mounted display
- Post-practice review session
- Multi-athlete comparison mode

**Capsule Behavior:**
- Static display (no animations)
- Full metric labels visible
- Export to PDF for athlete reports

---

## **📊 10. ACCESSIBILITY & READABILITY**

### **10.1 Color Blindness Considerations**

| Type | Affected Colors | Mitigation |
|------|-----------------|------------|
| **Protanopia** | Red/Green distinction | Use brightness + thickness as secondary cue |
| **Deuteranopia** | Red/Green distinction | Same as above |
| **Tritanopia** | Blue/Yellow distinction | Rely on position (top arc vs bottom arc) |

---

### **10.2 Contrast Ratios (WCAG AA)**

| Element | Background | Contrast Ratio | Pass/Fail |
|---------|------------|----------------|-----------|
| **Glow Ring (Gold)** | Dark Arena | 7.2:1 | ✅ AAA |
| **Stress Arc (Blue)** | Dark Arena | 4.8:1 | ✅ AA |
| **Fatigue Arc (Red)** | Dark Arena | 6.1:1 | ✅ AAA |

---

## **🚀 11. DEPLOYMENT CHECKLIST**

### **For Designers Implementing BiomechFlow:**

- [ ] Import color palette into design system
- [ ] Create capsule component library (Figma/Sketch)
- [ ] Build animation presets (After Effects)
- [ ] Export Lottie JSON files for web/mobile
- [ ] Create 3D capsule mesh (Blender/Maya)
- [ ] Test AR rendering on target devices
- [ ] Validate color contrast ratios
- [ ] Document component API for developers
- [ ] Create style guide for brand consistency
- [ ] Set up version control for assets

---

## **📚 12. REFERENCE MATERIALS**

### **12.1 Code Implementations**

| Component | Path | Language |
|-----------|------|----------|
| BiomechFlow Capsule | `/apps/web/src/components/BiomechFlowCapsule/BiomechFlowCapsule.jsx` | React + Canvas |
| 3D Skeleton Renderer | `/apps/web/src/components/BiomechFlowCapsule/ThreeDSkeletonRenderer.jsx` | React + Three.js |
| AR Viewer Dashboard | `/apps/web/src/app/ar-biomech-viewer/page.jsx` | React |

### **12.2 Design Assets**

**Available on Request:**
- Figma component library
- After Effects animation templates
- Blender 3D capsule meshes
- Unity AR integration package
- SVG icon set (all capsule states)

---

## **✅ 13. PRODUCTION STATUS**

### **✅ Completed**
- [x] Color system defined
- [x] Animation specifications documented
- [x] React + Canvas implementation
- [x] Three.js 3D skeleton renderer
- [x] AR viewer dashboard
- [x] Mode presets (uptrend, downtrend, clutch, etc.)
- [x] Interactive hover/tap functionality
- [x] Auto-scaling for distance
- [x] Environmental adaptation logic

### **🔄 In Progress**
- [ ] After Effects animation templates
- [ ] Blender 3D mesh exports
- [ ] Unity AR integration package
- [ ] iOS/Android native renderers

### **📋 Planned**
- [ ] Machine learning capsule prediction
- [ ] Multi-athlete AR overlay (5+ players simultaneously)
- [ ] Custom brand color themes
- [ ] Sponsor logo integration in glow ring

---

## **🎬 14. EXAMPLE USE CASES**

### **Basketball – NBA Playoff Game**

**Scenario:** LeBron James in final 2 minutes, Lakers down 2 points

**Capsule State:**
- **Mode:** Clutch
- **Glow Ring:** Gold/White strobe (2 Hz)
- **Stress Load:** 85% (thick navy arc)
- **Fatigue:** 75% (red pulsing arc)
- **Recovery:** +25 (positive slope, still recovering)
- **Injury Risk:** 80% (high orange bar, pulsing)

**Coach Decision:** Keep in game but monitor closely. Have backup ready.

---

### **Wrestling – NCAA Championship Match**

**Scenario:** Wrestler in 3rd period, tied score, 1 minute remaining

**Capsule State:**
- **Mode:** Elimination
- **Glow Ring:** Red/Gold alternating
- **Stress Load:** 95% (max thickness)
- **Fatigue:** 95% (deep red, rapid pulse)
- **Recovery:** -25 (negative slope, delayed recovery)
- **Injury Risk:** 95% (crimson, max height)

**Coach Decision:** High risk, but must finish match. Medical team on standby.

---

### **Tennis – Grand Slam Final**

**Scenario:** 5th set tiebreak, championship point

**Capsule State:**
- **Mode:** Clutch
- **Glow Ring:** Electric Gold (200% bloom)
- **Stress Load:** 70% (medium arc)
- **Fatigue:** 80% (yellow/red gradient)
- **Recovery:** +15 (slight positive)
- **Injury Risk:** 65% (medium-high)

**Broadcast Use:** Show capsule overlay during player close-up for dramatic effect.

---

## **💡 15. INNOVATION HIGHLIGHTS**

### **What Makes BiomechFlow Unique:**

✅ **First biometric visualization system to combine:**
- NIL valuation signals (glow ring momentum)
- Physical injury risk (right bar)
- Financial hedging signals (substitution probability)

✅ **Borderless application:**
- Works for 47 Olympic sports
- Music concerts (vocal fatigue = physical fatigue)
- Acting performances (emotional intensity = stress load)

✅ **Real-time adaptability:**
- Auto-scales based on viewing distance
- Adapts brightness to arena lighting
- Occlusion-aware rendering

✅ **Multi-platform support:**
- Web (Canvas 2D)
- Mobile (React Native)
- AR headsets (Unity/Three.js)
- Broadcast (After Effects render)

---

## **📞 16. SUPPORT & CONTACT**

**Design Questions:**  
Email: design@physiobiofin.com

**Technical Implementation:**  
Email: dev@physiobiofin.com

**Licensing & Brand Use:**  
Email: licensing@nib ls.com

**Partnership Inquiries:**  
LinkedIn: [Bledsoe Investment Management](https://www.linkedin.com/company/bledsoe-investment-management-ai-consultancy-firm/)

---

**END OF DOCUMENT**

---

**© 2026 Dashawn Ramel Bledsoe / NIBLS Inc.**  
**License:** Creative Commons Attribution–NonCommercial–NoDerivatives 4.0 International  
**Software:** Apache License 2.0 (for code components)  
**Commercial Use:** Requires written authorization from NIBLS Inc.
