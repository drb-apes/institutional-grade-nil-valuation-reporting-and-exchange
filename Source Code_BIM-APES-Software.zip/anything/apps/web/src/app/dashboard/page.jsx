"use client";

import { useState, useEffect } from "react";
import {
  CheckCircle,
  Clock,
  ArrowRight,
  User,
  Camera,
  Target,
  DollarSign,
  Trophy,
  TrendingUp,
  Gift,
  Vote,
  Building2,
  Wallet,
  Activity,
  Shield,
  PieChart,
  BarChart3,
  Settings,
  FileText,
  Users,
  Brain,
  RefreshCw,
  AlertCircle,
  Zap,
  Music,
} from "lucide-react";
import useUser from "@/utils/useUser";

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  color = "#B8860B",
  loading,
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-start gap-4">
      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}18` }}
      >
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-gray-500 uppercase tracking-wider mb-0.5">
          {label}
        </p>
        {loading ? (
          <div className="h-6 bg-gray-200 rounded animate-pulse w-20 mt-1" />
        ) : (
          <p className="text-xl font-bold text-[#1D2B3D] font-mono">{value}</p>
        )}
        {sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

function TierBadge({ tier }) {
  const colors = {
    elite: "#FFCC33",
    advanced: "#3CFF7A",
    competitive: "#4DA6FF",
    developing: "#FF8C33",
    beginner: "#999",
    platinum: "#E5E4E2",
    gold: "#FFCC33",
    silver: "#C0C0C0",
    bronze: "#CD7F32",
  };
  const c = colors[tier] || "#999";
  return (
    <span
      className="text-xs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider"
      style={{ background: `${c}22`, color: c }}
    >
      {tier}
    </span>
  );
}

function SimulationRow({ sim }) {
  const sportLabel = sim.sessionType || sim.sport || "analysis";
  const date = new Date(sim.createdAt);
  const timeAgo = (() => {
    const diff = Date.now() - date.getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  })();

  return (
    <div className="flex items-center gap-3 py-3 border-b border-gray-100 last:border-0">
      <div className="w-8 h-8 rounded-lg bg-[#1D2B3D]/10 flex items-center justify-center flex-shrink-0">
        <Activity className="w-4 h-4 text-[#1D2B3D]" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-[#1D2B3D] truncate capitalize">
          {sportLabel} Session
        </p>
        <p className="text-xs text-gray-500">{timeAgo}</p>
      </div>
      <div className="text-right flex-shrink-0">
        <p className="text-sm font-bold text-[#B8860B] font-mono">
          {sim.bimScore > 0
            ? sim.bimScore.toFixed(1)
            : (sim.assetValue / 1000).toFixed(1)}
        </p>
        <TierBadge tier={sim.tier} />
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { data: user, loading: userLoading } = useUser();
  const [stats, setStats] = useState(null);
  const [recentSimulations, setRecentSimulations] = useState([]);
  const [recentMilestones, setRecentMilestones] = useState([]);
  const [loadingStats, setLoadingStats] = useState(true);
  const [error, setError] = useState(null);
  const [lastRefresh, setLastRefresh] = useState(null);

  const fetchStats = async () => {
    setLoadingStats(true);
    setError(null);
    try {
      const res = await fetch("/api/dashboard/stats");
      if (!res.ok) throw new Error(`Stats API error: ${res.status}`);
      const data = await res.json();
      setStats(data.stats);
      setRecentSimulations(data.recentSimulations || []);
      setRecentMilestones(data.recentMilestones || []);
      setLastRefresh(new Date());
    } catch (err) {
      console.error("Dashboard stats fetch failed:", err);
      setError(
        "Could not load live statistics. Check your database connection.",
      );
    } finally {
      setLoadingStats(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const sportLinks = [
    {
      href: "/wrestling-dashboard",
      label: "Wrestling / Goalwrestling",
      icon: "🤼",
      color: "#4DA6FF",
    },
    {
      href: "/tactical-sports-dashboard",
      label: "Rugby · Soccer · Basketball",
      icon: "⚽",
      color: "#3CFF7A",
    },
    {
      href: "/racket-sports-dashboard",
      label: "Tennis · Pickleball Spike",
      icon: "🎾",
      color: "#FFCC33",
    },
    {
      href: "/american-football-dashboard",
      label: "American Football Session",
      icon: "🏈",
      color: "#FF8C33",
    },
    {
      href: "/concert-nil-dashboard",
      label: "Live Concert NIL",
      icon: "🎵",
      color: "#FF3C9A",
    },
    {
      href: "/combat-sports-dashboard",
      label: "Combat Sports",
      icon: "🥊",
      color: "#FF3C3C",
    },
  ];

  const aumFormatted =
    stats?.aum > 0 ? `$${(stats.aum / 1000).toFixed(1)}K` : "$0";

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-4 md:px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-[#1D2B3D]">
                BIM-APES Dashboard
              </h1>
              <p className="text-gray-600 mt-1">
                {user
                  ? `Welcome back, ${user.name || user.email}`
                  : "Biometric Intelligence Management · Athletic Performance Engine"}
              </p>
            </div>
            <div className="flex items-center gap-3">
              {lastRefresh && (
                <span className="text-xs text-gray-500 hidden md:block">
                  Updated {lastRefresh.toLocaleTimeString()}
                </span>
              )}
              <button
                onClick={fetchStats}
                disabled={loadingStats}
                className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm text-[#1D2B3D] hover:bg-gray-50 transition-all disabled:opacity-50"
              >
                <RefreshCw
                  className={`w-4 h-4 ${loadingStats ? "animate-spin" : ""}`}
                />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          {/* Live Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
            <div className="md:col-span-2 lg:col-span-1">
              <StatCard
                label="Athletes"
                value={stats?.athleteCount?.toLocaleString() || "0"}
                sub="registered profiles"
                icon={Users}
                color="#1D2B3D"
                loading={loadingStats}
              />
            </div>
            <div className="md:col-span-2 lg:col-span-1">
              <StatCard
                label="Motion Scans"
                value={stats?.motionScanCount?.toLocaleString() || "0"}
                sub="analyses run"
                icon={Camera}
                color="#B8860B"
                loading={loadingStats}
              />
            </div>
            <div className="md:col-span-2 lg:col-span-1">
              <StatCard
                label="Milestones"
                value={stats?.activeMilestones?.toLocaleString() || "0"}
                sub="investment targets"
                icon={Target}
                color="#3CFF7A"
                loading={loadingStats}
              />
            </div>
            <div className="md:col-span-2 lg:col-span-1">
              <StatCard
                label="Simulations"
                value={stats?.simulationCount?.toLocaleString() || "0"}
                sub="BIM analyses"
                icon={Activity}
                color="#4DA6FF"
                loading={loadingStats}
              />
            </div>
            <div className="md:col-span-2 lg:col-span-1">
              <StatCard
                label="Referrals"
                value={stats?.referralCount?.toLocaleString() || "0"}
                sub="athlete referrals"
                icon={User}
                color="#FF8C33"
                loading={loadingStats}
              />
            </div>
            <div className="md:col-span-2 lg:col-span-1">
              <StatCard
                label="Contributions"
                value={
                  stats?.totalContributions > 0
                    ? `$${stats.totalContributions.toLocaleString(undefined, { maximumFractionDigits: 0 })}`
                    : "$0"
                }
                sub="total pooled"
                icon={DollarSign}
                color="#FF3C9A"
                loading={loadingStats}
              />
            </div>
            <div className="md:col-span-4 lg:col-span-1">
              <StatCard
                label="AUM"
                value={aumFormatted}
                sub="assets under mgmt"
                icon={PieChart}
                color="#B8860B"
                loading={loadingStats}
              />
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Sport-Specific Modules */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-6">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-lg font-bold text-[#1D2B3D]">
                  Sport Intelligence Modules
                </h2>
                <span className="text-xs text-gray-500 uppercase tracking-wider">
                  BIM-APES Engine
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {sportLinks.map((s) => (
                  <a
                    key={s.href}
                    href={s.href}
                    className="flex items-center gap-3 p-4 rounded-xl border border-gray-100 hover:border-[#B8860B]/40 hover:bg-[#F5F5F0] transition-all group"
                  >
                    <span className="text-2xl">{s.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-[#1D2B3D] group-hover:text-[#B8860B] transition-colors truncate">
                        {s.label}
                      </p>
                      <div
                        className="text-xs mt-0.5"
                        style={{ color: s.color }}
                      >
                        BIM Performance Tracker
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[#B8860B] transition-colors flex-shrink-0" />
                  </a>
                ))}
              </div>

              <div className="mt-5 pt-5 border-t border-gray-100">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">
                  Quick Access
                </p>
                <div className="flex flex-wrap gap-2">
                  {[
                    {
                      href: "/motion-scan",
                      label: "Motion Scan",
                      icon: Camera,
                    },
                    {
                      href: "/bim-apes-dashboard",
                      label: "BIM-APES",
                      icon: BarChart3,
                    },
                    {
                      href: "/analytics-dashboard",
                      label: "Analytics",
                      icon: TrendingUp,
                    },
                    { href: "/milestones", label: "Milestones", icon: Target },
                    { href: "/dao-governance", label: "DAO", icon: Vote },
                    { href: "/wallet", label: "Wallet", icon: Wallet },
                    { href: "/referral", label: "Referral", icon: Users },
                    {
                      href: "/concert-nil-dashboard",
                      label: "Concert NIL",
                      icon: Music,
                    },
                  ].map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F5F5F0] hover:bg-[#E8E8E0] text-[#1D2B3D] text-xs font-medium rounded-lg transition-all"
                    >
                      <item.icon className="w-3 h-3" />
                      {item.label}
                    </a>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="space-y-4">
              {/* Recent Simulations */}
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-[#1D2B3D] text-sm">
                    Recent BIM Analyses
                  </h3>
                  <span className="text-xs text-gray-400">
                    {loadingStats
                      ? "Loading..."
                      : `${recentSimulations.length} results`}
                  </span>
                </div>
                {loadingStats ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-3 py-2">
                        <div className="w-8 h-8 bg-gray-200 rounded-lg animate-pulse" />
                        <div className="flex-1">
                          <div className="h-3 bg-gray-200 rounded animate-pulse mb-1" />
                          <div className="h-2 bg-gray-100 rounded animate-pulse w-2/3" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : recentSimulations.length > 0 ? (
                  <div>
                    {recentSimulations.slice(0, 6).map((sim) => (
                      <SimulationRow key={sim.id} sim={sim} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Activity className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-500 text-sm">No analyses yet</p>
                    <p className="text-gray-400 text-xs mt-1">
                      Run a sport module to see results here
                    </p>
                  </div>
                )}
              </div>

              {/* Recent Milestones */}
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-[#1D2B3D] text-sm">
                    Active Milestones
                  </h3>
                  <a
                    href="/milestones"
                    className="text-xs text-[#B8860B] hover:underline"
                  >
                    View all →
                  </a>
                </div>
                {loadingStats ? (
                  <div className="space-y-2">
                    {[1, 2].map((i) => (
                      <div
                        key={i}
                        className="h-12 bg-gray-100 rounded-lg animate-pulse"
                      />
                    ))}
                  </div>
                ) : recentMilestones.length > 0 ? (
                  <div className="space-y-2">
                    {recentMilestones.map((m) => (
                      <div
                        key={m.id}
                        className="flex items-center gap-3 p-3 bg-[#F5F5F0] rounded-lg"
                      >
                        <Target className="w-4 h-4 text-[#B8860B] flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-[#1D2B3D] truncate">
                            {m.title}
                          </p>
                          <p className="text-xs text-gray-500 capitalize">
                            {m.milestone_status}
                          </p>
                        </div>
                        {m.reward_pool > 0 && (
                          <span className="text-xs font-bold text-[#B8860B] font-mono flex-shrink-0">
                            $
                            {parseFloat(m.reward_pool).toLocaleString(
                              undefined,
                              { maximumFractionDigits: 0 },
                            )}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <Target className="w-7 h-7 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-500 text-sm">No milestones yet</p>
                    <a
                      href="/milestones/create"
                      className="text-xs text-[#B8860B] hover:underline mt-1 block"
                    >
                      Create your first milestone →
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Platform Architecture Overview */}
          <div className="bg-[#1D2B3D] rounded-xl p-6 text-white">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold">
                  BIM-APES Platform Architecture
                </h2>
                <p className="text-gray-400 text-sm mt-0.5">
                  Biometric Investment Management · Athletic Performance Engine
                  Suite
                </p>
              </div>
              <div className="hidden md:flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-xs text-green-400">
                  All Systems Operational
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                {
                  label: "NIL Valuation Engine",
                  status: "Live",
                  color: "#FFCC33",
                  links: [
                    { label: "BIM Dashboard", href: "/bim-apes-dashboard" },
                    { label: "NIL Advisory", href: "/nil-advisory-dashboard" },
                    { label: "Draft Equity", href: "/draft-equity-cards" },
                  ],
                },
                {
                  label: "Sponsor Intelligence",
                  status: "Live",
                  color: "#4DA6FF",
                  links: [
                    {
                      label: "Hedge Dashboard",
                      href: "/sponsor-hedge-dashboard",
                    },
                    { label: "Sponsor Staking", href: "/sponsor-staking" },
                    { label: "Fan Engagement", href: "/fan-engagement" },
                  ],
                },
                {
                  label: "Analytics Suite",
                  status: "Live",
                  color: "#3CFF7A",
                  links: [
                    {
                      label: "Feature Relationship",
                      href: "/feature-relationship-dashboard",
                    },
                    {
                      label: "Visualization Suite",
                      href: "/bim-visualization-suite",
                    },
                    {
                      label: "Biometric Finance",
                      href: "/biometric-finance-signals",
                    },
                  ],
                },
                {
                  label: "Wearable & Mesh",
                  status: "Live",
                  color: "#FF8C33",
                  links: [
                    {
                      label: "Mesh Dashboard",
                      href: "/mesh-network-dashboard",
                    },
                    { label: "Motion Scan", href: "/motion-scan" },
                    {
                      label: "Mesh Architecture",
                      href: "/wearable-mesh-architecture",
                    },
                  ],
                },
              ].map((module) => (
                <div
                  key={module.label}
                  className="bg-white/5 rounded-xl p-4 border border-white/10"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ background: module.color }}
                    />
                    <span
                      className="text-xs font-semibold uppercase tracking-wider"
                      style={{ color: module.color }}
                    >
                      {module.status}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-white mb-3">
                    {module.label}
                  </p>
                  <div className="space-y-1">
                    {module.links.map((l) => (
                      <a
                        key={l.href}
                        href={l.href}
                        className="block text-xs text-gray-400 hover:text-white transition-colors py-0.5"
                      >
                        → {l.label}
                      </a>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Licensing Footer */}
          <div className="mt-6 text-center text-xs text-gray-500 space-y-1">
            <p>© Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.</p>
            <p>
              BIM-APES Software is developed and published by Bledsoe Investment
              Management, a division of NIBLS Inc. Software licensed under
              Apache License 2.0.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
