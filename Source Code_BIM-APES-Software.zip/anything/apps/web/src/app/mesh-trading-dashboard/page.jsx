"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function MeshTradingDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [meshSignals, setMeshSignals] = useState(null);
  const [tradingOpportunities, setTradingOpportunities] = useState([]);
  const [automatedTriggers, setAutomatedTriggers] = useState([]);
  const [isLoadingSignals, setIsLoadingSignals] = useState(false);
  const [meshNetworks, setMeshNetworks] = useState([]);

  // Mock mesh network data
  useEffect(() => {
    setMeshNetworks([
      {
        meshId: "MESH_TRAINING_001",
        deviceId: "DEVICE_ATHLETE_01",
        status: "synchronized",
        lastSync: new Date().toISOString(),
        dataQuality: 92,
        athleteId: 1,
      },
      {
        meshId: "MESH_TEAM_002",
        deviceId: "DEVICE_COACH_01",
        status: "syncing",
        lastSync: new Date(Date.now() - 30000).toISOString(),
        dataQuality: 88,
        athleteId: 2,
      },
    ]);
  }, []);

  const fetchMeshTradingSignals = async (meshId, deviceId, athleteId) => {
    setIsLoadingSignals(true);
    try {
      const response = await fetch("/api/mesh-trading/real-time-signals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          meshId,
          deviceId,
          athleteId,
          tradingParameters: {
            risk_tolerance: "medium",
            position_size_limit: 25000,
            auto_execution: false,
          },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch mesh trading signals");
      }

      const data = await response.json();
      setMeshSignals(data);
      setTradingOpportunities(data.trading_opportunities || []);
      setAutomatedTriggers(data.automated_triggers || []);
    } catch (error) {
      console.error("Error fetching mesh signals:", error);
    } finally {
      setIsLoadingSignals(false);
    }
  };

  const executeAutomatedTrade = async (
    triggerId,
    meshId,
    deviceId,
    athleteId,
  ) => {
    try {
      const response = await fetch("/api/mesh-trading/execute-automated", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          triggerId,
          meshId,
          deviceId,
          athleteId,
        }),
      });

      const result = await response.json();

      if (result.success) {
        // Refresh signals after execution
        await fetchMeshTradingSignals(meshId, deviceId, athleteId);
      }

      return result;
    } catch (error) {
      console.error("Error executing automated trade:", error);
      return { success: false, error: error.message };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-lg text-[#1D2B3D]">Loading dashboard...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4 text-[#1D2B3D]">
            Authentication Required
          </h1>
          <p className="text-gray-600 mb-4">
            Please sign in to access the mesh trading dashboard.
          </p>
          <a
            href="/account/signin"
            className="text-[#B8860B] hover:text-[#1D2B3D] hover:underline transition-colors duration-300"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6 border border-[#1D2B3D]/10">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-[#1D2B3D] mb-2">
                🔗 Mesh Trading Dashboard
              </h1>
              <p className="text-gray-600">
                Real-time biometric trading with mesh network integration
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Last Updated</div>
              <div className="text-[#1D2B3D] font-medium">
                {new Date().toLocaleTimeString()}
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg shadow-sm border border-[#1D2B3D]/10 mb-6">
          <div className="flex border-b border-[#1D2B3D]/10">
            {[
              { id: "overview", label: "🏁 Overview", icon: "📊" },
              { id: "signals", label: "📡 Real-time Signals", icon: "⚡" },
              {
                id: "opportunities",
                label: "💰 Trading Opportunities",
                icon: "🎯",
              },
              { id: "automation", label: "🤖 Automated Triggers", icon: "⚙️" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-4 font-medium transition-colors duration-300 ${
                  activeTab === tab.id
                    ? "text-[#B8860B] border-b-2 border-[#B8860B] bg-[#B8860B]/5"
                    : "text-gray-600 hover:text-[#1D2B3D]"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Mesh Network Status */}
            <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
              <h2 className="text-xl font-bold text-[#1D2B3D] mb-4">
                📡 Active Mesh Networks
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {meshNetworks.map((network, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-[#1D2B3D]">
                          {network.meshId}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {network.deviceId}
                        </p>
                      </div>
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          network.status === "synchronized"
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {network.status}
                      </span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div>Quality: {network.dataQuality}%</div>
                      <div>
                        Last Sync:{" "}
                        {new Date(network.lastSync).toLocaleTimeString()}
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        fetchMeshTradingSignals(
                          network.meshId,
                          network.deviceId,
                          network.athleteId,
                        )
                      }
                      disabled={isLoadingSignals}
                      className="mt-3 w-full px-4 py-2 bg-[#B8860B] text-white rounded-lg hover:bg-[#1D2B3D] transition-colors duration-300 disabled:opacity-50"
                    >
                      {isLoadingSignals ? "Loading..." : "Get Trading Signals"}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "signals" && (
          <div className="space-y-6">
            {meshSignals ? (
              <>
                {/* Biometric Signals */}
                <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
                  <h2 className="text-xl font-bold text-[#1D2B3D] mb-4">
                    📊 Live Biometric Signals
                  </h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-[#B8860B]/10 rounded-lg">
                      <div className="text-2xl font-bold text-[#B8860B]">
                        {Math.round(
                          meshSignals.biometric_signals.momentum_signals
                            .overall_momentum,
                        )}
                      </div>
                      <div className="text-sm text-gray-600">
                        Overall Momentum
                      </div>
                    </div>
                    <div className="text-center p-4 bg-green-100 rounded-lg">
                      <div className="text-2xl font-bold text-green-700">
                        {Math.round(
                          meshSignals.biometric_signals.performance_metrics
                            .efficiency_score,
                        )}
                      </div>
                      <div className="text-sm text-gray-600">
                        Efficiency Score
                      </div>
                    </div>
                    <div className="text-center p-4 bg-blue-100 rounded-lg">
                      <div className="text-2xl font-bold text-blue-700">
                        {Math.round(
                          meshSignals.biometric_signals.biometric_indicators
                            .recovery_index,
                        )}
                      </div>
                      <div className="text-sm text-gray-600">
                        Recovery Index
                      </div>
                    </div>
                    <div className="text-center p-4 bg-red-100 rounded-lg">
                      <div className="text-2xl font-bold text-red-700">
                        {Math.round(
                          meshSignals.biometric_signals.risk_indicators
                            .overall_risk_score,
                        )}
                      </div>
                      <div className="text-sm text-gray-600">Risk Score</div>
                    </div>
                  </div>
                </div>

                {/* Asset Valuation */}
                <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
                  <h2 className="text-xl font-bold text-[#1D2B3D] mb-4">
                    💎 Real-time Asset Valuation
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <div className="text-3xl font-bold text-[#B8860B] mb-2">
                        $
                        {meshSignals.asset_valuations.current_asset_value.toLocaleString()}
                      </div>
                      <div className="text-gray-600">Current Asset Value</div>
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Performance Impact:</span>
                          <span className="font-medium">
                            +
                            {meshSignals.asset_valuations.performance_component}
                            %
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Risk Adjustment:</span>
                          <span className="font-medium">
                            {meshSignals.asset_valuations.risk_adjustment}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Market Sentiment:</span>
                          <span className="font-medium">
                            +{meshSignals.asset_valuations.sentiment_impact}%
                          </span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-[#1D2B3D] mb-2">
                        Valuation Confidence
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
                        <div
                          className="bg-[#B8860B] h-4 rounded-full transition-all duration-300"
                          style={{
                            width: `${meshSignals.asset_valuations.valuation_confidence}%`,
                          }}
                        ></div>
                      </div>
                      <div className="text-sm text-gray-600">
                        {Math.round(
                          meshSignals.asset_valuations.valuation_confidence,
                        )}
                        % Confidence
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
                <div className="text-center py-12">
                  <div className="text-gray-400 text-6xl mb-4">📡</div>
                  <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                    No Mesh Signals Available
                  </h3>
                  <p className="text-gray-600">
                    Select a mesh network from the Overview tab to load
                    real-time trading signals.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "opportunities" && (
          <div className="space-y-6">
            {tradingOpportunities.length > 0 ? (
              tradingOpportunities.map((opportunity, index) => (
                <div
                  key={index}
                  className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-[#1D2B3D] capitalize">
                        {opportunity.type.replace(/_/g, " ")}
                      </h3>
                      <p className="text-gray-600 mt-1">{opportunity.reason}</p>
                    </div>
                    <div className="text-right">
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          opportunity.confidence > 80
                            ? "bg-green-100 text-green-800"
                            : opportunity.confidence > 60
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                        }`}
                      >
                        {opportunity.confidence}% Confidence
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <div className="text-sm text-gray-600">
                        Recommended Action
                      </div>
                      <div className="font-semibold text-[#1D2B3D] capitalize">
                        {opportunity.recommended_action.replace(/_/g, " ")}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Risk Level</div>
                      <div
                        className={`font-semibold capitalize ${
                          opportunity.risk_level === "low"
                            ? "text-green-600"
                            : opportunity.risk_level === "medium"
                              ? "text-yellow-600"
                              : "text-red-600"
                        }`}
                      >
                        {opportunity.risk_level}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Time Horizon</div>
                      <div className="font-semibold text-[#1D2B3D] capitalize">
                        {opportunity.time_horizon.replace(/_/g, " ")}
                      </div>
                    </div>
                  </div>

                  {opportunity.suggested_instruments && (
                    <div className="mb-4">
                      <div className="text-sm text-gray-600 mb-2">
                        Suggested Instruments
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {opportunity.suggested_instruments.map(
                          (instrument, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1 bg-[#B8860B]/10 text-[#B8860B] rounded-full text-sm"
                            >
                              {instrument}
                            </span>
                          ),
                        )}
                      </div>
                    </div>
                  )}

                  <details className="mt-4">
                    <summary className="cursor-pointer text-sm text-[#B8860B] hover:text-[#1D2B3D] transition-colors duration-300">
                      View Supporting Signals
                    </summary>
                    <div className="mt-2 p-3 bg-gray-50 rounded text-sm">
                      <pre>{JSON.stringify(opportunity.signals, null, 2)}</pre>
                    </div>
                  </details>
                </div>
              ))
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
                <div className="text-center py-12">
                  <div className="text-gray-400 text-6xl mb-4">💰</div>
                  <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                    No Trading Opportunities
                  </h3>
                  <p className="text-gray-600">
                    Load mesh signals to discover real-time trading
                    opportunities.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "automation" && (
          <div className="space-y-6">
            {automatedTriggers.length > 0 ? (
              automatedTriggers.map((trigger, index) => (
                <div
                  key={index}
                  className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-[#1D2B3D] capitalize">
                        {trigger.type.replace(/_/g, " ")}
                      </h3>
                      <p className="text-gray-600 mt-1">
                        Triggered: {trigger.current_value} / {trigger.threshold}
                      </p>
                    </div>
                    <div className="text-right">
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          trigger.triggered
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {trigger.triggered ? "Active" : "Inactive"}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <div className="text-sm text-gray-600">Action</div>
                      <div className="font-semibold text-[#1D2B3D] capitalize">
                        {trigger.action}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Auto Execute</div>
                      <div
                        className={`font-semibold ${
                          trigger.auto_execute
                            ? "text-green-600"
                            : "text-gray-600"
                        }`}
                      >
                        {trigger.auto_execute ? "Enabled" : "Disabled"}
                      </div>
                    </div>
                  </div>

                  {trigger.auto_execute && trigger.triggered && (
                    <button
                      onClick={() =>
                        executeAutomatedTrade(
                          trigger.type,
                          meshSignals?.mesh_sync_status?.mesh_id,
                          meshSignals?.mesh_sync_status?.device_id,
                          1, // athlete ID - should be dynamic
                        )
                      }
                      className="w-full px-4 py-2 bg-[#B8860B] text-white rounded-lg hover:bg-[#1D2B3D] transition-colors duration-300"
                    >
                      Execute Automated Trade
                    </button>
                  )}
                </div>
              ))
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
                <div className="text-center py-12">
                  <div className="text-gray-400 text-6xl mb-4">🤖</div>
                  <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                    No Automated Triggers
                  </h3>
                  <p className="text-gray-600">
                    Configure automation settings to enable automated trading
                    triggers.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
