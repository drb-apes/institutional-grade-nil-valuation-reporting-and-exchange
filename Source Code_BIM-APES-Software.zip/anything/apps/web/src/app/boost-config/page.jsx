"use client";

import { useState, useEffect } from "react";
import { Settings, Zap, Bitcoin, DollarSign, Check, Save } from "lucide-react";
import useUser from "@/utils/useUser";

export default function BoostConfigPage() {
  const { data: user, loading: userLoading } = useUser();

  const [config, setConfig] = useState({
    engagement_layer: "free",
    boost_cost: 0,
    boost_credits_per_action: 1,
    payment_currency: "USD",
    features: {
      tap_to_boost: true,
      mega_boost: false,
      milestone_funding: false,
    },
    tier_system: {
      tier_1: { name: "Bronze", min_credits: 0, multiplier: 1.0 },
      tier_2: { name: "Silver", min_credits: 100, multiplier: 1.5 },
      tier_3: { name: "Gold", min_credits: 500, multiplier: 2.0 },
      vault: { name: "Vault", min_credits: 2000, multiplier: 3.0 },
    },
  });

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const res = await fetch("/api/boost/config");
      const data = await res.json();
      setConfig(data);
    } catch (error) {
      console.error("Error loading config:", error);
    }
  };

  const handleLayerChange = (layer) => {
    const presets = {
      free: {
        engagement_layer: "free",
        boost_cost: 0,
        payment_currency: null,
        features: {
          tap_to_boost: true,
          mega_boost: false,
          milestone_funding: false,
        },
      },
      crypto: {
        engagement_layer: "crypto",
        boost_cost: "0.00001",
        payment_currency: "ETH",
        features: {
          tap_to_boost: true,
          mega_boost: true,
          milestone_funding: true,
        },
      },
      fiat: {
        engagement_layer: "fiat",
        boost_cost: "0.10",
        payment_currency: "USD",
        features: {
          tap_to_boost: true,
          mega_boost: true,
          milestone_funding: true,
        },
      },
    };

    setConfig({ ...config, ...presets[layer] });
  };

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);

    try {
      // In production, this would save to database
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      console.error("Error saving config:", error);
      alert("Failed to save configuration");
    } finally {
      setSaving(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#10B981] mx-auto"></div>
          <p className="text-[#9CA3AF] mt-4">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-8">
        <div className="text-center max-w-md">
          <Settings className="w-16 h-16 text-[#6B7280] mx-auto" />
          <h1 className="text-[#F3F4F6] text-2xl font-bold mt-6">
            Admin Access Required
          </h1>
          <p className="text-[#9CA3AF] mt-3">
            Sign in to configure boost settings
          </p>
          <a
            href="/account/signin"
            className="inline-block mt-6 px-6 py-3 bg-[#10B981] text-white rounded-lg font-semibold hover:bg-[#059669]"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Settings className="w-8 h-8 text-[#10B981]" />
            <h1 className="text-[#F3F4F6] text-3xl font-extrabold">
              Boost Configuration
            </h1>
          </div>
          <p className="text-[#9CA3AF]">
            Configure your fan engagement layer and pricing
          </p>
        </div>

        {/* Engagement Layer Selection */}
        <div className="bg-[#111827] border border-[#1F2937] rounded-2xl p-8 mb-6">
          <h2 className="text-[#F3F4F6] text-xl font-bold mb-4">
            Engagement Layer
          </h2>
          <p className="text-[#9CA3AF] text-sm mb-6">
            Choose how fans can boost athletes
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <LayerCard
              icon={Zap}
              name="Free Tier"
              description="No payment required. Fans earn points through engagement."
              color="#10B981"
              isActive={config.engagement_layer === "free"}
              onClick={() => handleLayerChange("free")}
              badge="High School, Amateur"
            />

            <LayerCard
              icon={Bitcoin}
              name="Crypto Tier"
              description="Fans pay with cryptocurrency (ETH, BTC, etc.)"
              color="#F59E0B"
              isActive={config.engagement_layer === "crypto"}
              onClick={() => handleLayerChange("crypto")}
              badge="Web3 Leagues"
            />

            <LayerCard
              icon={DollarSign}
              name="Fiat Tier"
              description="Fans pay with USD/EUR via Stripe or bank"
              color="#3B82F6"
              isActive={config.engagement_layer === "fiat"}
              onClick={() => handleLayerChange("fiat")}
              badge="NIL Marketplaces"
            />
          </div>
        </div>

        {/* Pricing Configuration */}
        {config.engagement_layer !== "free" && (
          <div className="bg-[#111827] border border-[#1F2937] rounded-2xl p-8 mb-6">
            <h2 className="text-[#F3F4F6] text-xl font-bold mb-6">Pricing</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-[#9CA3AF] text-sm font-semibold mb-2">
                  Cost Per Boost
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={config.boost_cost}
                    onChange={(e) =>
                      setConfig({ ...config, boost_cost: e.target.value })
                    }
                    className="w-full bg-[#0A0A0A] border border-[#374151] rounded-lg px-4 py-3 text-[#F3F4F6] focus:border-[#10B981] focus:outline-none"
                  />
                  <span className="absolute right-4 top-3 text-[#6B7280]">
                    {config.payment_currency}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[#9CA3AF] text-sm font-semibold mb-2">
                  Credits Per Boost
                </label>
                <input
                  type="number"
                  value={config.boost_credits_per_action}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      boost_credits_per_action: parseInt(e.target.value),
                    })
                  }
                  className="w-full bg-[#0A0A0A] border border-[#374151] rounded-lg px-4 py-3 text-[#F3F4F6] focus:border-[#10B981] focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Features */}
        <div className="bg-[#111827] border border-[#1F2937] rounded-2xl p-8 mb-6">
          <h2 className="text-[#F3F4F6] text-xl font-bold mb-6">Features</h2>

          <div className="space-y-4">
            <FeatureToggle
              name="Tap to Boost"
              description="Enable simple one-tap boost functionality"
              enabled={config.features.tap_to_boost}
              onChange={(enabled) =>
                setConfig({
                  ...config,
                  features: { ...config.features, tap_to_boost: enabled },
                })
              }
            />

            <FeatureToggle
              name="Mega Boost"
              description="Allow fans to send larger boost amounts (10x, 100x)"
              enabled={config.features.mega_boost}
              onChange={(enabled) =>
                setConfig({
                  ...config,
                  features: { ...config.features, mega_boost: enabled },
                })
              }
            />

            <FeatureToggle
              name="Milestone Funding"
              description="Let fans contribute to athlete milestone pools"
              enabled={config.features.milestone_funding}
              onChange={(enabled) =>
                setConfig({
                  ...config,
                  features: { ...config.features, milestone_funding: enabled },
                })
              }
            />
          </div>
        </div>

        {/* Tier System */}
        <div className="bg-[#111827] border border-[#1F2937] rounded-2xl p-8 mb-6">
          <h2 className="text-[#F3F4F6] text-xl font-bold mb-6">Tier System</h2>

          <div className="space-y-4">
            {Object.entries(config.tier_system).map(([key, tier]) => (
              <div
                key={key}
                className="flex items-center justify-between p-4 bg-[#0A0A0A] rounded-lg border border-[#374151]"
              >
                <div className="flex-1">
                  <p className="text-[#F3F4F6] font-semibold">{tier.name}</p>
                  <p className="text-[#6B7280] text-sm">
                    Multiplier: {tier.multiplier}x
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[#9CA3AF] text-sm">Min Credits</p>
                  <p className="text-[#F3F4F6] font-bold">{tier.min_credits}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end gap-4">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-3 bg-[#10B981] hover:bg-[#059669] disabled:bg-[#374151] text-white rounded-lg font-semibold transition-colors"
          >
            {saving ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                Saving...
              </>
            ) : saved ? (
              <>
                <Check className="w-5 h-5" />
                Saved!
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                Save Configuration
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

function LayerCard({
  icon: Icon,
  name,
  description,
  color,
  isActive,
  onClick,
  badge,
}) {
  return (
    <button
      onClick={onClick}
      className={`
        relative p-6 rounded-xl border-2 transition-all text-left
        ${
          isActive
            ? "border-[" + color + "] bg-[" + color + "]10"
            : "border-[#374151] bg-[#0A0A0A] hover:border-[#4B5563]"
        }
      `}
      style={{
        borderColor: isActive ? color : "#374151",
        backgroundColor: isActive ? color + "10" : "#0A0A0A",
      }}
    >
      {isActive && (
        <div
          className="absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center"
          style={{ backgroundColor: color }}
        >
          <Check className="w-4 h-4 text-white" />
        </div>
      )}

      <Icon className="w-8 h-8 mb-3" style={{ color }} />
      <h3 className="text-[#F3F4F6] font-bold text-lg mb-2">{name}</h3>
      <p className="text-[#9CA3AF] text-sm mb-3">{description}</p>
      <span
        className="inline-block px-3 py-1 rounded-full text-xs font-semibold"
        style={{
          backgroundColor: color + "20",
          color,
        }}
      >
        {badge}
      </span>
    </button>
  );
}

function FeatureToggle({ name, description, enabled, onChange }) {
  return (
    <div className="flex items-center justify-between p-4 bg-[#0A0A0A] rounded-lg border border-[#374151]">
      <div className="flex-1">
        <p className="text-[#F3F4F6] font-semibold">{name}</p>
        <p className="text-[#6B7280] text-sm">{description}</p>
      </div>
      <button
        onClick={() => onChange(!enabled)}
        className={`
          relative w-14 h-8 rounded-full transition-colors
          ${enabled ? "bg-[#10B981]" : "bg-[#374151]"}
        `}
      >
        <div
          className={`
          absolute top-1 w-6 h-6 bg-white rounded-full transition-transform
          ${enabled ? "translate-x-7" : "translate-x-1"}
        `}
        />
      </button>
    </div>
  );
}
