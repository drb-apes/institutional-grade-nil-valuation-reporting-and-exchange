import { Header } from "@/components/HomePage/Header";
import { HeroSection } from "@/components/HomePage/HeroSection";
import { TrustSignals } from "@/components/HomePage/TrustSignals";
import { PerformanceMetrics } from "@/components/HomePage/PerformanceMetrics";
import { PlatformFeatures } from "@/components/HomePage/PlatformFeatures";
import { CoalitionNetwork } from "@/components/HomePage/CoalitionNetwork";
import { TrackRecord } from "@/components/HomePage/TrackRecord";
import { CallToAction } from "@/components/HomePage/CallToAction";
import { Footer } from "@/components/HomePage/Footer";
import LicensingFooter from "@/components/LicensingFooter";
import { BRAND_CLASSES, BRAND_COLORS } from "@/utils/brandColors";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      <Header />
      <HeroSection />

      {/* Universal Platform Message */}
      <div className="py-16 bg-[#1B3A57]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Universal Biometric Finance Engine
          </h2>
          <div className="h-[2px] bg-[#C8A882] w-16 mx-auto mb-6"></div>
          <p className="text-xl text-[#E5E5E5] mb-6">
            BIM-APES abstracts to any sport and any organization tier. From
            youth academies to professional leagues, from wrestling to
            motorsport — one platform, infinite contexts.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30">
              <div className="text-2xl font-bold text-[#C8A882] mb-1">10</div>
              <div className="text-sm text-[#E5E5E5]">Sports</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30">
              <div className="text-2xl font-bold text-[#C8A882] mb-1">9</div>
              <div className="text-sm text-[#E5E5E5]">Org Tiers</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30">
              <div className="text-2xl font-bold text-[#C8A882] mb-1">5</div>
              <div className="text-sm text-[#E5E5E5]">System Layers</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30">
              <div className="text-2xl font-bold text-[#C8A882] mb-1">PPI</div>
              <div className="text-sm text-[#E5E5E5]">Universal Index</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30">
              <div className="text-2xl font-bold text-[#C8A882] mb-1">∞</div>
              <div className="text-sm text-[#E5E5E5]">Contexts</div>
            </div>
          </div>
          <a
            href="/universal-dashboard"
            className={`inline-block ${BRAND_CLASSES.btnSecondary} px-8 py-3 rounded-lg`}
          >
            Explore Universal Dashboard
          </a>
        </div>
      </div>

      <TrustSignals />
      <PerformanceMetrics />
      <PlatformFeatures />
      <CoalitionNetwork />
      <TrackRecord />
      <CallToAction />
      <Footer />
      <LicensingFooter />
    </div>
  );
}
