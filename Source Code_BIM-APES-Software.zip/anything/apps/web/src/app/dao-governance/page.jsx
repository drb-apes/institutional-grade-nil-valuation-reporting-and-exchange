"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function DAOGovernanceDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("active");
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Create proposal form
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [proposalType, setProposalType] = useState("treasury_allocation");

  useEffect(() => {
    if (user) {
      loadProposals();
    }
  }, [user, activeTab]);

  const loadProposals = async () => {
    setLoading(true);
    try {
      const url =
        activeTab === "all"
          ? "/api/dao/proposals"
          : `/api/dao/proposals?status=${activeTab}`;
      const res = await fetch(url);
      const data = await res.json();
      setProposals(data.proposals || []);
    } catch (error) {
      console.error("Error loading proposals:", error);
    }
    setLoading(false);
  };

  const handleCreateProposal = async () => {
    if (!title || !description) return;
    setLoading(true);
    try {
      const res = await fetch("/api/dao/proposals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          proposal_type: proposalType,
          duration_days: 7,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage("Proposal created successfully!");
        setTitle("");
        setDescription("");
        setShowCreateForm(false);
        loadProposals();
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
    setLoading(false);
  };

  const handleVote = async (proposalId, voteChoice) => {
    setLoading(true);
    try {
      const res = await fetch("/api/dao/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          proposal_id: proposalId,
          vote_choice: voteChoice,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(`Vote cast: ${voteChoice}`);
        loadProposals();
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
    setLoading(false);
  };

  if (userLoading || !user)
    return (
      <div className="min-h-screen bg-[#0A0F1E] flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );

  return (
    <div className="min-h-screen bg-[#0A0F1E] text-white">
      {/* Header */}
      <div className="border-b border-[#1E293B] bg-gradient-to-r from-[#0F172A] to-[#1E293B]">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold mb-2">DAO Governance</h1>
              <p className="text-gray-400">
                Community Proposals, Voting, Treasury Decisions
              </p>
            </div>
            <button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="bg-[#C4A661] text-black px-6 py-3 rounded-lg font-bold hover:bg-[#D4B671] transition-all"
            >
              {showCreateForm ? "Cancel" : "+ Create Proposal"}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Create Proposal Form */}
        {showCreateForm && (
          <div className="bg-[#1E293B] rounded-xl p-6 mb-6">
            <h2 className="text-2xl font-bold mb-4">Create New Proposal</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Proposal title..."
                  className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe your proposal..."
                  rows={4}
                  className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Proposal Type
                </label>
                <select
                  value={proposalType}
                  onChange={(e) => setProposalType(e.target.value)}
                  className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                >
                  <option value="treasury_allocation">
                    Treasury Allocation
                  </option>
                  <option value="insurance_claim">Insurance Claim</option>
                  <option value="tier_adjustment">Tier Adjustment</option>
                  <option value="platform_upgrade">Platform Upgrade</option>
                  <option value="emergency_response">Emergency Response</option>
                </select>
              </div>
              <button
                onClick={handleCreateProposal}
                disabled={loading}
                className="w-full bg-[#C4A661] text-black font-bold py-3 rounded-lg hover:bg-[#D4B671] transition-all disabled:opacity-50"
              >
                {loading ? "Creating..." : "Submit Proposal"}
              </button>
            </div>
          </div>
        )}

        {message && (
          <div className="mb-6 bg-[#1E293B] border border-[#C4A661] rounded-lg p-4 text-center">
            {message}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {["active", "passed", "rejected", "all"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                activeTab === tab
                  ? "bg-[#C4A661] text-black"
                  : "bg-[#1E293B] text-gray-400 hover:bg-[#2D3B52]"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Proposals Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {loading ? (
            <div className="col-span-full text-center py-12 text-gray-400">
              Loading proposals...
            </div>
          ) : proposals.length === 0 ? (
            <div className="col-span-full bg-[#1E293B] rounded-xl p-12 text-center">
              <p className="text-gray-400">No {activeTab} proposals</p>
            </div>
          ) : (
            proposals.map((proposal) => (
              <div key={proposal.id} className="bg-[#1E293B] rounded-xl p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold mb-1">{proposal.title}</h3>
                    <div className="text-sm text-gray-400">
                      by {proposal.proposer_name || "Anonymous"}
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      proposal.proposal_status === "active"
                        ? "bg-green-500/20 text-green-400"
                        : proposal.proposal_status === "passed"
                          ? "bg-blue-500/20 text-blue-400"
                          : proposal.proposal_status === "rejected"
                            ? "bg-red-500/20 text-red-400"
                            : "bg-gray-500/20 text-gray-400"
                    }`}
                  >
                    {proposal.proposal_status}
                  </span>
                </div>

                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {proposal.description}
                </p>

                <div className="flex gap-2 items-center mb-4">
                  <span className="text-xs px-2 py-1 bg-[#0F172A] rounded">
                    {proposal.proposal_type.replace("_", " ")}
                  </span>
                  <span className="text-xs text-gray-500">
                    Expires:{" "}
                    {new Date(proposal.expires_at).toLocaleDateString()}
                  </span>
                </div>

                {/* Vote Counts */}
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Votes</span>
                    <span>
                      <span className="text-green-400">
                        {proposal.votes_for}
                      </span>
                      {" / "}
                      <span className="text-red-400">
                        {proposal.votes_against}
                      </span>
                    </span>
                  </div>
                  <div className="w-full bg-[#0F172A] rounded-full h-2">
                    <div
                      className="bg-green-500 h-2 rounded-full"
                      style={{
                        width: `${(proposal.votes_for / (proposal.votes_for + proposal.votes_against || 1)) * 100}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Vote Buttons */}
                {proposal.proposal_status === "active" && (
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleVote(proposal.id, "for")}
                      disabled={loading}
                      className="flex-1 bg-green-500/20 text-green-400 font-bold py-2 rounded-lg hover:bg-green-500/30 transition-all disabled:opacity-50"
                    >
                      Vote For
                    </button>
                    <button
                      onClick={() => handleVote(proposal.id, "against")}
                      disabled={loading}
                      className="flex-1 bg-red-500/20 text-red-400 font-bold py-2 rounded-lg hover:bg-red-500/30 transition-all disabled:opacity-50"
                    >
                      Vote Against
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
