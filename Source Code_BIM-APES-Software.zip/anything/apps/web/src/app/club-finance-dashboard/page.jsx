"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import InvoiceDiscountingPanel from "@/components/ClubBusinessDashboard/InvoiceDiscountingPanel";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Shield,
  Bot,
  PieChart,
  FileText,
  CreditCard,
  Target,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";

export default function ClubFinanceDashboard() {
  const { data: user, loading } = useUser();
  const [financialData, setFinancialData] = useState(null);
  const [invoiceData, setInvoiceData] = useState(null);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [loadingState, setLoadingState] = useState(true);

  useEffect(() => {
    if (user) {
      loadFinancialData();
      loadInvoiceData();
      loadAIAnalysis();
    }
  }, [user]);

  const loadFinancialData = async () => {
    try {
      const response = await fetch("/api/club-finance/capital-management");
      const data = await response.json();
      if (data.success) {
        setFinancialData(data.financial_overview);
      }
    } catch (error) {
      console.error("Error loading financial data:", error);
    }
  };

  const loadInvoiceData = async () => {
    try {
      const response = await fetch("/api/club-finance/invoice-discounting");
      const data = await response.json();
      if (data.success) {
        setInvoiceData(data.invoice_discounting);
      }
    } catch (error) {
      console.error("Error loading invoice data:", error);
    }
  };

  const loadAIAnalysis = async () => {
    try {
      const response = await fetch("/api/club-finance/ai-financial-advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "financial_analysis" }),
      });
      const data = await response.json();
      if (data.success) {
        setAiAnalysis(data.ai_analysis);
      }
    } catch (error) {
      console.error("Error loading AI analysis:", error);
    } finally {
      setLoadingState(false);
    }
  };

  if (loading || loadingState) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 border-t-2 border-b-2 border-[#B8860B] rounded-full"></div>
          <p className="mt-4 text-gray-300">
            Loading Club Finance Dashboard...
          </p>
          <style jsx global>{`
            @keyframes spin {
              to { transform: rotate(360deg); }
            }
            .inline-block {
              animation: spin 1s linear infinite;
            }
          `}</style>
        </div>
      </div>
    );
  }

  if (!user || !["institutional", "dao_member"].includes(user.user_type)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50] flex items-center justify-center">
        <div className="text-center bg-[#1D2B3D]/80 backdrop-blur-lg border border-[#B8860B]/20 p-8 rounded-2xl shadow-2xl">
          <Shield className="h-16 w-16 text-[#B8860B] mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">
            Access Restricted
          </h2>
          <p className="text-gray-300">
            Club management access required to view financial dashboard.
          </p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: "overview", label: "Financial Overview", icon: PieChart },
    { id: "invoice", label: "Invoice Discounting", icon: FileText },
    { id: "ai-advisor", label: "AI Financial Advisor", icon: Bot },
    { id: "compliance", label: "Compliance & Security", icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50]">
      {/* Enhanced Header with Brand Colors */}
      <div className="bg-[#1D2B3D]/80 backdrop-blur-lg border-b border-[#B8860B]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  Club Finance Dashboard
                </h1>
                <p className="text-lg text-gray-300">
                  BIM-APES Financial Optimization & Capital Management
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-[#B8860B]/20 backdrop-blur-sm border border-[#B8860B]/30 px-4 py-2 rounded-xl">
                  <span className="text-[#B8860B] text-sm font-bold flex items-center gap-2">
                    <CheckCircle size={16} />
                    GDPR Compliant
                  </span>
                </div>
                <div className="bg-[#00D9FF]/20 backdrop-blur-sm border border-[#00D9FF]/30 px-4 py-2 rounded-xl">
                  <span className="text-[#00D9FF] text-sm font-bold flex items-center gap-2">
                    <Bot size={16} />
                    AI-Powered
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Navigation Tabs with Brand Colors */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mt-6">
          <nav className="flex gap-2 bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold text-sm transition-all ${
                    activeTab === tab.id
                      ? "bg-[#B8860B] text-black shadow-lg shadow-[#B8860B]/50"
                      : "text-gray-300 hover:bg-white/10"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "overview" && (
          <FinancialOverview
            financialData={financialData}
            invoiceData={invoiceData}
            aiAnalysis={aiAnalysis}
          />
        )}

        {activeTab === "invoice" && <InvoiceDiscountingPanel />}

        {activeTab === "ai-advisor" && (
          <AIFinancialAdvisor
            aiAnalysis={aiAnalysis}
            onRefreshAnalysis={loadAIAnalysis}
          />
        )}

        {activeTab === "compliance" && <ComplianceOverview />}
      </div>
    </div>
  );
}

function FinancialOverview({ financialData, invoiceData, aiAnalysis }) {
  if (!financialData) {
    return (
      <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-8 text-center">
        <div className="inline-block h-12 w-12 border-t-2 border-b-2 border-[#B8860B] rounded-full"></div>
        <p className="text-white mt-4">Loading financial data...</p>
        <style jsx global>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
          .inline-block {
            animation: spin 1s linear infinite;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Enhanced Key Metrics with Brand Gradient Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Current Balance"
          value={`£${financialData.current_balance?.toLocaleString() || "0"}`}
          icon={DollarSign}
          trend="up"
          trendValue="12%"
          gradient="from-[#B8860B] to-[#A0750A]"
        />
        <MetricCard
          title="Available Credit"
          value={`£${(invoiceData?.total_available_value || 0).toLocaleString()}`}
          icon={CreditCard}
          trend="up"
          trendValue="8%"
          gradient="from-[#00D9FF] to-[#00B8DB]"
        />
        <MetricCard
          title="Financial Health"
          value={`${aiAnalysis?.financial_health_score || 75}/100`}
          icon={Target}
          trend="up"
          trendValue="5%"
          gradient="from-[#1D2B3D] to-[#2C3E50]"
        />
        <MetricCard
          title="Risk Score"
          value="Low"
          icon={Shield}
          trend="down"
          trendValue="3%"
          gradient="from-[#B8860B] to-[#8B6914]"
        />
      </div>

      {/* Enhanced Cash Flow & Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-[#B8860B]" />
            Cash Flow Trend
          </h3>
          <div className="space-y-4">
            {financialData.cash_flow_trend?.slice(0, 6).map((week, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-[#B8860B]/10"
              >
                <span className="text-sm text-gray-300">
                  Week {new Date(week.week).toLocaleDateString()}
                </span>
                <div className="flex items-center space-x-2">
                  <span
                    className={`text-sm font-bold ${parseFloat(week.net_flow) >= 0 ? "text-[#B8860B]" : "text-red-400"}`}
                  >
                    £{Math.abs(parseFloat(week.net_flow)).toLocaleString()}
                  </span>
                  {parseFloat(week.net_flow) >= 0 ? (
                    <ArrowUpRight className="h-5 w-5 text-[#B8860B]" />
                  ) : (
                    <ArrowDownRight className="h-5 w-5 text-red-400" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#00D9FF]/20 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Bot className="h-6 w-6 text-[#00D9FF]" />
            AI Insights
          </h3>
          <div className="space-y-3">
            {financialData.ai_insights?.recommendations
              ?.slice(0, 4)
              .map((insight, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-3 p-3 bg-[#00D9FF]/10 border border-[#00D9FF]/20 rounded-xl"
                >
                  <Zap className="h-5 w-5 text-[#00D9FF] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-200">{insight}</span>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* Enhanced Recent Transactions */}
      <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl overflow-hidden">
        <div className="px-6 py-5 border-b border-[#B8860B]/10 bg-gradient-to-r from-[#B8860B]/10 to-transparent">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="h-6 w-6 text-[#B8860B]" />
            Recent Transactions
          </h3>
        </div>
        <div className="p-6">
          <div className="space-y-3">
            {financialData.recent_transactions
              ?.slice(0, 5)
              .map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between py-4 px-4 bg-white/5 rounded-xl hover:bg-white/10 transition border border-[#B8860B]/10"
                >
                  <div className="flex items-center space-x-4">
                    <div
                      className={`p-3 rounded-xl ${
                        transaction.transaction_type === "deposit"
                          ? "bg-[#B8860B]/20 border border-[#B8860B]/30"
                          : "bg-red-500/20 border border-red-400/30"
                      }`}
                    >
                      {transaction.transaction_type === "deposit" ? (
                        <ArrowUpRight className="h-5 w-5 text-[#B8860B]" />
                      ) : (
                        <ArrowDownRight className="h-5 w-5 text-red-400" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">
                        {transaction.transaction_type === "deposit"
                          ? "Deposit"
                          : "Withdrawal"}
                      </p>
                      <p className="text-xs text-gray-400">
                        {transaction.description}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-sm font-bold ${
                        transaction.transaction_type === "deposit"
                          ? "text-[#B8860B]"
                          : "text-red-400"
                      }`}
                    >
                      {transaction.transaction_type === "deposit" ? "+" : "-"}£
                      {parseFloat(transaction.amount).toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-400">
                      {new Date(transaction.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AIFinancialAdvisor({ aiAnalysis, onRefreshAnalysis }) {
  const [selectedAction, setSelectedAction] = useState("overview");

  if (!aiAnalysis) {
    return (
      <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-8 text-center">
        <div className="inline-block h-12 w-12 border-t-2 border-b-2 border-[#B8860B] rounded-full"></div>
        <p className="text-white mt-4">Loading AI analysis...</p>
        <style jsx global>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
          .inline-block {
            animation: spin 1s linear infinite;
          }
        `}</style>
      </div>
    );
  }

  const actions = [
    { id: "overview", label: "Financial Overview", icon: PieChart },
    { id: "recommendations", label: "Strategic Recommendations", icon: Target },
    { id: "risk", label: "Risk Assessment", icon: AlertTriangle },
    { id: "optimization", label: "Capital Optimization", icon: Zap },
  ];

  return (
    <div className="space-y-6">
      {/* AI Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              onClick={() => setSelectedAction(action.id)}
              className={`p-4 rounded-xl border text-center transition-all ${
                selectedAction === action.id
                  ? "border-[#B8860B] bg-[#B8860B]/20 text-white shadow-lg shadow-[#B8860B]/30"
                  : "border-[#1D2B3D] bg-[#1D2B3D]/30 text-gray-300 hover:border-[#B8860B]/50"
              }`}
            >
              <Icon
                className={`h-6 w-6 mx-auto mb-2 ${selectedAction === action.id ? "text-[#B8860B]" : "text-gray-400"}`}
              />
              <span className="text-sm font-medium">{action.label}</span>
            </button>
          );
        })}
      </div>

      {/* AI Analysis Results */}
      <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">
            AI Analysis Results
          </h3>
          <button
            onClick={onRefreshAnalysis}
            className="text-[#00D9FF] hover:text-[#B8860B] text-sm font-medium transition"
          >
            Refresh Analysis
          </button>
        </div>

        {selectedAction === "overview" && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-white mb-2">
                  Financial Health Score
                </h4>
                <div className="flex items-center space-x-3">
                  <div className="w-32 bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-[#B8860B] h-2 rounded-full"
                      style={{ width: `${aiAnalysis.financial_health_score}%` }}
                    ></div>
                  </div>
                  <span className="font-medium text-white">
                    {aiAnalysis.financial_health_score}/100
                  </span>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-white mb-2">
                  Liquidity Status
                </h4>
                <span
                  className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${
                    aiAnalysis.liquidity_assessment?.liquidity_status ===
                    "excellent"
                      ? "bg-[#B8860B]/20 text-[#B8860B] border border-[#B8860B]/30"
                      : aiAnalysis.liquidity_assessment?.liquidity_status ===
                          "good"
                        ? "bg-[#00D9FF]/20 text-[#00D9FF] border border-[#00D9FF]/30"
                        : "bg-yellow-500/20 text-yellow-400 border border-yellow-400/30"
                  }`}
                >
                  {aiAnalysis.liquidity_assessment?.liquidity_status || "Good"}
                </span>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-white mb-3">Key AI Insights</h4>
              <div className="space-y-2">
                {aiAnalysis.ai_insights?.key_insights?.map((insight, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <Bot className="h-4 w-4 text-[#00D9FF] mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-300">{insight}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {selectedAction === "recommendations" && (
          <div className="space-y-4">
            <h4 className="font-medium text-white">Recommended Actions</h4>
            <div className="space-y-3">
              {aiAnalysis.ai_insights?.recommended_actions?.map(
                (action, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-3 p-3 bg-[#00D9FF]/10 border border-[#00D9FF]/20 rounded-xl"
                  >
                    <CheckCircle className="h-5 w-5 text-[#00D9FF] flex-shrink-0" />
                    <span className="text-sm text-gray-200">{action}</span>
                  </div>
                ),
              )}
            </div>

            <h4 className="font-medium text-white mt-6">
              Growth Opportunities
            </h4>
            <div className="space-y-3">
              {aiAnalysis.ai_insights?.growth_opportunities?.map(
                (opportunity, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-3 p-3 bg-[#B8860B]/10 border border-[#B8860B]/20 rounded-xl"
                  >
                    <TrendingUp className="h-5 w-5 text-[#B8860B] flex-shrink-0" />
                    <span className="text-sm text-gray-200">{opportunity}</span>
                  </div>
                ),
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ComplianceOverview() {
  const complianceItems = [
    {
      name: "GDPR Compliance",
      status: "compliant",
      description: "Data protection and privacy compliance",
    },
    {
      name: "PCI DSS",
      status: "compliant",
      description: "Payment card industry security standards",
    },
    {
      name: "AML/KYC",
      status: "compliant",
      description: "Anti-money laundering and know your customer",
    },
    {
      name: "Biometric Data Protection",
      status: "compliant",
      description: "BIPA and EU biometric data laws",
    },
    {
      name: "Financial Reporting",
      status: "compliant",
      description: "Regulatory financial reporting compliance",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-2xl p-6">
        <div className="flex items-center space-x-3">
          <CheckCircle className="h-6 w-6 text-[#B8860B]" />
          <div>
            <h3 className="text-lg font-semibold text-white">
              Compliance Status: Fully Compliant
            </h3>
            <p className="text-sm text-gray-300">
              All regulatory requirements are currently met
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {complianceItems.map((item, index) => (
          <div
            key={index}
            className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold text-white">{item.name}</h4>
              <span
                className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                  item.status === "compliant"
                    ? "bg-[#B8860B]/20 text-[#B8860B] border border-[#B8860B]/30"
                    : "bg-red-500/20 text-red-400 border border-red-400/30"
                }`}
              >
                {item.status === "compliant" ? "Compliant" : "Non-Compliant"}
              </span>
            </div>
            <p className="text-sm text-gray-400">{item.description}</p>
          </div>
        ))}
      </div>

      <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Data Protection & Privacy
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-white mb-2">
              Encryption Standards
            </h4>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• AES-256 encryption at rest</li>
              <li>• TLS 1.3 encryption in transit</li>
              <li>• End-to-end encryption for sensitive data</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-white mb-2">Access Controls</h4>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Role-based access control (RBAC)</li>
              <li>• Multi-factor authentication</li>
              <li>• Regular access reviews</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, trendValue, gradient }) {
  return (
    <div
      className={`bg-gradient-to-br ${gradient} rounded-2xl p-6 shadow-xl border border-[#B8860B]/20`}
    >
      <div className="flex items-center justify-between mb-4">
        <Icon className="h-10 w-10 text-white" />
        {trend && (
          <div className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-lg">
            {trend === "up" ? (
              <TrendingUp className="h-4 w-4 text-white" />
            ) : (
              <TrendingDown className="h-4 w-4 text-white" />
            )}
            <span className="text-sm font-bold text-white">{trendValue}</span>
          </div>
        )}
      </div>
      <div>
        <p className="text-sm font-medium text-white/80 mb-1">{title}</p>
        <p className="text-3xl font-bold text-white">{value}</p>
      </div>
    </div>
  );
}
