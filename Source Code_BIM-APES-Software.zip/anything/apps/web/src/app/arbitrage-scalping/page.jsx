"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function ArbitrageScalpingDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("arbitrage");
  const [arbitrageEvents, setArbitrageEvents] = useState([]);
  const [scalpingMoments, setScalpingMoments] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadArbitrageEvents();
      loadScalpingMoments();
    }
  }, [user]);

  const loadArbitrageEvents = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/arbitrage/capture?is_resolved=false");
      const data = await res.json();
      setArbitrageEvents(data.events || []);
    } catch (error) {
      console.error("Error loading arbitrage events:", error);
    }
    setLoading(false);
  };

  const loadScalpingMoments = async () => {
    try {
      const res = await fetch("/api/scalping/capture");
      const data = await res.json();
      setScalpingMoments(data.moments || []);
    } catch (error) {
      console.error("Error loading scalping moments:", error);
    }
  };

  if (userLoading || !user)
    return (
      <div className="min-h-screen bg-[#0A0F1E] flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );

  return (
    <div className="min-h-screen bg-[#0A0F1E] text-white">
      {/* Header */}
      <div className="border-b border-[#1E293B] bg-gradient-to-r from-[#0F172A] to-[#1E293B]">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold mb-2">Arbitrage & Scalping</h1>
          <p className="text-gray-400">
            Real-Time Event Capture, Tier Gaps, Micro-Moments
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab("arbitrage")}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === "arbitrage"
                ? "bg-[#C4A661] text-black"
                : "bg-[#1E293B] text-gray-400 hover:bg-[#2D3B52]"
            }`}
          >
            Arbitrage Events
          </button>
          <button
            onClick={() => setActiveTab("scalping")}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === "scalping"
                ? "bg-[#C4A661] text-black"
                : "bg-[#1E293B] text-gray-400 hover:bg-[#2D3B52]"
            }`}
          >
            Scalping Moments
          </button>
        </div>

        {activeTab === "arbitrage" && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                <div className="col-span-full text-center py-12 text-gray-400">
                  Loading events...
                </div>
              ) : arbitrageEvents.length === 0 ? (
                <div className="col-span-full bg-[#1E293B] rounded-xl p-12 text-center">
                  <p className="text-gray-400">No active arbitrage events</p>
                </div>
              ) : (
                arbitrageEvents.map((event) => (
                  <div key={event.id} className="bg-[#1E293B] rounded-xl p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-bold text-lg mb-1">
                          {event.event_type.replace("_", " ").toUpperCase()}
                        </h3>
                        <div className="text-sm text-gray-400">
                          {new Date(event.captured_at).toLocaleString()}
                        </div>
                      </div>
                      <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-xs font-medium">
                        Active
                      </span>
                    </div>

                    <div className="space-y-2 text-sm">
                      {event.current_tier && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Current Tier</span>
                          <span className="font-medium">
                            {event.current_tier}
                          </span>
                        </div>
                      )}
                      {event.expected_tier && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Expected Tier</span>
                          <span className="font-medium text-[#C4A661]">
                            {event.expected_tier}
                          </span>
                        </div>
                      )}
                      {event.attention_value && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Attention Value</span>
                          <span className="font-medium text-green-400">
                            $
                            {parseFloat(event.attention_value).toLocaleString()}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-gray-400">Capture Window</span>
                        <span>{event.capture_window_seconds}s</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-[#334155]">
                      <button className="w-full bg-[#C4A661] text-black font-bold py-2 rounded-lg hover:bg-[#D4B671] transition-all text-sm">
                        Capture Arbitrage
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === "scalping" && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {scalpingMoments.length === 0 ? (
                <div className="col-span-full bg-[#1E293B] rounded-xl p-12 text-center">
                  <p className="text-gray-400">No scalping moments captured</p>
                </div>
              ) : (
                scalpingMoments.map((moment) => (
                  <div key={moment.id} className="bg-[#1E293B] rounded-xl p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          moment.moment_type === "dunk"
                            ? "bg-orange-500/20 text-orange-400"
                            : moment.moment_type === "sprint"
                              ? "bg-blue-500/20 text-blue-400"
                              : moment.moment_type === "highlight"
                                ? "bg-purple-500/20 text-purple-400"
                                : moment.moment_type === "recovery"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                        }`}
                      >
                        {moment.moment_type}
                      </span>
                      <span className="text-2xl">
                        {moment.moment_type === "dunk"
                          ? "🏀"
                          : moment.moment_type === "sprint"
                            ? "⚡"
                            : moment.moment_type === "highlight"
                              ? "⭐"
                              : moment.moment_type === "recovery"
                                ? "💚"
                                : "🎯"}
                      </span>
                    </div>

                    <div className="mb-3">
                      <div className="text-xs text-gray-400 mb-1">
                        Intensity
                      </div>
                      <div className="w-full bg-[#0F172A] rounded-full h-2">
                        <div
                          className="bg-[#C4A661] h-2 rounded-full"
                          style={{
                            width: `${parseFloat(moment.moment_intensity) * 100}%`,
                          }}
                        />
                      </div>
                      <div className="text-right text-xs text-gray-500 mt-1">
                        {(parseFloat(moment.moment_intensity) * 100).toFixed(0)}
                        %
                      </div>
                    </div>

                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Spotlight</span>
                        <span className="text-orange-400">
                          {parseFloat(moment.spotlight_credits).toFixed(0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Event Window</span>
                        <span className="text-blue-400">
                          {parseFloat(moment.event_window_credits).toFixed(0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Boost</span>
                        <span className="text-purple-400">
                          {parseFloat(moment.boost_credits).toFixed(0)}
                        </span>
                      </div>
                      <div className="flex justify-between font-medium">
                        <span className="text-gray-400">Engagement Spike</span>
                        <span className="text-green-400">
                          +{moment.engagement_spike}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-[#334155] text-xs text-gray-500">
                      {new Date(moment.captured_at).toLocaleString()}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
