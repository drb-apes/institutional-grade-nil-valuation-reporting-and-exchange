"use client";

import { useState, useEffect } from "react";
import {
  Play,
  CheckCircle2,
  Circle,
  Copy,
  Check,
  ChevronRight,
  ChevronLeft,
  Trophy,
  Zap,
  Code,
  Database,
  TrendingUp,
  Shield,
  Rocket,
  Star,
  Target,
  Award,
  Send,
  RefreshCw,
  Eye,
  EyeOff,
  AlertCircle,
  Info,
} from "lucide-react";

export default function BIMAPESInteractiveTutorial() {
  const [currentTutorial, setCurrentTutorial] = useState("getting-started");
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState({});
  const [copiedCode, setCopiedCode] = useState(null);
  const [showApiKey, setShowApiKey] = useState(false);
  const [tutorialProgress, setTutorialProgress] = useState({});

  // Load progress from localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("bim-apes-tutorial-progress");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setCompletedSteps(parsed.completedSteps || {});
          setTutorialProgress(parsed.tutorialProgress || {});
        } catch (e) {
          console.error("Failed to load progress:", e);
        }
      }
    }
  }, []);

  // Save progress to localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem(
        "bim-apes-tutorial-progress",
        JSON.stringify({
          completedSteps,
          tutorialProgress,
        }),
      );
    }
  }, [completedSteps, tutorialProgress]);

  const tutorials = [
    {
      id: "getting-started",
      title: "Getting Started",
      icon: Rocket,
      description: "Set up your BIM APES account and get oriented",
      difficulty: "Beginner",
      duration: "5 min",
      steps: [
        {
          title: "Create Your Account",
          content:
            "Start by creating your BIM APES account. Choose your user type based on your goals.",
          action: "account-creation",
          tips: [
            "Developers: Get API access immediately",
            "Investors: Access trading dashboard",
            "Institutions: Multi-user tenant setup",
          ],
        },
        {
          title: "Complete Email Verification",
          content:
            "Check your email and click the verification link to activate your account.",
          action: "email-verification",
          tips: [
            "Check spam folder if not received",
            "Link expires in 24 hours",
            "Resend available from login page",
          ],
        },
        {
          title: "Configure Your Profile",
          content:
            "Set up your preferences, notification settings, and user type.",
          action: "profile-setup",
          tips: [
            "Enable 2FA for enhanced security",
            "Set notification preferences",
            "Link payment method if investing",
          ],
        },
        {
          title: "Explore the Dashboard",
          content:
            "Take a tour of your personalized dashboard and familiarize yourself with key features.",
          action: "dashboard-tour",
          tips: [
            "Check the navigation menu",
            "Review available modules",
            "Bookmark key pages",
          ],
        },
      ],
    },
    {
      id: "first-api-call",
      title: "Your First API Call",
      icon: Code,
      description: "Learn to authenticate and make your first API request",
      difficulty: "Beginner",
      duration: "10 min",
      steps: [
        {
          title: "Generate API Key",
          content:
            "Navigate to Settings → API Keys and generate your first API key.",
          action: "generate-api-key",
          code: `// Your API key will look like this:
const API_KEY = "bim_live_abc123def456...";

// Store it securely - never commit to version control
// Use environment variables in production`,
          tips: [
            "Copy and save immediately - won't be shown again",
            "Use sandbox keys for testing",
            "Rotate keys regularly for security",
          ],
        },
        {
          title: "Test Authentication",
          content:
            "Make a simple authenticated request to verify your API key works.",
          action: "test-auth",
          code: `const response = await fetch('${typeof window !== "undefined" ? window.location.origin : ""}/api/athletes/list', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
});

const data = await response.json();
console.log('Success!', data);`,
          tips: [
            "Use Postman or curl for quick testing",
            "Check response status codes",
            "Review error messages carefully",
          ],
        },
        {
          title: "Handle API Response",
          content: "Parse the JSON response and handle potential errors.",
          action: "handle-response",
          code: `try {
  const response = await fetch('/api/athletes/list', {
    headers: { 'Authorization': 'Bearer YOUR_API_KEY' }
  });
  
  if (!response.ok) {
    throw new Error(\`API error: \${response.status}\`);
  }
  
  const data = await response.json();
  console.log(\`Found \${data.athletes.length} athletes\`);
} catch (error) {
  console.error('Request failed:', error.message);
}`,
          tips: [
            "Always check response.ok",
            "Log errors for debugging",
            "Implement retry logic for production",
          ],
        },
      ],
    },
    {
      id: "calculate-bim",
      title: "Calculate BIM Score",
      icon: Database,
      description: "Submit biometric data and calculate performance scores",
      difficulty: "Intermediate",
      duration: "15 min",
      steps: [
        {
          title: "Understand BIM Inputs",
          content:
            "Learn which metrics are required for your sport's BIM calculation.",
          action: "bim-inputs",
          tips: [
            "Wrestling: takedownEfficiency, controlTime, pinRate, staminaIndex",
            "Basketball: shotAccuracy, reboundRate, assistRatio, defensiveRating",
            "Football: completionRate, yardsPerCarry, tackleEfficiency, staminaIndex",
          ],
        },
        {
          title: "Prepare Sample Data",
          content:
            "Structure your biometric data in the correct format for the API.",
          action: "prepare-data",
          code: `const biomechanicsData = {
  sport: "wrestling",
  athleteId: 123,
  sessionDate: "2026-02-17",
  metrics: {
    takedownEfficiency: 0.87,    // 87% success rate
    controlTime: 145,             // seconds
    pinRate: 0.62,                // 62% pin success
    staminaIndex: 0.91            // 91% endurance
  },
  deviceType: "whoop_4",
  sessionType: "competition"
};`,
          tips: [
            "Metrics should be normalized (0-1 scale where applicable)",
            "Include session context for better insights",
            "Verify device compatibility",
          ],
        },
        {
          title: "Submit BIM Calculation",
          content: "Send a POST request to calculate the BIM score.",
          action: "submit-calculation",
          code: `const response = await fetch('/api/bim-performance/calculate', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(biomechanicsData)
});

const result = await response.json();
console.log('BIM Score:', result.bimScore);
console.log('Tier:', result.tier);
console.log('Insights:', result.insights);`,
          tips: [
            "BIM scores range from 0-100",
            "Tier assigned: Bronze, Silver, Gold, Platinum, Diamond",
            "Review insights for performance breakdown",
          ],
        },
        {
          title: "Interpret Results",
          content:
            "Understand the BIM score components and tier classification.",
          action: "interpret-results",
          code: `// Sample response structure
{
  "bimScore": 84.7,
  "tier": "Platinum",
  "components": {
    "power": 30.45,      // takedownEfficiency × 0.35
    "technique": 33.60,  // (controlTime + pinRate) × 0.40
    "endurance": 22.75   // staminaIndex × 0.25
  },
  "insights": {
    "strengths": ["Exceptional stamina", "High control time"],
    "areas_for_improvement": ["Increase pin conversion rate"],
    "tier_advancement_distance": 5.3  // points to Diamond
  }
}`,
          tips: [
            "Compare components to identify strengths",
            "Track progress over multiple sessions",
            "Use insights for targeted training",
          ],
        },
      ],
    },
    {
      id: "execute-trade",
      title: "Execute Your First Trade",
      icon: TrendingUp,
      description: "Browse athletes and execute a performance equity trade",
      difficulty: "Intermediate",
      duration: "12 min",
      steps: [
        {
          title: "Browse Available Athletes",
          content: "Query the athlete database to find trading opportunities.",
          action: "browse-athletes",
          code: `const response = await fetch('/api/athletes/list?sport=wrestling&tier=Platinum&limit=10', {
  headers: { 'Authorization': 'Bearer YOUR_API_KEY' }
});

const { athletes } = await response.json();
athletes.forEach(athlete => {
  console.log(\`\${athlete.name} - BIM: \${athlete.bimScore} - Tier: \${athlete.tier}\`);
});`,
          tips: [
            "Filter by sport, tier, or growth trajectory",
            "Review recent performance history",
            "Check liquidity and trading volume",
          ],
        },
        {
          title: "Analyze Athlete Profile",
          content: "Review detailed performance metrics and risk assessment.",
          action: "analyze-athlete",
          tips: [
            "30-day BIM trend (upward/downward)",
            "Consistency rating (volatility)",
            "NIL valuation estimate",
            "Injury history and risk score",
          ],
        },
        {
          title: "Determine Position Size",
          content:
            "Calculate appropriate investment amount based on your strategy.",
          action: "position-sizing",
          code: `// Conservative approach: 5-10% of portfolio per athlete
const portfolioValue = 10000;  // $10,000 total
const positionPercent = 0.08;  // 8% allocation
const positionSize = portfolioValue * positionPercent;  // $800

// Apply Kelly Criterion for optimal sizing
const winProbability = 0.65;  // 65% success rate
const avgWin = 1.5;            // 50% average gain
const avgLoss = 1.0;           // 100% average loss
const kellyPercent = (winProbability * avgWin - (1 - winProbability)) / avgWin;
const kellyPositionSize = portfolioValue * kellyPercent;`,
          tips: [
            "Never risk more than 10% on single athlete",
            "Diversify across multiple sports/tiers",
            "Consider correlation between athletes",
          ],
        },
        {
          title: "Execute the Trade",
          content: "Submit your trade order to the platform.",
          action: "execute-trade",
          code: `const tradeRequest = {
  athleteId: 123,
  amount: 800,           // $800 position
  direction: "long",     // or "short" to bet against
  orderType: "market",   // or "limit" with price
  stopLoss: 0.15         // Exit if down 15%
};

const response = await fetch('/api/trades/execute', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(tradeRequest)
});

const trade = await response.json();
console.log('Trade ID:', trade.tradeId);
console.log('Execution Price:', trade.executionPrice);
console.log('Status:', trade.status);`,
          tips: [
            "Use market orders for immediate execution",
            "Set stop-loss to limit downside risk",
            "Review execution price and slippage",
          ],
        },
        {
          title: "Monitor Your Position",
          content: "Track performance and manage your active position.",
          action: "monitor-position",
          tips: [
            "Check real-time P&L in dashboard",
            "Set alerts for BIM score changes",
            "Rebalance if allocation drifts",
            "Close position when targets hit",
          ],
        },
      ],
    },
    {
      id: "hedging-strategy",
      title: "Set Up Hedging Positions",
      icon: Shield,
      description: "Protect your portfolio with insurance and hedging",
      difficulty: "Advanced",
      duration: "20 min",
      steps: [
        {
          title: "Understand Hedging Types",
          content: "Learn the different hedging instruments available.",
          action: "hedging-types",
          tips: [
            "Injury Hedging: Insurance against athlete injuries",
            "Underperformance Hedging: Protection if BIM score drops",
            "Volatility Hedging: Profit from performance swings",
            "Tier Demotion Hedging: Guard against tier downgrades",
          ],
        },
        {
          title: "Calculate Hedge Ratio",
          content:
            "Determine appropriate hedge size relative to your exposure.",
          action: "hedge-ratio",
          code: `// Portfolio Exposure
const athletePosition = 2000;  // $2,000 long position
const currentBIM = 85.0;
const athleteTier = "Platinum";

// Hedge Sizing
const hedgeRatio = 0.30;  // Hedge 30% of position
const hedgeAmount = athletePosition * hedgeRatio;  // $600

// Cost-Benefit Analysis
const hedgeCost = hedgeAmount * 0.05;  // 5% premium = $30
const maxProtectedLoss = hedgeAmount;  // Protected up to $600
const breakEvenMove = hedgeCost / athletePosition;  // 1.5% move needed`,
          tips: [
            "Full hedges (100%) are costly - use partial hedges",
            "Balance cost vs. protection level",
            "Consider correlation with other positions",
          ],
        },
        {
          title: "Create Injury Hedge",
          content: "Purchase insurance against athlete injury events.",
          action: "injury-hedge",
          code: `const injuryHedge = {
  athleteId: 123,
  hedgeType: "injury",
  coverage: 600,         // $600 max payout
  premium: 30,           // $30 cost
  duration: 90,          // 90 days coverage
  triggers: {
    minInjurySeverity: "moderate",  // excludes minor injuries
    excludedTypes: ["common_cold"]  // policy exclusions
  }
};

const response = await fetch('/api/hedging/create', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(injuryHedge)
});

const hedge = await response.json();
console.log('Hedge ID:', hedge.hedgeId);
console.log('Coverage Active Until:', hedge.expiresAt);`,
          tips: [
            "Read policy exclusions carefully",
            "Medical verification required for claims",
            "Seasonal pricing - higher during competition season",
          ],
        },
        {
          title: "Monitor Hedge Performance",
          content: "Track active hedges and evaluate effectiveness.",
          action: "monitor-hedges",
          tips: [
            "Review hedge status in risk dashboard",
            "Compare hedged vs. unhedged returns",
            "Adjust coverage as exposure changes",
            "Let hedges expire if athlete improves",
          ],
        },
      ],
    },
    {
      id: "portfolio-building",
      title: "Build Multi-Athlete Portfolio",
      icon: Target,
      description: "Construct a diversified performance equity portfolio",
      difficulty: "Advanced",
      duration: "25 min",
      steps: [
        {
          title: "Define Investment Strategy",
          content: "Choose your portfolio approach and risk tolerance.",
          action: "strategy-definition",
          tips: [
            "Conservative: 70% Gold/Platinum, 30% Silver, 0% Bronze",
            "Balanced: 50% Platinum, 30% Gold, 20% Silver",
            "Aggressive: 40% Diamond, 30% Platinum, 30% high-growth athletes",
          ],
        },
        {
          title: "Select Athletes",
          content: "Build a diversified roster across sports and tiers.",
          action: "athlete-selection",
          code: `// Portfolio Construction Rules
const portfolio = {
  maxAthletes: 15,           // 15-20 athletes for diversification
  minAthletes: 10,
  maxPerSport: 0.40,         // No more than 40% in one sport
  maxPerTier: 0.50,          // No more than 50% in one tier
  maxSinglePosition: 0.10,   // 10% max per athlete
  minSinglePosition: 0.03    // 3% minimum to make impact
};

// Sample Allocation
const allocation = [
  { athleteId: 1, sport: "wrestling", tier: "Platinum", weight: 0.08 },
  { athleteId: 2, sport: "basketball", tier: "Gold", weight: 0.07 },
  { athleteId: 3, sport: "football", tier: "Diamond", weight: 0.10 },
  // ... 12 more athletes
];`,
          tips: [
            "Avoid concentration in single sport",
            "Mix stable performers with high-growth prospects",
            "Consider seasonal timing (off-season vs. competition)",
          ],
        },
        {
          title: "Backtest Strategy",
          content: "Simulate portfolio performance using historical data.",
          action: "backtest",
          tips: [
            "Test against last 12 months of data",
            "Calculate Sharpe ratio and max drawdown",
            "Stress test with injury scenarios",
            "Compare to benchmark (average athlete index)",
          ],
        },
        {
          title: "Execute Portfolio",
          content: "Batch execute all positions at optimal prices.",
          action: "batch-execution",
          code: `const portfolioOrders = allocation.map(position => ({
  athleteId: position.athleteId,
  amount: totalCapital * position.weight,
  direction: "long",
  orderType: "market"
}));

// Execute all trades in parallel
const trades = await Promise.all(
  portfolioOrders.map(order =>
    fetch('/api/trades/execute', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer YOUR_API_KEY',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(order)
    }).then(r => r.json())
  )
);

console.log(\`Executed \${trades.length} trades\`);
console.log('Total Value:', trades.reduce((sum, t) => sum + t.amount, 0));`,
          tips: [
            "Execute during low-volatility periods",
            "Monitor execution quality and slippage",
            "Confirm all trades completed successfully",
          ],
        },
        {
          title: "Set Rebalancing Rules",
          content: "Configure automatic portfolio rebalancing.",
          action: "rebalancing",
          tips: [
            "Rebalance when allocation drifts >5% from target",
            "Consider tax implications when rebalancing",
            "Monthly or quarterly rebalancing cadence",
            "Avoid over-trading - set meaningful thresholds",
          ],
        },
      ],
    },
  ];

  const currentTutorialData = tutorials.find((t) => t.id === currentTutorial);
  const currentStepData = currentTutorialData?.steps[currentStep];

  const handleStepComplete = () => {
    const stepKey = `${currentTutorial}-${currentStep}`;
    setCompletedSteps((prev) => ({ ...prev, [stepKey]: true }));

    // If this is the last step, mark tutorial as complete
    if (currentStep === currentTutorialData.steps.length - 1) {
      setTutorialProgress((prev) => ({
        ...prev,
        [currentTutorial]: {
          completed: true,
          completedAt: new Date().toISOString(),
        },
      }));
    }
  };

  const handleNextStep = () => {
    if (currentStep < currentTutorialData.steps.length - 1) {
      handleStepComplete();
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleCopyCode = (code) => {
    if (typeof window !== "undefined") {
      navigator.clipboard.writeText(code);
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
    }
  };

  const calculateProgress = (tutorialId) => {
    const tutorial = tutorials.find((t) => t.id === tutorialId);
    if (!tutorial) return 0;

    let completed = 0;
    tutorial.steps.forEach((_, index) => {
      if (completedSteps[`${tutorialId}-${index}`]) completed++;
    });

    return Math.round((completed / tutorial.steps.length) * 100);
  };

  const totalCompleted = tutorials.filter(
    (t) => tutorialProgress[t.id]?.completed,
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50]">
      {/* Header */}
      <header className="bg-[#1D2B3D]/80 backdrop-blur-lg border-b-2 border-[#B8860B]">
        <div className="max-w-[1600px] mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-gradient-to-br from-[#B8860B] to-[#FFD700] rounded-xl flex items-center justify-center shadow-lg shadow-[#B8860B]/50">
                <Play className="w-8 h-8 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white mb-1">
                  Interactive BIM APES Tutorial
                </h1>
                <p className="text-[#B8860B] font-medium">
                  Hands-on learning with step-by-step guidance
                </p>
              </div>
            </div>

            {/* Overall Progress */}
            <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/20 rounded-xl px-6 py-3">
              <div className="flex items-center gap-4">
                <Trophy className="w-6 h-6 text-[#B8860B]" />
                <div>
                  <div className="text-white font-semibold text-lg">
                    {totalCompleted} / {tutorials.length}
                  </div>
                  <div className="text-gray-400 text-xs">
                    Tutorials Completed
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-[1600px] mx-auto px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Tutorial Selection Sidebar */}
          <aside className="lg:col-span-1">
            <div className="sticky top-8 space-y-4">
              {/* Progress Summary */}
              <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-5">
                <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                  <Star className="w-4 h-4 text-[#B8860B]" />
                  Your Progress
                </h3>
                <div className="space-y-3">
                  {tutorials.map((tutorial) => {
                    const progress = calculateProgress(tutorial.id);
                    const isComplete = tutorialProgress[tutorial.id]?.completed;

                    return (
                      <div key={tutorial.id} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-300 text-sm">
                            {tutorial.title}
                          </span>
                          {isComplete && (
                            <Award className="w-4 h-4 text-[#B8860B]" />
                          )}
                        </div>
                        <div className="w-full bg-[#1A1F3A] h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-[#B8860B] h-full rounded-full transition-all duration-500"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tutorial List */}
              <nav className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-4">
                <h3 className="text-white font-bold mb-4">Select Tutorial</h3>
                <div className="space-y-2">
                  {tutorials.map((tutorial) => {
                    const Icon = tutorial.icon;
                    const isActive = tutorial.id === currentTutorial;
                    const isComplete = tutorialProgress[tutorial.id]?.completed;

                    return (
                      <button
                        key={tutorial.id}
                        onClick={() => {
                          setCurrentTutorial(tutorial.id);
                          setCurrentStep(0);
                        }}
                        className={`w-full text-left px-4 py-3 rounded-lg transition-all ${
                          isActive
                            ? "bg-[#B8860B] text-black"
                            : "bg-[#1A1F3A]/30 text-gray-300 hover:bg-[#1A1F3A]/50"
                        }`}
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <Icon
                            className={`w-5 h-5 ${isActive ? "text-black" : "text-[#B8860B]"}`}
                          />
                          <span className="font-medium text-sm">
                            {tutorial.title}
                          </span>
                          {isComplete && (
                            <CheckCircle2 className="w-4 h-4 ml-auto" />
                          )}
                        </div>
                        <div
                          className={`flex items-center gap-3 text-xs ${
                            isActive ? "text-black/70" : "text-gray-500"
                          }`}
                        >
                          <span className="px-2 py-0.5 bg-black/10 rounded">
                            {tutorial.difficulty}
                          </span>
                          <span>{tutorial.duration}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </nav>
            </div>
          </aside>

          {/* Main Tutorial Content */}
          <main className="lg:col-span-3">
            {/* Tutorial Header */}
            <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-6 mb-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    {currentTutorialData?.title}
                  </h2>
                  <p className="text-gray-400">
                    {currentTutorialData?.description}
                  </p>
                </div>
                <div className="flex gap-2">
                  <span className="px-3 py-1 bg-[#B8860B]/20 text-[#B8860B] border border-[#B8860B]/30 rounded-full text-sm font-medium">
                    {currentTutorialData?.difficulty}
                  </span>
                  <span className="px-3 py-1 bg-[#00D9FF]/20 text-[#00D9FF] border border-[#00D9FF]/30 rounded-full text-sm font-medium">
                    {currentTutorialData?.duration}
                  </span>
                </div>
              </div>

              {/* Step Progress Bar */}
              <div className="flex items-center gap-2">
                {currentTutorialData?.steps.map((_, index) => {
                  const stepKey = `${currentTutorial}-${index}`;
                  const isCompleted = completedSteps[stepKey];
                  const isCurrent = index === currentStep;

                  return (
                    <div key={index} className="flex-1">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          isCompleted
                            ? "bg-[#B8860B]"
                            : isCurrent
                              ? "bg-[#B8860B]/50"
                              : "bg-[#1A1F3A]"
                        }`}
                      />
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between mt-2">
                <span className="text-gray-400 text-sm">
                  Step {currentStep + 1} of {currentTutorialData?.steps.length}
                </span>
                <span className="text-[#B8860B] text-sm font-medium">
                  {Math.round(
                    ((currentStep + 1) / currentTutorialData?.steps.length) *
                      100,
                  )}
                  % Complete
                </span>
              </div>
            </div>

            {/* Current Step Content */}
            <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8 mb-6">
              {/* Step Title */}
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 bg-[#B8860B] text-black rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0">
                  {currentStep + 1}
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-2">
                    {currentStepData?.title}
                  </h3>
                  <p className="text-gray-300 text-lg">
                    {currentStepData?.content}
                  </p>
                </div>
              </div>

              {/* Code Block */}
              {currentStepData?.code && (
                <div className="mb-6">
                  <div className="bg-[#0A0E27] border border-[#B8860B]/20 rounded-lg overflow-hidden">
                    <div className="flex items-center justify-between px-4 py-2 bg-[#1A1F3A] border-b border-[#B8860B]/10">
                      <div className="flex items-center gap-2">
                        <Code className="w-4 h-4 text-[#B8860B]" />
                        <span className="text-gray-300 text-sm font-medium">
                          Code Example
                        </span>
                      </div>
                      <button
                        onClick={() => handleCopyCode(currentStepData.code)}
                        className="flex items-center gap-2 px-3 py-1 bg-[#B8860B]/20 hover:bg-[#B8860B]/30 text-[#B8860B] rounded transition-all"
                      >
                        {copiedCode === currentStepData.code ? (
                          <>
                            <Check className="w-4 h-4" />
                            <span className="text-xs">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            <span className="text-xs">Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="p-4 overflow-x-auto">
                      <code className="text-[#00D9FF] text-sm font-mono">
                        {currentStepData.code}
                      </code>
                    </pre>
                  </div>
                </div>
              )}

              {/* Tips Section */}
              {currentStepData?.tips && currentStepData.tips.length > 0 && (
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Zap className="w-5 h-5 text-[#B8860B]" />
                    <h4 className="text-white font-semibold">Pro Tips</h4>
                  </div>
                  <div className="space-y-2">
                    {currentStepData.tips.map((tip, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-3 bg-[#1A1F3A]/50 p-3 rounded-lg"
                      >
                        <Info className="w-4 h-4 text-[#00D9FF] mt-0.5 flex-shrink-0" />
                        <span className="text-gray-300 text-sm">{tip}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Action Area */}
              <InteractiveAction
                action={currentStepData?.action}
                onComplete={handleStepComplete}
                showApiKey={showApiKey}
                setShowApiKey={setShowApiKey}
              />

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-[#B8860B]/10">
                <button
                  onClick={handlePrevStep}
                  disabled={currentStep === 0}
                  className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all ${
                    currentStep === 0
                      ? "bg-[#1A1F3A]/30 text-gray-500 cursor-not-allowed"
                      : "bg-[#1A1F3A] hover:bg-[#1A1F3A]/80 text-white"
                  }`}
                >
                  <ChevronLeft className="w-5 h-5" />
                  Previous Step
                </button>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleStepComplete}
                    className="flex items-center gap-2 px-6 py-3 bg-[#00D9FF]/20 hover:bg-[#00D9FF]/30 text-[#00D9FF] border border-[#00D9FF]/30 rounded-lg transition-all"
                  >
                    <CheckCircle2 className="w-5 h-5" />
                    Mark as Complete
                  </button>

                  {currentStep < currentTutorialData.steps.length - 1 ? (
                    <button
                      onClick={handleNextStep}
                      className="flex items-center gap-2 px-6 py-3 bg-[#B8860B] hover:bg-[#A0750A] text-black font-semibold rounded-lg transition-all shadow-lg shadow-[#B8860B]/30"
                    >
                      Next Step
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        handleStepComplete();
                        const nextTutorialIndex =
                          tutorials.findIndex((t) => t.id === currentTutorial) +
                          1;
                        if (nextTutorialIndex < tutorials.length) {
                          setCurrentTutorial(tutorials[nextTutorialIndex].id);
                          setCurrentStep(0);
                        }
                      }}
                      className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#B8860B] to-[#FFD700] hover:from-[#A0750A] hover:to-[#E5C700] text-black font-bold rounded-lg transition-all shadow-lg shadow-[#B8860B]/50"
                    >
                      <Trophy className="w-5 h-5" />
                      {tutorials.findIndex((t) => t.id === currentTutorial) ===
                      tutorials.length - 1
                        ? "Complete Tutorial!"
                        : "Next Tutorial"}
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Achievement Notification */}
            {tutorialProgress[currentTutorial]?.completed &&
              currentStep === currentTutorialData.steps.length - 1 && (
                <div className="bg-gradient-to-r from-[#B8860B]/20 to-[#FFD700]/20 border-2 border-[#B8860B] rounded-xl p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-[#B8860B] to-[#FFD700] rounded-full flex items-center justify-center">
                      <Trophy className="w-8 h-8 text-black" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-1">
                        🎉 Tutorial Complete!
                      </h3>
                      <p className="text-gray-300">
                        You've mastered{" "}
                        <span className="text-[#B8860B] font-semibold">
                          {currentTutorialData.title}
                        </span>
                        .
                        {totalCompleted === tutorials.length
                          ? " You've completed all tutorials - you're now a BIM APES expert!"
                          : " Ready for the next challenge?"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
          </main>
        </div>
      </div>
    </div>
  );
}

// Interactive Action Component
function InteractiveAction({ action, onComplete, showApiKey, setShowApiKey }) {
  const [formData, setFormData] = useState({});
  const [testResult, setTestResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!action) return null;

  // Account Creation Demo
  if (action === "account-creation") {
    return (
      <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-6">
        <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-[#B8860B]" />
          Try It: Account Setup
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-400 text-sm mb-2">
              User Type
            </label>
            <select className="w-full bg-[#0A0E27] border border-[#B8860B]/20 text-white rounded-lg px-4 py-2">
              <option>Developer (API Access)</option>
              <option>Individual Investor (Trading)</option>
              <option>Institutional Fund (Enterprise)</option>
            </select>
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">Email</label>
            <input
              type="email"
              placeholder="your.email@example.com"
              className="w-full bg-[#0A0E27] border border-[#B8860B]/20 text-white rounded-lg px-4 py-2"
            />
          </div>
          <button className="w-full bg-[#B8860B] hover:bg-[#A0750A] text-black font-semibold py-3 rounded-lg transition-all">
            Proceed to /account/signup →
          </button>
        </div>
      </div>
    );
  }

  // API Key Generation Demo
  if (action === "generate-api-key") {
    return (
      <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-6">
        <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-[#B8860B]" />
          Simulate: Generate API Key
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Key Name</label>
            <input
              type="text"
              placeholder="Production API Key"
              className="w-full bg-[#0A0E27] border border-[#B8860B]/20 text-white rounded-lg px-4 py-2"
              value={formData.keyName || ""}
              onChange={(e) =>
                setFormData({ ...formData, keyName: e.target.value })
              }
            />
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">
              Environment
            </label>
            <select
              className="w-full bg-[#0A0E27] border border-[#B8860B]/20 text-white rounded-lg px-4 py-2"
              value={formData.env || "sandbox"}
              onChange={(e) =>
                setFormData({ ...formData, env: e.target.value })
              }
            >
              <option value="sandbox">Sandbox (Testing)</option>
              <option value="production">Production (Live)</option>
            </select>
          </div>
          <button
            onClick={() => {
              const fakeKey = `bim_${formData.env || "sandbox"}_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
              setFormData({ ...formData, generatedKey: fakeKey });
            }}
            className="w-full bg-[#B8860B] hover:bg-[#A0750A] text-black font-semibold py-3 rounded-lg transition-all"
          >
            Generate API Key
          </button>

          {formData.generatedKey && (
            <div className="bg-[#0A0E27] border border-[#00D9FF]/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[#00D9FF] text-sm font-medium">
                  Your API Key (save this!)
                </span>
                <button className="flex items-center gap-1 text-[#00D9FF] text-xs hover:text-[#00D9FF]/80">
                  {showApiKey ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                  <span onClick={() => setShowApiKey(!showApiKey)}>
                    {showApiKey ? "Hide" : "Show"}
                  </span>
                </button>
              </div>
              <code className="text-[#00D9FF] text-sm font-mono block break-all">
                {showApiKey
                  ? formData.generatedKey
                  : "••••••••••••••••••••••••••••••••••••"}
              </code>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Test API Authentication
  if (action === "test-auth") {
    return (
      <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-6">
        <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-[#B8860B]" />
          Live Test: API Authentication
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-400 text-sm mb-2">API Key</label>
            <input
              type="password"
              placeholder="bim_live_..."
              className="w-full bg-[#0A0E27] border border-[#B8860B]/20 text-white rounded-lg px-4 py-2 font-mono text-sm"
            />
          </div>
          <button
            onClick={async () => {
              setIsLoading(true);
              // Simulate API call
              setTimeout(() => {
                setTestResult({ success: true, athleteCount: 247 });
                setIsLoading(false);
              }, 1500);
            }}
            disabled={isLoading}
            className="w-full bg-[#B8860B] hover:bg-[#A0750A] text-black font-semibold py-3 rounded-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Test Connection
              </>
            )}
          </button>

          {testResult && (
            <div
              className={`border rounded-lg p-4 ${
                testResult.success
                  ? "bg-green-500/10 border-green-500/30"
                  : "bg-red-500/10 border-red-500/30"
              }`}
            >
              <div className="flex items-start gap-3">
                {testResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
                )}
                <div>
                  <div
                    className={`font-semibold ${testResult.success ? "text-green-500" : "text-red-500"}`}
                  >
                    {testResult.success
                      ? "Authentication Successful!"
                      : "Authentication Failed"}
                  </div>
                  {testResult.success && (
                    <div className="text-gray-400 text-sm mt-1">
                      Retrieved {testResult.athleteCount} athletes from database
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Default interactive placeholder
  return (
    <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-6">
      <div className="flex items-center gap-3 text-gray-400">
        <Info className="w-5 h-5" />
        <span>Follow the steps above to complete this section</span>
      </div>
    </div>
  );
}
