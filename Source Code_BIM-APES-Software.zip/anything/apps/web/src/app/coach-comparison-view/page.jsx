"use client";

import { useState } from "react";
import { Users, TrendingUp, AlertCircle, Target, Activity } from "lucide-react";
import BiomechFlowCapsule, {
  CAPSULE_MODES,
} from "@/components/BiomechFlowCapsule/BiomechFlowCapsule";
import ThreeDSkeletonRenderer from "@/components/BiomechFlowCapsule/ThreeDSkeletonRenderer";
import useUser from "@/utils/useUser";

const JOINT_POSITIONS = {
  head: { x: 0, y: 1.7, z: 0 },
  neck: { x: 0, y: 1.5, z: 0 },
  shoulderLeft: { x: -0.3, y: 1.4, z: 0 },
  shoulderRight: { x: 0.3, y: 1.4, z: 0 },
  elbowLeft: { x: -0.3, y: 1.1, z: 0 },
  elbowRight: { x: 0.3, y: 1.1, z: 0 },
  wristLeft: { x: -0.3, y: 0.8, z: 0 },
  wristRight: { x: 0.3, y: 0.8, z: 0 },
  spine: { x: 0, y: 1.0, z: 0 },
  hipLeft: { x: -0.15, y: 0.9, z: 0 },
  hipRight: { x: 0.15, y: 0.9, z: 0 },
  kneeLeft: { x: -0.15, y: 0.5, z: 0 },
  kneeRight: { x: 0.15, y: 0.5, z: 0 },
  ankleLeft: { x: -0.15, y: 0.1, z: 0 },
  ankleRight: { x: 0.15, y: 0.1, z: 0 },
};

export default function CoachComparisonView() {
  const { data: user, loading } = useUser();
  const [viewMode, setViewMode] = useState("side-by-side"); // 'side-by-side' | 'overlay' | 'metrics'
  const [autoRotate, setAutoRotate] = useState(false);

  // Mock athlete data
  const athlete1 = {
    id: 1,
    name: "Marcus Johnson",
    sport: "Basketball",
    position: "Guard",
    bimScore: 87.5,
    tier: "Elite",
    capsuleData: {
      shoulderRight: {
        stressLoad: 75,
        fatigue: 60,
        nilMomentum: 85,
        recoveryVelocity: 15,
        subProbability: 25,
        injuryRisk: 65,
      },
      kneeLeft: {
        stressLoad: 85,
        fatigue: 80,
        nilMomentum: 70,
        recoveryVelocity: -10,
        subProbability: 45,
        injuryRisk: 80,
      },
      ankleRight: {
        stressLoad: 70,
        fatigue: 65,
        nilMomentum: 75,
        recoveryVelocity: 5,
        subProbability: 30,
        injuryRisk: 60,
      },
    },
    overallMetrics: {
      avgFatigue: 68,
      avgStress: 77,
      avgInjuryRisk: 68,
      nilMomentum: 77,
      recoveryScore: 45,
    },
  };

  const athlete2 = {
    id: 2,
    name: "Jamal Williams",
    sport: "Basketball",
    position: "Forward",
    bimScore: 92.3,
    tier: "Elite",
    capsuleData: {
      shoulderRight: {
        stressLoad: 45,
        fatigue: 35,
        nilMomentum: 90,
        recoveryVelocity: 25,
        subProbability: 15,
        injuryRisk: 30,
      },
      kneeLeft: {
        stressLoad: 55,
        fatigue: 50,
        nilMomentum: 85,
        recoveryVelocity: 10,
        subProbability: 20,
        injuryRisk: 45,
      },
      ankleRight: {
        stressLoad: 40,
        fatigue: 30,
        nilMomentum: 88,
        recoveryVelocity: 20,
        subProbability: 12,
        injuryRisk: 25,
      },
    },
    overallMetrics: {
      avgFatigue: 38,
      avgStress: 47,
      avgInjuryRisk: 33,
      nilMomentum: 88,
      recoveryScore: 75,
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-purple-400 underline">
            sign in
          </a>{" "}
          to access Coach Comparison View
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Users className="w-10 h-10 text-purple-400" />
          <h1 className="text-4xl font-bold text-white">
            Coach Comparison View
          </h1>
        </div>
        <p className="text-purple-200 text-lg">
          Side-by-Side BiomechFlow Analysis · Injury Risk Comparison · NIL
          Differential
        </p>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* View Mode Selector */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex gap-4 flex-wrap">
            {["side-by-side", "overlay", "metrics"].map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-6 py-3 rounded-lg font-semibold uppercase transition-all ${
                  viewMode === mode
                    ? "bg-purple-600 text-white"
                    : "bg-slate-800 text-purple-300 hover:bg-slate-700"
                }`}
              >
                {mode.replace("-", " ")}
              </button>
            ))}
            <button
              onClick={() => setAutoRotate(!autoRotate)}
              className={`ml-auto px-4 py-3 rounded-lg font-semibold transition-all ${
                autoRotate
                  ? "bg-blue-600 text-white"
                  : "bg-slate-800 text-blue-300 hover:bg-slate-700"
              }`}
            >
              {autoRotate ? "Stop" : "Start"} Rotation
            </button>
          </div>
        </div>

        {/* Side-by-Side View */}
        {viewMode === "side-by-side" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Athlete 1 */}
            <AthletePanel
              athlete={athlete1}
              autoRotate={autoRotate}
              color="blue"
            />

            {/* Athlete 2 */}
            <AthletePanel
              athlete={athlete2}
              autoRotate={autoRotate}
              color="purple"
            />
          </div>
        )}

        {/* Metrics Comparison */}
        {viewMode === "metrics" && (
          <div className="space-y-6">
            {/* Comparison Table */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">
                Biomechanical Metrics Comparison
              </h2>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left text-blue-300 font-semibold py-3 px-4">
                        Metric
                      </th>
                      <th className="text-center text-blue-400 font-semibold py-3 px-4">
                        {athlete1.name}
                      </th>
                      <th className="text-center text-purple-400 font-semibold py-3 px-4">
                        {athlete2.name}
                      </th>
                      <th className="text-center text-white font-semibold py-3 px-4">
                        Differential
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <MetricComparisonRow
                      label="BIM Score"
                      value1={athlete1.bimScore}
                      value2={athlete2.bimScore}
                      higherIsBetter={true}
                    />
                    <MetricComparisonRow
                      label="Avg Fatigue"
                      value1={athlete1.overallMetrics.avgFatigue}
                      value2={athlete2.overallMetrics.avgFatigue}
                      higherIsBetter={false}
                      unit="%"
                    />
                    <MetricComparisonRow
                      label="Avg Stress"
                      value1={athlete1.overallMetrics.avgStress}
                      value2={athlete2.overallMetrics.avgStress}
                      higherIsBetter={false}
                      unit="%"
                    />
                    <MetricComparisonRow
                      label="Avg Injury Risk"
                      value1={athlete1.overallMetrics.avgInjuryRisk}
                      value2={athlete2.overallMetrics.avgInjuryRisk}
                      higherIsBetter={false}
                      unit="%"
                    />
                    <MetricComparisonRow
                      label="NIL Momentum"
                      value1={athlete1.overallMetrics.nilMomentum}
                      value2={athlete2.overallMetrics.nilMomentum}
                      higherIsBetter={true}
                      unit="%"
                    />
                    <MetricComparisonRow
                      label="Recovery Score"
                      value1={athlete1.overallMetrics.recoveryScore}
                      value2={athlete2.overallMetrics.recoveryScore}
                      higherIsBetter={true}
                    />
                  </tbody>
                </table>
              </div>
            </div>

            {/* Joint-Specific Comparison */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {["shoulderRight", "kneeLeft", "ankleRight"].map((joint) => (
                <JointComparisonCard
                  key={joint}
                  joint={joint}
                  athlete1Data={athlete1.capsuleData[joint]}
                  athlete2Data={athlete2.capsuleData[joint]}
                  athlete1Name={athlete1.name}
                  athlete2Name={athlete2.name}
                />
              ))}
            </div>
          </div>
        )}

        {/* Coaching Insights */}
        <div className="bg-gradient-to-r from-blue-600/10 to-purple-600/10 backdrop-blur-lg rounded-xl p-6 border border-purple-400/30">
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="w-6 h-6 text-yellow-400" />
            <h3 className="text-2xl font-bold text-white">Coaching Insights</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InsightCard
              title="Injury Risk Assessment"
              athlete={athlete1.name}
              type="warning"
            >
              <p className="text-yellow-200 text-sm mb-2">
                <span className="font-bold">Left Knee</span> showing 80% injury
                risk with negative recovery velocity (-10).
              </p>
              <p className="text-yellow-300 text-xs italic">
                Recommendation: Reduce contact drills, monitor swelling,
                consider MRI if pain persists.
              </p>
            </InsightCard>

            <InsightCard
              title="Performance Advantage"
              athlete={athlete2.name}
              type="success"
            >
              <p className="text-green-200 text-sm mb-2">
                <span className="font-bold">Overall NIL Momentum</span> 88% vs
                77% — higher brand activation potential.
              </p>
              <p className="text-green-300 text-xs italic">
                Recommendation: Leverage current momentum for sponsor
                activations, premium marketing opportunities.
              </p>
            </InsightCard>

            <InsightCard
              title="Recovery Differential"
              athlete={athlete2.name}
              type="info"
            >
              <p className="text-blue-200 text-sm mb-2">
                <span className="font-bold">Recovery Score</span> 75 vs 45 —
                significantly faster adaptation to training load.
              </p>
              <p className="text-blue-300 text-xs italic">
                Insight: Superior recovery allows higher training volume without
                elevated injury risk.
              </p>
            </InsightCard>

            <InsightCard
              title="Load Management Priority"
              athlete={athlete1.name}
              type="warning"
            >
              <p className="text-yellow-200 text-sm mb-2">
                <span className="font-bold">Multiple Joints</span> showing high
                stress (shoulder 75%, knee 85%) — elevated risk profile.
              </p>
              <p className="text-yellow-300 text-xs italic">
                Action: Implement active rest protocol, reduce practice
                intensity 20% for next 5 days.
              </p>
            </InsightCard>
          </div>
        </div>

        {/* Tactical Recommendations */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center gap-3 mb-4">
            <Target className="w-6 h-6 text-blue-400" />
            <h3 className="text-2xl font-bold text-white">
              Tactical Recommendations
            </h3>
          </div>

          <div className="space-y-4">
            <TacticalCard
              title="Roster Management"
              icon={<Users className="w-5 h-5 text-purple-400" />}
            >
              <p className="text-white text-sm mb-2">
                Consider increased minutes for{" "}
                <span className="font-bold text-purple-400">
                  {athlete2.name}
                </span>{" "}
                (BIM 92.3, low injury risk) while implementing load management
                for{" "}
                <span className="font-bold text-blue-400">{athlete1.name}</span>{" "}
                (elevated knee risk).
              </p>
              <div className="flex gap-2 mt-3">
                <span className="px-3 py-1 bg-purple-600/20 rounded-full text-purple-300 text-xs">
                  Minutes Adjustment
                </span>
                <span className="px-3 py-1 bg-blue-600/20 rounded-full text-blue-300 text-xs">
                  Rest Protocol
                </span>
              </div>
            </TacticalCard>

            <TacticalCard
              title="Training Adjustments"
              icon={<Activity className="w-5 h-5 text-green-400" />}
            >
              <p className="text-white text-sm mb-2">
                Modify contact drill exposure for{" "}
                <span className="font-bold text-blue-400">{athlete1.name}</span>
                . Focus on mobility work, recovery modalities, and non-impact
                conditioning for 72 hours.
              </p>
              <div className="flex gap-2 mt-3">
                <span className="px-3 py-1 bg-green-600/20 rounded-full text-green-300 text-xs">
                  Mobility Focus
                </span>
                <span className="px-3 py-1 bg-yellow-600/20 rounded-full text-yellow-300 text-xs">
                  Load Reduction
                </span>
              </div>
            </TacticalCard>

            <TacticalCard
              title="NIL & Brand Opportunities"
              icon={<TrendingUp className="w-5 h-5 text-yellow-400" />}
            >
              <p className="text-white text-sm mb-2">
                <span className="font-bold text-purple-400">
                  {athlete2.name}
                </span>{" "}
                showing 88% NIL momentum with low injury risk — optimal window
                for sponsor activations, content creation, and premium brand
                partnerships.
              </p>
              <div className="flex gap-2 mt-3">
                <span className="px-3 py-1 bg-yellow-600/20 rounded-full text-yellow-300 text-xs">
                  Sponsor Ready
                </span>
                <span className="px-3 py-1 bg-green-600/20 rounded-full text-green-300 text-xs">
                  Content Window
                </span>
              </div>
            </TacticalCard>
          </div>
        </div>
      </div>
    </div>
  );
}

function AthletePanel({ athlete, autoRotate, color }) {
  const borderColor =
    color === "blue" ? "border-blue-400/30" : "border-purple-400/30";
  const bgColor =
    color === "blue"
      ? "from-blue-600/10 to-blue-800/10"
      : "from-purple-600/10 to-purple-800/10";
  const textColor = color === "blue" ? "text-blue-400" : "text-purple-400";

  return (
    <div
      className={`bg-gradient-to-br ${bgColor} backdrop-blur-lg rounded-xl p-6 border ${borderColor}`}
    >
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-1">{athlete.name}</h2>
        <p className="text-white/60 text-sm">
          {athlete.sport} · {athlete.position}
        </p>
        <div className="flex items-center gap-4 mt-3">
          <div>
            <p className="text-white/60 text-xs">BIM Score</p>
            <p className={`text-3xl font-bold ${textColor}`}>
              {athlete.bimScore}
            </p>
          </div>
          <div>
            <p className="text-white/60 text-xs">Tier</p>
            <p className="text-yellow-400 text-lg font-bold uppercase">
              {athlete.tier}
            </p>
          </div>
        </div>
      </div>

      {/* 3D Skeleton */}
      <div className="flex justify-center mb-6">
        <ThreeDSkeletonRenderer
          jointData={JOINT_POSITIONS}
          capsuleData={athlete.capsuleData}
          highlightJoints={Object.keys(athlete.capsuleData)}
          showCapsules={true}
          autoRotate={autoRotate}
          width={400}
          height={500}
        />
      </div>

      {/* Joint Status */}
      <div className="space-y-3">
        <h4 className="text-white font-semibold mb-3">Joint Status</h4>
        {Object.entries(athlete.capsuleData).map(([joint, data]) => (
          <JointStatusRow key={joint} joint={joint} data={data} color={color} />
        ))}
      </div>

      {/* Overall Metrics */}
      <div className="mt-6 pt-6 border-t border-white/20 grid grid-cols-2 gap-3">
        <OverallMetric
          label="Avg Fatigue"
          value={`${athlete.overallMetrics.avgFatigue}%`}
        />
        <OverallMetric
          label="Avg Stress"
          value={`${athlete.overallMetrics.avgStress}%`}
        />
        <OverallMetric
          label="Injury Risk"
          value={`${athlete.overallMetrics.avgInjuryRisk}%`}
        />
        <OverallMetric
          label="Recovery"
          value={athlete.overallMetrics.recoveryScore}
        />
      </div>
    </div>
  );
}

function JointStatusRow({ joint, data, color }) {
  const riskLevel =
    data.injuryRisk > 70 ? "high" : data.injuryRisk > 40 ? "medium" : "low";
  const riskColor =
    riskLevel === "high"
      ? "text-red-400"
      : riskLevel === "medium"
        ? "text-yellow-400"
        : "text-green-400";
  const barColor = color === "blue" ? "bg-blue-500" : "bg-purple-500";

  return (
    <div className="bg-slate-800/50 rounded-lg p-3">
      <div className="flex justify-between items-center mb-2">
        <span className="text-white text-sm capitalize font-medium">
          {joint.replace(/([A-Z])/g, " $1").trim()}
        </span>
        <span className={`${riskColor} text-sm font-bold`}>
          Risk: {data.injuryRisk.toFixed(0)}%
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-white/60">Fatigue: </span>
          <span className="text-white font-mono">
            {data.fatigue.toFixed(0)}%
          </span>
        </div>
        <div>
          <span className="text-white/60">Stress: </span>
          <span className="text-white font-mono">
            {data.stressLoad.toFixed(0)}%
          </span>
        </div>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-1.5 mt-2">
        <div
          className={`${barColor} h-1.5 rounded-full transition-all duration-300`}
          style={{ width: `${data.injuryRisk}%` }}
        />
      </div>
    </div>
  );
}

function OverallMetric({ label, value }) {
  return (
    <div className="bg-slate-800/50 rounded-lg p-3">
      <p className="text-white/60 text-xs mb-1">{label}</p>
      <p className="text-white text-lg font-bold">{value}</p>
    </div>
  );
}

function MetricComparisonRow({
  label,
  value1,
  value2,
  higherIsBetter,
  unit = "",
}) {
  const diff = value2 - value1;
  const winner = higherIsBetter
    ? value2 > value1
      ? 2
      : 1
    : value2 < value1
      ? 2
      : 1;

  return (
    <tr className="border-b border-white/10">
      <td className="text-blue-300 text-sm py-3 px-4">{label}</td>
      <td className="text-center py-3 px-4">
        <span
          className={`text-sm font-mono ${winner === 1 ? "text-white font-bold" : "text-white/60"}`}
        >
          {value1.toFixed(1)}
          {unit}
        </span>
      </td>
      <td className="text-center py-3 px-4">
        <span
          className={`text-sm font-mono ${winner === 2 ? "text-white font-bold" : "text-white/60"}`}
        >
          {value2.toFixed(1)}
          {unit}
        </span>
      </td>
      <td className="text-center py-3 px-4">
        <span
          className={`text-sm font-mono ${
            diff > 0 && higherIsBetter
              ? "text-green-400"
              : diff < 0 && higherIsBetter
                ? "text-red-400"
                : diff < 0 && !higherIsBetter
                  ? "text-green-400"
                  : diff > 0 && !higherIsBetter
                    ? "text-red-400"
                    : "text-white/60"
          }`}
        >
          {diff > 0 ? "+" : ""}
          {diff.toFixed(1)}
          {unit}
        </span>
      </td>
    </tr>
  );
}

function JointComparisonCard({
  joint,
  athlete1Data,
  athlete2Data,
  athlete1Name,
  athlete2Name,
}) {
  const diff = athlete2Data.injuryRisk - athlete1Data.injuryRisk;
  const winner = diff < 0 ? athlete2Name : athlete1Name;

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h4 className="text-white font-semibold mb-4 capitalize">
        {joint.replace(/([A-Z])/g, " $1").trim()}
      </h4>

      <div className="space-y-3 mb-4">
        <ComparisonBar
          label={athlete1Name}
          value={athlete1Data.injuryRisk}
          color="blue"
        />
        <ComparisonBar
          label={athlete2Name}
          value={athlete2Data.injuryRisk}
          color="purple"
        />
      </div>

      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-600">
        <p className="text-white/60 text-xs mb-1">Lower Injury Risk</p>
        <p className="text-white font-semibold">{winner}</p>
        <p className="text-green-400 text-xs mt-1">
          Differential: {Math.abs(diff).toFixed(1)}%
        </p>
      </div>
    </div>
  );
}

function ComparisonBar({ label, value, color }) {
  const barColor = color === "blue" ? "bg-blue-500" : "bg-purple-500";

  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-white/80 text-xs">{label}</span>
        <span className="text-white text-xs font-mono">
          {value.toFixed(0)}%
        </span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className={`${barColor} h-2 rounded-full transition-all duration-300`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

function InsightCard({ title, athlete, type, children }) {
  const bgColor =
    type === "warning"
      ? "bg-yellow-500/10"
      : type === "success"
        ? "bg-green-500/10"
        : "bg-blue-500/10";

  const borderColor =
    type === "warning"
      ? "border-yellow-500/30"
      : type === "success"
        ? "border-green-500/30"
        : "border-blue-500/30";

  return (
    <div className={`${bgColor} rounded-lg p-4 border ${borderColor}`}>
      <div className="flex items-center gap-2 mb-3">
        <AlertCircle
          className={`w-4 h-4 ${
            type === "warning"
              ? "text-yellow-400"
              : type === "success"
                ? "text-green-400"
                : "text-blue-400"
          }`}
        />
        <h5 className="text-white font-semibold text-sm">{title}</h5>
      </div>
      <p className="text-white/80 text-xs mb-2">
        Athlete: <span className="font-bold">{athlete}</span>
      </p>
      {children}
    </div>
  );
}

function TacticalCard({ title, icon, children }) {
  return (
    <div className="bg-slate-800/50 rounded-lg p-5 border border-slate-600">
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h4 className="text-white font-semibold">{title}</h4>
      </div>
      {children}
    </div>
  );
}
