"use client";

import { useState, useEffect } from "react";
import {
  DollarSign,
  TrendingUp,
  Award,
  Users,
  Shield,
  Target,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function WealthManagementDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [athleteId, setAthleteId] = useState("");
  const [nilAccount, setNilAccount] = useState(null);
  const [legacyPlan, setLegacyPlan] = useState(null);
  const [familyOffice, setFamilyOffice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchAccountData = async () => {
    if (!athleteId) return;

    setLoading(true);
    setError(null);

    try {
      // Fetch NIL account
      const nilRes = await fetch(
        `/api/wealth-management/nil-accounts?athleteId=${athleteId}`,
      );
      if (nilRes.ok) {
        const nilData = await nilRes.json();
        setNilAccount(nilData);
      }

      // Fetch legacy planning
      const legacyRes = await fetch(
        `/api/wealth-management/legacy-planning?athleteId=${athleteId}`,
      );
      if (legacyRes.ok) {
        const legacyData = await legacyRes.json();
        setLegacyPlan(legacyData);
      }

      // Fetch family office
      const familyRes = await fetch(
        `/api/wealth-management/family-office?athleteId=${athleteId}`,
      );
      if (familyRes.ok) {
        const familyData = await familyRes.json();
        setFamilyOffice(familyData);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to fetch account data");
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-emerald-400 underline">
            sign in
          </a>{" "}
          to access wealth management
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <DollarSign className="w-12 h-12 text-emerald-400" />
          <h1 className="text-5xl font-bold text-white">
            Wealth Management & Family Advisory
          </h1>
        </div>
        <p className="text-emerald-200 text-xl">
          BIM-APES Sports & Entertainment Financial Services
        </p>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Athlete Selector */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex gap-4 items-end">
            <div className="flex-1">
              <label className="block text-emerald-200 mb-2 font-medium">
                Athlete ID
              </label>
              <input
                type="number"
                value={athleteId}
                onChange={(e) => setAthleteId(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-emerald-400 focus:outline-none"
                placeholder="Enter athlete ID"
              />
            </div>
            <button
              onClick={fetchAccountData}
              disabled={!athleteId || loading}
              className="px-8 py-3 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-lg font-semibold hover:from-emerald-700 hover:to-green-700 transition-all disabled:opacity-50"
            >
              {loading ? "Loading..." : "Load Account"}
            </button>
          </div>
          {error && (
            <div className="mt-4 bg-red-500/20 border border-red-500 rounded-lg p-4">
              <p className="text-red-200">{error}</p>
            </div>
          )}
        </div>

        {/* Tabs Navigation */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-2 border border-white/20 flex gap-2">
          {["overview", "nil-account", "legacy-planning", "family-office"].map(
            (tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 px-6 py-3 rounded-lg font-semibold uppercase transition-all ${
                  activeTab === tab
                    ? "bg-emerald-600 text-white"
                    : "bg-slate-800/50 text-emerald-300 hover:bg-slate-700"
                }`}
              >
                {tab.replace("-", " ")}
              </button>
            ),
          )}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <OverviewTab
            nilAccount={nilAccount}
            legacyPlan={legacyPlan}
            familyOffice={familyOffice}
          />
        )}

        {activeTab === "nil-account" && (
          <NILAccountTab nilAccount={nilAccount} athleteId={athleteId} />
        )}

        {activeTab === "legacy-planning" && (
          <LegacyPlanningTab legacyPlan={legacyPlan} athleteId={athleteId} />
        )}

        {activeTab === "family-office" && (
          <FamilyOfficeTab familyOffice={familyOffice} athleteId={athleteId} />
        )}
      </div>
    </div>
  );
}

// Overview Tab
function OverviewTab({ nilAccount, legacyPlan, familyOffice }) {
  if (!nilAccount && !legacyPlan && !familyOffice) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20">
        <div className="flex flex-col items-center text-emerald-300">
          <Shield className="w-20 h-20 mb-4 opacity-50" />
          <p className="text-xl">
            Enter athlete ID and click Load Account to view comprehensive
            financial overview
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* NIL Valuation Card */}
      <div className="bg-gradient-to-br from-emerald-500/20 to-green-500/20 backdrop-blur-lg rounded-xl p-6 border border-emerald-400/30">
        <div className="flex items-center gap-3 mb-4">
          <DollarSign className="w-8 h-8 text-emerald-400" />
          <h3 className="text-xl font-bold text-white">NIL Valuation</h3>
        </div>
        {nilAccount?.account ? (
          <>
            <p className="text-4xl font-bold text-emerald-400 mb-2">
              $
              {parseFloat(
                nilAccount.account.current_valuation,
              ).toLocaleString()}
            </p>
            <p className="text-emerald-200 text-sm mb-4">
              Account: {nilAccount.account.account_number}
            </p>
            <div className="space-y-2">
              <MetricRow
                label="Player Index"
                value={parseFloat(nilAccount.account.player_index).toFixed(1)}
              />
              <MetricRow
                label="Account Type"
                value={nilAccount.account.account_type}
              />
              <MetricRow
                label="Margin Enabled"
                value={nilAccount.account.margin_enabled ? "Yes" : "No"}
              />
            </div>
          </>
        ) : (
          <p className="text-emerald-300">No NIL account found</p>
        )}
      </div>

      {/* Legacy Planning Card */}
      <div className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-lg rounded-xl p-6 border border-blue-400/30">
        <div className="flex items-center gap-3 mb-4">
          <Target className="w-8 h-8 text-blue-400" />
          <h3 className="text-xl font-bold text-white">Legacy Planning</h3>
        </div>
        {legacyPlan?.profile ? (
          <>
            <p className="text-4xl font-bold text-blue-400 mb-2">
              {legacyPlan.readinessScore}%
            </p>
            <p className="text-blue-200 text-sm mb-4">Transition Readiness</p>
            <div className="space-y-2">
              <MetricRow
                label="Career Stage"
                value={legacyPlan.profile.career_stage}
              />
              <MetricRow
                label="Years to Retirement"
                value={legacyPlan.profile.years_to_retirement}
              />
              <MetricRow
                label="Next Steps"
                value={legacyPlan.nextSteps?.length || 0}
              />
            </div>
          </>
        ) : (
          <p className="text-blue-300">No legacy plan found</p>
        )}
      </div>

      {/* Family Office Card */}
      <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-lg rounded-xl p-6 border border-purple-400/30">
        <div className="flex items-center gap-3 mb-4">
          <Users className="w-8 h-8 text-purple-400" />
          <h3 className="text-xl font-bold text-white">Family Office</h3>
        </div>
        {familyOffice?.profile ? (
          <>
            <p className="text-4xl font-bold text-purple-400 mb-2">
              {familyOffice.financialHealth?.rating || "N/A"}
            </p>
            <p className="text-purple-200 text-sm mb-4">
              Financial Health Rating
            </p>
            <div className="space-y-2">
              <MetricRow
                label="Annual Income"
                value={`$${parseFloat(familyOffice.profile.annual_income).toLocaleString()}`}
              />
              <MetricRow
                label="Tax Strategy"
                value={familyOffice.financialHealth?.components.taxOptimization}
              />
              <MetricRow
                label="Estate Plan"
                value={familyOffice.financialHealth?.components.estatePlanning}
              />
            </div>
          </>
        ) : (
          <p className="text-purple-300">No family office profile found</p>
        )}
      </div>

      {/* Action Items */}
      {(legacyPlan?.nextSteps || familyOffice?.actionItems) && (
        <div className="md:col-span-3 bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Recommended Actions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {legacyPlan?.nextSteps?.map((step, idx) => (
              <ActionCard key={idx} {...step} />
            ))}
            {familyOffice?.actionItems?.map((item, idx) => (
              <ActionCard
                key={idx}
                priority={item.priority}
                action={item.action}
                timeline={item.timeline}
                impact={item.impact}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// NIL Account Tab
function NILAccountTab({ nilAccount, athleteId }) {
  const [creating, setCreating] = useState(false);
  const [accountType, setAccountType] = useState("standard");
  const [marginEnabled, setMarginEnabled] = useState(false);
  const [riskTolerance, setRiskTolerance] = useState("moderate");

  const handleCreateAccount = async () => {
    if (!athleteId) {
      alert("Please enter athlete ID");
      return;
    }

    setCreating(true);

    try {
      const response = await fetch("/api/wealth-management/nil-accounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athleteId: parseInt(athleteId),
          accountType,
          marginEnabled,
          riskTolerance,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create NIL account");
      }

      const data = await response.json();
      alert("NIL account created successfully!");
      window.location.reload();
    } catch (err) {
      console.error(err);
      alert(err.message);
    } finally {
      setCreating(false);
    }
  };

  if (!nilAccount?.account) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8 border border-white/20">
        <h3 className="text-2xl font-bold text-white mb-6">
          Create NIL Valuation Account
        </h3>

        <div className="space-y-6 max-w-2xl">
          <div>
            <label className="block text-emerald-200 mb-2 font-medium">
              Account Type
            </label>
            <select
              value={accountType}
              onChange={(e) => setAccountType(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-emerald-400 focus:outline-none"
            >
              <option value="standard">Standard - Basic NIL tracking</option>
              <option value="premium">
                Premium - Enhanced analytics & reporting
              </option>
              <option value="family_office">
                Family Office - Full wealth management suite
              </option>
            </select>
          </div>

          <div>
            <label className="block text-emerald-200 mb-2 font-medium">
              Risk Tolerance
            </label>
            <select
              value={riskTolerance}
              onChange={(e) => setRiskTolerance(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-emerald-400 focus:outline-none"
            >
              <option value="conservative">
                Conservative - 1.5x max leverage
              </option>
              <option value="moderate">Moderate - 2.0x max leverage</option>
              <option value="aggressive">Aggressive - 3.0x max leverage</option>
            </select>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={marginEnabled}
              onChange={(e) => setMarginEnabled(e.target.checked)}
              className="w-5 h-5"
            />
            <label className="text-emerald-200 font-medium">
              Enable Margin Trading (leverage for athlete asset investments)
            </label>
          </div>

          <button
            onClick={handleCreateAccount}
            disabled={creating || !athleteId}
            className="w-full bg-gradient-to-r from-emerald-600 to-green-600 text-white py-4 px-6 rounded-lg font-semibold text-lg hover:from-emerald-700 hover:to-green-700 transition-all disabled:opacity-50"
          >
            {creating ? "Creating Account..." : "Create NIL Account"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Account Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-emerald-500/20 to-green-500/20 rounded-xl p-6 border border-emerald-400/30">
          <p className="text-emerald-200 text-sm mb-1">Current Valuation</p>
          <p className="text-4xl font-bold text-white">
            ${parseFloat(nilAccount.account.current_valuation).toLocaleString()}
          </p>
        </div>

        <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl p-6 border border-blue-400/30">
          <p className="text-blue-200 text-sm mb-1">Player Index</p>
          <p className="text-4xl font-bold text-white">
            {parseFloat(nilAccount.account.player_index).toFixed(1)}
          </p>
        </div>

        <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl p-6 border border-purple-400/30">
          <p className="text-purple-200 text-sm mb-1">Account Type</p>
          <p className="text-2xl font-bold text-white uppercase">
            {nilAccount.account.account_type}
          </p>
        </div>
      </div>

      {/* Brand Identity Profile */}
      {nilAccount.brandProfile && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <Award className="w-7 h-7 text-yellow-400" />
            Brand Identity Profile
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ScoreCard
              label="Brand Equity"
              value={parseFloat(
                nilAccount.brandProfile.brand_equity_score,
              ).toFixed(1)}
            />
            <ScoreCard
              label="Fan Sentiment"
              value={parseFloat(
                nilAccount.brandProfile.fan_sentiment_score,
              ).toFixed(1)}
            />
            <ScoreCard
              label="Sponsorship Potential"
              value={parseFloat(
                nilAccount.brandProfile.sponsorship_potential,
              ).toFixed(1)}
            />
            <ScoreCard
              label="Authenticity"
              value={parseFloat(
                nilAccount.brandProfile.authenticity_index,
              ).toFixed(1)}
            />
          </div>
          <div className="mt-4">
            <p className="text-emerald-200">
              Market Positioning:{" "}
              <span className="font-bold text-white uppercase">
                {nilAccount.brandProfile.market_positioning}
              </span>
            </p>
          </div>
        </div>
      )}

      {/* Margin Account */}
      {nilAccount.marginAccount && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">Margin Account</h3>
          <div className="grid grid-cols-3 gap-6">
            <div>
              <p className="text-emerald-200 text-sm mb-1">Available Margin</p>
              <p className="text-3xl font-bold text-white">
                $
                {parseFloat(
                  nilAccount.marginAccount.available_margin,
                ).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-blue-200 text-sm mb-1">Utilized Margin</p>
              <p className="text-3xl font-bold text-white">
                $
                {parseFloat(
                  nilAccount.marginAccount.utilized_margin,
                ).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-purple-200 text-sm mb-1">Max Leverage</p>
              <p className="text-3xl font-bold text-white">
                {parseFloat(nilAccount.marginAccount.max_leverage).toFixed(1)}x
              </p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-white/20">
            <p className="text-emerald-200 text-sm">
              Margin Rate:{" "}
              <span className="text-white font-mono">
                {(
                  parseFloat(nilAccount.marginAccount.margin_rate) * 100
                ).toFixed(2)}
                %
              </span>
            </p>
          </div>
        </div>
      )}

      {/* Contract Adjustments History */}
      {nilAccount.contractAdjustments &&
        nilAccount.contractAdjustments.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-6">
              Recent Contract Adjustments
            </h3>
            <div className="space-y-3">
              {nilAccount.contractAdjustments.slice(0, 5).map((adj, idx) => (
                <div
                  key={idx}
                  className="bg-slate-800/50 rounded-lg p-4 border border-slate-600"
                >
                  <div className="flex justify-between items-start mb-2">
                    <p className="text-emerald-300 font-medium">
                      {adj.adjustment_type.replace(/_/g, " ")}
                    </p>
                    <p
                      className={`text-lg font-bold ${parseFloat(adj.adjustment_amount) >= 0 ? "text-green-400" : "text-red-400"}`}
                    >
                      {parseFloat(adj.adjustment_amount) >= 0 ? "+" : ""}$
                      {parseFloat(adj.adjustment_amount).toLocaleString()}
                    </p>
                  </div>
                  {adj.adjustment_reason && (
                    <p className="text-blue-200 text-sm">
                      {adj.adjustment_reason}
                    </p>
                  )}
                  <p className="text-slate-400 text-xs mt-2">
                    {new Date(adj.adjustment_date).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

      {/* Player Index Chart */}
      {nilAccount.indexHistory && nilAccount.indexHistory.length > 0 && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Player Index Trend
          </h3>
          <div className="space-y-2">
            {nilAccount.indexHistory.slice(0, 10).map((history, idx) => (
              <div
                key={idx}
                className="flex justify-between items-center bg-slate-800/50 rounded-lg p-3"
              >
                <span className="text-blue-200 text-sm">
                  {new Date(history.recorded_at).toLocaleDateString()}
                </span>
                <span className="text-white font-mono font-semibold">
                  {parseFloat(history.index_value).toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Legacy Planning Tab
function LegacyPlanningTab({ legacyPlan, athleteId }) {
  if (!legacyPlan?.profile) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20">
        <div className="flex flex-col items-center text-blue-300">
          <Target className="w-20 h-20 mb-4 opacity-50" />
          <p className="text-xl mb-6">No legacy planning profile found</p>
          <p className="text-sm">
            Create a profile to begin post-career transition planning
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Readiness Score */}
      <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl p-8 border border-blue-400/30">
        <h3 className="text-3xl font-bold text-white mb-4">
          Transition Readiness Score
        </h3>
        <div className="flex items-end gap-4 mb-4">
          <p className="text-6xl font-bold text-blue-400">
            {legacyPlan.readinessScore}%
          </p>
          <p className="text-2xl text-blue-200 mb-2">
            {legacyPlan.readinessScore >= 80
              ? "Excellent"
              : legacyPlan.readinessScore >= 60
                ? "Good"
                : legacyPlan.readinessScore >= 40
                  ? "Fair"
                  : "Needs Attention"}
          </p>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-4">
          <div
            className="bg-gradient-to-r from-blue-400 to-purple-400 h-4 rounded-full transition-all duration-700"
            style={{ width: `${legacyPlan.readinessScore}%` }}
          />
        </div>
      </div>

      {/* Roadmap */}
      {legacyPlan.profile.roadmap?.phases && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Transition Roadmap
          </h3>
          <div className="space-y-6">
            {legacyPlan.profile.roadmap.phases.map((phase, idx) => (
              <div
                key={idx}
                className="bg-slate-800/50 rounded-lg p-6 border border-slate-600"
              >
                <h4 className="text-xl font-bold text-white mb-2">
                  {phase.phase}
                </h4>
                <p className="text-blue-300 mb-4">{phase.timeframe}</p>
                <div className="mb-4">
                  <p className="text-emerald-200 font-medium mb-2">
                    Focus Areas:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {phase.focus.map((item, i) => (
                      <span
                        key={i}
                        className="bg-emerald-600/20 text-emerald-300 px-3 py-1 rounded-full text-sm"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-blue-200 font-medium mb-2">Actions:</p>
                  <ul className="space-y-1">
                    {phase.actions.map((action, i) => (
                      <li key={i} className="text-white text-sm">
                        • {action}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Entrepreneurial Opportunities */}
      {legacyPlan.entrepreneurialOpportunities && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Entrepreneurial Opportunities
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {legacyPlan.entrepreneurialOpportunities.map((opp, idx) => (
              <div
                key={idx}
                className="bg-slate-800/50 rounded-lg p-5 border border-slate-600"
              >
                <div className="flex justify-between items-start mb-3">
                  <h4 className="text-lg font-bold text-white">
                    {opp.opportunity}
                  </h4>
                  <span className="bg-emerald-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    Fit: {opp.fit}%
                  </span>
                </div>
                <p className="text-blue-200 text-sm mb-3">{opp.category}</p>
                <div className="space-y-2 text-sm">
                  <p className="text-emerald-300">
                    Capital: ${opp.capitalRequired.toLocaleString()}
                  </p>
                  <p className="text-blue-300">Timeline: {opp.timeToLaunch}</p>
                  <p className="text-purple-300">
                    Potential ROI: {opp.potentialROI}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Next Steps */}
      {legacyPlan.nextSteps && legacyPlan.nextSteps.length > 0 && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">Next Steps</h3>
          <div className="space-y-3">
            {legacyPlan.nextSteps.map((step, idx) => (
              <ActionCard key={idx} {...step} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Family Office Tab
function FamilyOfficeTab({ familyOffice, athleteId }) {
  if (!familyOffice?.profile) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20">
        <div className="flex flex-col items-center text-purple-300">
          <Users className="w-20 h-20 mb-4 opacity-50" />
          <p className="text-xl mb-6">No family office profile found</p>
          <p className="text-sm">
            Create a profile for comprehensive financial planning
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Financial Health Score */}
      <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl p-8 border border-purple-400/30">
        <h3 className="text-3xl font-bold text-white mb-4">
          Financial Health Assessment
        </h3>
        <div className="flex items-end gap-4 mb-4">
          <p className="text-6xl font-bold text-purple-400">
            {familyOffice.financialHealth?.score}
          </p>
          <p className="text-2xl text-purple-200 mb-2">
            {familyOffice.financialHealth?.rating}
          </p>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-4">
          <div
            className="bg-gradient-to-r from-purple-400 to-pink-400 h-4 rounded-full transition-all duration-700"
            style={{ width: `${familyOffice.financialHealth?.score}%` }}
          />
        </div>
      </div>

      {/* Tax Optimization Strategy */}
      {familyOffice.profile.tax_strategy?.strategies && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Tax Optimization Strategy
          </h3>
          <div className="mb-6 bg-emerald-500/10 rounded-lg p-4 border border-emerald-400/30">
            <p className="text-emerald-200 mb-1">Total Estimated Tax Savings</p>
            <p className="text-3xl font-bold text-emerald-400">
              $
              {familyOffice.profile.tax_strategy.totalEstimatedSavings.toLocaleString()}
            </p>
          </div>
          <div className="space-y-4">
            {familyOffice.profile.tax_strategy.strategies.map(
              (strategy, idx) => (
                <div
                  key={idx}
                  className="bg-slate-800/50 rounded-lg p-5 border border-slate-600"
                >
                  <h4 className="text-lg font-bold text-white mb-2">
                    {strategy.strategy}
                  </h4>
                  <p className="text-blue-200 text-sm mb-3">
                    {strategy.description}
                  </p>
                  <div className="flex justify-between items-center">
                    <p className="text-emerald-300 text-sm">
                      Savings: ${strategy.estimatedSavings.toLocaleString()}
                    </p>
                    <p className="text-purple-300 text-sm">
                      {strategy.implementation}
                    </p>
                  </div>
                </div>
              ),
            )}
          </div>
        </div>
      )}

      {/* Philanthropic Plan */}
      {familyOffice.profile.philanthropic_plan?.givingVehicles && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Philanthropic Giving Plan
          </h3>
          <div className="mb-6">
            <p className="text-blue-200 mb-1">
              Recommended Annual Contribution
            </p>
            <p className="text-3xl font-bold text-white">
              $
              {familyOffice.profile.philanthropic_plan.recommendedAnnualContribution.toLocaleString()}
            </p>
          </div>
          <div className="space-y-3">
            {familyOffice.profile.philanthropic_plan.givingVehicles.map(
              (vehicle, idx) => (
                <div
                  key={idx}
                  className="bg-slate-800/50 rounded-lg p-4 border border-slate-600"
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-white font-semibold">
                      {vehicle.vehicle}
                    </h4>
                    <p className="text-emerald-400 font-mono">
                      ${vehicle.contribution.toLocaleString()}
                    </p>
                  </div>
                  <p className="text-blue-200 text-sm mb-1">
                    {vehicle.taxBenefit}
                  </p>
                  <p className="text-purple-300 text-xs">{vehicle.setup}</p>
                </div>
              ),
            )}
          </div>
        </div>
      )}

      {/* Estate Planning */}
      {familyOffice.profile.estate_plan?.essentialDocuments && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Estate Planning
          </h3>
          <div className="space-y-3 mb-6">
            {familyOffice.profile.estate_plan.essentialDocuments.map(
              (doc, idx) => (
                <div
                  key={idx}
                  className="flex justify-between items-center bg-slate-800/50 rounded-lg p-4 border border-slate-600"
                >
                  <div>
                    <p className="text-white font-medium">{doc.document}</p>
                    <p className="text-blue-200 text-sm">
                      {doc.priority} Priority
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      doc.status === "Completed"
                        ? "bg-green-600 text-white"
                        : "bg-yellow-600 text-white"
                    }`}
                  >
                    {doc.status}
                  </span>
                </div>
              ),
            )}
          </div>

          {familyOffice.profile.estate_plan.recommendations &&
            familyOffice.profile.estate_plan.recommendations.length > 0 && (
              <div>
                <h4 className="text-xl font-semibold text-white mb-4">
                  Recommendations
                </h4>
                <div className="space-y-3">
                  {familyOffice.profile.estate_plan.recommendations.map(
                    (rec, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-800/50 rounded-lg p-4 border border-slate-600"
                      >
                        <p className="text-emerald-300 font-medium mb-2">
                          {rec.recommendation}
                        </p>
                        <p className="text-blue-200 text-sm mb-2">
                          {rec.reason}
                        </p>
                        <p className="text-purple-300 text-xs">
                          Est. Cost: {rec.estimatedCost}
                        </p>
                      </div>
                    ),
                  )}
                </div>
              </div>
            )}
        </div>
      )}

      {/* Action Items */}
      {familyOffice.actionItems && familyOffice.actionItems.length > 0 && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-2xl font-bold text-white mb-6">
            Recommended Actions
          </h3>
          <div className="space-y-3">
            {familyOffice.actionItems.map((item, idx) => (
              <ActionCard key={idx} {...item} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Utility Components
function MetricRow({ label, value }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm opacity-80">{label}</span>
      <span className="font-mono font-semibold capitalize">{value}</span>
    </div>
  );
}

function ScoreCard({ label, value }) {
  const numValue = parseFloat(value);
  const color =
    numValue >= 75
      ? "text-green-400"
      : numValue >= 50
        ? "text-yellow-400"
        : "text-red-400";

  return (
    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
      <p className="text-blue-200 text-xs mb-2">{label}</p>
      <p className={`text-3xl font-bold ${color}`}>{value}</p>
    </div>
  );
}

function ActionCard({ priority, action, timeline, impact }) {
  const priorityColors = {
    Critical: "border-red-500 bg-red-500/10",
    High: "border-red-500 bg-red-500/10",
    high: "border-red-500 bg-red-500/10",
    Medium: "border-yellow-500 bg-yellow-500/10",
    medium: "border-yellow-500 bg-yellow-500/10",
    Low: "border-blue-500 bg-blue-500/10",
    low: "border-blue-500 bg-blue-500/10",
  };

  const badgeColors = {
    Critical: "bg-red-600 text-white",
    High: "bg-red-600 text-white",
    high: "bg-red-600 text-white",
    Medium: "bg-yellow-600 text-white",
    medium: "bg-yellow-600 text-white",
    Low: "bg-blue-600 text-white",
    low: "bg-blue-600 text-white",
  };

  return (
    <div
      className={`rounded-lg p-5 border ${priorityColors[priority] || "border-slate-600 bg-slate-800/50"}`}
    >
      <div className="flex justify-between items-start mb-3">
        <h4 className="text-white font-semibold text-lg flex-1">{action}</h4>
        <span
          className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${badgeColors[priority]}`}
        >
          {priority}
        </span>
      </div>
      <div className="flex justify-between items-center text-sm">
        <p className="text-blue-200">
          Timeline: <span className="text-white font-medium">{timeline}</span>
        </p>
        {impact && <p className="text-emerald-300">{impact}</p>}
      </div>
    </div>
  );
}
