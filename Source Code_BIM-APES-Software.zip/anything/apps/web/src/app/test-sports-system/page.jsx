"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function TestSportsSystem() {
  const { data: user, loading } = useUser();
  const [testResults, setTestResults] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [currentTest, setCurrentTest] = useState("");

  // Test data for different sports
  const sportTestData = {
    wrestling: {
      motion_scan_data: {
        biomechanics: {
          velocity_peak: 12.5,
          acceleration_max: 28.0,
          power_output: 1200,
          stability_score: 85,
          efficiency_rating: 78,
          range_of_motion: 120,
        },
        motion_type: "takedown",
        sport_type: "wrestling",
        key_points: [
          { x: 100, y: 200, confidence: 0.95 },
          { x: 150, y: 180, confidence: 0.92 },
          { x: 120, y: 220, confidence: 0.88 },
        ],
        ai_score: 0.87,
        frame_sequence: [1, 2, 3, 4, 5],
        scan_id: Math.floor(Math.random() * 1000),
      },
      session_context: { sport: "wrestling" },
      athlete_data: { sport: "wrestling", height: 1.78 },
    },
    tennis: {
      motion_scan_data: {
        biomechanics: {
          velocity_peak: 25.0,
          acceleration_max: 35.0,
          power_output: 800,
          stability_score: 92,
          efficiency_rating: 85,
          range_of_motion: 165,
        },
        motion_type: "serve",
        sport_type: "tennis",
        key_points: [
          { x: 110, y: 190, confidence: 0.96 },
          { x: 140, y: 175, confidence: 0.93 },
          { x: 125, y: 210, confidence: 0.91 },
        ],
        ai_score: 0.89,
        frame_sequence: [1, 2, 3, 4, 5, 6],
        scan_id: Math.floor(Math.random() * 1000),
      },
      session_context: { sport: "tennis" },
      athlete_data: { sport: "tennis", height: 1.75 },
    },
    american_football: {
      motion_scan_data: {
        biomechanics: {
          velocity_peak: 18.0,
          acceleration_max: 32.0,
          power_output: 1500,
          stability_score: 80,
          efficiency_rating: 72,
          range_of_motion: 140,
        },
        motion_type: "sprint",
        sport_type: "american_football",
        key_points: [
          { x: 105, y: 195, confidence: 0.94 },
          { x: 145, y: 185, confidence: 0.89 },
          { x: 130, y: 215, confidence: 0.87 },
        ],
        ai_score: 0.84,
        frame_sequence: [1, 2, 3, 4],
        scan_id: Math.floor(Math.random() * 1000),
      },
      session_context: { sport: "american_football" },
      athlete_data: { sport: "american_football", height: 1.85 },
    },
    soccer: {
      motion_scan_data: {
        biomechanics: {
          velocity_peak: 22.0,
          acceleration_max: 30.0,
          power_output: 900,
          stability_score: 88,
          efficiency_rating: 82,
          range_of_motion: 150,
        },
        motion_type: "kick",
        sport_type: "soccer",
        key_points: [
          { x: 115, y: 185, confidence: 0.93 },
          { x: 135, y: 170, confidence: 0.9 },
          { x: 125, y: 205, confidence: 0.92 },
        ],
        ai_score: 0.86,
        frame_sequence: [1, 2, 3, 4, 5],
        scan_id: Math.floor(Math.random() * 1000),
      },
      session_context: { sport: "soccer" },
      athlete_data: { sport: "soccer", height: 1.76 },
    },
    pickleball: {
      motion_scan_data: {
        biomechanics: {
          velocity_peak: 20.0,
          acceleration_max: 25.0,
          power_output: 600,
          stability_score: 90,
          efficiency_rating: 88,
          range_of_motion: 155,
        },
        motion_type: "volley",
        sport_type: "pickleball",
        key_points: [
          { x: 108, y: 188, confidence: 0.97 },
          { x: 142, y: 172, confidence: 0.94 },
          { x: 128, y: 208, confidence: 0.9 },
        ],
        ai_score: 0.91,
        frame_sequence: [1, 2, 3, 4, 5],
        scan_id: Math.floor(Math.random() * 1000),
      },
      session_context: { sport: "pickleball" },
      athlete_data: { sport: "pickleball", height: 1.7 },
    },
  };

  const runBIMPerformanceTest = async (sport, testData) => {
    setCurrentTest(`Testing BIM Performance for ${sport}`);

    try {
      const response = await fetch("/api/bim-performance/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testData),
      });

      const result = await response.json();

      return {
        sport,
        test: "BIM Performance",
        success: response.ok,
        data: result,
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      return {
        sport,
        test: "BIM Performance",
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      };
    }
  };

  const runCoachingIntegrationTest = async (sport) => {
    setCurrentTest(`Testing AI Coaching for ${sport}`);

    try {
      // Test coaching insights
      const response = await fetch(
        `/api/coach-portal/ai-coaching-integration?action=coaching_insights&athlete_id=1`,
      );
      const result = await response.json();

      return {
        sport,
        test: "AI Coaching Integration",
        success: response.ok,
        data: result,
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      return {
        sport,
        test: "AI Coaching Integration",
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      };
    }
  };

  const runSportAnalyticsTest = async (sport) => {
    setCurrentTest(`Testing Sport Analytics for ${sport}`);

    try {
      let endpoint = "";
      switch (sport) {
        case "wrestling":
          endpoint = "/api/bim-performance/wrestling";
          break;
        case "tennis":
        case "pickleball":
          endpoint = "/api/bim-performance/racket-sports";
          break;
        case "american_football":
          endpoint = "/api/bim-performance/american-football";
          break;
        case "soccer":
          endpoint = "/api/bim-performance/tactical-sports";
          break;
        default:
          endpoint = "/api/bim-performance/calculate";
      }

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sportTestData[sport]),
      });

      const result = await response.json();

      return {
        sport,
        test: "Sport-Specific Analytics",
        success: response.ok,
        data: result,
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      return {
        sport,
        test: "Sport-Specific Analytics",
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      };
    }
  };

  const runComprehensiveTest = async () => {
    setIsRunning(true);
    setTestResults([]);

    const results = [];
    const sports = Object.keys(sportTestData);

    for (const sport of sports) {
      // Test BIM Performance
      const bimResult = await runBIMPerformanceTest(
        sport,
        sportTestData[sport],
      );
      results.push(bimResult);
      setTestResults([...results]);

      await new Promise((resolve) => setTimeout(resolve, 500)); // Small delay

      // Test AI Coaching
      const coachingResult = await runCoachingIntegrationTest(sport);
      results.push(coachingResult);
      setTestResults([...results]);

      await new Promise((resolve) => setTimeout(resolve, 500)); // Small delay

      // Test Sport Analytics
      const analyticsResult = await runSportAnalyticsTest(sport);
      results.push(analyticsResult);
      setTestResults([...results]);

      await new Promise((resolve) => setTimeout(resolve, 1000)); // Delay between sports
    }

    setCurrentTest("Tests completed!");
    setIsRunning(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-lg text-[#1D2B3D]">Loading user data...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4 text-[#1D2B3D]">
            Authentication Required
          </h1>
          <p className="text-gray-600">Please sign in to run system tests.</p>
          <a
            href="/account/signin"
            className="text-[#B8860B] hover:text-[#1D2B3D] hover:underline transition-colors duration-300"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] p-6">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6 border border-[#1D2B3D]/10">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-[#1D2B3D]">
                🏆 Sports System Test Suite
              </h1>
              <p className="text-gray-600 mt-2">
                Comprehensive testing for all sport-specific implementations
              </p>
            </div>
            <button
              onClick={runComprehensiveTest}
              disabled={isRunning}
              className={`px-6 py-3 rounded-lg font-medium ${
                isRunning
                  ? "bg-gray-400 cursor-not-allowed text-white"
                  : "bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] hover:from-[#B8860B] hover:to-[#1D2B3D] text-white shadow-lg hover:shadow-xl"
              } transition-all duration-300`}
            >
              {isRunning ? "Running Tests..." : "Run All Tests"}
            </button>
          </div>

          {isRunning && (
            <div className="mb-6 p-4 bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-[#B8860B]"></div>
                <span className="text-[#1D2B3D] font-medium">
                  {currentTest}
                </span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {Object.keys(sportTestData).map((sport) => (
              <div
                key={sport}
                className="p-4 border border-[#1D2B3D]/20 rounded-lg"
              >
                <h3 className="font-semibold capitalize mb-2 text-[#1D2B3D]">
                  {sport}
                </h3>
                <div className="text-sm text-gray-600">
                  <div>
                    Motion: {sportTestData[sport].motion_scan_data.motion_type}
                  </div>
                  <div>
                    AI Score:{" "}
                    {Math.round(
                      sportTestData[sport].motion_scan_data.ai_score * 100,
                    )}
                    %
                  </div>
                  <div>
                    Velocity:{" "}
                    {
                      sportTestData[sport].motion_scan_data.biomechanics
                        .velocity_peak
                    }{" "}
                    m/s
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {testResults.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
            <h2 className="text-2xl font-bold mb-4 text-[#1D2B3D]">
              Test Results
            </h2>
            <div className="space-y-4">
              {testResults.map((result, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-l-4 ${
                    result.success
                      ? "bg-green-50 border-green-500"
                      : "bg-red-50 border-red-500"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold capitalize text-[#1D2B3D]">
                        {result.sport} - {result.test}
                      </h3>
                      <p
                        className={`text-sm ${result.success ? "text-green-700" : "text-red-700"}`}
                      >
                        {result.success ? "✅ Passed" : "❌ Failed"}
                      </p>
                      {result.error && (
                        <p className="text-red-600 text-sm mt-1">
                          Error: {result.error}
                        </p>
                      )}
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(result.timestamp).toLocaleTimeString()}
                    </span>
                  </div>

                  {result.success && result.data && (
                    <details className="mt-3">
                      <summary className="cursor-pointer text-sm text-[#B8860B] hover:text-[#1D2B3D] transition-colors duration-300">
                        View Response Data
                      </summary>
                      <div className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-auto max-h-40">
                        <pre>{JSON.stringify(result.data, null, 2)}</pre>
                      </div>
                    </details>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-lg">
              <h3 className="font-semibold text-[#1D2B3D] mb-2">
                Test Summary
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-[#1D2B3D]">Total Tests</div>
                  <div className="font-bold text-[#1D2B3D]">
                    {testResults.length}
                  </div>
                </div>
                <div>
                  <div className="text-green-600">Passed</div>
                  <div className="font-bold text-green-700">
                    {testResults.filter((r) => r.success).length}
                  </div>
                </div>
                <div>
                  <div className="text-red-600">Failed</div>
                  <div className="font-bold text-red-700">
                    {testResults.filter((r) => !r.success).length}
                  </div>
                </div>
                <div>
                  <div className="text-[#B8860B]">Success Rate</div>
                  <div className="font-bold text-[#B8860B]">
                    {testResults.length > 0
                      ? Math.round(
                          (testResults.filter((r) => r.success).length /
                            testResults.length) *
                            100,
                        )
                      : 0}
                    %
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
