"use client";

import { useState, useEffect } from "react";
import {
  Camera,
  TrendingUp,
  Users,
  Eye,
  Palette,
  Star,
  Zap,
  Award,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function SuperModelingDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [modelData, setModelData] = useState(null);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoadingData(true);

      const mockData = {
        summary: {
          totalModels: 18,
          avgREI: 0.92,
          avgBVI: 0.87,
          avgCPI: 0.9,
        },
        models: [],
      };

      setModelData(mockData);
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900 flex items-center justify-center">
        <div className="text-center">
          <Camera className="w-16 h-16 text-purple-400 mx-auto mb-4 animate-pulse" />
          <p className="text-white text-xl mt-4">
            Loading Super Modeling Advisory...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900">
      {/* Header */}
      <header className="border-b border-purple-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Camera className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Super Modeling NIL Advisory
                </h1>
                <p className="text-purple-300 text-sm">
                  Runway Analytics · Brand Versatility · Camera Presence
                  Intelligence
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-purple-300">Logged in as</p>
                <p className="text-white font-semibold">
                  {user?.name || user?.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="border-b border-purple-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "overview", label: "Overview", icon: Eye },
              { id: "models", label: "Model Portfolio", icon: Users },
              { id: "performance", label: "Performance Units", icon: Zap },
              { id: "indices", label: "Runway Indices", icon: TrendingUp },
              { id: "brands", label: "Brand Fit Analytics", icon: Palette },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-purple-400 text-purple-400"
                    : "border-transparent text-purple-300 hover:text-purple-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && <OverviewTab modelData={modelData} />}
        {activeTab === "models" && <ModelPortfolioTab />}
        {activeTab === "performance" && <PerformanceUnitsTab />}
        {activeTab === "indices" && <RunwayIndicesTab />}
        {activeTab === "brands" && <BrandFitAnalyticsTab />}
      </div>
    </div>
  );
}

function OverviewTab({ modelData }) {
  const metrics = modelData?.summary || {
    totalModels: 18,
    avgREI: 0.92,
    avgBVI: 0.87,
    avgCPI: 0.9,
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Models"
          value={metrics.totalModels}
          icon={Users}
          trend="+4 this quarter"
          color="purple"
        />
        <MetricCard
          title="Avg REI (Runway)"
          value={(metrics.avgREI * 100).toFixed(1)}
          icon={Zap}
          trend="+6.3% vs last quarter"
          color="pink"
        />
        <MetricCard
          title="Avg Brand Versatility"
          value={(metrics.avgBVI * 100).toFixed(1)}
          icon={Palette}
          trend="+4.7% vs last quarter"
          color="blue"
        />
        <MetricCard
          title="Avg Camera Presence"
          value={(metrics.avgCPI * 100).toFixed(1)}
          icon={Camera}
          trend="+5.2% vs last quarter"
          color="green"
        />
      </div>

      {/* Performance Units Dashboard */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6">
          Performance Unit Breakdown
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <PerformanceUnitCard
            title="Runway Gait Units (RGU)"
            value="842"
            efficiency="95.1%"
            color="purple"
          />
          <PerformanceUnitCard
            title="Pose Stability Units (PSU)"
            value="1,294"
            efficiency="92.3%"
            color="pink"
          />
          <PerformanceUnitCard
            title="Expression Fidelity Units (EFU)"
            value="1,086"
            efficiency="89.7%"
            color="blue"
          />
          <PerformanceUnitCard
            title="Camera-Hold Units (CHU)"
            value="2,103"
            efficiency="93.4%"
            color="green"
          />
          <PerformanceUnitCard
            title="Brand Fit Units (BFU)"
            value="654"
            efficiency="87.8%"
            color="yellow"
          />
          <PerformanceUnitCard
            title="Editorial Versatility Units"
            value="921"
            efficiency="91.2%"
            color="red"
          />
        </div>
      </div>

      {/* Recent Sessions */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Recent Modeling Sessions
        </h2>
        <div className="space-y-3">
          {[
            {
              model: "Model A",
              session: "Paris Fashion Week",
              rei: 0.96,
              bvi: 0.91,
              brand: "Chanel",
              date: "3 hours ago",
            },
            {
              model: "Model B",
              session: "Editorial Shoot",
              rei: 0.93,
              bvi: 0.88,
              brand: "Vogue",
              date: "6 hours ago",
            },
            {
              model: "Model C",
              session: "Campaign Shoot",
              rei: 0.91,
              bvi: 0.85,
              brand: "L'Oréal",
              date: "1 day ago",
            },
          ].map((scan, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-4 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Camera className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">{scan.model}</p>
                  <p className="text-sm text-purple-300">
                    {scan.session} · {scan.brand}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold">
                  REI {(scan.rei * 100).toFixed(0)}
                </p>
                <p className="text-sm text-purple-300">
                  BVI {(scan.bvi * 100).toFixed(0)} · {scan.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Agency Benchmarks */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Agency Performance Benchmarks
        </h2>
        <div className="space-y-3">
          {[
            {
              agency: "IMG Models",
              avgREI: 0.94,
              modelCount: 28,
              trend: "+5.2%",
            },
            {
              agency: "Elite Model Management",
              avgREI: 0.91,
              modelCount: 24,
              trend: "+4.1%",
            },
            {
              agency: "The Society Management",
              avgREI: 0.93,
              modelCount: 22,
              trend: "+6.3%",
            },
          ].map((agency, i) => (
            <div
              key={i}
              className="p-4 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold">{agency.agency}</p>
                  <p className="text-sm text-purple-300">
                    {agency.modelCount} models tracked
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-white">
                    {(agency.avgREI * 100).toFixed(1)}
                  </p>
                  <p className="text-sm text-green-400">{agency.trend}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ModelPortfolioTab() {
  const models = [
    {
      name: "Model A",
      category: "High Fashion",
      rei: 0.96,
      bvi: 0.91,
      nilValue: 350000,
    },
    {
      name: "Model B",
      category: "Commercial",
      rei: 0.93,
      bvi: 0.88,
      nilValue: 280000,
    },
    {
      name: "Model C",
      category: "Editorial",
      rei: 0.91,
      bvi: 0.85,
      nilValue: 245000,
    },
    {
      name: "Model D",
      category: "Runway Specialist",
      rei: 0.94,
      bvi: 0.87,
      nilValue: 315000,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Model Portfolio</h2>
        <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors">
          Add Model
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {models.map((model, i) => (
          <ModelCard key={i} model={model} />
        ))}
      </div>
    </div>
  );
}

function PerformanceUnitsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Performance Unit Analytics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Runway Gait Units (RGU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Total RGUs Captured</span>
              <span className="text-white font-bold">842</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Gait Consistency</span>
              <span className="text-green-400 font-bold">95.1%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Avg Stride Quality</span>
              <span className="text-white font-bold">9.4 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Pose Stability Units (PSU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Total PSUs Captured</span>
              <span className="text-white font-bold">1,294</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Hold Stability</span>
              <span className="text-green-400 font-bold">92.3%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Balance Score</span>
              <span className="text-white font-bold">9.1 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Expression Fidelity Units (EFU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Total EFUs Tracked</span>
              <span className="text-white font-bold">1,086</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Expression Range</span>
              <span className="text-green-400 font-bold">89.7%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Emotion Authenticity</span>
              <span className="text-white font-bold">8.9 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Camera-Hold Units (CHU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Total CHUs Captured</span>
              <span className="text-white font-bold">2,103</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Hold Duration Quality</span>
              <span className="text-green-400 font-bold">93.4%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Avg Hold Time</span>
              <span className="text-white font-bold">4.2s</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RunwayIndicesTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Runway Performance Indices
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Core Indices</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Runway Efficiency Index (REI)"
            value="92.4"
            trend="+6.3"
          />
          <IndexCard
            title="Expression Fidelity Index (EFI)"
            value="89.7"
            trend="+4.1"
          />
          <IndexCard
            title="Brand Versatility Index (BVI)"
            value="87.2"
            trend="+4.7"
          />
        </div>
      </div>

      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Advanced Indices
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Camera Presence Index (CPI)"
            value="90.3"
            trend="+5.2"
          />
          <IndexCard title="Poise Stability Index" value="93.1" trend="+3.8" />
          <IndexCard
            title="Editorial Versatility Index"
            value="88.6"
            trend="+4.9"
          />
        </div>
      </div>
    </div>
  );
}

function BrandFitAnalyticsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Brand Fit & Domain Pack Analytics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Luxury Brand Alignment
          </h3>
          <div className="space-y-3">
            {[
              { brand: "Chanel", alignment: 0.94, models: 6 },
              { brand: "Dior", alignment: 0.91, models: 5 },
              { brand: "Louis Vuitton", alignment: 0.89, models: 4 },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-purple-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.brand}</p>
                  <p className="text-sm text-purple-300">
                    {item.models} models aligned
                  </p>
                </div>
                <p className="text-white font-bold">
                  {(item.alignment * 100).toFixed(0)}%
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Commercial Brand Alignment
          </h3>
          <div className="space-y-3">
            {[
              { brand: "H&M", alignment: 0.88, models: 8 },
              { brand: "Zara", alignment: 0.86, models: 7 },
              { brand: "Gap", alignment: 0.84, models: 6 },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-purple-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.brand}</p>
                  <p className="text-sm text-purple-300">
                    {item.models} models aligned
                  </p>
                </div>
                <p className="text-white font-bold">
                  {(item.alignment * 100).toFixed(0)}%
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color }) {
  const colorClasses = {
    purple: "from-purple-500 to-purple-600",
    pink: "from-pink-500 to-pink-600",
    blue: "from-blue-500 to-blue-600",
    green: "from-green-500 to-green-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-purple-300 uppercase">
          {title}
        </p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function PerformanceUnitCard({ title, value, efficiency, color }) {
  return (
    <div className="p-4 bg-purple-900/20 rounded-lg border border-purple-500/20">
      <p className="text-sm text-purple-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{efficiency} efficiency</p>
    </div>
  );
}

function ModelCard({ model }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6 hover:border-purple-400 transition-all cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
          <Camera className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-lg">{model.name}</p>
          <p className="text-sm text-purple-300">{model.category}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-purple-300">
            Runway Efficiency (REI)
          </span>
          <span className="text-white font-bold">
            {(model.rei * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-purple-300">
            Brand Versatility (BVI)
          </span>
          <span className="text-white font-bold">
            {(model.bvi * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-purple-300">NIL Value</span>
          <span className="text-white font-bold">
            ${(model.nilValue / 1000).toFixed(0)}K
          </span>
        </div>
      </div>
    </div>
  );
}

function IndexCard({ title, value, trend }) {
  return (
    <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4">
      <p className="text-sm text-purple-300 mb-2">{title}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm text-green-400">+{trend}</p>
      </div>
    </div>
  );
}
