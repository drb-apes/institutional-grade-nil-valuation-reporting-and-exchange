"use client";

import { useState } from "react";
import useUser from "@/utils/useUser";
import Footer from "@/components/Footer";
import { PageHeader } from "@/components/BIMVisualizationSuite/PageHeader";
import { SportSelector } from "@/components/BIMVisualizationSuite/SportSelector";
import { ChartTypeSelector } from "@/components/BIMVisualizationSuite/ChartTypeSelector";
import { ARBiomechanicalOverlay } from "@/components/BIMVisualizationSuite/ARBiomechanicalOverlay";
import { BiomechflowChart } from "@/components/BIMVisualizationSuite/BiomechflowChart";
import {
  HeatmapDisplay,
  RadarDisplay,
  CandlestickDisplay,
  TrendlineDisplay,
} from "@/components/BIMVisualizationSuite/ChartDisplays";
import { NILComponentsSection } from "@/components/BIMVisualizationSuite/NILComponentsSection";
import { IntegrationExamples } from "@/components/BIMVisualizationSuite/IntegrationExamples";
import { UseCaseCards } from "@/components/BIMVisualizationSuite/UseCaseCards";
import { sportConfigs } from "@/components/BIMVisualizationSuite/sportConfigs";
import {
  athleteRadar,
  nilRadar,
  generateNILCandlestick,
  performanceTrend,
} from "@/components/BIMVisualizationSuite/constants";

export default function BIMVisualizationSuite() {
  const { data: user, loading } = useUser();
  const [activeSport, setActiveSport] = useState("wrestling");
  const [activeChart, setActiveChart] = useState("ar-overlay"); // Changed default to AR overlay

  const currentConfig = sportConfigs[activeSport];
  const nilCandlestick = generateNILCandlestick();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-indigo-400 underline">
            sign in
          </a>{" "}
          to access visualizations
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex flex-col">
      <div className="flex-1 p-6">
        <PageHeader />

        <div className="max-w-7xl mx-auto space-y-6">
          <SportSelector
            sportConfigs={sportConfigs}
            activeSport={activeSport}
            onSportChange={setActiveSport}
          />

          <ChartTypeSelector
            activeChart={activeChart}
            onChartChange={setActiveChart}
          />

          {/* Updated chart rendering to include ar-overlay and biomechflow as active tabs */}
          {activeChart === "ar-overlay" && (
            <ARBiomechanicalOverlay
              sport={activeSport}
              sportConfig={currentConfig}
            />
          )}

          {activeChart === "biomechflow" && (
            <BiomechflowChart sport={activeSport} sportConfig={currentConfig} />
          )}

          {activeChart === "heatmap" && (
            <HeatmapDisplay currentConfig={currentConfig} />
          )}

          {activeChart === "radar" && (
            <RadarDisplay athleteRadar={athleteRadar} />
          )}

          {activeChart === "candlestick" && (
            <CandlestickDisplay nilCandlestick={nilCandlestick} />
          )}

          {activeChart === "trendline" && (
            <TrendlineDisplay performanceTrend={performanceTrend} />
          )}

          <NILComponentsSection nilRadar={nilRadar} />

          <IntegrationExamples />

          <UseCaseCards />
        </div>
      </div>

      <Footer />
    </div>
  );
}
