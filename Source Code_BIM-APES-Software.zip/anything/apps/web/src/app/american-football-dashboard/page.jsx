"use client";

import { useState } from "react";
import {
  Activity,
  Target,
  Shield,
  Zap,
  TrendingUp,
  AlertCircle,
  ChevronRight,
  BarChart2,
} from "lucide-react";
import useUser from "@/utils/useUser";
import Footer from "@/components/Footer";

const POSITIONS = {
  QB: {
    label: "Quarterback",
    color: "#FFCC33",
    metrics: [
      "passingYards",
      "completions",
      "attempts",
      "touchdowns",
      "interceptions",
      "rushingYards",
    ],
  },
  RB: {
    label: "Running Back",
    color: "#3CFF7A",
    metrics: [
      "rushingYards",
      "carries",
      "yardsPerCarry",
      "receptions",
      "touchdowns",
      "fumbles",
    ],
  },
  WR: {
    label: "Wide Receiver",
    color: "#4DA6FF",
    metrics: [
      "targets",
      "receptions",
      "receivingYards",
      "yardsPerReception",
      "touchdowns",
      "droppedPasses",
    ],
  },
  LB: {
    label: "Linebacker",
    color: "#FF8C33",
    metrics: [
      "totalTackles",
      "soloTackles",
      "sacksCount",
      "interceptions",
      "passDeflections",
      "forcedFumbles",
    ],
  },
  DB: {
    label: "Defensive Back",
    color: "#FF3C3C",
    metrics: [
      "totalTackles",
      "interceptions",
      "passDeflections",
      "coveredPlays",
      "missedTackles",
      "beatenRoutes",
    ],
  },
};

const SESSION_DEFAULTS = [
  {
    date: "2024-01-07",
    passingYards: 285,
    completions: 22,
    attempts: 34,
    touchdowns: 2,
    interceptions: 1,
    rushingYards: 18,
    quality: 78,
  },
  {
    date: "2024-01-14",
    passingYards: 312,
    completions: 24,
    attempts: 36,
    touchdowns: 3,
    interceptions: 0,
    rushingYards: 24,
    quality: 85,
  },
  {
    date: "2024-01-21",
    passingYards: 198,
    completions: 17,
    attempts: 30,
    touchdowns: 1,
    interceptions: 2,
    rushingYards: 10,
    quality: 62,
  },
  {
    date: "2024-01-28",
    passingYards: 340,
    completions: 26,
    attempts: 38,
    touchdowns: 3,
    interceptions: 0,
    rushingYards: 32,
    quality: 89,
  },
  {
    date: "2024-02-04",
    passingYards: 275,
    completions: 21,
    attempts: 33,
    touchdowns: 2,
    interceptions: 1,
    rushingYards: 20,
    quality: 76,
  },
];

function ConsistencyChart({ sessions, color }) {
  if (!sessions || sessions.length === 0) return null;
  const w = 480,
    h = 120,
    pad = 30;
  const maxQ = 100,
    minQ = 0;
  const scores = sessions.map((s) => s.quality || 70);
  const pts = scores.map((q, i) => ({
    x: pad + (i / Math.max(1, scores.length - 1)) * (w - pad * 2),
    y: h - pad - ((q - minQ) / (maxQ - minQ)) * (h - pad * 2),
    q,
  }));
  const pathD = pts.reduce(
    (d, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${d} L ${p.x} ${p.y}`),
    "",
  );
  const areaD = `${pathD} L ${pts[pts.length - 1].x} ${h - pad} L ${pts[0].x} ${h - pad} Z`;
  const avg = scores.reduce((s, v) => s + v, 0) / scores.length;
  const avgY = h - pad - ((avg - minQ) / (maxQ - minQ)) * (h - pad * 2);

  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: "100%" }}>
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      {/* Grid lines */}
      {[25, 50, 75, 100].map((v) => {
        const y = h - pad - ((v - minQ) / (maxQ - minQ)) * (h - pad * 2);
        return (
          <g key={v}>
            <line
              x1={pad}
              y1={y}
              x2={w - pad}
              y2={y}
              stroke="#1a2a4a"
              strokeWidth="1"
            />
            <text
              x={pad - 5}
              y={y + 4}
              textAnchor="end"
              fill="#444"
              fontSize="9"
            >
              {v}
            </text>
          </g>
        );
      })}
      {/* Average line */}
      <line
        x1={pad}
        y1={avgY}
        x2={w - pad}
        y2={avgY}
        stroke={color}
        strokeWidth="1"
        strokeDasharray="6,4"
        opacity="0.5"
      />
      <text
        x={w - pad + 5}
        y={avgY + 4}
        fill={color}
        fontSize="9"
        opacity="0.7"
      >
        AVG {avg.toFixed(0)}
      </text>
      {/* Area */}
      <path d={areaD} fill="url(#areaGrad)" />
      {/* Line */}
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
      {/* Points */}
      {pts.map((p, i) => (
        <g key={i}>
          <circle
            cx={p.x}
            cy={p.y}
            r="5"
            fill={color}
            stroke="#0a1628"
            strokeWidth="2"
          />
          <text
            x={p.x}
            y={p.y - 10}
            textAnchor="middle"
            fill={color}
            fontSize="9"
            fontFamily="monospace"
            fontWeight="700"
          >
            {p.q}
          </text>
          <text x={p.x} y={h - 5} textAnchor="middle" fill="#444" fontSize="8">
            {sessions[i].date?.slice(5)}
          </text>
        </g>
      ))}
    </svg>
  );
}

function StatBar({ label, value, max, color = "#FFCC33" }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="mb-3">
      <div className="flex justify-between mb-1">
        <span className="text-slate-300 text-sm">{label}</span>
        <span
          style={{
            color,
            fontFamily: "monospace",
            fontSize: 13,
            fontWeight: 700,
          }}
        >
          {value}
        </span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className="h-2 rounded-full transition-all duration-700"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, ${color}66, ${color})`,
          }}
        />
      </div>
    </div>
  );
}

function computeConsistency(sessions) {
  if (!sessions || sessions.length < 2)
    return { score: 0, variance: 0, trend: "stable" };
  const q = sessions.map((s) => s.quality || 70);
  const avg = q.reduce((s, v) => s + v, 0) / q.length;
  const variance = q.reduce((s, v) => s + Math.pow(v - avg, 2), 0) / q.length;
  const std = Math.sqrt(variance);
  const cv = std / avg;
  const consistencyScore = Math.max(0, Math.min(100, 100 - cv * 100));
  const recent = q.slice(-3);
  const earlier = q.slice(0, Math.floor(q.length / 2));
  const recentAvg = recent.reduce((s, v) => s + v, 0) / recent.length;
  const earlierAvg = earlier.reduce((s, v) => s + v, 0) / earlier.length;
  const trend =
    recentAvg > earlierAvg + 3
      ? "improving"
      : recentAvg < earlierAvg - 3
        ? "declining"
        : "stable";
  const bimScore = Math.min(100, consistencyScore * 0.6 + avg * 0.4);
  return {
    score: consistencyScore,
    avg,
    variance,
    std,
    cv,
    trend,
    bimScore,
    peak: Math.max(...q),
    low: Math.min(...q),
  };
}

export default function AmericanFootballDashboard() {
  const { data: user, loading } = useUser();
  const [position, setPosition] = useState("QB");
  const [athleteId, setAthleteId] = useState("1");
  const [sessions, setSessions] = useState(SESSION_DEFAULTS);
  const [result, setResult] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const posInfo = POSITIONS[position];

  const addSession = () => {
    setSessions((p) => [
      ...p,
      {
        date: new Date().toISOString().split("T")[0],
        passingYards: 0,
        completions: 0,
        attempts: 0,
        touchdowns: 0,
        interceptions: 0,
        rushingYards: 0,
        rushingYards2: 0,
        carries: 0,
        yardsPerCarry: 0,
        receptions: 0,
        fumbles: 0,
        targets: 0,
        receivingYards: 0,
        yardsPerReception: 0,
        droppedPasses: 0,
        totalTackles: 0,
        soloTackles: 0,
        sacksCount: 0,
        passDeflections: 0,
        forcedFumbles: 0,
        coveredPlays: 0,
        missedTackles: 0,
        beatenRoutes: 0,
        quality: 70,
      },
    ]);
  };

  const updateSession = (i, field, val) => {
    setSessions((prev) =>
      prev.map((s, idx) =>
        idx === i ? { ...s, [field]: parseFloat(val) || 0 } : s,
      ),
    );
  };

  const handleAnalyze = async () => {
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }
    setLoadingData(true);
    setError(null);
    try {
      const consistency = computeConsistency(sessions);
      // Call the sport-specific consistency API
      const res = await fetch(
        "/api/sport-specific/american-football/consistency-monitor",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            position,
            sessions,
            timeframe: "monthly",
          }),
        },
      );
      let apiData = null;
      if (res.ok) {
        apiData = await res.json();
      }
      setResult({ ...consistency, ...(apiData || {}), position, sessions });
    } catch (err) {
      // Fallback: use local computation
      const consistency = computeConsistency(sessions);
      setResult({ ...consistency, position, sessions });
      console.error(err);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{
          background: "linear-gradient(135deg, #1a0a00, #2a1400, #1a0a00)",
        }}
      >
        <div className="text-white text-xl">
          Loading American Football Consistency Module...
        </div>
      </div>
    );
  if (!user)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #1a0a00, #2a1400)" }}
      >
        <div className="text-center">
          <Shield className="w-16 h-16 text-amber-400 mx-auto mb-4" />
          <p className="text-white text-xl mb-4">
            American Football Consistency Monitor
          </p>
          <a
            href="/account/signin"
            className="bg-amber-600 text-white px-6 py-3 rounded-lg font-semibold"
          >
            Sign In
          </a>
        </div>
      </div>
    );

  const consistency = computeConsistency(sessions);

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "linear-gradient(135deg, #100800, #1a1000, #0a0800)",
      }}
    >
      {/* Header */}
      <div className="border-b border-white/10 bg-black/20 backdrop-blur-lg sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: posInfo.color + "22" }}
          >
            <Shield className="w-6 h-6" style={{ color: posInfo.color }} />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg">
              American Football Consistency Monitor
            </h1>
            <p className="text-xs" style={{ color: posInfo.color }}>
              BIM-APES · Session-by-Session Consistency Intelligence
            </p>
          </div>
        </div>
      </div>

      {/* Position Selector */}
      <div className="max-w-7xl mx-auto w-full px-4 md:px-6 pt-5">
        <div className="flex gap-2 flex-wrap">
          {Object.entries(POSITIONS).map(([key, p]) => (
            <button
              key={key}
              onClick={() => setPosition(key)}
              className="px-4 py-2 rounded-xl font-bold text-sm transition-all"
              style={{
                background:
                  position === key ? p.color : "rgba(255,255,255,0.05)",
                color: position === key ? "#000" : "#aaa",
              }}
            >
              {key} · {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-4 md:p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Live Consistency Preview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              [
                "Consistency Score",
                consistency.score.toFixed(1),
                posInfo.color,
              ],
              ["Avg Quality", consistency.avg?.toFixed(1) || "—", "#4DA6FF"],
              ["Peak Session", consistency.peak || "—", "#3CFF7A"],
              [
                "Trend",
                consistency.trend || "stable",
                consistency.trend === "improving"
                  ? "#3CFF7A"
                  : consistency.trend === "declining"
                    ? "#FF3C3C"
                    : "#FFD93C",
              ],
            ].map(([l, v, c]) => (
              <div
                key={l}
                className="bg-white/5 rounded-2xl p-4 border border-white/10 text-center"
              >
                <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                  {l}
                </p>
                <p
                  style={{
                    color: c,
                    fontFamily: "monospace",
                    fontSize: 20,
                    fontWeight: 900,
                    textTransform: "uppercase",
                  }}
                >
                  {v}
                </p>
              </div>
            ))}
          </div>

          {/* Consistency Chart */}
          <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-base">
                Session Consistency Curve
              </h3>
              <div className="flex items-center gap-3">
                <div>
                  <label className="text-slate-400 text-xs mr-2">
                    Athlete ID
                  </label>
                  <input
                    type="number"
                    value={athleteId}
                    onChange={(e) => setAthleteId(e.target.value)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 text-white border border-slate-700 text-sm w-20 focus:outline-none"
                  />
                </div>
                <button
                  onClick={handleAnalyze}
                  disabled={loadingData}
                  className="px-4 py-1.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50"
                  style={{ background: posInfo.color, color: "#000" }}
                >
                  {loadingData ? "Computing..." : "⚡ Full Analysis"}
                </button>
              </div>
            </div>
            <ConsistencyChart sessions={sessions} color={posInfo.color} />
          </div>

          {/* Session Input Table */}
          <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-base">
                Session Data ({position})
              </h3>
              <button
                onClick={addSession}
                className="text-xs px-3 py-1.5 rounded-lg border border-white/20 text-slate-300 hover:bg-white/10 transition-all"
              >
                + Add Session
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px]">
                <thead>
                  <tr>
                    <th className="text-left text-slate-400 text-xs uppercase tracking-wider pb-3 pr-4">
                      Date
                    </th>
                    {position === "QB" && (
                      <>
                        <th className="text-right text-slate-400 text-xs uppercase tracking-wider pb-3 px-2">
                          Pass Yds
                        </th>
                        <th className="text-right text-slate-400 text-xs uppercase tracking-wider pb-3 px-2">
                          Comp/Att
                        </th>
                        <th className="text-right text-slate-400 text-xs uppercase tracking-wider pb-3 px-2">
                          TD/INT
                        </th>
                        <th className="text-right text-slate-400 text-xs uppercase tracking-wider pb-3 px-2">
                          Rush Yds
                        </th>
                      </>
                    )}
                    <th className="text-right text-slate-400 text-xs uppercase tracking-wider pb-3 px-2">
                      Quality
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {sessions.map((s, i) => (
                    <tr key={i} className="border-t border-white/5">
                      <td className="py-2 pr-4">
                        <input
                          type="date"
                          value={s.date || ""}
                          onChange={(e) =>
                            updateSession(i, "date", e.target.value)
                          }
                          className="bg-slate-800 text-white border border-slate-700 rounded-lg px-2 py-1 text-xs w-[120px] focus:outline-none"
                        />
                      </td>
                      {position === "QB" && (
                        <>
                          <td className="py-2 px-2">
                            <input
                              type="number"
                              value={s.passingYards}
                              onChange={(e) =>
                                updateSession(i, "passingYards", e.target.value)
                              }
                              className="bg-slate-800 text-white border border-slate-700 rounded-lg px-2 py-1 text-xs w-16 text-right focus:outline-none"
                            />
                          </td>
                          <td className="py-2 px-2">
                            <div className="flex gap-1">
                              <input
                                type="number"
                                value={s.completions}
                                onChange={(e) =>
                                  updateSession(
                                    i,
                                    "completions",
                                    e.target.value,
                                  )
                                }
                                className="bg-slate-800 text-white border border-slate-700 rounded-lg px-1 py-1 text-xs w-10 text-right focus:outline-none"
                              />
                              <span className="text-slate-500 text-xs self-center">
                                /
                              </span>
                              <input
                                type="number"
                                value={s.attempts}
                                onChange={(e) =>
                                  updateSession(i, "attempts", e.target.value)
                                }
                                className="bg-slate-800 text-white border border-slate-700 rounded-lg px-1 py-1 text-xs w-10 text-right focus:outline-none"
                              />
                            </div>
                          </td>
                          <td className="py-2 px-2">
                            <div className="flex gap-1">
                              <input
                                type="number"
                                value={s.touchdowns}
                                onChange={(e) =>
                                  updateSession(i, "touchdowns", e.target.value)
                                }
                                className="bg-slate-800 text-white border border-slate-700 rounded-lg px-1 py-1 text-xs w-10 text-right focus:outline-none"
                              />
                              <span className="text-slate-500 text-xs self-center">
                                /
                              </span>
                              <input
                                type="number"
                                value={s.interceptions}
                                onChange={(e) =>
                                  updateSession(
                                    i,
                                    "interceptions",
                                    e.target.value,
                                  )
                                }
                                className="bg-slate-800 text-white border border-slate-700 rounded-lg px-1 py-1 text-xs w-10 text-right focus:outline-none"
                              />
                            </div>
                          </td>
                          <td className="py-2 px-2">
                            <input
                              type="number"
                              value={s.rushingYards}
                              onChange={(e) =>
                                updateSession(i, "rushingYards", e.target.value)
                              }
                              className="bg-slate-800 text-white border border-slate-700 rounded-lg px-2 py-1 text-xs w-14 text-right focus:outline-none"
                            />
                          </td>
                        </>
                      )}
                      <td className="py-2 px-2">
                        <input
                          type="number"
                          value={s.quality}
                          min="0"
                          max="100"
                          onChange={(e) =>
                            updateSession(i, "quality", e.target.value)
                          }
                          className="rounded-lg px-2 py-1 text-xs w-14 text-right font-bold font-mono focus:outline-none"
                          style={{
                            background:
                              s.quality >= 80
                                ? "#3CFF7A22"
                                : s.quality >= 60
                                  ? "#FFD93C22"
                                  : "#FF3C3C22",
                            color:
                              s.quality >= 80
                                ? "#3CFF7A"
                                : s.quality >= 60
                                  ? "#FFD93C"
                                  : "#FF3C3C",
                            border: "1px solid transparent",
                          }}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Full Analysis Results */}
          {result && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Consistency Metrics */}
              <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                <h3 className="text-white font-bold text-base mb-4">
                  Consistency Analytics
                </h3>
                <StatBar
                  label="Consistency Score"
                  value={result.score?.toFixed(1) || 0}
                  max={100}
                  color={posInfo.color}
                />
                <StatBar
                  label="Average Quality"
                  value={result.avg?.toFixed(1) || 0}
                  max={100}
                  color="#4DA6FF"
                />
                <StatBar
                  label="BIM Score"
                  value={
                    result.bimScore?.toFixed(1) ||
                    (result.score * 0.85).toFixed(1)
                  }
                  max={100}
                  color="#FFCC33"
                />
                <StatBar
                  label="Peak Session"
                  value={result.peak || 0}
                  max={100}
                  color="#3CFF7A"
                />

                <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
                  {[
                    ["Standard Deviation", result.std?.toFixed(2) || "—"],
                    [
                      "Coefficient of Variation",
                      result.cv ? `${(result.cv * 100).toFixed(1)}%` : "—",
                    ],
                    ["Performance Trend", result.trend?.toUpperCase() || "—"],
                    ["Sessions Analyzed", result.sessions?.length || 0],
                  ].map(([l, v]) => (
                    <div key={l} className="flex justify-between">
                      <span className="text-slate-400 text-sm">{l}</span>
                      <span
                        style={{
                          color: posInfo.color,
                          fontFamily: "monospace",
                          fontWeight: 700,
                        }}
                      >
                        {v}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* NIL Valuation */}
              <div className="space-y-4">
                <div
                  style={{
                    background: `linear-gradient(135deg, ${posInfo.color}11, rgba(30,95,168,0.1))`,
                    border: `1px solid ${posInfo.color}30`,
                    borderRadius: 16,
                    padding: 24,
                  }}
                >
                  <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">
                    NIL Consistency Premium
                  </p>
                  <p
                    style={{
                      color: posInfo.color,
                      fontSize: 32,
                      fontWeight: 900,
                      fontFamily: "monospace",
                    }}
                  >
                    ${((result.score || 70) * 1500).toLocaleString()}
                  </p>
                  <p className="text-slate-400 text-sm mt-2">
                    Based on {result.sessions?.length || 5} sessions at{" "}
                    {position} position
                  </p>
                </div>

                <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
                  <p className="text-white font-bold mb-3">
                    Consistency Signals
                  </p>
                  {[
                    {
                      signal: "Session Variance",
                      value:
                        result.std?.toFixed(1) < 10
                          ? "LOW — Sponsor Friendly"
                          : "HIGH — Needs Stability",
                      ok: result.std?.toFixed(1) < 10,
                    },
                    {
                      signal: "Performance Trend",
                      value:
                        result.trend === "improving"
                          ? "UPWARD — Acquisition Window"
                          : result.trend === "declining"
                            ? "DECLINING — Risk Alert"
                            : "STABLE — Hold Signal",
                      ok: result.trend !== "declining",
                    },
                    {
                      signal: "BIM Eligibility",
                      value:
                        (result.bimScore || 70) >= 65
                          ? "ELIGIBLE — Tier 2+"
                          : "DEVELOPING — Tier 1",
                      ok: (result.bimScore || 70) >= 65,
                    },
                  ].map(({ signal, value, ok }) => (
                    <div
                      key={signal}
                      className="flex items-start gap-3 mb-3 last:mb-0"
                    >
                      <div
                        style={{
                          width: 8,
                          height: 8,
                          borderRadius: "50%",
                          background: ok ? "#3CFF7A" : "#FF3C3C",
                          flexShrink: 0,
                          marginTop: 4,
                        }}
                      />
                      <div>
                        <p className="text-slate-400 text-xs uppercase tracking-wider">
                          {signal}
                        </p>
                        <p
                          style={{
                            color: ok ? "#3CFF7A" : "#FF3C3C",
                            fontSize: 12,
                            fontWeight: 700,
                          }}
                        >
                          {value}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
}
