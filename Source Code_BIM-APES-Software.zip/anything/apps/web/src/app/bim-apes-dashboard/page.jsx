"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { BRAND_CLASSES } from "@/utils/brandColors";

export default function BIMAPESDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("positions");
  const [loading, setLoading] = useState(false);

  // State for different sections
  const [positions, setPositions] = useState(null);
  const [arbitrageOpps, setArbitrageOpps] = useState([]);
  const [scalpingSignals, setScalpingSignals] = useState([]);
  const [riskMetrics, setRiskMetrics] = useState(null);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadPositions(),
        loadArbitrageOpportunities(),
        loadScalpingSignals(),
        loadRiskMetrics(),
      ]);
    } catch (error) {
      console.error("Dashboard load error:", error);
    }
    setLoading(false);
  };

  const loadPositions = async () => {
    try {
      const res = await fetch(`/api/bim-apes/hedge-strategies?sponsorId=1`);
      const data = await res.json();
      setPositions(data);
    } catch (error) {
      console.error("Load positions error:", error);
    }
  };

  const loadArbitrageOpportunities = async () => {
    try {
      const res = await fetch(
        "/api/bim-apes/nil-valuation?minSpread=10&limit=10",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "scan_opportunities",
            minSpread: 10,
            limit: 10,
          }),
        },
      );
      const data = await res.json();
      setArbitrageOpps(data.opportunities || []);
    } catch (error) {
      console.error("Load arbitrage error:", error);
    }
  };

  const loadScalpingSignals = async () => {
    try {
      const res = await fetch("/api/scalping/capture?limit=20");
      const data = await res.json();
      setScalpingSignals(data.moments || []);
    } catch (error) {
      console.error("Load scalping error:", error);
    }
  };

  const loadRiskMetrics = async () => {
    try {
      const res = await fetch("/api/bim-apes/hedge-strategies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "monitor_exposure",
          sponsorId: 1,
        }),
      });
      const data = await res.json();
      setRiskMetrics(data);
    } catch (error) {
      console.error("Load risk metrics error:", error);
    }
  };

  if (userLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#C8A882] mb-4"></div>
          <div className="text-white text-xl">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] text-white">
      {/* Header with Brand Colors */}
      <div className="bg-[#1B3A57]/90 backdrop-blur-lg border-b-2 border-[#C8A882]">
        <div className="max-w-[1800px] mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                BIM-APES PhysiobioFIN
              </h1>
              <p className="text-[#E8DCC8]">
                Biometric Index Market - Athlete Performance Equity Swaps
              </p>
            </div>
            <button
              onClick={loadDashboardData}
              className={`${BRAND_CLASSES.btnSecondary} px-6 py-3 rounded-lg shadow-lg`}
            >
              Refresh Data
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1800px] mx-auto px-8 py-8">
        {/* Navigation Tabs with Brand Styling */}
        <div className="flex gap-2 mb-8 bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-2xl p-2">
          {["positions", "arbitrage", "scalping", "risk"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 px-6 py-3 font-semibold rounded-xl transition-all ${
                activeTab === tab
                  ? "bg-[#C8A882] text-[#1B3A57] shadow-lg"
                  : "text-[#E8DCC8] hover:bg-white/10"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {loading && (
          <div className="text-center py-12">
            <div className="text-[#E8DCC8]">Loading data...</div>
          </div>
        )}

        {/* Positions Tab */}
        {activeTab === "positions" && (
          <PositionsView positions={positions} onRefresh={loadPositions} />
        )}

        {/* Arbitrage Tab */}
        {activeTab === "arbitrage" && (
          <ArbitrageView
            opportunities={arbitrageOpps}
            onRefresh={loadArbitrageOpportunities}
          />
        )}

        {/* Scalping Tab */}
        {activeTab === "scalping" && (
          <ScalpingView
            signals={scalpingSignals}
            onRefresh={loadScalpingSignals}
          />
        )}

        {/* Risk Tab */}
        {activeTab === "risk" && (
          <RiskView metrics={riskMetrics} onRefresh={loadRiskMetrics} />
        )}
      </div>
    </div>
  );
}

// Positions View Component with Brand Colors
function PositionsView({ positions, onRefresh }) {
  if (!positions) {
    return <div className="text-[#E8DCC8]">No position data available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards with Brand Styling */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
          <div className="text-[#9CA3AF] text-sm mb-2">Total Exposure</div>
          <div className="text-3xl font-bold text-white">
            ${positions.summary?.totalExposure?.toLocaleString() || "0"}
          </div>
        </div>
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
          <div className="text-[#9CA3AF] text-sm mb-2">Active Positions</div>
          <div className="text-3xl font-bold text-[#C8A882]">
            {positions.summary?.activePositions || 0}
          </div>
        </div>
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
          <div className="text-[#9CA3AF] text-sm mb-2">Avg Position Size</div>
          <div className="text-3xl font-bold text-[#D4B896]">
            ${positions.summary?.averagePosition?.toLocaleString() || "0"}
          </div>
        </div>
      </div>

      {/* Positions List */}
      <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#C8A882]/20">
          <h3 className="text-xl font-bold text-white">Active Positions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1B3A57]/50">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-medium text-[#E8DCC8]">
                  Athlete ID
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-[#E8DCC8]">
                  Type
                </th>
                <th className="px-6 py-3 text-right text-sm font-medium text-[#E8DCC8]">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-[#E8DCC8]">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-[#E8DCC8]">
                  Created
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#C8A882]/10">
              {positions.positions?.map((pos) => (
                <tr key={pos.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 text-sm text-white">
                    #{pos.athleteId}
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-[#D4B896]/20 text-[#D4B896] border border-[#D4B896]/30 rounded-full text-xs font-medium">
                      {pos.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium text-white">
                    ${pos.amount?.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-[#C8A882]/20 text-[#C8A882] border border-[#C8A882]/30 rounded-full text-xs font-medium">
                      {pos.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-[#9CA3AF]">
                    {new Date(pos.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Arbitrage View Component with Brand Colors
function ArbitrageView({ opportunities, onRefresh }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">
          Arbitrage Opportunities
        </h2>
        <div className="text-sm text-[#E8DCC8]">
          {opportunities.length} opportunities detected
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {opportunities.map((opp, index) => (
          <div
            key={index}
            className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6 hover:border-[#C8A882]/40 transition-all"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="text-lg font-bold text-white mb-1">
                  {opp.athleteName}
                </div>
                <div className="text-sm text-[#9CA3AF]">
                  Athlete #{opp.athleteId}
                </div>
              </div>
              <div
                className={`px-4 py-2 rounded-lg font-bold text-sm border ${
                  opp.direction === "UNDERVALUED"
                    ? "bg-[#C8A882]/20 text-[#C8A882] border-[#C8A882]/30"
                    : "bg-red-500/20 text-red-400 border-red-500/30"
                }`}
              >
                {opp.direction}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div className="text-xs text-[#9CA3AF] mb-1">Model NIL</div>
                <div className="text-xl font-bold text-white">
                  ${opp.modelNIL.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#9CA3AF] mb-1">Market NIL</div>
                <div className="text-xl font-bold text-white">
                  ${opp.marketNIL.toLocaleString()}
                </div>
              </div>
            </div>

            <div className="border-t border-[#C8A882]/20 pt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#9CA3AF]">Spread</span>
                <span
                  className={`text-lg font-bold ${
                    opp.spread > 0 ? "text-[#C8A882]" : "text-red-400"
                  }`}
                >
                  {opp.spread > 0 ? "+" : ""}
                  {opp.spread.toFixed(2)}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#9CA3AF]">Confidence</span>
                <span className="text-sm font-medium text-white">
                  {opp.confidence}%
                </span>
              </div>
            </div>

            <div className="mt-4 p-3 bg-[#1B3A57]/50 rounded-lg border border-[#C8A882]/10">
              <div className="text-xs text-[#9CA3AF] mb-1">Recommendation</div>
              <div className="text-sm text-white">{opp.recommendation}</div>
            </div>
          </div>
        ))}
      </div>

      {opportunities.length === 0 && (
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-12 text-center">
          <div className="text-[#E8DCC8] mb-4">
            No arbitrage opportunities detected
          </div>
          <button
            onClick={onRefresh}
            className={`${BRAND_CLASSES.btnSecondary} px-6 py-2 rounded-lg`}
          >
            Scan for Opportunities
          </button>
        </div>
      )}
    </div>
  );
}

// Scalping View Component with Brand Colors
function ScalpingView({ signals, onRefresh }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Scalping Signals</h2>
        <div className="text-sm text-[#E8DCC8]">
          {signals.length} signals captured
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {signals.map((signal) => (
          <div
            key={signal.id}
            className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="px-4 py-2 bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded-lg text-sm font-medium">
                  {signal.type}
                </div>
                <div className="text-sm text-[#9CA3AF]">
                  Athlete #{signal.athleteId}
                </div>
              </div>
              <div className="text-sm text-[#9CA3AF]">
                {new Date(signal.capturedAt).toLocaleTimeString()}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-4">
              <div>
                <div className="text-xs text-[#9CA3AF] mb-1">Intensity</div>
                <div className="text-lg font-bold text-white">
                  {(signal.intensity * 100).toFixed(0)}%
                </div>
              </div>
              <div>
                <div className="text-xs text-[#9CA3AF] mb-1">Spotlight</div>
                <div className="text-lg font-bold text-[#C8A882]">
                  {signal.spotlightCredits}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#9CA3AF] mb-1">Event Window</div>
                <div className="text-lg font-bold text-[#D4B896]">
                  {signal.eventWindowCredits}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#9CA3AF] mb-1">Boost</div>
                <div className="text-lg font-bold text-purple-400">
                  {signal.boostCredits}
                </div>
              </div>
            </div>

            {signal.metadata && (
              <div className="bg-[#1B3A57]/50 rounded-lg p-3 border border-[#C8A882]/10">
                <div className="text-xs text-[#9CA3AF] mb-2">
                  Signal Metadata
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {Object.entries(signal.metadata).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-[#9CA3AF]">{key}:</span>
                      <span className="text-white font-mono">
                        {JSON.stringify(value)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {signals.length === 0 && (
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-12 text-center">
          <div className="text-[#E8DCC8]">No scalping signals detected</div>
        </div>
      )}
    </div>
  );
}

// Risk View Component with Brand Colors
function RiskView({ metrics, onRefresh }) {
  if (!metrics) {
    return <div className="text-[#E8DCC8]">No risk metrics available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Risk Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
          <div className="text-[#9CA3AF] text-sm mb-2">Concentration Risk</div>
          <div
            className={`text-3xl font-bold ${
              metrics.riskMetrics?.concentrationRisk > 40
                ? "text-red-400"
                : "text-[#C8A882]"
            }`}
          >
            {metrics.riskMetrics?.concentrationRisk?.toFixed(1)}%
          </div>
          {metrics.riskMetrics?.alert && (
            <div className="mt-2 text-xs text-red-400">
              {metrics.riskMetrics.alert}
            </div>
          )}
        </div>
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
          <div className="text-[#9CA3AF] text-sm mb-2">Diversification</div>
          <div className="text-3xl font-bold text-[#D4B896]">
            {metrics.riskMetrics?.diversification} athletes
          </div>
        </div>
        <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
          <div className="text-[#9CA3AF] text-sm mb-2">Total Exposure</div>
          <div className="text-3xl font-bold text-white">
            ${metrics.summary?.totalExposure?.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Exposure Breakdown */}
      <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-6">Exposure by Type</h3>
        <div className="space-y-4">
          {Object.entries(metrics.breakdown?.byType || {}).map(
            ([type, amount]) => {
              const percentage = (amount / metrics.summary.totalExposure) * 100;
              return (
                <div key={type}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-white capitalize">
                      {type.replace("_", " ")}
                    </span>
                    <span className="text-sm font-medium text-[#9CA3AF]">
                      ${amount.toLocaleString()} ({percentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full bg-[#1B3A57]/50 rounded-full h-2">
                    <div
                      className="bg-[#C8A882] h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            },
          )}
        </div>
      </div>

      {/* Athlete Exposure */}
      <div className="bg-white/5 backdrop-blur-lg border border-[#C8A882]/20 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-6">
          Exposure by Athlete
        </h3>
        <div className="space-y-3">
          {metrics.breakdown?.byAthlete?.slice(0, 10).map((item) => {
            const percentage =
              (item.exposure / metrics.summary.totalExposure) * 100;
            return (
              <div
                key={item.athleteId}
                className="flex items-center justify-between"
              >
                <span className="text-sm text-white">
                  Athlete #{item.athleteId}
                </span>
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium text-[#9CA3AF]">
                    ${item.exposure.toLocaleString()}
                  </span>
                  <span className="text-sm text-[#C8A882] w-12 text-right">
                    {percentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
