"use client";

import useUser from "@/utils/useUser";
import { useFeatureRelationshipDashboard } from "@/hooks/useFeatureRelationshipDashboard";
import { LoadingView } from "@/components/FeatureRelationshipDashboard/LoadingView";
import { AuthRequiredView } from "@/components/FeatureRelationshipDashboard/AuthRequiredView";
import { DashboardHeader } from "@/components/FeatureRelationshipDashboard/DashboardHeader";
import { TabNavigation } from "@/components/FeatureRelationshipDashboard/TabNavigation";
import { OverviewTab } from "@/components/FeatureRelationshipDashboard/OverviewTab";
import { HeatmapTab } from "@/components/FeatureRelationshipDashboard/HeatmapTab";
import { RadarTab } from "@/components/FeatureRelationshipDashboard/RadarTab";
import { TrendlineTab } from "@/components/FeatureRelationshipDashboard/TrendlineTab";
import { TradingTab } from "@/components/FeatureRelationshipDashboard/TradingTab";
import { TradingSignalsTab } from "@/components/FeatureRelationshipDashboard/TradingSignalsTab";
import { DraftLogicTab } from "@/components/FeatureRelationshipDashboard/DraftLogicTab";
import { CoachingTab } from "@/components/FeatureRelationshipDashboard/CoachingTab";
import { SponsorshipTab } from "@/components/FeatureRelationshipDashboard/SponsorshipTab";
import { RevenueOptimizationPanel } from "@/components/FeatureRelationshipDashboard/RevenueOptimizationPanel";
import { EmptyState } from "@/components/FeatureRelationshipDashboard/EmptyState";

export default function FeatureRelationshipDashboard() {
  const { data: user, loading } = useUser();
  const {
    athleteId,
    setAthleteId,
    activeTab,
    setActiveTab,
    dashboardData,
    loadingData,
    error,
    loadComprehensiveAnalytics,
  } = useFeatureRelationshipDashboard();

  if (loading) {
    return <LoadingView />;
  }

  if (!user) {
    return <AuthRequiredView />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-purple-950 p-6">
      <DashboardHeader
        athleteId={athleteId}
        setAthleteId={setAthleteId}
        loadingData={loadingData}
        onLoadAnalytics={loadComprehensiveAnalytics}
        error={error}
      />

      {dashboardData && (
        <div className="max-w-[1600px] mx-auto space-y-6">
          <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />

          {activeTab === "overview" && (
            <>
              <OverviewTab dashboardData={dashboardData} />
              {dashboardData.revenueOptimization && (
                <RevenueOptimizationPanel
                  revenueOptimization={dashboardData.revenueOptimization}
                />
              )}
            </>
          )}

          {activeTab === "heatmap" && (
            <HeatmapTab performanceEngine={dashboardData.performanceEngine} />
          )}

          {activeTab === "radar" && (
            <RadarTab performanceEngine={dashboardData.performanceEngine} />
          )}

          {activeTab === "trendline" && (
            <TrendlineTab performanceEngine={dashboardData.performanceEngine} />
          )}

          {activeTab === "trading" && (
            <TradingSignalsTab trading={dashboardData.trading} />
          )}

          {activeTab === "sponsorship" && (
            <SponsorshipTab sponsorships={dashboardData.sponsorships} />
          )}

          {activeTab === "draft" && (
            <DraftLogicTab relationships={dashboardData.relationships} />
          )}

          {activeTab === "coaching" && (
            <CoachingTab relationships={dashboardData.relationships} />
          )}
        </div>
      )}

      {!dashboardData && !loadingData && <EmptyState />}
    </div>
  );
}
