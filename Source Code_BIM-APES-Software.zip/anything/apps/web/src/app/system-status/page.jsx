"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function SystemStatus() {
  const { data: user, loading } = useUser();
  const [systemChecks, setSystemChecks] = useState([]);
  const [isChecking, setIsChecking] = useState(false);

  const runSystemCheck = async () => {
    setIsChecking(true);
    const checks = [];

    // Check 1: Authentication
    try {
      checks.push({
        system: "Authentication",
        status: user ? "operational" : "warning",
        message: user ? "User authenticated" : "No user authenticated",
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      checks.push({
        system: "Authentication",
        status: "error",
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }

    // Check 2: BIM Performance API
    try {
      const response = await fetch("/api/bim-performance/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          motion_scan_data: {
            biomechanics: {
              velocity_peak: 15.0,
              acceleration_max: 30.0,
              power_output: 1000,
              stability_score: 85,
              efficiency_rating: 80,
              range_of_motion: 140,
            },
            motion_type: "test",
            sport_type: "general",
            key_points: [{ x: 100, y: 200, confidence: 0.95 }],
            ai_score: 0.85,
            scan_id: "test_" + Date.now(),
          },
          session_context: { sport: "general" },
          athlete_data: { sport: "general", height: 1.75 },
        }),
      });

      checks.push({
        system: "BIM Performance API",
        status: response.ok ? "operational" : "error",
        message: response.ok
          ? "API responding correctly"
          : `HTTP ${response.status}`,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      checks.push({
        system: "BIM Performance API",
        status: "error",
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }

    // Check 3: AI Coaching Integration
    try {
      const response = await fetch(
        "/api/coach-portal/ai-coaching-integration?action=coaching_insights&athlete_id=1",
      );

      checks.push({
        system: "AI Coaching Integration",
        status: response.ok ? "operational" : "warning",
        message: response.ok
          ? "Coaching API responding"
          : `HTTP ${response.status}`,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      checks.push({
        system: "AI Coaching Integration",
        status: "error",
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }

    // Check 4: Database Connectivity
    try {
      const response = await fetch("/api/motion-scans/list");

      checks.push({
        system: "Database",
        status: response.ok ? "operational" : "error",
        message: response.ok
          ? "Database queries working"
          : `HTTP ${response.status}`,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      checks.push({
        system: "Database",
        status: "error",
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }

    setSystemChecks(checks);
    setIsChecking(false);
  };

  useEffect(() => {
    runSystemCheck();
  }, [user]);

  const getStatusColor = (status) => {
    switch (status) {
      case "operational":
        return "bg-green-500";
      case "warning":
        return "bg-yellow-500";
      case "error":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "operational":
        return "✅";
      case "warning":
        return "⚠️";
      case "error":
        return "❌";
      default:
        return "⚪";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-lg text-[#1D2B3D]">Loading system status...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-[#1D2B3D]/10">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-[#1D2B3D]">
                🔧 System Status Dashboard
              </h1>
              <p className="text-gray-600 mt-2">
                Real-time status of all sport-specific implementations
              </p>
            </div>
            <button
              onClick={runSystemCheck}
              disabled={isChecking}
              className={`px-6 py-3 rounded-lg font-medium ${
                isChecking
                  ? "bg-gray-400 cursor-not-allowed text-white"
                  : "bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] hover:from-[#B8860B] hover:to-[#1D2B3D] text-white shadow-lg hover:shadow-xl"
              } transition-all duration-300`}
            >
              {isChecking ? "Checking..." : "Refresh Status"}
            </button>
          </div>

          {isChecking && (
            <div className="mb-6 p-4 bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-[#B8860B]"></div>
                <span className="text-[#1D2B3D] font-medium">
                  Running system checks...
                </span>
              </div>
            </div>
          )}

          <div className="grid gap-4">
            {systemChecks.map((check, index) => (
              <div
                key={index}
                className="border border-[#1D2B3D]/20 rounded-lg p-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-3 h-3 rounded-full ${getStatusColor(check.status)}`}
                    ></div>
                    <div>
                      <h3 className="font-semibold text-lg text-[#1D2B3D]">
                        {check.system}
                      </h3>
                      <p className="text-gray-600">{check.message}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl">
                      {getStatusIcon(check.status)}
                    </div>
                    <div className="text-xs text-gray-500">
                      {new Date(check.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-6 bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-lg">
            <h2 className="text-xl font-bold mb-4 text-[#1D2B3D]">
              🏆 Sport-Specific Features Status
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="p-4 bg-white rounded border border-[#1D2B3D]/20">
                <h3 className="font-semibold text-[#1D2B3D]">
                  Wrestling/Goalwrestling
                </h3>
                <div className="text-sm text-green-600">
                  ✅ Performance tracking active
                </div>
                <div className="text-sm text-green-600">
                  ✅ Takedown efficiency metrics
                </div>
                <div className="text-sm text-green-600">
                  ✅ Positional awareness analysis
                </div>
              </div>

              <div className="p-4 bg-white rounded border border-[#1D2B3D]/20">
                <h3 className="font-semibold text-[#1D2B3D]">
                  Rugby/Soccer/Basketball
                </h3>
                <div className="text-sm text-green-600">
                  ✅ Tactical efficiency modules
                </div>
                <div className="text-sm text-green-600">
                  ✅ Team coordination tracking
                </div>
                <div className="text-sm text-green-600">
                  ✅ Field awareness analysis
                </div>
              </div>

              <div className="p-4 bg-white rounded border border-[#1D2B3D]/20">
                <h3 className="font-semibold text-[#1D2B3D]">
                  Tennis/Pickleball
                </h3>
                <div className="text-sm text-green-600">
                  ✅ Spike score analysis
                </div>
                <div className="text-sm text-green-600">
                  ✅ Power generation tracking
                </div>
                <div className="text-sm text-green-600">
                  ✅ Shot accuracy metrics
                </div>
              </div>

              <div className="p-4 bg-white rounded border border-[#1D2B3D]/20">
                <h3 className="font-semibold text-[#1D2B3D]">
                  American Football
                </h3>
                <div className="text-sm text-green-600">
                  ✅ Session consistency monitoring
                </div>
                <div className="text-sm text-green-600">
                  ✅ Position-specific analysis
                </div>
                <div className="text-sm text-green-600">
                  ✅ Game preparation tracking
                </div>
              </div>

              <div className="p-4 bg-white rounded border border-[#1D2B3D]/20">
                <h3 className="font-semibold text-[#1D2B3D]">AI Coaching</h3>
                <div className="text-sm text-green-600">
                  ✅ Sport-specific recommendations
                </div>
                <div className="text-sm text-green-600">
                  ✅ Training plan generation
                </div>
                <div className="text-sm text-green-600">
                  ✅ Real-time feedback
                </div>
              </div>

              <div className="p-4 bg-white rounded border border-[#1D2B3D]/20">
                <h3 className="font-semibold text-[#1D2B3D]">
                  Finance Management
                </h3>
                <div className="text-sm text-green-600">
                  ✅ Club finance dashboard
                </div>
                <div className="text-sm text-green-600">
                  ✅ Multi-sport coalition
                </div>
                <div className="text-sm text-green-600">
                  ✅ Digital wallet integration
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-[#1D2B3D]/5 border border-[#1D2B3D]/20 rounded-lg">
            <h3 className="font-semibold mb-2 text-[#1D2B3D]">
              Quick Navigation
            </h3>
            <div className="flex flex-wrap gap-2">
              <a
                href="/test-sports-system"
                className="px-3 py-1 bg-[#1D2B3D] text-white text-sm rounded hover:bg-[#B8860B] transition-colors duration-300"
              >
                🧪 Run Full Test Suite
              </a>
              <a
                href="/motion-scan"
                className="px-3 py-1 bg-[#B8860B] text-white text-sm rounded hover:bg-[#1D2B3D] transition-colors duration-300"
              >
                📊 Motion Scan
              </a>
              <a
                href="/coach-portal"
                className="px-3 py-1 bg-[#1D2B3D] text-white text-sm rounded hover:bg-[#B8860B] transition-colors duration-300"
              >
                🧑‍💼 Coach Portal
              </a>
              <a
                href="/analytics-dashboard"
                className="px-3 py-1 bg-[#B8860B] text-white text-sm rounded hover:bg-[#1D2B3D] transition-colors duration-300"
              >
                📈 Analytics Dashboard
              </a>
              <a
                href="/bim-dashboard"
                className="px-3 py-1 bg-[#1D2B3D] text-white text-sm rounded hover:bg-[#B8860B] transition-colors duration-300"
              >
                🎯 BIM Dashboard
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
