"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Users,
  BarChart3,
  Target,
  TrendingUp,
  AlertTriangle,
  Trophy,
  Activity,
  MessageSquare,
} from "lucide-react";

export default function CoachDashboard() {
  const { data: user, loading } = useUser();
  const [rosterData, setRosterData] = useState([]);
  const [teamAnalytics, setTeamAnalytics] = useState(null);
  const [tacticalInsights, setTacticalInsights] = useState([]);
  const [selectedSport, setSelectedSport] = useState("wrestling");
  const [selectedOrg, setSelectedOrg] = useState("ncaa_d1");
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      loadCoachData();
    }
  }, [user, selectedSport, selectedOrg]);

  const loadCoachData = async () => {
    try {
      setLoadingData(true);

      // Fetch roster
      const rosterRes = await fetch(
        `/api/coach-portal/roster?sport=${selectedSport}&org=${selectedOrg}`,
      );
      if (rosterRes.ok) {
        const data = await rosterRes.json();
        setRosterData(data.roster || []);
      }

      // Fetch team analytics
      const analyticsRes = await fetch(
        `/api/coach-portal/team-analytics?sport=${selectedSport}&org=${selectedOrg}`,
      );
      if (analyticsRes.ok) {
        const data = await analyticsRes.json();
        setTeamAnalytics(data);
      }

      // Fetch tactical insights
      const insightsRes = await fetch(
        `/api/coach-portal/tactical-insights?sport=${selectedSport}`,
      );
      if (insightsRes.ok) {
        const data = await insightsRes.json();
        setTacticalInsights(data.insights || []);
      }
    } catch (error) {
      console.error("Error loading coach data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#00D9FF] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading coach dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center bg-white p-8 rounded-lg shadow-lg max-w-md">
          <h2 className="text-2xl font-bold text-[#0A0E27] mb-4">
            Authentication Required
          </h2>
          <p className="text-gray-600 mb-6">
            Please sign in to access the coach portal.
          </p>
          <a
            href="/account/signin"
            className="inline-block bg-[#00D9FF] text-black px-6 py-3 rounded-lg font-semibold hover:bg-[#00C3E6] transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const tpi = teamAnalytics?.tpi?.tpi || 0;
  const teamTrend = teamAnalytics?.teamTrend || "stable";

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-[#0A0E27] border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-1">
                Coach Portal
              </h1>
              <p className="text-gray-400">
                Team Performance & Tactical Management
              </p>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedSport}
                onChange={(e) => setSelectedSport(e.target.value)}
                className="px-4 py-2 bg-[#1A1F3A] text-white rounded-lg border border-gray-700"
              >
                <option value="wrestling">Wrestling</option>
                <option value="basketball">Basketball</option>
                <option value="soccer">Soccer</option>
                <option value="rugby">Rugby</option>
                <option value="tennis">Tennis</option>
                <option value="american_football">American Football</option>
              </select>
              <select
                value={selectedOrg}
                onChange={(e) => setSelectedOrg(e.target.value)}
                className="px-4 py-2 bg-[#1A1F3A] text-white rounded-lg border border-gray-700"
              >
                <option value="high_school">High School</option>
                <option value="junior_college">Junior College</option>
                <option value="ncaa_d1">NCAA D1</option>
                <option value="ncaa_d2">NCAA D2</option>
                <option value="professional">Professional</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Team Performance Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-full bg-[#00D9FF]/10 flex items-center justify-center">
                <Trophy className="w-6 h-6 text-[#00D9FF]" />
              </div>
              <span className="text-3xl font-bold text-[#0A0E27]">
                {tpi.toFixed(1)}
              </span>
            </div>
            <div className="text-sm text-gray-600">Team Performance Index</div>
            <div className="text-xs text-gray-500 mt-1">
              Roster aggregate score
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <span className="text-3xl font-bold text-[#0A0E27]">
                {rosterData.length}
              </span>
            </div>
            <div className="text-sm text-gray-600">Active Athletes</div>
            <div className="text-xs text-gray-500 mt-1">
              Current roster size
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <span
                className={`text-2xl font-bold ${teamTrend === "improving" ? "text-green-600" : teamTrend === "declining" ? "text-red-600" : "text-gray-600"}`}
              >
                {teamTrend === "improving"
                  ? "↗"
                  : teamTrend === "declining"
                    ? "↘"
                    : "→"}
              </span>
            </div>
            <div className="text-sm text-gray-600">Team Trend</div>
            <div className="text-xs text-gray-500 mt-1 capitalize">
              {teamTrend}
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-yellow-600" />
              </div>
              <span className="text-3xl font-bold text-yellow-600">
                {rosterData.filter((a) => a.injury_risk === "high").length}
              </span>
            </div>
            <div className="text-sm text-gray-600">High Risk Athletes</div>
            <div className="text-xs text-gray-500 mt-1">Require attention</div>
          </div>
        </div>

        {/* Roster Table */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mb-8">
          <h2 className="text-xl font-bold text-[#0A0E27] mb-4 flex items-center gap-2">
            <Users className="w-5 h-5" />
            Roster Management
          </h2>
          {rosterData.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No athletes in roster yet.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                      Athlete
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                      Position
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      PPI
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Tier
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Trend
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Injury Risk
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rosterData.map((athlete) => (
                    <tr
                      key={athlete.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#0A0E27]">
                          {athlete.name}
                        </div>
                        <div className="text-xs text-gray-500">
                          ID: {athlete.id}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-700">
                        {athlete.position || "N/A"}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="text-lg font-bold text-[#00D9FF]">
                          {athlete.ppi?.toFixed(1) || "0.0"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-1 bg-gray-100 rounded text-xs font-medium uppercase">
                          {athlete.tier || "amateur"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-lg ${athlete.velocity > 0 ? "text-green-600" : athlete.velocity < 0 ? "text-red-600" : "text-gray-600"}`}
                        >
                          {athlete.velocity > 0
                            ? "↗"
                            : athlete.velocity < 0
                              ? "↘"
                              : "→"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            athlete.injury_risk === "high"
                              ? "bg-red-100 text-red-700"
                              : athlete.injury_risk === "medium"
                                ? "bg-yellow-100 text-yellow-700"
                                : "bg-green-100 text-green-700"
                          }`}
                        >
                          {athlete.injury_risk || "low"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button className="text-[#00D9FF] hover:text-[#00C3E6] text-sm font-medium">
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Tactical Insights */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h2 className="text-xl font-bold text-[#0A0E27] mb-4 flex items-center gap-2">
            <Target className="w-5 h-5" />
            Sport-Specific Tactical Insights
          </h2>
          {tacticalInsights.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No tactical insights available for this sport yet.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {tacticalInsights.map((insight, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-lg p-4"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-[#00D9FF]/10 flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="w-5 h-5 text-[#00D9FF]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0A0E27] mb-1">
                        {insight.title}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {insight.description}
                      </p>
                    </div>
                  </div>
                  {insight.metrics && (
                    <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-gray-100">
                      {Object.entries(insight.metrics)
                        .slice(0, 4)
                        .map(([key, value]) => (
                          <div key={key}>
                            <div className="text-xs text-gray-500 mb-1 capitalize">
                              {key.replace(/_/g, " ")}
                            </div>
                            <div className="text-lg font-bold text-[#0A0E27]">
                              {value}
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                  {insight.recommendations && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="text-xs font-semibold text-gray-700 mb-2">
                        Recommendations:
                      </div>
                      <ul className="space-y-1">
                        {insight.recommendations
                          .slice(0, 3)
                          .map((rec, recIndex) => (
                            <li
                              key={recIndex}
                              className="text-xs text-gray-600 flex items-start gap-2"
                            >
                              <span className="text-[#00D9FF] mt-1">•</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
