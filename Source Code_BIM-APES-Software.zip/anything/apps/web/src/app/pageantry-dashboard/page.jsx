"use client";

import { useState, useEffect } from "react";
import {
  Crown,
  TrendingUp,
  Users,
  Star,
  Mic,
  Sparkles,
  Award,
  Heart,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function PageantryDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [contestantData, setContestantData] = useState(null);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoadingData(true);

      const mockData = {
        summary: {
          totalContestants: 16,
          avgSPI: 0.9,
          avgQEI: 0.86,
          avgARI: 0.88,
        },
        contestants: [],
      };

      setContestantData(mockData);
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-900 via-black to-pink-900 flex items-center justify-center">
        <div className="text-center">
          <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
          <p className="text-white text-xl mt-4">
            Loading Pageantry NIL Advisory...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-900 via-black to-pink-900">
      {/* Header */}
      <header className="border-b border-yellow-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-yellow-500 to-pink-500 p-3 rounded-xl">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Pageantry NIL Advisory
                </h1>
                <p className="text-yellow-300 text-sm">
                  Stage Presence · Q&A Excellence · Audience Resonance
                  Intelligence
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-yellow-300">Logged in as</p>
                <p className="text-white font-semibold">
                  {user?.name || user?.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="border-b border-yellow-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "overview", label: "Overview", icon: Star },
              { id: "contestants", label: "Contestant Portfolio", icon: Users },
              { id: "performance", label: "Performance Units", icon: Sparkles },
              { id: "indices", label: "Pageant Indices", icon: TrendingUp },
              { id: "platform", label: "Platform Impact", icon: Heart },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-yellow-400 text-yellow-400"
                    : "border-transparent text-yellow-300 hover:text-yellow-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && (
          <OverviewTab contestantData={contestantData} />
        )}
        {activeTab === "contestants" && <ContestantPortfolioTab />}
        {activeTab === "performance" && <PerformanceUnitsTab />}
        {activeTab === "indices" && <PageantIndicesTab />}
        {activeTab === "platform" && <PlatformImpactTab />}
      </div>
    </div>
  );
}

function OverviewTab({ contestantData }) {
  const metrics = contestantData?.summary || {
    totalContestants: 16,
    avgSPI: 0.9,
    avgQEI: 0.86,
    avgARI: 0.88,
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Contestants"
          value={metrics.totalContestants}
          icon={Users}
          trend="+3 this quarter"
          color="yellow"
        />
        <MetricCard
          title="Avg SPI (Stage Presence)"
          value={(metrics.avgSPI * 100).toFixed(1)}
          icon={Star}
          trend="+5.8% vs last quarter"
          color="pink"
        />
        <MetricCard
          title="Avg QEI (Q&A Eloquence)"
          value={(metrics.avgQEI * 100).toFixed(1)}
          icon={Mic}
          trend="+4.3% vs last quarter"
          color="purple"
        />
        <MetricCard
          title="Avg ARI (Audience Resonance)"
          value={(metrics.avgARI * 100).toFixed(1)}
          icon={Heart}
          trend="+6.1% vs last quarter"
          color="red"
        />
      </div>

      {/* Performance Units Dashboard */}
      <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6">
          Performance Unit Breakdown
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <PerformanceUnitCard
            title="Stage Presence Units (SPU)"
            value="1,156"
            efficiency="92.8%"
            color="yellow"
          />
          <PerformanceUnitCard
            title="Q&A Delivery Units (QDU)"
            value="784"
            efficiency="88.5%"
            color="pink"
          />
          <PerformanceUnitCard
            title="Poise & Composure Units (PCU)"
            value="1,423"
            efficiency="94.1%"
            color="purple"
          />
          <PerformanceUnitCard
            title="Walk & Turn Units (WTU)"
            value="892"
            efficiency="91.3%"
            color="blue"
          />
          <PerformanceUnitCard
            title="Audience Resonance Units (ARU)"
            value="2,108"
            efficiency="89.7%"
            color="red"
          />
          <PerformanceUnitCard
            title="Interview Excellence Units"
            value="645"
            efficiency="87.9%"
            color="green"
          />
        </div>
      </div>

      {/* Recent Competitions */}
      <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Recent Competition Performances
        </h2>
        <div className="space-y-3">
          {[
            {
              contestant: "Contestant A",
              competition: "Miss USA",
              spi: 0.95,
              qei: 0.92,
              pageant: "National",
              date: "1 day ago",
            },
            {
              contestant: "Contestant B",
              competition: "Miss Teen USA",
              spi: 0.91,
              qei: 0.88,
              pageant: "National",
              date: "3 days ago",
            },
            {
              contestant: "Contestant C",
              competition: "State Pageant",
              spi: 0.89,
              qei: 0.84,
              pageant: "State",
              date: "5 days ago",
            },
          ].map((comp, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-4 bg-yellow-900/20 rounded-lg border border-yellow-500/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">{comp.contestant}</p>
                  <p className="text-sm text-yellow-300">
                    {comp.competition} · {comp.pageant}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold">
                  SPI {(comp.spi * 100).toFixed(0)}
                </p>
                <p className="text-sm text-yellow-300">
                  QEI {(comp.qei * 100).toFixed(0)} · {comp.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Biometric Intelligence */}
      <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Biometric Intelligence Summary
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <BiometricCard
            title="Composure Stability"
            value="93.4%"
            trend="+4.1%"
          />
          <BiometricCard title="Voice Clarity" value="89.7%" trend="+2.8%" />
          <BiometricCard title="Movement Grace" value="91.2%" trend="+3.5%" />
        </div>
      </div>

      {/* Pageant Organization Benchmarks */}
      <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Pageant Organization Benchmarks
        </h2>
        <div className="space-y-3">
          {[
            {
              org: "Miss Universe Organization",
              avgSPI: 0.93,
              contestants: 12,
              trend: "+5.8%",
            },
            {
              org: "Miss USA Organization",
              avgSPI: 0.9,
              contestants: 10,
              trend: "+4.2%",
            },
            {
              org: "Miss Teen USA",
              avgSPI: 0.87,
              contestants: 8,
              trend: "+3.9%",
            },
          ].map((org, i) => (
            <div
              key={i}
              className="p-4 bg-yellow-900/20 rounded-lg border border-yellow-500/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold">{org.org}</p>
                  <p className="text-sm text-yellow-300">
                    {org.contestants} contestants tracked
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-white">
                    {(org.avgSPI * 100).toFixed(1)}
                  </p>
                  <p className="text-sm text-green-400">{org.trend}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ContestantPortfolioTab() {
  const contestants = [
    {
      name: "Contestant A",
      title: "Miss USA Finalist",
      spi: 0.95,
      qei: 0.92,
      nilValue: 180000,
    },
    {
      name: "Contestant B",
      title: "Miss Teen USA",
      spi: 0.91,
      qei: 0.88,
      nilValue: 145000,
    },
    {
      name: "Contestant C",
      title: "State Champion",
      spi: 0.89,
      qei: 0.84,
      nilValue: 125000,
    },
    {
      name: "Contestant D",
      title: "Rising Pageant Star",
      spi: 0.87,
      qei: 0.82,
      nilValue: 105000,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Contestant Portfolio</h2>
        <button className="px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg transition-colors">
          Add Contestant
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {contestants.map((contestant, i) => (
          <ContestantCard key={i} contestant={contestant} />
        ))}
      </div>
    </div>
  );
}

function PerformanceUnitsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Performance Unit Analytics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Stage Presence Units (SPU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Total SPUs Captured</span>
              <span className="text-white font-bold">1,156</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Confidence Level</span>
              <span className="text-green-400 font-bold">92.8%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Avg Presence Score</span>
              <span className="text-white font-bold">9.2 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Q&A Delivery Units (QDU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Total QDUs Captured</span>
              <span className="text-white font-bold">784</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Eloquence Score</span>
              <span className="text-green-400 font-bold">88.5%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Clarity Rating</span>
              <span className="text-white font-bold">8.8 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Poise & Composure Units (PCU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Total PCUs Tracked</span>
              <span className="text-white font-bold">1,423</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Composure Rating</span>
              <span className="text-green-400 font-bold">94.1%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Under-Pressure Score</span>
              <span className="text-white font-bold">9.4 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Walk & Turn Units (WTU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Total WTUs Executed</span>
              <span className="text-white font-bold">892</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Grace & Balance</span>
              <span className="text-green-400 font-bold">91.3%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-yellow-300">Presentation Quality</span>
              <span className="text-white font-bold">9.1 / 10</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PageantIndicesTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Pageantry Performance Indices
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Core Indices</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Stage Presence Index (SPI)"
            value="90.2"
            trend="+5.8"
          />
          <IndexCard
            title="Composure Stability Index (CSI)"
            value="93.4"
            trend="+4.1"
          />
          <IndexCard
            title="Q&A Eloquence Index (QEI)"
            value="86.7"
            trend="+4.3"
          />
        </div>
      </div>

      <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Advanced Indices
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Audience Resonance Index (ARI)"
            value="88.3"
            trend="+6.1"
          />
          <IndexCard title="Grace & Movement Index" value="91.8" trend="+3.5" />
          <IndexCard title="Platform Impact Index" value="87.9" trend="+5.2" />
        </div>
      </div>
    </div>
  );
}

function PlatformImpactTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Platform & Advocacy Impact
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Social Impact Metrics
          </h3>
          <div className="space-y-3">
            {[
              { platform: "Education Advocacy", impact: 0.92, reach: 125000 },
              { platform: "Environmental Causes", impact: 0.88, reach: 98000 },
              { platform: "Youth Empowerment", impact: 0.9, reach: 110000 },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-yellow-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.platform}</p>
                  <p className="text-sm text-yellow-300">
                    {item.reach.toLocaleString()} reach
                  </p>
                </div>
                <p className="text-white font-bold">
                  {(item.impact * 100).toFixed(0)}%
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Community Engagement
          </h3>
          <div className="space-y-3">
            {[
              { activity: "Speaking Engagements", count: 24, impact: 0.91 },
              { activity: "Charity Events", count: 18, impact: 0.88 },
              { activity: "School Visits", count: 32, impact: 0.93 },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-yellow-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.activity}</p>
                  <p className="text-sm text-yellow-300">{item.count} events</p>
                </div>
                <p className="text-white font-bold">
                  {(item.impact * 100).toFixed(0)}%
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color }) {
  const colorClasses = {
    yellow: "from-yellow-500 to-yellow-600",
    pink: "from-pink-500 to-pink-600",
    purple: "from-purple-500 to-purple-600",
    red: "from-red-500 to-red-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-yellow-300 uppercase">
          {title}
        </p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function PerformanceUnitCard({ title, value, efficiency, color }) {
  return (
    <div className="p-4 bg-yellow-900/20 rounded-lg border border-yellow-500/20">
      <p className="text-sm text-yellow-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{efficiency} efficiency</p>
    </div>
  );
}

function BiometricCard({ title, value, trend }) {
  return (
    <div className="p-4 bg-yellow-900/20 rounded-lg border border-yellow-500/20">
      <p className="text-sm text-yellow-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function ContestantCard({ contestant }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-yellow-500/30 rounded-xl p-6 hover:border-yellow-400 transition-all cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-pink-500 rounded-full flex items-center justify-center">
          <Crown className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-lg">{contestant.name}</p>
          <p className="text-sm text-yellow-300">{contestant.title}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-yellow-300">Stage Presence (SPI)</span>
          <span className="text-white font-bold">
            {(contestant.spi * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-yellow-300">Q&A Eloquence (QEI)</span>
          <span className="text-white font-bold">
            {(contestant.qei * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-yellow-300">NIL Value</span>
          <span className="text-white font-bold">
            ${(contestant.nilValue / 1000).toFixed(0)}K
          </span>
        </div>
      </div>
    </div>
  );
}

function IndexCard({ title, value, trend }) {
  return (
    <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4">
      <p className="text-sm text-yellow-300 mb-2">{title}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm text-green-400">+{trend}</p>
      </div>
    </div>
  );
}
