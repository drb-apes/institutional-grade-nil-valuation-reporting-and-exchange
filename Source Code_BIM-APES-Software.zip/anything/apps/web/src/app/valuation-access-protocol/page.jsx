"use client";
import { Header } from "@/components/ValuationAccessProtocol/Header";
import { KeyFeatures } from "@/components/ValuationAccessProtocol/KeyFeatures";
import { PricingInsertsSection } from "@/components/ValuationAccessProtocol/PricingInsertsSection";
import { SaleSplitSection } from "@/components/ValuationAccessProtocol/SaleSplitSection";
import { PrivacyLogicSection } from "@/components/ValuationAccessProtocol/PrivacyLogicSection";
import { ProtocolDetailsSection } from "@/components/ValuationAccessProtocol/ProtocolDetailsSection";
import { PurchaseLogicSection } from "@/components/ValuationAccessProtocol/PurchaseLogicSection";
import { FullProtocolDownload } from "@/components/ValuationAccessProtocol/FullProtocolDownload";
import { ContactSection } from "@/components/ValuationAccessProtocol/ContactSection";

export default function ValuationAccessProtocol() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="px-6 py-12">
        <div className="max-w-6xl mx-auto">
          <Header />
          <KeyFeatures />
          <PricingInsertsSection />
          <SaleSplitSection />
          <PrivacyLogicSection />
          <ProtocolDetailsSection />
          <PurchaseLogicSection />
          <FullProtocolDownload />
          <ContactSection />
        </div>
      </div>
    </div>
  );
}
