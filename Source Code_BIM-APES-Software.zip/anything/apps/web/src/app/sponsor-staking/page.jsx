"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function SponsorStakingDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("create");
  const [athletes, setAthletes] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Form states
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [contractType, setContractType] = useState("biometric_index");
  const [indexType, setIndexType] = useState("sprint");
  const [exposureAmount, setExposureAmount] = useState("");
  const [predictableSpend, setPredictableSpend] = useState("");
  const [durationDays, setDurationDays] = useState(90);

  useEffect(() => {
    if (user) {
      loadAthletes();
      loadContracts();
    }
  }, [user]);

  const loadAthletes = async () => {
    try {
      const res = await fetch("/api/athletes/list");
      const data = await res.json();
      setAthletes(data.athletes || []);
    } catch (error) {
      console.error("Error loading athletes:", error);
    }
  };

  const loadContracts = async () => {
    try {
      const res = await fetch("/api/sponsor-staking/list");
      const data = await res.json();
      setContracts(data.contracts || []);
    } catch (error) {
      console.error("Error loading contracts:", error);
    }
  };

  const handleCreateContract = async () => {
    if (!selectedAthlete || !exposureAmount || !predictableSpend) return;
    setLoading(true);
    try {
      const res = await fetch("/api/sponsor-staking/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete.id,
          contract_type: contractType,
          index_type: contractType === "biometric_index" ? indexType : null,
          exposure_amount: parseFloat(exposureAmount),
          predictable_spend: parseFloat(predictableSpend),
          yield_target: {
            brand_lift: 0.15,
            engagement_lift: 0.25,
          },
          duration_days: durationDays,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage("Sponsor contract created successfully!");
        setExposureAmount("");
        setPredictableSpend("");
        loadContracts();
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
    setLoading(false);
  };

  if (userLoading || !user)
    return (
      <div className="min-h-screen bg-[#0A0F1E] flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );

  return (
    <div className="min-h-screen bg-[#0A0F1E] text-white">
      {/* Header */}
      <div className="border-b border-[#1E293B] bg-gradient-to-r from-[#0F172A] to-[#1E293B]">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold mb-2">Sponsor Staking</h1>
          <p className="text-gray-400">
            Predictable Spend, Performance Exposure, Brand Yield
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab("create")}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === "create"
                ? "bg-[#C4A661] text-black"
                : "bg-[#1E293B] text-gray-400 hover:bg-[#2D3B52]"
            }`}
          >
            Create Contract
          </button>
          <button
            onClick={() => setActiveTab("active")}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === "active"
                ? "bg-[#C4A661] text-black"
                : "bg-[#1E293B] text-gray-400 hover:bg-[#2D3B52]"
            }`}
          >
            Active Contracts
          </button>
        </div>

        {activeTab === "create" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Create Form */}
            <div className="bg-[#1E293B] rounded-xl p-6">
              <h2 className="text-2xl font-bold mb-6">New Sponsor Contract</h2>

              <div className="space-y-4">
                {/* Athlete Selector */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Select Athlete
                  </label>
                  <select
                    value={selectedAthlete?.id || ""}
                    onChange={(e) =>
                      setSelectedAthlete(
                        athletes.find((a) => a.id === parseInt(e.target.value)),
                      )
                    }
                    className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                  >
                    <option value="">Choose an athlete...</option>
                    {athletes.map((athlete) => (
                      <option key={athlete.id} value={athlete.id}>
                        {athlete.name || `Athlete ${athlete.id}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Contract Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Contract Type
                  </label>
                  <select
                    value={contractType}
                    onChange={(e) => setContractType(e.target.value)}
                    className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                  >
                    <option value="biometric_index">Biometric Index</option>
                    <option value="metadata_credits">Metadata Credits</option>
                    <option value="coalition_syndication">
                      Coalition Syndication
                    </option>
                  </select>
                </div>

                {/* Index Type (if biometric) */}
                {contractType === "biometric_index" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">
                      Biometric Index
                    </label>
                    <select
                      value={indexType}
                      onChange={(e) => setIndexType(e.target.value)}
                      className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                    >
                      <option value="sprint">Sprint Performance</option>
                      <option value="hydration">Hydration Index</option>
                      <option value="recovery">Recovery Index</option>
                      <option value="highlight">Highlight Moments</option>
                      <option value="tactical">Tactical Efficiency</option>
                    </select>
                  </div>
                )}

                {/* Exposure Amount */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Exposure Amount ($)
                  </label>
                  <input
                    type="number"
                    value={exposureAmount}
                    onChange={(e) => setExposureAmount(e.target.value)}
                    placeholder="e.g. 50000"
                    className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                  />
                </div>

                {/* Predictable Spend */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Predictable Monthly Spend ($)
                  </label>
                  <input
                    type="number"
                    value={predictableSpend}
                    onChange={(e) => setPredictableSpend(e.target.value)}
                    placeholder="e.g. 5000"
                    className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                  />
                </div>

                {/* Duration */}
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Duration: {durationDays} days
                  </label>
                  <input
                    type="range"
                    min="30"
                    max="365"
                    step="30"
                    value={durationDays}
                    onChange={(e) => setDurationDays(parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>

                <button
                  onClick={handleCreateContract}
                  disabled={loading}
                  className="w-full bg-[#C4A661] text-black font-bold py-3 rounded-lg hover:bg-[#D4B671] transition-all disabled:opacity-50"
                >
                  {loading ? "Creating..." : "Create Contract"}
                </button>
              </div>

              {message && (
                <div className="mt-4 bg-[#0F172A] border border-[#C4A661] rounded-lg p-4 text-center text-sm">
                  {message}
                </div>
              )}
            </div>

            {/* Info Panel */}
            <div className="space-y-6">
              <div className="bg-[#1E293B] rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4">Yield Model</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Brand Lift Target</span>
                    <span className="text-[#C4A661]">+15%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">
                      Engagement Lift Target
                    </span>
                    <span className="text-[#8B5CF6]">+25%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Metadata Distribution</span>
                    <span className="text-[#3B82F6]">Coalition</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#1E293B] rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4">Contract Types</h3>
                <div className="space-y-4 text-sm">
                  <div>
                    <div className="font-medium text-[#C4A661]">
                      Biometric Index
                    </div>
                    <div className="text-gray-400">
                      Stake on specific performance metrics (Sprint, Recovery,
                      Hydration, etc.)
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-[#8B5CF6]">
                      Metadata Credits
                    </div>
                    <div className="text-gray-400">
                      Purchase credits for metadata visibility and unlocks
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-[#3B82F6]">
                      Coalition Syndication
                    </div>
                    <div className="text-gray-400">
                      Cross-sport visibility via coalition distribution
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "active" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {contracts.length === 0 ? (
              <div className="col-span-full bg-[#1E293B] rounded-xl p-12 text-center">
                <p className="text-gray-400">No active sponsor contracts</p>
              </div>
            ) : (
              contracts.map((contract) => (
                <div key={contract.id} className="bg-[#1E293B] rounded-xl p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold">
                        {contract.athlete_name || "Athlete"}
                      </h3>
                      <div className="text-sm text-gray-400">
                        {contract.contract_type.replace("_", " ")}
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        contract.contract_status === "active"
                          ? "bg-green-500/20 text-green-400"
                          : contract.contract_status === "completed"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-gray-500/20 text-gray-400"
                      }`}
                    >
                      {contract.contract_status}
                    </span>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Exposure</span>
                      <span className="font-medium">
                        ${parseFloat(contract.exposure_amount).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Monthly Spend</span>
                      <span className="font-medium">
                        $
                        {parseFloat(
                          contract.predictable_spend,
                        ).toLocaleString()}
                      </span>
                    </div>
                    {contract.index_type && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Index</span>
                        <span className="font-medium text-[#C4A661]">
                          {contract.index_type}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-400">Expires</span>
                      <span>
                        {new Date(contract.expires_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-[#334155]">
                    <div className="text-xs text-gray-400 mb-1">
                      Performance
                    </div>
                    <div className="flex gap-4">
                      <div>
                        <div className="text-sm font-medium text-green-400">
                          +
                          {parseFloat(contract.brand_lift_score || 0).toFixed(
                            1,
                          )}
                          %
                        </div>
                        <div className="text-xs text-gray-500">Brand Lift</div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-purple-400">
                          +
                          {parseFloat(
                            contract.engagement_lift_score || 0,
                          ).toFixed(1)}
                          %
                        </div>
                        <div className="text-xs text-gray-500">Engagement</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
