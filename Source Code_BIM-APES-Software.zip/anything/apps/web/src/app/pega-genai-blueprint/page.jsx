"use client";

import { BlueprintHeader } from "@/components/PegaGenAIBlueprint/BlueprintHeader";
import { ModuleNavigation } from "@/components/PegaGenAIBlueprint/ModuleNavigation";
import { GeneratorModule } from "@/components/PegaGenAIBlueprint/GeneratorModule/GeneratorModule";
import { ValuationModule } from "@/components/PegaGenAIBlueprint/ValuationModule/ValuationModule";
import { CandlestickModule } from "@/components/PegaGenAIBlueprint/CandlestickModule/CandlestickModule";
import { LiquidityModule } from "@/components/PegaGenAIBlueprint/LiquidityModule/LiquidityModule";
import { CoalitionModule } from "@/components/PegaGenAIBlueprint/CoalitionModule/CoalitionModule";
import { SimulationModule } from "@/components/PegaGenAIBlueprint/SimulationModule/SimulationModule";
import { usePegaGenAIBlueprint } from "@/hooks/usePegaGenAIBlueprint";
import {
  blueprintModules,
  scaffoldingTemplates,
  generationSteps,
} from "@/components/PegaGenAIBlueprint/constants";

export default function PegaGenAIBlueprintPage() {
  const {
    activeModule,
    setActiveModule,
    generationStep,
    isGenerating,
    startGeneration,
  } = usePegaGenAIBlueprint();

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <BlueprintHeader />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <ModuleNavigation
          modules={blueprintModules}
          activeModule={activeModule}
          onModuleChange={setActiveModule}
        />

        {activeModule === "generator" && (
          <GeneratorModule
            scaffoldingTemplates={scaffoldingTemplates}
            generationSteps={generationSteps}
            isGenerating={isGenerating}
            generationStep={generationStep}
            onStartGeneration={startGeneration}
          />
        )}

        {activeModule === "valuation" && <ValuationModule />}

        {activeModule === "candlestick" && <CandlestickModule />}

        {activeModule === "liquidity" && <LiquidityModule />}

        {activeModule === "coalition" && <CoalitionModule />}

        {activeModule === "simulation" && <SimulationModule />}
      </div>
    </div>
  );
}
