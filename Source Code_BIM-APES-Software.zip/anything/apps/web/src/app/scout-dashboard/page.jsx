"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Search,
  Users,
  TrendingUp,
  Star,
  Filter,
  BarChart3,
  Target,
  Eye,
  Award,
} from "lucide-react";

export default function ScoutDashboard() {
  const { data: user, loading } = useUser();
  const [prospects, setProspects] = useState([]);
  const [selectedSport, setSelectedSport] = useState("wrestling");
  const [selectedOrg, setSelectedOrg] = useState("ncaa_d1");
  const [filterTier, setFilterTier] = useState("all");
  const [sortBy, setSortBy] = useState("ppi_desc");
  const [searchQuery, setSearchQuery] = useState("");
  const [comparisonMode, setComparisonMode] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      loadProspects();
    }
  }, [user, selectedSport, selectedOrg, filterTier, sortBy]);

  const loadProspects = async () => {
    try {
      setLoadingData(true);
      const params = new URLSearchParams({
        sport: selectedSport,
        org: selectedOrg,
        tier: filterTier,
        sort: sortBy,
        search: searchQuery,
      });

      const response = await fetch(`/api/scout-dashboard/prospects?${params}`);
      if (response.ok) {
        const data = await response.json();
        setProspects(data.prospects || []);
      }
    } catch (error) {
      console.error("Error loading prospects:", error);
    } finally {
      setLoadingData(false);
    }
  };

  const toggleComparison = (prospectId) => {
    if (selectedForComparison.includes(prospectId)) {
      setSelectedForComparison(
        selectedForComparison.filter((id) => id !== prospectId),
      );
    } else {
      if (selectedForComparison.length < 4) {
        setSelectedForComparison([...selectedForComparison, prospectId]);
      }
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#00D9FF] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading scout dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center bg-white p-8 rounded-lg shadow-lg max-w-md">
          <h2 className="text-2xl font-bold text-[#0A0E27] mb-4">
            Authentication Required
          </h2>
          <p className="text-gray-600 mb-6">
            Please sign in to access the scout dashboard.
          </p>
          <a
            href="/account/signin"
            className="inline-block bg-[#00D9FF] text-black px-6 py-3 rounded-lg font-semibold hover:bg-[#00C3E6] transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const filteredProspects = searchQuery
    ? prospects.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.position?.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : prospects;

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-[#0A0E27] border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-1">
                Scout Dashboard
              </h1>
              <p className="text-gray-400">
                Prospect Evaluation & Cross-Athlete Analysis
              </p>
            </div>
            <div className="flex gap-4">
              <button
                onClick={() => setComparisonMode(!comparisonMode)}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  comparisonMode
                    ? "bg-[#00D9FF] text-black"
                    : "bg-[#1A1F3A] text-white border border-gray-700"
                }`}
              >
                <Users className="w-5 h-5 inline mr-2" />
                Compare ({selectedForComparison.length}/4)
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Filters & Search */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sport
              </label>
              <select
                value={selectedSport}
                onChange={(e) => setSelectedSport(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="wrestling">Wrestling</option>
                <option value="basketball">Basketball</option>
                <option value="soccer">Soccer</option>
                <option value="rugby">Rugby</option>
                <option value="tennis">Tennis</option>
                <option value="pickleball">Pickleball</option>
                <option value="american_football">American Football</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Organization
              </label>
              <select
                value={selectedOrg}
                onChange={(e) => setSelectedOrg(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="high_school">High School</option>
                <option value="junior_college">Junior College</option>
                <option value="ncaa_d1">NCAA D1</option>
                <option value="ncaa_d2">NCAA D2</option>
                <option value="semi_pro">Semi-Pro</option>
                <option value="professional">Professional</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tier Filter
              </label>
              <select
                value={filterTier}
                onChange={(e) => setFilterTier(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="all">All Tiers</option>
                <option value="elite">Elite Only</option>
                <option value="pro">Pro Only</option>
                <option value="development">Development</option>
                <option value="amateur">Amateur</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sort By
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="ppi_desc">PPI (High to Low)</option>
                <option value="ppi_asc">PPI (Low to High)</option>
                <option value="velocity_desc">Velocity (High to Low)</option>
                <option value="breakout_desc">Breakout Probability</option>
                <option value="recent">Most Recent</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Search
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search prospects..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 rounded-full bg-[#00D9FF]/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-[#00D9FF]" />
              </div>
              <span className="text-3xl font-bold text-[#0A0E27]">
                {filteredProspects.length}
              </span>
            </div>
            <div className="text-sm text-gray-600">Total Prospects</div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
              <span className="text-3xl font-bold text-[#0A0E27]">
                {filteredProspects.filter((p) => p.tier === "elite").length}
              </span>
            </div>
            <div className="text-sm text-gray-600">Elite Tier</div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <span className="text-3xl font-bold text-[#0A0E27]">
                {
                  filteredProspects.filter((p) => p.breakout_probability > 70)
                    .length
                }
              </span>
            </div>
            <div className="text-sm text-gray-600">High Breakout Potential</div>
          </div>

          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
              <span className="text-3xl font-bold text-[#0A0E27]">
                {filteredProspects.filter((p) => p.velocity > 5).length}
              </span>
            </div>
            <div className="text-sm text-gray-600">Rapid Improvers</div>
          </div>
        </div>

        {/* Prospects Table */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h2 className="text-xl font-bold text-[#0A0E27] mb-4 flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Prospect Database
          </h2>

          {filteredProspects.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              No prospects found matching your criteria.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    {comparisonMode && (
                      <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                        Compare
                      </th>
                    )}
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                      Athlete
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                      Position
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      PPI
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Tier
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Velocity
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Breakout %
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Consistency
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProspects.map((prospect) => (
                    <tr
                      key={prospect.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      {comparisonMode && (
                        <td className="py-3 px-4">
                          <input
                            type="checkbox"
                            checked={selectedForComparison.includes(
                              prospect.id,
                            )}
                            onChange={() => toggleComparison(prospect.id)}
                            className="w-4 h-4 text-[#00D9FF] rounded focus:ring-[#00D9FF]"
                            disabled={
                              !selectedForComparison.includes(prospect.id) &&
                              selectedForComparison.length >= 4
                            }
                          />
                        </td>
                      )}
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#0A0E27]">
                          {prospect.name}
                        </div>
                        <div className="text-xs text-gray-500">
                          {prospect.age} yrs • {prospect.org_name}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-700">
                        {prospect.position || "N/A"}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="text-lg font-bold text-[#00D9FF]">
                          {prospect.ppi?.toFixed(1) || "0.0"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium uppercase ${
                            prospect.tier === "elite"
                              ? "bg-yellow-100 text-yellow-700"
                              : prospect.tier === "pro"
                                ? "bg-blue-100 text-blue-700"
                                : prospect.tier === "development"
                                  ? "bg-green-100 text-green-700"
                                  : "bg-gray-100 text-gray-700"
                          }`}
                        >
                          {prospect.tier}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`font-bold ${prospect.velocity > 0 ? "text-green-600" : "text-red-600"}`}
                        >
                          {prospect.velocity > 0 ? "+" : ""}
                          {prospect.velocity?.toFixed(1) || "0.0"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-bold text-purple-600">
                          {prospect.breakout_probability || 0}%
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="text-sm text-gray-700">
                          {prospect.consistency?.toFixed(1) || "0.0"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button className="text-[#00D9FF] hover:text-[#00C3E6] text-sm font-medium">
                          Full Report
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Comparison Panel */}
        {comparisonMode && selectedForComparison.length > 0 && (
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mt-8">
            <h2 className="text-xl font-bold text-[#0A0E27] mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Prospect Comparison ({selectedForComparison.length} selected)
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {selectedForComparison.map((id) => {
                const prospect = prospects.find((p) => p.id === id);
                if (!prospect) return null;

                return (
                  <div
                    key={id}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="font-semibold text-[#0A0E27] mb-3">
                      {prospect.name}
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">PPI:</span>
                        <span className="font-bold text-[#00D9FF]">
                          {prospect.ppi?.toFixed(1)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Velocity:</span>
                        <span
                          className={`font-bold ${prospect.velocity > 0 ? "text-green-600" : "text-red-600"}`}
                        >
                          {prospect.velocity > 0 ? "+" : ""}
                          {prospect.velocity?.toFixed(1)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Breakout:</span>
                        <span className="font-bold text-purple-600">
                          {prospect.breakout_probability}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Consistency:</span>
                        <span className="font-bold text-gray-700">
                          {prospect.consistency?.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
