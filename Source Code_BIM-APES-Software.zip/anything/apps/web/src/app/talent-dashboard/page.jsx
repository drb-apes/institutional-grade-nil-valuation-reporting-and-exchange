"use client";

import { useState, useEffect } from "react";
import {
  Activity,
  TrendingUp,
  FileText,
  Users,
  AlertTriangle,
  DollarSign,
  Target,
  Award,
} from "lucide-react";
import useUser from "@/utils/useUser";

/**
 * TALENT EXPERIENCE DASHBOARD
 *
 * For: Athletes, Performers, Musicians, Actors
 *
 * Features:
 * - Real-time biometric performance dashboard
 * - NIL value tracking
 * - Contract management
 * - Milestone progress
 * - Brand collaboration opportunities
 * - Health & recovery metrics
 */

export default function TalentDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [biometricData, setBiometricData] = useState(null);
  const [nilValue, setNilValue] = useState(null);
  const [contracts, setContracts] = useState([]);
  const [milestones, setMilestones] = useState([]);
  const [brandOpportunities, setBrandOpportunities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchTalentData();
    }
  }, [user]);

  const fetchTalentData = async () => {
    try {
      setLoading(true);

      // Fetch all talent-related data
      const [bioRes, nilRes, contractRes, milestoneRes, brandRes] =
        await Promise.all([
          fetch("/api/talent/biometric-dashboard"),
          fetch("/api/talent/nil-value"),
          fetch("/api/talent/contracts"),
          fetch("/api/talent/milestones"),
          fetch("/api/talent/brand-opportunities"),
        ]);

      if (bioRes.ok) setBiometricData(await bioRes.json());
      if (nilRes.ok) setNilValue(await nilRes.json());
      if (contractRes.ok) setContracts(await contractRes.json());
      if (milestoneRes.ok) setMilestones(await milestoneRes.json());
      if (brandRes.ok) setBrandOpportunities(await brandRes.json());
    } catch (error) {
      console.error("Error fetching talent data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#C8A882] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center bg-white/10 backdrop-blur-lg p-8 rounded-2xl border border-[#C8A882]/20">
          <p className="text-white text-xl mb-4">
            Please sign in to access your talent dashboard
          </p>
          <a
            href="/account/signin"
            className="px-6 py-3 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-bold rounded-lg transition-colors shadow-lg inline-block"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68]">
      {/* Header */}
      <div className="bg-[#1B3A57]/90 backdrop-blur-lg border-b-2 border-[#C8A882]">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Talent Dashboard
              </h1>
              <p className="text-[#E8DCC8]">
                Real-time performance, NIL value, and opportunities
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-[#9CA3AF]">Current NIL Value</p>
                <p className="text-2xl font-bold text-[#C8A882]">
                  ${nilValue?.currentValue?.toLocaleString() || "0"}
                </p>
              </div>
              <div className="w-16 h-16 bg-gradient-to-br from-[#C8A882] to-[#D4B896] rounded-full flex items-center justify-center">
                <Activity className="w-8 h-8 text-[#1B3A57]" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-6 mt-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            { id: "overview", label: "Overview", icon: Activity },
            { id: "biometrics", label: "Performance", icon: TrendingUp },
            { id: "contracts", label: "Contracts", icon: FileText },
            { id: "milestones", label: "Milestones", icon: Target },
            { id: "brands", label: "Brand Deals", icon: Users },
            { id: "health", label: "Health", icon: AlertTriangle },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-[#C8A882] text-[#1B3A57] shadow-lg font-bold"
                  : "bg-white/5 text-[#E8DCC8] hover:bg-white/10"
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && (
          <OverviewTab
            biometricData={biometricData}
            nilValue={nilValue}
            contracts={contracts}
            milestones={milestones}
          />
        )}
        {activeTab === "biometrics" && <BiometricsTab data={biometricData} />}
        {activeTab === "contracts" && <ContractsTab contracts={contracts} />}
        {activeTab === "milestones" && (
          <MilestonesTab milestones={milestones} />
        )}
        {activeTab === "brands" && (
          <BrandsTab opportunities={brandOpportunities} />
        )}
        {activeTab === "health" && <HealthTab data={biometricData} />}
      </div>
    </div>
  );
}

// --- OVERVIEW TAB ---
function OverviewTab({ biometricData, nilValue, contracts, milestones }) {
  const activeMilestones =
    milestones?.filter((m) => m.status === "active") || [];
  const activeContracts = contracts?.filter((c) => c.status === "active") || [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Performance Summary */}
      <div className="lg:col-span-2 bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <Activity className="w-6 h-6 text-purple-400" />
          Performance Summary
        </h2>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl p-4">
            <p className="text-sm text-gray-400 mb-1">BIM Score</p>
            <p className="text-3xl font-bold text-white">
              {biometricData?.bimScore || 0}
            </p>
            <p className="text-xs text-green-400 mt-1">↑ +5.2 this week</p>
          </div>

          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl p-4">
            <p className="text-sm text-gray-400 mb-1">Tier</p>
            <p className="text-3xl font-bold text-white">
              {biometricData?.tier || "Rising"}
            </p>
            <p className="text-xs text-blue-400 mt-1">Top 15% in cohort</p>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Performance Consistency</span>
              <span className="text-white font-medium">87%</span>
            </div>
            <div className="h-2 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                style={{ width: "87%" }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Recovery Rate</span>
              <span className="text-white font-medium">92%</span>
            </div>
            <div className="h-2 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
                style={{ width: "92%" }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Market Momentum</span>
              <span className="text-white font-medium">78%</span>
            </div>
            <div className="h-2 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
                style={{ width: "78%" }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* NIL Value Card */}
      <div className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 backdrop-blur-lg rounded-2xl p-6 border border-green-500/30">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-green-400" />
          NIL Valuation
        </h3>

        <div className="mb-4">
          <p className="text-sm text-gray-400 mb-1">Current Value</p>
          <p className="text-4xl font-bold text-white mb-1">
            ${nilValue?.currentValue?.toLocaleString() || "0"}
          </p>
          <p className="text-sm text-green-400">↑ 12.3% from last month</p>
        </div>

        <div className="space-y-2 pt-4 border-t border-white/10">
          <div className="flex justify-between">
            <span className="text-sm text-gray-400">30-day Average</span>
            <span className="text-sm text-white font-medium">
              ${nilValue?.thirtyDayAvg?.toLocaleString() || "0"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-400">Peak Value</span>
            <span className="text-sm text-white font-medium">
              ${nilValue?.peakValue?.toLocaleString() || "0"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-400">Market Rank</span>
            <span className="text-sm text-purple-400 font-medium">#247</span>
          </div>
        </div>
      </div>

      {/* Active Contracts */}
      <div className="lg:col-span-2 bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-400" />
          Active Contracts ({activeContracts.length})
        </h3>

        {activeContracts.length > 0 ? (
          <div className="space-y-3">
            {activeContracts.slice(0, 3).map((contract, idx) => (
              <div key={idx} className="bg-black/30 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white">
                    {contract.brandName}
                  </h4>
                  <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                    Active
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Value</p>
                    <p className="text-white font-medium">
                      ${contract.value?.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Duration</p>
                    <p className="text-white font-medium">
                      {contract.duration}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Completion</p>
                    <p className="text-white font-medium">
                      {contract.completion}%
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-400 text-center py-8">No active contracts</p>
        )}
      </div>

      {/* Active Milestones */}
      <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-purple-400" />
          Active Milestones
        </h3>

        {activeMilestones.length > 0 ? (
          <div className="space-y-3">
            {activeMilestones.slice(0, 3).map((milestone, idx) => (
              <div key={idx} className="bg-black/30 rounded-lg p-3">
                <p className="text-sm font-medium text-white mb-2">
                  {milestone.title}
                </p>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-400">Progress</span>
                  <span className="text-white">{milestone.progress}%</span>
                </div>
                <div className="h-1.5 bg-black/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                    style={{ width: `${milestone.progress}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-400 text-center py-8 text-sm">
            No active milestones
          </p>
        )}
      </div>
    </div>
  );
}

// --- BIOMETRICS TAB ---
function BiometricsTab({ data }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-bold text-white mb-4">
          Real-Time Performance Metrics
        </h3>
        <div className="space-y-4">
          {data?.metrics?.map((metric, idx) => (
            <div key={idx} className="bg-black/30 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">{metric.name}</span>
                <span className="text-white font-bold">{metric.value}</span>
              </div>
              <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                  style={{ width: `${metric.percentage}%` }}
                ></div>
              </div>
            </div>
          )) || (
            <p className="text-gray-400 text-center py-8">
              No biometric data available
            </p>
          )}
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-bold text-white mb-4">
          Performance Trends
        </h3>
        <p className="text-gray-400 text-center py-8">
          Chart visualization coming soon
        </p>
      </div>
    </div>
  );
}

// --- CONTRACTS TAB ---
function ContractsTab({ contracts }) {
  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
      <h3 className="text-lg font-bold text-white mb-6">Contract Management</h3>

      {contracts && contracts.length > 0 ? (
        <div className="space-y-4">
          {contracts.map((contract, idx) => (
            <div
              key={idx}
              className="bg-black/30 rounded-lg p-6 border border-white/5"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-lg font-bold text-white">
                    {contract.brandName}
                  </h4>
                  <p className="text-sm text-gray-400">{contract.type}</p>
                </div>
                <span
                  className={`px-4 py-2 rounded-full text-sm font-medium ${
                    contract.status === "active"
                      ? "bg-green-500/20 text-green-400"
                      : contract.status === "pending"
                        ? "bg-yellow-500/20 text-yellow-400"
                        : "bg-gray-500/20 text-gray-400"
                  }`}
                >
                  {contract.status}
                </span>
              </div>

              <div className="grid grid-cols-4 gap-4 mb-4">
                <div>
                  <p className="text-xs text-gray-400 mb-1">Total Value</p>
                  <p className="text-white font-bold">
                    ${contract.value?.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Duration</p>
                  <p className="text-white font-medium">{contract.duration}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Earned</p>
                  <p className="text-green-400 font-bold">
                    ${contract.earned?.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Completion</p>
                  <p className="text-white font-medium">
                    {contract.completion}%
                  </p>
                </div>
              </div>

              <div className="h-2 bg-black/30 rounded-full overflow-hidden mb-4">
                <div
                  className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
                  style={{ width: `${contract.completion}%` }}
                ></div>
              </div>

              <button className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors">
                View Contract Details
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-400 text-center py-12">
          No contracts available
        </p>
      )}
    </div>
  );
}

// --- MILESTONES TAB ---
function MilestonesTab({ milestones }) {
  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
      <h3 className="text-lg font-bold text-white mb-6">Milestone Progress</h3>

      {milestones && milestones.length > 0 ? (
        <div className="space-y-4">
          {milestones.map((milestone, idx) => (
            <div key={idx} className="bg-black/30 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-4">
                <Award className="w-6 h-6 text-purple-400" />
                <div className="flex-1">
                  <h4 className="text-white font-bold">{milestone.title}</h4>
                  <p className="text-sm text-gray-400">
                    {milestone.description}
                  </p>
                </div>
                <span className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm font-medium">
                  {milestone.reward}
                </span>
              </div>

              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Progress</span>
                <span className="text-white font-medium">
                  {milestone.progress}%
                </span>
              </div>

              <div className="h-3 bg-black/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                  style={{ width: `${milestone.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-400 text-center py-12">
          No milestones available
        </p>
      )}
    </div>
  );
}

// --- BRANDS TAB ---
function BrandsTab({ opportunities }) {
  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
      <h3 className="text-lg font-bold text-white mb-6">
        Brand Collaboration Opportunities
      </h3>

      {opportunities && opportunities.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {opportunities.map((opp, idx) => (
            <div
              key={idx}
              className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-lg p-6 border border-purple-500/30"
            >
              <h4 className="text-lg font-bold text-white mb-2">
                {opp.brandName}
              </h4>
              <p className="text-sm text-gray-400 mb-4">{opp.description}</p>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <p className="text-xs text-gray-400 mb-1">Est. Value</p>
                  <p className="text-white font-bold">
                    ${opp.estimatedValue?.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Duration</p>
                  <p className="text-white font-medium">{opp.duration}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium transition-colors">
                  View Details
                </button>
                <button className="flex-1 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-sm font-medium transition-colors">
                  Decline
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-400 text-center py-12">
          No opportunities available
        </p>
      )}
    </div>
  );
}

// --- HEALTH TAB ---
function HealthTab({ data }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-bold text-white mb-4">
          Recovery & Health Metrics
        </h3>
        <div className="space-y-4">
          <div className="bg-black/30 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-400">Recovery Score</span>
              <span className="text-green-400 font-bold">92%</span>
            </div>
            <div className="h-2 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
                style={{ width: "92%" }}
              ></div>
            </div>
          </div>

          <div className="bg-black/30 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-400">Sleep Quality</span>
              <span className="text-blue-400 font-bold">85%</span>
            </div>
            <div className="h-2 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
                style={{ width: "85%" }}
              ></div>
            </div>
          </div>

          <div className="bg-black/30 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-400">Injury Risk</span>
              <span className="text-yellow-400 font-bold">Low</span>
            </div>
            <div className="h-2 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-yellow-500 to-orange-500"
                style={{ width: "25%" }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-bold text-white mb-4">
          Recommended Actions
        </h3>
        <div className="space-y-3">
          <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
            <p className="text-green-400 font-medium mb-1">
              ✓ Optimal Performance Window
            </p>
            <p className="text-sm text-gray-400">
              Your recovery metrics indicate peak performance readiness
            </p>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
            <p className="text-yellow-400 font-medium mb-1">
              ⚠ Hydration Reminder
            </p>
            <p className="text-sm text-gray-400">
              Increase water intake before next session
            </p>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
            <p className="text-blue-400 font-medium mb-1">
              ℹ Rest Day Recommended
            </p>
            <p className="text-sm text-gray-400">
              Schedule a full recovery day within the next 48 hours
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
