"use client";

import { useState, useEffect } from "react";
import {
  Sparkles,
  TrendingUp,
  Users,
  Award,
  Target,
  Activity,
  Zap,
  Shield,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function CheerleadingDanceDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [performerData, setPerformerData] = useState(null);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoadingData(true);

      const mockData = {
        summary: {
          totalPerformers: 24,
          avgPPI: 0.88,
          avgStuntRisk: 0.22,
          avgSynchIndex: 0.91,
        },
        performers: [],
      };

      setPerformerData(mockData);
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-900 via-black to-purple-900 flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-16 h-16 text-pink-400 mx-auto mb-4 animate-pulse" />
          <p className="text-white text-xl mt-4">
            Loading Cheerleading & Dance Advisory...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-900 via-black to-purple-900">
      {/* Header */}
      <header className="border-b border-pink-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-pink-500 to-purple-500 p-3 rounded-xl">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Cheerleading & Dance NIL Advisory
                </h1>
                <p className="text-pink-300 text-sm">
                  Performance Precision · Stunt Analytics · Synchronization
                  Intelligence
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-pink-300">Logged in as</p>
                <p className="text-white font-semibold">
                  {user?.name || user?.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="border-b border-pink-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "overview", label: "Overview", icon: Activity },
              { id: "performers", label: "Performer Portfolio", icon: Users },
              { id: "performance", label: "Performance Units", icon: Target },
              { id: "indices", label: "Biometric Indices", icon: TrendingUp },
              { id: "risk", label: "Stunt Risk Analytics", icon: Shield },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-pink-400 text-pink-400"
                    : "border-transparent text-pink-300 hover:text-pink-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && (
          <OverviewTab performerData={performerData} />
        )}
        {activeTab === "performers" && <PerformerPortfolioTab />}
        {activeTab === "performance" && <PerformanceUnitsTab />}
        {activeTab === "indices" && <BiometricIndicesTab />}
        {activeTab === "risk" && <StuntRiskAnalyticsTab />}
      </div>
    </div>
  );
}

function OverviewTab({ performerData }) {
  const metrics = performerData?.summary || {
    totalPerformers: 24,
    avgPPI: 0.88,
    avgStuntRisk: 0.22,
    avgSynchIndex: 0.91,
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Performers"
          value={metrics.totalPerformers}
          icon={Users}
          trend="+5 this quarter"
          color="pink"
        />
        <MetricCard
          title="Avg PPI (Precision)"
          value={(metrics.avgPPI * 100).toFixed(1)}
          icon={Target}
          trend="+4.2% vs last quarter"
          color="purple"
        />
        <MetricCard
          title="Avg Stunt Risk Index"
          value={(metrics.avgStuntRisk * 100).toFixed(1)}
          icon={Shield}
          trend="-3.1% (lower is better)"
          color="blue"
        />
        <MetricCard
          title="Avg Synch Index"
          value={(metrics.avgSynchIndex * 100).toFixed(1)}
          icon={Zap}
          trend="+5.8% vs last quarter"
          color="green"
        />
      </div>

      {/* Performance Units Dashboard */}
      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6">
          Performance Unit Breakdown
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <PerformanceUnitCard
            title="Stunt Execution Units (SEU)"
            value="1,284"
            efficiency="94.2%"
            color="pink"
          />
          <PerformanceUnitCard
            title="Tumble Precision Units (TPU)"
            value="892"
            efficiency="89.5%"
            color="purple"
          />
          <PerformanceUnitCard
            title="Synchronization Units (SU)"
            value="2,103"
            efficiency="91.8%"
            color="blue"
          />
          <PerformanceUnitCard
            title="Formation Transition Units (FTU)"
            value="1,456"
            efficiency="87.3%"
            color="green"
          />
          <PerformanceUnitCard
            title="Crowd Impact Units (CIU)"
            value="3,221"
            efficiency="93.1%"
            color="yellow"
          />
          <PerformanceUnitCard
            title="Dance Precision Units (DPU)"
            value="1,789"
            efficiency="90.4%"
            color="red"
          />
        </div>
      </div>

      {/* Recent Performance Scans */}
      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Recent Performance Scans
        </h2>
        <div className="space-y-3">
          {[
            {
              performer: "Performer A",
              discipline: "All-Star Cheer",
              ppi: 0.94,
              sri: 0.18,
              event: "Nationals",
              date: "2 hours ago",
            },
            {
              performer: "Performer B",
              discipline: "Dance Team",
              ppi: 0.91,
              sri: 0.12,
              event: "Regional Comp",
              date: "5 hours ago",
            },
            {
              performer: "Performer C",
              discipline: "College Cheer",
              ppi: 0.89,
              sri: 0.25,
              event: "Home Game",
              date: "1 day ago",
            },
          ].map((scan, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-4 bg-pink-900/20 rounded-lg border border-pink-500/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">{scan.performer}</p>
                  <p className="text-sm text-pink-300">
                    {scan.discipline} · {scan.event}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold">
                  PPI {(scan.ppi * 100).toFixed(0)}
                </p>
                <p className="text-sm text-pink-300">
                  SRI {(scan.sri * 100).toFixed(0)} · {scan.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Biometric Intelligence */}
      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Biometric Intelligence Summary
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <BiometricCard title="HRV Stability" value="87.2%" trend="+2.1%" />
          <BiometricCard
            title="Breath Efficiency"
            value="91.5%"
            trend="+3.4%"
          />
          <BiometricCard title="Motion Precision" value="89.8%" trend="+1.8%" />
        </div>
      </div>
    </div>
  );
}

function PerformerPortfolioTab() {
  const performers = [
    {
      name: "Performer A",
      discipline: "All-Star Cheer",
      ppi: 0.94,
      sri: 0.18,
      nilValue: 125000,
    },
    {
      name: "Performer B",
      discipline: "Dance Team",
      ppi: 0.91,
      sri: 0.12,
      nilValue: 98000,
    },
    {
      name: "Performer C",
      discipline: "College Cheer",
      ppi: 0.89,
      sri: 0.25,
      nilValue: 87000,
    },
    {
      name: "Performer D",
      discipline: "Hip-Hop Dance",
      ppi: 0.92,
      sri: 0.1,
      nilValue: 110000,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Performer Portfolio</h2>
        <button className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg transition-colors">
          Add Performer
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {performers.map((performer, i) => (
          <PerformerCard key={i} performer={performer} />
        ))}
      </div>
    </div>
  );
}

function PerformanceUnitsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Performance Unit Analytics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Stunt Execution Units (SEU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Total SEUs Captured</span>
              <span className="text-white font-bold">1,284</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Clean Execution Rate</span>
              <span className="text-green-400 font-bold">94.2%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Avg Difficulty Score</span>
              <span className="text-white font-bold">8.7 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Tumble Precision Units (TPU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Total TPUs Captured</span>
              <span className="text-white font-bold">892</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Landing Precision</span>
              <span className="text-green-400 font-bold">89.5%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Form Quality</span>
              <span className="text-white font-bold">9.1 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Synchronization Units (SU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Total SUs Tracked</span>
              <span className="text-white font-bold">2,103</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Team Sync Rate</span>
              <span className="text-green-400 font-bold">91.8%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Timing Precision</span>
              <span className="text-white font-bold">±0.12s avg</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Formation Transition Units (FTU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Total FTUs Executed</span>
              <span className="text-white font-bold">1,456</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Transition Speed</span>
              <span className="text-green-400 font-bold">87.3%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-pink-300">Position Accuracy</span>
              <span className="text-white font-bold">±8cm avg</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BiometricIndicesTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Biometric Performance Indices
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Core Indices</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Performance Precision Index (PPI)"
            value="88.4"
            trend="+4.2"
          />
          <IndexCard title="Stunt Risk Index (SRI)" value="22.1" trend="-3.1" />
          <IndexCard
            title="Synchronization Index (SI)"
            value="91.2"
            trend="+5.8"
          />
        </div>
      </div>

      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Advanced Indices
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Crowd Momentum Index (CMI)"
            value="93.7"
            trend="+6.2"
          />
          <IndexCard
            title="Stamina Efficiency Index"
            value="89.1"
            trend="+2.4"
          />
          <IndexCard title="Recovery Rate Index" value="85.3" trend="+1.9" />
        </div>
      </div>
    </div>
  );
}

function StuntRiskAnalyticsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Stunt Risk Analytics</h2>

      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Risk Profile Distribution
        </h3>
        <div className="space-y-3">
          {[
            { risk: "Low Risk (<15%)", count: 12, color: "bg-green-500" },
            {
              risk: "Moderate Risk (15-30%)",
              count: 8,
              color: "bg-yellow-500",
            },
            { risk: "High Risk (>30%)", count: 4, color: "bg-red-500" },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-white">{item.risk}</span>
                  <span className="text-sm text-pink-300">
                    {item.count} performers
                  </span>
                </div>
                <div className="w-full bg-pink-900/30 rounded-full h-2">
                  <div
                    className={`${item.color} h-2 rounded-full`}
                    style={{ width: `${(item.count / 24) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Risk Mitigation Recommendations
        </h3>
        <div className="space-y-3">
          {[
            {
              recommendation:
                "Increase warm-up duration for high-risk performers",
              priority: "High",
            },
            {
              recommendation: "Review landing technique for tumble sequences",
              priority: "Medium",
            },
            {
              recommendation: "Strengthen core stability training",
              priority: "High",
            },
            {
              recommendation: "Implement progressive load management",
              priority: "Medium",
            },
          ].map((item, i) => (
            <div
              key={i}
              className="p-3 bg-pink-900/20 rounded-lg border border-pink-500/20"
            >
              <div className="flex items-center justify-between">
                <p className="text-white">{item.recommendation}</p>
                <span
                  className={`px-2 py-1 rounded text-xs font-semibold ${
                    item.priority === "High"
                      ? "bg-red-500/20 text-red-300"
                      : "bg-yellow-500/20 text-yellow-300"
                  }`}
                >
                  {item.priority}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color }) {
  const colorClasses = {
    pink: "from-pink-500 to-pink-600",
    purple: "from-purple-500 to-purple-600",
    blue: "from-blue-500 to-blue-600",
    green: "from-green-500 to-green-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-pink-300 uppercase">{title}</p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function PerformanceUnitCard({ title, value, efficiency, color }) {
  return (
    <div className="p-4 bg-pink-900/20 rounded-lg border border-pink-500/20">
      <p className="text-sm text-pink-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{efficiency} efficiency</p>
    </div>
  );
}

function BiometricCard({ title, value, trend }) {
  return (
    <div className="p-4 bg-pink-900/20 rounded-lg border border-pink-500/20">
      <p className="text-sm text-pink-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function PerformerCard({ performer }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-pink-500/30 rounded-xl p-6 hover:border-pink-400 transition-all cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-lg">{performer.name}</p>
          <p className="text-sm text-pink-300">{performer.discipline}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-pink-300">
            Performance Precision (PPI)
          </span>
          <span className="text-white font-bold">
            {(performer.ppi * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-pink-300">Stunt Risk Index (SRI)</span>
          <span className="text-white font-bold">
            {(performer.sri * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-pink-300">NIL Value</span>
          <span className="text-white font-bold">
            ${(performer.nilValue / 1000).toFixed(0)}K
          </span>
        </div>
      </div>
    </div>
  );
}

function IndexCard({ title, value, trend }) {
  return (
    <div className="bg-pink-900/20 border border-pink-500/30 rounded-lg p-4">
      <p className="text-sm text-pink-300 mb-2">{title}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm text-green-400">+{trend}</p>
      </div>
    </div>
  );
}
