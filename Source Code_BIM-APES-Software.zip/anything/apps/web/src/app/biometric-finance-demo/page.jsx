"use client";

import { useState } from "react";
import { DemoHeader } from "@/components/BiometricFinanceDemo/DemoHeader";
import { NavigationTabs } from "@/components/BiometricFinanceDemo/NavigationTabs";
import { OverviewSection } from "@/components/BiometricFinanceDemo/OverviewSection";
import { CoalitionSection } from "@/components/BiometricFinanceDemo/CoalitionSection";
import { PegaFlowsSection } from "@/components/BiometricFinanceDemo/PegaFlowsSection";
import { ArchitectureSection } from "@/components/BiometricFinanceDemo/ArchitectureSection";
import { LiveDemoSection } from "@/components/BiometricFinanceDemo/LiveDemoSection";
import {
  architectureComponents,
  pegaFlows,
  demoSections,
} from "@/components/BiometricFinanceDemo/constants";

export default function BiometricFinanceDemoPage() {
  const [activeSection, setActiveSection] = useState("overview");

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <DemoHeader />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <NavigationTabs
          sections={demoSections}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
        />

        {activeSection === "overview" && <OverviewSection />}
        {activeSection === "coalition" && <CoalitionSection />}
        {activeSection === "pega-flows" && (
          <PegaFlowsSection pegaFlows={pegaFlows} />
        )}
        {activeSection === "architecture" && (
          <ArchitectureSection
            architectureComponents={architectureComponents}
          />
        )}
        {activeSection === "live-demo" && <LiveDemoSection />}
      </div>
    </div>
  );
}
