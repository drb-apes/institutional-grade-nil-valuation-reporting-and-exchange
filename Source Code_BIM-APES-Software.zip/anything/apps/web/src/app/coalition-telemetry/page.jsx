"use client";

import { useState } from "react";
import {
  Activity,
  Award,
  TrendingUp,
  Users,
  Shield,
  Eye,
  Zap,
  Building,
  Target,
  BarChart3,
} from "lucide-react";
import BIMPerformanceDisplay from "@/components/MotionScan/BIMPerformanceDisplay/BIMPerformanceDisplay";
import RegulatoryPhaseCandlestick from "@/components/MotionScan/RegulatoryPhaseCandlestick";

export default function CoalitionTelemetryPage() {
  const [selectedAudience, setSelectedAudience] = useState("all");
  const [lsocEligible, setLsocEligible] = useState(false);

  const audiences = [
    {
      id: "all",
      label: "All Audiences",
      icon: Activity,
      color: "text-gray-600",
      bgColor: "bg-gray-50",
    },
    {
      id: "finance",
      label: "Finance & Investors",
      icon: TrendingUp,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      id: "coaching",
      label: "Coaching & Scouting",
      icon: Target,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      id: "fans",
      label: "Fans & Broadcast",
      icon: Eye,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      id: "institutional",
      label: "Institutional & Compliance",
      icon: Shield,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
  ];

  const chartConfigs = [
    {
      id: 1,
      title: "Predictive Trade-Type Chart",
      audience: "finance",
      purpose: "Finance routing & institutional investors",
      description:
        "Real-time biometric trade routing for institutional investment flows",
      component: "BIMPerformanceDisplay",
      mode: "predictive_trade",
      sportType: "wrestling",
      data: {
        performance_index: {
          overall_score: 85,
          consistency_score: 92,
          power_index: 78,
          endurance_rating: 88,
          technical_proficiency: 91,
        },
      },
      features: [
        "Trade type prediction algorithms",
        "Institutional flow routing",
        "Risk-adjusted pricing models",
        "Portfolio allocation optimization",
      ],
    },
    {
      id: 2,
      title: "BVI Tactical Analysis Chart",
      audience: "coaching",
      purpose: "Coaching insights & scouting optimization",
      description:
        "Tactical performance analysis for coaching staff and scout networks",
      component: "BIMPerformanceDisplay",
      mode: "bvi_tactical",
      sportType: "rugby",
      data: {
        performance_index: {
          overall_score: 87,
          consistency_score: 89,
          tactical_efficiency: 94,
          decision_making: 86,
          pressure_handling: 82,
        },
      },
      features: [
        "Tactical efficiency tracking",
        "Decision-making analysis",
        "Pressure situation modeling",
        "Scout network integration",
      ],
    },
    {
      id: 3,
      title: "Fan Cinematic Display Chart",
      audience: "fans",
      purpose: "Broadcast overlays & fan engagement",
      description:
        "Cinematic performance visualization for broadcast and fan applications",
      component: "BIMPerformanceDisplay",
      mode: "fan_cinematic",
      sportType: "tennis",
      data: {
        performance_index: {
          overall_score: 91,
          consistency_score: 88,
          spike_score: 96,
          accuracy_rating: 89,
          power_consistency: 85,
        },
      },
      features: [
        "Cinematic data overlays",
        "Fan engagement metrics",
        "Broadcast integration",
        "Real-time performance streaming",
      ],
    },
    {
      id: 4,
      title: "Regulatory Phase Analysis Chart",
      audience: "institutional",
      purpose: "Compliance modeling & institutional partnerships",
      description:
        "Regulatory compliance analysis for institutional onboarding and LSOC eligibility",
      component: "RegulatoryPhaseCandlestick",
      mode: "regulatory_compliance",
      data: {
        biometricData: {
          consistency_score: 92,
          compliance_rating: 88,
          trade_efficiency: 85,
          regulatory_alignment: 91,
        },
        tierLevel: 4,
        jurisdiction: "partial",
      },
      features: [
        "Regulatory friction modeling",
        "LSOC swap eligibility",
        "Compliance score tracking",
        "Jurisdiction impact analysis",
      ],
    },
  ];

  const filteredCharts =
    selectedAudience === "all"
      ? chartConfigs
      : chartConfigs.filter((chart) => chart.audience === selectedAudience);

  const renderChart = (config) => {
    if (config.component === "RegulatoryPhaseCandlestick") {
      return (
        <RegulatoryPhaseCandlestick
          biometricData={config.data.biometricData}
          tierLevel={config.data.tierLevel}
          jurisdiction={config.data.jurisdiction}
          onSwapEligibilityChange={setLsocEligible}
          className="h-96"
        />
      );
    }

    return (
      <BIMPerformanceDisplay
        bimData={{
          ...config.data,
          sport_type: config.sportType,
        }}
        chartMode={config.mode}
        className="h-96"
      />
    );
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1D2B3D] to-[#2C3E50] text-white">
        <div className="px-6 py-12">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center space-x-4 mb-6">
              <Activity className="w-10 h-10 text-[#B8860B]" />
              <div>
                <h1 className="text-4xl font-bold">Coalition Telemetry Loop</h1>
                <p className="text-xl text-gray-300 mt-2">
                  Complete biometric trade analysis across all audience
                  verticals
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white/10 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <BarChart3 className="w-5 h-5 text-[#B8860B]" />
                  <span className="text-sm font-medium">Charts Active</span>
                </div>
                <div className="text-2xl font-bold">4/4</div>
              </div>

              <div className="bg-white/10 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Users className="w-5 h-5 text-[#B8860B]" />
                  <span className="text-sm font-medium">Audiences</span>
                </div>
                <div className="text-2xl font-bold">4</div>
              </div>

              <div className="bg-white/10 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Building className="w-5 h-5 text-[#B8860B]" />
                  <span className="text-sm font-medium">Institutional</span>
                </div>
                <div className="text-2xl font-bold">Ready</div>
              </div>

              <div className="bg-white/10 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Zap className="w-5 h-5 text-[#B8860B]" />
                  <span className="text-sm font-medium">LSOC Status</span>
                </div>
                <div
                  className={`text-2xl font-bold ${lsocEligible ? "text-green-300" : "text-yellow-300"}`}
                >
                  {lsocEligible ? "Eligible" : "Pending"}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Audience Filter */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-[#1D2B3D] mb-4">
            Filter by Audience
          </h2>
          <div className="flex flex-wrap gap-3">
            {audiences.map((audience) => {
              const Icon = audience.icon;
              return (
                <button
                  key={audience.id}
                  onClick={() => setSelectedAudience(audience.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                    selectedAudience === audience.id
                      ? `${audience.bgColor} border-2 border-current ${audience.color}`
                      : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-medium">{audience.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Charts Grid */}
        <div className="space-y-8">
          {filteredCharts.map((config) => (
            <div
              key={config.id}
              className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
            >
              {/* Chart Header */}
              <div className="border-b border-gray-100 p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span
                      className={`
                      px-3 py-1 rounded-full text-sm font-medium
                      ${config.audience === "finance" ? "bg-blue-100 text-blue-800" : ""}
                      ${config.audience === "coaching" ? "bg-green-100 text-green-800" : ""}
                      ${config.audience === "fans" ? "bg-purple-100 text-purple-800" : ""}
                      ${config.audience === "institutional" ? "bg-orange-100 text-orange-800" : ""}
                    `}
                    >
                      Chart {config.id}
                    </span>
                    <div>
                      <h3 className="text-xl font-semibold text-[#1D2B3D]">
                        {config.title}
                      </h3>
                      <p className="text-sm text-gray-500">{config.purpose}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">
                      Live Data
                    </div>
                    <div className="text-xs text-gray-500">Updated 30s ago</div>
                  </div>
                </div>

                <p className="text-gray-700 mt-3">{config.description}</p>
              </div>

              {/* Chart Content */}
              <div className="p-6">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  {/* Chart Visualization */}
                  <div className="lg:col-span-3">{renderChart(config)}</div>

                  {/* Features Sidebar */}
                  <div className="lg:col-span-1">
                    <h4 className="font-semibold text-[#1D2B3D] mb-3">
                      Key Features
                    </h4>
                    <ul className="space-y-2">
                      {config.features.map((feature, index) => (
                        <li
                          key={index}
                          className="flex items-start space-x-2 text-sm"
                        >
                          <div className="w-1.5 h-1.5 bg-[#B8860B] rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Technical Specs */}
                    <div className="mt-6 p-3 bg-gray-50 rounded-lg">
                      <h5 className="font-medium text-gray-900 mb-2 text-sm">
                        Technical Specs
                      </h5>
                      <div className="space-y-1 text-xs text-gray-600">
                        <div>Sport: {config.sportType}</div>
                        <div>Mode: {config.mode}</div>
                        <div>Refresh: Real-time</div>
                        <div>API: Coalition v2.0</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Coalition Status Summary */}
        <div className="mt-12 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-blue-900">
                  Coalition Telemetry Complete
                </h3>
                <p className="text-blue-700">
                  Full biometric trade analysis deployed across all audience
                  verticals. Ready for institutional onboarding and
                  coalition-grade investor modeling.
                </p>
              </div>
            </div>

            <div className="text-right">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-sm font-medium text-blue-900">
                    LSOC Status
                  </div>
                  <div
                    className={`text-lg font-bold ${lsocEligible ? "text-green-600" : "text-yellow-600"}`}
                  >
                    {lsocEligible ? "Eligible" : "Pending"}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-blue-900">
                    Tier Level
                  </div>
                  <div className="text-lg font-bold text-blue-600">T4</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Integration Guide */}
        <div className="mt-8 bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-[#1D2B3D] mb-4">
            Integration Guide
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-blue-900 mb-2">
                Financial Integration
              </h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Portfolio management APIs</li>
                <li>• Risk assessment webhooks</li>
                <li>• Trade execution endpoints</li>
                <li>• Institutional data feeds</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-green-900 mb-2">
                Coaching Integration
              </h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Performance tracking APIs</li>
                <li>• Scout network connectivity</li>
                <li>• Training plan optimization</li>
                <li>• Tactical analysis exports</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-purple-900 mb-2">
                Broadcast Integration
              </h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Cinematic overlay APIs</li>
                <li>• Fan engagement widgets</li>
                <li>• Real-time streaming</li>
                <li>• Social media hooks</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-orange-900 mb-2">
                Compliance Integration
              </h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Regulatory monitoring</li>
                <li>• LSOC swap contracts</li>
                <li>• Jurisdiction compliance</li>
                <li>• Audit trail generation</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
