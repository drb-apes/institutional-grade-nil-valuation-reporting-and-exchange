"use client";

import { useState, useRef } from "react";
import {
  Music,
  DollarSign,
  TrendingUp,
  Zap,
  Mic,
  Users,
  Activity,
  Radio,
  ChevronRight,
  Star,
} from "lucide-react";
import useUser from "@/utils/useUser";
import LicensingFooter from "@/components/LicensingFooter";

// ── Concert Performance Unit types (CPUs) ──────────────────────────────────
const CPU_TYPES = [
  {
    id: "song",
    label: "Song Performance",
    icon: "🎵",
    points: 10,
    equiv: "Possession / Drive",
  },
  {
    id: "verse",
    label: "Verse Delivery",
    icon: "🎤",
    points: 4,
    equiv: "Play / Attempt",
  },
  {
    id: "hook",
    label: "Chorus / Hook",
    icon: "⚡",
    points: 8,
    equiv: "Scoring Attempt",
  },
  {
    id: "intensity",
    label: "High-Intensity Moment",
    icon: "🔥",
    points: 12,
    equiv: "Sprint / Burst",
  },
  {
    id: "crowd",
    label: "Crowd Interaction",
    icon: "👥",
    points: 6,
    equiv: "Momentum Swing",
  },
  {
    id: "instrumental",
    label: "Instrumental Solo",
    icon: "🎸",
    points: 5,
    equiv: "Technical Skill",
  },
  {
    id: "transition",
    label: "Set Transition",
    icon: "🔄",
    points: 2,
    equiv: "Phase of Play",
  },
];

// ── NIL Timeline Chart ───────────────────────────────────────────────────────
function NILTimeline({ events, baseValue, color = "#FF3C9A" }) {
  if (!events || events.length === 0) return null;
  const w = 500,
    h = 120,
    pad = 30;
  const values = events.map((e, i) => baseValue + (e.delta || i * 1200));
  const minV = Math.min(...values) * 0.98,
    maxV = Math.max(...values) * 1.02;
  const pts = values.map((v, i) => ({
    x: pad + (i / Math.max(1, values.length - 1)) * (w - pad * 2),
    y: h - pad - ((v - minV) / (maxV - minV)) * (h - pad * 2),
    v,
  }));
  const pathD = pts.reduce(
    (d, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${d} L ${p.x} ${p.y}`),
    "",
  );
  const areaD = `${pathD} L ${pts[pts.length - 1].x} ${h - pad} L ${pts[0].x} ${h - pad} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: "100%" }}>
      <defs>
        <linearGradient id="nilGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.4" />
          <stop offset="100%" stopColor={color} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      <path d={areaD} fill="url(#nilGrad)" />
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
      {pts.map((p, i) => (
        <g key={i}>
          <circle
            cx={p.x}
            cy={p.y}
            r="4"
            fill={color}
            stroke="#0a1628"
            strokeWidth="2"
          />
          <text x={p.x} y={h - 5} textAnchor="middle" fill="#555" fontSize="8">
            {events[i].label || `CPU ${i + 1}`}
          </text>
        </g>
      ))}
      <text
        x={pad}
        y={
          h -
          pad -
          ((values[values.length - 1] - minV) / (maxV - minV)) * (h - pad * 2) -
          8
        }
        fill={color}
        fontSize="9"
        fontFamily="monospace"
        fontWeight="700"
      >
        ${values[values.length - 1].toLocaleString()}
      </text>
    </svg>
  );
}

// ── APS Dial ─────────────────────────────────────────────────────────────────
function APSDial({ score, label = "APS", color = "#FF3C9A" }) {
  const r = 56,
    cx = 70,
    cy = 76;
  const circ = Math.PI * r;
  const offset = circ * (1 - Math.min(100, Math.max(0, score)) / 100);
  const grade =
    score >= 90
      ? "LEGENDARY"
      : score >= 80
        ? "ELITE"
        : score >= 70
          ? "STAR"
          : score >= 55
            ? "RISING"
            : "DEVELOPING";
  const gradeColor = score >= 80 ? "#FFCC33" : score >= 65 ? color : "#FF8C33";

  return (
    <div style={{ textAlign: "center" }}>
      <svg width={140} height={110} viewBox="0 0 140 110">
        <path
          d={`M 14 76 A 56 56 0 0 1 126 76`}
          fill="none"
          stroke="#1a2a3a"
          strokeWidth="12"
          strokeLinecap="round"
        />
        <path
          d={`M 14 76 A 56 56 0 0 1 126 76`}
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1s ease" }}
        />
        <text
          x={cx}
          y={cy - 10}
          textAnchor="middle"
          fill={color}
          fontSize="24"
          fontWeight="900"
          fontFamily="monospace"
        >
          {score?.toFixed(0)}
        </text>
        <text
          x={cx}
          y={cy + 8}
          textAnchor="middle"
          fill="#555"
          fontSize="8"
          textTransform="uppercase"
        >
          {label}
        </text>
        <text
          x={cx}
          y={cy + 22}
          textAnchor="middle"
          fill={gradeColor}
          fontSize="9"
          fontWeight="700"
          letterSpacing="1"
        >
          {grade}
        </text>
      </svg>
    </div>
  );
}

// ── CPU Feed ──────────────────────────────────────────────────────────────────
function CPUFeedItem({ cpu, delta, description }) {
  const isPositive = delta >= 0;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 0",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
      }}
    >
      <span style={{ fontSize: 20 }}>{cpu.icon}</span>
      <div style={{ flex: 1 }}>
        <p
          style={{
            color: "#fff",
            fontSize: 13,
            fontWeight: 600,
            marginBottom: 2,
          }}
        >
          {cpu.label}
        </p>
        <p style={{ color: "#666", fontSize: 11 }}>
          {description || cpu.equiv}
        </p>
      </div>
      <div style={{ textAlign: "right" }}>
        <p
          style={{
            color: isPositive ? "#3CFF7A" : "#FF3C3C",
            fontFamily: "monospace",
            fontSize: 13,
            fontWeight: 700,
          }}
        >
          {isPositive ? "+" : ""}${Math.abs(delta).toLocaleString()}
        </p>
        <p style={{ color: "#555", fontSize: 10 }}>NIL Impact</p>
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export default function ConcertNILDashboard() {
  const { data: user, loading } = useUser();
  const [artistId, setArtistId] = useState("1");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");

  const [concertConfig, setConcertConfig] = useState({
    venueCapacity: 8500,
    ticketRevenue: 425000,
    setlistLength: 18,
    concertDurationMinutes: 110,
    vocalQuality: 88,
    crowdEngagementPeak: 95,
    socialSpikes: 3,
    broadcastReach: 125000,
    technicalIssues: 0,
    surpriseGuest: false,
  });

  // Simulate Concert Performance Units (CPUs) for the setlist
  const cpuFeed = [
    {
      cpu: CPU_TYPES[0],
      delta: 8200,
      description: "Opening anthem — crowd immediately engaged",
    },
    {
      cpu: CPU_TYPES[2],
      delta: 5400,
      description: "Pre-chorus hook lands perfectly — NIL spike",
    },
    {
      cpu: CPU_TYPES[3],
      delta: 9100,
      description: "Vocal run + stage sprint — peak energy moment",
    },
    {
      cpu: CPU_TYPES[4],
      delta: 6800,
      description: "Call-and-response drives crowd participation rate to 94%",
    },
    {
      cpu: CPU_TYPES[1],
      delta: -1200,
      description: "Verse delivery slightly off-tempo — minor NIL dip",
    },
    {
      cpu: CPU_TYPES[3],
      delta: 11500,
      description: "Pyro moment + vocal peak — biggest spike of night",
    },
    {
      cpu: CPU_TYPES[0],
      delta: 7300,
      description: "Fan favorite — social clips already going viral",
    },
  ];

  const handleAnalyze = async (e) => {
    e.preventDefault();
    if (!artistId) {
      setError("Please enter an artist ID");
      return;
    }
    setLoadingData(true);
    setError(null);
    try {
      const songs = Array.from(
        { length: Math.min(concertConfig.setlistLength, 20) },
        (_, i) => ({
          vocalClean: Math.random() > 0.15,
          errors: Math.random() < 0.1,
          duration: 180 + Math.floor(Math.random() * 90),
          verses: [
            {
              clarity: 75 + Math.random() * 20,
              timing: 78 + Math.random() * 18,
              wpm: 110 + Math.random() * 40,
            },
          ],
          hooks: [
            {
              pitchAccuracy: 80 + Math.random() * 18,
              powerOutput: 78 + Math.random() * 18,
              crowdSing: 80 + Math.random() * 18,
            },
          ],
          intensity: concertConfig.vocalQuality - 5 + Math.random() * 15,
        }),
      );
      const crowdEngagement = Array.from({ length: 8 }, (_, i) => ({
        level: 70 + Math.random() * 28,
        timestamp: Date.now() - (7 - i) * 600000,
      }));

      const res = await fetch("/api/music-nil/live-concert-performance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          artistId: parseInt(artistId),
          concertData: {
            songs,
            crowdEngagement,
            socialSpikes: Array.from(
              { length: concertConfig.socialSpikes },
              (_, i) => ({
                platform: ["TikTok", "Instagram", "X"][i] || "YouTube",
                growthRate: 80 + Math.random() * 120,
              }),
            ),
            technicalIssues: [],
          },
          venueCapacity: concertConfig.venueCapacity,
          ticketRevenue: concertConfig.ticketRevenue,
        }),
      });
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      setPerformanceData(await res.json());
    } catch (err) {
      console.error(err);
      // Compute fallback locally
      const aps = Math.min(
        100,
        concertConfig.vocalQuality * 0.5 +
          concertConfig.crowdEngagementPeak * 0.3 +
          Math.min(100, concertConfig.socialSpikes * 20) * 0.2,
      );
      const baseVal = concertConfig.ticketRevenue * 0.15;
      const currentVal = baseVal * (1 + (aps - 50) / 100);
      setPerformanceData({
        artistPerformanceScore: parseFloat(aps.toFixed(1)),
        tier:
          aps >= 85
            ? "platinum"
            : aps >= 70
              ? "gold"
              : aps >= 55
                ? "silver"
                : "bronze",
        nilValuation: {
          baseValue: Math.round(baseVal),
          currentValue: Math.round(currentVal),
          changeFromBase: parseFloat(
            (((currentVal - baseVal) / baseVal) * 100).toFixed(1),
          ),
        },
        performanceMetrics: {
          songMetrics: {
            songAccuracy: concertConfig.vocalQuality,
            totalSongs: concertConfig.setlistLength,
            averageSongDuration: 220,
          },
          crowdMetrics: {
            averageEngagement: concertConfig.crowdEngagementPeak * 0.9,
            engagementSpikes: concertConfig.socialSpikes,
            responseVolume: concertConfig.crowdEngagementPeak,
          },
        },
        sponsorROI: {
          brandValue: Math.round(currentVal * 0.3),
          estimatedReach:
            concertConfig.broadcastReach + concertConfig.venueCapacity,
          roiMultiplier: parseFloat((aps / 40).toFixed(1)),
        },
        insights: [
          {
            type: aps >= 75 ? "strength" : "weakness",
            area: "Vocal Performance",
            message: `${aps >= 75 ? "Outstanding" : "Developing"} vocal quality at ${concertConfig.vocalQuality}% — primary NIL value driver.`,
            recommendation:
              aps >= 75
                ? "Leverage vocal consistency for premium sponsor activations."
                : "Vocal coaching and breathing exercises recommended before next show.",
          },
          {
            type: "strength",
            area: "Crowd Engagement",
            message: `Peak crowd engagement at ${concertConfig.crowdEngagementPeak}% — call-and-response segments are working.`,
            recommendation:
              "Structure fan interaction moments earlier in the setlist to build momentum faster.",
          },
          concertConfig.socialSpikes >= 2
            ? {
                type: "strength",
                area: "Social Amplification",
                message: `${concertConfig.socialSpikes} social spikes detected during performance — viral moment created.`,
                recommendation:
                  "Work with team to capitalize on viral content for brand partnership outreach.",
              }
            : {
                type: "warning",
                area: "Social Amplification",
                message:
                  "Limited social spikes detected. Create more shareable AR-ready moments.",
                recommendation:
                  "Plan branded moments specifically for social media virality.",
              },
        ],
      });
    } finally {
      setLoadingData(false);
    }
  };

  const nilTimeline = performanceData
    ? cpuFeed
        .map((f, i) => ({ label: f.cpu.icon, delta: f.delta }))
        .reduce(
          (acc, item, i) => {
            const prev =
              acc[acc.length - 1] ||
              performanceData.nilValuation?.baseValue ||
              60000;
            return [...acc, { label: item.label, v: prev + item.delta }];
          },
          [performanceData?.nilValuation?.baseValue || 60000],
        )
    : [];

  const tabs = ["overview", "cpu_feed", "sponsor", "insights"];

  if (loading)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #1a0022, #0a0028)" }}
      >
        <div className="text-white text-xl">
          Loading Music NIL Intelligence...
        </div>
      </div>
    );
  if (!user)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #1a0022, #0a0028)" }}
      >
        <div className="text-center">
          <Music className="w-16 h-16 text-pink-400 mx-auto mb-4" />
          <p className="text-white text-xl mb-4">
            Music NIL Concert Intelligence
          </p>
          <a
            href="/account/signin"
            className="bg-pink-600 text-white px-6 py-3 rounded-lg font-semibold"
          >
            Sign In
          </a>
        </div>
      </div>
    );

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "linear-gradient(135deg, #120018, #08001a, #120018)",
      }}
    >
      {/* Header */}
      <div className="border-b border-white/10 bg-black/20 backdrop-blur-lg sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,60,154,0.2)" }}
          >
            <Music className="w-6 h-6 text-pink-400" />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg">
              Music NIL Concert Performance
            </h1>
            <p className="text-xs text-pink-400">
              BIM-APES · Concert Performance Units · Live NIL Valuation
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 p-4 md:p-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Config Panel */}
          <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10 space-y-4">
            <h2 className="text-white font-bold text-base flex items-center gap-2">
              <Radio className="w-5 h-5 text-pink-400" /> Concert Configuration
            </h2>

            <form onSubmit={handleAnalyze} className="space-y-3">
              <div>
                <label className="block text-xs uppercase tracking-wider text-pink-300 mb-1">
                  Artist ID
                </label>
                <input
                  type="number"
                  value={artistId}
                  onChange={(e) => setArtistId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-800 text-white border border-slate-700 focus:border-pink-400 focus:outline-none text-sm"
                />
              </div>

              {[
                ["venueCapacity", "Venue Capacity", 1],
                ["ticketRevenue", "Ticket Revenue ($)", 1],
                ["setlistLength", "Setlist Songs", 1],
                ["vocalQuality", "Vocal Quality Score", 1],
                ["crowdEngagementPeak", "Peak Crowd Engagement %", 1],
                ["socialSpikes", "Social Spike Events", 1],
                ["broadcastReach", "Broadcast / Stream Reach", 1],
              ].map(([f, l]) => (
                <div key={f}>
                  <label className="block text-slate-400 text-xs mb-1">
                    {l}
                  </label>
                  <input
                    type="number"
                    value={concertConfig[f]}
                    onChange={(e) =>
                      setConcertConfig((p) => ({
                        ...p,
                        [f]: parseFloat(e.target.value) || 0,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  />
                </div>
              ))}

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="surpriseGuest"
                  checked={concertConfig.surpriseGuest}
                  onChange={(e) =>
                    setConcertConfig((p) => ({
                      ...p,
                      surpriseGuest: e.target.checked,
                    }))
                  }
                  className="w-4 h-4"
                />
                <label
                  htmlFor="surpriseGuest"
                  className="text-slate-300 text-sm"
                >
                  Surprise Guest Performance
                </label>
              </div>

              {error && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3">
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loadingData}
                className="w-full py-3 px-6 rounded-xl font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50"
                style={{
                  background: loadingData
                    ? "#334"
                    : "linear-gradient(135deg, #FF3C9A, #8B2FC9)",
                  color: "#fff",
                }}
              >
                {loadingData
                  ? "⚡ Computing NIL Value..."
                  : "⚡ Calculate Live NIL"}
              </button>
            </form>

            {/* CPU Type Legend */}
            <div className="pt-4 border-t border-white/10">
              <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">
                Concert Performance Units™
              </p>
              {CPU_TYPES.map((cpu) => (
                <div key={cpu.id} className="flex items-center gap-2 mb-1.5">
                  <span style={{ fontSize: 14 }}>{cpu.icon}</span>
                  <span className="text-slate-400 text-xs">{cpu.label}</span>
                  <span className="ml-auto text-pink-400 text-xs font-mono">
                    +{cpu.points}pts
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2 space-y-5">
            {!performanceData ? (
              <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-12 border border-white/10 flex flex-col items-center min-h-[500px] justify-center">
                <div style={{ fontSize: 64, marginBottom: 16 }}>🎵</div>
                <p className="text-slate-400 text-lg mb-2">
                  Concert NIL Engine Ready
                </p>
                <p className="text-slate-500 text-sm text-center max-w-xs">
                  Configure concert parameters and calculate live NIL valuation
                  using the Concert Performance Unit (CPU) framework
                </p>
                <div className="mt-8 grid grid-cols-2 gap-3 w-full max-w-xs">
                  {CPU_TYPES.slice(0, 4).map((cpu) => (
                    <div
                      key={cpu.id}
                      className="bg-white/5 rounded-xl p-3 border border-white/10 text-center"
                    >
                      <span style={{ fontSize: 24 }}>{cpu.icon}</span>
                      <p className="text-xs text-slate-400 mt-1">
                        {cpu.id === "song"
                          ? "Song"
                          : cpu.id === "hook"
                            ? "Hook"
                            : cpu.id === "intensity"
                              ? "Intensity"
                              : "Crowd"}
                      </p>
                      <p
                        style={{
                          color: "#FF3C9A",
                          fontSize: 11,
                          fontFamily: "monospace",
                        }}
                      >
                        ={cpu.equiv.split("/")[0].trim()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {/* Tabs */}
                <div className="flex gap-2">
                  {tabs.map((t) => (
                    <button
                      key={t}
                      onClick={() => setActiveTab(t)}
                      className="px-4 py-2 rounded-xl text-sm font-semibold transition-all capitalize"
                      style={{
                        background:
                          activeTab === t
                            ? "#FF3C9A"
                            : "rgba(255,255,255,0.05)",
                        color: activeTab === t ? "#fff" : "#888",
                      }}
                    >
                      {t.replace("_", " ")}
                    </button>
                  ))}
                </div>

                {/* Overview Tab */}
                {activeTab === "overview" && (
                  <>
                    {/* APS + NIL Row */}
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-4">
                        Artist Performance Score™
                      </h3>
                      <div className="flex flex-wrap gap-8 justify-center items-start">
                        <APSDial
                          score={performanceData.artistPerformanceScore}
                          color="#FF3C9A"
                          label="APS"
                        />
                        <APSDial
                          score={
                            performanceData.performanceMetrics?.crowdMetrics
                              ?.averageEngagement || 80
                          }
                          color="#FFCC33"
                          label="CROWD"
                        />
                        <APSDial
                          score={
                            performanceData.performanceMetrics?.songMetrics
                              ?.songAccuracy || 78
                          }
                          color="#4DA6FF"
                          label="VOCAL"
                        />
                      </div>
                      <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
                        <span className="text-slate-400 text-sm">
                          Performance Tier
                        </span>
                        <span
                          className="font-bold uppercase text-sm px-3 py-1 rounded-full"
                          style={{
                            background: "rgba(255,60,154,0.2)",
                            color: "#FF3C9A",
                          }}
                        >
                          {performanceData.tier}
                        </span>
                      </div>
                    </div>

                    {/* NIL Valuation */}
                    <div
                      style={{
                        background:
                          "linear-gradient(135deg, rgba(255,60,154,0.1), rgba(139,47,201,0.1))",
                        border: "1px solid rgba(255,60,154,0.25)",
                        borderRadius: 16,
                        padding: 24,
                      }}
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <DollarSign className="w-7 h-7 text-green-400" />
                        <h3 className="text-white font-bold text-lg">
                          Real-Time NIL Valuation
                        </h3>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                        <div>
                          <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                            Base NIL Value
                          </p>
                          <p className="text-2xl font-bold text-white font-mono">
                            $
                            {performanceData.nilValuation?.baseValue?.toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                            Live NIL Value
                          </p>
                          <p className="text-2xl font-bold text-green-400 font-mono">
                            $
                            {performanceData.nilValuation?.currentValue?.toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                            Delta from Base
                          </p>
                          <p
                            className={`text-2xl font-bold font-mono ${performanceData.nilValuation?.changeFromBase >= 0 ? "text-green-400" : "text-red-400"}`}
                          >
                            {performanceData.nilValuation?.changeFromBase >= 0
                              ? "+"
                              : ""}
                            {performanceData.nilValuation?.changeFromBase}%
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* NIL Timeline */}
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-2">
                        Live NIL Movement Timeline
                      </h3>
                      <p className="text-slate-500 text-xs mb-4">
                        Concert Performance Unit (CPU) impacts on NIL value
                      </p>
                      <NILTimeline
                        events={nilTimeline.map((v, i) => ({
                          label: cpuFeed[i]?.cpu.icon || "🎵",
                          delta: 0,
                        }))}
                        baseValue={
                          performanceData.nilValuation?.baseValue || 60000
                        }
                        color="#FF3C9A"
                      />
                    </div>

                    {/* Metrics Grid */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {[
                        [
                          "Songs Performed",
                          performanceData.performanceMetrics?.songMetrics
                            ?.totalSongs,
                          "🎵",
                        ],
                        [
                          "Vocal Accuracy",
                          `${performanceData.performanceMetrics?.songMetrics?.songAccuracy?.toFixed(1)}%`,
                          "🎤",
                        ],
                        [
                          "Crowd Engagement",
                          `${performanceData.performanceMetrics?.crowdMetrics?.averageEngagement?.toFixed(1)}%`,
                          "👥",
                        ],
                        [
                          "Engagement Spikes",
                          performanceData.performanceMetrics?.crowdMetrics
                            ?.engagementSpikes,
                          "⚡",
                        ],
                        [
                          "Est. Reach",
                          performanceData.sponsorROI?.estimatedReach?.toLocaleString(),
                          "📡",
                        ],
                        [
                          "ROI Multiplier",
                          `${performanceData.sponsorROI?.roiMultiplier}x`,
                          "💰",
                        ],
                      ].map(([l, v, icon]) => (
                        <div
                          key={l}
                          className="bg-white/5 rounded-2xl p-4 border border-white/10 text-center"
                        >
                          <span style={{ fontSize: 20 }}>{icon}</span>
                          <p className="text-slate-400 text-xs uppercase tracking-wider my-1">
                            {l}
                          </p>
                          <p className="text-white font-bold text-lg font-mono">
                            {v}
                          </p>
                        </div>
                      ))}
                    </div>
                  </>
                )}

                {/* CPU Feed Tab */}
                {activeTab === "cpu_feed" && (
                  <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                    <h3 className="text-white font-bold text-base mb-4">
                      Concert Performance Unit Feed™
                    </h3>
                    <p className="text-slate-500 text-xs mb-4">
                      Real-time CPU events and their NIL impact — equivalent to
                      play-by-play analytics in sports
                    </p>
                    {cpuFeed.map((f, i) => (
                      <CPUFeedItem
                        key={i}
                        cpu={f.cpu}
                        delta={f.delta}
                        description={f.description}
                      />
                    ))}
                    <div className="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
                      <span className="text-slate-400 text-sm">
                        Net NIL Impact (7 CPUs)
                      </span>
                      <span className="text-green-400 font-bold font-mono text-lg">
                        +$
                        {cpuFeed
                          .reduce((s, f) => s + f.delta, 0)
                          .toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}

                {/* Sponsor Tab */}
                {activeTab === "sponsor" && (
                  <div className="space-y-4">
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-blue-400" /> Sponsor
                        ROI Dashboard
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
                        {[
                          [
                            "Brand Activation Value",
                            `$${performanceData.sponsorROI?.brandValue?.toLocaleString()}`,
                            "#4DA6FF",
                          ],
                          [
                            "Estimated Total Reach",
                            `${performanceData.sponsorROI?.estimatedReach?.toLocaleString()}`,
                            "#FFCC33",
                          ],
                          [
                            "ROI Multiplier",
                            `${performanceData.sponsorROI?.roiMultiplier}x`,
                            "#3CFF7A",
                          ],
                        ].map(([l, v, c]) => (
                          <div
                            key={l}
                            className="bg-white/5 rounded-xl p-4 text-center"
                          >
                            <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">
                              {l}
                            </p>
                            <p
                              style={{
                                color: c,
                                fontFamily: "monospace",
                                fontSize: 22,
                                fontWeight: 900,
                              }}
                            >
                              {v}
                            </p>
                          </div>
                        ))}
                      </div>

                      {/* Sponsor Activation Types */}
                      <div className="space-y-3">
                        <p className="text-slate-400 text-xs uppercase tracking-wider">
                          Recommended Sponsor Activations
                        </p>
                        {[
                          {
                            brand: "Hydration Brand",
                            moment: "High-Intensity Moments",
                            type: "Brand-Integrated AR Overlay",
                            roi: "High",
                          },
                          {
                            brand: "Apparel Partner",
                            moment: "Stage Entrance / Costume Change",
                            type: "Interactive Product Placement",
                            roi: "Medium",
                          },
                          {
                            brand: "Tech Sponsor",
                            moment: "Crowd Interaction Segments",
                            type: "Fan-Triggered Animation",
                            roi: "Very High",
                          },
                          {
                            brand: "Social Platform",
                            moment: "All Viral Moments",
                            type: "Social-Share-Ready Content",
                            roi: "High",
                          },
                        ].map((act, i) => (
                          <div
                            key={i}
                            style={{
                              background: "rgba(255,255,255,0.03)",
                              border: "1px solid rgba(255,255,255,0.08)",
                              borderRadius: 10,
                              padding: "10px 14px",
                              display: "flex",
                              alignItems: "center",
                              gap: 12,
                            }}
                          >
                            <Star className="w-4 h-4 text-pink-400 flex-shrink-0" />
                            <div style={{ flex: 1 }}>
                              <p className="text-white text-sm font-semibold">
                                {act.brand}
                              </p>
                              <p className="text-slate-500 text-xs">
                                {act.moment} · {act.type}
                              </p>
                            </div>
                            <span
                              style={{
                                color:
                                  act.roi === "Very High"
                                    ? "#3CFF7A"
                                    : act.roi === "High"
                                      ? "#FFCC33"
                                      : "#4DA6FF",
                                fontSize: 11,
                                fontWeight: 700,
                                background: "rgba(255,255,255,0.05)",
                                padding: "2px 8px",
                                borderRadius: 12,
                              }}
                            >
                              {act.roi} ROI
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Insights Tab */}
                {activeTab === "insights" && performanceData.insights && (
                  <div className="space-y-4">
                    {performanceData.insights.map((ins, i) => {
                      const types = {
                        strength: {
                          bg: "rgba(60,255,122,0.08)",
                          border: "rgba(60,255,122,0.3)",
                          dot: "#3CFF7A",
                        },
                        weakness: {
                          bg: "rgba(255,60,60,0.08)",
                          border: "rgba(255,60,60,0.3)",
                          dot: "#FF3C3C",
                        },
                        warning: {
                          bg: "rgba(255,204,51,0.08)",
                          border: "rgba(255,204,51,0.3)",
                          dot: "#FFD93C",
                        },
                      };
                      const t = types[ins.type] || types.warning;
                      return (
                        <div
                          key={i}
                          style={{
                            background: t.bg,
                            border: `1px solid ${t.border}`,
                            borderRadius: 14,
                            padding: "16px 20px",
                          }}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <div
                              style={{
                                width: 10,
                                height: 10,
                                borderRadius: "50%",
                                background: t.dot,
                              }}
                            />
                            <span className="text-white font-bold">
                              {ins.area}
                            </span>
                            <span
                              style={{
                                color: t.dot,
                                fontSize: 11,
                                fontWeight: 700,
                                textTransform: "uppercase",
                                letterSpacing: 1,
                                marginLeft: "auto",
                              }}
                            >
                              {ins.type}
                            </span>
                          </div>
                          <p className="text-slate-300 text-sm mb-2">
                            {ins.message}
                          </p>
                          {ins.recommendation && (
                            <p className="text-slate-400 text-xs flex items-start gap-1">
                              <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                              {ins.recommendation}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <LicensingFooter />
    </div>
  );
}
