"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";
import useSponsorHedgeDashboard from "@/hooks/useSponsorHedgeDashboard";
import DashboardHeader from "@/components/SponsorHedgeDashboard/DashboardHeader";
import MarketOverview from "@/components/SponsorHedgeDashboard/MarketOverview";
import PortfolioSummary from "@/components/SponsorHedgeDashboard/PortfolioSummary";
import ActivePositions from "@/components/SponsorHedgeDashboard/ActivePositions";
import ArbitrageOpportunities from "@/components/SponsorHedgeDashboard/ArbitrageOpportunities";
import HedgingStrategies from "@/components/SponsorHedgeDashboard/HedgingStrategies";
import CampaignROI from "@/components/SponsorHedgeDashboard/CampaignROI";
import TradingSignals from "@/components/SponsorHedgeDashboard/TradingSignals";
import AthleteWatchlist from "@/components/SponsorHedgeDashboard/AthleteWatchlist";

export default function SponsorHedgeDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [selectedView, setSelectedView] = useState("overview"); // overview, positions, opportunities, campaigns
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [refreshInterval, setRefreshInterval] = useState(30000); // 30 seconds

  const {
    marketData,
    portfolioData,
    positions,
    opportunities,
    campaigns,
    signals,
    watchlist,
    loading,
    error,
    refreshData,
  } = useSponsorHedgeDashboard(refreshInterval);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
          <p className="text-slate-400">Loading PhysiobioFIN Dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900/50 border border-slate-800 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">
            Authentication Required
          </h2>
          <p className="text-slate-400 mb-6">
            Please sign in to access the Sponsor Hedge Dashboard
          </p>
          <a
            href="/account/signin"
            className="inline-block px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <DashboardHeader
        user={user}
        selectedView={selectedView}
        setSelectedView={setSelectedView}
        refreshInterval={refreshInterval}
        setRefreshInterval={setRefreshInterval}
        onRefresh={refreshData}
      />

      {/* Main Content */}
      <div className="max-w-[1600px] mx-auto px-4 py-6 space-y-6">
        {/* Market Overview - Always visible */}
        <MarketOverview data={marketData} />

        {/* Portfolio Summary - Always visible */}
        <PortfolioSummary data={portfolioData} />

        {/* View-specific content */}
        {selectedView === "overview" && (
          <>
            {/* Trading Signals */}
            <TradingSignals signals={signals} />

            {/* Split view: Opportunities + Top Campaigns */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ArbitrageOpportunities
                opportunities={opportunities}
                onSelectAthlete={setSelectedAthlete}
              />
              <CampaignROI campaigns={campaigns?.slice(0, 3)} compact />
            </div>

            {/* Athlete Watchlist */}
            <AthleteWatchlist
              watchlist={watchlist}
              onSelectAthlete={setSelectedAthlete}
            />
          </>
        )}

        {selectedView === "positions" && (
          <ActivePositions
            positions={positions}
            onSelectAthlete={setSelectedAthlete}
          />
        )}

        {selectedView === "opportunities" && (
          <>
            <ArbitrageOpportunities
              opportunities={opportunities}
              onSelectAthlete={setSelectedAthlete}
              expanded
            />
            <HedgingStrategies
              marketData={marketData}
              portfolioData={portfolioData}
            />
          </>
        )}

        {selectedView === "campaigns" && <CampaignROI campaigns={campaigns} />}
      </div>

      {/* Selected Athlete Modal */}
      {selectedAthlete && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedAthlete(null)}
        >
          <div
            className="bg-slate-900 border border-slate-700 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-slate-900 border-b border-slate-700 px-6 py-4 flex items-center justify-between">
              <h3 className="text-xl font-bold text-white">
                Athlete Deep Dive
              </h3>
              <button
                onClick={() => setSelectedAthlete(null)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            <div className="p-6">
              <p className="text-slate-300">Athlete ID: {selectedAthlete}</p>
              <p className="text-slate-500 text-sm mt-2">
                Deep dive analytics coming soon...
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
