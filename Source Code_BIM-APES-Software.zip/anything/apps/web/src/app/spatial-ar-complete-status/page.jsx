"use client";

import { CheckCircle, Zap, Tv, Grid3x3, Map, FileText } from "lucide-react";
import useUser from "@/utils/useUser";

export default function SpatialARCompleteStatus() {
  const { data: user, loading } = useUser();

  const tasks = [
    {
      id: 1,
      title: "3D Timeline Playback System",
      description:
        "Scrub through match timelines, watch capsules evolve, overlay coaching playbooks",
      status: "complete",
      features: [
        "Canvas-based 2D visualization (WebGL 3D ready)",
        "Playback controls (play, pause, skip, scrub)",
        "View modes: 3D, Tactical, Capsule",
        "Playbook overlay toggle",
        "Speed controls (0.5x, 1x, 2x)",
        "Real-time capsule state rendering",
        "Tactical geometry (formations, spacing, pressure zones)",
      ],
      endpoints: ["/api/spatial-intelligence/3d-mapping"],
      dashboards: ["/3d-timeline-playback"],
      icon: <Grid3x3 className="w-6 h-6" />,
      color: "cyan",
    },
    {
      id: 2,
      title: "AR/3D Spatial Intelligence Complete Map",
      description:
        "All 24 methods mapped to 47 Olympic sports + Motorsports + Entertainment",
      status: "complete",
      features: [
        "Cyclic Endurance Sports (Track, Swimming, Cycling)",
        "Combat Sports (Wrestling, Boxing, Judo)",
        "Team Sports (Soccer, Basketball, Football)",
        "Racket & Precision Sports (Tennis, Archery)",
        "Motorsports (F1, MotoGP, NASCAR)",
        "Power Sports (Weightlifting, Throws)",
        "Artistic Sports (Gymnastics, Figure Skating)",
        "Winter Sports (Skiing, Bobsled)",
        "Equestrian",
        "Aquatic Sports",
        "Entertainment NIL (Concerts, Fashion)",
      ],
      endpoints: [],
      dashboards: [],
      icon: <Map className="w-6 h-6" />,
      color: "purple",
      documentation: ["/apps/web/AR_3D_SPATIAL_INTELLIGENCE_COMPLETE.md"],
    },
    {
      id: 3,
      title: "Broadcast Network APIs",
      description: "Live data feeds for ESPN, TNT, NBC, and universal adapter",
      status: "complete",
      features: [
        "ESPN Real-Time Feed (200 req/min)",
        "TNT BiomechFlow Capsule Overlay (SVG + animations)",
        "NBC Athlete Story Feed (narrative-focused)",
        "Universal Broadcast Feed (multi-network adapter)",
        "Real-time NIL valuation",
        "BiomechFlow capsule states",
        "Tactical playbook data",
        "Graphics suggestions (automated)",
        "Highlight reel detection",
      ],
      endpoints: [
        "/api/broadcast/espn/real-time-feed",
        "/api/broadcast/tnt/capsule-overlay",
        "/api/broadcast/nbc/athlete-story-feed",
        "/api/broadcast/universal-feed",
      ],
      dashboards: ["/broadcast-network-test"],
      icon: <Tv className="w-6 h-6" />,
      color: "red",
    },
  ];

  const systemCapabilities = [
    {
      category: "Data Throughput",
      capability: "200 req/min (ESPN), 100 req/min (TNT), 60 req/min (NBC)",
    },
    {
      category: "Latency Target",
      capability: "< 100ms (ESPN), < 200ms (TNT), < 500ms (NBC)",
    },
    {
      category: "Sports Supported",
      capability: "47 Olympic + Motorsports + Music/Entertainment NIL",
    },
    {
      category: "AR/3D Methods",
      capability: "24 methods (hedge, arbitrage, scalping, medical)",
    },
    {
      category: "Capsule Components",
      capability:
        "6 (Glow Ring, Stress Arc, Fatigue Arc, Recovery Line, 2 Bars)",
    },
    {
      category: "Mesh Network",
      capability: "Multi-hop topology, offline sync, auto-reparenting",
    },
    {
      category: "Broadcast Networks",
      capability: "ESPN, TNT, NBC, Fox, CBS, Amazon, Apple (universal adapter)",
    },
    {
      category: "Timeline Playback",
      capability: "Frame-by-frame scrubbing, 3 view modes, playbook overlays",
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-indigo-400 underline">
            sign in
          </a>{" "}
          to view system status
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="bg-green-500 rounded-full p-3">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <div>
            <h1 className="text-5xl font-bold text-white mb-2">
              ALL TASKS COMPLETE
            </h1>
            <p className="text-indigo-200 text-xl">
              3D Timeline • AR/3D Spatial Intelligence • Broadcast Network APIs
            </p>
          </div>
        </div>

        <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-6">
          <p className="text-green-300 text-lg">
            ✅ <strong>Task 1:</strong> 3D Timeline Playback with BiomechFlow
            Capsule Evolution
          </p>
          <p className="text-green-300 text-lg">
            ✅ <strong>Task 2:</strong> Complete AR/3D Spatial Intelligence Map
            (All 47 Sports)
          </p>
          <p className="text-green-300 text-lg">
            ✅ <strong>Task 3:</strong> Broadcast Network APIs (ESPN, TNT, NBC,
            Universal)
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Task Summary Cards */}
        {tasks.map((task) => (
          <div
            key={task.id}
            className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
          >
            <div className="flex items-start gap-4 mb-4">
              <div className={`bg-${task.color}-500 rounded-lg p-3`}>
                {task.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-bold text-white">
                    Task {task.id}: {task.title}
                  </h2>
                  <span className="bg-green-500 text-white text-sm font-semibold px-3 py-1 rounded-full uppercase">
                    {task.status}
                  </span>
                </div>
                <p className="text-indigo-200">{task.description}</p>
              </div>
            </div>

            {/* Features */}
            <div className="mb-4">
              <h3 className="text-white font-semibold mb-3">
                Features Delivered:
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {task.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-300 text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Endpoints */}
            {task.endpoints.length > 0 && (
              <div className="mb-4">
                <h3 className="text-white font-semibold mb-2">
                  API Endpoints:
                </h3>
                <div className="space-y-1">
                  {task.endpoints.map((endpoint, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-900 rounded px-3 py-2 border border-slate-700"
                    >
                      <code className="text-green-400 text-sm">{endpoint}</code>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Dashboards */}
            {task.dashboards.length > 0 && (
              <div className="mb-4">
                <h3 className="text-white font-semibold mb-2">Dashboards:</h3>
                <div className="flex gap-2 flex-wrap">
                  {task.dashboards.map((dashboard, idx) => (
                    <a
                      key={idx}
                      href={dashboard}
                      className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-all text-sm font-semibold"
                    >
                      {dashboard}
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Documentation */}
            {task.documentation && task.documentation.length > 0 && (
              <div>
                <h3 className="text-white font-semibold mb-2">
                  Documentation:
                </h3>
                <div className="space-y-1">
                  {task.documentation.map((doc, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-indigo-400" />
                      <code className="text-indigo-300 text-sm">{doc}</code>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}

        {/* System Capabilities */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <Zap className="w-7 h-7 text-yellow-400" />
            System Capabilities
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {systemCapabilities.map((cap, idx) => (
              <div
                key={idx}
                className="bg-slate-900 rounded-lg p-4 border border-slate-700"
              >
                <p className="text-slate-400 text-sm mb-1">{cap.category}</p>
                <p className="text-white font-medium">{cap.capability}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="bg-gradient-to-r from-indigo-900/50 to-purple-900/50 backdrop-blur-lg rounded-xl p-8 border border-indigo-500/30">
          <h2 className="text-3xl font-bold text-white mb-6 text-center">
            🚀 Quick Access Links
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <QuickLinkCard
              title="3D Timeline"
              url="/3d-timeline-playback"
              icon={<Grid3x3 />}
            />
            <QuickLinkCard
              title="Broadcast Test"
              url="/broadcast-network-test"
              icon={<Tv />}
            />
            <QuickLinkCard
              title="Wrestling"
              url="/wrestling-dashboard"
              icon={<Zap />}
            />
            <QuickLinkCard
              title="Tactical Sports"
              url="/tactical-sports-dashboard"
              icon={<Zap />}
            />
            <QuickLinkCard
              title="Racket Sports"
              url="/racket-sports-dashboard"
              icon={<Zap />}
            />
            <QuickLinkCard
              title="Concert NIL"
              url="/concert-nil-dashboard"
              icon={<Zap />}
            />
          </div>
        </div>

        {/* Next Steps */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-4">
            Suggested Next Steps
          </h2>
          <div className="space-y-3">
            <NextStepCard
              priority="High"
              title="Deploy WebGL 3D Renderer"
              description="Upgrade from Canvas 2D to Three.js for true 3D camera angles"
            />
            <NextStepCard
              priority="High"
              title="Test with Live Wearable Devices"
              description="Connect Bluetooth heart rate monitors, GPS trackers, accelerometers"
            />
            <NextStepCard
              priority="Medium"
              title="Add More Sport Modules"
              description="Build dashboards for Swimming, Boxing, Cycling, Gymnastics"
            />
            <NextStepCard
              priority="Medium"
              title="Broadcast Partner Onboarding"
              description="Create API key management system for ESPN, TNT, NBC"
            />
            <NextStepCard
              priority="Low"
              title="VR Headset Support"
              description="Meta Quest / Apple Vision Pro integration for immersive timeline playback"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function QuickLinkCard({ title, url, icon }) {
  return (
    <a
      href={url}
      className="bg-slate-900 rounded-lg p-6 border border-slate-700 hover:border-indigo-500 transition-all group"
    >
      <div className="flex items-center gap-3 mb-2">
        <div className="text-indigo-400 group-hover:text-indigo-300">
          {icon}
        </div>
        <h3 className="text-white font-semibold group-hover:text-indigo-300 transition-colors">
          {title}
        </h3>
      </div>
      <p className="text-slate-400 text-sm">{url}</p>
    </a>
  );
}

function NextStepCard({ priority, title, description }) {
  const priorityColors = {
    High: "bg-red-500/20 border-red-500/30 text-red-300",
    Medium: "bg-yellow-500/20 border-yellow-500/30 text-yellow-300",
    Low: "bg-blue-500/20 border-blue-500/30 text-blue-300",
  };

  return (
    <div className="bg-slate-900 rounded-lg p-4 border border-slate-700 flex gap-4">
      <div
        className={`px-3 py-1 rounded-lg border font-semibold text-sm h-fit ${priorityColors[priority]}`}
      >
        {priority}
      </div>
      <div>
        <h3 className="text-white font-semibold mb-1">{title}</h3>
        <p className="text-slate-400 text-sm">{description}</p>
      </div>
    </div>
  );
}
