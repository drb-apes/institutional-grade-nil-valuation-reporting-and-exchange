"use client";

import { useState } from "react";
import {
  Activity,
  Target,
  TrendingUp,
  AlertCircle,
  Shield,
  Zap,
  Award,
  ChevronRight,
} from "lucide-react";
import useUser from "@/utils/useUser";
import Footer from "@/components/Footer";

// ── BiomechFlow Capsule (CSS-based AR visualization) ────────────────────────
function BiomechCapsule({ bimScore, staminaScore, pinProbability, momentum }) {
  const tier =
    bimScore >= 85
      ? "elite"
      : bimScore >= 70
        ? "advanced"
        : bimScore >= 55
          ? "competitive"
          : "developing";
  const glowColor =
    bimScore >= 80 ? "#FFCC33" : bimScore >= 60 ? "#4DA6FF" : "#FF3C3C";
  const fatigue = 100 - staminaScore;
  const fatigueColor =
    fatigue < 30 ? "#3CFF7A" : fatigue < 60 ? "#FFD93C" : "#FF3C3C";

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        maxWidth: 400,
        margin: "0 auto",
      }}
    >
      {/* Glow Ring */}
      <div
        style={{
          border: `3px solid ${glowColor}`,
          boxShadow: `0 0 20px ${glowColor}66, 0 0 40px ${glowColor}33`,
          borderRadius: 20,
          padding: "24px 20px",
          background: "rgba(0,0,0,0.4)",
          backdropFilter: "blur(12px)",
          position: "relative",
        }}
      >
        {/* Tier Badge */}
        <div style={{ textAlign: "center", marginBottom: 16 }}>
          <span
            style={{
              background: glowColor,
              color: "#000",
              padding: "4px 16px",
              borderRadius: 20,
              fontSize: 11,
              fontWeight: 800,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            {tier} · BIM-APES
          </span>
        </div>

        {/* Top Arc: Stress Load */}
        <div style={{ marginBottom: 16 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 4,
            }}
          >
            <span
              style={{
                color: "#4DA6FF",
                fontSize: 10,
                textTransform: "uppercase",
                letterSpacing: 1,
              }}
            >
              Stress Load
            </span>
            <span style={{ color: "#fff", fontSize: 10 }}>
              {(100 - staminaScore).toFixed(0)}%
            </span>
          </div>
          <div
            style={{
              height: 6,
              background: "#1a2a4a",
              borderRadius: 4,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${100 - staminaScore}%`,
                background: `linear-gradient(90deg, #4DA6FF, #002B66)`,
                borderRadius: 4,
                transition: "width 1s ease",
              }}
            />
          </div>
        </div>

        {/* Center: BIM Score */}
        <div style={{ textAlign: "center", padding: "16px 0" }}>
          <div
            style={{
              fontSize: 64,
              fontWeight: 900,
              color: glowColor,
              lineHeight: 1,
              fontFamily: "monospace",
            }}
          >
            {bimScore.toFixed(1)}
          </div>
          <div
            style={{
              color: "#aaa",
              fontSize: 12,
              marginTop: 4,
              letterSpacing: 2,
            }}
          >
            BIM PERFORMANCE INDEX
          </div>
        </div>

        {/* Left/Right Bars */}
        <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
          <div style={{ flex: 1 }}>
            <div
              style={{
                color: "#aaa",
                fontSize: 10,
                textTransform: "uppercase",
                letterSpacing: 1,
                marginBottom: 4,
              }}
            >
              Pin Prob.
            </div>
            <div
              style={{
                height: Math.max(20, pinProbability * 0.6),
                background: `linear-gradient(180deg, #33FFF3, #002B66)`,
                borderRadius: 4,
                minWidth: "100%",
                transition: "height 1s ease",
              }}
            />
            <div
              style={{
                color: "#33FFF3",
                fontSize: 11,
                marginTop: 4,
                fontFamily: "monospace",
              }}
            >
              {pinProbability.toFixed(0)}%
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div
              style={{
                color: "#aaa",
                fontSize: 10,
                textTransform: "uppercase",
                letterSpacing: 1,
                marginBottom: 4,
              }}
            >
              Momentum
            </div>
            <div
              style={{
                height: Math.max(20, Math.abs(momentum) * 60),
                background:
                  momentum > 0.5
                    ? "linear-gradient(180deg, #3CFF7A, #005522)"
                    : "linear-gradient(180deg, #FF3C3C, #660000)",
                borderRadius: 4,
                transition: "height 1s ease",
              }}
            />
            <div
              style={{
                color: momentum > 0.5 ? "#3CFF7A" : "#FF3C3C",
                fontSize: 11,
                marginTop: 4,
                fontFamily: "monospace",
              }}
            >
              {(momentum * 100).toFixed(0)}
            </div>
          </div>
        </div>

        {/* Bottom Arc: Fatigue */}
        <div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 4,
            }}
          >
            <span
              style={{
                color: fatigueColor,
                fontSize: 10,
                textTransform: "uppercase",
                letterSpacing: 1,
              }}
            >
              Fatigue Level
            </span>
            <span style={{ color: "#fff", fontSize: 10 }}>
              {fatigue.toFixed(0)}%
            </span>
          </div>
          <div
            style={{
              height: 6,
              background: "#1a2a4a",
              borderRadius: 4,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${fatigue}%`,
                background: `linear-gradient(90deg, #3CFF7A, ${fatigueColor})`,
                borderRadius: 4,
                transition: "width 1s ease",
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Period Bars ─────────────────────────────────────────────────────────────
function PeriodBar({ period, label, value, energyLevel }) {
  const color = value >= 75 ? "#3CFF7A" : value >= 55 ? "#FFD93C" : "#FF3C3C";
  return (
    <div style={{ marginBottom: 12 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 4,
        }}
      >
        <span className="text-blue-200 text-sm">
          {label || `Period ${period}`}
        </span>
        <div className="flex items-center gap-2">
          <span
            style={{
              color,
              fontSize: 13,
              fontFamily: "monospace",
              fontWeight: 700,
            }}
          >
            {value?.toFixed(1)}
          </span>
          <span className="text-slate-400 text-xs">
            • Energy {energyLevel}%
          </span>
        </div>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className="h-2 rounded-full transition-all duration-700"
          style={{
            width: `${Math.min(100, value || 0)}%`,
            background: `linear-gradient(90deg, ${color}88, ${color})`,
          }}
        />
      </div>
    </div>
  );
}

// ── Metric Card ─────────────────────────────────────────────────────────────
function StatCard({ label, value, icon, accent = "#4DA6FF" }) {
  return (
    <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-600 flex flex-col gap-2">
      <div className="flex items-center gap-2" style={{ color: accent }}>
        {icon}
        <span className="text-xs text-slate-400 uppercase tracking-wider">
          {label}
        </span>
      </div>
      <div className="text-2xl font-bold text-white font-mono">{value}</div>
    </div>
  );
}

// ── Insight Card ─────────────────────────────────────────────────────────────
function InsightCard({ insight }) {
  const styles = {
    strength: {
      bg: "rgba(60,255,122,0.08)",
      border: "rgba(60,255,122,0.3)",
      dot: "#3CFF7A",
    },
    weakness: {
      bg: "rgba(255,60,60,0.08)",
      border: "rgba(255,60,60,0.3)",
      dot: "#FF3C3C",
    },
    warning: {
      bg: "rgba(255,217,60,0.08)",
      border: "rgba(255,217,60,0.3)",
      dot: "#FFD93C",
    },
  };
  const s = styles[insight.type] || styles.warning;
  return (
    <div
      style={{
        background: s.bg,
        border: `1px solid ${s.border}`,
        borderRadius: 12,
        padding: "12px 16px",
      }}
    >
      <div className="flex items-center gap-2 mb-1">
        <div
          style={{
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: s.dot,
            flexShrink: 0,
          }}
        />
        <span className="text-white text-sm font-semibold">
          {insight.metric}
        </span>
      </div>
      <p className="text-slate-300 text-sm mb-1">{insight.message}</p>
      {insight.recommendation && (
        <p className="text-slate-400 text-xs italic flex items-start gap-1">
          <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
          {insight.recommendation}
        </p>
      )}
    </div>
  );
}

// ── Main Component ───────────────────────────────────────────────────────────
export default function WrestlingDashboard() {
  const { data: user, loading } = useUser();
  const [athleteId, setAthleteId] = useState("1");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const [matchData, setMatchData] = useState({
    takedowns: 4,
    takedownAttempts: 7,
    escapes: 2,
    escapeAttempts: 3,
    reversals: 1,
    reversalAttempts: 2,
    nearFalls: 2,
    controlTimeSeconds: 180,
    totalMatchTimeSeconds: 360,
    exposurePoints: 2,
    technicalViolations: 0,
  });

  const upd = (field, val) =>
    setMatchData((p) => ({ ...p, [field]: parseFloat(val) || 0 }));

  const loadHistory = async (id) => {
    setLoadingHistory(true);
    try {
      const res = await fetch(
        `/api/simulations/history?athleteId=${id}&limit=10`,
      );
      if (!res.ok) throw new Error("History fetch failed");
      const data = await res.json();
      setHistory(
        (data.history || []).filter(
          (h) =>
            h.simulationData?.sport === "wrestling" || !h.simulationData?.sport,
        ),
      );
    } catch (err) {
      console.error("History load error:", err);
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }
    setLoadingData(true);
    setError(null);
    try {
      const res = await fetch(
        "/api/sport-specific/wrestling/performance-tracking",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            matchData,
            sessionType: "match",
          }),
        },
      );
      if (!res.ok) throw new Error(`Server error: ${res.status}`);
      const result = await res.json();
      setPerformanceData(result);
      // Refresh history after successful analysis
      loadHistory(athleteId);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading)
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl animate-pulse">
          Loading BIM-APES Wrestling Module...
        </div>
      </div>
    );

  if (!user)
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Activity className="w-16 h-16 text-blue-400 mx-auto mb-4" />
          <div className="text-white text-xl mb-4">
            Wrestling Performance Tracker
          </div>
          <a
            href="/account/signin"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
          >
            Sign In to Continue
          </a>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex flex-col">
      {/* Header */}
      <div className="border-b border-white/10 bg-black/20 backdrop-blur-lg sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg leading-tight">
                Wrestling Performance Tracker
              </h1>
              <p className="text-blue-300 text-xs">
                BIM-APES · NIL Intelligence Engine
              </p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-3">
            <span className="text-slate-400 text-sm">Signed in as</span>
            <span className="text-white text-sm font-semibold">
              {user.name || user.email}
            </span>
          </div>
        </div>
      </div>

      <div className="flex-1 p-4 md:p-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ── Input Panel ─────────────────────────────────────────────── */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
              <h2 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-400" /> Match Data Input
              </h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-blue-200 text-xs uppercase tracking-wider mb-2">
                    Athlete ID
                  </label>
                  <input
                    type="number"
                    value={athleteId}
                    onChange={(e) => setAthleteId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none text-sm"
                    placeholder="Enter athlete ID"
                  />
                </div>

                {[
                  ["takedowns", "takedownAttempts", "Takedowns", "Attempts"],
                  ["escapes", "escapeAttempts", "Escapes", "Attempts"],
                  ["reversals", "reversalAttempts", "Reversals", "Attempts"],
                ].map(([f1, f2, l1, l2]) => (
                  <div key={f1} className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 text-xs mb-1">
                        {l1}
                      </label>
                      <input
                        type="number"
                        value={matchData[f1]}
                        min="0"
                        onChange={(e) => upd(f1, e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-blue-400 focus:outline-none text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 text-xs mb-1">
                        {l2}
                      </label>
                      <input
                        type="number"
                        value={matchData[f2]}
                        min="0"
                        onChange={(e) => upd(f2, e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-blue-400 focus:outline-none text-sm"
                      />
                    </div>
                  </div>
                ))}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 text-xs mb-1">
                      Near Falls
                    </label>
                    <input
                      type="number"
                      value={matchData.nearFalls}
                      min="0"
                      onChange={(e) => upd("nearFalls", e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-blue-400 focus:outline-none text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 text-xs mb-1">
                      Exposure Pts
                    </label>
                    <input
                      type="number"
                      value={matchData.exposurePoints}
                      min="0"
                      onChange={(e) => upd("exposurePoints", e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-blue-400 focus:outline-none text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 text-xs mb-1">
                      Control Time (sec)
                    </label>
                    <input
                      type="number"
                      value={matchData.controlTimeSeconds}
                      min="0"
                      onChange={(e) =>
                        upd("controlTimeSeconds", e.target.value)
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-blue-400 focus:outline-none text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 text-xs mb-1">
                      Violations
                    </label>
                    <input
                      type="number"
                      value={matchData.technicalViolations}
                      min="0"
                      onChange={(e) =>
                        upd("technicalViolations", e.target.value)
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:border-blue-400 focus:outline-none text-sm"
                    />
                  </div>
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3">
                    <p className="text-red-300 text-sm">{error}</p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loadingData}
                  className="w-full py-3 px-6 rounded-xl font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50"
                  style={{
                    background: loadingData
                      ? "#334"
                      : "linear-gradient(135deg, #1E5FA8, #FFCC33)",
                    color: loadingData ? "#888" : "#000",
                  }}
                >
                  {loadingData
                    ? "⚡ Computing BIM Score..."
                    : "⚡ Analyze Performance"}
                </button>
              </form>
            </div>

            {/* Quick Legend */}
            <div className="bg-white/5 rounded-2xl p-4 border border-white/10">
              <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">
                BiomechFlow Tier Guide
              </p>
              {[
                ["≥ 85", "Elite", "#FFCC33"],
                ["≥ 70", "Advanced", "#3CFF7A"],
                ["≥ 55", "Competitive", "#4DA6FF"],
                ["< 55", "Developing", "#FF3C3C"],
              ].map(([range, label, color]) => (
                <div key={label} className="flex items-center gap-2 mb-2">
                  <div
                    style={{
                      width: 10,
                      height: 10,
                      borderRadius: "50%",
                      background: color,
                    }}
                  />
                  <span
                    style={{
                      color,
                      fontSize: 11,
                      fontFamily: "monospace",
                      fontWeight: 700,
                    }}
                  >
                    {range}
                  </span>
                  <span className="text-slate-400 text-xs">{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── Results Panel ─────────────────────────────────────────────── */}
          <div className="lg:col-span-2 space-y-6">
            {!performanceData ? (
              <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-12 border border-white/10 flex flex-col items-center justify-center min-h-[400px]">
                <Activity className="w-20 h-20 text-blue-400/30 mb-4" />
                <p className="text-slate-400 text-lg mb-2">
                  Wrestling Intelligence Ready
                </p>
                <p className="text-slate-500 text-sm">
                  Enter match data and click Analyze to generate the BiomechFlow
                  Capsule
                </p>
              </div>
            ) : (
              <>
                {/* BiomechFlow Capsule */}
                <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-white font-bold text-lg">
                      BiomechFlow Capsule™
                    </h3>
                    <span className="text-slate-400 text-xs uppercase tracking-wider">
                      AR Intelligence Overlay
                    </span>
                  </div>
                  <BiomechCapsule
                    bimScore={performanceData.bimScore}
                    staminaScore={performanceData.staminaScore}
                    pinProbability={performanceData.pinProbability}
                    momentum={performanceData.momentum}
                  />
                </div>

                {/* Core Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatCard
                    label="Takedown Eff."
                    value={`${performanceData.performanceMetrics?.takedownEfficiency?.toFixed(1)}%`}
                    icon={<Target className="w-4 h-4" />}
                    accent="#FFCC33"
                  />
                  <StatCard
                    label="Control Time"
                    value={`${performanceData.performanceMetrics?.controlPercentage?.toFixed(1)}%`}
                    icon={<Shield className="w-4 h-4" />}
                    accent="#4DA6FF"
                  />
                  <StatCard
                    label="Pin Probability"
                    value={`${performanceData.pinProbability?.toFixed(1)}%`}
                    icon={<Zap className="w-4 h-4" />}
                    accent="#FF3C3C"
                  />
                  <StatCard
                    label="BIM Tier"
                    value={performanceData.tier?.toUpperCase()}
                    icon={<Award className="w-4 h-4" />}
                    accent="#3CFF7A"
                  />
                </div>

                {/* Period Analysis */}
                {performanceData.periodAnalysis &&
                  performanceData.periodAnalysis.length > 0 && (
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-4">
                        Period-by-Period Breakdown
                      </h3>
                      {performanceData.periodAnalysis.map((p) => (
                        <PeriodBar
                          key={p.period}
                          period={p.period}
                          label={`Period ${p.period} — ${p.focus}`}
                          value={p.score}
                          energyLevel={p.energyLevel || 80}
                        />
                      ))}
                    </div>
                  )}

                {/* Score Breakdown */}
                {performanceData.breakdown && (
                  <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                    <h3 className="text-white font-bold text-base mb-4">
                      Score Breakdown
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {Object.entries(performanceData.breakdown).map(
                        ([key, val]) => {
                          const label = key
                            .replace(/Component$/, "")
                            .replace(/([A-Z])/g, " $1")
                            .trim();
                          const pct = Math.min(100, Math.max(0, val));
                          return (
                            <div
                              key={key}
                              className="bg-slate-800/50 rounded-xl p-3 border border-slate-700"
                            >
                              <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                                {label}
                              </p>
                              <p className="text-white font-mono text-lg font-bold mb-1">
                                {pct.toFixed(1)}
                              </p>
                              <div className="w-full bg-slate-700 rounded-full h-1.5">
                                <div
                                  className="h-1.5 rounded-full bg-blue-500 transition-all duration-700"
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                            </div>
                          );
                        },
                      )}
                    </div>
                  </div>
                )}

                {/* Coaching Insights */}
                {performanceData.insights &&
                  performanceData.insights.length > 0 && (
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-yellow-400" />{" "}
                        Coaching Insights
                      </h3>
                      <div className="space-y-3">
                        {performanceData.insights.map((insight, i) => (
                          <InsightCard key={i} insight={insight} />
                        ))}
                      </div>
                    </div>
                  )}

                {/* NIL Valuation Block */}
                <div
                  style={{
                    background:
                      "linear-gradient(135deg, rgba(255,204,51,0.08), rgba(30,95,168,0.08))",
                    border: "1px solid rgba(255,204,51,0.2)",
                    borderRadius: 16,
                    padding: 24,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                        Estimated NIL Market Value
                      </p>
                      <p
                        style={{
                          color: "#FFCC33",
                          fontSize: 28,
                          fontWeight: 900,
                          fontFamily: "monospace",
                        }}
                      >
                        ${(performanceData.bimScore * 1250).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                        Sponsor ROI Signal
                      </p>
                      <p className="text-green-400 text-xl font-bold font-mono">
                        {performanceData.bimScore >= 70
                          ? "BUY"
                          : performanceData.bimScore >= 50
                            ? "HOLD"
                            : "MONITOR"}
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ── Analysis History ──────────────────────────────────────────── */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 pb-6">
        <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-bold text-base flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-400" />
              Past Wrestling Analyses
            </h3>
            <button
              onClick={() => loadHistory(athleteId)}
              disabled={loadingHistory}
              className="text-xs text-blue-400 hover:text-blue-300 transition-colors disabled:opacity-50"
            >
              {loadingHistory ? "Loading…" : "↻ Refresh"}
            </button>
          </div>
          {loadingHistory ? (
            <div className="flex items-center gap-2 text-slate-400 text-sm py-4">
              <Activity className="w-4 h-4 animate-spin" />
              Loading history…
            </div>
          ) : history.length === 0 ? (
            <p className="text-slate-500 text-sm py-4">
              No past analyses found for Athlete #{athleteId}. Run your first
              analysis above to begin tracking.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left border-b border-white/10">
                    <th className="pb-2 text-slate-400 text-xs uppercase tracking-wider font-medium">
                      Date
                    </th>
                    <th className="pb-2 text-slate-400 text-xs uppercase tracking-wider font-medium">
                      BIM Score
                    </th>
                    <th className="pb-2 text-slate-400 text-xs uppercase tracking-wider font-medium">
                      Tier
                    </th>
                    <th className="pb-2 text-slate-400 text-xs uppercase tracking-wider font-medium">
                      ROI Signal
                    </th>
                    <th className="pb-2 text-slate-400 text-xs uppercase tracking-wider font-medium">
                      Est. NIL Value
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((h) => {
                    const tierColors = {
                      elite: "#FFCC33",
                      advanced: "#3CFF7A",
                      competitive: "#4DA6FF",
                      developing: "#FF8C33",
                    };
                    const c = tierColors[h.tier] || "#999";
                    const signal =
                      h.bimScore >= 70
                        ? "BUY"
                        : h.bimScore >= 50
                          ? "HOLD"
                          : "MONITOR";
                    const signalColor =
                      signal === "BUY"
                        ? "#3CFF7A"
                        : signal === "HOLD"
                          ? "#FFCC33"
                          : "#FF8C33";
                    const dateStr = new Date(h.createdAt).toLocaleDateString(
                      undefined,
                      {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      },
                    );
                    return (
                      <tr
                        key={h.id}
                        className="border-b border-white/5 hover:bg-white/5 transition-colors"
                      >
                        <td className="py-2 text-slate-400 text-xs">
                          {dateStr}
                        </td>
                        <td className="py-2">
                          <span
                            style={{
                              color: c,
                              fontFamily: "monospace",
                              fontWeight: 700,
                            }}
                          >
                            {h.bimScore > 0
                              ? h.bimScore.toFixed(1)
                              : (h.assetValue / 1000).toFixed(1)}
                          </span>
                        </td>
                        <td className="py-2">
                          <span
                            style={{
                              color: c,
                              fontSize: 11,
                              fontWeight: 700,
                              textTransform: "uppercase",
                            }}
                          >
                            {h.tier}
                          </span>
                        </td>
                        <td className="py-2">
                          <span
                            style={{
                              color: signalColor,
                              fontSize: 12,
                              fontWeight: 700,
                            }}
                          >
                            {signal}
                          </span>
                        </td>
                        <td className="py-2">
                          <span
                            style={{
                              color: "#FFCC33",
                              fontFamily: "monospace",
                              fontSize: 12,
                            }}
                          >
                            $
                            {h.assetValue.toLocaleString(undefined, {
                              maximumFractionDigits: 0,
                            })}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
