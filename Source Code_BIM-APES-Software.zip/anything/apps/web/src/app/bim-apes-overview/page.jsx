"use client";

import { useState } from "react";
import {
  User,
  BarChart3,
  Shield,
  Code,
  Handshake,
  Trophy,
  TrendingUp,
  Download,
  Printer,
  ChevronRight,
  CheckCircle2,
} from "lucide-react";
import { BRAND_CLASSES } from "@/utils/brandColors";

export default function BIMAPESOverview() {
  const [activeSection, setActiveSection] = useState("overview");

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    // Trigger print dialog which can save as PDF
    window.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50]">
      {/* Branded Header - Print Friendly */}
      <header className="bg-[#1D2B3D]/80 backdrop-blur-lg border-b-2 border-[#B8860B] print:bg-white print:border-black">
        <div className="max-w-[1400px] mx-auto px-8 py-8">
          <div className="flex items-center justify-between print:justify-center">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[#B8860B] to-[#FFD700] rounded-xl flex items-center justify-center shadow-lg shadow-[#B8860B]/50 print:shadow-none">
                <TrendingUp className="w-10 h-10 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white mb-1 print:text-black">
                  BIM APES
                </h1>
                <p className="text-[#B8860B] font-medium print:text-gray-700">
                  Athletic Performance Exchange System
                </p>
              </div>
            </div>

            {/* Action Buttons - Hidden in Print */}
            <div className="flex gap-3 print:hidden">
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg transition-all"
              >
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button
                onClick={handleDownloadPDF}
                className="flex items-center gap-2 px-6 py-2 bg-[#B8860B] hover:bg-[#A0750A] text-black font-semibold rounded-lg transition-all shadow-lg shadow-[#B8860B]/30"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content - Two Column Layout */}
      <div className="max-w-[1400px] mx-auto px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 print:grid-cols-1">
          {/* Sidebar Navigation - Hidden in Print */}
          <aside className="lg:col-span-1 print:hidden">
            <nav className="sticky top-8 bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-4">
              <h2 className="text-white font-bold mb-4 px-2">Contents</h2>
              <div className="space-y-1">
                {sections.map((section) => {
                  const Icon = section.icon;
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                        activeSection === section.id
                          ? "bg-[#B8860B] text-black"
                          : "text-gray-300 hover:bg-white/10"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm font-medium">
                        {section.title}
                      </span>
                    </button>
                  );
                })}
              </div>
            </nav>
          </aside>

          {/* Main Content Area - Two Column Print Layout */}
          <main className="lg:col-span-2 space-y-8 print:space-y-6">
            {/* System Overview */}
            <Section id="overview" icon={BarChart3} title="System Overview">
              <p className="text-gray-300 mb-4 print:text-black">
                BIM APES (Biometric Index Market - Athlete Performance Equity
                Swaps) is a revolutionary platform that transforms athletic
                performance data into tradable financial instruments through
                advanced biometric indexing and real-time performance analytics.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 print:gap-3 print:grid-cols-2">
                <MetricCard
                  title="Performance Indices"
                  value="12+"
                  description="Sport-specific BIM calculations"
                  color="gold"
                />
                <MetricCard
                  title="Real-Time Tracking"
                  value="<100ms"
                  description="Biometric data latency"
                  color="cyan"
                />
                <MetricCard
                  title="Tier Accuracy"
                  value="94.7%"
                  description="AI-powered classification"
                  color="gold"
                />
                <MetricCard
                  title="Trade Volume"
                  value="$2.4M+"
                  description="Monthly equity swaps"
                  color="cyan"
                />
              </div>
            </Section>

            {/* Account & Setup */}
            <Section
              id="account"
              icon={User}
              title="Account & Participant Setup"
            >
              <p className="text-gray-300 mb-4 print:text-black">
                BIM APES supports multiple participant types with role-based
                access and customizable permissions.
              </p>

              <ParticipantTable />
            </Section>

            {/* Analytics & Performance */}
            <Section
              id="analytics"
              icon={BarChart3}
              title="Analytics & Performance Metrics"
            >
              <p className="text-gray-300 mb-4 print:text-black">
                Comprehensive performance tracking across multiple sports with
                real-time biometric indexing and predictive analytics.
              </p>

              <SportMetricsTable />
            </Section>

            {/* Tier System */}
            <Section
              id="tiers"
              icon={Trophy}
              title="Performance Tier Classification"
            >
              <p className="text-gray-300 mb-4 print:text-black">
                Athletes are classified into performance tiers based on BIM
                scores, consistency metrics, and growth trajectory analysis.
              </p>

              <TierTable />
            </Section>

            {/* Security & Licensing */}
            <Section id="security" icon={Shield} title="Security & Licensing">
              <p className="text-gray-300 mb-4 print:text-black">
                Enterprise-grade security with role-based access control, data
                encryption, and comprehensive audit logging.
              </p>

              <SecurityFeatures />
            </Section>

            {/* API & Integration */}
            <Section id="api" icon={Code} title="API & Integration">
              <p className="text-gray-300 mb-4 print:text-black">
                RESTful API with comprehensive endpoints for biometric data
                ingestion, performance analysis, and trading operations.
              </p>

              <APIEndpointsTable />
            </Section>

            {/* Milestones & Partnerships */}
            <Section
              id="partnerships"
              icon={Handshake}
              title="Milestones & Strategic Partnerships"
            >
              <p className="text-gray-300 mb-4 print:text-black">
                Performance milestones unlock additional value and create
                opportunities for sponsor partnerships and athlete development
                funding.
              </p>

              <MilestoneTable />
            </Section>

            {/* Rewards & Incentives */}
            <Section
              id="rewards"
              icon={Trophy}
              title="Rewards & Incentive Structure"
            >
              <p className="text-gray-300 mb-4 print:text-black">
                Multi-tiered reward system for athletes, coaches, and investors
                based on performance achievements and platform engagement.
              </p>

              <RewardsTable />
            </Section>

            {/* Trading & Deployment */}
            <Section
              id="trading"
              icon={TrendingUp}
              title="Trading Operations & System Deployment"
            >
              <p className="text-gray-300 mb-4 print:text-black">
                Automated trading infrastructure with real-time position
                management, risk hedging, and arbitrage opportunity detection.
              </p>

              <TradingFeaturesTable />
            </Section>
          </main>
        </div>
      </div>

      {/* Print-Only Footer */}
      <footer className="hidden print:block mt-12 pt-6 border-t border-gray-300">
        <div className="max-w-[1400px] mx-auto px-8">
          <p className="text-sm text-gray-600 text-center">
            BIM APES - Athletic Performance Exchange System | Generated{" "}
            {new Date().toLocaleDateString()}
          </p>
        </div>
      </footer>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          @page {
            margin: 1in;
            size: letter;
          }
          
          body {
            background: white !important;
          }
          
          .print\\:hidden {
            display: none !important;
          }
          
          .print\\:block {
            display: block !important;
          }
          
          .print\\:grid-cols-1 {
            grid-template-columns: repeat(1, minmax(0, 1fr)) !important;
          }
          
          .print\\:grid-cols-2 {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
          }
          
          .print\\:text-black {
            color: black !important;
          }
          
          .print\\:bg-white {
            background-color: white !important;
          }
          
          .print\\:border-black {
            border-color: black !important;
          }
          
          .print\\:shadow-none {
            box-shadow: none !important;
          }
          
          table {
            page-break-inside: avoid;
          }
          
          .section-container {
            page-break-inside: avoid;
          }
        }
      `}</style>
    </div>
  );
}

// Section Component
function Section({ id, icon: Icon, title, children }) {
  return (
    <section
      id={id}
      className="section-container bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-6 print:bg-white print:border print:border-gray-300"
    >
      <div className="flex items-center gap-3 mb-4 print:mb-3">
        <div className="w-10 h-10 bg-[#B8860B]/20 border border-[#B8860B]/30 rounded-lg flex items-center justify-center print:bg-gray-100 print:border-gray-300">
          <Icon className="w-5 h-5 text-[#B8860B] print:text-gray-700" />
        </div>
        <h2 className="text-2xl font-bold text-white print:text-black">
          {title}
        </h2>
      </div>
      {children}
    </section>
  );
}

// Metric Card Component
function MetricCard({ title, value, description, color = "gold" }) {
  const colorClass = color === "gold" ? "text-[#B8860B]" : "text-[#00D9FF]";

  return (
    <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-4 print:bg-gray-50 print:border-gray-300">
      <div className="text-gray-400 text-xs mb-1 print:text-gray-600">
        {title}
      </div>
      <div className={`text-2xl font-bold ${colorClass} mb-1 print:text-black`}>
        {value}
      </div>
      <div className="text-gray-500 text-xs print:text-gray-600">
        {description}
      </div>
    </div>
  );
}

// Participant Table
function ParticipantTable() {
  const participants = [
    {
      type: "Athlete",
      access: "Full Profile",
      features:
        "Performance tracking, milestone management, earnings dashboard",
    },
    {
      type: "Coach",
      access: "Team Analytics",
      features:
        "Multi-athlete comparison, roster optimization, training insights",
    },
    {
      type: "Sponsor",
      access: "Investment Portal",
      features: "Position management, ROI tracking, hedge strategies",
    },
    {
      type: "Scout",
      access: "Discovery Tools",
      features: "Talent identification, tier analysis, draft equity cards",
    },
    {
      type: "DAO Member",
      access: "Governance",
      features: "Voting rights, treasury oversight, proposal creation",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Participant Type
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Access Level
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Key Features
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {participants.map((p, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {p.type}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] print:text-gray-700">
                {p.access}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {p.features}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Sport Metrics Table
function SportMetricsTable() {
  const sports = [
    {
      sport: "Wrestling",
      metrics: "Takedown efficiency, control time, pin rate, stamina index",
      bimWeight: "Power: 35%, Technique: 40%, Endurance: 25%",
    },
    {
      sport: "Rugby",
      metrics: "Tackle efficiency, gain line success, breakdown dominance",
      bimWeight: "Power: 30%, Tactical: 35%, Endurance: 35%",
    },
    {
      sport: "Basketball",
      metrics: "Court coverage, defensive impact, offensive efficiency",
      bimWeight: "Speed: 25%, Tactical: 40%, Consistency: 35%",
    },
    {
      sport: "Soccer",
      metrics: "Passing accuracy, defensive actions, sprint efficiency",
      bimWeight: "Speed: 30%, Tactical: 35%, Endurance: 35%",
    },
    {
      sport: "Tennis",
      metrics: "Serve velocity, rally endurance, point conversion",
      bimWeight: "Power: 35%, Precision: 40%, Stamina: 25%",
    },
    {
      sport: "American Football",
      metrics: "Route efficiency, separation rate, catch consistency",
      bimWeight: "Power: 30%, Speed: 35%, Consistency: 35%",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Sport
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Key Metrics
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              BIM Weighting
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {sports.map((s, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {s.sport}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {s.metrics}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] text-xs print:text-gray-700">
                {s.bimWeight}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Tier Table
function TierTable() {
  const tiers = [
    {
      tier: "Diamond",
      range: "90-100",
      nilValue: "$250K - $1M+",
      features:
        "Elite performance, national visibility, premium sponsor access",
    },
    {
      tier: "Platinum",
      range: "80-89",
      nilValue: "$100K - $250K",
      features:
        "Consistent excellence, regional recognition, high growth potential",
    },
    {
      tier: "Gold",
      range: "70-79",
      nilValue: "$50K - $100K",
      features: "Strong performance, emerging talent, sponsor-ready metrics",
    },
    {
      tier: "Silver",
      range: "60-69",
      nilValue: "$20K - $50K",
      features: "Developing athlete, trackable improvement, milestone-focused",
    },
    {
      tier: "Bronze",
      range: "50-59",
      nilValue: "$5K - $20K",
      features: "Entry-level athlete, baseline metrics, training emphasis",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Tier
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              BIM Score
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              NIL Valuation
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Key Features
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {tiers.map((t, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3">
                <span className="px-3 py-1 bg-[#B8860B]/20 text-[#B8860B] border border-[#B8860B]/30 rounded-full text-xs font-medium print:bg-gray-200 print:text-black print:border-gray-400">
                  {t.tier}
                </span>
              </td>
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {t.range}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] font-medium print:text-gray-700">
                {t.nilValue}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {t.features}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Security Features
function SecurityFeatures() {
  const features = [
    {
      feature: "Data Encryption",
      description:
        "AES-256 encryption for data at rest, TLS 1.3 for data in transit",
    },
    {
      feature: "Access Control",
      description: "Role-based permissions with multi-factor authentication",
    },
    {
      feature: "Audit Logging",
      description:
        "Comprehensive activity tracking with immutable audit trails",
    },
    {
      feature: "Compliance",
      description: "GDPR, CCPA, and FERPA compliant data handling",
    },
    {
      feature: "API Security",
      description: "OAuth 2.0, rate limiting, and IP whitelisting",
    },
    {
      feature: "Data Backup",
      description: "Automated daily backups with 30-day retention",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 print:grid-cols-2">
      {features.map((f, i) => (
        <div
          key={i}
          className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-4 print:bg-gray-50 print:border-gray-300"
        >
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#B8860B] mt-0.5 flex-shrink-0 print:text-gray-700" />
            <div>
              <div className="text-white font-medium text-sm mb-1 print:text-black">
                {f.feature}
              </div>
              <div className="text-gray-400 text-xs print:text-gray-600">
                {f.description}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// API Endpoints Table
function APIEndpointsTable() {
  const endpoints = [
    {
      endpoint: "POST /api/bim-performance/calculate",
      purpose: "Calculate BIM score from biometric data",
      auth: "API Key",
    },
    {
      endpoint: "GET /api/athletes/list",
      purpose: "Retrieve athlete profiles and performance data",
      auth: "OAuth 2.0",
    },
    {
      endpoint: "POST /api/trades/execute",
      purpose: "Execute performance equity swap",
      auth: "OAuth 2.0",
    },
    {
      endpoint: "GET /api/arbitrage/capture",
      purpose: "Identify arbitrage opportunities",
      auth: "API Key",
    },
    {
      endpoint: "POST /api/milestones/create",
      purpose: "Create performance milestone",
      auth: "OAuth 2.0",
    },
    {
      endpoint: "GET /api/sandbox/events",
      purpose: "Retrieve biometric event stream",
      auth: "Sandbox Key",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Endpoint
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Purpose
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Auth
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {endpoints.map((e, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-[#00D9FF] font-mono text-xs print:text-gray-700">
                {e.endpoint}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {e.purpose}
              </td>
              <td className="px-4 py-3 text-white print:text-black">
                {e.auth}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Milestone Table
function MilestoneTable() {
  const milestones = [
    {
      category: "Performance",
      examples: "Championship win, season MVP, record breaking",
      reward: "10-25% NIL increase",
    },
    {
      category: "Consistency",
      examples: "90+ days injury-free, 95% training attendance",
      reward: "Tier advancement eligibility",
    },
    {
      category: "Growth",
      examples: "20% BIM improvement, skill mastery certification",
      reward: "Sponsor visibility boost",
    },
    {
      category: "Community",
      examples: "100+ fan engagement, social media metrics",
      reward: "Metadata unlock, merchandise rights",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Category
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Examples
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Reward
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {milestones.map((m, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {m.category}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {m.examples}
              </td>
              <td className="px-4 py-3 text-[#B8860B] print:text-gray-700">
                {m.reward}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Rewards Table
function RewardsTable() {
  const rewards = [
    {
      participant: "Athlete",
      trigger: "Milestone completion",
      amount: "60% of pool",
      type: "Direct payment + PT tokens",
    },
    {
      participant: "Coach",
      trigger: "Athlete tier advancement",
      amount: "15% of pool",
      type: "Performance bonus",
    },
    {
      participant: "Contributor",
      trigger: "Pool participation",
      amount: "10% ROI",
      type: "Proportional return",
    },
    {
      participant: "DAO Treasury",
      trigger: "Platform fee",
      amount: "10% of pool",
      type: "Governance funds",
    },
    {
      participant: "Insurance Fund",
      trigger: "Risk mitigation",
      amount: "5% of pool",
      type: "Protection reserve",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Participant
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Trigger
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Amount
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Type
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {rewards.map((r, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {r.participant}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {r.trigger}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] font-medium print:text-gray-700">
                {r.amount}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {r.type}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Trading Features Table
function TradingFeaturesTable() {
  const features = [
    {
      feature: "Real-Time Position Management",
      description:
        "Live tracking of equity positions with automated rebalancing",
      status: "Active",
    },
    {
      feature: "Arbitrage Detection",
      description: "AI-powered identification of mispriced athletes",
      status: "Active",
    },
    {
      feature: "Risk Hedging",
      description: "Injury, underperformance, and volatility hedging options",
      status: "Active",
    },
    {
      feature: "Scalping Signals",
      description: "High-frequency trading signals from biometric spikes",
      status: "Beta",
    },
    {
      feature: "Coalition Indices",
      description: "Multi-sport portfolio optimization and ETF-style products",
      status: "Roadmap",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Feature
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Description
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Status
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {features.map((f, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {f.feature}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {f.description}
              </td>
              <td className="px-4 py-3">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    f.status === "Active"
                      ? "bg-[#B8860B]/20 text-[#B8860B] border border-[#B8860B]/30 print:bg-gray-200 print:text-black print:border-gray-400"
                      : f.status === "Beta"
                        ? "bg-[#00D9FF]/20 text-[#00D9FF] border border-[#00D9FF]/30 print:bg-gray-200 print:text-black print:border-gray-400"
                        : "bg-gray-500/20 text-gray-400 border border-gray-500/30 print:bg-gray-100 print:text-gray-600 print:border-gray-300"
                  }`}
                >
                  {f.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Section Navigation Data
const sections = [
  { id: "overview", title: "System Overview", icon: BarChart3 },
  { id: "account", title: "Account Setup", icon: User },
  { id: "analytics", title: "Analytics", icon: BarChart3 },
  { id: "tiers", title: "Performance Tiers", icon: Trophy },
  { id: "security", title: "Security & Licensing", icon: Shield },
  { id: "api", title: "API Integration", icon: Code },
  { id: "partnerships", title: "Partnerships", icon: Handshake },
  { id: "rewards", title: "Rewards", icon: Trophy },
  { id: "trading", title: "Trading Operations", icon: TrendingUp },
];
