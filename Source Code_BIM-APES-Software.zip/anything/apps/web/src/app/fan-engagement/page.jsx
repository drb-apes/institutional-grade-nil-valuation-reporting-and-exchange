"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function FanEngagementDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("tip");
  const [athletes, setAthletes] = useState([]);
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [ptBalance, setPtBalance] = useState(null);
  const [stakes, setStakes] = useState([]);
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(false);

  // Form states
  const [tipAmount, setTipAmount] = useState("");
  const [boostAmount, setBoostAmount] = useState("");
  const [stakeAmount, setStakeAmount] = useState("");
  const [stakeDuration, setStakeDuration] = useState(30);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (user) {
      loadAthletes();
      loadBalance();
      loadStakes();
    }
  }, [user]);

  const loadAthletes = async () => {
    try {
      const res = await fetch("/api/athletes/list");
      const data = await res.json();
      setAthletes(data.athletes || []);
    } catch (error) {
      console.error("Error loading athletes:", error);
    }
  };

  const loadBalance = async () => {
    try {
      const res = await fetch("/api/wallet");
      const data = await res.json();
      setPtBalance(data.pt_balance);
    } catch (error) {
      console.error("Error loading balance:", error);
    }
  };

  const loadStakes = async () => {
    try {
      const res = await fetch("/api/fan-engagement/stake");
      const data = await res.json();
      setStakes(data.stakes || []);
    } catch (error) {
      console.error("Error loading stakes:", error);
    }
  };

  const handleTip = async () => {
    if (!selectedAthlete || !tipAmount) return;
    setLoading(true);
    try {
      const res = await fetch("/api/fan-engagement/tip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete.id,
          amount: parseFloat(tipAmount),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(
          `Tip sent! ${data.badgeUnlocked ? `Badge unlocked: ${data.badgeUnlocked}` : ""}`,
        );
        setTipAmount("");
        loadBalance();
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
    setLoading(false);
  };

  const handleBoost = async () => {
    if (!selectedAthlete || !boostAmount) return;
    setLoading(true);
    try {
      const res = await fetch("/api/fan-engagement/boost", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete.id,
          amount: parseFloat(boostAmount),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(
          `Boost applied! Multiplier: ${data.metadata_multiplier.toFixed(2)}x`,
        );
        setBoostAmount("");
        loadBalance();
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
    setLoading(false);
  };

  const handleStake = async () => {
    if (!selectedAthlete || !stakeAmount) return;
    setLoading(true);
    try {
      const res = await fetch("/api/fan-engagement/stake", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete.id,
          amount: parseFloat(stakeAmount),
          duration_days: stakeDuration,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(`Stake created! Unlocked: ${data.metadata_tier}`);
        setStakeAmount("");
        loadBalance();
        loadStakes();
      } else {
        setMessage(`Error: ${data.error}`);
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
    setLoading(false);
  };

  if (userLoading || !user)
    return (
      <div className="min-h-screen bg-[#0A0F1E] flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );

  return (
    <div className="min-h-screen bg-[#0A0F1E] text-white">
      {/* Header */}
      <div className="border-b border-[#1E293B] bg-gradient-to-r from-[#0F172A] to-[#1E293B]">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold mb-2">Fan Engagement</h1>
          <p className="text-gray-400">Tip, Boost, Stake, Unlock Metadata</p>

          {/* PT Balance */}
          {ptBalance && (
            <div className="mt-6 inline-flex items-center bg-[#1E293B] px-6 py-3 rounded-lg">
              <span className="text-sm text-gray-400 mr-3">PT Balance:</span>
              <span className="text-2xl font-bold text-[#C4A661]">
                {parseFloat(ptBalance.available_balance || 0).toFixed(2)}
              </span>
              <span className="text-sm text-gray-400 ml-3">
                Staked: {parseFloat(ptBalance.staked_balance || 0).toFixed(2)}
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Actions */}
          <div className="lg:col-span-2">
            {/* Tabs */}
            <div className="flex gap-2 mb-6">
              {["tip", "boost", "stake"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-3 rounded-lg font-medium transition-all ${
                    activeTab === tab
                      ? "bg-[#C4A661] text-black"
                      : "bg-[#1E293B] text-gray-400 hover:bg-[#2D3B52]"
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>

            {/* Action Cards */}
            <div className="bg-[#1E293B] rounded-xl p-6">
              {/* Athlete Selector */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Select Athlete
                </label>
                <select
                  value={selectedAthlete?.id || ""}
                  onChange={(e) =>
                    setSelectedAthlete(
                      athletes.find((a) => a.id === parseInt(e.target.value)),
                    )
                  }
                  className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                >
                  <option value="">Choose an athlete...</option>
                  {athletes.map((athlete) => (
                    <option key={athlete.id} value={athlete.id}>
                      {athlete.name || `Athlete ${athlete.id}`}
                    </option>
                  ))}
                </select>
              </div>

              {selectedAthlete && (
                <>
                  {activeTab === "tip" && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">
                          PT Token Amount
                        </label>
                        <input
                          type="number"
                          value={tipAmount}
                          onChange={(e) => setTipAmount(e.target.value)}
                          placeholder="Enter amount..."
                          className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                        />
                      </div>
                      <button
                        onClick={handleTip}
                        disabled={loading}
                        className="w-full bg-[#C4A661] text-black font-bold py-3 rounded-lg hover:bg-[#D4B671] transition-all disabled:opacity-50"
                      >
                        {loading ? "Processing..." : "Send Tip"}
                      </button>
                      <p className="text-sm text-gray-400">
                        ✨ Engagement weight: 1 per PT token
                      </p>
                    </div>
                  )}

                  {activeTab === "boost" && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">
                          PT Token Amount (min 10)
                        </label>
                        <input
                          type="number"
                          value={boostAmount}
                          onChange={(e) => setBoostAmount(e.target.value)}
                          placeholder="Enter amount..."
                          className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                        />
                      </div>
                      <button
                        onClick={handleBoost}
                        disabled={loading}
                        className="w-full bg-[#8B5CF6] text-white font-bold py-3 rounded-lg hover:bg-[#9B6CF6] transition-all disabled:opacity-50"
                      >
                        {loading ? "Processing..." : "Apply Boost"}
                      </button>
                      <p className="text-sm text-gray-400">
                        🚀 Multiplier: 1.5x per 10 PT | Engagement weight: 3x
                        tips
                      </p>
                    </div>
                  )}

                  {activeTab === "stake" && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">
                          PT Token Amount
                        </label>
                        <input
                          type="number"
                          value={stakeAmount}
                          onChange={(e) => setStakeAmount(e.target.value)}
                          placeholder="Enter amount..."
                          className="w-full bg-[#0F172A] border border-[#334155] rounded-lg px-4 py-3 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">
                          Duration: {stakeDuration} days
                        </label>
                        <input
                          type="range"
                          min="30"
                          max="365"
                          step="30"
                          value={stakeDuration}
                          onChange={(e) =>
                            setStakeDuration(parseInt(e.target.value))
                          }
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                          <span>30d</span>
                          <span>90d</span>
                          <span>180d</span>
                          <span>365d</span>
                        </div>
                      </div>
                      <button
                        onClick={handleStake}
                        disabled={loading}
                        className="w-full bg-[#EF4444] text-white font-bold py-3 rounded-lg hover:bg-[#F55454] transition-all disabled:opacity-50"
                      >
                        {loading ? "Processing..." : "Create Stake"}
                      </button>
                      <p className="text-sm text-gray-400">
                        🔒 Metadata tier unlocks: 50 PT → Tier 1 | 200 PT → Tier
                        2 | 500 PT → Tier 3 | 1000 PT → Vault
                      </p>
                    </div>
                  )}
                </>
              )}
            </div>

            {message && (
              <div className="mt-4 bg-[#1E293B] border border-[#C4A661] rounded-lg p-4 text-center">
                {message}
              </div>
            )}
          </div>

          {/* Right Column: Stats & Active Stakes */}
          <div className="space-y-6">
            {/* Active Stakes */}
            <div className="bg-[#1E293B] rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Active Stakes</h3>
              {stakes.length === 0 ? (
                <p className="text-gray-400 text-sm">No active stakes</p>
              ) : (
                <div className="space-y-3">
                  {stakes.map((stake) => (
                    <div key={stake.id} className="bg-[#0F172A] rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">
                          {stake.athlete_name || "Athlete"}
                        </span>
                        <span className="text-[#C4A661] font-bold">
                          {parseFloat(stake.pt_amount).toFixed(0)} PT
                        </span>
                      </div>
                      <div className="text-sm text-gray-400">
                        <div>Tier: {stake.metadata_tier_unlocked}</div>
                        <div>
                          Multiplier:{" "}
                          {parseFloat(stake.engagement_multiplier).toFixed(2)}x
                        </div>
                        <div>
                          Expires:{" "}
                          {new Date(stake.expires_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Engagement Tiers */}
            <div className="bg-[#1E293B] rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Engagement Tiers</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Observer</span>
                  <span>1.0x</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#3B82F6]">Supporter</span>
                  <span>1.2x</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8B5CF6]">Advocate</span>
                  <span>1.5x</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#C4A661]">Champion</span>
                  <span>2.0x</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#EF4444]">Elite</span>
                  <span>3.0x</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
