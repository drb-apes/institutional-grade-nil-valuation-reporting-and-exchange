"use client";

import { useState, useEffect } from "react";
import {
  Star,
  TrendingUp,
  Users,
  Zap,
  Target,
  Sparkles,
  Award,
  TrendingDown,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function RisingStarDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [talentData, setTalentData] = useState(null);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoadingData(true);

      const mockData = {
        summary: {
          totalTalent: 28,
          avgPMI: 0.85,
          avgEGI: 0.91,
          avgBFI: 0.82,
        },
        talent: [],
      };

      setTalentData(mockData);
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-black to-purple-900 flex items-center justify-center">
        <div className="text-center">
          <Star className="w-16 h-16 text-blue-400 mx-auto mb-4" />
          <p className="text-white text-xl mt-4">
            Loading Rising-Star Talent Advisory...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-black to-purple-900">
      {/* Header */}
      <header className="border-b border-blue-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-blue-500 to-purple-500 p-3 rounded-xl">
                <Star className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Rising-Star Talent NIL Advisory
                </h1>
                <p className="text-blue-300 text-sm">
                  Portfolio Momentum · Engagement Growth · Development
                  Intelligence
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-blue-300">Logged in as</p>
                <p className="text-white font-semibold">
                  {user?.name || user?.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="border-b border-blue-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "overview", label: "Overview", icon: Star },
              { id: "talent", label: "Talent Portfolio", icon: Users },
              { id: "performance", label: "Performance Units", icon: Zap },
              { id: "indices", label: "Growth Indices", icon: TrendingUp },
              { id: "development", label: "Development Path", icon: Target },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-blue-400 text-blue-400"
                    : "border-transparent text-blue-300 hover:text-blue-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && <OverviewTab talentData={talentData} />}
        {activeTab === "talent" && <TalentPortfolioTab />}
        {activeTab === "performance" && <PerformanceUnitsTab />}
        {activeTab === "indices" && <GrowthIndicesTab />}
        {activeTab === "development" && <DevelopmentPathTab />}
      </div>
    </div>
  );
}

function OverviewTab({ talentData }) {
  const metrics = talentData?.summary || {
    totalTalent: 28,
    avgPMI: 0.85,
    avgEGI: 0.91,
    avgBFI: 0.82,
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Rising Stars"
          value={metrics.totalTalent}
          icon={Users}
          trend="+8 this quarter"
          color="blue"
        />
        <MetricCard
          title="Avg PMI (Portfolio Momentum)"
          value={(metrics.avgPMI * 100).toFixed(1)}
          icon={Zap}
          trend="+7.2% vs last quarter"
          color="purple"
        />
        <MetricCard
          title="Avg EGI (Engagement Growth)"
          value={(metrics.avgEGI * 100).toFixed(1)}
          icon={TrendingUp}
          trend="+9.4% vs last quarter"
          color="green"
        />
        <MetricCard
          title="Avg BFI (Brand Fit)"
          value={(metrics.avgBFI * 100).toFixed(1)}
          icon={Target}
          trend="+5.1% vs last quarter"
          color="pink"
        />
      </div>

      {/* Performance Units Dashboard */}
      <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6">
          Performance Unit Breakdown
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <PerformanceUnitCard
            title="Portfolio Versatility Units (PVU)"
            value="2,184"
            efficiency="92.3%"
            color="blue"
          />
          <PerformanceUnitCard
            title="On-Camera Adaptability Units (OAU)"
            value="1,567"
            efficiency="88.9%"
            color="purple"
          />
          <PerformanceUnitCard
            title="Brand Alignment Units (BAU)"
            value="1,892"
            efficiency="85.7%"
            color="pink"
          />
          <PerformanceUnitCard
            title="Engagement Momentum Units (EMU)"
            value="3,421"
            efficiency="94.1%"
            color="green"
          />
          <PerformanceUnitCard
            title="Social Growth Units (SGU)"
            value="2,789"
            efficiency="91.5%"
            color="yellow"
          />
          <PerformanceUnitCard
            title="Content Quality Units (CQU)"
            value="1,645"
            efficiency="89.2%"
            color="red"
          />
        </div>
      </div>

      {/* Recent Development Milestones */}
      <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Recent Development Milestones
        </h2>
        <div className="space-y-3">
          {[
            {
              talent: "Talent A",
              milestone: "Agency Signing",
              pmi: 0.92,
              egi: 0.95,
              category: "TikTok Fashion",
              date: "2 days ago",
            },
            {
              talent: "Talent B",
              milestone: "Brand Partnership",
              pmi: 0.88,
              egi: 0.91,
              category: "Instagram Beauty",
              date: "4 days ago",
            },
            {
              talent: "Talent C",
              milestone: "Portfolio Launch",
              pmi: 0.85,
              egi: 0.87,
              category: "YouTube Content",
              date: "1 week ago",
            },
          ].map((milestone, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-4 bg-blue-900/20 rounded-lg border border-blue-500/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                  <Star className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">{milestone.talent}</p>
                  <p className="text-sm text-blue-300">
                    {milestone.milestone} · {milestone.category}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold">
                  PMI {(milestone.pmi * 100).toFixed(0)}
                </p>
                <p className="text-sm text-blue-300">
                  EGI {(milestone.egi * 100).toFixed(0)} · {milestone.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Growth Trajectory Analysis */}
      <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Growth Trajectory Intelligence
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <BiometricCard
            title="Momentum Acceleration"
            value="94.2%"
            trend="+8.3%"
          />
          <BiometricCard
            title="Market Penetration"
            value="87.5%"
            trend="+6.1%"
          />
          <BiometricCard title="Brand Readiness" value="91.8%" trend="+5.7%" />
        </div>
      </div>

      {/* Agency Benchmarks */}
      <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Talent Development Agency Benchmarks
        </h2>
        <div className="space-y-3">
          {[
            {
              agency: "TikTok Talent Hub",
              avgPMI: 0.89,
              talentCount: 18,
              trend: "+7.8%",
            },
            {
              agency: "Instagram Fashion Collective",
              avgPMI: 0.86,
              talentCount: 14,
              trend: "+6.2%",
            },
            {
              agency: "YouTube Beauty Network",
              avgPMI: 0.84,
              talentCount: 12,
              trend: "+5.9%",
            },
          ].map((agency, i) => (
            <div
              key={i}
              className="p-4 bg-blue-900/20 rounded-lg border border-blue-500/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold">{agency.agency}</p>
                  <p className="text-sm text-blue-300">
                    {agency.talentCount} rising stars tracked
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-white">
                    {(agency.avgPMI * 100).toFixed(1)}
                  </p>
                  <p className="text-sm text-green-400">{agency.trend}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TalentPortfolioTab() {
  const talent = [
    {
      name: "Talent A",
      category: "TikTok Fashion",
      pmi: 0.92,
      egi: 0.95,
      nilValue: 95000,
    },
    {
      name: "Talent B",
      category: "Instagram Beauty",
      pmi: 0.88,
      egi: 0.91,
      nilValue: 82000,
    },
    {
      name: "Talent C",
      category: "YouTube Content",
      pmi: 0.85,
      egi: 0.87,
      nilValue: 73000,
    },
    {
      name: "Talent D",
      category: "Multi-Platform Influencer",
      pmi: 0.9,
      egi: 0.93,
      nilValue: 88000,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">
          Rising-Star Talent Portfolio
        </h2>
        <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
          Add Rising Star
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {talent.map((person, i) => (
          <TalentCard key={i} talent={person} />
        ))}
      </div>
    </div>
  );
}

function PerformanceUnitsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Performance Unit Analytics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Portfolio Versatility Units (PVU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Total PVUs Captured</span>
              <span className="text-white font-bold">2,184</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Content Diversity Score</span>
              <span className="text-green-400 font-bold">92.3%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Platform Versatility</span>
              <span className="text-white font-bold">9.2 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            On-Camera Adaptability Units (OAU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Total OAUs Captured</span>
              <span className="text-white font-bold">1,567</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Adaptability Score</span>
              <span className="text-green-400 font-bold">88.9%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Style Flexibility</span>
              <span className="text-white font-bold">8.9 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Brand Alignment Units (BAU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Total BAUs Tracked</span>
              <span className="text-white font-bold">1,892</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Brand Fit Quality</span>
              <span className="text-green-400 font-bold">85.7%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Partnership Potential</span>
              <span className="text-white font-bold">8.6 / 10</span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Engagement Momentum Units (EMU)
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Total EMUs Captured</span>
              <span className="text-white font-bold">3,421</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Growth Velocity</span>
              <span className="text-green-400 font-bold">94.1%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-blue-300">Momentum Sustainability</span>
              <span className="text-white font-bold">9.4 / 10</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function GrowthIndicesTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Rising-Star Growth Indices
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Core Indices</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Portfolio Momentum Index (PMI)"
            value="85.3"
            trend="+7.2"
          />
          <IndexCard
            title="Engagement Growth Index (EGI)"
            value="91.4"
            trend="+9.4"
          />
          <IndexCard title="Brand Fit Index (BFI)" value="82.6" trend="+5.1" />
        </div>
      </div>

      <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Advanced Indices
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            title="Market Penetration Index (MPI)"
            value="87.9"
            trend="+6.8"
          />
          <IndexCard title="Content Quality Index" value="89.5" trend="+4.3" />
          <IndexCard title="Social Velocity Index" value="93.2" trend="+8.1" />
        </div>
      </div>
    </div>
  );
}

function DevelopmentPathTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Talent Development Pathways
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Next Milestone Targets
          </h3>
          <div className="space-y-3">
            {[
              { target: "Reach 100K Followers", progress: 0.78, daysLeft: 24 },
              {
                target: "Secure First Brand Deal",
                progress: 0.85,
                daysLeft: 18,
              },
              {
                target: "Launch Portfolio Website",
                progress: 0.92,
                daysLeft: 8,
              },
            ].map((item, i) => (
              <div key={i} className="p-3 bg-blue-900/20 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-white font-semibold">{item.target}</p>
                  <span className="text-sm text-blue-300">
                    {item.daysLeft} days
                  </span>
                </div>
                <div className="w-full bg-blue-900/30 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${item.progress * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Development Recommendations
          </h3>
          <div className="space-y-3">
            {[
              {
                recommendation: "Increase posting frequency to 5x/week",
                priority: "High",
              },
              {
                recommendation: "Diversify content across platforms",
                priority: "Medium",
              },
              {
                recommendation: "Engage with brand collaboration offers",
                priority: "High",
              },
              {
                recommendation: "Build professional portfolio assets",
                priority: "Medium",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="p-3 bg-blue-900/20 rounded-lg border border-blue-500/20"
              >
                <div className="flex items-center justify-between">
                  <p className="text-white">{item.recommendation}</p>
                  <span
                    className={`px-2 py-1 rounded text-xs font-semibold ${
                      item.priority === "High"
                        ? "bg-blue-500/20 text-blue-300"
                        : "bg-purple-500/20 text-purple-300"
                    }`}
                  >
                    {item.priority}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color }) {
  const colorClasses = {
    blue: "from-blue-500 to-blue-600",
    purple: "from-purple-500 to-purple-600",
    green: "from-green-500 to-green-600",
    pink: "from-pink-500 to-pink-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-blue-300 uppercase">{title}</p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function PerformanceUnitCard({ title, value, efficiency, color }) {
  return (
    <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
      <p className="text-sm text-blue-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{efficiency} efficiency</p>
    </div>
  );
}

function BiometricCard({ title, value, trend }) {
  return (
    <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
      <p className="text-sm text-blue-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function TalentCard({ talent }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-blue-500/30 rounded-xl p-6 hover:border-blue-400 transition-all cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
          <Star className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-lg">{talent.name}</p>
          <p className="text-sm text-blue-300">{talent.category}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-blue-300">
            Portfolio Momentum (PMI)
          </span>
          <span className="text-white font-bold">
            {(talent.pmi * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-blue-300">Engagement Growth (EGI)</span>
          <span className="text-white font-bold">
            {(talent.egi * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-blue-300">NIL Value</span>
          <span className="text-white font-bold">
            ${(talent.nilValue / 1000).toFixed(0)}K
          </span>
        </div>
      </div>
    </div>
  );
}

function IndexCard({ title, value, trend }) {
  return (
    <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
      <p className="text-sm text-blue-300 mb-2">{title}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm text-green-400">+{trend}</p>
      </div>
    </div>
  );
}
