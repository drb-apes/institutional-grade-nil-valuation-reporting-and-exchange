"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function WearableMeshArchitecture() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [deviceTypes, setDeviceTypes] = useState([]);
  const [schemaMappings, setSchemaMappings] = useState([]);
  const [meshTopology, setMeshTopology] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadArchitectureData();
    }
  }, [user]);

  const loadArchitectureData = async () => {
    setLoading(true);
    try {
      const [devicesRes, mappingsRes, topologyRes] = await Promise.all([
        fetch("/api/wearable-mesh/device-types"),
        fetch("/api/wearable-mesh/schema-mappings"),
        fetch("/api/wearable-mesh/topology"),
      ]);

      if (devicesRes.ok) {
        const data = await devicesRes.json();
        setDeviceTypes(data.deviceTypes || []);
      }
      if (mappingsRes.ok) {
        const data = await mappingsRes.json();
        setSchemaMappings(data.mappings || []);
      }
      if (topologyRes.ok) {
        const data = await topologyRes.json();
        setMeshTopology(data.topology || []);
      }
    } catch (error) {
      console.error("Failed to load architecture data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#0A0E27] flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0E27] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-white text-2xl mb-4">Authentication Required</h2>
          <a href="/account/signin" className="text-[#00D9FF] hover:underline">
            Sign in to continue
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0E27]">
      {/* Header */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-2">
            <svg
              className="w-10 h-10 text-[#00D9FF]"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"
              />
            </svg>
            <div>
              <h1 className="text-3xl font-bold text-white">
                Plug & Play Wearable Mesh Architecture
              </h1>
              <p className="text-gray-400">
                BIM-APES Universal Schema System — Any Device, Any Sport
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-6 overflow-x-auto">
            <TabButton
              active={activeTab === "overview"}
              onClick={() => setActiveTab("overview")}
              icon={
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"
                  />
                </svg>
              }
            >
              System Overview
            </TabButton>
            <TabButton
              active={activeTab === "devices"}
              onClick={() => setActiveTab("devices")}
              icon={
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
                  />
                </svg>
              }
            >
              Device Registry
            </TabButton>
            <TabButton
              active={activeTab === "schema"}
              onClick={() => setActiveTab("schema")}
              icon={
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              }
            >
              BIM Schema Mappings
            </TabButton>
            <TabButton
              active={activeTab === "mesh"}
              onClick={() => setActiveTab("mesh")}
              icon={
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z"
                  />
                </svg>
              }
            >
              Mesh Network
            </TabButton>
            <TabButton
              active={activeTab === "dataflow"}
              onClick={() => setActiveTab("dataflow")}
              icon={
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              }
            >
              Data Flow
            </TabButton>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === "overview" && <OverviewTab />}
        {activeTab === "devices" && (
          <DeviceRegistryTab deviceTypes={deviceTypes} loading={loading} />
        )}
        {activeTab === "schema" && (
          <SchemaMappingsTab mappings={schemaMappings} loading={loading} />
        )}
        {activeTab === "mesh" && (
          <MeshNetworkTab topology={meshTopology} loading={loading} />
        )}
        {activeTab === "dataflow" && <DataFlowTab />}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, icon, children }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-3 font-medium transition-colors whitespace-nowrap ${
        active
          ? "text-[#00D9FF] border-b-2 border-[#00D9FF]"
          : "text-gray-400 hover:text-white"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}

function OverviewTab() {
  return (
    <div className="space-y-6">
      {/* Architecture Diagram */}
      <div className="bg-[#1A1F3A] rounded-lg p-8 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-6">
          Plug & Play Architecture
        </h2>

        <div className="space-y-6">
          {/* Step 1: Device */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0">
              1
            </div>
            <div className="flex-1 bg-[#0A0E27] rounded-lg p-4 border border-gray-700">
              <h3 className="text-lg font-bold text-white mb-2">
                Device Layer
              </h3>
              <p className="text-sm text-gray-400">
                Any wearable device (HR monitor, GPS tracker, IMU sensor, force
                plate, smartwatch, etc.)
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="text-xs bg-[#00D9FF]/10 text-[#00D9FF] px-3 py-1 rounded-full border border-[#00D9FF]/30">
                  Bluetooth LE
                </span>
                <span className="text-xs bg-[#00D9FF]/10 text-[#00D9FF] px-3 py-1 rounded-full border border-[#00D9FF]/30">
                  ANT+
                </span>
                <span className="text-xs bg-[#00D9FF]/10 text-[#00D9FF] px-3 py-1 rounded-full border border-[#00D9FF]/30">
                  WiFi
                </span>
                <span className="text-xs bg-[#00D9FF]/10 text-[#00D9FF] px-3 py-1 rounded-full border border-[#00D9FF]/30">
                  NFC
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <svg
              className="w-6 h-6 text-[#00D9FF]"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 3a1 1 0 011 1v10.586l2.293-2.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V4a1 1 0 011-1z"
                clipRule="evenodd"
              />
            </svg>
          </div>

          {/* Step 2: Mesh Network */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0">
              2
            </div>
            <div className="flex-1 bg-[#0A0E27] rounded-lg p-4 border border-gray-700">
              <h3 className="text-lg font-bold text-white mb-2">
                Mesh Network
              </h3>
              <p className="text-sm text-gray-400">
                Offline-first peer-to-peer mesh syncs data across devices
                without internet
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="text-xs bg-green-500/10 text-green-400 px-3 py-1 rounded-full border border-green-500/30">
                  Multi-hop routing
                </span>
                <span className="text-xs bg-green-500/10 text-green-400 px-3 py-1 rounded-full border border-green-500/30">
                  Offline sync
                </span>
                <span className="text-xs bg-green-500/10 text-green-400 px-3 py-1 rounded-full border border-green-500/30">
                  Auto-discovery
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <svg
              className="w-6 h-6 text-[#00D9FF]"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 3a1 1 0 011 1v10.586l2.293-2.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V4a1 1 0 011-1z"
                clipRule="evenodd"
              />
            </svg>
          </div>

          {/* Step 3: BIM Schema */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#C4A661] flex items-center justify-center text-black font-bold flex-shrink-0">
              3
            </div>
            <div className="flex-1 bg-[#0A0E27] rounded-lg p-4 border border-[#C4A661]/30">
              <h3 className="text-lg font-bold text-white mb-2">
                BIM-APES Schema Transformation
              </h3>
              <p className="text-sm text-gray-400">
                Raw device data → Universal BIM metrics (sport-aware
                transformation)
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="text-xs bg-[#C4A661]/10 text-[#C4A661] px-3 py-1 rounded-full border border-[#C4A661]/30">
                  Direct mapping
                </span>
                <span className="text-xs bg-[#C4A661]/10 text-[#C4A661] px-3 py-1 rounded-full border border-[#C4A661]/30">
                  Unit conversion
                </span>
                <span className="text-xs bg-[#C4A661]/10 text-[#C4A661] px-3 py-1 rounded-full border border-[#C4A661]/30">
                  Aggregation
                </span>
                <span className="text-xs bg-[#C4A661]/10 text-[#C4A661] px-3 py-1 rounded-full border border-[#C4A661]/30">
                  Normalization
                </span>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <svg
              className="w-6 h-6 text-[#00D9FF]"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 3a1 1 0 011 1v10.586l2.293-2.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V4a1 1 0 011-1z"
                clipRule="evenodd"
              />
            </svg>
          </div>

          {/* Step 4: Analytics */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold flex-shrink-0">
              4
            </div>
            <div className="flex-1 bg-[#0A0E27] rounded-lg p-4 border border-purple-500/30">
              <h3 className="text-lg font-bold text-white mb-2">
                Universal Analytics Engine
              </h3>
              <p className="text-sm text-gray-400">
                BIM metrics → PPI/TPI/LPI indices (works across all sports)
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="text-xs bg-purple-500/10 text-purple-400 px-3 py-1 rounded-full border border-purple-500/30">
                  PPI calculation
                </span>
                <span className="text-xs bg-purple-500/10 text-purple-400 px-3 py-1 rounded-full border border-purple-500/30">
                  Forecasting
                </span>
                <span className="text-xs bg-purple-500/10 text-purple-400 px-3 py-1 rounded-full border border-purple-500/30">
                  Risk assessment
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Benefits */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <div className="w-12 h-12 rounded-full bg-[#00D9FF]/20 flex items-center justify-center mb-4">
            <svg
              className="w-6 h-6 text-[#00D9FF]"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4a2 2 0 00-2-2H6zm1 2a1 1 0 000 2h6a1 1 0 100-2H7zm6 7a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1zm-3 3a1 1 0 100 2h.01a1 1 0 100-2H10zm-4 1a1 1 0 011-1h.01a1 1 0 110 2H7a1 1 0 01-1-1zm1-4a1 1 0 100 2h.01a1 1 0 100-2H7zm2 1a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1zm4-4a1 1 0 100 2h.01a1 1 0 100-2H13zM9 9a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1zM7 8a1 1 0 000 2h.01a1 1 0 000-2H7z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Device Agnostic</h3>
          <p className="text-sm text-gray-400">
            Support for 50+ wearable types across all major protocols
            (Bluetooth, ANT+, WiFi, NFC)
          </p>
        </div>

        <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
            <svg
              className="w-6 h-6 text-green-400"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
            </svg>
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Offline-First</h3>
          <p className="text-sm text-gray-400">
            Mesh networking enables data collection in remote locations without
            internet connectivity
          </p>
        </div>

        <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <div className="w-12 h-12 rounded-full bg-[#C4A661]/20 flex items-center justify-center mb-4">
            <svg
              className="w-6 h-6 text-[#C4A661]"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <h3 className="text-lg font-bold text-white mb-2">
            Auto-Transformation
          </h3>
          <p className="text-sm text-gray-400">
            Schema mappings automatically convert device-specific data into
            universal BIM metrics
          </p>
        </div>
      </div>
    </div>
  );
}

function DeviceRegistryTab({ deviceTypes, loading }) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-white">Loading device registry...</div>
      </div>
    );
  }

  // Sample device types if none loaded
  const devices =
    deviceTypes.length > 0
      ? deviceTypes
      : [
          {
            id: 1,
            device_type_id: "polar_h10",
            manufacturer: "Polar",
            device_model: "H10",
            device_category: "heart_rate_monitor",
            connection_protocol: "bluetooth_le",
            sampling_rate_hz: 1,
            battery_life_hours: 400,
            supported_sports: [
              "wrestling",
              "basketball",
              "soccer",
              "track_field",
            ],
            certification_status: "certified",
          },
          {
            id: 2,
            device_type_id: "garmin_hrm_pro",
            manufacturer: "Garmin",
            device_model: "HRM-Pro",
            device_category: "heart_rate_monitor",
            connection_protocol: "ant_plus",
            sampling_rate_hz: 1,
            battery_life_hours: 365,
            supported_sports: [
              "american_football",
              "rugby",
              "soccer",
              "track_field",
            ],
            certification_status: "certified",
          },
          {
            id: 3,
            device_type_id: "whoop_4_0",
            manufacturer: "WHOOP",
            device_model: "4.0",
            device_category: "biometric_band",
            connection_protocol: "bluetooth_le",
            sampling_rate_hz: 100,
            battery_life_hours: 120,
            supported_sports: ["all_sports"],
            certification_status: "certified",
          },
          {
            id: 4,
            device_type_id: "catapult_vector",
            manufacturer: "Catapult",
            device_model: "Vector",
            device_category: "imu_sensor",
            connection_protocol: "proprietary_mesh",
            sampling_rate_hz: 100,
            battery_life_hours: 8,
            supported_sports: ["american_football", "rugby", "soccer"],
            certification_status: "certified",
          },
        ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">
          Certified Device Registry
        </h2>
        <button className="bg-[#00D9FF] text-black px-4 py-2 rounded-lg font-semibold hover:bg-[#00B8DB] transition-colors">
          + Register New Device
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {devices.map((device) => (
          <div
            key={device.id}
            className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-white mb-1">
                  {device.manufacturer} {device.device_model}
                </h3>
                <p className="text-sm text-gray-400">
                  ID: {device.device_type_id}
                </p>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  device.certification_status === "certified"
                    ? "bg-green-500/20 text-green-400 border border-green-500/30"
                    : "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                }`}
              >
                {device.certification_status}
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div>
                <div className="text-xs text-gray-500 mb-1">Category</div>
                <div className="text-sm text-white font-medium capitalize">
                  {device.device_category.replace(/_/g, " ")}
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Protocol</div>
                <div className="text-sm text-white font-medium capitalize">
                  {device.connection_protocol.replace(/_/g, " ")}
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Sampling Rate</div>
                <div className="text-sm text-white font-medium">
                  {device.sampling_rate_hz} Hz
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Battery Life</div>
                <div className="text-sm text-white font-medium">
                  {device.battery_life_hours}h
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs text-gray-500 mb-2">Supported Sports</div>
              <div className="flex flex-wrap gap-2">
                {device.supported_sports.map((sport) => (
                  <span
                    key={sport}
                    className="text-xs bg-[#00D9FF]/10 text-[#00D9FF] px-3 py-1 rounded-full border border-[#00D9FF]/30"
                  >
                    {sport === "all_sports"
                      ? "All Sports"
                      : sport.replace(/_/g, " ")}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SchemaMappingsTab({ mappings, loading }) {
  const [selectedSport, setSelectedSport] = useState("wrestling");

  // Sample schema mappings for demonstration
  const sampleMappings = {
    wrestling: [
      {
        raw_field: "heart_rate_bpm",
        bim_metric: "cardiovascular_intensity",
        transformation: "direct_map",
        description: "Maps HR directly to intensity metric",
      },
      {
        raw_field: "accelerometer_xyz",
        bim_metric: "explosive_power",
        transformation: "derived_calculation",
        description:
          "Calculates explosive power from 3-axis acceleration vectors",
      },
      {
        raw_field: "gps_speed_mps",
        bim_metric: "agility_score",
        transformation: "unit_conversion",
        description:
          "Converts m/s to agility score with sport-specific thresholds",
      },
      {
        raw_field: "contact_time_ms",
        bim_metric: "takedown_efficiency",
        transformation: "aggregation",
        description:
          "Aggregates contact events into takedown efficiency metric",
      },
    ],
    basketball: [
      {
        raw_field: "vertical_jump_cm",
        bim_metric: "explosive_power",
        transformation: "normalization",
        description: "Normalizes jump height to 0-100 explosive power scale",
      },
      {
        raw_field: "sprint_speed_kmh",
        bim_metric: "burst_speed",
        transformation: "unit_conversion",
        description: "Converts km/h to burst speed metric",
      },
      {
        raw_field: "change_of_direction_count",
        bim_metric: "agility_score",
        transformation: "aggregation",
        description: "Counts directional changes per minute",
      },
    ],
  };

  const currentMappings =
    sampleMappings[selectedSport] || sampleMappings.wrestling;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">
          BIM-APES Schema Mappings
        </h2>
        <p className="text-gray-400 mb-6">
          These mappings define how raw device data transforms into universal
          BIM metrics for each sport.
        </p>
      </div>

      {/* Sport Selector */}
      <div className="flex gap-3 flex-wrap">
        {[
          "wrestling",
          "basketball",
          "tennis",
          "american_football",
          "soccer",
        ].map((sport) => (
          <button
            key={sport}
            onClick={() => setSelectedSport(sport)}
            className={`px-4 py-2 rounded-lg font-medium transition-colors capitalize ${
              selectedSport === sport
                ? "bg-[#C4A661] text-black"
                : "bg-[#1A1F3A] text-gray-400 border border-gray-700 hover:border-[#C4A661]"
            }`}
          >
            {sport.replace(/_/g, " ")}
          </button>
        ))}
      </div>

      {/* Transformation Pipeline */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-6 capitalize">
          {selectedSport.replace(/_/g, " ")} — Schema Transformation Pipeline
        </h3>

        <div className="space-y-4">
          {currentMappings.map((mapping, index) => (
            <div
              key={index}
              className="bg-[#0A0E27] rounded-lg p-4 border border-gray-700"
            >
              <div className="flex items-center gap-4 mb-3">
                <div className="flex-1">
                  <div className="text-sm text-gray-500 mb-1">
                    Raw Device Field
                  </div>
                  <div className="text-white font-mono">
                    {mapping.raw_field}
                  </div>
                </div>

                <div className="flex-shrink-0">
                  <svg
                    className="w-8 h-8 text-[#C4A661]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 7l5 5m0 0l-5 5m5-5H6"
                    />
                  </svg>
                </div>

                <div className="flex-1">
                  <div className="text-sm text-gray-500 mb-1">BIM Metric</div>
                  <div className="text-[#00D9FF] font-semibold">
                    {mapping.bim_metric}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 mb-2">
                <span className="text-xs bg-[#C4A661]/10 text-[#C4A661] px-3 py-1 rounded-full border border-[#C4A661]/30 font-medium">
                  {mapping.transformation.replace(/_/g, " ")}
                </span>
              </div>

              <p className="text-sm text-gray-400">{mapping.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Transformation Types Reference */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-bold text-white mb-4">
          Transformation Types
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#0A0E27] rounded p-3 border border-gray-700">
            <div className="text-sm font-semibold text-[#C4A661] mb-1">
              Direct Map
            </div>
            <p className="text-xs text-gray-400">
              1:1 mapping with no transformation
            </p>
          </div>
          <div className="bg-[#0A0E27] rounded p-3 border border-gray-700">
            <div className="text-sm font-semibold text-[#C4A661] mb-1">
              Unit Conversion
            </div>
            <p className="text-xs text-gray-400">
              Convert units (mph → m/s, lb → kg, etc.)
            </p>
          </div>
          <div className="bg-[#0A0E27] rounded p-3 border border-gray-700">
            <div className="text-sm font-semibold text-[#C4A661] mb-1">
              Aggregation
            </div>
            <p className="text-xs text-gray-400">
              Combine multiple readings (sum, avg, max)
            </p>
          </div>
          <div className="bg-[#0A0E27] rounded p-3 border border-gray-700">
            <div className="text-sm font-semibold text-[#C4A661] mb-1">
              Derived Calculation
            </div>
            <p className="text-xs text-gray-400">
              Complex math from multiple inputs
            </p>
          </div>
          <div className="bg-[#0A0E27] rounded p-3 border border-gray-700">
            <div className="text-sm font-semibold text-[#C4A661] mb-1">
              Normalization
            </div>
            <p className="text-xs text-gray-400">
              Scale to standard range (0-100)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MeshNetworkTab({ topology, loading }) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-2">
          Mesh Network Topology
        </h2>
        <p className="text-gray-400 mb-6">
          Peer-to-peer device mesh enables offline data collection and sync
          across multiple devices.
        </p>
      </div>

      {/* Network Visualization */}
      <div className="bg-[#1A1F3A] rounded-lg p-8 border border-gray-700">
        <h3 className="text-lg font-bold text-white mb-6">
          Active Mesh Sessions
        </h3>

        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <svg
              className="w-24 h-24 text-gray-600 mx-auto mb-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z"
              />
            </svg>
            <p className="text-gray-400 mb-2">No active mesh sessions</p>
            <p className="text-sm text-gray-500">
              Start a training session from the mobile app to see live mesh
              topology
            </p>
          </div>
        </div>
      </div>

      {/* Mesh Capabilities */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-bold text-white mb-3">
            Multi-Hop Routing
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Devices relay data through intermediate nodes to extend network
            range beyond Bluetooth limits
          </p>
          <div className="text-xs text-[#00D9FF]">
            Range: up to 300m (5 hops)
          </div>
        </div>

        <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-bold text-white mb-3">Auto-Discovery</h3>
          <p className="text-sm text-gray-400 mb-4">
            New devices automatically join the mesh when in range, no manual
            pairing required
          </p>
          <div className="text-xs text-green-400">
            Discovery time: &lt;2 seconds
          </div>
        </div>

        <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-bold text-white mb-3">Offline Sync</h3>
          <p className="text-sm text-gray-400 mb-4">
            All data collected offline syncs automatically when internet
            connectivity returns
          </p>
          <div className="text-xs text-purple-400">Sync queue: unlimited</div>
        </div>
      </div>
    </div>
  );
}

function DataFlowTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-2">
          Complete Data Flow
        </h2>
        <p className="text-gray-400 mb-6">
          End-to-end journey from raw device signal to tradable financial
          indices
        </p>
      </div>

      <div className="bg-[#1A1F3A] rounded-lg p-8 border border-gray-700">
        <div className="space-y-8">
          {/* Flow 1: Collection */}
          <DataFlowStep
            number="1"
            title="Device Collection"
            color="bg-[#00D9FF]"
            description="Wearable device captures raw sensor data"
            example="Polar H10 records heart rate: 165 BPM"
          />

          {/* Flow 2: Mesh Sync */}
          <DataFlowStep
            number="2"
            title="Mesh Synchronization"
            color="bg-green-500"
            description="Data broadcasts through mesh network to mobile app"
            example="Device → Phone mesh sync (offline capable)"
          />

          {/* Flow 3: Schema Transform */}
          <DataFlowStep
            number="3"
            title="BIM Schema Transformation"
            color="bg-[#C4A661]"
            description="Raw data transforms to universal BIM metrics via sport-specific mappings"
            example="165 BPM → cardiovascular_intensity: 85/100 (wrestling context)"
          />

          {/* Flow 4: Analytics */}
          <DataFlowStep
            number="4"
            title="Universal Analytics"
            color="bg-purple-500"
            description="BIM metrics feed into PPI/TPI/LPI calculation engine"
            example="cardiovascular_intensity + explosive_power + agility → PPI: 78.5"
          />

          {/* Flow 5: Financial */}
          <DataFlowStep
            number="5"
            title="Financial Layer"
            color="bg-yellow-500"
            description="Performance indices drive NIL valuation and swap pricing"
            example="PPI 78.5 → NIL value: $12,450 | Swap price: $0.85/unit"
          />
        </div>
      </div>

      {/* Real-world Example */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4">
          Real-World Example: Wrestling Practice
        </h3>

        <div className="bg-[#0A0E27] rounded-lg p-6 border border-gray-700">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-[#00D9FF] flex items-center justify-center flex-shrink-0 text-xs font-bold text-black">
                1
              </div>
              <div className="text-sm text-gray-300">
                Wrestler wears Polar H10 (HR monitor) + Catapult Vector (IMU
                sensor)
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0 text-xs font-bold text-black">
                2
              </div>
              <div className="text-sm text-gray-300">
                Devices mesh-sync to coach's phone (no WiFi in gym)
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-[#C4A661] flex items-center justify-center flex-shrink-0 text-xs font-bold text-black">
                3
              </div>
              <div className="text-sm text-gray-300">
                BIM schema transforms: HR → cardiovascular_intensity, IMU →
                explosive_power, contact events → takedown_efficiency
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center flex-shrink-0 text-xs font-bold text-white">
                4
              </div>
              <div className="text-sm text-gray-300">
                Analytics engine calculates PPI from BIM metrics + historical
                performance
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-yellow-500 flex items-center justify-center flex-shrink-0 text-xs font-bold text-black">
                5
              </div>
              <div className="text-sm text-gray-300">
                Updated PPI triggers NIL valuation recalc + swap price
                adjustment
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataFlowStep({ number, title, color, description, example }) {
  return (
    <div className="flex items-start gap-4">
      <div
        className={`w-12 h-12 rounded-full ${color} flex items-center justify-center text-black font-bold flex-shrink-0`}
      >
        {number}
      </div>
      <div className="flex-1">
        <h4 className="text-lg font-bold text-white mb-2">{title}</h4>
        <p className="text-sm text-gray-400 mb-2">{description}</p>
        <div className="bg-[#0A0E27] rounded px-3 py-2 border border-gray-700">
          <code className="text-xs text-[#00D9FF]">{example}</code>
        </div>
      </div>
    </div>
  );
}
