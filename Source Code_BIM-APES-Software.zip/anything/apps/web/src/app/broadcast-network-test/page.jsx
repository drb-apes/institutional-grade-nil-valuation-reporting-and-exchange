"use client";

import { useState } from "react";
import { Radio, Tv, Film, Zap, CheckCircle, XCircle } from "lucide-react";
import useUser from "@/utils/useUser";

export default function BroadcastNetworkTest() {
  const { data: user, loading } = useUser();
  const [network, setNetwork] = useState("espn");
  const [testResults, setTestResults] = useState(null);
  const [testingInProgress, setTestingInProgress] = useState(false);
  const [error, setError] = useState(null);

  const networks = [
    {
      id: "espn",
      name: "ESPN",
      icon: <Tv className="w-5 h-5" />,
      color: "red",
    },
    {
      id: "tnt",
      name: "TNT",
      icon: <Film className="w-5 h-5" />,
      color: "blue",
    },
    {
      id: "nbc",
      name: "NBC",
      icon: <Radio className="w-5 h-5" />,
      color: "yellow",
    },
  ];

  const handleTest = async () => {
    setTestingInProgress(true);
    setError(null);
    setTestResults(null);

    try {
      let response;

      if (network === "espn") {
        response = await fetch("/api/broadcast/espn/real-time-feed", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-broadcast-api-key": "test_key_espn_demo",
          },
          body: JSON.stringify({
            eventId: "test_event_12345",
            sport: "basketball",
            athletes: [
              {
                athleteId: 1,
                name: "Test Athlete 1",
                position: "PG",
                jerseyNumber: 1,
              },
              {
                athleteId: 2,
                name: "Test Athlete 2",
                position: "SG",
                jerseyNumber: 2,
              },
            ],
            dataTypes: ["performance", "biometric", "nil"],
            includeNIL: true,
            includeCapsules: true,
            includePlaybook: false,
          }),
        });
      } else if (network === "tnt") {
        response = await fetch("/api/broadcast/tnt/capsule-overlay", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-broadcast-api-key": "test_key_tnt_demo",
          },
          body: JSON.stringify({
            athleteId: 1,
            eventId: "test_event_12345",
            renderFormat: "svg",
            size: 200,
            animationDuration: 300,
          }),
        });
      } else if (network === "nbc") {
        response = await fetch("/api/broadcast/nbc/athlete-story-feed", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-broadcast-api-key": "test_key_nbc_demo",
          },
          body: JSON.stringify({
            athleteId: 1,
            storyType: "full_profile",
            includePerformanceJourney: true,
            includeMilestones: true,
            includeNILGrowth: true,
          }),
        });
      }

      const data = await response.json();

      setTestResults({
        success: response.ok,
        status: response.status,
        data,
        latency: data.latency || 0,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setTestingInProgress(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-indigo-400 underline">
            sign in
          </a>{" "}
          to access broadcast testing
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Zap className="w-10 h-10 text-indigo-400" />
          <h1 className="text-4xl font-bold text-white">
            Broadcast Network API Tester
          </h1>
        </div>
        <p className="text-indigo-200 text-lg">
          ESPN · TNT · NBC Integration Testing
        </p>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Network Selector */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-white text-xl font-semibold mb-4">
            Select Broadcast Network
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {networks.map((net) => (
              <button
                key={net.id}
                onClick={() => setNetwork(net.id)}
                className={`flex items-center gap-3 p-6 rounded-xl border-2 transition-all ${
                  network === net.id
                    ? "bg-indigo-600 border-indigo-400 text-white"
                    : "bg-slate-800 border-slate-600 text-slate-300 hover:border-slate-400"
                }`}
              >
                {net.icon}
                <span className="text-xl font-bold">{net.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Test Controls */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white text-xl font-semibold">
              API Test Configuration
            </h2>
            <button
              onClick={handleTest}
              disabled={testingInProgress}
              className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Zap className="w-5 h-5" />
              {testingInProgress
                ? "Testing..."
                : `Test ${network.toUpperCase()} API`}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <InfoCard
              label="Endpoint"
              value={`/api/broadcast/${network}/...`}
            />
            <InfoCard
              label="Rate Limit"
              value={
                network === "espn"
                  ? "200/min"
                  : network === "tnt"
                    ? "100/min"
                    : "60/min"
              }
            />
            <InfoCard label="Auth Method" value="API Key Header" />
          </div>
        </div>

        {/* Test Results */}
        {testResults && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-center gap-3 mb-6">
              {testResults.success ? (
                <CheckCircle className="w-8 h-8 text-green-400" />
              ) : (
                <XCircle className="w-8 h-8 text-red-400" />
              )}
              <h2 className="text-white text-2xl font-semibold">
                {testResults.success ? "Test Successful" : "Test Failed"}
              </h2>
            </div>

            {/* Status Info */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <StatusCard
                label="HTTP Status"
                value={testResults.status}
                success={testResults.success}
              />
              <StatusCard
                label="Latency"
                value={`${testResults.latency}ms`}
                success={testResults.latency < 200}
              />
              <StatusCard
                label="Timestamp"
                value={new Date(testResults.timestamp).toLocaleTimeString()}
                success={true}
              />
              <StatusCard
                label="Data Quality"
                value={`${testResults.data.dataQuality || "N/A"}%`}
                success={true}
              />
            </div>

            {/* Response Data */}
            <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
              <h3 className="text-white font-semibold mb-3">Response Data</h3>
              <pre className="text-green-400 text-sm overflow-x-auto">
                {JSON.stringify(testResults.data, null, 2)}
              </pre>
            </div>

            {/* Network-Specific Insights */}
            {network === "espn" && testResults.data.feed && (
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-slate-800 rounded-lg p-4 border border-slate-600">
                  <h4 className="text-white font-semibold mb-3">
                    Athletes in Feed
                  </h4>
                  <div className="space-y-2">
                    {testResults.data.feed.athletes.map((athlete, idx) => (
                      <div
                        key={idx}
                        className="flex justify-between items-center"
                      >
                        <span className="text-indigo-200">{athlete.name}</span>
                        <span className="text-white font-mono text-sm">
                          {athlete.performance?.heartRate || "N/A"} bpm
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-800 rounded-lg p-4 border border-slate-600">
                  <h4 className="text-white font-semibold mb-3">
                    Graphics Suggestions
                  </h4>
                  {testResults.data.feed.graphicsSuggestions?.length > 0 ? (
                    <div className="space-y-2">
                      {testResults.data.feed.graphicsSuggestions.map(
                        (suggestion, idx) => (
                          <div
                            key={idx}
                            className="bg-indigo-900/30 rounded p-3 border border-indigo-600/30"
                          >
                            <p className="text-indigo-300 text-sm font-medium">
                              {suggestion.type}
                            </p>
                            <p className="text-white text-sm">
                              {suggestion.message}
                            </p>
                          </div>
                        ),
                      )}
                    </div>
                  ) : (
                    <p className="text-slate-400 text-sm">
                      No suggestions generated
                    </p>
                  )}
                </div>
              </div>
            )}

            {network === "tnt" && testResults.data.capsule && (
              <div className="mt-6 bg-slate-800 rounded-lg p-6 border border-slate-600">
                <h4 className="text-white font-semibold mb-4">
                  SVG Capsule Rendering
                </h4>
                <div
                  className="bg-slate-900 rounded p-4"
                  dangerouslySetInnerHTML={{ __html: testResults.data.capsule }}
                />
              </div>
            )}
          </div>
        )}

        {error && (
          <div className="bg-red-500/20 border border-red-500 rounded-xl p-6">
            <h3 className="text-red-200 font-semibold mb-2">Error</h3>
            <p className="text-red-300">{error}</p>
          </div>
        )}

        {/* Integration Guide */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-white text-xl font-semibold mb-4">
            Integration Guide
          </h2>
          <div className="space-y-4">
            <IntegrationStep
              number={1}
              title="Request API Key"
              description="Contact PhysiobioFIN to obtain network-specific broadcast API key"
            />
            <IntegrationStep
              number={2}
              title="Configure Authentication"
              description="Add x-broadcast-api-key header to all requests"
            />
            <IntegrationStep
              number={3}
              title="Test Endpoints"
              description="Use this dashboard to verify integration and data flow"
            />
            <IntegrationStep
              number={4}
              title="Deploy to Production"
              description="Integrate feed into broadcast graphics system"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ label, value }) {
  return (
    <div className="bg-slate-800 rounded-lg p-4 border border-slate-600">
      <p className="text-slate-400 text-sm mb-1">{label}</p>
      <p className="text-white font-mono text-lg">{value}</p>
    </div>
  );
}

function StatusCard({ label, value, success }) {
  return (
    <div
      className={`rounded-lg p-4 border ${
        success
          ? "bg-green-900/20 border-green-600/30"
          : "bg-red-900/20 border-red-600/30"
      }`}
    >
      <p className="text-slate-300 text-sm mb-1">{label}</p>
      <p
        className={`font-mono text-lg ${success ? "text-green-400" : "text-red-400"}`}
      >
        {value}
      </p>
    </div>
  );
}

function IntegrationStep({ number, title, description }) {
  return (
    <div className="flex gap-4">
      <div className="flex-shrink-0 w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold">
        {number}
      </div>
      <div>
        <h3 className="text-white font-semibold mb-1">{title}</h3>
        <p className="text-indigo-200 text-sm">{description}</p>
      </div>
    </div>
  );
}
