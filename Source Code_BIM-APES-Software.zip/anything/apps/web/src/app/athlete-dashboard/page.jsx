"use client";

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import useUser from "@/utils/useUser";
import {
  TrendingUp,
  TrendingDown,
  Target,
  Zap,
  Activity,
  BarChart3,
  Trophy,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowUp,
  ArrowDown,
  Minus,
} from "lucide-react";

export default function AthleteDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [selectedTimeframe, setSelectedTimeframe] = useState("30");
  const [selectedScale, setSelectedScale] = useState("auto");

  // Fetch athlete performance data
  const {
    data: dashboardData,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["athlete-dashboard", user?.id, selectedTimeframe],
    queryFn: async () => {
      const response = await fetch(
        `/api/athlete-dashboard/metrics?timeframe=${selectedTimeframe}`,
      );
      if (!response.ok) {
        throw new Error("Failed to fetch dashboard data");
      }
      return response.json();
    },
    enabled: !!user?.id,
    refetchInterval: 30000, // Update every 30 seconds
  });

  if (userLoading || isLoading) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return <ErrorDisplay error={error} onRetry={refetch} />;
  }

  const {
    performance_metrics,
    tier_status,
    progression_tracking,
    coaching_insights,
    recent_activity,
    alerts,
  } = dashboardData || {};

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header Section */}
        <DashboardHeader
          user={user}
          tierStatus={tier_status}
          selectedTimeframe={selectedTimeframe}
          setSelectedTimeframe={setSelectedTimeframe}
          selectedScale={selectedScale}
          setSelectedScale={setSelectedScale}
        />

        {/* Alert Banner */}
        {alerts && alerts.length > 0 && <AlertBanner alerts={alerts} />}

        {/* Main Performance Metrics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Performance Index Cards */}
          <div className="lg:col-span-2 space-y-6">
            <PerformanceIndexGrid
              metrics={performance_metrics}
              scale={selectedScale}
            />

            {/* Progression Tracking Chart */}
            <ProgressionChart
              data={progression_tracking}
              timeframe={selectedTimeframe}
            />
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Tier Status Card */}
            <TierStatusCard tierStatus={tier_status} />

            {/* Coaching Insights */}
            <CoachingInsightsCard insights={coaching_insights} />

            {/* Recent Activity */}
            <RecentActivityCard activity={recent_activity} />
          </div>
        </div>

        {/* Cross-Correlation Analysis */}
        <CrossCorrelationSection insights={coaching_insights} />
      </div>
    </div>
  );
}

// **📊 DASHBOARD HEADER**
function DashboardHeader({
  user,
  tierStatus,
  selectedTimeframe,
  setSelectedTimeframe,
  selectedScale,
  setSelectedScale,
}) {
  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Performance Dashboard
          </h1>
          <div className="flex items-center space-x-4">
            <p className="text-gray-600">Welcome back, {user?.name}</p>
            {tierStatus && (
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span className="text-sm font-medium text-gray-700">
                  {tierStatus.current_tier_name}
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Scale Toggle */}
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-gray-700">Scale:</label>
            <select
              value={selectedScale}
              onChange={(e) => setSelectedScale(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="auto">Auto</option>
              <option value="0-10">0-10</option>
              <option value="0-100">0-100</option>
            </select>
          </div>

          {/* Timeframe Selector */}
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-gray-700">Period:</label>
            <select
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="7">7 Days</option>
              <option value="30">30 Days</option>
              <option value="90">90 Days</option>
              <option value="180">6 Months</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

// **⚡ PERFORMANCE INDEX GRID**
function PerformanceIndexGrid({ metrics, scale }) {
  if (!metrics) {
    return (
      <div className="text-center py-8 text-gray-500">
        No performance data available
      </div>
    );
  }

  const performanceIndices = [
    {
      key: "bvi",
      name: "BVI Score",
      description: "Biomechanical Velocity Index",
      icon: Zap,
      color: "blue",
      current: metrics.bvi?.current || 0,
      previous: metrics.bvi?.previous || 0,
      trend: metrics.bvi?.trend || "stable",
      max_scale: metrics.bvi?.scale_max || 10,
    },
    {
      key: "tactical_efficiency",
      name: "Tactical Efficiency",
      description: "Strategic execution precision",
      icon: Target,
      color: "green",
      current: metrics.tactical_efficiency?.current || 0,
      previous: metrics.tactical_efficiency?.previous || 0,
      trend: metrics.tactical_efficiency?.trend || "stable",
      max_scale: metrics.tactical_efficiency?.scale_max || 10,
    },
    {
      key: "recovery_index",
      name: "Recovery Index",
      description: "Performance sustainability",
      icon: Activity,
      color: "purple",
      current: metrics.recovery_index?.current || 0,
      previous: metrics.recovery_index?.previous || 0,
      trend: metrics.recovery_index?.trend || "stable",
      max_scale: metrics.recovery_index?.scale_max || 10,
    },
    {
      key: "spike_score",
      name: "Spike Score",
      description: "Peak performance capability",
      icon: TrendingUp,
      color: "orange",
      current: metrics.spike_score?.current || 0,
      previous: metrics.spike_score?.previous || 0,
      trend: metrics.spike_score?.trend || "stable",
      max_scale: metrics.spike_score?.scale_max || 10,
    },
    {
      key: "session_consistency",
      name: "Session Consistency",
      description: "Performance reliability",
      icon: BarChart3,
      color: "indigo",
      current: metrics.session_consistency?.current || 0,
      previous: metrics.session_consistency?.previous || 0,
      trend: metrics.session_consistency?.trend || "stable",
      max_scale: metrics.session_consistency?.scale_max || 10,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {performanceIndices.map((metric) => (
        <PerformanceIndexCard key={metric.key} metric={metric} scale={scale} />
      ))}
    </div>
  );
}

// **📈 PERFORMANCE INDEX CARD**
function PerformanceIndexCard({ metric, scale }) {
  const {
    name,
    description,
    icon: Icon,
    color,
    current,
    previous,
    trend,
    max_scale,
  } = metric;

  // Determine display scale
  let displayCurrent = current;
  let displayMax = max_scale;

  if (scale === "0-100") {
    displayCurrent = (current / max_scale) * 100;
    displayMax = 100;
  } else if (scale === "0-10") {
    displayCurrent = (current / max_scale) * 10;
    displayMax = 10;
  }

  const percentage = (displayCurrent / displayMax) * 100;
  const change = current - previous;
  const changePercentage = previous > 0 ? (change / previous) * 100 : 0;

  // Color mappings
  const colorClasses = {
    blue: "bg-blue-500 text-blue-600 border-blue-200",
    green: "bg-green-500 text-green-600 border-green-200",
    purple: "bg-purple-500 text-purple-600 border-purple-200",
    orange: "bg-orange-500 text-orange-600 border-orange-200",
    indigo: "bg-indigo-500 text-indigo-600 border-indigo-200",
  };

  const trendIcon = {
    improving: <ArrowUp className="w-4 h-4 text-green-500" />,
    declining: <ArrowDown className="w-4 h-4 text-red-500" />,
    stable: <Minus className="w-4 h-4 text-gray-500" />,
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div
          className={`p-3 rounded-lg bg-opacity-10 border ${colorClasses[color]}`}
        >
          <Icon className={`w-6 h-6 text-${color}-600`} />
        </div>
        <div className="flex items-center space-x-1">
          {trendIcon[trend]}
          <span
            className={`text-sm font-medium ${
              trend === "improving"
                ? "text-green-600"
                : trend === "declining"
                  ? "text-red-600"
                  : "text-gray-600"
            }`}
          >
            {changePercentage > 0 ? "+" : ""}
            {changePercentage.toFixed(1)}%
          </span>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-lg font-bold text-gray-900 mb-1">{name}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>

      <div className="mb-4">
        <div className="flex items-end space-x-2 mb-2">
          <span className="text-3xl font-bold text-gray-900">
            {displayCurrent.toFixed(1)}
          </span>
          <span className="text-lg text-gray-500 mb-1">/{displayMax}</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full bg-${color}-500 transition-all duration-500`}
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>
      </div>

      <div className="flex justify-between text-sm text-gray-600">
        <span>Previous: {previous.toFixed(1)}</span>
        <span
          className={`font-medium ${change >= 0 ? "text-green-600" : "text-red-600"}`}
        >
          {change >= 0 ? "+" : ""}
          {change.toFixed(1)}
        </span>
      </div>
    </div>
  );
}

// **📊 PROGRESSION CHART**
function ProgressionChart({ data, timeframe }) {
  if (!data || !data.progression_data) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">
          Performance Progression
        </h3>
        <div className="text-center py-8 text-gray-500">
          No progression data available
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-900">
          Performance Progression
        </h3>
        <div className="text-sm text-gray-600">Last {timeframe} days</div>
      </div>

      {/* Chart would go here - using a simple visualization for now */}
      <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-200 rounded-lg">
        <div className="text-center">
          <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-500">Interactive chart visualization</p>
          <p className="text-sm text-gray-400">
            Recharts integration coming soon
          </p>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-gray-100">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">
            {data.summary?.average_score?.toFixed(1) || "0.0"}
          </div>
          <div className="text-sm text-gray-600">Average Score</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">
            {data.summary?.improvement_rate?.toFixed(1) || "0.0"}%
          </div>
          <div className="text-sm text-gray-600">Improvement</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {data.summary?.consistency_score?.toFixed(1) || "0.0"}
          </div>
          <div className="text-sm text-gray-600">Consistency</div>
        </div>
      </div>
    </div>
  );
}

// **🏆 TIER STATUS CARD**
function TierStatusCard({ tierStatus }) {
  if (!tierStatus) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Tier Status</h3>
        <div className="text-center py-4 text-gray-500">
          No tier data available
        </div>
      </div>
    );
  }

  const {
    current_tier,
    current_tier_name,
    next_tier_name,
    advancement_progress,
    requirements,
  } = tierStatus;

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h3 className="text-lg font-bold text-gray-900 mb-4">Tier Status</h3>

      {/* Current Tier */}
      <div className="text-center mb-6">
        <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
          <Trophy className="w-8 h-8 text-white" />
        </div>
        <h4 className="text-xl font-bold text-gray-900">{current_tier_name}</h4>
        <p className="text-sm text-gray-600">Current Tier</p>
      </div>

      {/* Progression to Next Tier */}
      {next_tier_name && (
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">
              Progress to {next_tier_name}
            </span>
            <span className="text-sm font-bold text-blue-600">
              {advancement_progress?.toFixed(0) || 0}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="h-3 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-500"
              style={{ width: `${Math.min(advancement_progress || 0, 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Requirements */}
      {requirements && requirements.length > 0 && (
        <div>
          <h5 className="text-sm font-medium text-gray-700 mb-3">
            Requirements
          </h5>
          <div className="space-y-2">
            {requirements.map((req, index) => (
              <div key={index} className="flex items-center space-x-2">
                {req.completed ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Clock className="w-4 h-4 text-gray-400" />
                )}
                <span
                  className={`text-sm ${req.completed ? "text-green-700" : "text-gray-600"}`}
                >
                  {req.description}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// **🧠 COACHING INSIGHTS CARD**
function CoachingInsightsCard({ insights }) {
  if (!insights || !insights.recommendations) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">
          Coaching Insights
        </h3>
        <div className="text-center py-4 text-gray-500">
          No insights available
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h3 className="text-lg font-bold text-gray-900 mb-4">
        Coaching Insights
      </h3>

      <div className="space-y-4">
        {insights.recommendations.slice(0, 3).map((insight, index) => (
          <div key={index} className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-start space-x-3">
              <div
                className={`p-1 rounded-full ${
                  insight.priority === "high"
                    ? "bg-red-100 text-red-600"
                    : insight.priority === "medium"
                      ? "bg-yellow-100 text-yellow-600"
                      : "bg-blue-100 text-blue-600"
                }`}
              >
                <Target className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-medium text-gray-900 mb-1">
                  {insight.title}
                </h4>
                <p className="text-xs text-gray-600 mb-2">
                  {insight.description}
                </p>
                {insight.action_items && insight.action_items.length > 0 && (
                  <ul className="text-xs text-gray-600 space-y-1">
                    {insight.action_items
                      .slice(0, 2)
                      .map((action, actionIndex) => (
                        <li
                          key={actionIndex}
                          className="flex items-center space-x-1"
                        >
                          <span className="w-1 h-1 bg-gray-400 rounded-full" />
                          <span>{action}</span>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// **📋 RECENT ACTIVITY CARD**
function RecentActivityCard({ activity }) {
  if (!activity || activity.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">
          Recent Activity
        </h3>
        <div className="text-center py-4 text-gray-500">No recent activity</div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Activity</h3>

      <div className="space-y-3">
        {activity.slice(0, 5).map((item, index) => (
          <div
            key={index}
            className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg"
          >
            <div className="w-2 h-2 bg-blue-500 rounded-full" />
            <div className="flex-1">
              <p className="text-sm text-gray-900">{item.description}</p>
              <p className="text-xs text-gray-500">{item.timestamp}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// **⚠️ ALERT BANNER**
function AlertBanner({ alerts }) {
  const highPriorityAlerts = alerts.filter(
    (alert) => alert.severity === "high",
  );

  if (highPriorityAlerts.length === 0) return null;

  return (
    <div className="bg-red-50 border border-red-200 rounded-xl p-4">
      <div className="flex items-center space-x-3">
        <AlertTriangle className="w-5 h-5 text-red-600" />
        <div>
          <h4 className="text-sm font-medium text-red-800">
            Attention Required
          </h4>
          <p className="text-sm text-red-600">
            {highPriorityAlerts.length} high-priority alert
            {highPriorityAlerts.length > 1 ? "s" : ""} need your attention
          </p>
        </div>
      </div>
    </div>
  );
}

// **🔗 CROSS-CORRELATION SECTION**
function CrossCorrelationSection({ insights }) {
  if (!insights?.correlations) {
    return null;
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h3 className="text-lg font-bold text-gray-900 mb-6">
        Cross-Correlation Analysis
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {insights.correlations.map((correlation, index) => (
          <div key={index} className="p-4 bg-gray-50 rounded-lg">
            <h4 className="text-sm font-medium text-gray-900 mb-2">
              {correlation.metric_pair}
            </h4>
            <div className="flex items-center space-x-2 mb-2">
              <div className="text-lg font-bold text-blue-600">
                {correlation.correlation_strength}
              </div>
              <div
                className={`px-2 py-1 rounded text-xs font-medium ${
                  correlation.strength_level === "strong"
                    ? "bg-green-100 text-green-700"
                    : correlation.strength_level === "moderate"
                      ? "bg-yellow-100 text-yellow-700"
                      : "bg-gray-100 text-gray-700"
                }`}
              >
                {correlation.strength_level}
              </div>
            </div>
            <p className="text-xs text-gray-600">
              {correlation.coaching_insight}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

// **💀 SKELETON LOADER**
function DashboardSkeleton() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="bg-white rounded-xl shadow-lg border border-gray-100 p-6"
                >
                  <div className="animate-pulse">
                    <div className="h-12 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="bg-white rounded-xl shadow-lg border border-gray-100 p-6"
              >
                <div className="animate-pulse">
                  <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// **⚠️ ERROR DISPLAY**
function ErrorDisplay({ error, onRetry }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 p-6 flex items-center justify-center">
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8 text-center max-w-md">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-gray-900 mb-2">
          Dashboard Error
        </h3>
        <p className="text-gray-600 mb-4">{error.message}</p>
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Retry
        </button>
      </div>
    </div>
  );
}
