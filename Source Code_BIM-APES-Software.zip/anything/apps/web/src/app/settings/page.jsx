"use client";

import { useState } from "react";
import {
  Settings,
  User,
  Shield,
  Bell,
  CreditCard,
  Building2,
  Globe,
  Lock,
  Eye,
  EyeOff,
  Mail,
  Phone,
  MapPin,
  Save,
  ArrowLeft,
  Trash2,
  AlertTriangle,
  CheckCircle,
} from "lucide-react";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("account");
  const [showPassword, setShowPassword] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    marketing: false,
  });
  const [privacy, setPrivacy] = useState({
    profileVisible: true,
    performanceVisible: true,
    contactVisible: false,
  });

  const tabs = [
    { id: "account", label: "Account", icon: User },
    { id: "security", label: "Security", icon: Shield },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "privacy", label: "Privacy", icon: Lock },
    { id: "billing", label: "Billing", icon: CreditCard },
    { id: "institutional", label: "Institutional", icon: Building2 },
  ];

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="px-6 py-4 bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <a
              href="/dashboard"
              className="text-[#1D2B3D] hover:text-[#B8860B] transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </a>
            <div>
              <h1 className="text-2xl font-bold text-[#1D2B3D]">
                Account Settings
              </h1>
              <p className="text-gray-600">
                Manage your portfolio and platform preferences
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-6 py-2 rounded-lg flex items-center space-x-2 transition-colors">
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
              <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                Settings
              </h3>
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === tab.id
                          ? "bg-[#1D2B3D] text-white"
                          : "text-gray-600 hover:bg-gray-50 hover:text-[#1D2B3D]"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
              {/* Account Settings */}
              {activeTab === "account" && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-[#1D2B3D]">
                    Account Information
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Full Name
                      </label>
                      <input
                        type="text"
                        defaultValue="Jordan Mitchell"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        defaultValue="jordan.mitchell@example.com"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        defaultValue="+1 (555) 123-4567"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Sport/Speciality
                      </label>
                      <input
                        type="text"
                        defaultValue="Track & Field - Sprint/Hurdles"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location
                      </label>
                      <input
                        type="text"
                        defaultValue="Atlanta, GA, United States"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Bio
                      </label>
                      <textarea
                        rows={4}
                        defaultValue="Professional sprinter focused on breaking personal records and building sustainable athletic career through institutional investment management."
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent resize-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Security Settings */}
              {activeTab === "security" && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-[#1D2B3D]">
                    Security
                  </h2>

                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4 text-[#1D2B3D]">
                        Change Password
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Current Password
                          </label>
                          <div className="relative">
                            <input
                              type={showPassword ? "text" : "password"}
                              className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                            >
                              {showPassword ? (
                                <EyeOff className="w-5 h-5" />
                              ) : (
                                <Eye className="w-5 h-5" />
                              )}
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            New Password
                          </label>
                          <input
                            type="password"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-lg font-medium mb-4 text-[#1D2B3D]">
                        Two-Factor Authentication
                      </h3>
                      <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                        <div>
                          <h4 className="font-medium text-[#1D2B3D]">
                            SMS Authentication
                          </h4>
                          <p className="text-sm text-gray-600">
                            Receive codes via text message
                          </p>
                        </div>
                        <button className="bg-[#B8860B] hover:bg-[#A0750A] text-white px-4 py-2 rounded-lg transition-colors">
                          Enable
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-lg font-medium mb-4 text-[#1D2B3D]">
                        Active Sessions
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                          <div>
                            <h4 className="font-medium text-[#1D2B3D]">
                              Current Session
                            </h4>
                            <p className="text-sm text-gray-600">
                              Chrome on MacOS • Atlanta, GA
                            </p>
                          </div>
                          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                            Active
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Notifications */}
              {activeTab === "notifications" && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-[#1D2B3D]">
                    Notification Preferences
                  </h2>

                  <div className="space-y-6">
                    {Object.entries(notifications).map(([key, value]) => (
                      <div
                        key={key}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                      >
                        <div>
                          <h4 className="font-medium text-[#1D2B3D] capitalize">
                            {key === "sms" ? "SMS" : key} Notifications
                          </h4>
                          <p className="text-sm text-gray-600">
                            {key === "email" && "Receive updates via email"}
                            {key === "push" && "Browser push notifications"}
                            {key === "sms" && "Text message notifications"}
                            {key === "marketing" &&
                              "Marketing and promotional content"}
                          </p>
                        </div>
                        <button
                          onClick={() =>
                            setNotifications({
                              ...notifications,
                              [key]: !value,
                            })
                          }
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            value ? "bg-[#B8860B]" : "bg-gray-300"
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              value ? "translate-x-6" : "translate-x-1"
                            }`}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Privacy Settings */}
              {activeTab === "privacy" && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-[#1D2B3D]">
                    Privacy Settings
                  </h2>

                  <div className="space-y-6">
                    <div className="bg-[#B8860B]/10 border border-[#B8860B]/20 rounded-xl p-6">
                      <div className="flex items-start space-x-3">
                        <AlertTriangle className="w-6 h-6 text-[#B8860B] flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                            Data Usage Notice
                          </h3>
                          <p className="text-gray-700">
                            Your performance data is used for educational
                            simulation purposes only. We never provide
                            investment advice or manage client assets directly.
                          </p>
                        </div>
                      </div>
                    </div>

                    {Object.entries(privacy).map(([key, value]) => (
                      <div
                        key={key}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                      >
                        <div>
                          <h4 className="font-medium text-[#1D2B3D] capitalize">
                            {key.replace(/([A-Z])/g, " $1").trim()}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {key === "profileVisible" &&
                              "Allow others to view your profile"}
                            {key === "performanceVisible" &&
                              "Share performance metrics publicly"}
                            {key === "contactVisible" &&
                              "Show contact information to other users"}
                          </p>
                        </div>
                        <button
                          onClick={() =>
                            setPrivacy({ ...privacy, [key]: !value })
                          }
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            value ? "bg-[#B8860B]" : "bg-gray-300"
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              value ? "translate-x-6" : "translate-x-1"
                            }`}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Billing */}
              {activeTab === "billing" && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-[#1D2B3D]">
                    Billing & Subscription
                  </h2>

                  <div className="space-y-6">
                    <div className="bg-[#F5F5F0] p-6 rounded-xl border border-gray-200">
                      <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                        Current Plan
                      </h3>
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-[#1D2B3D]">
                            Professional Athlete Plan
                          </h4>
                          <p className="text-sm text-gray-600">
                            Full platform access with motion analytics
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="text-2xl font-bold text-[#B8860B]">
                            $299
                          </span>
                          <span className="text-gray-600">/month</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                        Payment Method
                      </h3>
                      <div className="border border-gray-200 rounded-lg p-4 flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <CreditCard className="w-8 h-8 text-gray-400" />
                          <div>
                            <p className="font-medium text-[#1D2B3D]">
                              •••• •••• •••• 4567
                            </p>
                            <p className="text-sm text-gray-600">
                              Expires 12/26
                            </p>
                          </div>
                        </div>
                        <button className="text-[#B8860B] hover:text-[#A0750A] font-medium">
                          Update
                        </button>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                        Recent Transactions
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                          <div>
                            <p className="font-medium text-[#1D2B3D]">
                              Monthly Subscription
                            </p>
                            <p className="text-sm text-gray-600">
                              September 20, 2025
                            </p>
                          </div>
                          <span className="text-[#1D2B3D] font-semibold">
                            $299.00
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Institutional Settings */}
              {activeTab === "institutional" && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-[#1D2B3D]">
                    Institutional Partnerships
                  </h2>

                  <div className="space-y-6">
                    <div className="bg-[#F5F5F0] p-6 rounded-xl border border-gray-200">
                      <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                        Connected Institutions
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <Building2 className="w-8 h-8 text-[#B8860B]" />
                            <div>
                              <p className="font-medium text-[#1D2B3D]">
                                Atlanta Sports Finance Credit Union
                              </p>
                              <p className="text-sm text-gray-600">
                                Banking & Investment Services
                              </p>
                            </div>
                          </div>
                          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                            Connected
                          </span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                        Investment Management
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 border border-gray-200 rounded-lg">
                          <h4 className="font-medium text-[#1D2B3D] mb-2">
                            Portfolio Manager
                          </h4>
                          <p className="text-sm text-gray-600">
                            Bledsoe Investment Management
                          </p>
                        </div>
                        <div className="p-4 border border-gray-200 rounded-lg">
                          <h4 className="font-medium text-[#1D2B3D] mb-2">
                            Risk Profile
                          </h4>
                          <p className="text-sm text-gray-600">
                            Conservative Growth
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4 text-[#1D2B3D]">
                        Compliance Status
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="text-green-700">
                            Identity Verification Complete
                          </span>
                        </div>
                        <div className="flex items-center space-x-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="text-green-700">
                            Investment Profile Verified
                          </span>
                        </div>
                        <div className="flex items-center space-x-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="text-green-700">
                            Institutional Partnership Active
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Danger Zone */}
              <div className="mt-12 pt-8 border-t border-gray-200">
                <h3 className="text-lg font-semibold mb-4 text-red-600">
                  Danger Zone
                </h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-6">
                  <div className="flex items-start space-x-3">
                    <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                    <div className="flex-1">
                      <h4 className="font-medium text-red-800 mb-2">
                        Delete Account
                      </h4>
                      <p className="text-sm text-red-700 mb-4">
                        Permanently delete your account and all associated data.
                        This action cannot be undone.
                      </p>
                      <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
                        <Trash2 className="w-4 h-4" />
                        <span>Delete Account</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
