"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import ScoutingPodInterface from "@/components/CombatSports/ScoutingPodInterface";
import CoachFeedbackLoop from "@/components/CombatSports/CoachFeedbackLoop";
import {
  Target,
  Users,
  TrendingUp,
  Activity,
  AlertTriangle,
  CheckCircle,
} from "lucide-react";

export default function CombatSportsDashboardPage() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("scouting");
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [combatType, setCombatType] = useState("mma");
  const [combatAthletes, setCombatAthletes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dashboardStats, setDashboardStats] = useState(null);

  useEffect(() => {
    if (!userLoading && user) {
      fetchCombatAthletes();

      // Check for URL parameters manually
      if (typeof window !== "undefined") {
        const urlParams = new URLSearchParams(window.location.search);
        const athleteId = urlParams.get("athlete");
        const sport = urlParams.get("sport");
        if (athleteId) {
          setSelectedAthlete(parseInt(athleteId));
        }
        if (sport && ["mma", "boxing"].includes(sport.toLowerCase())) {
          setCombatType(sport.toLowerCase());
        }
      }
    }
  }, [user, userLoading]);

  const fetchCombatAthletes = async () => {
    try {
      const response = await fetch("/api/athletes/list?sport=combat");
      if (response.ok) {
        const data = await response.json();
        // Filter for combat sports athletes
        const combatAthletes = data.athletes.filter(
          (athlete) =>
            athlete.sport?.toLowerCase().includes("mma") ||
            athlete.sport?.toLowerCase().includes("boxing") ||
            athlete.sport?.toLowerCase().includes("combat"),
        );

        setCombatAthletes(combatAthletes);

        if (!selectedAthlete && combatAthletes.length > 0) {
          setSelectedAthlete(combatAthletes[0].id);
        }

        // Generate dashboard stats
        generateDashboardStats(combatAthletes);
      }
    } catch (error) {
      console.error("Error fetching combat athletes:", error);
    } finally {
      setLoading(false);
    }
  };

  const generateDashboardStats = (athletes) => {
    const mmaAthletes = athletes.filter((a) =>
      a.sport?.toLowerCase().includes("mma"),
    );
    const boxingAthletes = athletes.filter((a) =>
      a.sport?.toLowerCase().includes("boxing"),
    );

    const avgBVIScore =
      athletes.length > 0
        ? Math.round(
            athletes.reduce((sum, a) => sum + (a.biometric_score || 0), 0) /
              athletes.length,
          )
        : 0;

    const eliteProspects = athletes.filter(
      (a) => (a.biometric_score || 0) >= 85,
    ).length;
    const activeScouting = athletes.filter(
      (a) => (a.contributor_count || 0) > 0,
    ).length;

    setDashboardStats({
      total_athletes: athletes.length,
      mma_count: mmaAthletes.length,
      boxing_count: boxingAthletes.length,
      avg_bvi_score: avgBVIScore,
      elite_prospects: eliteProspects,
      active_scouting: activeScouting,
      coalition_value: athletes.reduce(
        (sum, a) => sum + (a.asset_value || 0),
        0,
      ),
    });
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">
            Loading Combat Sports Dashboard...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center bg-white rounded-xl shadow-lg p-8 max-w-md">
          <AlertTriangle className="h-16 w-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Authentication Required
          </h2>
          <p className="text-gray-600 mb-6">
            Please sign in to access the Combat Sports Dashboard.
          </p>
          <a
            href="/account/signin"
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const selectedAthleteData = combatAthletes.find(
    (a) => a.id === selectedAthlete,
  );

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-900 via-red-700 to-orange-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">
                Combat Sports Dashboard
              </h1>
              <p className="text-red-100 mt-2">
                BVI Analytics • Scouting Pods • Coach Feedback Loops
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-red-100">Coalition Analyst</p>
                <p className="font-medium text-white">{user.name}</p>
              </div>
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Dashboard Stats */}
        {dashboardStats && (
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
            <StatCard
              icon={Users}
              title="Total Athletes"
              value={dashboardStats.total_athletes}
              color="blue"
            />
            <StatCard
              icon={Target}
              title="MMA Athletes"
              value={dashboardStats.mma_count}
              color="red"
            />
            <StatCard
              icon={Activity}
              title="Boxing Athletes"
              value={dashboardStats.boxing_count}
              color="orange"
            />
            <StatCard
              icon={TrendingUp}
              title="Avg BVI Score"
              value={dashboardStats.avg_bvi_score}
              color="green"
            />
            <StatCard
              icon={CheckCircle}
              title="Elite Prospects"
              value={dashboardStats.elite_prospects}
              color="purple"
            />
            <StatCard
              icon={Users}
              title="Coalition Value"
              value={`$${Math.round(dashboardStats.coalition_value / 1000)}K`}
              color="indigo"
            />
          </div>
        )}

        {/* Athlete & Combat Type Selectors */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            Analysis Configuration
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Combat Sport
              </label>
              <select
                value={combatType}
                onChange={(e) => setCombatType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="mma">Mixed Martial Arts (MMA)</option>
                <option value="boxing">Boxing</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Athlete
              </label>
              <select
                value={selectedAthlete || ""}
                onChange={(e) => setSelectedAthlete(parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                {combatAthletes.length === 0 ? (
                  <option value="">No combat athletes available</option>
                ) : (
                  combatAthletes.map((athlete) => (
                    <option key={athlete.id} value={athlete.id}>
                      {athlete.name} - {athlete.sport} (BVI:{" "}
                      {athlete.biometric_score})
                    </option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Analysis Mode
              </label>
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setActiveTab("scouting")}
                  className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                    activeTab === "scouting"
                      ? "bg-red-600 text-white"
                      : "text-gray-700 hover:text-gray-900"
                  }`}
                >
                  Scouting Pod
                </button>
                <button
                  onClick={() => setActiveTab("coaching")}
                  className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                    activeTab === "coaching"
                      ? "bg-red-600 text-white"
                      : "text-gray-700 hover:text-gray-900"
                  }`}
                >
                  Coach Feedback
                </button>
              </div>
            </div>
          </div>

          {selectedAthleteData && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">
                Selected Athlete Profile
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Name:</span>
                  <p className="font-medium">{selectedAthleteData.name}</p>
                </div>
                <div>
                  <span className="text-gray-600">Sport:</span>
                  <p className="font-medium">{selectedAthleteData.sport}</p>
                </div>
                <div>
                  <span className="text-gray-600">Tier Level:</span>
                  <p className="font-medium">
                    Tier {selectedAthleteData.tier_level}
                  </p>
                </div>
                <div>
                  <span className="text-gray-600">Asset Value:</span>
                  <p className="font-medium">
                    {selectedAthleteData.asset_value
                      ? `$${Math.round(selectedAthleteData.asset_value / 1000)}K`
                      : "TBD"}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Main Analysis Interface */}
        {selectedAthlete && combatAthletes.length > 0 ? (
          <div className="space-y-8">
            {activeTab === "scouting" ? (
              <ScoutingPodInterface
                athleteId={selectedAthlete}
                combatType={combatType}
              />
            ) : (
              <CoachFeedbackLoop
                athleteId={selectedAthlete}
                combatType={combatType}
              />
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-lg p-12 text-center">
            <AlertTriangle className="h-16 w-16 text-amber-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              No Combat Athletes Available
            </h3>
            <p className="text-gray-600 mb-6">
              No combat sports athletes found in the system. Please add MMA or
              Boxing athletes to begin analysis.
            </p>
            <a
              href="/referral"
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors inline-flex items-center space-x-2"
            >
              <Users className="h-5 w-5" />
              <span>Add Combat Athlete</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, title, value, color }) {
  const colorClasses = {
    blue: "from-blue-500 to-blue-600",
    red: "from-red-500 to-red-600",
    orange: "from-orange-500 to-orange-600",
    green: "from-green-500 to-green-600",
    purple: "from-purple-500 to-purple-600",
    indigo: "from-indigo-500 to-indigo-600",
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-3">
        <div
          className={`p-2 rounded-lg bg-gradient-to-r ${colorClasses[color]}`}
        >
          <Icon className="h-5 w-5 text-white" />
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-sm text-gray-600">{title}</p>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
      </div>
    </div>
  );
}
