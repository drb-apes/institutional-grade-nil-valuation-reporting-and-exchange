"use client";
import { useState, useRef, useEffect } from "react";
import RegulatoryPhaseCandlestick from "@/components/MotionScan/RegulatoryPhaseCandlestick";
import { Activity, Award } from "lucide-react";
import useUser from "@/utils/useUser";
import useMotionScan from "@/hooks/useMotionScan";
import LoadingSpinner from "@/components/MotionScan/LoadingSpinner";
import AuthRequired from "@/components/MotionScan/AuthRequired";
import MotionScanHeader from "@/components/MotionScan/MotionScanHeader";
import SportConfigPanel from "@/components/MotionScan/SportConfigPanel";
import MotionCapture from "@/components/MotionScan/MotionCapture";
import BIMPerformanceDisplay from "@/components/MotionScan/BIMPerformanceDisplay/BIMPerformanceDisplay";
import BasicResults from "@/components/MotionScan/BasicResults";
import ScoutNotesPanel from "@/components/MotionScan/ScoutNotesPanel";
import QRFlyerPanel from "@/components/MotionScan/QRFlyerPanel";
import ScanHistory from "@/components/MotionScan/ScanHistory";
import TierBadgeDisplay from "@/components/MotionScan/TierBadgeDisplay";
import BiomechanicalHeatmap from "@/components/MotionScan/BiomechanicalHeatmap";

export default function MotionScanPage() {
  const { data: user, loading: userLoading } = useUser();

  // Enhanced capture settings
  const [recordingAngle, setRecordingAngle] = useState("front");
  const [selectedSport, setSelectedSport] = useState("general");
  const [sessionId, setSessionId] = useState(null);
  const [recordingDuration, setRecordingDuration] = useState(0);

  const {
    videoRef,
    streamRef,
    isRecording,
    hasRecording,
    isProcessing,
    scanResults,
    scanHistory,
    startCamera,
    startRecording,
    stopRecording,
    processMotionScan,
    resetScan,
  } = useMotionScan(user, selectedSport);

  // Enhanced state for tier badge and biomechanical analysis
  const [scoutNotes, setScoutNotes] = useState("");
  const [spikeEvents, setSpikeEvents] = useState([]);
  const [tierBadge, setTierBadge] = useState(null);
  const [biomechanicalHeatmap, setBiomechanicalHeatmap] = useState(null);

  const durationIntervalRef = useRef(null);

  useEffect(() => {
    if (user) {
      generateSessionId();
    }
  }, [user]);

  useEffect(() => {
    if (isRecording) {
      durationIntervalRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 0.1);
      }, 100);
    } else {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
      if (!hasRecording) {
        setRecordingDuration(0);
      }
    }

    return () => {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [isRecording, hasRecording]);

  useEffect(() => {
    if (scanResults?.tier_badge) {
      // Handle tier badge assignment from API response
      setTierBadge(scanResults.tier_badge);

      // Set spike events from tier badge data
      if (scanResults.tier_badge.spike_events) {
        setSpikeEvents(scanResults.tier_badge.spike_events);
      }

      // Auto-generate scout notes
      if (scanResults.bim_performance) {
        const autoNotes = generateAutoScoutNotes(scanResults.bim_performance);
        setScoutNotes(autoNotes);
      }
    }

    // Handle biomechanical heatmap data
    if (scanResults?.biomechanical_heatmap) {
      setBiomechanicalHeatmap(scanResults.biomechanical_heatmap);

      // Merge auto-scout notes from heatmap analysis
      if (scanResults.biomechanical_heatmap.auto_scout_notes?.length > 0) {
        const heatmapNotes =
          scanResults.biomechanical_heatmap.auto_scout_notes.join(". ");
        setScoutNotes((prev) =>
          prev ? `${prev} ${heatmapNotes}` : heatmapNotes,
        );
      }
    }
  }, [scanResults]);

  const generateSessionId = () => {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    setSessionId(`SCAN_${timestamp}_${random}`);
  };

  const generateAutoScoutNotes = (bimData) => {
    const { performance_index, tier_assessment } = bimData;
    const notes = [];

    if (performance_index.spike_score > 80) {
      notes.push("Exceptional explosive power demonstrated");
    }
    if (performance_index.tactical_efficiency > 75) {
      notes.push("Strong tactical awareness and decision-making");
    }
    if (tier_assessment?.tier_change_recommended) {
      notes.push(
        `Recommended for tier advancement to Level ${tier_assessment.recommended_tier}`,
      );
    }

    return notes.join(". ") + ".";
  };

  if (userLoading) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return <AuthRequired />;
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-12">
        <div className="max-w-7xl mx-auto">
          <MotionScanHeader />

          {/* Sport & Angle Configuration Panel */}
          <SportConfigPanel
            selectedSport={selectedSport}
            setSelectedSport={setSelectedSport}
            recordingAngle={recordingAngle}
            setRecordingAngle={setRecordingAngle}
            sessionId={sessionId}
            generateSessionId={generateSessionId}
            isRecording={isRecording}
            recordingDuration={recordingDuration}
          />

          {/* 🏷️ TIER BADGE DISPLAY (PRIMARY POSITION) */}
          {tierBadge && (
            <div className="mb-12">
              <TierBadgeDisplay tierBadge={tierBadge} />
            </div>
          )}

          <div
            className={`grid gap-8 mb-12 ${scanResults?.bim_performance ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-2"}`}
          >
            <MotionCapture
              videoRef={videoRef}
              isRecording={isRecording}
              hasRecording={hasRecording}
              isProcessing={isProcessing}
              scanResults={scanResults}
              streamRef={streamRef}
              startCamera={startCamera}
              startRecording={startRecording}
              stopRecording={stopRecording}
              processMotionScan={processMotionScan}
              resetScan={resetScan}
            />

            {scanResults?.bim_performance && (
              <div className="lg:col-span-1">
                <BIMPerformanceDisplay bimData={scanResults.bim_performance} />
              </div>
            )}

            <BasicResults scanResults={scanResults} />
          </div>

          {/* Institutional Features Panel */}
          {scanResults?.bim_performance && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
              <ScoutNotesPanel
                tierBadge={tierBadge?.new_badge}
                scoutNotes={scoutNotes}
                setScoutNotes={setScoutNotes}
                spikeEvents={spikeEvents}
              />

              <QRFlyerPanel
                sessionId={sessionId}
                scanResults={scanResults}
                scoutNotes={scoutNotes}
                tierBadge={tierBadge?.new_badge}
                spikeEvents={spikeEvents}
                selectedSport={selectedSport}
                recordingAngle={recordingAngle}
                recordingDuration={recordingDuration}
                user={user}
              />
            </div>
          )}

          {/* 🔥 BIOMECHANICAL HEATMAP ANALYSIS */}
          {biomechanicalHeatmap && (
            <div className="mb-12">
              <BiomechanicalHeatmap heatmapData={biomechanicalHeatmap} />
            </div>
          )}

          {/* 🧭 COALITION TELEMETRY LOOP - Complete 4-Chart System */}
          {scanResults?.bim_performance && (
            <div className="mb-12">
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <Activity className="w-6 h-6 text-[#B8860B]" />
                    <div>
                      <h3 className="text-xl font-semibold text-[#1D2B3D]">
                        Coalition Telemetry Loop
                      </h3>
                      <p className="text-sm text-gray-500">
                        Complete biometric trade analysis across all audience
                        verticals
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>4/4 Charts Active</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  {/* 1. Predictive Trade-Type Chart → Finance routing */}
                  <div className="border border-gray-100 rounded-lg p-4">
                    <div className="mb-3">
                      <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                        <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                          1
                        </span>
                        <span>Predictive Trade-Type</span>
                      </h4>
                      <p className="text-xs text-gray-500">
                        Finance routing & institutional investors
                      </p>
                    </div>
                    <BIMPerformanceDisplay
                      bimData={{
                        performance_index: {
                          overall_score: 85,
                          consistency_score: 92,
                          power_index: 78,
                          endurance_rating: 88,
                          technical_proficiency: 91,
                        },
                        sport_type: "wrestling",
                      }}
                      chartMode="predictive_trade"
                      className="h-80"
                    />
                  </div>

                  {/* 2. BVI Tactical Chart → Coaching and scouting */}
                  <div className="border border-gray-100 rounded-lg p-4">
                    <div className="mb-3">
                      <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                          2
                        </span>
                        <span>BVI Tactical Analysis</span>
                      </h4>
                      <p className="text-xs text-gray-500">
                        Coaching insights & scouting optimization
                      </p>
                    </div>
                    <BIMPerformanceDisplay
                      bimData={{
                        performance_index: {
                          overall_score: 87,
                          consistency_score: 89,
                          tactical_efficiency: 94,
                          decision_making: 86,
                          pressure_handling: 82,
                        },
                        sport_type: "rugby",
                      }}
                      chartMode="bvi_tactical"
                      className="h-80"
                    />
                  </div>

                  {/* 3. Fan-Focused Chart → Cinematic broadcast overlays */}
                  <div className="border border-gray-100 rounded-lg p-4">
                    <div className="mb-3">
                      <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                        <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded">
                          3
                        </span>
                        <span>Fan Cinematic Display</span>
                      </h4>
                      <p className="text-xs text-gray-500">
                        Broadcast overlays & fan engagement
                      </p>
                    </div>
                    <BIMPerformanceDisplay
                      bimData={{
                        performance_index: {
                          overall_score: 91,
                          consistency_score: 88,
                          spike_score: 96,
                          accuracy_rating: 89,
                          power_consistency: 85,
                        },
                        sport_type: "tennis",
                      }}
                      chartMode="fan_cinematic"
                      className="h-80"
                    />
                  </div>

                  {/* 4. Regulatory Phase Chart → Institutional modeling and compliance */}
                  <div className="border border-gray-100 rounded-lg p-4">
                    <div className="mb-3">
                      <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                        <span className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded">
                          4
                        </span>
                        <span>Regulatory Phase Analysis</span>
                      </h4>
                      <p className="text-xs text-gray-500">
                        Compliance modeling & institutional partnerships
                      </p>
                    </div>
                    <RegulatoryPhaseCandlestick
                      biometricData={{
                        consistency_score: 92,
                        compliance_rating: 88,
                        trade_efficiency: 85,
                        regulatory_alignment: 91,
                      }}
                      tierLevel={4}
                      jurisdiction="partial"
                      onSwapEligibilityChange={(eligible) => {
                        console.log("LSOC Swap Eligibility:", eligible);
                      }}
                      className="h-80"
                    />
                  </div>
                </div>

                {/* Coalition Completion Status */}
                <div className="mt-6 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                      <Award className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-blue-900">
                        Coalition Telemetry Complete
                      </h4>
                      <p className="text-sm text-blue-700">
                        Full biometric trade analysis deployed across all
                        audience verticals. Ready for institutional onboarding
                        and coalition-grade investor modeling.
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-blue-600 font-medium">
                        LSOC Eligible
                      </div>
                      <div className="text-xs text-blue-500">
                        Tier 4 • Partial Compliance
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <ScanHistory scanHistory={scanHistory} />
        </div>
      </div>
    </div>
  );
}
