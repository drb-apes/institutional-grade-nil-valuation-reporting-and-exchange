"use client";

import { useState, useEffect } from "react";
import {
  Play,
  Search,
  Filter,
  Grid,
  List,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  Download,
  Settings,
  Calendar,
  User,
  Shield,
  Trophy,
  Clock,
  Tag,
  ChevronDown,
  SortAsc,
  SortDesc,
  ArrowLeft,
} from "lucide-react";
import useUser from "@/utils/useUser";

// Utility functions
const formatDuration = (seconds) => {
  if (!seconds) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
};

const formatFileSize = (mb) => {
  if (!mb) return "Unknown";
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(1)} GB`;
};

const getPrivacyIcon = (level) => {
  switch (level) {
    case "public":
      return "🌍";
    case "team_only":
      return "👥";
    case "coach_only":
      return "👨‍🏫";
    case "private":
      return "🔒";
    default:
      return "❓";
  }
};

const getSessionTypeColor = (type) => {
  switch (type) {
    case "training":
      return "bg-blue-100 text-blue-800";
    case "competition":
      return "bg-red-100 text-red-800";
    case "assessment":
      return "bg-green-100 text-green-800";
    case "motion_capture":
      return "bg-purple-100 text-purple-800";
    case "live_broadcast":
      return "bg-orange-100 text-orange-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

export default function VideoArchivePage() {
  const { data: user, loading } = useUser();
  const [videos, setVideos] = useState([]);
  const [filteredVideos, setFilteredVideos] = useState([]);
  const [userRole, setUserRole] = useState("fan");
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSport, setSelectedSport] = useState("all");
  const [selectedSessionType, setSelectedSessionType] = useState("all");
  const [selectedPrivacy, setSelectedPrivacy] = useState("all");
  const [sortBy, setSortBy] = useState("created_at");
  const [sortOrder, setSortOrder] = useState("desc");
  const [showFilters, setShowFilters] = useState(false);

  const sessionTypes = [
    { value: "all", label: "All Sessions" },
    { value: "training", label: "Training" },
    { value: "competition", label: "Competition" },
    { value: "assessment", label: "Assessment" },
    { value: "motion_capture", label: "Motion Capture" },
    { value: "live_broadcast", label: "Live Broadcast" },
  ];

  const sportCategories = [
    { value: "all", label: "All Sports" },
    { value: "Wrestling", label: "Wrestling" },
    { value: "Basketball", label: "Basketball" },
    { value: "Tennis", label: "Tennis" },
    { value: "American Football", label: "American Football" },
    { value: "Soccer", label: "Soccer" },
    { value: "Rugby", label: "Rugby" },
  ];

  const privacyLevels = [
    { value: "all", label: "All Access Levels" },
    { value: "public", label: "Public" },
    { value: "team_only", label: "Team Only" },
    { value: "coach_only", label: "Coach Only" },
    { value: "private", label: "Private" },
  ];

  useEffect(() => {
    fetchVideos();
  }, []);

  useEffect(() => {
    filterAndSortVideos();
  }, [
    videos,
    searchQuery,
    selectedSport,
    selectedSessionType,
    selectedPrivacy,
    sortBy,
    sortOrder,
  ]);

  const fetchVideos = async () => {
    try {
      setIsLoading(true);
      const response = await fetch("/api/video-archives");
      if (!response.ok) throw new Error("Failed to fetch videos");

      const data = await response.json();
      setVideos(data.videos || []);
      setUserRole(data.userRole || "fan");
    } catch (error) {
      console.error("Error fetching videos:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterAndSortVideos = () => {
    let filtered = [...videos];

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (video) =>
          video.video_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          video.athlete_name
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          video.tags?.some((tag) =>
            tag.toLowerCase().includes(searchQuery.toLowerCase()),
          ),
      );
    }

    // Apply sport filter
    if (selectedSport !== "all") {
      filtered = filtered.filter(
        (video) => video.sport_category === selectedSport,
      );
    }

    // Apply session type filter
    if (selectedSessionType !== "all") {
      filtered = filtered.filter(
        (video) => video.session_type === selectedSessionType,
      );
    }

    // Apply privacy filter
    if (selectedPrivacy !== "all") {
      filtered = filtered.filter(
        (video) => video.privacy_level === selectedPrivacy,
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aVal = a[sortBy];
      let bVal = b[sortBy];

      if (sortBy === "created_at") {
        aVal = new Date(aVal);
        bVal = new Date(bVal);
      }

      if (sortOrder === "asc") {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });

    setFilteredVideos(filtered);
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#B8860B] mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading video archive...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <a
                href="/"
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-[#1D2B3D]" />
              </a>
              <div>
                <h1 className="text-2xl font-bold text-[#1D2B3D]">
                  Video Archive
                </h1>
                <p className="text-gray-600">
                  {filteredVideos.length} videos •{" "}
                  {userRole === "athlete"
                    ? "Athlete"
                    : userRole === "institutional"
                      ? "Coach/Scout"
                      : "Fan"}{" "}
                  access
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-gray-100 rounded-lg">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-2 rounded-lg transition-colors ${
                    viewMode === "grid"
                      ? "bg-white shadow text-[#B8860B]"
                      : "text-gray-500"
                  }`}
                >
                  <Grid className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`p-2 rounded-lg transition-colors ${
                    viewMode === "list"
                      ? "bg-white shadow text-[#B8860B]"
                      : "text-gray-500"
                  }`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 min-w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search videos, athletes, or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
              />
            </div>

            {/* Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="w-5 h-5" />
              <span>Filters</span>
              <ChevronDown
                className={`w-4 h-4 transition-transform ${showFilters ? "rotate-180" : ""}`}
              />
            </button>

            {/* Sort */}
            <select
              value={`${sortBy}-${sortOrder}`}
              onChange={(e) => {
                const [field, order] = e.target.value.split("-");
                setSortBy(field);
                setSortOrder(order);
              }}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
            >
              <option value="created_at-desc">Newest First</option>
              <option value="created_at-asc">Oldest First</option>
              <option value="video_title-asc">Title A-Z</option>
              <option value="video_title-desc">Title Z-A</option>
              <option value="view_count-desc">Most Viewed</option>
              <option value="likes_count-desc">Most Liked</option>
            </select>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sport Category
                </label>
                <select
                  value={selectedSport}
                  onChange={(e) => setSelectedSport(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  {sportCategories.map((sport) => (
                    <option key={sport.value} value={sport.value}>
                      {sport.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Session Type
                </label>
                <select
                  value={selectedSessionType}
                  onChange={(e) => setSelectedSessionType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  {sessionTypes.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>

              {(userRole === "institutional" || userRole === "dao_member") && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Privacy Level
                  </label>
                  <select
                    value={selectedPrivacy}
                    onChange={(e) => setSelectedPrivacy(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    {privacyLevels.map((level) => (
                      <option key={level.value} value={level.value}>
                        {level.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Video Grid/List */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {filteredVideos.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Play className="w-16 h-16 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No videos found
            </h3>
            <p className="text-gray-600">
              Try adjusting your search or filters
            </p>
          </div>
        ) : viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredVideos.map((video) => (
              <VideoCard key={video.id} video={video} userRole={userRole} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredVideos.map((video) => (
              <VideoListItem key={video.id} video={video} userRole={userRole} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Video Card Component
function VideoCard({ video, userRole }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
      {/* Thumbnail */}
      <div className="relative aspect-video bg-gray-900">
        {video.thumbnail_url ? (
          <img
            src={video.thumbnail_url}
            alt={video.video_title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Play className="w-12 h-12 text-white" />
          </div>
        )}

        {/* Duration */}
        <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
          {formatDuration(video.duration_seconds)}
        </div>

        {/* Privacy Level */}
        <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
          {getPrivacyIcon(video.privacy_level)}
        </div>

        {/* Video Quality */}
        <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
          {video.video_quality}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-semibold text-[#1D2B3D] mb-2 line-clamp-2">
          {video.video_title}
        </h3>

        <div className="space-y-2 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <User className="w-4 h-4" />
            <span>{video.athlete_name || "Unknown Athlete"}</span>
          </div>

          <div className="flex items-center space-x-2">
            <Trophy className="w-4 h-4" />
            <span>{video.sport_category}</span>
          </div>

          <div className="flex items-center space-x-2">
            <Tag className="w-4 h-4" />
            <span
              className={`px-2 py-1 rounded text-xs ${getSessionTypeColor(video.session_type)}`}
            >
              {video.session_type}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4" />
            <span>{new Date(video.created_at).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Metrics */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <Eye className="w-4 h-4" />
              <span>{video.view_count}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Heart className="w-4 h-4" />
              <span>{video.likes_count}</span>
            </div>
            <div className="flex items-center space-x-1">
              <MessageCircle className="w-4 h-4" />
              <span>{video.comments_count}</span>
            </div>
          </div>

          <button className="p-2 text-[#B8860B] hover:bg-[#B8860B]/10 rounded-lg transition-colors">
            <Play className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

// Video List Item Component
function VideoListItem({ video, userRole }) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center space-x-4">
        {/* Thumbnail */}
        <div className="relative w-40 h-24 bg-gray-900 rounded-lg overflow-hidden flex-shrink-0">
          {video.thumbnail_url ? (
            <img
              src={video.thumbnail_url}
              alt={video.video_title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Play className="w-6 h-6 text-white" />
            </div>
          )}
          <div className="absolute bottom-1 right-1 bg-black/70 text-white text-xs px-1 py-0.5 rounded">
            {formatDuration(video.duration_seconds)}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-[#1D2B3D] mb-2">
            {video.video_title}
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
            <div>
              <span className="font-medium">Athlete:</span>{" "}
              {video.athlete_name || "Unknown"}
            </div>
            <div>
              <span className="font-medium">Sport:</span> {video.sport_category}
            </div>
            <div>
              <span className="font-medium">Type:</span>
              <span
                className={`ml-1 px-2 py-1 rounded text-xs ${getSessionTypeColor(video.session_type)}`}
              >
                {video.session_type}
              </span>
            </div>
            <div>
              <span className="font-medium">Date:</span>{" "}
              {new Date(video.created_at).toLocaleDateString()}
            </div>
          </div>

          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <Eye className="w-4 h-4" />
                <span>{video.view_count} views</span>
              </div>
              <div className="flex items-center space-x-1">
                <Heart className="w-4 h-4" />
                <span>{video.likes_count} likes</span>
              </div>
              <div className="flex items-center space-x-1">
                <MessageCircle className="w-4 h-4" />
                <span>{video.comments_count} comments</span>
              </div>
              <div className="flex items-center space-x-1">
                <Shield className="w-4 h-4" />
                <span>
                  {getPrivacyIcon(video.privacy_level)} {video.privacy_level}
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors">
                <Share2 className="w-4 h-4" />
              </button>
              {userRole === "institutional" && (
                <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors">
                  <Download className="w-4 h-4" />
                </button>
              )}
              <button className="px-4 py-2 bg-[#B8860B] text-white rounded-lg hover:bg-[#A0750A] transition-colors">
                Watch
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
