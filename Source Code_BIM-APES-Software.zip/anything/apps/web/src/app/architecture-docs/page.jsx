export default function ArchitectureDocs() {
  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-[#0A0E27] border-b border-gray-800">
        <div className="max-w-5xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            BIM-APES System Architecture
          </h1>
          <p className="text-xl text-gray-400">
            Universal Biometric Finance Engine — Multi-Sport, Multi-Org
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* Executive Summary */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-[#0A0E27] mb-4">
            Executive Summary
          </h2>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <p className="text-gray-700 mb-4">
              <strong>BIM-APES</strong> (Biometric Investment Model & Athlete
              Performance Equity System) is a universal biometric finance engine
              that abstracts to any sport and any organization tier.
            </p>
            <p className="text-gray-700 mb-4">
              When someone asks:{" "}
              <em>"So is this like a motorsport/NASCAR thing?"</em>
            </p>
            <p className="text-gray-700 font-medium">
              Your answer:{" "}
              <strong>
                "Motorsport is just one lane. BIM-APES is a universal biometric
                finance engine: we plug into any sport, layer athlete
                performance into indices, and then give organizations NIL
                valuation, risk protection, and tradable exposure — whether
                that's a high-school basketball program, a national wrestling
                federation, an MLS academy, or an F1 team."
              </strong>
            </p>
          </div>
        </section>

        {/* NEW: Wearable Mesh Architecture Callout */}
        <section className="mb-12">
          <div className="bg-gradient-to-r from-[#00D9FF]/10 to-[#C4A661]/10 rounded-xl p-8 border-2 border-[#00D9FF]/30">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 rounded-full bg-[#00D9FF] flex items-center justify-center flex-shrink-0">
                <svg
                  className="w-8 h-8 text-black"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"
                  />
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-[#0A0E27] mb-3">
                  🔌 Plug & Play Wearable Mesh Architecture
                </h3>
                <p className="text-gray-700 mb-4">
                  <strong>Any device, any sport, any location.</strong> Our
                  universal BIM-APES schema system automatically transforms raw
                  wearable data into tradable financial indices — supporting 50+
                  device types across Bluetooth, ANT+, WiFi, and NFC with
                  offline-first mesh networking.
                </p>
                <a
                  href="/wearable-mesh-architecture"
                  className="inline-flex items-center gap-2 bg-[#00D9FF] text-black px-6 py-3 rounded-lg font-semibold hover:bg-[#00B8DB] transition-colors"
                >
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 7l5 5m0 0l-5 5m5-5H6"
                    />
                  </svg>
                  Explore Device Registry & Schema Mappings
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* 5-Layer Architecture */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-[#0A0E27] mb-6">
            5-Layer System Architecture
          </h2>

          <div className="space-y-6">
            {/* Layer 1 */}
            <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-[#00D9FF]">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0 text-xl">
                  1
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#0A0E27] mb-2">
                    Collection Layer
                  </h3>
                  <p className="text-gray-600 mb-3">
                    Sport-agnostic data capture via mobile app, device mesh, and
                    manual input
                  </p>
                </div>
              </div>
              <div className="ml-16">
                <h4 className="font-semibold text-gray-800 mb-2">Inputs:</h4>
                <ul className="list-disc list-inside text-gray-700 space-y-1 mb-4">
                  <li>Phone camera (motion capture)</li>
                  <li>Bluetooth wearables (HR, GPS, IMU, etc.)</li>
                  <li>Game logs / tracking data</li>
                  <li>Manual tags (coach, scout, staff)</li>
                </ul>
                <h4 className="font-semibold text-gray-800 mb-2">
                  Core Functions:
                </h4>
                <ul className="list-disc list-inside text-gray-700 space-y-1">
                  <li>Motion capture & sensor ingestion</li>
                  <li>Mesh networking & offline sync</li>
                  <li>
                    NIL onboarding (identity, rights, consents, wallet link)
                  </li>
                </ul>
                <p className="mt-3 text-sm text-gray-600 italic">
                  This layer doesn't "care" what sport it's in. Job: capture
                  everything in a standard way.
                </p>
              </div>
            </div>

            {/* Layer 2 */}
            <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-[#00D9FF]">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0 text-xl">
                  2
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#0A0E27] mb-2">
                    Context Layer
                  </h3>
                  <p className="text-gray-600 mb-3">
                    Sport + organization adapters that define rules,
                    constraints, and metrics
                  </p>
                </div>
              </div>
              <div className="ml-16">
                <h4 className="font-semibold text-gray-800 mb-2">
                  Sport Adapter:
                </h4>
                <p className="text-gray-700 mb-2">
                  Each sport defines a profile with:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-1 mb-4">
                  <li>
                    <strong>Feature map:</strong> Wrestling → control time,
                    takedowns | Basketball → speed bursts, spacing
                  </li>
                  <li>
                    <strong>Derived metrics:</strong> Raw signals →
                    Explosiveness, Consistency, Load/Fatigue, Decision Quality,
                    Recovery
                  </li>
                  <li>
                    <strong>Scoring schema:</strong> How metrics roll up into
                    PPI/TPI/LPI
                  </li>
                </ul>
                <h4 className="font-semibold text-gray-800 mb-2">
                  Organization Adapter:
                </h4>
                <p className="text-gray-700 mb-2">Each org type defines:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-1">
                  <li>
                    <strong>Policy constraints:</strong> NIL rules, age rules,
                    training hours, compliance
                  </li>
                  <li>
                    <strong>Visibility rules:</strong> What coaches see vs
                    agents vs sponsors vs fans
                  </li>
                  <li>
                    <strong>Market permissions:</strong> Who can hold swaps,
                    fund pools, earn stipends
                  </li>
                </ul>
                <div className="mt-4 bg-gray-50 rounded p-4">
                  <p className="text-sm font-medium text-gray-800 mb-2">
                    Supported Contexts:
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-xs font-semibold text-gray-600 mb-1">
                        10 Sports:
                      </p>
                      <p className="text-xs text-gray-700">
                        Wrestling, Basketball, Tennis, Pickleball, American
                        Football, Rugby, Soccer, Track & Field, Esports,
                        Motorsport
                      </p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-600 mb-1">
                        9 Org Tiers:
                      </p>
                      <p className="text-xs text-gray-700">
                        Youth Academy, High School, Junior College, NCAA D1/D2,
                        Semi-Pro, Professional, National Federation, Multi-Sport
                        Coalition
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Layer 3 */}
            <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-[#00D9FF]">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0 text-xl">
                  3
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#0A0E27] mb-2">
                    Analytics Layer
                  </h3>
                  <p className="text-gray-600 mb-3">
                    Universal performance engine that computes PPI/TPI/LPI for
                    any context
                  </p>
                </div>
              </div>
              <div className="ml-16">
                <h4 className="font-semibold text-gray-800 mb-2">
                  Core Capabilities:
                </h4>
                <ul className="list-disc list-inside text-gray-700 space-y-1 mb-4">
                  <li>
                    <strong>PPI</strong> — Player Performance Index (per
                    athlete)
                  </li>
                  <li>
                    <strong>TPI</strong> — Team Performance Index (per
                    roster/unit)
                  </li>
                  <li>
                    <strong>LPI</strong> — League/Federation/Coalition
                    Performance Index
                  </li>
                  <li>
                    <strong>Velocity</strong> — Rate of improvement over time
                  </li>
                  <li>
                    <strong>Consistency</strong> — Performance stability
                  </li>
                  <li>
                    <strong>Learning Curve</strong> — Adaptation rate
                  </li>
                  <li>
                    <strong>Forecasting</strong> — 30/60/90-day projections
                  </li>
                  <li>
                    <strong>Risk Assessment</strong> — Injury risk & stress
                    bands
                  </li>
                  <li>
                    <strong>Breakout Probability</strong> — Likelihood of
                    performance spike
                  </li>
                </ul>
                <p className="text-sm text-gray-600 italic">
                  Converts sport-specific features into universal
                  financial-grade indices.
                </p>
              </div>
            </div>

            {/* Layer 4 */}
            <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-[#00D9FF]">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0 text-xl">
                  4
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#0A0E27] mb-2">
                    Market Layer
                  </h3>
                  <p className="text-gray-600 mb-3">
                    NIL valuation, swaps, and trading engine (context-aware)
                  </p>
                </div>
              </div>
              <div className="ml-16">
                <h4 className="font-semibold text-gray-800 mb-2">
                  NIL Swaps (Universal Patterns):
                </h4>
                <ul className="list-disc list-inside text-gray-700 space-y-1 mb-4">
                  <li>
                    <strong>Player Swap:</strong> Hedge one athlete's NIL
                    against PPI decline
                  </li>
                  <li>
                    <strong>Team Basket Swap:</strong> Roster-level hedge via
                    TPI
                  </li>
                  <li>
                    <strong>Index Swap:</strong> League/federation/coalition
                    hedge via LPI
                  </li>
                </ul>
                <h4 className="font-semibold text-gray-800 mb-2">
                  Trading & Triggers:
                </h4>
                <ul className="list-disc list-inside text-gray-700 space-y-1 mb-4">
                  <li>
                    Mesh trading (local markets: camp, combine, tournament,
                    league)
                  </li>
                  <li>
                    Automated triggers (injury risk → auto-hedge, breakout →
                    rebalance)
                  </li>
                  <li>
                    Contribution pools (fans fund milestones for any sport, any
                    level)
                  </li>
                </ul>
                <p className="text-sm text-gray-600 italic">
                  Doesn't assume any specific sport — assumes indexed
                  performance with volatility.
                </p>
              </div>
            </div>

            {/* Layer 5 */}
            <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-[#00D9FF]">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0 text-xl">
                  5
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#0A0E27] mb-2">
                    Governance Layer
                  </h3>
                  <p className="text-gray-600 mb-3">
                    Web3 milestones, stipends, treasury, and DAO governance
                  </p>
                </div>
              </div>
              <div className="ml-16">
                <ul className="list-disc list-inside text-gray-700 space-y-1 mb-4">
                  <li>
                    <strong>Milestone contracts:</strong> Academic + performance
                    + participation + health milestones (configurable per org)
                  </li>
                  <li>
                    <strong>Micro-stipends:</strong> Triggered by milestone
                    completions in any sport
                  </li>
                  <li>
                    <strong>Treasury & DAO logic:</strong> Coalition funds,
                    national programs, multi-club ownership pools
                  </li>
                  <li>
                    <strong>Voting & governance:</strong> Org-level decisions,
                    policy changes, revenue-sharing schemes
                  </li>
                </ul>
                <p className="text-sm text-gray-600 italic">
                  Gives institutional legitimacy and shared control across very
                  different organizations.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* API Reference */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-[#0A0E27] mb-6">
            Core API Endpoints
          </h2>
          <div className="space-y-4">
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="font-mono text-sm text-[#00D9FF] mb-2">
                GET /api/context/sport-profiles
              </div>
              <p className="text-gray-700 text-sm">
                Retrieve all supported sport profiles with feature maps, derived
                metrics, and scoring schemas.
              </p>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="font-mono text-sm text-[#00D9FF] mb-2">
                GET /api/context/org-profiles
              </div>
              <p className="text-gray-700 text-sm">
                Retrieve all supported organization profiles with policy
                constraints, visibility rules, and market permissions.
              </p>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="font-mono text-sm text-[#00D9FF] mb-2">
                POST /api/analytics/universal-engine
              </div>
              <p className="text-gray-700 text-sm mb-2">
                Run universal analytics for any sport/org context. Supports
                multiple analysis types:
              </p>
              <ul className="list-disc list-inside text-gray-700 text-sm ml-4">
                <li>
                  <code className="bg-gray-100 px-1">ppi</code> — Calculate
                  Player Performance Index
                </li>
                <li>
                  <code className="bg-gray-100 px-1">tpi</code> — Calculate Team
                  Performance Index
                </li>
                <li>
                  <code className="bg-gray-100 px-1">lpi</code> — Calculate
                  League/Federation Index
                </li>
                <li>
                  <code className="bg-gray-100 px-1">velocity</code> — Calculate
                  improvement velocity
                </li>
                <li>
                  <code className="bg-gray-100 px-1">consistency</code> —
                  Calculate performance consistency
                </li>
                <li>
                  <code className="bg-gray-100 px-1">forecast</code> — Generate
                  30/60/90-day forecasts
                </li>
                <li>
                  <code className="bg-gray-100 px-1">injury_risk</code> — Assess
                  injury risk
                </li>
                <li>
                  <code className="bg-gray-100 px-1">full_analysis</code> — Run
                  complete analysis suite
                </li>
              </ul>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="font-mono text-sm text-[#00D9FF] mb-2">
                GET
                /api/analytics/universal-engine?athlete_id=X&sport_id=Y&org_id=Z
              </div>
              <p className="text-gray-700 text-sm">
                Fetch complete analytics for a specific athlete in a given
                sport/org context.
              </p>
            </div>
          </div>
        </section>

        {/* Technical Stack */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-[#0A0E27] mb-6">
            Technical Stack
          </h2>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">
                  Frontend (Web)
                </h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• React / Next.js</li>
                  <li>• Tailwind CSS</li>
                  <li>• React Query (@tanstack/react-query)</li>
                  <li>• Zustand (state management)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">
                  Frontend (Mobile)
                </h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• React Native / Expo</li>
                  <li>• Expo Router</li>
                  <li>• Mesh networking (offline-first)</li>
                  <li>• Motion capture & Bluetooth sensors</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Backend</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Node.js / Next.js API Routes</li>
                  <li>• PostgreSQL 17</li>
                  <li>• Authentication (NextAuth)</li>
                  <li>• Universal Analytics Engine (custom)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">
                  Infrastructure
                </h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Anything Platform (deployment)</li>
                  <li>• Database migrations (version-controlled)</li>
                  <li>• Context-aware API routing</li>
                  <li>• Multi-tenant architecture</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Next Steps */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-[#0A0E27] mb-6">
            Quick Start
          </h2>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <ol className="space-y-4 text-gray-700">
              <li className="flex gap-3">
                <span className="font-bold text-[#00D9FF]">1.</span>
                <div>
                  <strong>Explore the Universal Dashboard:</strong> Visit{" "}
                  <a
                    href="/universal-dashboard"
                    className="text-[#00D9FF] underline"
                  >
                    /universal-dashboard
                  </a>{" "}
                  to select a sport and organization context, then run sample
                  analytics.
                </div>
              </li>
              <li className="flex gap-3">
                <span className="font-bold text-[#00D9FF]">2.</span>
                <div>
                  <strong>Review existing sport-specific modules:</strong> Check
                  out specialized interfaces like{" "}
                  <a href="/motion-scan" className="text-[#00D9FF] underline">
                    /motion-scan
                  </a>{" "}
                  and{" "}
                  <a href="/coach-portal" className="text-[#00D9FF] underline">
                    /coach-portal
                  </a>
                  .
                </div>
              </li>
              <li className="flex gap-3">
                <span className="font-bold text-[#00D9FF]">3.</span>
                <div>
                  <strong>Test the mobile app:</strong> Open the mobile preview
                  to see mesh networking, motion capture, and offline sync in
                  action.
                </div>
              </li>
              <li className="flex gap-3">
                <span className="font-bold text-[#00D9FF]">4.</span>
                <div>
                  <strong>Integrate with your org:</strong> Use the API to
                  connect your organization's existing data streams to the
                  universal analytics engine.
                </div>
              </li>
            </ol>
          </div>
        </section>

        {/* Footer */}
        <div className="text-center text-gray-500 text-sm">
          <p>
            BIM-APES Universal Platform — Built with ❤️ for athletes, coaches,
            and organizations worldwide
          </p>
        </div>
      </div>
    </div>
  );
}
