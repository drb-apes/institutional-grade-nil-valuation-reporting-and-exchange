"use client";

import { useState } from "react";
import {
  Brain,
  Activity,
  TrendingUp,
  Shield,
  Zap,
  Target,
  Users,
  BarChart3,
} from "lucide-react";

export default function PlatformHome() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-slate-900/50 backdrop-blur-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">
                BLEDSOE
              </h1>
              <p className="text-xs text-slate-400 tracking-wide uppercase">
                Investment Management
              </p>
            </div>
            <nav className="flex items-center gap-8">
              <a
                href="/"
                className="text-slate-300 hover:text-white transition-colors text-sm font-medium"
              >
                Home
              </a>
              <a
                href="/analytics-dashboard"
                className="text-slate-300 hover:text-white transition-colors text-sm font-medium"
              >
                Intelligence
              </a>
              <a
                href="/coach-portal"
                className="text-slate-300 hover:text-white transition-colors text-sm font-medium"
              >
                Coach Portal
              </a>
              <button
                onClick={() => (window.location.href = "/account/signin")}
                className="bg-slate-700 hover:bg-slate-600 text-white px-6 py-2 rounded-lg text-sm font-semibold transition-all"
              >
                Get Started
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-6xl font-bold text-white mb-4 tracking-tight">
            BIM-APES
          </h1>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-400 to-purple-400 mx-auto mb-8"></div>
          <h2 className="text-2xl text-slate-300 mb-4 font-light">
            Biometric Intelligence Management System
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Coalition-Grade Analytics for Performance & NIL Valuation
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 max-w-5xl mx-auto">
            <StatCard number="4" label="Intelligence Engines" />
            <StatCard number="10+" label="AR Overlays" />
            <StatCard number="1000" label="Biometric Indices" />
            <StatCard number="24/7" label="Real-Time Analysis" />
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent"></div>
      </div>

      {/* Choose Dashboard Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-4">
            Choose Your Dashboard
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-400 to-purple-400 mx-auto mb-16"></div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Intelligence Dashboard */}
            <DashboardCard
              title="Intelligence Dashboard"
              icon={<Brain className="w-8 h-8" />}
              badge="NEW"
              description="Complete real-time biomechanical intelligence with stress, fatigue, recovery, and training analysis plus market signals"
              features={[
                "Stress Intelligence (joint torque, asymmetry, HRV)",
                "Fatigue Intelligence (ACWR, stride analysis, hydration)",
                "Recovery Intelligence (sleep, muscle soreness, tissue repair)",
                "Training Intelligence (ACWR, velocity loss, technique drift)",
                "Market Intelligence (bull/bear signals, NIL momentum)",
                "AR Biomechanical Overlays",
                "BiomechFlow™ Charts",
                "Trading Signals (LONG, SHORT, ARBITRAGE, BREAKOUT)",
              ]}
              buttonText="Launch Intelligence Dashboard"
              buttonColor="from-blue-600 to-purple-600"
              onClick={() => (window.location.href = "/analytics-dashboard")}
            />

            {/* Coach Dashboard */}
            <DashboardCard
              title="Coach Dashboard"
              icon={<Activity className="w-8 h-8" />}
              description="Advanced analytics and biometric tracking for athletic performance optimization and team management"
              features={[
                "Athlete roster management",
                "Performance session tracking",
                "NIL valuation analysis",
                "Mispricing detection",
                "AR biomechanical visualization",
                "Risk forecasting",
                "BiomechFlow™ charts",
                "Market trend intelligence",
              ]}
              buttonText="Launch Coach Dashboard"
              buttonColor="from-green-600 to-emerald-600"
              onClick={() => (window.location.href = "/coach-portal")}
            />
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent"></div>
      </div>

      {/* Platform Capabilities */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-4">
            Platform Capabilities
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-400 to-purple-400 mx-auto mb-16"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <CapabilityCard
              icon={<TrendingUp className="w-8 h-8" />}
              title="Market Intelligence"
              description="Bull/bear signal detection with NIL momentum tracking and trading recommendations"
            />
            <CapabilityCard
              icon={<Shield className="w-8 h-8" />}
              title="Risk Management"
              description="ACWR monitoring, injury prediction, and performance breakdown prevention"
            />
            <CapabilityCard
              icon={<Zap className="w-8 h-8" />}
              title="Real-Time Alerts"
              description="Critical stress, fatigue, and recovery alerts with actionable intervention protocols"
            />
            <CapabilityCard
              icon={<Target className="w-8 h-8" />}
              title="Biomechanical Analysis"
              description="Joint torque modeling, asymmetry detection, and AR spatial overlays"
            />
          </div>
        </div>
      </section>

      {/* Four Intelligence Engines */}
      <section className="py-20 px-6 bg-gradient-to-b from-slate-900 to-slate-800">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-4">
            Four Intelligence Engines Working in Harmony
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-400 to-purple-400 mx-auto mb-16"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <EngineCard
              icon={<Shield className="w-12 h-12" />}
              title="Stress Intelligence"
              color="from-red-500/20 to-orange-500/20"
              borderColor="border-red-400/30"
              iconColor="text-red-400"
              description="Joint torque analysis, asymmetry detection, HRV monitoring for injury prevention"
            />
            <EngineCard
              icon={<Zap className="w-12 h-12" />}
              title="Fatigue Intelligence"
              color="from-yellow-500/20 to-amber-500/20"
              borderColor="border-yellow-400/30"
              iconColor="text-yellow-400"
              description="ACWR tracking, stride analysis, hydration monitoring for performance optimization"
            />
            <EngineCard
              icon={<Activity className="w-12 h-12" />}
              title="Recovery Intelligence"
              color="from-green-500/20 to-emerald-500/20"
              borderColor="border-green-400/30"
              iconColor="text-green-400"
              description="Sleep quality, muscle soreness, tissue repair analysis for optimal recovery"
            />
            <EngineCard
              icon={<BarChart3 className="w-12 h-12" />}
              title="Market Intelligence"
              color="from-blue-500/20 to-cyan-500/20"
              borderColor="border-blue-400/30"
              iconColor="text-blue-400"
              description="Bull/bear signals, NIL momentum tracking, arbitrage detection for trading"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-slate-900 py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-white mb-2">
              BLEDSOE INVESTMENT MANAGEMENT
            </h3>
            <p className="text-slate-400 text-sm">
              Powered by BIM-APES Software
            </p>
          </div>

          <div className="border-t border-white/10 pt-8">
            <p className="text-slate-500 text-xs text-center mb-4">
              © Dashawn Ramel Bledsoe / NIBLS Inc. All Rights Reserved.
            </p>
            <p className="text-slate-500 text-xs text-center max-w-4xl mx-auto">
              BIM-APES Software is developed and published by Bledsoe Investment
              Management, a division of NIBLS Inc. Software License: Apache
              License, Version 2.0. Content License: Creative Commons
              Attribution–NonCommercial–NoDerivatives 4.0 International License.
            </p>
            <div className="text-center mt-4">
              <a
                href="https://www.linkedin.com/company/bledsoe-investment-management-ai-consultancy-firm/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:text-blue-300 text-xs underline"
              >
                Contact: bim-apes@consultant.com
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function StatCard({ number, label }) {
  return (
    <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl p-6 border border-slate-700/50 hover:border-slate-600 transition-all">
      <div className="text-4xl font-bold text-slate-300 mb-2">{number}</div>
      <div className="text-sm text-slate-400">{label}</div>
    </div>
  );
}

function DashboardCard({
  title,
  icon,
  badge,
  description,
  features,
  buttonText,
  buttonColor,
  onClick,
}) {
  return (
    <div className="bg-slate-800/30 backdrop-blur-lg rounded-2xl p-8 border border-slate-700/50 hover:border-slate-600 transition-all">
      <div className="flex items-start gap-4 mb-6">
        <div className="bg-slate-700/50 p-3 rounded-xl text-blue-400">
          {icon}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-2xl font-bold text-white">{title}</h3>
            {badge && (
              <span className="bg-gradient-to-r from-yellow-500 to-orange-500 text-xs font-bold text-white px-3 py-1 rounded-full">
                {badge}
              </span>
            )}
          </div>
          <p className="text-slate-300 text-sm leading-relaxed">
            {description}
          </p>
        </div>
      </div>

      <div className="mb-8">
        <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wide">
          Key Features
        </h4>
        <ul className="space-y-2">
          {features.map((feature, idx) => (
            <li
              key={idx}
              className="flex items-start gap-3 text-slate-300 text-sm"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-2 flex-shrink-0"></div>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      <button
        onClick={onClick}
        className={`w-full bg-gradient-to-r ${buttonColor} text-white py-4 px-6 rounded-xl font-semibold hover:shadow-lg hover:shadow-blue-500/20 transition-all`}
      >
        {buttonText}
      </button>
    </div>
  );
}

function CapabilityCard({ icon, title, description }) {
  return (
    <div className="text-center">
      <div className="bg-amber-100/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-amber-200/20">
        <div className="text-amber-200">{icon}</div>
      </div>
      <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
      <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function EngineCard({
  icon,
  title,
  color,
  borderColor,
  iconColor,
  description,
}) {
  return (
    <div
      className={`bg-gradient-to-br ${color} backdrop-blur-lg rounded-2xl p-8 border ${borderColor} hover:scale-105 transition-all duration-300`}
    >
      <div className={`${iconColor} mb-6`}>{icon}</div>
      <h3 className="text-xl font-bold text-white mb-4">{title}</h3>
      <p className="text-slate-300 text-sm leading-relaxed">{description}</p>
    </div>
  );
}
