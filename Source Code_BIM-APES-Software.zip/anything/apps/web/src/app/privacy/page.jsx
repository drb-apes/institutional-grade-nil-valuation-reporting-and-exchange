import {
  Shield,
  AlertTriangle,
  Mail,
  Globe,
  FileText,
  Eye,
} from "lucide-react";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <header className="px-6 py-4 bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img
              src="https://ucarecdn.com/f8b235cc-3c56-4c0f-a2d1-b1546f00d742/-/format/auto/"
              alt="Bledsoe Investment Management"
              className="h-8 w-auto"
            />
          </div>
          <a
            href="/"
            className="text-[#1D2B3D] hover:text-[#B8860B] font-medium transition-colors"
          >
            Back to Home
          </a>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Important Disclaimer Banner */}
        <div className="bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-xl p-6 mb-8">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-6 h-6 text-[#B8860B] flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-semibold text-[#1D2B3D] mb-2">
                Important Disclaimer
              </h2>
              <p className="text-[#1D2B3D] text-lg leading-relaxed">
                <strong>
                  Bledsoe Investment Management does not provide personalized
                  investment advice or manage client assets. All simulations are
                  for educational and illustrative purposes only.
                </strong>
              </p>
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#1D2B3D] mb-4">
            Privacy Policy & Disclaimer Statement
          </h1>
          <div className="space-y-2 text-gray-600">
            <p>
              <strong>Effective Date:</strong> September 20, 2025
            </p>
            <p>
              <strong>Entity:</strong> Bledsoe Investment Management ("BIM")
            </p>
          </div>
        </div>

        {/* Policy Sections */}
        <div className="space-y-8">
          {/* Section 1 */}
          <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-semibold text-[#1D2B3D]">
                1. Educational Use Only
              </h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Bledsoe Investment Management does not provide personalized
              investment advice or manage client assets. All
              simulations—including Monte Carlo models, performance indexes, and
              valuation tools—are for educational and illustrative purposes
              only. No content on this site should be interpreted as financial,
              legal, or investment advice.
            </p>
          </div>

          {/* Section 2 */}
          <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                <Eye className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-semibold text-[#1D2B3D]">
                2. Data Collection & Usage
              </h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              We may collect anonymized session data, drill footage, and
              performance metrics to improve our simulation tools and user
              experience. This data is never sold, shared, or used to identify
              individuals unless explicitly authorized.
            </p>
          </div>

          {/* Section 3 */}
          <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-semibold text-[#1D2B3D]">
                3. Third-Party Tools
              </h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Our platform may integrate third-party services (e.g., analytics,
              video hosting, API endpoints). These services may collect usage
              data under their own privacy policies. BIM is not responsible for
              external data handling practices.
            </p>
          </div>

          {/* Section 4 */}
          <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-semibold text-[#1D2B3D]">
                4. User Responsibility
              </h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Users are responsible for how they interpret and apply simulation
              outputs. BIM does not guarantee future performance, recruitment
              outcomes, or financial results based on simulation data.
            </p>
          </div>

          {/* Section 5 */}
          <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-semibold text-[#1D2B3D]">
                5. Compliance & Exemption
              </h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              BIM operates as a simulation and modeling platform—not a
              registered investment adviser. We do not recommend securities,
              manage portfolios, or engage in regulated financial advising. For
              questions about compliance, please consult a licensed
              professional.
            </p>
          </div>

          {/* Section 6 */}
          <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-semibold text-[#1D2B3D]">
                6. Contact
              </h2>
            </div>
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                For privacy inquiries, data requests, or compliance questions:
              </p>
              <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-3 sm:space-y-0">
                <a
                  href="mailto:bim-apes@consultant.com"
                  className="flex items-center space-x-2 text-[#B8860B] hover:text-[#A0750A] font-medium transition-colors"
                >
                  <Mail className="w-5 h-5" />
                  <span>bim-apes@consultant.com</span>
                </a>
                <a
                  href="http://www.bimadvisor.xyz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-[#B8860B] hover:text-[#A0750A] font-medium transition-colors"
                >
                  <Globe className="w-5 h-5" />
                  <span>www.bimadvisor.xyz</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Legal Notice */}
        <div className="mt-12 p-6 bg-gray-100 rounded-xl border border-gray-300">
          <p className="text-sm text-gray-600 text-center leading-relaxed">
            <strong>Legal Notice:</strong> This platform provides educational
            simulations and modeling tools only. Users should consult licensed
            financial professionals for actual investment advice. BIM disclaims
            all liability for decisions made based on simulation outputs or
            platform content.
          </p>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-12">
          <a
            href="/"
            className="inline-flex items-center space-x-2 bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            <span>Return to Platform</span>
          </a>
        </div>
      </div>
    </div>
  );
}
