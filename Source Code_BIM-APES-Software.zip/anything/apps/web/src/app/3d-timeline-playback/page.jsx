"use client";

import { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Maximize,
  Grid3x3,
  Eye,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function ThreeDTimelinePlayback() {
  const { data: user, loading } = useUser();
  const [sessionId, setSessionId] = useState("");
  const [sport, setSport] = useState("soccer");
  const [timeline, setTimeline] = useState(null);
  const [loadingTimeline, setLoadingTimeline] = useState(false);
  const [error, setError] = useState(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [viewMode, setViewMode] = useState("3d"); // '3d' | 'tactical' | 'capsule'
  const [showPlaybook, setShowPlaybook] = useState(false);

  const canvasRef = useRef(null);
  const animationRef = useRef(null);

  // Sample athletes for demo
  const [athletes] = useState([
    { athleteId: 1, name: "Player 1", position: "Forward" },
    { athleteId: 2, name: "Player 2", position: "Midfielder" },
    { athleteId: 3, name: "Player 3", position: "Defender" },
  ]);

  const handleLoadSession = async () => {
    if (!sessionId) {
      setError("Please enter a session ID");
      return;
    }

    setLoadingTimeline(true);
    setError(null);

    try {
      const now = Date.now();
      const startTime = now - 3600000; // 1 hour ago
      const endTime = now;

      const response = await fetch("/api/spatial-intelligence/3d-mapping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          sport,
          athletes,
          startTime,
          endTime,
          venue: {
            name: "Demo Stadium",
            latRange: { min: 37.7, max: 37.8 },
            lngRange: { min: -122.5, max: -122.4 },
          },
          includePlaybook: true,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to load timeline");
      }

      const data = await response.json();
      setTimeline(data);
      setCurrentFrame(0);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingTimeline(false);
    }
  };

  // Playback controls
  useEffect(() => {
    if (!timeline || !isPlaying) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }

    const frameRate = timeline.frameRate * playbackSpeed;
    const frameInterval = 1000 / frameRate;
    let lastTime = Date.now();

    const animate = () => {
      const now = Date.now();
      const delta = now - lastTime;

      if (delta >= frameInterval) {
        setCurrentFrame((prev) => {
          if (prev >= timeline.frames.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
        lastTime = now;
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, timeline, playbackSpeed]);

  // Render 3D scene
  useEffect(() => {
    if (!timeline || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    // Clear canvas
    ctx.fillStyle = "#0F172A";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Get current frame data
    const frame = timeline.frames[currentFrame];
    if (!frame) return;

    // Draw venue outline
    drawVenue(
      ctx,
      timeline.venueDimensions,
      canvas.width,
      canvas.height,
      sport,
    );

    // Draw tactical geometry
    if (viewMode === "tactical" && timeline.tacticalGeometry) {
      drawTacticalGeometry(
        ctx,
        timeline.tacticalGeometry,
        canvas.width,
        canvas.height,
        timeline.venueDimensions,
      );
    }

    // Draw playbook overlays
    if (showPlaybook && timeline.playbookOverlays) {
      drawPlaybookOverlays(
        ctx,
        timeline.playbookOverlays,
        canvas.width,
        canvas.height,
        timeline.venueDimensions,
      );
    }

    // Draw athlete positions
    frame.positions.forEach((pos, idx) => {
      const capsule = frame.capsules.find(
        (c) => c.athleteId === pos.athleteId,
      )?.capsule;

      // Convert 3D to 2D canvas coordinates
      const canvasX =
        ((pos.position.x + timeline.venueDimensions.width / 2) /
          timeline.venueDimensions.width) *
        canvas.width;
      const canvasY =
        ((pos.position.y + timeline.venueDimensions.length / 2) /
          timeline.venueDimensions.length) *
        canvas.height;

      if (viewMode === "capsule" && capsule) {
        drawBiomechCapsule(ctx, canvasX, canvasY, capsule);
      } else {
        drawAthlete(ctx, canvasX, canvasY, pos, capsule);
      }
    });
  }, [timeline, currentFrame, viewMode, showPlaybook, sport]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-blue-400 underline">
            sign in
          </a>{" "}
          to access 3D playback
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="flex items-center gap-4 mb-2">
          <Grid3x3 className="w-10 h-10 text-cyan-400" />
          <h1 className="text-4xl font-bold text-white">
            3D Timeline Playback
          </h1>
        </div>
        <p className="text-cyan-200 text-lg">
          BiomechFlow Capsule Evolution • Tactical Playbook Overlay
        </p>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Session Loader */}
        {!timeline && (
          <div className="bg-slate-900 rounded-xl p-6 border border-slate-700">
            <h2 className="text-white text-xl font-semibold mb-4">
              Load Session
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-cyan-200 mb-2 text-sm">
                  Session ID
                </label>
                <input
                  type="text"
                  value={sessionId}
                  onChange={(e) => setSessionId(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-cyan-400 focus:outline-none"
                  placeholder="mesh_12345_abc"
                />
              </div>
              <div>
                <label className="block text-cyan-200 mb-2 text-sm">
                  Sport
                </label>
                <select
                  value={sport}
                  onChange={(e) => setSport(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-cyan-400 focus:outline-none"
                >
                  <option value="soccer">Soccer</option>
                  <option value="basketball">Basketball</option>
                  <option value="football">American Football</option>
                  <option value="rugby">Rugby</option>
                  <option value="tennis">Tennis</option>
                  <option value="wrestling">Wrestling</option>
                </select>
              </div>
              <div className="flex items-end">
                <button
                  onClick={handleLoadSession}
                  disabled={loadingTimeline}
                  className="w-full bg-cyan-600 text-white py-2 px-6 rounded-lg font-semibold hover:bg-cyan-700 transition-all disabled:opacity-50"
                >
                  {loadingTimeline ? "Loading..." : "Load Timeline"}
                </button>
              </div>
            </div>

            {error && (
              <div className="mt-4 bg-red-500/20 border border-red-500 rounded-lg p-4">
                <p className="text-red-200">{error}</p>
              </div>
            )}
          </div>
        )}

        {/* 3D Canvas */}
        {timeline && (
          <>
            {/* Controls */}
            <div className="bg-slate-900 rounded-xl p-6 border border-slate-700">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                {/* Playback Controls */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setCurrentFrame(0)}
                    className="bg-slate-800 text-white p-2 rounded-lg hover:bg-slate-700 transition-all"
                  >
                    <SkipBack className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="bg-cyan-600 text-white px-6 py-2 rounded-lg hover:bg-cyan-700 transition-all font-semibold"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5" />
                    ) : (
                      <Play className="w-5 h-5" />
                    )}
                  </button>
                  <button
                    onClick={() =>
                      setCurrentFrame(
                        Math.min(currentFrame + 10, timeline.frames.length - 1),
                      )
                    }
                    className="bg-slate-800 text-white p-2 rounded-lg hover:bg-slate-700 transition-all"
                  >
                    <SkipForward className="w-5 h-5" />
                  </button>
                </div>

                {/* View Mode */}
                <div className="flex items-center gap-2">
                  {["3d", "tactical", "capsule"].map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setViewMode(mode)}
                      className={`px-4 py-2 rounded-lg font-semibold uppercase text-sm transition-all ${
                        viewMode === mode
                          ? "bg-cyan-600 text-white"
                          : "bg-slate-800 text-cyan-300 hover:bg-slate-700"
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>

                {/* Playbook Toggle */}
                <button
                  onClick={() => setShowPlaybook(!showPlaybook)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                    showPlaybook
                      ? "bg-yellow-600 text-white"
                      : "bg-slate-800 text-yellow-300 hover:bg-slate-700"
                  }`}
                >
                  <Eye className="w-4 h-4" />
                  Playbook
                </button>

                {/* Speed Control */}
                <div className="flex items-center gap-3">
                  <span className="text-cyan-200 text-sm">Speed:</span>
                  {[0.5, 1.0, 2.0].map((speed) => (
                    <button
                      key={speed}
                      onClick={() => setPlaybackSpeed(speed)}
                      className={`px-3 py-1 rounded-lg text-sm font-semibold transition-all ${
                        playbackSpeed === speed
                          ? "bg-cyan-600 text-white"
                          : "bg-slate-800 text-cyan-300 hover:bg-slate-700"
                      }`}
                    >
                      {speed}x
                    </button>
                  ))}
                </div>
              </div>

              {/* Timeline Scrubber */}
              <div className="mt-6">
                <div className="flex items-center gap-4">
                  <span className="text-cyan-200 text-sm font-mono">
                    {formatTime((currentFrame / timeline.frameRate) * 1000)}
                  </span>
                  <input
                    type="range"
                    min="0"
                    max={timeline.frames.length - 1}
                    value={currentFrame}
                    onChange={(e) => setCurrentFrame(parseInt(e.target.value))}
                    className="flex-1 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                  <span className="text-cyan-200 text-sm font-mono">
                    {formatTime(timeline.totalDuration)}
                  </span>
                </div>
              </div>
            </div>

            {/* 3D Canvas */}
            <div className="bg-slate-900 rounded-xl p-6 border border-slate-700">
              <canvas
                ref={canvasRef}
                width={1200}
                height={800}
                className="w-full rounded-lg border border-slate-600"
              />
            </div>

            {/* Frame Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Frame Stats */}
              <div className="bg-slate-900 rounded-xl p-6 border border-slate-700">
                <h3 className="text-white font-semibold mb-4">Frame Info</h3>
                <div className="space-y-2">
                  <InfoRow
                    label="Frame"
                    value={`${currentFrame + 1} / ${timeline.frames.length}`}
                  />
                  <InfoRow
                    label="Time"
                    value={formatTime(
                      (currentFrame / timeline.frameRate) * 1000,
                    )}
                  />
                  <InfoRow
                    label="Athletes"
                    value={timeline.frames[currentFrame]?.positions.length || 0}
                  />
                  <InfoRow
                    label="Data Quality"
                    value={`${timeline.dataQuality}%`}
                  />
                </div>
              </div>

              {/* Capsule States */}
              <div className="bg-slate-900 rounded-xl p-6 border border-slate-700">
                <h3 className="text-white font-semibold mb-4">
                  Capsule States
                </h3>
                <div className="space-y-3">
                  {timeline.frames[currentFrame]?.capsules
                    .slice(0, 3)
                    .map((c, idx) => {
                      const athlete = athletes.find(
                        (a) => a.athleteId === c.athleteId,
                      );
                      const capsule = c.capsule;

                      return (
                        <div key={idx} className="bg-slate-800 rounded-lg p-3">
                          <p className="text-cyan-300 text-sm font-medium mb-2">
                            {athlete?.name}
                          </p>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <span className="text-slate-400">NIL:</span>
                            <div
                              className="h-2 rounded-full"
                              style={{
                                width: `${capsule?.glowRing?.bloom || 0}%`,
                                backgroundColor:
                                  capsule?.glowRing?.color || "#6B6B6B",
                              }}
                            />
                            <span className="text-slate-400">Fatigue:</span>
                            <div
                              className="h-2 rounded-full"
                              style={{
                                backgroundColor:
                                  capsule?.fatigueArc?.color || "#3CFF7A",
                              }}
                            />
                            <span className="text-slate-400">Risk:</span>
                            <span className="text-white font-mono">
                              {capsule?.rightBar?.risk?.toFixed(0) || 0}%
                            </span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* Tactical Insights */}
              <div className="bg-slate-900 rounded-xl p-6 border border-slate-700">
                <h3 className="text-white font-semibold mb-4">
                  Tactical Geometry
                </h3>
                {timeline.tacticalGeometry ? (
                  <div className="space-y-2 text-sm">
                    <InfoRow
                      label="Formation"
                      value={timeline.tacticalGeometry.formation?.type || "N/A"}
                    />
                    <InfoRow
                      label="Compactness"
                      value={`${timeline.tacticalGeometry.compactness?.toFixed(1) || 0}%`}
                    />
                    <InfoRow
                      label="Avg Spacing"
                      value={`${timeline.tacticalGeometry.spacing?.avg?.toFixed(1) || 0}m`}
                    />
                    <InfoRow
                      label="Shape Width"
                      value={`${timeline.tacticalGeometry.defensiveShape?.width?.toFixed(1) || 0}m`}
                    />
                  </div>
                ) : (
                  <p className="text-slate-500 text-sm">
                    No tactical data available for {sport}
                  </p>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// Canvas drawing functions
function drawVenue(ctx, dimensions, canvasWidth, canvasHeight, sport) {
  const scaleX = canvasWidth / dimensions.width;
  const scaleY = canvasHeight / dimensions.length;

  // Draw field outline
  ctx.strokeStyle = "#22D3EE";
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 0, canvasWidth, canvasHeight);

  // Draw center line
  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(canvasWidth / 2, 0);
  ctx.lineTo(canvasWidth / 2, canvasHeight);
  ctx.stroke();

  // Sport-specific markings
  if (sport === "soccer") {
    // Center circle
    ctx.beginPath();
    ctx.arc(canvasWidth / 2, canvasHeight / 2, 50, 0, Math.PI * 2);
    ctx.stroke();
  }
}

function drawTacticalGeometry(
  ctx,
  geometry,
  canvasWidth,
  canvasHeight,
  venueDimensions,
) {
  // Draw pressure zones
  if (geometry.pressureZones) {
    geometry.pressureZones.forEach((zone) => {
      const x =
        ((zone.zone.center.x + venueDimensions.width / 2) /
          venueDimensions.width) *
        canvasWidth;
      const y =
        ((zone.zone.center.y + venueDimensions.length / 2) /
          venueDimensions.length) *
        canvasHeight;
      const radius = (zone.zone.radius / venueDimensions.width) * canvasWidth;

      ctx.fillStyle = `rgba(34, 211, 238, ${zone.zone.intensity * 0.2})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    });
  }
}

function drawPlaybookOverlays(
  ctx,
  overlays,
  canvasWidth,
  canvasHeight,
  venueDimensions,
) {
  // Draw playbook patterns
  ctx.strokeStyle = "#FBBF24";
  ctx.lineWidth = 2;
  ctx.setLineDash([5, 5]);

  overlays.forEach((overlay) => {
    overlay.coordinates.forEach((coord) => {
      const x = canvasWidth / 2 + Math.random() * 100 - 50;
      const y = canvasHeight / 2 + Math.random() * 100 - 50;

      ctx.beginPath();
      ctx.arc(x, y, 30, 0, Math.PI * 2);
      ctx.stroke();
    });
  });

  ctx.setLineDash([]);
}

function drawAthlete(ctx, x, y, position, capsule) {
  // Draw player dot
  const glowColor = capsule?.glowRing?.color || "#F2F2F2";
  const glowIntensity = (capsule?.glowRing?.bloom || 100) / 100;

  // Glow effect
  ctx.shadowBlur = 20 * glowIntensity;
  ctx.shadowColor = glowColor;
  ctx.fillStyle = glowColor;
  ctx.beginPath();
  ctx.arc(x, y, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Player name
  ctx.fillStyle = "#FFFFFF";
  ctx.font = "12px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(position.name, x, y - 15);
}

function drawBiomechCapsule(ctx, x, y, capsule) {
  // Draw full capsule visualization
  const size = 60;

  // Glow ring
  ctx.strokeStyle = capsule.glowRing.color;
  ctx.lineWidth = 3;
  ctx.shadowBlur = capsule.glowRing.bloom / 10;
  ctx.shadowColor = capsule.glowRing.color;
  ctx.beginPath();
  ctx.arc(x, y, size / 2, 0, Math.PI * 2);
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Top arc (stress)
  ctx.strokeStyle = capsule.stressArc.color;
  ctx.lineWidth = capsule.stressArc.thickness;
  ctx.beginPath();
  ctx.arc(x, y, size / 2.5, Math.PI, Math.PI * 2);
  ctx.stroke();

  // Bottom arc (fatigue)
  ctx.strokeStyle = capsule.fatigueArc.color;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(x, y, size / 2.5, 0, Math.PI);
  ctx.stroke();

  // Recovery line
  const angle = (capsule.recoveryLine.slope * Math.PI) / 180;
  ctx.strokeStyle = "#FFFFFF";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x - 15, y);
  ctx.lineTo(x + 15, y - Math.tan(angle) * 15);
  ctx.stroke();

  // Left bar (sub probability)
  ctx.fillStyle = "#3B82F6";
  ctx.fillRect(
    x - size / 2 - 5,
    y - capsule.leftBar.height / 2,
    3,
    capsule.leftBar.height,
  );

  // Right bar (injury risk)
  ctx.fillStyle = capsule.rightBar.color;
  ctx.fillRect(
    x + size / 2 + 2,
    y - capsule.rightBar.height / 2,
    3,
    capsule.rightBar.height,
  );
}

function formatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function InfoRow({ label, value }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-slate-400 text-sm">{label}</span>
      <span className="text-white font-mono text-sm">{value}</span>
    </div>
  );
}
