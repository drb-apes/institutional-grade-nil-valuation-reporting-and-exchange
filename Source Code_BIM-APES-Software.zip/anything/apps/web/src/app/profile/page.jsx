"use client";

import { useState } from "react";
import {
  User,
  Trophy,
  TrendingUp,
  Heart,
  Target,
  Camera,
  Settings,
  Share,
  Edit,
  Calendar,
  Star,
  Award,
  BarChart3,
  Clock,
  Zap,
  Activity,
  PieChart,
  Shield,
  DollarSign,
  ArrowUp,
  ArrowDown,
} from "lucide-react";

export default function AthleteProfilePage() {
  const [activeTab, setActiveTab] = useState("overview");

  // Mock athlete data
  const athlete = {
    name: "Jordan Mitchell",
    sport: "Track & Field",
    speciality: "Sprint/Hurdles",
    joinDate: "2025-03-15",
    location: "Atlanta, GA",
    bio: "Professional sprinter focused on breaking personal records and building sustainable athletic career through institutional investment management.",
    avatar: <User className="w-8 h-8" />,
    verified: true,
  };

  const stats = {
    bviScore: 96,
    totalSessions: 247,
    recoveryIndex: 74,
    formAccuracy: 87,
    careerEarnings: 12847,
    activeMilestones: 3,
    completedMilestones: 12,
    fanSupport: 1567,
  };

  const achievements = [
    {
      id: 1,
      title: "First Motion Analysis",
      icon: Target,
      date: "2025-03-15",
      rarity: "Foundation",
    },
    {
      id: 2,
      title: "BVI Score Excellence",
      icon: Star,
      date: "2025-04-22",
      rarity: "Professional",
    },
    {
      id: 3,
      title: "Performance Milestone",
      icon: Trophy,
      date: "2025-05-10",
      rarity: "Elite",
    },
    {
      id: 4,
      title: "Investment Portfolio",
      icon: PieChart,
      date: "2025-06-05",
      rarity: "Institutional",
    },
  ];

  const recentActivity = [
    {
      id: 1,
      type: "Motion Analysis",
      description: "Sprint Training Session",
      bvi: 96,
      date: "2 hours ago",
    },
    {
      id: 2,
      type: "Milestone",
      description: "Sub-11 Second 100m Goal",
      value: "$2,400",
      date: "1 day ago",
    },
    {
      id: 3,
      type: "Recovery",
      description: "Recovery Index Updated",
      value: "74%",
      date: "2 days ago",
    },
    {
      id: 4,
      type: "Achievement",
      description: "Form Accuracy Milestone",
      badge: "Gold",
      date: "3 days ago",
    },
  ];

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case "Foundation":
        return "text-gray-600 bg-gray-100 border-gray-300";
      case "Professional":
        return "text-[#1D2B3D] bg-blue-100 border-blue-300";
      case "Elite":
        return "text-[#B8860B] bg-yellow-100 border-yellow-300";
      case "Institutional":
        return "text-green-700 bg-green-100 border-green-300";
      default:
        return "text-gray-600 bg-gray-100 border-gray-300";
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="px-6 py-4 bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#1D2B3D]">
              Client Portfolio
            </h1>
            <p className="text-gray-600">
              Performance analytics & investment management
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button className="bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
              <Share className="w-4 h-4" />
              <span>Share Report</span>
            </button>
            <button className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
              <Edit className="w-4 h-4" />
              <span>Edit Profile</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Profile Header */}
        <div className="bg-white rounded-xl p-8 mb-8 border border-gray-200 shadow-sm">
          <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8">
            {/* Avatar */}
            <div className="relative">
              <div className="w-24 h-24 bg-[#1D2B3D] rounded-full flex items-center justify-center text-white">
                {athlete.avatar}
              </div>
              {athlete.verified && (
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center border-2 border-white">
                  <Star className="w-4 h-4 text-white fill-current" />
                </div>
              )}
            </div>

            {/* Basic Info */}
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h2 className="text-3xl font-bold text-[#1D2B3D]">
                  {athlete.name}
                </h2>
                {athlete.verified && (
                  <span className="bg-[#B8860B]/10 text-[#B8860B] px-3 py-1 rounded-full text-sm font-medium border border-[#B8860B]/20">
                    <Star className="w-3 h-3 inline mr-1 fill-current" />
                    Verified Client
                  </span>
                )}
              </div>
              <p className="text-xl text-gray-700 mb-2">
                {athlete.sport} • {athlete.speciality}
              </p>
              <p className="text-gray-600 mb-4">{athlete.bio}</p>

              <div className="flex items-center space-x-6 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>
                    Client Since{" "}
                    {new Date(athlete.joinDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Target className="w-4 h-4" />
                  <span>{athlete.location}</span>
                </div>
              </div>
            </div>

            {/* Performance Summary */}
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                <div className="text-2xl font-bold text-[#B8860B]">
                  {stats.bviScore}
                </div>
                <div className="text-sm text-gray-600">BVI Score</div>
              </div>
              <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                <div className="text-2xl font-bold text-green-600">
                  {stats.recoveryIndex}%
                </div>
                <div className="text-sm text-gray-600">Risk Level</div>
              </div>
              <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                <div className="text-2xl font-bold text-[#1D2B3D]">
                  {stats.fanSupport}
                </div>
                <div className="text-sm text-gray-600">Supporters</div>
              </div>
              <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                <div className="text-2xl font-bold text-[#B8860B]">
                  ${stats.careerEarnings}
                </div>
                <div className="text-sm text-gray-600">Portfolio Value</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-8 bg-white rounded-lg p-1 border border-gray-200 shadow-sm">
          {[
            { id: "overview", label: "Portfolio Overview", icon: BarChart3 },
            { id: "achievements", label: "Achievements", icon: Trophy },
            { id: "activity", label: "Recent Activity", icon: Clock },
            { id: "stats", label: "Analytics", icon: TrendingUp },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? "bg-[#1D2B3D] text-white"
                    : "text-gray-600 hover:text-[#1D2B3D] hover:bg-gray-50"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Performance Metrics */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                  Investment Performance
                </h3>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-[#B8860B]/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <TrendingUp className="w-8 h-8 text-[#B8860B]" />
                    </div>
                    <div className="text-2xl font-bold text-[#B8860B] mb-1">
                      {stats.bviScore}
                    </div>
                    <div className="text-sm text-gray-600">BVI Score</div>
                  </div>

                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Shield className="w-8 h-8 text-green-600" />
                    </div>
                    <div className="text-2xl font-bold text-green-600 mb-1">
                      {stats.recoveryIndex}%
                    </div>
                    <div className="text-sm text-gray-600">Risk Level</div>
                  </div>

                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Target className="w-8 h-8 text-blue-600" />
                    </div>
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      {stats.formAccuracy}%
                    </div>
                    <div className="text-sm text-gray-600">Success Rate</div>
                  </div>

                  <div className="text-center">
                    <div className="w-16 h-16 bg-[#1D2B3D]/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Activity className="w-8 h-8 text-[#1D2B3D]" />
                    </div>
                    <div className="text-2xl font-bold text-[#1D2B3D] mb-1">
                      {stats.totalSessions}
                    </div>
                    <div className="text-sm text-gray-600">Assessments</div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                  Milestone Progress
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Active Milestones</span>
                    <span className="font-bold text-[#1D2B3D]">
                      {stats.activeMilestones}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Completed Milestones</span>
                    <span className="font-bold text-green-600">
                      {stats.completedMilestones}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Success Rate</span>
                    <span className="font-bold text-[#B8860B]">
                      {Math.round(
                        (stats.completedMilestones /
                          (stats.completedMilestones +
                            stats.activeMilestones)) *
                          100,
                      )}
                      %
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Portfolio Summary */}
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                  Portfolio Summary
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Total Portfolio Value</span>
                    <span className="font-bold text-[#B8860B]">
                      ${stats.careerEarnings}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Monthly Performance</span>
                    <span className="font-bold text-green-600 flex items-center">
                      <ArrowUp className="w-4 h-4 mr-1" />
                      +12.4%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Risk Rating</span>
                    <span className="font-bold text-blue-600">
                      Conservative
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                  Quick Actions
                </h3>

                <div className="space-y-3">
                  <a
                    href="/record"
                    className="w-full bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-4 py-3 rounded-lg flex items-center space-x-3 transition-colors"
                  >
                    <Camera className="w-5 h-5" />
                    <span>Record Session</span>
                  </a>
                  <a
                    href="/milestones/create"
                    className="w-full bg-[#B8860B] hover:bg-[#A0750A] text-white px-4 py-3 rounded-lg flex items-center space-x-3 transition-colors"
                  >
                    <Target className="w-5 h-5" />
                    <span>Set Milestone</span>
                  </a>
                  <a
                    href="/dashboard"
                    className="w-full bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] px-4 py-3 rounded-lg flex items-center space-x-3 transition-colors"
                  >
                    <BarChart3 className="w-5 h-5" />
                    <span>View Analytics</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "achievements" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {achievements.map((achievement) => {
              const Icon = achievement.icon;
              return (
                <div
                  key={achievement.id}
                  className={`bg-white rounded-xl p-6 border shadow-sm ${getRarityColor(achievement.rarity)}`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-8 h-8 text-[#1D2B3D]" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-[#1D2B3D]">
                      {achievement.title}
                    </h3>
                    <div
                      className={`inline-block px-3 py-1 rounded-full text-sm font-medium mb-3 ${getRarityColor(achievement.rarity)}`}
                    >
                      {achievement.rarity}
                    </div>
                    <p className="text-gray-500 text-sm">
                      Achieved {achievement.date}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === "activity" && (
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm flex items-center justify-between"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-[#1D2B3D]/10 rounded-lg flex items-center justify-center">
                    {activity.type === "Motion Analysis" && (
                      <Camera className="w-5 h-5 text-[#1D2B3D]" />
                    )}
                    {activity.type === "Milestone" && (
                      <Target className="w-5 h-5 text-[#B8860B]" />
                    )}
                    {activity.type === "Recovery" && (
                      <Heart className="w-5 h-5 text-green-600" />
                    )}
                    {activity.type === "Achievement" && (
                      <Award className="w-5 h-5 text-yellow-600" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-medium text-[#1D2B3D]">
                      {activity.description}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {activity.type} • {activity.date}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  {activity.bvi && (
                    <div className="font-bold text-[#B8860B]">
                      BVI: {activity.bvi}
                    </div>
                  )}
                  {activity.value && (
                    <div className="font-bold text-green-600">
                      {activity.value}
                    </div>
                  )}
                  {activity.badge && (
                    <div className="font-bold text-yellow-600">
                      {activity.badge}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "stats" && (
          <div className="text-center py-12">
            <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2 text-[#1D2B3D]">
              Advanced Analytics
            </h3>
            <p className="text-gray-600">
              Comprehensive performance analytics and portfolio insights coming
              soon
            </p>
          </div>
        )}
      </div>

      {/* Footer Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around py-3">
          <a
            href="/"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <BarChart3 className="w-6 h-6" />
            <span className="text-xs">Dashboard</span>
          </a>

          <a
            href="/record"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <Camera className="w-6 h-6" />
            <span className="text-xs">Record</span>
          </a>

          <a
            href="/dashboard"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <PieChart className="w-6 h-6" />
            <span className="text-xs">Analytics</span>
          </a>

          <a
            href="/profile"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-[#B8860B]"
          >
            <User className="w-6 h-6" />
            <span className="text-xs">Portfolio</span>
          </a>

          <a
            href="/settings"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <Settings className="w-6 h-6" />
            <span className="text-xs">Settings</span>
          </a>
        </div>
      </div>
    </div>
  );
}
