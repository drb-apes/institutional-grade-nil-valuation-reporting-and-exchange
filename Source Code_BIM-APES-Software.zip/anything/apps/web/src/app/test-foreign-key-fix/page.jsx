"use client";

import { useState } from "react";
import useUser from "@/utils/useUser";

export default function TestForeignKeyFix() {
  const { data: user, loading } = useUser();
  const [testResults, setTestResults] = useState([]);
  const [isRunning, setIsRunning] = useState(false);

  const runTests = async () => {
    setIsRunning(true);
    setTestResults([]);

    const tests = [
      {
        name: "Motion Scan Creation",
        endpoint: "/api/motion-scans/create",
        data: {
          scan_data: { test: true, sport_type: "wrestling" },
          ai_score: 85,
          motion_type: "test_motion",
          sport: "wrestling",
        },
      },
      {
        name: "QaaS Generation",
        endpoint: "/api/qaas/generate",
        data: {
          biometricData: { fatigueIndex: 10 },
          performanceData: { roi: 20 },
        },
      },
      {
        name: "Valuation Request",
        endpoint: "/api/valuation-request",
        data: {
          athlete_name: "Test Athlete",
          organization: "Test Org",
          contact_email: "test@example.com",
          data_types_requested: ["motion_scan_summary"],
        },
      },
    ];

    for (const test of tests) {
      try {
        const response = await fetch(test.endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(test.data),
        });

        const result = await response.json();

        setTestResults((prev) => [
          ...prev,
          {
            name: test.name,
            status: response.ok ? "PASS" : "FAIL",
            message: response.ok ? "Success" : result.error || "Unknown error",
            details: result,
          },
        ]);
      } catch (error) {
        setTestResults((prev) => [
          ...prev,
          {
            name: test.name,
            status: "ERROR",
            message: error.message,
            details: null,
          },
        ]);
      }
    }

    setIsRunning(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Authentication Required</h1>
          <p>Please sign in to test the foreign key fixes.</p>
          <a
            href="/account/signin"
            className="mt-4 inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            🔧 Foreign Key Constraint Fix Test
          </h1>

          <div className="mb-6 p-4 bg-blue-50 rounded-lg">
            <h2 className="text-lg font-semibold text-blue-900 mb-2">
              Test Overview
            </h2>
            <p className="text-blue-800">
              This test verifies that all APIs correctly handle the{" "}
              <code>athlete_id</code> foreign key constraint by using{" "}
              <code>user_profiles.id</code> instead of{" "}
              <code>auth_users.id</code>.
            </p>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Current User Profile</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p>
                <strong>User ID:</strong> {user.id}
              </p>
              <p>
                <strong>Name:</strong> {user.name}
              </p>
              <p>
                <strong>Email:</strong> {user.email}
              </p>
            </div>
          </div>

          <div className="mb-6">
            <button
              onClick={runTests}
              disabled={isRunning}
              className={`px-6 py-3 rounded-lg font-semibold ${
                isRunning
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-green-600 hover:bg-green-700"
              } text-white`}
            >
              {isRunning ? "Running Tests..." : "Run Foreign Key Tests"}
            </button>
          </div>

          {testResults.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Test Results</h3>
              {testResults.map((result, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-l-4 ${
                    result.status === "PASS"
                      ? "bg-green-50 border-green-500"
                      : result.status === "FAIL"
                        ? "bg-red-50 border-red-500"
                        : "bg-yellow-50 border-yellow-500"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">{result.name}</h4>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        result.status === "PASS"
                          ? "bg-green-100 text-green-800"
                          : result.status === "FAIL"
                            ? "bg-red-100 text-red-800"
                            : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {result.status}
                    </span>
                  </div>
                  <p className="text-gray-700 mb-2">{result.message}</p>
                  {result.details && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-800">
                        View Details
                      </summary>
                      <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">
                        {JSON.stringify(result.details, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          )}

          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold mb-2">
              Sport-Specific Features Supported:
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                <span>Wrestling/Goalwrestling</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <span>Rugby/Soccer/Basketball</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                <span>Tennis/Pickleball</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
                <span>American Football</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
