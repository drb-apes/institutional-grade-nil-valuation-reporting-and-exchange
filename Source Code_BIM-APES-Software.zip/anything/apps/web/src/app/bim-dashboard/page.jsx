"use client";
import { useState, useEffect } from "react";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Award,
  Target,
  Brain,
  Activity,
  Users,
  Zap,
  CheckCircle,
  AlertCircle,
  Clock,
  Calendar,
  ArrowRight,
  RefreshCw,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function BIMDashboardPage() {
  const { data: user, loading: userLoading } = useUser();
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [timeframe, setTimeframe] = useState("30");
  const [selectedMetric, setSelectedMetric] = useState("overall");

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user, timeframe]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `/api/bim-performance/dashboard?timeframe=${timeframe}`,
      );
      if (response.ok) {
        const data = await response.json();
        setDashboardData(data);
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#B8860B] border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading BIM Performance Dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Authentication Required</h1>
          <p className="text-gray-600 mb-6">
            Please sign in to access the BIM Performance Dashboard
          </p>
          <a
            href="/account/signin"
            className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors text-white"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const athlete = dashboardData?.athlete;
  const trends = dashboardData?.trends;
  const history = dashboardData?.performance_history || [];
  const recommendations = dashboardData?.coaching_recommendations || [];

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-12">
            <div>
              <div className="inline-flex items-center space-x-2 bg-[#B8860B]/20 px-4 py-2 rounded-full border border-[#B8860B]/30 mb-4">
                <Brain className="w-5 h-5 text-[#B8860B]" />
                <span className="text-[#1D2B3D] font-medium">
                  BIM Athlete Simulator
                </span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-[#1D2B3D] via-[#B8860B] to-[#1D2B3D] bg-clip-text text-transparent">
                Performance Index Dashboard
              </h1>
              <p className="text-xl text-gray-600">
                Comprehensive athletic performance analytics powered by AI
              </p>
            </div>

            <div className="flex items-center space-x-4">
              {/* Timeframe Selector */}
              <select
                value={timeframe}
                onChange={(e) => setTimeframe(e.target.value)}
                className="bg-white border border-[#1D2B3D]/20 rounded-lg px-4 py-2 text-[#1D2B3D] focus:outline-none focus:border-[#B8860B]"
              >
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
              </select>

              <button
                onClick={fetchDashboardData}
                className="bg-[#1D2B3D] hover:bg-[#B8860B] px-4 py-2 rounded-lg transition-colors flex items-center space-x-2 text-white"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Refresh</span>
              </button>
            </div>
          </div>

          {!dashboardData ? (
            <div className="text-center py-12">
              <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4 opacity-50" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">
                No Performance Data Available
              </h3>
              <p className="text-gray-500 mb-6">
                Complete a motion scan to begin tracking your BIM Performance
                Index
              </p>
              <a
                href="/motion-scan"
                className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors inline-flex items-center space-x-2 text-white"
              >
                <Zap className="w-5 h-5" />
                <span>Start Motion Scan</span>
              </a>
            </div>
          ) : (
            <>
              {/* Athlete Overview */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
                {/* Athlete Profile */}
                <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-[#1D2B3D] to-[#B8860B] rounded-full flex items-center justify-center">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#1D2B3D]">
                        {athlete.name}
                      </h3>
                      <p className="text-gray-600 capitalize">
                        {athlete.user_type} • Tier {athlete.tier_level}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Reputation Score</span>
                      <span className="text-[#1D2B3D] font-semibold">
                        {athlete.reputation_score}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Scans</span>
                      <span className="text-[#1D2B3D] font-semibold">
                        {athlete.stats.total_scans}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">BIM Analyses</span>
                      <span className="text-[#1D2B3D] font-semibold">
                        {athlete.stats.total_simulations}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Current Performance */}
                <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#B8860B]/20 shadow-lg">
                  <div className="flex items-center space-x-3 mb-6">
                    <Award className="w-6 h-6 text-[#B8860B]" />
                    <h3 className="text-xl font-bold text-[#1D2B3D]">
                      Current Performance
                    </h3>
                  </div>

                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-[#B8860B] mb-2">
                      {athlete.stats.avg_performance_score.toFixed(1)}
                    </div>
                    <p className="text-gray-600">Average BIM Score</p>
                  </div>

                  {trends && (
                    <div className="flex items-center justify-center space-x-2">
                      {trends.overall_trend === "improving" ? (
                        <>
                          <TrendingUp className="w-5 h-5 text-[#B8860B]" />
                          <span className="text-[#B8860B] font-medium">
                            +{trends.performance_change}% Improving
                          </span>
                        </>
                      ) : trends.overall_trend === "declining" ? (
                        <>
                          <TrendingDown className="w-5 h-5 text-red-600" />
                          <span className="text-red-600 font-medium">
                            {trends.performance_change}% Declining
                          </span>
                        </>
                      ) : (
                        <>
                          <BarChart3 className="w-5 h-5 text-[#1D2B3D]" />
                          <span className="text-[#1D2B3D] font-medium">
                            Stable Performance
                          </span>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* Consistency Score */}
                <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
                  <div className="flex items-center space-x-3 mb-6">
                    <Activity className="w-6 h-6 text-[#1D2B3D]" />
                    <h3 className="text-xl font-bold text-[#1D2B3D]">
                      Session Consistency
                    </h3>
                  </div>

                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-[#1D2B3D] mb-2">
                      {trends?.consistency_score
                        ? (trends.consistency_score * 100).toFixed(0)
                        : "N/A"}
                      %
                    </div>
                    <p className="text-gray-600">Consistency Rating</p>
                  </div>

                  <div className="w-full bg-[#1D2B3D]/20 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] h-3 rounded-full"
                      style={{
                        width: `${trends?.consistency_score ? trends.consistency_score * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Performance History Chart */}
              {history.length > 0 && (
                <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg mb-12">
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center space-x-3">
                      <BarChart3 className="w-6 h-6 text-[#B8860B]" />
                      <h3 className="text-2xl font-bold text-[#1D2B3D]">
                        Performance History
                      </h3>
                    </div>
                    <p className="text-gray-600">{dashboardData.timeframe}</p>
                  </div>

                  {/* Simple Chart Visualization */}
                  <div className="space-y-4">
                    {history.slice(0, 10).map((record, index) => (
                      <div
                        key={record.id}
                        className="flex items-center space-x-4"
                      >
                        <div className="w-20 text-sm text-gray-600 flex-shrink-0">
                          {new Date(record.created_at).toLocaleDateString()}
                        </div>

                        <div className="flex-1 relative">
                          <div className="w-full bg-gray-200 rounded-full h-6">
                            <div
                              className="bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] h-6 rounded-full flex items-center justify-end pr-3"
                              style={{
                                width: `${(record.overall_score / 100) * 100}%`,
                              }}
                            >
                              <span className="text-white text-sm font-semibold">
                                {record.overall_score}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="w-16 text-sm text-gray-600 flex-shrink-0 capitalize">
                          {record.motion_type}
                        </div>

                        <div
                          className={`w-20 text-sm flex-shrink-0 ${
                            record.verification_status === "verified"
                              ? "text-[#B8860B]"
                              : record.verification_status === "pending"
                                ? "text-orange-500"
                                : "text-red-600"
                          }`}
                        >
                          {record.verification_status}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Coaching Recommendations */}
              {recommendations.length > 0 && (
                <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-orange-500/20 mb-12">
                  <div className="flex items-center space-x-3 mb-8">
                    <Brain className="w-6 h-6 text-orange-400" />
                    <h3 className="text-2xl font-bold text-[#1D2B3D]">
                      AI Coaching Recommendations
                    </h3>
                  </div>

                  <div className="space-y-6">
                    {recommendations.map((rec, index) => (
                      <div
                        key={index}
                        className="bg-gray-900/50 rounded-lg p-6"
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-3 h-3 rounded-full ${
                                rec.priority === "high"
                                  ? "bg-red-400"
                                  : rec.priority === "medium"
                                    ? "bg-yellow-400"
                                    : "bg-green-400"
                              }`}
                            ></div>
                            <h4 className="text-lg font-semibold text-[#1D2B3D]">
                              {rec.title}
                            </h4>
                          </div>
                          <span
                            className={`px-2 py-1 rounded text-xs font-medium ${
                              rec.priority === "high"
                                ? "bg-red-500/20 text-red-300"
                                : rec.priority === "medium"
                                  ? "bg-yellow-500/20 text-yellow-300"
                                  : "bg-green-500/20 text-green-300"
                            }`}
                          >
                            {rec.priority} priority
                          </span>
                        </div>

                        <p className="text-gray-300 mb-4">{rec.description}</p>

                        <div className="space-y-2">
                          <p className="text-sm font-medium text-blue-300">
                            Action Items:
                          </p>
                          {rec.action_items.map((item, itemIndex) => (
                            <div
                              key={itemIndex}
                              className="flex items-center space-x-2"
                            >
                              <ArrowRight className="w-4 h-4 text-blue-400 flex-shrink-0" />
                              <span className="text-gray-300 text-sm">
                                {item}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Cross-Correlation Insights */}
              {dashboardData.correlation_insights && (
                <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-cyan-500/20">
                  <div className="flex items-center space-x-3 mb-8">
                    <Target className="w-6 h-6 text-cyan-400" />
                    <h3 className="text-2xl font-bold text-[#1D2B3D]">
                      Cross-Correlation Analysis
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400 mb-2">
                        {(
                          dashboardData.correlation_insights
                            .roi_performance_correlation * 100
                        ).toFixed(0)}
                        %
                      </div>
                      <p className="text-gray-300 text-sm">
                        ROI-Performance Correlation
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400 mb-2">
                        {(
                          dashboardData.correlation_insights
                            .risk_consistency_correlation * 100
                        ).toFixed(0)}
                        %
                      </div>
                      <p className="text-gray-300 text-sm">
                        Risk-Consistency Factor
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400 mb-2">
                        {dashboardData.correlation_insights.verification_impact.toFixed(
                          1,
                        )}
                      </div>
                      <p className="text-gray-300 text-sm">
                        Verification Impact
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400 mb-2">
                        {
                          Object.keys(
                            dashboardData.correlation_insights
                              .motion_type_performance,
                          ).length
                        }
                      </div>
                      <p className="text-gray-300 text-sm">
                        Motion Types Analyzed
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Quick Actions */}
          <div className="mt-12 text-center">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6">
              Quick Actions
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="/motion-scan"
                className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors flex items-center space-x-2 text-white"
              >
                <Zap className="w-5 h-5" />
                <span>New Motion Scan</span>
              </a>

              <a
                href="/milestones"
                className="bg-[#B8860B] hover:bg-[#1D2B3D] px-6 py-3 rounded-lg font-semibold transition-colors flex items-center space-x-2 text-white"
              >
                <Target className="w-5 h-5" />
                <span>View Milestones</span>
              </a>

              <a
                href="/profile"
                className="bg-white border-2 border-[#1D2B3D] hover:bg-[#1D2B3D] hover:text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center space-x-2 text-[#1D2B3D]"
              >
                <Users className="w-5 h-5" />
                <span>Update Profile</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
