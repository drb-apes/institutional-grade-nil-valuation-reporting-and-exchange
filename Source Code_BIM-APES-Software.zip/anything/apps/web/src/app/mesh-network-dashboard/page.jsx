"use client";

import { useState, useEffect } from "react";
import {
  Radio,
  Wifi,
  Activity,
  AlertTriangle,
  CheckCircle,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function MeshNetworkDashboard() {
  const { data: user, loading } = useUser();
  const [meshSessions, setMeshSessions] = useState([]);
  const [selectedSession, setSelectedSession] = useState(null);
  const [sessionDetails, setSessionDetails] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const [newSessionForm, setNewSessionForm] = useState({
    sessionName: "",
    sessionType: "team_training",
    coordinatorDeviceUUID: "",
    sport: "wrestling",
    maxDevices: 50,
  });

  useEffect(() => {
    if (user) {
      fetchMeshSessions();
    }
  }, [user]);

  const fetchMeshSessions = async () => {
    try {
      const response = await fetch("/api/wearable-mesh/mesh-session");
      if (!response.ok) throw new Error("Failed to fetch sessions");

      const data = await response.json();
      setMeshSessions(data.sessions || []);
    } catch (err) {
      console.error(err);
      setError(err.message);
    }
  };

  const createMeshSession = async (e) => {
    e.preventDefault();
    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch("/api/wearable-mesh/mesh-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSessionForm),
      });

      if (!response.ok) throw new Error("Failed to create mesh session");

      const data = await response.json();
      setSelectedSession(data.meshSessionId);
      fetchMeshSessions();

      // Reset form
      setNewSessionForm({
        sessionName: "",
        sessionType: "team_training",
        coordinatorDeviceUUID: "",
        sport: "wrestling",
        maxDevices: 50,
      });
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  const loadSessionDetails = async (meshSessionId) => {
    setLoadingData(true);
    try {
      const response = await fetch(
        `/api/wearable-mesh/mesh-session?meshSessionId=${meshSessionId}`,
      );
      if (!response.ok) throw new Error("Failed to load session details");

      const data = await response.json();
      setSessionDetails(data);
      setSelectedSession(meshSessionId);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-blue-400 underline">
            sign in
          </a>{" "}
          to access this dashboard
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Radio className="w-10 h-10 text-blue-400" />
          <h1 className="text-4xl font-bold text-white">
            Wearable Mesh Network
          </h1>
        </div>
        <p className="text-blue-200 text-lg">
          Multi-Device Synchronization & Real-Time Biometric Streaming
        </p>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Create Session Panel */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-6">
            Create Mesh Session
          </h2>

          <form onSubmit={createMeshSession} className="space-y-4">
            <div>
              <label className="block text-blue-200 mb-2 text-sm">
                Session Name
              </label>
              <input
                type="text"
                value={newSessionForm.sessionName}
                onChange={(e) =>
                  setNewSessionForm({
                    ...newSessionForm,
                    sessionName: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                placeholder="Team Practice Session"
                required
              />
            </div>

            <div>
              <label className="block text-blue-200 mb-2 text-sm">
                Session Type
              </label>
              <select
                value={newSessionForm.sessionType}
                onChange={(e) =>
                  setNewSessionForm({
                    ...newSessionForm,
                    sessionType: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
              >
                <option value="team_training">Team Training</option>
                <option value="competition">Competition</option>
                <option value="research">Research</option>
                <option value="stadium">Stadium</option>
              </select>
            </div>

            <div>
              <label className="block text-blue-200 mb-2 text-sm">
                Coordinator Device UUID
              </label>
              <input
                type="text"
                value={newSessionForm.coordinatorDeviceUUID}
                onChange={(e) =>
                  setNewSessionForm({
                    ...newSessionForm,
                    coordinatorDeviceUUID: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                placeholder="device-uuid-12345"
                required
              />
            </div>

            <div>
              <label className="block text-blue-200 mb-2 text-sm">Sport</label>
              <select
                value={newSessionForm.sport}
                onChange={(e) =>
                  setNewSessionForm({
                    ...newSessionForm,
                    sport: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
              >
                <option value="wrestling">Wrestling</option>
                <option value="basketball">Basketball</option>
                <option value="soccer">Soccer</option>
                <option value="football">Football</option>
                <option value="tennis">Tennis</option>
                <option value="running">Running</option>
              </select>
            </div>

            <div>
              <label className="block text-blue-200 mb-2 text-sm">
                Max Devices
              </label>
              <input
                type="number"
                value={newSessionForm.maxDevices}
                onChange={(e) =>
                  setNewSessionForm({
                    ...newSessionForm,
                    maxDevices: parseInt(e.target.value) || 50,
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
              />
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500 rounded-lg p-3">
                <p className="text-red-200 text-sm">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loadingData}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-700 transition-all disabled:opacity-50"
            >
              {loadingData ? "Creating..." : "Create Mesh Session"}
            </button>
          </form>

          {/* Active Sessions List */}
          <div className="mt-6 pt-6 border-t border-white/20">
            <h3 className="text-white font-semibold mb-3">
              Active Sessions ({meshSessions.length})
            </h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {meshSessions.map((session) => (
                <button
                  key={session.mesh_id}
                  onClick={() => loadSessionDetails(session.mesh_id)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-all ${
                    selectedSession === session.mesh_id
                      ? "bg-blue-600 text-white"
                      : "bg-slate-800 text-blue-200 hover:bg-slate-700"
                  }`}
                >
                  <p className="font-medium text-sm truncate">
                    {session.sync_data?.session_name || "Unnamed Session"}
                  </p>
                  <p className="text-xs opacity-75">
                    {session.sync_data?.sport} ·{" "}
                    {session.sync_data?.session_type}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Session Details Panel */}
        <div className="lg:col-span-2 space-y-6">
          {!sessionDetails ? (
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 flex flex-col items-center justify-center">
              <Wifi className="w-20 h-20 text-blue-400/50 mb-4" />
              <p className="text-blue-300 text-lg">
                Create or select a mesh session to view details
              </p>
            </div>
          ) : (
            <>
              {/* Mesh Health */}
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-bold text-white">Mesh Health</h3>
                  <HealthBadge status={sessionDetails.health?.status} />
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <MetricCard
                    label="Health Score"
                    value={sessionDetails.health?.score || 0}
                    suffix="/100"
                    color="blue"
                  />
                  <MetricCard
                    label="Connected Devices"
                    value={sessionDetails.connectedDevices || 0}
                    suffix=""
                    color="green"
                  />
                  <MetricCard
                    label="Avg Connection"
                    value={sessionDetails.health?.avgConnectionStrength || 0}
                    suffix="%"
                    color="cyan"
                  />
                  <MetricCard
                    label="Max Hops"
                    value={sessionDetails.health?.maxHopCount || 0}
                    suffix=""
                    color="purple"
                  />
                </div>

                {sessionDetails.health?.weakNodeCount > 0 && (
                  <div className="mt-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                    <div className="flex items-center gap-2 text-yellow-300">
                      <AlertTriangle className="w-5 h-5" />
                      <p className="font-medium">
                        {sessionDetails.health.weakNodeCount} weak node(s)
                        detected
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Network Topology */}
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4">
                  Network Topology
                </h3>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {sessionDetails.topology?.map((node, idx) => (
                    <div
                      key={idx}
                      className={`rounded-lg p-4 border ${
                        node.hop_count === 0
                          ? "bg-blue-500/20 border-blue-400/50"
                          : node.connection_strength < 30
                            ? "bg-red-500/20 border-red-400/50"
                            : "bg-slate-800/50 border-slate-600"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="text-white font-medium font-mono text-sm truncate">
                            {node.child_device_uuid}
                          </p>
                          <p className="text-blue-200 text-xs mt-1">
                            {node.hop_count === 0
                              ? "Coordinator"
                              : `Hop ${node.hop_count}`}
                            {node.parent_device_uuid &&
                              ` ← ${node.parent_device_uuid.substring(0, 12)}...`}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="text-white font-bold">
                              {node.connection_strength || 0}%
                            </p>
                            <p className="text-xs text-blue-200">Signal</p>
                          </div>
                          {node.connection_strength >= 70 ? (
                            <CheckCircle className="w-5 h-5 text-green-400" />
                          ) : node.connection_strength >= 30 ? (
                            <Activity className="w-5 h-5 text-yellow-400" />
                          ) : (
                            <AlertTriangle className="w-5 h-5 text-red-400" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Sync Events */}
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-4">
                  Recent Sync Events
                </h3>

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {sessionDetails.recentSyncs?.slice(0, 10).map((sync, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-800/50 rounded-lg p-3 border border-slate-600"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white text-sm font-medium capitalize">
                            {sync.sync_type.replace(/_/g, " ")}
                          </p>
                          <p className="text-blue-200 text-xs font-mono truncate max-w-xs">
                            {sync.device_id}
                          </p>
                        </div>
                        <p className="text-blue-300 text-xs">
                          {new Date(sync.sync_timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function HealthBadge({ status }) {
  const colors = {
    excellent: "bg-green-500/20 border-green-400 text-green-300",
    good: "bg-blue-500/20 border-blue-400 text-blue-300",
    fair: "bg-yellow-500/20 border-yellow-400 text-yellow-300",
    poor: "bg-red-500/20 border-red-400 text-red-300",
    no_devices: "bg-slate-500/20 border-slate-400 text-slate-300",
  };

  return (
    <div
      className={`px-4 py-2 rounded-lg border ${colors[status] || colors.no_devices}`}
    >
      <p className="text-sm font-semibold uppercase">
        {status?.replace("_", " ") || "Unknown"}
      </p>
    </div>
  );
}

function MetricCard({ label, value, suffix, color }) {
  const colors = {
    blue: "from-blue-500/20 to-cyan-500/20 border-blue-400/30 text-blue-400",
    green:
      "from-green-500/20 to-emerald-500/20 border-green-400/30 text-green-400",
    cyan: "from-cyan-500/20 to-blue-500/20 border-cyan-400/30 text-cyan-400",
    purple:
      "from-purple-500/20 to-pink-500/20 border-purple-400/30 text-purple-400",
  };

  return (
    <div className={`bg-gradient-to-br ${colors[color]} rounded-lg p-4 border`}>
      <p className="text-white/70 text-xs mb-1">{label}</p>
      <p className="text-2xl font-bold">
        {value}
        <span className="text-sm ml-1">{suffix}</span>
      </p>
    </div>
  );
}
