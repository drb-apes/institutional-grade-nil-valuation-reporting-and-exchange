"use client";

import { useState, useRef, useEffect } from "react";
import {
  Camera,
  StopCircle,
  Play,
  Grid3X3,
  Heart,
  Target,
  Timer,
  Activity,
  Users,
  Settings,
  ArrowLeft,
  RotateCcw,
  TrendingUp,
  BarChart3,
  User,
  PieChart,
  Download,
  Archive,
  Zap,
} from "lucide-react";

export default function RecordPage() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const [coachMode, setCoachMode] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [stream, setStream] = useState(null);
  const [motionDetected, setMotionDetected] = useState(false);
  const [motionIntensity, setMotionIntensity] = useState(0);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const previousFrameRef = useRef(null);
  const motionAnalysisRef = useRef(null);

  // Enhanced biometric data with motion binding
  const [biometrics, setBiometrics] = useState({
    heartRate: 142,
    formAccuracy: 91,
    speed: 24.5,
    fatigue: "Low",
    motionScore: 0,
    biomechanicalEfficiency: 85,
    stabilityIndex: 78,
  });

  // Motion detection function
  const onMotionDetected = (frameData, intensity) => {
    setMotionDetected(true);
    setMotionIntensity(intensity);

    // Extract biometric markers from frame
    const biometricPayload = extractBiometrics(frameData, intensity);

    // Send to biometric live feed
    updateBiometricFeed(biometricPayload);

    // Clear motion indicator after brief period
    setTimeout(() => setMotionDetected(false), 150);
  };

  // Extract biometric data from motion analysis
  const extractBiometrics = (frameData, motionIntensity) => {
    // Sport-specific motion analysis
    const sportFactors = {
      basketball: { speedMultiplier: 1.2, stabilityWeight: 0.8 },
      wrestling: { speedMultiplier: 0.9, stabilityWeight: 1.3 },
      tennis: { speedMultiplier: 1.1, stabilityWeight: 1.0 },
      soccer: { speedMultiplier: 1.3, stabilityWeight: 0.9 },
      "american-football": { speedMultiplier: 1.4, stabilityWeight: 1.1 },
      rugby: { speedMultiplier: 1.3, stabilityWeight: 1.2 },
    };

    const currentSport = "basketball"; // This would come from user selection
    const factors = sportFactors[currentSport] || {
      speedMultiplier: 1.0,
      stabilityWeight: 1.0,
    };

    return {
      motionScore: Math.min(100, motionIntensity * 100),
      speed: Math.min(30, motionIntensity * 25 * factors.speedMultiplier),
      formAccuracy: Math.max(70, 95 - motionIntensity * 15),
      stabilityIndex: Math.max(
        60,
        90 - motionIntensity * 20 * factors.stabilityWeight,
      ),
      biomechanicalEfficiency: Math.max(75, 92 - motionIntensity * 12),
      heartRate: Math.floor(130 + motionIntensity * 40),
      timestamp: Date.now(),
    };
  };

  // Update biometric feed with real-time data
  const updateBiometricFeed = (data) => {
    setBiometrics((prev) => ({
      ...prev,
      ...data,
      fatigue:
        data.heartRate > 160 ? "High" : data.heartRate > 140 ? "Medium" : "Low",
    }));
  };

  // Motion detection analysis
  const analyzeMotion = () => {
    if (!videoRef.current || !canvasRef.current || !isRecording) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const currentFrame = ctx.getImageData(0, 0, canvas.width, canvas.height);

    if (previousFrameRef.current) {
      const motionLevel = calculateMotionDifference(
        previousFrameRef.current,
        currentFrame,
      );
      if (motionLevel > 0.02) {
        // Motion threshold
        onMotionDetected(currentFrame, motionLevel);
      }
    }

    previousFrameRef.current = currentFrame;
  };

  // Calculate motion difference between frames
  const calculateMotionDifference = (prevFrame, currentFrame) => {
    let totalDiff = 0;
    const pixels = prevFrame.data.length;

    for (let i = 0; i < pixels; i += 4) {
      const rDiff = Math.abs(prevFrame.data[i] - currentFrame.data[i]);
      const gDiff = Math.abs(prevFrame.data[i + 1] - currentFrame.data[i + 1]);
      const bDiff = Math.abs(prevFrame.data[i + 2] - currentFrame.data[i + 2]);
      totalDiff += (rDiff + gDiff + bDiff) / 3;
    }

    return totalDiff / (pixels / 4) / 255; // Normalize to 0-1
  };

  useEffect(() => {
    // Start camera
    async function startCamera() {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
          audio: true,
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (error) {
        console.error("Error accessing camera:", error);
      }
    }

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  useEffect(() => {
    let interval;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
        analyzeMotion(); // Bind motion analysis to recording loop
      }, 1000);

      // Start motion analysis at higher frequency
      motionAnalysisRef.current = setInterval(analyzeMotion, 100);
    } else {
      if (motionAnalysisRef.current) {
        clearInterval(motionAnalysisRef.current);
      }
    }

    return () => {
      clearInterval(interval);
      if (motionAnalysisRef.current) {
        clearInterval(motionAnalysisRef.current);
      }
    };
  }, [isRecording]);

  const startCountdown = () => {
    setCountdown(3);
    const countInterval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countInterval);
          startRecording();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const startRecording = () => {
    setIsRecording(true);
    setRecordingTime(0);
    // Reset biometric baselines
    setBiometrics((prev) => ({
      ...prev,
      motionScore: 0,
      biomechanicalEfficiency: 85,
      stabilityIndex: 78,
    }));
  };

  const stopRecording = () => {
    setIsRecording(false);
    setIsPreviewing(true);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="relative z-20 flex items-center justify-between p-4 bg-white shadow-sm border-b border-gray-200">
        <div className="flex items-center space-x-4">
          <a
            href="/"
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#1D2B3D]" />
          </a>
          <div>
            <h1 className="text-lg font-semibold text-[#1D2B3D]">
              Motion Analysis Session
            </h1>
            <p className="text-sm text-gray-600">
              Professional performance capture & assessment
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Motion Detection Indicator */}
          <div
            className={`p-2 rounded-lg transition-colors flex items-center space-x-2 ${
              motionDetected
                ? "bg-green-100 text-green-600"
                : "bg-gray-100 text-gray-500"
            }`}
          >
            <Zap
              className={`w-4 h-4 ${motionDetected ? "animate-pulse" : ""}`}
            />
            <span className="text-xs font-medium">
              {motionDetected ? "MOTION" : "READY"}
            </span>
          </div>

          <button
            onClick={() => setShowGrid(!showGrid)}
            className={`p-2 rounded-lg transition-colors ${
              showGrid
                ? "bg-[#B8860B]/10 text-[#B8860B]"
                : "bg-gray-100 text-gray-500"
            }`}
          >
            <Grid3X3 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setCoachMode(!coachMode)}
            className={`p-2 rounded-lg transition-colors ${
              coachMode
                ? "bg-[#1D2B3D]/10 text-[#1D2B3D]"
                : "bg-gray-100 text-gray-500"
            }`}
          >
            <Users className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <Settings className="w-5 h-5 text-gray-500" />
          </button>
        </div>
      </div>

      {/* Camera Feed */}
      <div className="relative flex-1">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-screen object-cover bg-gray-900"
        />

        {/* Hidden canvas for motion detection */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Grid Overlay */}
        {showGrid && (
          <div className="absolute inset-0 pointer-events-none">
            <div className="grid grid-cols-3 grid-rows-3 h-full w-full">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="border border-white/30"></div>
              ))}
            </div>
          </div>
        )}

        {/* Recording Indicator */}
        {isRecording && (
          <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 border border-[#B8860B]/20">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-[#B8860B] rounded-full animate-pulse"></div>
              <span className="text-[#1D2B3D] font-medium">RECORDING</span>
            </div>
          </div>
        )}

        {/* Timer */}
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 border border-gray-200">
          <span className="text-[#1D2B3D] font-mono text-lg">
            {isRecording ? formatTime(recordingTime) : "00:00"}
          </span>
        </div>

        {/* Countdown */}
        {countdown > 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="text-8xl font-bold text-white animate-pulse bg-[#1D2B3D]/20 px-8 py-4 rounded-full">
              {countdown}
            </div>
          </div>
        )}

        {/* Enhanced Performance Metrics Overlays */}
        <div className="absolute bottom-32 left-4 space-y-3">
          <div className="bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center space-x-3 border border-gray-200 shadow-sm">
            <Heart className="w-5 h-5 text-red-500" />
            <span className="text-[#1D2B3D] font-medium">
              {Math.round(biometrics.heartRate)} BPM
            </span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center space-x-3 border border-gray-200 shadow-sm">
            <Target className="w-5 h-5 text-[#B8860B]" />
            <span className="text-[#1D2B3D] font-medium">
              Form: {Math.round(biometrics.formAccuracy)}%
            </span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center space-x-3 border border-gray-200 shadow-sm">
            <Activity className="w-5 h-5 text-blue-500" />
            <span className="text-[#1D2B3D] font-medium">
              {Math.round(biometrics.speed)} mph
            </span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center space-x-3 border border-gray-200 shadow-sm">
            <Timer className="w-5 h-5 text-green-500" />
            <span className="text-[#1D2B3D] font-medium">
              Recovery: {biometrics.fatigue}
            </span>
          </div>

          {/* New Motion-Based Metrics */}
          <div
            className={`bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center space-x-3 border shadow-sm transition-colors ${
              motionDetected ? "border-green-400" : "border-gray-200"
            }`}
          >
            <Zap
              className={`w-5 h-5 text-purple-500 ${motionDetected ? "animate-pulse" : ""}`}
            />
            <span className="text-[#1D2B3D] font-medium">
              Motion: {Math.round(biometrics.motionScore)}%
            </span>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center space-x-3 border border-gray-200 shadow-sm">
            <BarChart3 className="w-5 h-5 text-indigo-500" />
            <span className="text-[#1D2B3D] font-medium">
              Stability: {Math.round(biometrics.stabilityIndex)}%
            </span>
          </div>
        </div>

        {/* Professional Mode Indicators */}
        {coachMode && (
          <div className="absolute top-20 left-4 space-y-2">
            <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 border border-gray-200">
              <span className="text-[#1D2B3D] text-sm font-medium flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Professional Mode</span>
              </span>
            </div>
            <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 border border-gray-200">
              <span className="text-gray-700 text-sm">
                Multi-athlete tracking: Active
              </span>
            </div>
            <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 border border-gray-200">
              <span className="text-gray-700 text-sm">
                Motion Analysis: {isRecording ? "Recording" : "Standby"}
              </span>
            </div>
          </div>
        )}

        {/* Control Buttons */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center space-x-6">
          {!isRecording && !isPreviewing && (
            <>
              <button
                onClick={startCountdown}
                className="w-20 h-20 bg-white rounded-full flex items-center justify-center border-4 border-[#B8860B] shadow-lg hover:scale-105 transition-transform"
              >
                <div className="w-12 h-12 bg-[#B8860B] rounded-full flex items-center justify-center">
                  <Play className="w-6 h-6 text-white ml-1" />
                </div>
              </button>
            </>
          )}

          {isRecording && (
            <button
              onClick={stopRecording}
              className="w-20 h-20 bg-white rounded-full flex items-center justify-center border-4 border-gray-300 shadow-lg hover:scale-105 transition-transform"
            >
              <StopCircle className="w-10 h-10 text-[#B8860B]" />
            </button>
          )}

          {isPreviewing && (
            <div className="flex items-center space-x-4">
              <button
                onClick={() => {
                  setIsPreviewing(false);
                  setRecordingTime(0);
                }}
                className="bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] px-6 py-3 rounded-full flex items-center space-x-2 transition-colors shadow-lg"
              >
                <RotateCcw className="w-5 h-5" />
                <span>Retake</span>
              </button>
              <a
                href="/dashboard"
                className="bg-[#B8860B] hover:bg-[#A0750A] text-white px-6 py-3 rounded-full flex items-center space-x-2 transition-colors shadow-lg"
              >
                <BarChart3 className="w-5 h-5" />
                <span>Analyze Performance</span>
              </a>
            </div>
          )}
        </div>

        {/* Performance Instructions */}
        {!isRecording && !isPreviewing && (
          <div className="absolute bottom-32 left-1/2 transform -translate-x-1/2 text-center">
            <div className="bg-white/90 backdrop-blur-sm rounded-lg px-6 py-4 border border-gray-200 shadow-lg">
              <p className="text-[#1D2B3D] text-lg font-medium mb-2">
                Position yourself in the analysis frame
              </p>
              <p className="text-gray-600">
                Ensure proper lighting and stable positioning for optimal motion
                capture
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Professional Footer Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around py-3">
          <a
            href="/"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <BarChart3 className="w-6 h-6" />
            <span className="text-xs">Dashboard</span>
          </a>

          <a
            href="/record"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-[#B8860B]"
          >
            <Camera className="w-6 h-6" />
            <span className="text-xs">Record</span>
          </a>

          <a
            href="/dashboard"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <PieChart className="w-6 h-6" />
            <span className="text-xs">Analytics</span>
          </a>

          <a
            href="/video-archive"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <Archive className="w-6 h-6" />
            <span className="text-xs">Archive</span>
          </a>

          <a
            href="/profile"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <User className="w-6 h-6" />
            <span className="text-xs">Portfolio</span>
          </a>

          <a
            href="/settings"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <Settings className="w-6 h-6" />
            <span className="text-xs">Settings</span>
          </a>
        </div>
      </div>
    </div>
  );
}
