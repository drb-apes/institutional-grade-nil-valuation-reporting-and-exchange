"use client";

import { useState } from "react";
import {
  Users,
  Upload,
  FileText,
  CheckCircle,
  AlertCircle,
  User,
  Trophy,
  Target,
  ArrowRight,
  Camera,
  Shield,
  Wallet,
  Brain,
  Award,
  MapPin,
  Calendar,
  Phone,
  Mail,
  Star,
  Zap,
} from "lucide-react";

export default function ReferralPage() {
  const [formData, setFormData] = useState({
    // Representative Info
    rep_name: "",
    rep_title: "",
    rep_organization: "",
    rep_email: "",
    rep_phone: "",
    rep_type: "",
    rep_credentials: "",

    // Athlete Info
    athlete_name: "",
    athlete_age: "",
    athlete_sport: "",
    athlete_position: "",
    athlete_level: "",
    athlete_location: "",

    // Performance Context
    standout_traits: "",
    adversity_overcome: "",
    community_impact: "",
    training_schedule: "",
    recent_achievements: "",
    milestone_potential: "",

    // Technical Details
    sample_footage_url: "",
    stat_sheet_notes: "",
    wallet_address: "",
    preferred_milestones: [],

    // Verification
    agreement_terms: false,
    data_accuracy: false,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null);

  const repTypes = [
    { value: "coach_high_school", label: "High School Coach" },
    { value: "coach_college", label: "College Coach" },
    { value: "trainer_certified", label: "Certified Trainer" },
    { value: "mentor_community", label: "Community Mentor" },
    { value: "agency_nil", label: "NIL Agency Representative" },
    { value: "scout_summit", label: "Summit-Approved Scout" },
    { value: "validator_dao", label: "DAO Validator" },
    { value: "advisor_performance", label: "Performance Advisor" },
  ];

  const sportTypes = [
    "Wrestling",
    "Boxing",
    "MMA",
    "Track & Field",
    "Basketball",
    "Football",
    "Soccer",
    "Baseball",
    "Swimming",
    "Gymnastics",
    "Tennis",
    "Golf",
    "Volleyball",
    "Cross Country",
    "Other",
  ];

  const milestoneOptions = [
    { id: "grip_symmetry", label: "Grip Symmetry & Control" },
    { id: "fatigue_decay", label: "Fatigue Decay Resistance" },
    { id: "clean_takedowns", label: "Clean Takedown Execution" },
    { id: "zone_dominance", label: "Zone Dominance Tracking" },
    { id: "rhythm_maintenance", label: "Rhythm Maintenance" },
    { id: "power_consistency", label: "Power Output Consistency" },
    { id: "recovery_speed", label: "Recovery Speed Index" },
    { id: "technique_precision", label: "Technique Precision" },
  ];

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleMilestoneToggle = (milestoneId) => {
    setFormData((prev) => ({
      ...prev,
      preferred_milestones: prev.preferred_milestones.includes(milestoneId)
        ? prev.preferred_milestones.filter((id) => id !== milestoneId)
        : [...prev.preferred_milestones, milestoneId],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/api/referrals/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setSubmitStatus("success");
      } else {
        setSubmitStatus("error");
      }
    } catch (error) {
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitStatus === "success") {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center p-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-[#1D2B3D] mb-4">
            Athlete Referral Submitted Successfully
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Thank you for submitting <strong>{formData.athlete_name}</strong> to
            the BIM-APES platform. Our verification team will review the
            recommendation packet and create their athlete profile within 24-48
            hours.
          </p>
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm mb-8">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
              Next Steps
            </h3>
            <div className="space-y-3 text-left">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-bold">1</span>
                </div>
                <span className="text-gray-700">
                  Profile Creation & Motion Analysis Setup
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-bold">2</span>
                </div>
                <span className="text-gray-700">
                  Milestone Publication to Fan Staking Pools
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-bold">3</span>
                </div>
                <span className="text-gray-700">
                  Athlete Onboarding Link Delivery
                </span>
              </div>
            </div>
          </div>
          <a
            href="/"
            className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-8 py-3 rounded-lg font-semibold transition-colors"
          >
            Return to Platform
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1D2B3D] to-[#2C3E50] text-white">
        <div className="px-6 py-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center space-x-2 bg-[#B8860B]/20 px-4 py-2 rounded-full border border-[#B8860B]/30 mb-6">
              <Users className="w-5 h-5 text-[#B8860B]" />
              <span className="text-[#B8860B] font-medium">
                Verified Representative Portal
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Athlete Referral System
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Submit athletes for verified onboarding into the BIM-APES
              ecosystem. Trusted representatives create institutional-grade
              asset profiles.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Verification Benefits */}
        <div className="bg-white rounded-xl p-6 mb-8 border border-gray-200 shadow-sm">
          <h2 className="text-2xl font-bold text-[#1D2B3D] mb-6 flex items-center space-x-2">
            <Shield className="w-6 h-6" />
            <span>Verified Representative Benefits</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-[#B8860B]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Star className="w-6 h-6 text-[#B8860B]" />
              </div>
              <h3 className="font-semibold text-[#1D2B3D] mb-2">
                Institutional Trust
              </h3>
              <p className="text-sm text-gray-600">
                Your referrals carry verified credibility in the investment
                ecosystem
              </p>
            </div>
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-[#B8860B]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Zap className="w-6 h-6 text-[#B8860B]" />
              </div>
              <h3 className="font-semibold text-[#1D2B3D] mb-2">
                No Friction Onboarding
              </h3>
              <p className="text-sm text-gray-600">
                Athletes bypass self-upload requirements with your validation
              </p>
            </div>
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-[#B8860B]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Award className="w-6 h-6 text-[#B8860B]" />
              </div>
              <h3 className="font-semibold text-[#1D2B3D] mb-2">
                Success Tracking
              </h3>
              <p className="text-sm text-gray-600">
                Monitor your referred athletes' performance and ROI
              </p>
            </div>
          </div>
        </div>

        {/* Referral Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Representative Information */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6 flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Representative Information</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.rep_name}
                  onChange={(e) =>
                    handleInputChange("rep_name", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="John Smith"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Title/Position *
                </label>
                <input
                  type="text"
                  required
                  value={formData.rep_title}
                  onChange={(e) =>
                    handleInputChange("rep_title", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Head Wrestling Coach"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Organization *
                </label>
                <input
                  type="text"
                  required
                  value={formData.rep_organization}
                  onChange={(e) =>
                    handleInputChange("rep_organization", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Lincoln High School Athletics"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Representative Type *
                </label>
                <select
                  required
                  value={formData.rep_type}
                  onChange={(e) =>
                    handleInputChange("rep_type", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                >
                  <option value="">Select Type</option>
                  {repTypes.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={formData.rep_email}
                  onChange={(e) =>
                    handleInputChange("rep_email", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="coach@lincolnhs.edu"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.rep_phone}
                  onChange={(e) =>
                    handleInputChange("rep_phone", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Credentials & Certifications
              </label>
              <textarea
                value={formData.rep_credentials}
                onChange={(e) =>
                  handleInputChange("rep_credentials", e.target.value)
                }
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                placeholder="USA Wrestling Level 3 Certified, 15 years coaching experience, State Championship winner 2023..."
              />
            </div>
          </div>

          {/* Athlete Information */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6 flex items-center space-x-2">
              <Trophy className="w-5 h-5" />
              <span>Athlete Information</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Athlete Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.athlete_name}
                  onChange={(e) =>
                    handleInputChange("athlete_name", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Maria Rodriguez"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Age *
                </label>
                <input
                  type="number"
                  required
                  min="13"
                  max="30"
                  value={formData.athlete_age}
                  onChange={(e) =>
                    handleInputChange("athlete_age", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="19"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Primary Sport *
                </label>
                <select
                  required
                  value={formData.athlete_sport}
                  onChange={(e) =>
                    handleInputChange("athlete_sport", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                >
                  <option value="">Select Sport</option>
                  {sportTypes.map((sport) => (
                    <option key={sport} value={sport}>
                      {sport}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Position/Weight Class
                </label>
                <input
                  type="text"
                  value={formData.athlete_position}
                  onChange={(e) =>
                    handleInputChange("athlete_position", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="145 lbs, Point Guard, Midfielder..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Competition Level *
                </label>
                <select
                  required
                  value={formData.athlete_level}
                  onChange={(e) =>
                    handleInputChange("athlete_level", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                >
                  <option value="">Select Level</option>
                  <option value="high_school">High School</option>
                  <option value="junior_college">Junior College</option>
                  <option value="college_d1">College Division I</option>
                  <option value="college_d2">College Division II</option>
                  <option value="college_d3">College Division III</option>
                  <option value="amateur_elite">Elite Amateur</option>
                  <option value="semi_professional">Semi-Professional</option>
                  <option value="professional">Professional</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location (City, State)
                </label>
                <input
                  type="text"
                  value={formData.athlete_location}
                  onChange={(e) =>
                    handleInputChange("athlete_location", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Queens, NY"
                />
              </div>
            </div>
          </div>

          {/* Performance Context */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6 flex items-center space-x-2">
              <Target className="w-5 h-5" />
              <span>Performance Context</span>
            </h3>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Standout Traits & Skills *
                </label>
                <textarea
                  required
                  value={formData.standout_traits}
                  onChange={(e) =>
                    handleInputChange("standout_traits", e.target.value)
                  }
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Exceptional grip control, natural timing, quick recovery between rounds, strong mental focus under pressure..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Adversity Overcome
                </label>
                <textarea
                  value={formData.adversity_overcome}
                  onChange={(e) =>
                    handleInputChange("adversity_overcome", e.target.value)
                  }
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Single-parent household, limited training resources, injury recovery, financial challenges..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Community Impact & Leadership
                </label>
                <textarea
                  value={formData.community_impact}
                  onChange={(e) =>
                    handleInputChange("community_impact", e.target.value)
                  }
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Mentors younger athletes, volunteers at local gym, academic honor roll, team captain..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Training Schedule *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.training_schedule}
                    onChange={(e) =>
                      handleInputChange("training_schedule", e.target.value)
                    }
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                    placeholder="6 days/week, 3 hours/day"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Recent Achievements
                  </label>
                  <input
                    type="text"
                    value={formData.recent_achievements}
                    onChange={(e) =>
                      handleInputChange("recent_achievements", e.target.value)
                    }
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                    placeholder="Regional finalist, State qualifier, Tournament winner..."
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Milestone Potential Assessment *
                </label>
                <textarea
                  required
                  value={formData.milestone_potential}
                  onChange={(e) =>
                    handleInputChange("milestone_potential", e.target.value)
                  }
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="Strong potential for takedown milestones, excellent grip symmetry for motion analysis, consistent performance under fatigue..."
                />
              </div>
            </div>
          </div>

          {/* Technical & Milestone Selection */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6 flex items-center space-x-2">
              <Brain className="w-5 h-5" />
              <span>Recommended Milestones</span>
            </h3>

            <p className="text-gray-600 mb-6">
              Select 2-3 milestones that best match this athlete's strengths and
              potential:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {milestoneOptions.map((milestone) => (
                <label
                  key={milestone.id}
                  className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={formData.preferred_milestones.includes(
                      milestone.id,
                    )}
                    onChange={() => handleMilestoneToggle(milestone.id)}
                    className="w-4 h-4 text-[#B8860B] rounded focus:ring-[#B8860B]"
                  />
                  <span className="text-gray-700">{milestone.label}</span>
                </label>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sample Footage URL (Optional)
                </label>
                <input
                  type="url"
                  value={formData.sample_footage_url}
                  onChange={(e) =>
                    handleInputChange("sample_footage_url", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="https://youtube.com/watch?v=..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Existing Wallet Address (Optional)
                </label>
                <input
                  type="text"
                  value={formData.wallet_address}
                  onChange={(e) =>
                    handleInputChange("wallet_address", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                  placeholder="0x... or request wallet provisioning"
                />
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Notes & Stats
              </label>
              <textarea
                value={formData.stat_sheet_notes}
                onChange={(e) =>
                  handleInputChange("stat_sheet_notes", e.target.value)
                }
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                placeholder="Win/loss record, specific technique details, scouting notes, future potential..."
              />
            </div>
          </div>

          {/* Verification & Agreement */}
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6 flex items-center space-x-2">
              <CheckCircle className="w-5 h-5" />
              <span>Verification & Agreement</span>
            </h3>

            <div className="space-y-4">
              <label className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  required
                  checked={formData.agreement_terms}
                  onChange={(e) =>
                    handleInputChange("agreement_terms", e.target.checked)
                  }
                  className="w-4 h-4 text-[#B8860B] rounded focus:ring-[#B8860B] mt-1"
                />
                <span className="text-gray-700">
                  I agree to the BIM-APES representative terms and understand
                  that this referral will create an athlete profile for
                  investment purposes. I confirm that I have proper authority to
                  submit this athlete for onboarding.
                </span>
              </label>

              <label className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  required
                  checked={formData.data_accuracy}
                  onChange={(e) =>
                    handleInputChange("data_accuracy", e.target.checked)
                  }
                  className="w-4 h-4 text-[#B8860B] rounded focus:ring-[#B8860B] mt-1"
                />
                <span className="text-gray-700">
                  I certify that all information provided is accurate to the
                  best of my knowledge and that I have a legitimate
                  coaching/training relationship with this athlete.
                </span>
              </label>
            </div>
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <button
              type="submit"
              disabled={isSubmitting}
              className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-12 py-4 rounded-lg font-semibold text-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-3 mx-auto"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Submitting Referral...</span>
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  <span>Submit Athlete Referral</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
