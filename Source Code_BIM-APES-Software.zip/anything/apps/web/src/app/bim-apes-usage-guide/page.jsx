"use client";

import { useState } from "react";
import {
  User,
  BarChart3,
  Shield,
  Code,
  Handshake,
  Trophy,
  TrendingUp,
  Download,
  Printer,
  CheckCircle2,
  Lock,
  Mail,
  Key,
  FileText,
  Database,
  LineChart,
  Settings,
  Zap,
  DollarSign,
  Target,
  ArrowRight,
} from "lucide-react";

export default function BIMAPESUsageGuide() {
  const [activeSection, setActiveSection] = useState("registration");

  const handlePrint = () => {
    if (typeof window !== "undefined") {
      window.print();
    }
  };

  const handleDownloadPDF = () => {
    if (typeof window !== "undefined") {
      window.print();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50]">
      {/* Branded Header */}
      <header className="bg-[#1D2B3D]/80 backdrop-blur-lg border-b-2 border-[#B8860B] print:bg-white print:border-black">
        <div className="max-w-[1400px] mx-auto px-8 py-8">
          <div className="flex items-center justify-between print:justify-center">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[#B8860B] to-[#FFD700] rounded-xl flex items-center justify-center shadow-lg shadow-[#B8860B]/50 print:shadow-none">
                <TrendingUp className="w-10 h-10 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white mb-1 print:text-black">
                  BIM APES Usage Guide
                </h1>
                <p className="text-[#B8860B] font-medium print:text-gray-700">
                  Step-by-Step for Developers, Investors & Institutional Funds
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 print:hidden">
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg transition-all"
              >
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button
                onClick={handleDownloadPDF}
                className="flex items-center gap-2 px-6 py-2 bg-[#B8860B] hover:bg-[#A0750A] text-black font-semibold rounded-lg transition-all shadow-lg shadow-[#B8860B]/30"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-[1400px] mx-auto px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 print:grid-cols-1">
          {/* Sidebar Navigation */}
          <aside className="lg:col-span-1 print:hidden">
            <nav className="sticky top-8 bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-4">
              <h2 className="text-white font-bold mb-4 px-2">Guide Sections</h2>
              <div className="space-y-1">
                {sections.map((section) => {
                  const Icon = section.icon;
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                        activeSection === section.id
                          ? "bg-[#B8860B] text-black"
                          : "text-gray-300 hover:bg-white/10"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm font-medium">
                        {section.title}
                      </span>
                    </button>
                  );
                })}
              </div>
            </nav>
          </aside>

          {/* Main Content Area */}
          <main className="lg:col-span-2 space-y-8 print:space-y-6">
            {/* 1. Account Registration */}
            <Section
              id="registration"
              icon={User}
              title="1. Account Registration: Foundation of Access"
            >
              <SubSection title="Account Structure and Security">
                <p className="text-gray-300 mb-4 print:text-black">
                  Upon entering BIM APES, users initiate registration via a
                  multi-layered account system designed for developers,
                  individual investors, and institutional funds.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 print:grid-cols-3">
                  <StepCard
                    icon={Mail}
                    title="Personal/Institutional Profile"
                    description="Input name, email, optional organizational credentials"
                    step="1"
                  />
                  <StepCard
                    icon={Lock}
                    title="Verification"
                    description="Email confirmation and automated KYC via third-party engine"
                    step="2"
                  />
                  <StepCard
                    icon={Key}
                    title="OAuth Integration"
                    description="Link with Google, Microsoft, or enterprise SSO"
                    step="3"
                  />
                </div>

                <DatabaseSchemaBox
                  title="Relevant Database Schema"
                  tables={[
                    {
                      name: "auth_users",
                      description:
                        "Stores user identity (id, name, email, verification status, profile image)",
                    },
                    {
                      name: "auth_accounts",
                      description:
                        "Manages authentication types (OAuth, credentials), tokens, session states",
                    },
                    {
                      name: "auth_sessions",
                      description:
                        "Controls session tokens and expirations for secure, multi-device access",
                    },
                  ]}
                />
              </SubSection>

              <SubSection title="User Experience and Visual Cues">
                <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-5 mb-4 print:bg-gray-50 print:border-gray-300">
                  <div className="flex items-start gap-3 mb-3">
                    <Lock className="w-5 h-5 text-[#B8860B] mt-0.5 print:text-gray-700" />
                    <div>
                      <div className="text-white font-medium mb-1 print:text-black">
                        Lock Icon
                      </div>
                      <div className="text-gray-400 text-sm print:text-gray-600">
                        Indicates KYC/verification steps in progress
                      </div>
                    </div>
                  </div>
                  <ProgressBarExample />
                </div>

                <AnalysisBox>
                  Security and efficient onboarding are paramount for attracting
                  sophisticated developers and institutional investors. OAuth
                  and enterprise SSO support reduce friction, while robust
                  session/token management (including two-step verification and
                  session tracking) ensures privacy and compliance. Modern
                  onboarding is fully digital, reducing manual document exchange
                  and error-prone data entry.
                </AnalysisBox>
              </SubSection>

              <OnboardingTable />
            </Section>

            {/* 2. Profile Configuration */}
            <Section
              id="profile"
              icon={Settings}
              title="2. Profile Configuration & User Type Selection"
            >
              <SubSection title="Multi-Tiered User Types">
                <p className="text-gray-300 mb-4 print:text-black">
                  BIM APES supports three primary user categories, each with
                  tailored interfaces and access levels.
                </p>

                <UserTypeTable />
              </SubSection>

              <SubSection title="Database Integration">
                <DatabaseSchemaBox
                  title="Profile Management Schema"
                  tables={[
                    {
                      name: "user_profiles",
                      description:
                        "Links auth_users to user_type (developer/investor/institutional), tier_level, reputation_score",
                    },
                    {
                      name: "tenants",
                      description:
                        "Manages institutional profiles (tenant_id, tenant_type, tier_level, apex_credit_balance)",
                    },
                    {
                      name: "user_tenant_mappings",
                      description:
                        "Associates users with tenants and defines roles (owner, admin, member, analyst, viewer)",
                    },
                  ]}
                />
              </SubSection>

              <SubSection title="Configuration Steps">
                <ConfigurationSteps />
              </SubSection>
            </Section>

            {/* 3. API Integration */}
            <Section
              id="api"
              icon={Code}
              title="3. API Integration & Developer Access"
            >
              <SubSection title="API Authentication">
                <p className="text-gray-300 mb-4 print:text-black">
                  Developers gain programmatic access through secure API keys
                  and OAuth 2.0 tokens.
                </p>

                <APIAuthenticationTable />
              </SubSection>

              <SubSection title="Core API Endpoints">
                <APIEndpointsDetailedTable />
              </SubSection>

              <SubSection title="Sample Integration Code">
                <CodeExample />
              </SubSection>
            </Section>

            {/* 4. Data Ingestion */}
            <Section
              id="data"
              icon={Database}
              title="4. Data Ingestion & Biometric Processing"
            >
              <SubSection title="Wearable Device Integration">
                <p className="text-gray-300 mb-4 print:text-black">
                  BIM APES accepts biometric data from certified wearable
                  devices through standardized protocols.
                </p>

                <WearableDeviceTable />
              </SubSection>

              <SubSection title="Data Flow Architecture">
                <DataFlowDiagram />
              </SubSection>

              <SubSection title="BIM Calculation Process">
                <BIMCalculationSteps />
              </SubSection>
            </Section>

            {/* 5. Analytics & Performance Tracking */}
            <Section
              id="analytics"
              icon={BarChart3}
              title="5. Analytics & Performance Tracking"
            >
              <SubSection title="Dashboard Access">
                <p className="text-gray-300 mb-4 print:text-black">
                  Access real-time analytics through role-specific dashboards
                  tailored to your user type.
                </p>

                <DashboardAccessTable />
              </SubSection>

              <SubSection title="Key Performance Metrics">
                <PerformanceMetricsTable />
              </SubSection>
            </Section>

            {/* 6. Trading Operations */}
            <Section
              id="trading"
              icon={TrendingUp}
              title="6. Trading Operations & Position Management"
            >
              <SubSection title="Executing Your First Trade">
                <TradingSteps />
              </SubSection>

              <SubSection title="Position Management Tools">
                <PositionManagementTable />
              </SubSection>

              <SubSection title="Risk Management Features">
                <RiskManagementTable />
              </SubSection>
            </Section>

            {/* 7. Smart Contracts & Licensing */}
            <Section
              id="licensing"
              icon={Shield}
              title="7. Smart Contracts & Licensing for Automation"
            >
              <SubSection title="Licensing Tiers">
                <p className="text-gray-300 mb-4 print:text-black">
                  BIM APES offers flexible licensing for end-to-end automation
                  and white-label deployment.
                </p>

                <LicensingTable />
              </SubSection>

              <SubSection title="Smart Contract Execution">
                <SmartContractTable />
              </SubSection>
            </Section>

            {/* 8. Scaling & Production */}
            <Section
              id="scaling"
              icon={Zap}
              title="8. Scaling to Production & For-Profit Engines"
            >
              <SubSection title="Production Deployment Checklist">
                <ProductionChecklist />
              </SubSection>

              <SubSection title="Revenue Models">
                <RevenueModelTable />
              </SubSection>

              <SubSection title="Support & Optimization">
                <SupportTable />
              </SubSection>
            </Section>
          </main>
        </div>
      </div>

      {/* Print Footer */}
      <footer className="hidden print:block mt-12 pt-6 border-t border-gray-300">
        <div className="max-w-[1400px] mx-auto px-8">
          <p className="text-sm text-gray-600 text-center">
            BIM APES Usage Guide | Generated {new Date().toLocaleDateString()}
          </p>
        </div>
      </footer>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          @page { margin: 1in; size: letter; }
          body { background: white !important; }
          .print\\:hidden { display: none !important; }
          .print\\:block { display: block !important; }
          .print\\:grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)) !important; }
          .print\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .print\\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)) !important; }
          .print\\:text-black { color: black !important; }
          .print\\:bg-white { background-color: white !important; }
          .print\\:border-black { border-color: black !important; }
          .print\\:border-gray-300 { border-color: #d1d5db !important; }
          .print\\:bg-gray-50 { background-color: #f9fafb !important; }
          .print\\:text-gray-600 { color: #4b5563 !important; }
          .print\\:text-gray-700 { color: #374151 !important; }
          .print\\:shadow-none { box-shadow: none !important; }
          table { page-break-inside: avoid; }
          .section-container { page-break-inside: avoid; }
        }
      `}</style>
    </div>
  );
}

// Section Component
function Section({ id, icon: Icon, title, children }) {
  return (
    <section
      id={id}
      className="section-container bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-6 print:bg-white print:border print:border-gray-300"
    >
      <div className="flex items-center gap-3 mb-6 print:mb-4">
        <div className="w-10 h-10 bg-[#B8860B]/20 border border-[#B8860B]/30 rounded-lg flex items-center justify-center print:bg-gray-100 print:border-gray-300">
          <Icon className="w-5 h-5 text-[#B8860B] print:text-gray-700" />
        </div>
        <h2 className="text-2xl font-bold text-white print:text-black">
          {title}
        </h2>
      </div>
      {children}
    </section>
  );
}

// SubSection Component
function SubSection({ title, children }) {
  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold text-[#B8860B] mb-3 print:text-black">
        {title}
      </h3>
      {children}
    </div>
  );
}

// Step Card Component
function StepCard({ icon: Icon, title, description, step }) {
  return (
    <div className="bg-[#1A1F3A]/50 border border-[#B8860B]/10 rounded-lg p-4 print:bg-gray-50 print:border-gray-300">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 bg-[#B8860B]/20 border border-[#B8860B]/30 rounded-lg flex items-center justify-center flex-shrink-0 print:bg-gray-200 print:border-gray-400">
          <Icon className="w-4 h-4 text-[#B8860B] print:text-gray-700" />
        </div>
        <div>
          <div className="text-xs text-[#B8860B] font-semibold mb-1 print:text-gray-600">
            Step {step}
          </div>
          <div className="text-white font-medium text-sm mb-1 print:text-black">
            {title}
          </div>
          <div className="text-gray-400 text-xs print:text-gray-600">
            {description}
          </div>
        </div>
      </div>
    </div>
  );
}

// Database Schema Box
function DatabaseSchemaBox({ title, tables }) {
  return (
    <div className="bg-[#0A0E27]/50 border border-[#00D9FF]/20 rounded-lg p-4 mb-4 print:bg-gray-50 print:border-gray-300">
      <div className="flex items-center gap-2 mb-3">
        <Database className="w-4 h-4 text-[#00D9FF] print:text-gray-700" />
        <div className="text-[#00D9FF] font-medium text-sm print:text-black">
          {title}
        </div>
      </div>
      <div className="space-y-2">
        {tables.map((table, i) => (
          <div key={i} className="flex items-start gap-2">
            <ArrowRight className="w-3 h-3 text-[#B8860B] mt-0.5 flex-shrink-0 print:text-gray-600" />
            <div>
              <code className="text-[#00D9FF] text-xs font-mono print:text-black">
                {table.name}
              </code>
              <span className="text-gray-400 text-xs ml-2 print:text-gray-600">
                - {table.description}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Analysis Box
function AnalysisBox({ children }) {
  return (
    <div className="bg-[#B8860B]/10 border-l-4 border-[#B8860B] rounded-r-lg p-4 print:bg-gray-100 print:border-gray-400">
      <div className="flex items-start gap-2">
        <Target className="w-4 h-4 text-[#B8860B] mt-0.5 flex-shrink-0 print:text-gray-700" />
        <p className="text-gray-300 text-sm italic print:text-gray-700">
          {children}
        </p>
      </div>
    </div>
  );
}

// Progress Bar Example
function ProgressBarExample() {
  return (
    <div className="mt-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-gray-400 text-xs print:text-gray-600">
          Account Setup Progress
        </span>
        <span className="text-[#B8860B] text-xs font-semibold print:text-gray-700">
          75%
        </span>
      </div>
      <div className="w-full bg-[#1A1F3A] h-2 rounded-full overflow-hidden print:bg-gray-300">
        <div
          className="bg-[#B8860B] h-full rounded-full"
          style={{ width: "75%" }}
        ></div>
      </div>
    </div>
  );
}

// Onboarding Table
function OnboardingTable() {
  const steps = [
    {
      step: "1",
      action: "Create Account",
      endpoint: "/account/signup",
      duration: "2 min",
    },
    {
      step: "2",
      action: "Email Verification",
      endpoint: "Email confirmation link",
      duration: "Instant",
    },
    {
      step: "3",
      action: "KYC Submission",
      endpoint: "/onboarding/kyc",
      duration: "5-10 min",
    },
    {
      step: "4",
      action: "Profile Configuration",
      endpoint: "/profile",
      duration: "3 min",
    },
    {
      step: "5",
      action: "API Key Generation (Developers)",
      endpoint: "/settings/api-keys",
      duration: "1 min",
    },
  ];

  return (
    <SubSection title="Onboarding Timeline">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-[#1A1F3A] print:bg-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
                Step
              </th>
              <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
                Action
              </th>
              <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
                Endpoint/Location
              </th>
              <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
                Est. Duration
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
            {steps.map((s, i) => (
              <tr
                key={i}
                className="hover:bg-[#1A1F3A]/30 print:hover:bg-white"
              >
                <td className="px-4 py-3">
                  <span className="px-2 py-1 bg-[#B8860B]/20 text-[#B8860B] rounded text-xs font-semibold print:bg-gray-200 print:text-black">
                    {s.step}
                  </span>
                </td>
                <td className="px-4 py-3 text-white font-medium print:text-black">
                  {s.action}
                </td>
                <td className="px-4 py-3 text-[#00D9FF] text-xs font-mono print:text-gray-700">
                  {s.endpoint}
                </td>
                <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                  {s.duration}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SubSection>
  );
}

// User Type Table
function UserTypeTable() {
  const types = [
    {
      type: "Developer",
      access: "API Access, Sandbox Environment",
      features:
        "Build custom integrations, test data ingestion, deploy licensed engines",
      pricing: "Free tier available, pay-per-API-call or monthly subscription",
    },
    {
      type: "Individual Investor",
      access: "Trading Dashboard, Portfolio Management",
      features:
        "Execute trades, track positions, view analytics, access arbitrage signals",
      pricing: "Commission per trade or monthly platform fee",
    },
    {
      type: "Institutional Fund",
      access: "Multi-User Tenant, Advanced Analytics",
      features:
        "Portfolio optimization, risk management, white-label licensing, dedicated support",
      pricing: "Enterprise licensing with volume discounts",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              User Type
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Access Level
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Key Features
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Pricing Model
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {types.map((t, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {t.type}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] print:text-gray-700">
                {t.access}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {t.features}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {t.pricing}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Configuration Steps
function ConfigurationSteps() {
  const steps = [
    "Select user type (Developer/Investor/Institutional)",
    "Configure notification preferences (email, SMS, in-app)",
    "Set risk tolerance levels (Conservative/Balanced/Aggressive)",
    "Link bank account or crypto wallet for funding",
    "Accept terms of service and platform agreements",
  ];

  return (
    <div className="space-y-2">
      {steps.map((step, i) => (
        <div
          key={i}
          className="flex items-start gap-3 bg-[#1A1F3A]/30 p-3 rounded-lg print:bg-gray-50"
        >
          <CheckCircle2 className="w-4 h-4 text-[#B8860B] mt-0.5 flex-shrink-0 print:text-gray-700" />
          <span className="text-gray-300 text-sm print:text-gray-700">
            {step}
          </span>
        </div>
      ))}
    </div>
  );
}

// API Authentication Table
function APIAuthenticationTable() {
  const methods = [
    {
      method: "API Key",
      useCase: "Server-to-server integration",
      security: "High - Store securely, rotate regularly",
    },
    {
      method: "OAuth 2.0",
      useCase: "User-delegated access",
      security: "Highest - Token-based with refresh mechanism",
    },
    {
      method: "Sandbox Key",
      useCase: "Testing and development",
      security: "Medium - Limited to test data",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Authentication Method
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Use Case
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Security Level
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {methods.map((m, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {m.method}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {m.useCase}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] text-xs print:text-gray-700">
                {m.security}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// API Endpoints Detailed Table
function APIEndpointsDetailedTable() {
  const endpoints = [
    {
      endpoint: "POST /api/bim-performance/calculate",
      description: "Calculate BIM score from raw biometric data",
      params: "sport, metrics{}, deviceType",
      response: "bimScore, tier, insights{}",
    },
    {
      endpoint: "GET /api/athletes/list",
      description: "Retrieve athlete profiles with performance data",
      params: "sport?, tier?, limit=50",
      response: "athletes[], totalCount",
    },
    {
      endpoint: "POST /api/trades/execute",
      description: "Execute performance equity swap",
      params: "athleteId, amount, direction",
      response: "tradeId, executionPrice, status",
    },
    {
      endpoint: "GET /api/arbitrage/capture",
      description: "Identify arbitrage opportunities",
      params: "sport?, minSpread=5%",
      response: "opportunities[], expectedReturn",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Endpoint
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Description
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Parameters
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Response
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {endpoints.map((e, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-[#00D9FF] font-mono text-xs print:text-gray-700">
                {e.endpoint}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {e.description}
              </td>
              <td className="px-4 py-3 text-gray-500 text-xs font-mono print:text-gray-600">
                {e.params}
              </td>
              <td className="px-4 py-3 text-gray-500 text-xs font-mono print:text-gray-600">
                {e.response}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Code Example
function CodeExample() {
  return (
    <div className="bg-[#0A0E27] border border-[#B8860B]/20 rounded-lg p-4 print:bg-gray-50 print:border-gray-300">
      <div className="text-[#B8860B] text-xs font-semibold mb-2 print:text-black">
        Sample: Calculate BIM Score
      </div>
      <pre className="text-[#00D9FF] text-xs font-mono overflow-x-auto print:text-black">
        {`const response = await fetch('/api/bim-performance/calculate', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    sport: 'wrestling',
    metrics: {
      takedownEfficiency: 0.87,
      controlTime: 145,
      pinRate: 0.62,
      staminaIndex: 0.91
    },
    deviceType: 'whoop_4'
  })
});

const data = await response.json();
console.log(data.bimScore); // 84.7 (Platinum Tier)`}
      </pre>
    </div>
  );
}

// Wearable Device Table
function WearableDeviceTable() {
  const devices = [
    {
      device: "Whoop 4.0",
      category: "Biometric Band",
      protocol: "Bluetooth LE",
      dataTypes: "Heart rate, HRV, sleep, recovery, strain",
    },
    {
      device: "Garmin Fenix 7",
      category: "GPS Tracker",
      protocol: "ANT+, Bluetooth LE",
      dataTypes: "GPS, heart rate, VO2 max, training load",
    },
    {
      device: "Catapult Vector",
      category: "IMU Sensor",
      protocol: "Proprietary Mesh",
      dataTypes: "Acceleration, velocity, player load, impacts",
    },
    {
      device: "Polar H10",
      category: "Heart Rate Monitor",
      protocol: "Bluetooth LE",
      dataTypes: "Real-time HR, HRV, ECG-level accuracy",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Device
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Category
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Protocol
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Data Types
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {devices.map((d, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {d.device}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] print:text-gray-700">
                {d.category}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {d.protocol}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {d.dataTypes}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Data Flow Diagram
function DataFlowDiagram() {
  const flow = [
    {
      step: "1",
      component: "Wearable Device",
      action: "Captures raw biometric data during training/competition",
    },
    {
      step: "2",
      component: "Mesh Network Sync",
      action: "Data transmitted via Bluetooth/ANT+ to local mesh node",
    },
    {
      step: "3",
      component: "Schema Mapping",
      action: "Raw data transformed to standardized BIM format",
    },
    {
      step: "4",
      component: "BIM Calculation Engine",
      action: "Sport-specific algorithms calculate performance score",
    },
    {
      step: "5",
      component: "Tier Classification",
      action: "AI model assigns tier based on BIM score and trajectory",
    },
    {
      step: "6",
      component: "Dashboard/API",
      action: "Results available in real-time via dashboard or API",
    },
  ];

  return (
    <div className="space-y-3">
      {flow.map((f, i) => (
        <div key={i} className="flex items-start gap-3">
          <div className="w-8 h-8 bg-[#B8860B] text-black rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 print:bg-gray-300">
            {f.step}
          </div>
          <div className="flex-1 bg-[#1A1F3A]/30 p-3 rounded-lg print:bg-gray-50">
            <div className="text-white font-medium text-sm mb-1 print:text-black">
              {f.component}
            </div>
            <div className="text-gray-400 text-xs print:text-gray-600">
              {f.action}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// BIM Calculation Steps
function BIMCalculationSteps() {
  return (
    <div className="bg-[#1A1F3A]/30 border border-[#B8860B]/10 rounded-lg p-4 print:bg-gray-50 print:border-gray-300">
      <div className="text-[#B8860B] font-semibold mb-3 print:text-black">
        BIM Score Formula (Wrestling Example)
      </div>
      <div className="space-y-2 text-sm">
        <div className="flex items-center gap-2">
          <span className="text-gray-500 print:text-gray-600">
            Power Component:
          </span>
          <code className="text-[#00D9FF] text-xs font-mono print:text-black">
            takedownEfficiency × 0.35
          </code>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-500 print:text-gray-600">
            Technique Component:
          </span>
          <code className="text-[#00D9FF] text-xs font-mono print:text-black">
            (controlTime + pinRate) × 0.40
          </code>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-500 print:text-gray-600">
            Endurance Component:
          </span>
          <code className="text-[#00D9FF] text-xs font-mono print:text-black">
            staminaIndex × 0.25
          </code>
        </div>
        <div className="mt-3 pt-3 border-t border-[#B8860B]/20 print:border-gray-300">
          <span className="text-white font-medium print:text-black">
            Final BIM Score = Sum of all components × 100
          </span>
        </div>
      </div>
    </div>
  );
}

// Dashboard Access Table
function DashboardAccessTable() {
  const dashboards = [
    {
      role: "Developer",
      dashboard: "/analytics-dashboard",
      features: "API usage metrics, sandbox activity, error logs",
    },
    {
      role: "Individual Investor",
      dashboard: "/sponsor-hedge-dashboard",
      features: "Portfolio positions, P&L tracking, arbitrage alerts",
    },
    {
      role: "Institutional Fund",
      dashboard: "/nil-advisory-dashboard",
      features: "Multi-athlete portfolios, risk analytics, coalition ETFs",
    },
    {
      role: "Coach",
      dashboard: "/coach-portal",
      features: "Team performance, roster optimization, tier recommendations",
    },
    {
      role: "Scout",
      dashboard: "/scout-dashboard",
      features: "Prospect identification, draft equity cards, talent pipeline",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Role
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Dashboard URL
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Key Features
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {dashboards.map((d, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {d.role}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] font-mono text-xs print:text-gray-700">
                {d.dashboard}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {d.features}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Performance Metrics Table
function PerformanceMetricsTable() {
  const metrics = [
    {
      metric: "BIM Score",
      description: "Overall performance index (0-100)",
      update: "Real-time",
    },
    {
      metric: "Tier Classification",
      description: "Bronze, Silver, Gold, Platinum, Diamond",
      update: "Daily",
    },
    {
      metric: "Growth Trajectory",
      description: "30-day performance trend (+/- %)",
      update: "Daily",
    },
    {
      metric: "Consistency Rating",
      description: "Standard deviation of BIM scores",
      update: "Weekly",
    },
    {
      metric: "NIL Valuation",
      description: "Estimated market value based on tier",
      update: "Real-time",
    },
    {
      metric: "Risk Profile",
      description: "Injury, volatility, and career risk score",
      update: "Weekly",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Metric
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Description
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Update Frequency
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {metrics.map((m, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {m.metric}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {m.description}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] print:text-gray-700">
                {m.update}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Trading Steps
function TradingSteps() {
  const steps = [
    {
      step: "1",
      title: "Browse Athletes",
      action:
        "Navigate to /sponsor-hedge-dashboard or use API to query athletes",
    },
    {
      step: "2",
      title: "Analyze Performance",
      action: "Review BIM scores, tier, growth trajectory, and risk profile",
    },
    {
      step: "3",
      title: "Determine Position Size",
      action:
        "Calculate allocation based on portfolio strategy and risk tolerance",
    },
    {
      step: "4",
      title: "Execute Trade",
      action:
        "POST /api/trades/execute with athleteId, amount, direction (long/short)",
    },
    {
      step: "5",
      title: "Monitor Position",
      action: "Track real-time P&L, set stop-loss orders, rebalance as needed",
    },
  ];

  return (
    <div className="space-y-3">
      {steps.map((s, i) => (
        <div key={i} className="flex items-start gap-3">
          <div className="w-8 h-8 bg-[#B8860B] text-black rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 print:bg-gray-300">
            {s.step}
          </div>
          <div className="flex-1 bg-[#1A1F3A]/30 p-3 rounded-lg print:bg-gray-50">
            <div className="text-white font-medium text-sm mb-1 print:text-black">
              {s.title}
            </div>
            <div className="text-gray-400 text-xs print:text-gray-600">
              {s.action}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// Position Management Table
function PositionManagementTable() {
  const tools = [
    {
      tool: "Real-Time P&L Dashboard",
      description:
        "Live tracking of all open positions with mark-to-market pricing",
    },
    {
      tool: "Automated Rebalancing",
      description:
        "Set target allocations and auto-rebalance on drift threshold",
    },
    {
      tool: "Stop-Loss Orders",
      description:
        "Define maximum loss tolerance per position or portfolio-wide",
    },
    {
      tool: "Performance Attribution",
      description: "Analyze which athletes contribute most to returns",
    },
  ];

  return (
    <div className="space-y-2">
      {tools.map((t, i) => (
        <div
          key={i}
          className="bg-[#1A1F3A]/30 border border-[#B8860B]/10 p-3 rounded-lg print:bg-gray-50 print:border-gray-300"
        >
          <div className="text-white font-medium text-sm mb-1 print:text-black">
            {t.tool}
          </div>
          <div className="text-gray-400 text-xs print:text-gray-600">
            {t.description}
          </div>
        </div>
      ))}
    </div>
  );
}

// Risk Management Table
function RiskManagementTable() {
  const features = [
    {
      feature: "Injury Hedging",
      description:
        "Purchase insurance contracts that pay out if athlete is injured",
    },
    {
      feature: "Underperformance Hedging",
      description: "Hedge against BIM score decline or tier demotion",
    },
    {
      feature: "Volatility Hedging",
      description: "Options-style contracts to profit from performance swings",
    },
    {
      feature: "Portfolio Diversification",
      description: "Spread risk across multiple athletes, sports, and tiers",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Risk Feature
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Description
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {features.map((f, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {f.feature}
              </td>
              <td className="px-4 py-3 text-gray-400 print:text-gray-600">
                {f.description}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Licensing Table
function LicensingTable() {
  const tiers = [
    {
      tier: "Free Tier",
      features: "Sandbox access, 1,000 API calls/month, basic analytics",
      price: "$0/month",
      bestFor: "Developers testing integration",
    },
    {
      tier: "Professional",
      features: "50,000 API calls/month, real-time data, email support",
      price: "$299/month",
      bestFor: "Individual investors and small funds",
    },
    {
      tier: "Enterprise",
      features:
        "Unlimited API calls, white-label deployment, dedicated support",
      price: "Custom pricing",
      bestFor: "Institutional funds and large platforms",
    },
    {
      tier: "Licensed Engine",
      features:
        "Full platform source code, smart contract templates, branding rights",
      price: "$50K+ one-time",
      bestFor: "Building proprietary for-profit engines",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Tier
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Features
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Price
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Best For
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {tiers.map((t, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3">
                <span className="px-3 py-1 bg-[#B8860B]/20 text-[#B8860B] border border-[#B8860B]/30 rounded-full text-xs font-medium print:bg-gray-200 print:text-black print:border-gray-400">
                  {t.tier}
                </span>
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {t.features}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] font-medium print:text-gray-700">
                {t.price}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {t.bestFor}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Smart Contract Table
function SmartContractTable() {
  const contracts = [
    {
      contract: "Milestone Completion",
      trigger: "Athlete achieves performance milestone",
      action: "Auto-distribute rewards to athlete, coach, contributors",
    },
    {
      contract: "Tier Advancement",
      trigger: "BIM score crosses tier threshold for 30 days",
      action: "Update NIL valuation, notify stakeholders, adjust positions",
    },
    {
      contract: "Insurance Payout",
      trigger: "Injury confirmed via verified medical report",
      action: "Transfer insurance funds to hedging position holders",
    },
    {
      contract: "Trade Settlement",
      trigger: "Trade executed on platform",
      action: "Transfer funds, update position ownership, record on ledger",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Contract Type
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Trigger Event
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Automated Action
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {contracts.map((c, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {c.contract}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {c.trigger}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] text-xs print:text-gray-700">
                {c.action}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Production Checklist
function ProductionChecklist() {
  const items = [
    "Complete security audit and penetration testing",
    "Configure production database with replication and backup",
    "Set up monitoring, alerting, and incident response",
    "Establish API rate limits and DDoS protection",
    "Implement comprehensive logging and audit trails",
    "Configure CDN and optimize for global latency",
    "Finalize terms of service and regulatory compliance",
    "Train support team on platform operations",
  ];

  return (
    <div className="space-y-2">
      {items.map((item, i) => (
        <div
          key={i}
          className="flex items-start gap-3 bg-[#1A1F3A]/30 p-3 rounded-lg print:bg-gray-50"
        >
          <CheckCircle2 className="w-4 h-4 text-[#B8860B] mt-0.5 flex-shrink-0 print:text-gray-700" />
          <span className="text-gray-300 text-sm print:text-gray-700">
            {item}
          </span>
        </div>
      ))}
    </div>
  );
}

// Revenue Model Table
function RevenueModelTable() {
  const models = [
    {
      model: "Trading Commissions",
      description: "Charge 0.5-2% per trade executed on platform",
      example: "$1,000 trade = $5-20 revenue",
    },
    {
      model: "Subscription Fees",
      description: "Monthly or annual access to premium analytics and tools",
      example: "$299/month professional tier",
    },
    {
      model: "API Usage Fees",
      description: "Pay-per-call or tiered pricing for API access",
      example: "$0.01 per API call after free tier",
    },
    {
      model: "White-Label Licensing",
      description: "One-time or recurring fees for branded deployment",
      example: "$50K upfront + 10% revenue share",
    },
    {
      model: "Data Licensing",
      description: "Sell aggregated/anonymized biometric data to researchers",
      example: "$10K per dataset",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Revenue Model
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Description
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Example
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {models.map((m, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {m.model}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {m.description}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] text-xs print:text-gray-700">
                {m.example}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Support Table
function SupportTable() {
  const options = [
    {
      tier: "Community (Free)",
      channels: "GitHub issues, community forum",
      response: "Best effort",
      availability: "Community-driven",
    },
    {
      tier: "Professional",
      channels: "Email support, priority forum",
      response: "24-48 hours",
      availability: "Business hours",
    },
    {
      tier: "Enterprise",
      channels: "Dedicated Slack, phone support",
      response: "4-8 hours",
      availability: "24/7",
    },
    {
      tier: "Licensed Engine",
      channels: "Direct engineering contact, custom SLA",
      response: "1-2 hours",
      availability: "24/7 with on-call",
    },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-[#1A1F3A] print:bg-gray-200">
          <tr>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Support Tier
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Channels
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Response Time
            </th>
            <th className="px-4 py-3 text-left text-gray-400 font-medium print:text-black">
              Availability
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#B8860B]/10 print:divide-gray-300">
          {options.map((o, i) => (
            <tr key={i} className="hover:bg-[#1A1F3A]/30 print:hover:bg-white">
              <td className="px-4 py-3 text-white font-medium print:text-black">
                {o.tier}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {o.channels}
              </td>
              <td className="px-4 py-3 text-[#00D9FF] print:text-gray-700">
                {o.response}
              </td>
              <td className="px-4 py-3 text-gray-400 text-xs print:text-gray-600">
                {o.availability}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Section Navigation Data
const sections = [
  { id: "registration", title: "Account Registration", icon: User },
  { id: "profile", title: "Profile Configuration", icon: Settings },
  { id: "api", title: "API Integration", icon: Code },
  { id: "data", title: "Data Ingestion", icon: Database },
  { id: "analytics", title: "Analytics & Tracking", icon: BarChart3 },
  { id: "trading", title: "Trading Operations", icon: TrendingUp },
  { id: "licensing", title: "Smart Contracts & Licensing", icon: Shield },
  { id: "scaling", title: "Scaling to Production", icon: Zap },
];
