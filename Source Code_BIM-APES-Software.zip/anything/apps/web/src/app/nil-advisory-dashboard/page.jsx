"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";
import useNILAdvisoryDashboard from "@/hooks/useNILAdvisoryDashboard";
import DashboardTopBar from "@/components/NILAdvisoryDashboard/DashboardTopBar";
import AthleteCards from "@/components/NILAdvisoryDashboard/AthleteCards";
import MilestoneProgressBars from "@/components/NILAdvisoryDashboard/MilestoneProgressBars";
import SponsorROIPanel from "@/components/NILAdvisoryDashboard/SponsorROIPanel";
import CommunityImpactFooter from "@/components/NILAdvisoryDashboard/CommunityImpactFooter";
import CoalitionETFPanel from "@/components/NILAdvisoryDashboard/CoalitionETFPanel";
import ModuleCoordination from "@/components/NILAdvisoryDashboard/ModuleCoordination";

export default function NILAdvisoryDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [selectedView, setSelectedView] = useState("overview"); // overview, etf, modules, compliance
  const [selectedAthlete, setSelectedAthlete] = useState(null);

  const {
    stipendPool,
    athletes,
    milestones,
    sponsorMetrics,
    communityImpact,
    coalitionETF,
    modules,
    loading,
    error,
    refreshData,
  } = useNILAdvisoryDashboard();

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#C8A882] mb-4"></div>
          <p className="text-[#E8DCC8]">Loading NIL Advisory Dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white/10 border border-[#C8A882]/20 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">
            Authentication Required
          </h2>
          <p className="text-[#E8DCC8] mb-6">
            Please sign in to access the NIL Advisory Dashboard
          </p>
          <a
            href="/account/signin"
            className="inline-block px-6 py-3 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-bold rounded-lg transition-colors shadow-lg"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68]">
      {/* Top Bar */}
      <DashboardTopBar
        stipendPool={stipendPool}
        selectedView={selectedView}
        setSelectedView={setSelectedView}
        onRefresh={refreshData}
      />

      {/* Main Content Area */}
      <div className="max-w-[1800px] mx-auto px-4 py-6">
        {selectedView === "overview" && (
          <div className="grid grid-cols-12 gap-6">
            {/* Left Column - Athlete Cards */}
            <div className="col-span-12 lg:col-span-3">
              <AthleteCards
                athletes={athletes}
                onSelectAthlete={setSelectedAthlete}
              />
            </div>

            {/* Center - Milestone Progress Bars */}
            <div className="col-span-12 lg:col-span-6">
              <MilestoneProgressBars milestones={milestones} />

              {/* Community Impact */}
              <div className="mt-6">
                <CommunityImpactFooter communityImpact={communityImpact} />
              </div>
            </div>

            {/* Right Column - Sponsor ROI Panel */}
            <div className="col-span-12 lg:col-span-3">
              <SponsorROIPanel
                metrics={sponsorMetrics}
                stipendPool={stipendPool}
              />
            </div>
          </div>
        )}

        {selectedView === "etf" && (
          <CoalitionETFPanel coalitionETF={coalitionETF} />
        )}

        {selectedView === "modules" && <ModuleCoordination modules={modules} />}

        {selectedView === "compliance" && (
          <div className="bg-white/5 border border-[#C8A882]/20 rounded-xl p-8 backdrop-blur-lg">
            <h2 className="text-2xl font-bold text-white mb-6">
              Compliance & Audit Trails
            </h2>
            <div className="space-y-4">
              <div className="bg-white/5 border border-[#C8A882]/10 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <svg
                    className="w-5 h-5 text-green-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <span className="text-white font-medium">
                    Privacy Compliance: 100%
                  </span>
                </div>
                <p className="text-[#E8DCC8] text-sm">
                  All sponsor dashboards using anonymized views
                </p>
              </div>

              <div className="bg-white/5 border border-[#C8A882]/10 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <svg
                    className="w-5 h-5 text-green-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <span className="text-white font-medium">
                    Dual-Authorization Active
                  </span>
                </div>
                <p className="text-[#E8DCC8] text-sm">
                  All payouts require two-signer approval
                </p>
              </div>

              <div className="bg-white/5 border border-[#C8A882]/10 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <svg
                    className="w-5 h-5 text-green-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <span className="text-white font-medium">
                    Immutable Audit Trail
                  </span>
                </div>
                <p className="text-[#E8DCC8] text-sm">
                  Blockchain-backed transaction logs
                </p>
              </div>

              <div className="bg-white/5 border border-[#C8A882]/10 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <svg
                    className="w-5 h-5 text-[#C8A882]"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <span className="text-white font-medium">
                    Next Quarterly Audit: 45 days
                  </span>
                </div>
                <p className="text-[#E8DCC8] text-sm">
                  Independent third-party review scheduled
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Athlete Detail Modal */}
      {selectedAthlete && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedAthlete(null)}
        >
          <div
            className="bg-[#1B3A57] border border-[#C8A882]/30 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-[#1B3A57] border-b border-[#C8A882]/20 px-6 py-4 flex items-center justify-between">
              <h3 className="text-xl font-bold text-white">
                Athlete Deep Dive
              </h3>
              <button
                onClick={() => setSelectedAthlete(null)}
                className="text-[#E8DCC8] hover:text-white transition-colors"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            <div className="p-6">
              <p className="text-white">Athlete: {selectedAthlete.name}</p>
              <p className="text-[#E8DCC8] text-sm mt-2">
                Biometric profile and milestone history
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
