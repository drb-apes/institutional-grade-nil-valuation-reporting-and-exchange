"use client";

import { useState, useEffect } from "react";
import {
  TrendingUp,
  Users,
  Target,
  AlertTriangle,
  Star,
  ArrowUp,
  ArrowDown,
  TrendingDown,
  DollarSign,
  Trophy,
  Activity,
  BarChart3,
  Filter,
  RefreshCw,
  Search,
  ChevronRight,
  Eye,
  UserCheck,
  Zap,
  Shield,
  Clock,
  CheckCircle,
  XCircle,
  Pause,
} from "lucide-react";

export default function CoachPortalPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedAthletes, setSelectedAthletes] = useState([]);
  const [riskTolerance, setRiskTolerance] = useState("medium");
  const [timeframe, setTimeframe] = useState(90);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [alerts, setAlerts] = useState(null);

  // Simulate loading data
  useEffect(() => {
    loadDashboardData();
  }, [activeTab, timeframe]);

  const loadDashboardData = async () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setData(generateMockData());
      setLoading(false);
    }, 1000);
  };

  const loadAlerts = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/coach-portal/performance-alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          alert_types: ["all"],
          severity_threshold: "medium",
          timeframe_hours: 24,
        }),
      });
      const alertData = await response.json();
      setAlerts(alertData.alerts);
    } catch (error) {
      console.error("Failed to load alerts:", error);
    }
    setLoading(false);
  };

  const generateMockData = () => ({
    athletes: [
      {
        id: 1,
        name: "Marcus Johnson",
        tier: 2,
        score: 78.5,
        trend: "up",
        change: 5.2,
        investmentScore: 82,
        riskLevel: "medium",
        advancementProbability: 0.75,
        milestones: 3,
        contributions: 4580,
      },
      {
        id: 2,
        name: "Sarah Chen",
        tier: 3,
        score: 85.2,
        trend: "up",
        change: 3.1,
        investmentScore: 88,
        riskLevel: "low",
        advancementProbability: 0.45,
        milestones: 5,
        contributions: 8920,
      },
      {
        id: 3,
        name: "Diego Rodriguez",
        tier: 1,
        score: 68.8,
        trend: "down",
        change: -2.8,
        investmentScore: 65,
        riskLevel: "high",
        advancementProbability: 0.25,
        milestones: 2,
        contributions: 2340,
      },
      {
        id: 4,
        name: "Aisha Patel",
        tier: 2,
        score: 82.1,
        trend: "up",
        change: 7.3,
        investmentScore: 86,
        riskLevel: "low",
        advancementProbability: 0.85,
        milestones: 4,
        contributions: 6750,
      },
      {
        id: 5,
        name: "Kyle Thompson",
        tier: 1,
        score: 72.4,
        trend: "stable",
        change: 0.8,
        investmentScore: 71,
        riskLevel: "medium",
        advancementProbability: 0.55,
        milestones: 3,
        contributions: 3450,
      },
    ],
    summary: {
      totalAthletes: 5,
      averageScore: 77.4,
      topPerformers: 3,
      atRisk: 1,
      totalContributions: 26040,
      activeAlerts: 7,
    },
    tierDistribution: {
      tier1: 2,
      tier2: 2,
      tier3: 1,
    },
    investmentOpportunities: [
      {
        athlete: "Aisha Patel",
        score: 86,
        opportunity: "Tier 3 advancement likely",
        recommendation: "strong_buy",
        timeline: "4-6 weeks",
      },
      {
        athlete: "Marcus Johnson",
        score: 82,
        opportunity: "Momentum building",
        recommendation: "buy",
        timeline: "6-8 weeks",
      },
    ],
    riskAlerts: [
      {
        athlete: "Diego Rodriguez",
        risk: "Performance decline",
        severity: "high",
        action: "Immediate intervention required",
      },
    ],
  });

  const tabs = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "comparison", label: "Multi-Athlete Comparison", icon: Users },
    { id: "tier-recommendations", label: "Tier Recommendations", icon: Target },
    { id: "investment-scoring", label: "Investment Scoring", icon: DollarSign },
    { id: "alerts", label: "Performance Alerts", icon: AlertTriangle },
  ];

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-4xl font-bold text-[#1D2B3D] mb-2">
                  Coach & Scout Portal
                </h1>
                <p className="text-xl text-gray-600">
                  Institutional-grade tools for multi-athlete analysis and
                  investment insights
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <select
                  value={timeframe}
                  onChange={(e) => setTimeframe(Number(e.target.value))}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                >
                  <option value={30}>30 Days</option>
                  <option value={60}>60 Days</option>
                  <option value={90}>90 Days</option>
                  <option value={180}>180 Days</option>
                </select>
                <button
                  onClick={loadDashboardData}
                  disabled={loading}
                  className="flex items-center space-x-2 bg-[#1D2B3D] text-white px-4 py-2 rounded-lg hover:bg-[#B8860B] transition-colors disabled:opacity-50"
                >
                  <RefreshCw
                    className={`w-4 h-4 ${loading ? "animate-spin" : ""}`}
                  />
                  <span>Refresh</span>
                </button>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="border-b border-gray-200">
              <nav className="flex space-x-8">
                {tabs.map((tab) => {
                  const IconComponent = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                        activeTab === tab.id
                          ? "border-[#B8860B] text-[#B8860B]"
                          : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                      }`}
                    >
                      <IconComponent className="w-5 h-5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Content */}
          {activeTab === "overview" && (
            <OverviewTab data={data} loading={loading} />
          )}
          {activeTab === "comparison" && <ComparisonTab />}
          {activeTab === "tier-recommendations" && <TierRecommendationsTab />}
          {activeTab === "investment-scoring" && <InvestmentScoringTab />}
          {activeTab === "alerts" && (
            <AlertsTab
              alerts={alerts}
              loadAlerts={loadAlerts}
              loading={loading}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// **📊 OVERVIEW TAB**
function OverviewTab({ data, loading }) {
  if (loading || !data) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-8">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">
                Total Athletes
              </p>
              <p className="text-3xl font-bold text-[#1D2B3D]">
                {data.summary.totalAthletes}
              </p>
            </div>
            <div className="w-12 h-12 bg-[#B8860B]/10 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-[#B8860B]" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Average Score</p>
              <p className="text-3xl font-bold text-[#1D2B3D]">
                {data.summary.averageScore.toFixed(1)}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">
                Top Performers
              </p>
              <p className="text-3xl font-bold text-[#1D2B3D]">
                {data.summary.topPerformers}
              </p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">
                Total Contributions
              </p>
              <p className="text-3xl font-bold text-[#1D2B3D]">
                ${data.summary.totalContributions.toLocaleString()}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Athletes Performance Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[#1D2B3D]">
              Athlete Performance Overview
            </h3>
            <div className="flex items-center space-x-2">
              <Search className="w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search athletes..."
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Athlete
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tier
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Performance Score
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Investment Score
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Advancement Prob.
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Risk Level
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {data.athletes.map((athlete) => (
                <tr key={athlete.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-[#B8860B]/10 rounded-full flex items-center justify-center mr-3">
                        <User className="w-5 h-5 text-[#B8860B]" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-[#1D2B3D]">
                          {athlete.name}
                        </div>
                        <div className="text-sm text-gray-500">
                          Contributions: $
                          {athlete.contributions.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        athlete.tier === 3
                          ? "bg-yellow-100 text-yellow-800"
                          : athlete.tier === 2
                            ? "bg-blue-100 text-blue-800"
                            : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      Tier {athlete.tier}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="text-sm font-medium text-[#1D2B3D] mr-2">
                        {athlete.score.toFixed(1)}
                      </div>
                      <div
                        className={`flex items-center ${
                          athlete.trend === "up"
                            ? "text-green-600"
                            : athlete.trend === "down"
                              ? "text-red-600"
                              : "text-gray-600"
                        }`}
                      >
                        {athlete.trend === "up" && (
                          <ArrowUp className="w-3 h-3 mr-1" />
                        )}
                        {athlete.trend === "down" && (
                          <ArrowDown className="w-3 h-3 mr-1" />
                        )}
                        <span className="text-xs">
                          {Math.abs(athlete.change).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-[#1D2B3D]">
                      {athlete.investmentScore}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-[#1D2B3D]">
                      {(athlete.advancementProbability * 100).toFixed(0)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        athlete.riskLevel === "low"
                          ? "bg-green-100 text-green-800"
                          : athlete.riskLevel === "medium"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {athlete.riskLevel}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-[#B8860B] hover:text-[#A0750A] mr-3">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="text-[#B8860B] hover:text-[#A0750A]">
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Investment Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-[#1D2B3D] flex items-center">
              <Zap className="w-5 h-5 mr-2 text-[#B8860B]" />
              Investment Opportunities
            </h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {data.investmentOpportunities.map((opp, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium text-[#1D2B3D]">
                      {opp.athlete}
                    </div>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        opp.recommendation === "strong_buy"
                          ? "bg-green-100 text-green-800"
                          : opp.recommendation === "buy"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {opp.recommendation.replace("_", " ").toUpperCase()}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mb-2">
                    {opp.opportunity}
                  </div>
                  <div className="text-xs text-gray-500">
                    Timeline: {opp.timeline}
                  </div>
                  <div className="text-xs text-gray-500">
                    Investment Score: {opp.score}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-[#1D2B3D] flex items-center">
              <Shield className="w-5 h-5 mr-2 text-red-500" />
              Risk Alerts
            </h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {data.riskAlerts.map((alert, index) => (
                <div
                  key={index}
                  className="border border-red-200 rounded-lg p-4 bg-red-50"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium text-[#1D2B3D]">
                      {alert.athlete}
                    </div>
                    <span className="text-xs px-2 py-1 rounded-full bg-red-100 text-red-800">
                      {alert.severity.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-sm text-red-600 mb-2">{alert.risk}</div>
                  <div className="text-xs text-red-500">{alert.action}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// **👥 COMPARISON TAB**
function ComparisonTab() {
  const [selectedAthletes, setSelectedAthletes] = useState([]);
  const [loading, setLoading] = useState(false);

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-[#1D2B3D]">
            Multi-Athlete Comparison
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Compare up to 10 athletes across performance metrics
          </p>
        </div>
        <div className="p-6">
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Select Athletes to Compare
            </h3>
            <p className="text-gray-600 mb-6">
              Choose 2-10 athletes to generate comprehensive comparison analysis
            </p>
            <button className="bg-[#B8860B] text-white px-6 py-2 rounded-lg hover:bg-[#A0750A] transition-colors">
              Select Athletes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// **🎯 TIER RECOMMENDATIONS TAB**
function TierRecommendationsTab() {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-[#1D2B3D]">
            Tier Movement Recommendations
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Data-driven tier advancement and risk assessments
          </p>
        </div>
        <div className="p-6">
          <div className="text-center py-12">
            <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Tier Analysis
            </h3>
            <p className="text-gray-600 mb-6">
              Generate comprehensive tier movement recommendations
            </p>
            <button className="bg-[#B8860B] text-white px-6 py-2 rounded-lg hover:bg-[#A0750A] transition-colors">
              Generate Recommendations
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// **💰 INVESTMENT SCORING TAB**
function InvestmentScoringTab() {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-[#1D2B3D]">
            Investment Potential Scoring
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Institutional-grade investment analysis and portfolio optimization
          </p>
        </div>
        <div className="p-6">
          <div className="text-center py-12">
            <DollarSign className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Investment Analysis
            </h3>
            <p className="text-gray-600 mb-6">
              Score athletes and optimize portfolio allocation
            </p>
            <button className="bg-[#B8860B] text-white px-6 py-2 rounded-lg hover:bg-[#A0750A] transition-colors">
              Run Investment Analysis
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// **🚨 ALERTS TAB**
function AlertsTab({ alerts, loadAlerts, loading }) {
  useEffect(() => {
    if (!alerts && !loading) {
      loadAlerts();
    }
  }, []);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-8">
      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Alerts</p>
              <p className="text-3xl font-bold text-[#1D2B3D]">
                {alerts?.total_alerts || 0}
              </p>
            </div>
            <AlertTriangle className="w-8 h-8 text-[#B8860B]" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Urgent</p>
              <p className="text-3xl font-bold text-red-600">
                {alerts?.summary?.urgent_alerts || 0}
              </p>
            </div>
            <Zap className="w-8 h-8 text-red-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">High Priority</p>
              <p className="text-3xl font-bold text-orange-600">
                {alerts?.summary?.high_priority_alerts || 0}
              </p>
            </div>
            <TrendingUp className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Status</p>
              <p
                className={`text-lg font-bold ${
                  alerts?.summary?.status === "critical"
                    ? "text-red-600"
                    : alerts?.summary?.status === "elevated"
                      ? "text-orange-600"
                      : "text-green-600"
                }`}
              >
                {alerts?.summary?.status?.toUpperCase() || "NORMAL"}
              </p>
            </div>
            <Activity className="w-8 h-8 text-blue-500" />
          </div>
        </div>
      </div>

      {/* Alert Controls */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[#1D2B3D]">
              Performance Alerts
            </h3>
            <div className="flex items-center space-x-4">
              <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option>All Alert Types</option>
                <option>Performance Threshold</option>
                <option>Tier Movement</option>
                <option>Investment Opportunity</option>
                <option>Risk Warning</option>
              </select>
              <button
                onClick={loadAlerts}
                disabled={loading}
                className="flex items-center space-x-2 bg-[#1D2B3D] text-white px-4 py-2 rounded-lg hover:bg-[#B8860B] transition-colors disabled:opacity-50"
              >
                <RefreshCw
                  className={`w-4 h-4 ${loading ? "animate-spin" : ""}`}
                />
                <span>Refresh</span>
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          {alerts?.active_alerts?.length > 0 ? (
            <div className="space-y-4">
              {alerts.active_alerts.slice(0, 10).map((alert) => (
                <AlertCard key={alert.id} alert={alert} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Active Alerts
              </h3>
              <p className="text-gray-600">
                All athletes are performing within normal parameters
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// **🚨 ALERT CARD COMPONENT**
function AlertCard({ alert }) {
  const getAlertIcon = (type, severity) => {
    if (severity === "high")
      return <AlertTriangle className="w-5 h-5 text-red-500" />;
    if (type === "investment_opportunity")
      return <DollarSign className="w-5 h-5 text-green-500" />;
    if (type === "tier_movement")
      return <TrendingUp className="w-5 h-5 text-blue-500" />;
    return <Activity className="w-5 h-5 text-[#B8860B]" />;
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case "high":
        return "border-red-200 bg-red-50";
      case "medium":
        return "border-yellow-200 bg-yellow-50";
      case "low":
        return "border-blue-200 bg-blue-50";
      default:
        return "border-gray-200 bg-gray-50";
    }
  };

  return (
    <div
      className={`border rounded-lg p-4 ${getSeverityColor(alert.severity)}`}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <div className="mt-1">{getAlertIcon(alert.type, alert.severity)}</div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-1">
              <h4 className="font-medium text-[#1D2B3D]">{alert.title}</h4>
              <span
                className={`text-xs px-2 py-1 rounded-full ${
                  alert.severity === "high"
                    ? "bg-red-100 text-red-800"
                    : alert.severity === "medium"
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-blue-100 text-blue-800"
                }`}
              >
                {alert.severity.toUpperCase()}
              </span>
            </div>
            <p className="text-sm text-gray-700 mb-2">{alert.message}</p>
            <div className="flex items-center space-x-4 text-xs text-gray-500">
              <span className="flex items-center space-x-1">
                <UserCheck className="w-3 h-3" />
                <span>{alert.athlete_name}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>{new Date(alert.created_at).toLocaleTimeString()}</span>
              </span>
            </div>
          </div>
        </div>
        <button className="text-[#B8860B] hover:text-[#A0750A] transition-colors">
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {alert.actions && alert.actions.length > 0 && (
        <div className="mt-3 pt-3 border-t border-gray-200">
          <p className="text-xs text-gray-600 mb-2">Recommended Actions:</p>
          <div className="flex flex-wrap gap-2">
            {alert.actions.slice(0, 3).map((action, index) => (
              <span
                key={index}
                className="text-xs bg-white px-2 py-1 rounded border border-gray-300"
              >
                {action.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// **⏳ LOADING SPINNER COMPONENT**
function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#B8860B]"></div>
      <span className="ml-3 text-gray-600">Loading...</span>
    </div>
  );
}

// **👤 USER ICON COMPONENT**
function User({ className }) {
  return (
    <div
      className={`rounded-full bg-gray-300 flex items-center justify-center ${className}`}
    >
      <Users className="w-3 h-3 text-gray-600" />
    </div>
  );
}
