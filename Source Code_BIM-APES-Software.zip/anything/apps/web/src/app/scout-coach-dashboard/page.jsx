"use client";
import { useState, useEffect } from "react";
import {
  Play,
  Target,
  TrendingUp,
  TrendingDown,
  Mic,
  MessageSquare,
  Users,
  Activity,
  Volume2,
  Settings,
  RotateCcw,
  FastForward,
  Loader,
  AlertTriangle,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import useHandleStreamResponse from "@/utils/useHandleStreamResponse";

export default function ScoutCoachDashboard() {
  const [selectedSession, setSelectedSession] = useState("training");
  const [isRecording, setIsRecording] = useState(false);
  const [nilTicker, setNilTicker] = useState([]);
  const [teamBiometrics, setTeamBiometrics] = useState([]);
  const [qaasLogs, setQaasLogs] = useState([]);
  const [candlestickData, setCandlestickData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [teamStats, setTeamStats] = useState(null);

  const handleStreamResponse = useHandleStreamResponse();

  const sessions = [
    { id: "training", label: "Training Session", color: "#4F7942" },
    { id: "season", label: "Season Games", color: "#2563EB" },
    { id: "playoff", label: "Playoff Mode", color: "#8B2635" },
  ];

  useEffect(() => {
    // Fetch initial data
    fetchTeamBiometrics();
    fetchQaasLogs();
    fetchCandlestickData();
    startNILTicker();
  }, [selectedSession]);

  const fetchTeamBiometrics = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `/api/coach-dashboard/team-biometrics?session=${selectedSession}&timeRange=24h&includeHistory=true`,
      );
      const result = await handleStreamResponse(response);

      if (result.athletes) {
        setTeamBiometrics(result.athletes);
        setTeamStats(result.teamStats);

        // Update candlestick data with historical trends
        if (result.historicalTrends) {
          setCandlestickData(
            result.historicalTrends.map((trend) => ({
              time: new Date(trend.timestamp).toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
              }),
              close: trend.averagePerformance,
              high: Math.min(100, trend.averagePerformance + 5),
              low: Math.max(0, trend.averagePerformance - 5),
              volume: trend.dataPoints,
            })),
          );
        }
      } else {
        throw new Error(result.error || "Failed to fetch team data");
      }
    } catch (error) {
      console.error("Team biometrics fetch error:", error);
      setError(error.message);
      // Keep mock data as fallback
      setTeamBiometrics([
        {
          id: 1,
          name: "Jordan M.",
          position: "QB",
          stress: 65,
          fatigue: 40,
          performance: 88,
          alerts: [],
        },
        {
          id: 2,
          name: "Alex K.",
          position: "RB",
          stress: 45,
          fatigue: 60,
          performance: 82,
          alerts: [],
        },
        {
          id: 3,
          name: "Sam L.",
          position: "WR",
          stress: 70,
          fatigue: 35,
          performance: 91,
          alerts: [],
        },
        {
          id: 4,
          name: "Chris P.",
          position: "TE",
          stress: 55,
          fatigue: 50,
          performance: 85,
          alerts: [],
        },
        {
          id: 5,
          name: "Taylor R.",
          position: "OL",
          stress: 50,
          fatigue: 65,
          performance: 79,
          alerts: [],
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchQaasLogs = async () => {
    setQaasLogs([
      {
        id: 1,
        athlete: "Jordan M.",
        prompt: "How do you handle pressure in 4th quarter?",
        response: "Stay calm, trust my training, communicate with team",
        timestamp: "2:34 PM",
        score: 92,
      },
      {
        id: 2,
        athlete: "Alex K.",
        prompt: "Describe your pre-game mindset",
        response: "Focused energy, visualize success, ready to execute",
        timestamp: "2:31 PM",
        score: 88,
      },
      {
        id: 3,
        athlete: "Sam L.",
        prompt: "How do you adapt when coverage changes?",
        response: "Read the field quickly, adjust route, signal QB",
        timestamp: "2:28 PM",
        score: 95,
      },
    ]);
  };

  const fetchCandlestickData = async () => {
    const mockData = Array.from({ length: 20 }, (_, i) => ({
      time: `${i + 1}:00`,
      open: 80 + Math.random() * 20,
      high: 85 + Math.random() * 25,
      low: 75 + Math.random() * 15,
      close: 78 + Math.random() * 22,
      volume: Math.floor(Math.random() * 100),
    }));
    setCandlestickData(mockData);
  };

  const startNILTicker = () => {
    const mockTicker = [
      { athlete: "Jordan M.", change: "+12", direction: "up", value: 87 },
      { athlete: "Sam L.", change: "+8", direction: "up", value: 91 },
      { athlete: "Chris P.", change: "-3", direction: "down", value: 82 },
      { athlete: "Alex K.", change: "+15", direction: "up", value: 89 },
      { athlete: "Taylor R.", change: "+5", direction: "up", value: 78 },
    ];
    setNilTicker(mockTicker);
  };

  const handleTagAthlete = (athleteId, tag) => {
    console.log(`Tagged athlete ${athleteId} with: ${tag}`);
    // Implementation for tagging
  };

  const handleVoicePrompt = () => {
    setIsRecording(!isRecording);
    console.log(isRecording ? "Stopping recording" : "Starting voice prompt");
  };

  const getStressColor = (stress) => {
    if (stress < 40) return "#4F7942";
    if (stress < 70) return "#D97706";
    return "#8B2635";
  };

  return (
    <div className="min-h-screen bg-[#1A1A1A] text-white">
      {/* Top Navigation Bar */}
      <div className="bg-[#2D2D2D] border-b border-[#404040] px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">
            Scout & Coach Pod Dashboard
          </h1>

          {/* Session Selection */}
          <div className="flex space-x-2">
            {sessions.map((session) => (
              <button
                key={session.id}
                onClick={() => setSelectedSession(session.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedSession === session.id
                    ? "text-white"
                    : "bg-[#404040] text-[#C0C0C0] hover:bg-[#525252]"
                }`}
                style={{
                  backgroundColor:
                    selectedSession === session.id ? session.color : undefined,
                }}
              >
                {session.label}
              </button>
            ))}
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-3">
            <button
              onClick={handleVoicePrompt}
              className={`p-3 rounded-xl transition-all ${
                isRecording
                  ? "bg-[#8B2635] text-white"
                  : "bg-[#404040] text-[#C0C0C0] hover:bg-[#525252]"
              }`}
            >
              {isRecording ? <Volume2 size={20} /> : <Mic size={20} />}
            </button>
            <button className="p-3 rounded-xl bg-[#404040] text-[#C0C0C0] hover:bg-[#525252]">
              <Settings size={20} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Left Panel - Team Biometric Heatmap */}
        <div className="w-80 bg-[#2D2D2D] border-r border-[#404040] p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Team Biometrics</h2>
            <div className="flex items-center space-x-2">
              {isLoading && (
                <Loader size={16} className="text-[#C0C0C0] animate-spin" />
              )}
              <div className="text-sm text-[#9CA3AF]">
                {isLoading ? "Loading..." : "Live Feed"}
              </div>
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="bg-[#8B2635] rounded-lg p-3 mb-4 border border-[#A82F3F]">
              <div className="flex items-center space-x-2">
                <AlertTriangle size={16} className="text-white" />
                <span className="text-sm text-white">API Error</span>
              </div>
              <div className="text-xs text-[#FFB3B3] mt-1">
                {error} - Using cached data
              </div>
            </div>
          )}

          {/* Team Stats Summary */}
          {teamStats && (
            <div className="bg-[#1A1A1A] rounded-lg p-3 mb-4 border border-[#525252]">
              <div className="text-sm font-medium text-[#C0C0C0] mb-2">
                Team Overview
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[#9CA3AF]">Avg Performance:</span>
                  <span className="text-white font-bold ml-1">
                    {teamStats.averagePerformance}
                  </span>
                </div>
                <div>
                  <span className="text-[#9CA3AF]">Readiness:</span>
                  <span
                    className={`font-bold ml-1 ${
                      teamStats.readinessLevel === "Ready"
                        ? "text-[#4F7942]"
                        : teamStats.readinessLevel === "Caution"
                          ? "text-[#D97706]"
                          : "text-[#8B2635]"
                    }`}
                  >
                    {teamStats.readinessLevel}
                  </span>
                </div>
                <div>
                  <span className="text-[#9CA3AF]">Team Morale:</span>
                  <span className="text-white font-bold ml-1">
                    {teamStats.teamMorale}%
                  </span>
                </div>
                <div>
                  <span className="text-[#9CA3AF]">Athletes:</span>
                  <span className="text-white font-bold ml-1">
                    {teamStats.totalAthletes}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-4">
            {teamBiometrics.map((athlete) => (
              <div
                key={athlete.id}
                className="bg-[#1A1A1A] rounded-xl p-4 border border-[#525252] relative"
              >
                {/* Alert Indicator */}
                {athlete.alerts && athlete.alerts.length > 0 && (
                  <div className="absolute top-2 right-2">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        athlete.alerts.some((a) => a.severity === "high")
                          ? "bg-[#8B2635]"
                          : athlete.alerts.some((a) => a.severity === "medium")
                            ? "bg-[#D97706]"
                            : "bg-[#4F7942]"
                      } animate-pulse`}
                    ></div>
                  </div>
                )}

                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="font-semibold text-white">
                      {athlete.name}
                    </div>
                    <div className="text-sm text-[#C0C0C0]">
                      {athlete.position}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#C0C0C0]">
                      {athlete.performance}
                    </div>
                    <div className="text-xs text-[#9CA3AF]">NIL Score</div>
                  </div>
                </div>

                {/* Biometric Bars */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#C0C0C0]">Stress</span>
                    <span style={{ color: getStressColor(athlete.stress) }}>
                      {athlete.stress}%
                    </span>
                  </div>
                  <div className="w-full bg-[#404040] rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all duration-300"
                      style={{
                        width: `${athlete.stress}%`,
                        backgroundColor: getStressColor(athlete.stress),
                      }}
                    ></div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#C0C0C0]">Fatigue</span>
                    <span className="text-[#D97706]">{athlete.fatigue}%</span>
                  </div>
                  <div className="w-full bg-[#404040] rounded-full h-2">
                    <div
                      className="bg-[#D97706] h-2 rounded-full transition-all duration-300"
                      style={{ width: `${athlete.fatigue}%` }}
                    ></div>
                  </div>

                  {/* Additional metrics if available from API */}
                  {athlete.recovery && (
                    <>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-[#C0C0C0]">Recovery</span>
                        <span className="text-[#4F7942]">
                          {athlete.recovery}%
                        </span>
                      </div>
                      <div className="w-full bg-[#404040] rounded-full h-2">
                        <div
                          className="bg-[#4F7942] h-2 rounded-full transition-all duration-300"
                          style={{ width: `${athlete.recovery}%` }}
                        ></div>
                      </div>
                    </>
                  )}
                </div>

                {/* Alert Messages */}
                {athlete.alerts && athlete.alerts.length > 0 && (
                  <div className="mt-3 space-y-1">
                    {athlete.alerts.slice(0, 2).map((alert, index) => (
                      <div
                        key={index}
                        className="text-xs p-2 rounded bg-[#2D2D2D] border-l-2"
                        style={{
                          borderLeftColor:
                            alert.severity === "high"
                              ? "#8B2635"
                              : alert.severity === "medium"
                                ? "#D97706"
                                : "#4F7942",
                        }}
                      >
                        <div className="font-medium text-white">
                          {alert.message}
                        </div>
                        <div className="text-[#9CA3AF]">
                          {alert.recommendation}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Quick Actions */}
                <div className="flex space-x-2 mt-3">
                  <button
                    onClick={() => handleTagAthlete(athlete.id, "focus")}
                    className="px-3 py-1 bg-[#2563EB] text-xs rounded-lg hover:bg-[#1D4ED8]"
                  >
                    Tag Focus
                  </button>
                  <button
                    onClick={() => handleTagAthlete(athlete.id, "rest")}
                    className="px-3 py-1 bg-[#4F7942] text-xs rounded-lg hover:bg-[#3F5E35]"
                  >
                    Tag Rest
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Center Panel - Candlestick Chart */}
        <div className="flex-1 p-6">
          <div className="bg-[#2D2D2D] rounded-xl p-6 h-full border border-[#404040]">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Performance Analytics</h2>
              <div className="flex items-center space-x-3">
                <button className="p-2 rounded-lg bg-[#404040] hover:bg-[#525252]">
                  <RotateCcw size={16} />
                </button>
                <button className="p-2 rounded-lg bg-[#404040] hover:bg-[#525252]">
                  <FastForward size={16} />
                </button>
                <div className="text-sm text-[#9CA3AF]">
                  Exit Signals: Active
                </div>
              </div>
            </div>

            {/* Chart Container */}
            <div className="h-96 mb-6">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={candlestickData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#525252" />
                  <XAxis dataKey="time" stroke="#C0C0C0" fontSize={12} />
                  <YAxis stroke="#C0C0C0" fontSize={12} />
                  <Line
                    type="monotone"
                    dataKey="close"
                    stroke="#C0C0C0"
                    strokeWidth={2}
                    dot={{ fill: "#C0C0C0", strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, stroke: "#C0C0C0", strokeWidth: 2 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="high"
                    stroke="#4F7942"
                    strokeWidth={1}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="low"
                    stroke="#8B2635"
                    strokeWidth={1}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-4 gap-4">
              {[
                {
                  label: "Team Average",
                  value: "85.2",
                  trend: "+3.2",
                  up: true,
                },
                {
                  label: "Peak Performance",
                  value: "91.8",
                  trend: "+1.5",
                  up: true,
                },
                {
                  label: "Stress Index",
                  value: "58%",
                  trend: "-5%",
                  up: false,
                },
                {
                  label: "Exit Probability",
                  value: "12%",
                  trend: "-2%",
                  up: false,
                },
              ].map((metric, index) => (
                <div
                  key={index}
                  className="bg-[#1A1A1A] rounded-lg p-4 border border-[#525252]"
                >
                  <div className="text-sm text-[#9CA3AF] mb-1">
                    {metric.label}
                  </div>
                  <div className="text-xl font-bold text-white mb-1">
                    {metric.value}
                  </div>
                  <div
                    className={`flex items-center text-sm ${
                      metric.up ? "text-[#4F7942]" : "text-[#8B2635]"
                    }`}
                  >
                    {metric.up ? (
                      <TrendingUp size={14} />
                    ) : (
                      <TrendingDown size={14} />
                    )}
                    <span className="ml-1">{metric.trend}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel - QaaS Logs */}
        <div className="w-96 bg-[#2D2D2D] border-l border-[#404040] p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">QaaS Prompt Logs</h2>
            <button className="p-2 rounded-lg bg-[#C0C0C0] hover:bg-[#A8A8A8] text-[#1A1A1A]">
              <MessageSquare size={16} />
            </button>
          </div>

          <div className="space-y-4 mb-6">
            {qaasLogs.map((log) => (
              <div
                key={log.id}
                className="bg-[#1A1A1A] rounded-xl p-4 border border-[#525252]"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-white">
                    {log.athlete}
                  </span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-[#9CA3AF]">
                      {log.timestamp}
                    </span>
                    <div className="bg-[#C0C0C0] text-[#1A1A1A] text-xs px-2 py-1 rounded">
                      {log.score}
                    </div>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="text-sm text-[#9CA3AF] mb-1">Prompt:</div>
                  <div className="text-sm text-[#2563EB]">{log.prompt}</div>
                </div>

                <div>
                  <div className="text-sm text-[#9CA3AF] mb-1">Response:</div>
                  <div className="text-sm text-[#C0C0C0]">{log.response}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Voice Prompt Interface */}
          <div className="bg-[#1A1A1A] rounded-xl p-4 border border-[#525252]">
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold">Voice Prompt</span>
              <div
                className={`w-3 h-3 rounded-full ${
                  isRecording ? "bg-[#8B2635] animate-pulse" : "bg-[#525252]"
                }`}
              ></div>
            </div>

            <button
              onClick={handleVoicePrompt}
              className={`w-full p-4 rounded-lg font-medium transition-all ${
                isRecording
                  ? "bg-[#8B2635] hover:bg-[#7A1F2C] text-white"
                  : "bg-[#C0C0C0] hover:bg-[#A8A8A8] text-[#1A1A1A]"
              }`}
            >
              {isRecording ? "Stop Recording" : "Start Voice Prompt"}
            </button>

            <div className="text-xs text-[#9CA3AF] mt-2 text-center">
              {isRecording ? "Listening..." : "Tap to begin recording"}
            </div>
          </div>
        </div>
      </div>

      {/* Footer NIL Ticker */}
      <div className="bg-[#2D2D2D] border-t border-[#404040] px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity size={16} className="text-[#C0C0C0]" />
            <span className="text-sm font-medium">NIL Valuation Shifts:</span>
          </div>

          <div className="flex items-center space-x-6 overflow-x-auto">
            {nilTicker.map((item, index) => (
              <div
                key={index}
                className="flex items-center space-x-2 whitespace-nowrap"
              >
                <span className="text-sm text-[#C0C0C0]">{item.athlete}</span>
                <div
                  className={`flex items-center space-x-1 ${
                    item.direction === "up"
                      ? "text-[#4F7942]"
                      : "text-[#8B2635]"
                  }`}
                >
                  {item.direction === "up" ? (
                    <TrendingUp size={14} />
                  ) : (
                    <TrendingDown size={14} />
                  )}
                  <span className="text-sm font-medium">{item.change}</span>
                </div>
                <span className="text-sm text-white font-bold">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
