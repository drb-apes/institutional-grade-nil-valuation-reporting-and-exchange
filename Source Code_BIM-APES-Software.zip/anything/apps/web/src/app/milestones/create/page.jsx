"use client";

import { useState } from "react";
import useUser from "@/utils/useUser";
import {
  Target,
  Calendar,
  DollarSign,
  Plus,
  Minus,
  ArrowLeft,
  Trophy,
  TrendingUp,
  Clock,
  Zap,
} from "lucide-react";

export default function CreateMilestonePage() {
  const { data: user, loading: userLoading } = useUser();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    target_date: "",
    reward_pool: 0,
    target_metrics: [],
  });

  const [currentMetric, setCurrentMetric] = useState({
    name: "",
    target_value: "",
    unit: "",
    description: "",
  });

  // Common metric types for quick selection
  const commonMetrics = [
    { name: "Sprint Time", unit: "seconds", description: "40-yard dash time" },
    {
      name: "Jump Height",
      unit: "inches",
      description: "Vertical jump measurement",
    },
    {
      name: "Bench Press",
      unit: "lbs",
      description: "Maximum bench press weight",
    },
    { name: "Mile Time", unit: "minutes", description: "One mile run time" },
    {
      name: "Points Scored",
      unit: "points",
      description: "Game performance metric",
    },
    {
      name: "Training Sessions",
      unit: "sessions",
      description: "Completed training sessions",
    },
  ];

  const addMetric = () => {
    if (!currentMetric.name || !currentMetric.target_value) {
      return;
    }

    setFormData((prev) => ({
      ...prev,
      target_metrics: [...prev.target_metrics, { ...currentMetric }],
    }));

    setCurrentMetric({
      name: "",
      target_value: "",
      unit: "",
      description: "",
    });
  };

  const removeMetric = (index) => {
    setFormData((prev) => ({
      ...prev,
      target_metrics: prev.target_metrics.filter((_, i) => i !== index),
    }));
  };

  const selectCommonMetric = (metric) => {
    setCurrentMetric({
      ...currentMetric,
      name: metric.name,
      unit: metric.unit,
      description: metric.description,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.title || formData.target_metrics.length === 0) {
      setError("Please provide a title and at least one target metric");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/milestones/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create milestone");
      }

      const result = await response.json();
      console.log("Milestone created:", result);

      // Redirect to dashboard
      window.location.href = "/dashboard";
    } catch (error) {
      console.error("Error creating milestone:", error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#B8860B] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Authentication Required</h1>
          <p className="text-gray-600 mb-6">
            Please sign in to create milestones
          </p>
          <a
            href="/account/signin"
            className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors text-white"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center mb-8">
            <button
              onClick={() => window.history.back()}
              className="bg-white/70 hover:bg-white border border-[#1D2B3D]/20 p-2 rounded-lg transition-colors mr-4"
            >
              <ArrowLeft className="w-5 h-5 text-[#1D2B3D]" />
            </button>
            <div>
              <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-[#1D2B3D] via-[#B8860B] to-[#1D2B3D] bg-clip-text text-transparent">
                Create Milestone
              </h1>
              <p className="text-gray-600">
                Set your performance targets and enable fan support
              </p>
            </div>
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4 mb-6">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Basic Information */}
            <div className="bg-white/70 rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
              <h2 className="text-xl font-semibold mb-4 flex items-center text-[#1D2B3D]">
                <Target className="w-5 h-5 mr-2 text-[#B8860B]" />
                Milestone Details
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Title *
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        title: e.target.value,
                      }))
                    }
                    placeholder="e.g., Improve 40-yard dash time"
                    className="w-full bg-white border border-[#1D2B3D]/20 rounded-lg px-4 py-3 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        description: e.target.value,
                      }))
                    }
                    placeholder="Describe your milestone goals and training plan..."
                    rows="3"
                    className="w-full bg-white border border-[#1D2B3D]/20 rounded-lg px-4 py-3 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Calendar className="w-4 h-4 inline mr-1" />
                      Target Date
                    </label>
                    <input
                      type="date"
                      value={formData.target_date}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          target_date: e.target.value,
                        }))
                      }
                      className="w-full bg-white border border-[#1D2B3D]/20 rounded-lg px-4 py-3 text-[#1D2B3D] focus:border-[#B8860B] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <DollarSign className="w-4 h-4 inline mr-1" />
                      Initial Reward Pool
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.reward_pool}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          reward_pool: parseFloat(e.target.value) || 0,
                        }))
                      }
                      placeholder="0.00"
                      className="w-full bg-white border border-[#1D2B3D]/20 rounded-lg px-4 py-3 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Target Metrics */}
            <div className="bg-white/70 rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
              <h2 className="text-xl font-semibold mb-4 flex items-center text-[#1D2B3D]">
                <TrendingUp className="w-5 h-5 mr-2 text-[#B8860B]" />
                Target Metrics
              </h2>

              {/* Common Metrics Quick Select */}
              <div className="mb-6">
                <p className="text-sm text-gray-600 mb-3">
                  Quick select common metrics:
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {commonMetrics.map((metric, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => selectCommonMetric(metric)}
                      className="bg-[#1D2B3D]/10 hover:bg-[#1D2B3D]/20 border border-[#1D2B3D]/20 hover:border-[#B8860B]/50 px-3 py-2 rounded-lg text-sm transition-colors text-left"
                    >
                      <div className="font-medium text-[#1D2B3D]">
                        {metric.name}
                      </div>
                      <div className="text-xs text-gray-600">{metric.unit}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Add New Metric Form */}
              <div className="bg-[#1D2B3D]/5 rounded-lg p-4 mb-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
                  <input
                    type="text"
                    value={currentMetric.name}
                    onChange={(e) =>
                      setCurrentMetric((prev) => ({
                        ...prev,
                        name: e.target.value,
                      }))
                    }
                    placeholder="Metric name"
                    className="bg-white border border-[#1D2B3D]/20 rounded-lg px-3 py-2 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                  />
                  <input
                    type="text"
                    value={currentMetric.target_value}
                    onChange={(e) =>
                      setCurrentMetric((prev) => ({
                        ...prev,
                        target_value: e.target.value,
                      }))
                    }
                    placeholder="Target value"
                    className="bg-white border border-[#1D2B3D]/20 rounded-lg px-3 py-2 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                  />
                  <input
                    type="text"
                    value={currentMetric.unit}
                    onChange={(e) =>
                      setCurrentMetric((prev) => ({
                        ...prev,
                        unit: e.target.value,
                      }))
                    }
                    placeholder="Unit (e.g., seconds)"
                    className="bg-white border border-[#1D2B3D]/20 rounded-lg px-3 py-2 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={addMetric}
                    disabled={
                      !currentMetric.name || !currentMetric.target_value
                    }
                    className="bg-[#1D2B3D] hover:bg-[#B8860B] disabled:bg-gray-400 disabled:cursor-not-allowed px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center text-white"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add
                  </button>
                </div>
                <input
                  type="text"
                  value={currentMetric.description}
                  onChange={(e) =>
                    setCurrentMetric((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  placeholder="Optional description"
                  className="w-full bg-white border border-[#1D2B3D]/20 rounded-lg px-3 py-2 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                />
              </div>

              {/* Current Metrics List */}
              {formData.target_metrics.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-700">
                    Target Metrics ({formData.target_metrics.length}):
                  </p>
                  {formData.target_metrics.map((metric, index) => (
                    <div
                      key={index}
                      className="bg-white border border-[#1D2B3D]/20 rounded-lg p-3 flex items-center justify-between"
                    >
                      <div>
                        <div className="font-medium text-[#1D2B3D]">
                          {metric.name}: {metric.target_value} {metric.unit}
                        </div>
                        {metric.description && (
                          <div className="text-sm text-gray-600">
                            {metric.description}
                          </div>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => removeMetric(index)}
                        className="bg-red-500/20 hover:bg-red-500/30 text-red-600 p-1 rounded transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {formData.target_metrics.length === 0 && (
                <div className="text-center py-8 text-gray-600">
                  <Trophy className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>
                    No metrics added yet. Add at least one target metric to
                    continue.
                  </p>
                </div>
              )}
            </div>

            {/* Submit */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                <Zap className="w-4 h-4 inline mr-1" />
                Creating a milestone will make it visible to fans who can
                contribute to your success
              </div>

              <button
                type="submit"
                disabled={
                  loading ||
                  !formData.title ||
                  formData.target_metrics.length === 0
                }
                className="bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] hover:from-[#B8860B] hover:to-[#1D2B3D] disabled:from-gray-400 disabled:to-gray-500 disabled:cursor-not-allowed px-8 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center space-x-2 text-white"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Creating...</span>
                  </>
                ) : (
                  <>
                    <Target className="w-4 h-4" />
                    <span>Create Milestone</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
