"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Target,
  Plus,
  Calendar,
  DollarSign,
  TrendingUp,
  Users,
  CheckCircle,
  Clock,
  XCircle,
  Eye,
  Filter,
  Search,
} from "lucide-react";

export default function MilestonesPage() {
  const { data: user, loading: userLoading } = useUser();
  const [milestones, setMilestones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all"); // all, active, completed, failed
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchMilestones();
  }, [filter]);

  const fetchMilestones = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (filter !== "all") {
        params.append("status", filter);
      }

      const response = await fetch(`/api/milestones/list?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch milestones");
      }

      const data = await response.json();
      setMilestones(data.milestones || []);
    } catch (error) {
      console.error("Error fetching milestones:", error);
      setError("Failed to load milestones");
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-[#B8860B]" />;
      case "failed":
      case "cancelled":
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Clock className="w-5 h-5 text-[#1D2B3D]" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "completed":
        return "border-[#B8860B]/30 bg-[#B8860B]/10";
      case "failed":
      case "cancelled":
        return "border-red-500/30 bg-red-500/10";
      default:
        return "border-[#1D2B3D]/30 bg-[#1D2B3D]/10";
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "No deadline";
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const filteredMilestones = milestones.filter(
    (milestone) =>
      milestone.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      milestone.athlete_name?.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#B8860B] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading milestones...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-[#1D2B3D] via-[#B8860B] to-[#1D2B3D] bg-clip-text text-transparent">
                Milestones
              </h1>
              <p className="text-gray-600">
                Track performance goals and support athletic achievements
              </p>
            </div>

            {user && (
              <a
                href="/milestones/create"
                className="bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] hover:from-[#B8860B] hover:to-[#1D2B3D] px-6 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center space-x-2 mt-4 md:mt-0 text-white"
              >
                <Plus className="w-5 h-5" />
                <span>Create Milestone</span>
              </a>
            )}
          </div>

          {/* Filters and Search */}
          <div className="bg-white/70 rounded-xl p-6 border border-[#1D2B3D]/20 mb-8 shadow-lg">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
              {/* Status Filter */}
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-600" />
                <select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                  className="bg-white border border-[#1D2B3D]/20 rounded-lg px-3 py-2 text-[#1D2B3D] focus:border-[#B8860B] focus:outline-none"
                >
                  <option value="all">All Milestones</option>
                  <option value="active">Active</option>
                  <option value="completed">Completed</option>
                  <option value="failed">Failed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              {/* Search */}
              <div className="flex-1 relative">
                <Search className="w-4 h-4 text-gray-600 absolute left-3 top-1/2 transform -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search milestones or athletes..."
                  className="w-full bg-white border border-[#1D2B3D]/20 rounded-lg pl-10 pr-4 py-2 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none"
                />
              </div>

              {/* Stats */}
              <div className="flex items-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center space-x-1">
                  <Target className="w-4 h-4" />
                  <span>{filteredMilestones.length} milestones</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span>
                    {new Set(milestones.map((m) => m.athlete_id)).size} athletes
                  </span>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4 mb-6">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          {/* Milestones Grid */}
          {filteredMilestones.length === 0 ? (
            <div className="text-center py-12">
              <Target className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-semibold mb-2 text-[#1D2B3D]">
                {searchTerm ? "No matching milestones" : "No milestones found"}
              </h3>
              <p className="text-gray-600 mb-6">
                {searchTerm
                  ? "Try adjusting your search terms or filters"
                  : "Be the first to create a milestone and start your journey"}
              </p>
              {user && !searchTerm && (
                <a
                  href="/milestones/create"
                  className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors inline-flex items-center space-x-2 text-white"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Your First Milestone</span>
                </a>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMilestones.map((milestone) => (
                <div
                  key={milestone.id}
                  className={`bg-white/80 rounded-xl p-6 border transition-all duration-300 hover:border-opacity-70 hover:shadow-lg ${getStatusColor(milestone.milestone_status)}`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(milestone.milestone_status)}
                      <span className="text-sm font-medium text-gray-600 capitalize">
                        {milestone.milestone_status}
                      </span>
                    </div>
                    <button className="text-gray-500 hover:text-[#1D2B3D] transition-colors">
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Title and Athlete */}
                  <h3 className="text-lg font-semibold mb-2 text-[#1D2B3D]">
                    {milestone.title}
                  </h3>
                  <p className="text-sm text-[#B8860B] mb-3">
                    by {milestone.athlete_name || "Unknown Athlete"}
                  </p>

                  {/* Description */}
                  {milestone.description && (
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                      {milestone.description}
                    </p>
                  )}

                  {/* Metrics Preview */}
                  <div className="mb-4">
                    <div className="flex items-center space-x-1 mb-2">
                      <TrendingUp className="w-4 h-4 text-[#1D2B3D]" />
                      <span className="text-sm font-medium text-gray-600">
                        Target Metrics (
                        {Object.keys(milestone.target_metrics || {}).length})
                      </span>
                    </div>
                    <div className="space-y-1">
                      {Object.entries(milestone.target_metrics || {})
                        .slice(0, 2)
                        .map(([key, value]) => (
                          <div key={key} className="text-xs text-gray-500">
                            {key}:{" "}
                            {typeof value === "object"
                              ? JSON.stringify(value)
                              : value}
                          </div>
                        ))}
                      {Object.keys(milestone.target_metrics || {}).length >
                        2 && (
                        <div className="text-xs text-gray-400">
                          +{Object.keys(milestone.target_metrics).length - 2}{" "}
                          more
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-[#B8860B]/10 rounded-lg p-3">
                      <div className="flex items-center space-x-1 mb-1">
                        <DollarSign className="w-3 h-3 text-[#B8860B]" />
                        <span className="text-xs text-gray-600">Pool</span>
                      </div>
                      <div className="text-sm font-semibold text-[#B8860B]">
                        $
                        {parseFloat(
                          milestone.total_amount || 0,
                        ).toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-[#1D2B3D]/10 rounded-lg p-3">
                      <div className="flex items-center space-x-1 mb-1">
                        <Users className="w-3 h-3 text-[#1D2B3D]" />
                        <span className="text-xs text-gray-600">
                          Supporters
                        </span>
                      </div>
                      <div className="text-sm font-semibold text-[#1D2B3D]">
                        {milestone.contributor_count || 0}
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(milestone.target_date)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{formatDate(milestone.created_at)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
