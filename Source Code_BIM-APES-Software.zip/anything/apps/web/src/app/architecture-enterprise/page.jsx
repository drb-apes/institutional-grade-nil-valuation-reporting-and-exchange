"use client";

import { HeroHeader } from "@/components/EnterpriseArchitecture/HeroHeader";
import { EntryLayer } from "@/components/EnterpriseArchitecture/EntryLayer";
import { IntelligenceCore } from "@/components/EnterpriseArchitecture/IntelligenceCore";
import { MultiCloudLayer } from "@/components/EnterpriseArchitecture/MultiCloudLayer";
import { ExperienceLayer } from "@/components/EnterpriseArchitecture/ExperienceLayer";
import { AppLaunchLayer } from "@/components/EnterpriseArchitecture/AppLaunchLayer";
import { OutputLayer } from "@/components/EnterpriseArchitecture/OutputLayer";
import { EnterpriseFooter } from "@/components/EnterpriseArchitecture/EnterpriseFooter";

export default function EnterpriseArchitecturePage() {
  return (
    <div className="min-h-screen bg-[#0A0F1E] text-white">
      <HeroHeader />

      <div className="max-w-7xl mx-auto px-6 py-12 space-y-12">
        <EntryLayer />
        <IntelligenceCore />
        <MultiCloudLayer />
        <ExperienceLayer />
        <AppLaunchLayer />
        <OutputLayer />
        <EnterpriseFooter />
      </div>
    </div>
  );
}
