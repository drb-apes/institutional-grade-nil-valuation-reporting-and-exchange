"use client";

import { useState, useEffect } from "react";
import {
  Brain,
  MessageSquare,
  TrendingUp,
  Target,
  Shield,
  Clock,
  AlertCircle,
  CheckCircle,
  RefreshCw,
  Filter,
  BarChart3,
  User,
  ArrowRight,
  Lightbulb,
  Activity,
  DollarSign,
  Search,
  Calendar,
  ChevronDown,
  Zap,
} from "lucide-react";

export default function QaaSPage() {
  const [questions, setQuestions] = useState([]);
  const [recentQuestions, setRecentQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [userProfile, setUserProfile] = useState(null);
  const [selectedMilestone, setSelectedMilestone] = useState(null);
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");

  const categories = [
    "all",
    "Performance Analysis",
    "Investment Strategy",
    "Recovery Management",
    "Risk Management",
    "Strategic Planning",
    "Portfolio Expansion",
    "Biomechanics",
    "Physiological",
  ];

  const priorities = ["all", "urgent", "high", "medium", "low"];

  useEffect(() => {
    fetchRecentQuestions();
  }, []);

  const fetchRecentQuestions = async () => {
    try {
      const response = await fetch("/api/qaas/generate");
      if (response.ok) {
        const data = await response.json();
        setRecentQuestions(data.recent_questions || []);
      }
    } catch (error) {
      console.error("Failed to fetch recent questions:", error);
    }
  };

  const generateQuestions = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/qaas/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          milestoneId: selectedMilestone,
          biometricData: {
            fatigueIndex: Math.floor(Math.random() * 25),
            heartRateVariability: Math.floor(Math.random() * 50) + 20,
            vo2Max: Math.floor(Math.random() * 30) + 50,
          },
          performanceData: {
            roi: Math.floor(Math.random() * 25),
            riskScore: Math.floor(Math.random() * 8) + 1,
          },
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setQuestions(data.questions || []);
        setUserProfile(data.userProfile);
        await fetchRecentQuestions(); // Refresh recent questions
      } else {
        console.error("Failed to generate questions");
      }
    } catch (error) {
      console.error("Error generating questions:", error);
    } finally {
      setLoading(false);
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-700 border-red-200";
      case "high":
        return "bg-orange-100 text-orange-700 border-orange-200";
      case "medium":
        return "bg-blue-100 text-blue-700 border-blue-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case "Performance Analysis":
        return Activity;
      case "Investment Strategy":
        return DollarSign;
      case "Recovery Management":
        return Shield;
      case "Risk Management":
        return AlertCircle;
      case "Strategic Planning":
        return Target;
      case "Portfolio Expansion":
        return TrendingUp;
      case "Biomechanics":
        return Zap;
      case "Physiological":
        return Activity;
      default:
        return MessageSquare;
    }
  };

  const filteredQuestions = questions.filter((q) => {
    const categoryMatch =
      filterCategory === "all" || q.category === filterCategory;
    const priorityMatch =
      filterPriority === "all" || q.priority === filterPriority;
    return categoryMatch && priorityMatch;
  });

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="px-6 py-8 bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-[#1D2B3D] rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-[#B8860B]" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-[#1D2B3D]">
                Question as a Service (QaaS)
              </h1>
              <p className="text-gray-600">
                AI-powered contextual analysis for institutional athletic
                investment decisions
              </p>
            </div>
          </div>

          {userProfile && (
            <div className="bg-[#F5F5F0] rounded-xl p-6 border border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <User className="w-8 h-8 text-[#B8860B]" />
                  <div>
                    <h3 className="text-lg font-semibold text-[#1D2B3D]">
                      {userProfile.name}
                    </h3>
                    <p className="text-gray-600">
                      Tier: {userProfile.tier} (Level {userProfile.level})
                    </p>
                  </div>
                </div>
                <button
                  onClick={generateQuestions}
                  disabled={loading}
                  className="bg-[#B8860B] hover:bg-[#A0750A] disabled:bg-gray-300 text-white px-6 py-3 rounded-lg flex items-center space-x-2 transition-colors"
                >
                  {loading ? (
                    <RefreshCw className="w-5 h-5 animate-spin" />
                  ) : (
                    <Lightbulb className="w-5 h-5" />
                  )}
                  <span>
                    {loading ? "Generating..." : "Generate Questions"}
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Controls */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative">
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat === "all" ? "All Categories" : cat}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none" />
              </div>

              <div className="relative">
                <select
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
                >
                  {priorities.map((priority) => (
                    <option key={priority} value={priority}>
                      {priority === "all"
                        ? "All Priorities"
                        : `${priority.charAt(0).toUpperCase()}${priority.slice(1)} Priority`}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none" />
              </div>
            </div>

            {!userProfile && (
              <button
                onClick={generateQuestions}
                disabled={loading}
                className="bg-[#1D2B3D] hover:bg-[#B8860B] disabled:bg-gray-300 text-white px-6 py-3 rounded-lg flex items-center space-x-2 transition-colors"
              >
                {loading ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <Brain className="w-5 h-5" />
                )}
                <span>{loading ? "Analyzing..." : "Start Analysis"}</span>
              </button>
            )}
          </div>
        </div>

        {/* Generated Questions */}
        {questions.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
              <MessageSquare className="w-6 h-6" />
              <span>Generated Analysis Questions</span>
              <span className="bg-[#B8860B] text-white px-3 py-1 rounded-full text-sm">
                {filteredQuestions.length}
              </span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredQuestions.map((question, index) => {
                const CategoryIcon = getCategoryIcon(question.category);
                return (
                  <div
                    key={`${question.id}-${index}`}
                    className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-[#1D2B3D] rounded-lg flex items-center justify-center">
                          <CategoryIcon className="w-5 h-5 text-[#B8860B]" />
                        </div>
                        <div>
                          <h3 className="font-medium text-[#1D2B3D]">
                            {question.category}
                          </h3>
                          <span
                            className={`inline-block px-2 py-1 rounded-full text-xs border ${getPriorityColor(question.priority)}`}
                          >
                            {question.priority.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <h4 className="text-lg font-semibold mb-3 text-[#1D2B3D]">
                      {question.question}
                    </h4>

                    <p className="text-gray-600 text-sm mb-4">
                      {question.context}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        Generated for {question.userTier} tier
                      </span>
                      <button className="text-[#B8860B] hover:text-[#A0750A] text-sm font-medium flex items-center space-x-1">
                        <span>Analyze</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Recent Questions History */}
        {recentQuestions.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
              <Clock className="w-6 h-6" />
              <span>Recent Analysis History</span>
            </h2>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-[#1D2B3D]">
                    Previous Questions
                  </h3>
                  <span className="text-sm text-gray-600">
                    Last {recentQuestions.length} questions
                  </span>
                </div>
              </div>

              <div className="divide-y divide-gray-200">
                {recentQuestions.slice(0, 10).map((question, index) => {
                  const CategoryIcon = getCategoryIcon(question.category);
                  return (
                    <div
                      key={question.id}
                      className="p-6 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-start space-x-4">
                        <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <CategoryIcon className="w-4 h-4 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-[#B8860B]">
                              {question.category}
                            </span>
                            <span className="text-xs text-gray-500">
                              {new Date(
                                question.created_at,
                              ).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-[#1D2B3D] font-medium mb-1">
                            {question.question}
                          </p>
                          {question.milestone_title && (
                            <p className="text-sm text-gray-600">
                              Related to: {question.milestone_title}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {questions.length === 0 && recentQuestions.length === 0 && !loading && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-[#1D2B3D] rounded-full flex items-center justify-center mx-auto mb-6">
              <Brain className="w-12 h-12 text-[#B8860B]" />
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-[#1D2B3D]">
              AI-Powered Question Generation
            </h3>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Generate contextual analysis questions based on your performance
              data, investment tier, and milestone objectives. Our AI analyzes
              your profile to provide relevant insights for strategic
              decision-making.
            </p>
            <button
              onClick={generateQuestions}
              disabled={loading}
              className="bg-[#B8860B] hover:bg-[#A0750A] disabled:bg-gray-300 text-white px-8 py-4 rounded-lg flex items-center space-x-3 mx-auto transition-colors"
            >
              <Brain className="w-6 h-6" />
              <span>Generate Your First Analysis</span>
            </button>
          </div>
        )}
      </div>

      {/* Footer Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around py-3">
          <a
            href="/"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <BarChart3 className="w-6 h-6" />
            <span className="text-xs">Home</span>
          </a>

          <a
            href="/record"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <Activity className="w-6 h-6" />
            <span className="text-xs">Record</span>
          </a>

          <a
            href="/qaas"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-[#B8860B]"
          >
            <Brain className="w-6 h-6" />
            <span className="text-xs">QaaS</span>
          </a>

          <a
            href="/dashboard"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <Target className="w-6 h-6" />
            <span className="text-xs">Dashboard</span>
          </a>

          <a
            href="/profile"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D] transition-colors"
          >
            <User className="w-6 h-6" />
            <span className="text-xs">Portfolio</span>
          </a>
        </div>
      </div>
    </div>
  );
}
