"use client";

import { useState, useEffect } from "react";
import {
  Zap,
  DollarSign,
  Bitcoin,
  Award,
  Lock,
  Unlock,
  TrendingUp,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function BoostPage() {
  const { data: user, loading: userLoading } = useUser();

  const [boostBalance, setBoostBalance] = useState(0);
  const [currentTier, setCurrentTier] = useState("tier_1");
  const [featuredAthletes, setFeaturedAthletes] = useState([]);
  const [tenantConfig, setTenantConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [boosting, setBoosting] = useState(null);

  useEffect(() => {
    if (user?.id) {
      loadBoostData();
    }
  }, [user]);

  const loadBoostData = async () => {
    try {
      setLoading(true);

      const [configRes, balanceRes, athletesRes] = await Promise.all([
        fetch("/api/boost/config"),
        fetch(`/api/boost/balance?userId=${user.id}`),
        fetch("/api/boost/featured-athletes"),
      ]);

      const config = await configRes.json();
      const balanceData = await balanceRes.json();
      const athletes = await athletesRes.json();

      setTenantConfig(config);
      setBoostBalance(balanceData.boostCredits || 0);
      setCurrentTier(balanceData.currentTier || "tier_1");
      setFeaturedAthletes(athletes);
    } catch (error) {
      console.error("Error loading boost data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleBoost = async (athlete) => {
    if (!user?.id) {
      alert("Please sign in to boost athletes");
      return;
    }

    setBoosting(athlete.id);

    try {
      const layer = tenantConfig?.engagement_layer || "free";

      const res = await fetch("/api/boost/tap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fanId: user.id,
          athleteId: athlete.id,
          paymentLayer: layer,
        }),
      });

      if (!res.ok) throw new Error("Boost failed");

      const result = await res.json();
      setBoostBalance(result.newBalance);
      setCurrentTier(result.currentTier);

      alert(
        `⚡ Boost Sent!\n+${result.boostCreditsEarned} Boost Credits\nNew Balance: ${result.newBalance}`,
      );
    } catch (error) {
      console.error("Boost error:", error);
      alert("Failed to send boost. Please try again.");
    } finally {
      setBoosting(null);
    }
  };

  const getTierInfo = (tier) => {
    const tiers = {
      tier_1: { name: "Bronze", color: "#CD7F32", nextAt: 100 },
      tier_2: { name: "Silver", color: "#C0C0C0", nextAt: 500 },
      tier_3: { name: "Gold", color: "#FFD700", nextAt: 2000 },
      vault: { name: "Vault", color: "#9333EA", nextAt: null },
    };
    return tiers[tier] || tiers.tier_1;
  };

  const getLayerBadge = () => {
    if (!tenantConfig) return null;

    const layer = tenantConfig.engagement_layer;
    const badges = {
      free: { icon: Zap, color: "#10B981", text: "Free Boost" },
      crypto: { icon: Bitcoin, color: "#F59E0B", text: "Crypto Boost" },
      fiat: { icon: DollarSign, color: "#3B82F6", text: "USD Boost" },
    };

    return badges[layer] || badges.free;
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#10B981] mx-auto"></div>
          <p className="text-[#9CA3AF] mt-4">Loading boost data...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-8">
        <div className="text-center max-w-md">
          <Lock className="w-16 h-16 text-[#6B7280] mx-auto" />
          <h1 className="text-[#F3F4F6] text-2xl font-bold mt-6">
            Sign In to Boost Athletes
          </h1>
          <p className="text-[#9CA3AF] mt-3">
            Connect to start earning Boost Credits and supporting athletes
          </p>
          <a
            href="/account/signin"
            className="inline-block mt-6 px-6 py-3 bg-[#10B981] text-white rounded-lg font-semibold hover:bg-[#059669] transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const tierInfo = getTierInfo(currentTier);
  const layerBadge = getLayerBadge();
  const LayerIcon = layerBadge?.icon;

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Header with Balance */}
      <div className="bg-[#111827] border-b border-[#1F2937]">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[#9CA3AF] text-sm font-semibold tracking-wide">
                BOOST CREDITS
              </p>
              <div className="flex items-baseline mt-2">
                <h1 className="text-[#F3F4F6] text-5xl font-extrabold">
                  {boostBalance}
                </h1>
                <span className="text-[#6B7280] text-xl font-semibold ml-3">
                  pts
                </span>
              </div>
            </div>

            <div className="text-right">
              <div
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl"
                style={{ backgroundColor: tierInfo.color + "20" }}
              >
                <Award className="w-5 h-5" style={{ color: tierInfo.color }} />
                <span
                  className="font-bold text-sm"
                  style={{ color: tierInfo.color }}
                >
                  {tierInfo.name}
                </span>
              </div>
              {tierInfo.nextAt && (
                <p className="text-[#6B7280] text-sm mt-2">
                  {tierInfo.nextAt - boostBalance} to next tier
                </p>
              )}
            </div>
          </div>

          {/* Layer Badge */}
          {layerBadge && (
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-lg mt-6"
              style={{ backgroundColor: layerBadge.color + "15" }}
            >
              <LayerIcon
                className="w-5 h-5"
                style={{ color: layerBadge.color }}
              />
              <span
                className="font-semibold text-sm"
                style={{ color: layerBadge.color }}
              >
                {layerBadge.text}
              </span>
              {tenantConfig?.engagement_layer === "fiat" && (
                <span className="text-[#9CA3AF] text-sm">
                  • ${tenantConfig.boost_cost || "0.10"} per boost
                </span>
              )}
              {tenantConfig?.engagement_layer === "crypto" && (
                <span className="text-[#9CA3AF] text-sm">
                  • {tenantConfig.boost_cost || "0.00001"} ETH per boost
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Featured Athletes */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <h2 className="text-[#F3F4F6] text-2xl font-bold mb-6">
          🔥 Featured Athletes
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredAthletes.map((athlete) => (
            <div
              key={athlete.id}
              className="bg-[#111827] border border-[#1F2937] rounded-2xl p-6"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-[#F3F4F6] text-lg font-bold">
                    {athlete.name}
                  </h3>
                  <p className="text-[#9CA3AF] text-sm mt-1">
                    {athlete.sport} • {athlete.position}
                  </p>

                  {athlete.recentMilestone && (
                    <div className="inline-block px-3 py-1 rounded-lg mt-3 bg-[#10B98120]">
                      <p className="text-[#10B981] text-xs font-semibold">
                        🎯 {athlete.recentMilestone}
                      </p>
                    </div>
                  )}
                </div>

                <button
                  onClick={() => handleBoost(athlete)}
                  disabled={boosting === athlete.id}
                  className="px-5 py-3 bg-[#10B981] hover:bg-[#059669] disabled:bg-[#374151] rounded-xl transition-colors flex flex-col items-center gap-1 min-w-[100px]"
                >
                  {boosting === athlete.id ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <Zap className="w-5 h-5" fill="white" />
                      <span className="text-white text-xs font-bold">
                        BOOST
                      </span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex gap-6 mt-4 pt-4 border-t border-[#1F2937]">
                <div>
                  <p className="text-[#6B7280] text-xs">Total Boosts</p>
                  <p className="text-[#F3F4F6] text-lg font-bold mt-1">
                    {athlete.totalBoosts || 0}
                  </p>
                </div>
                <div>
                  <p className="text-[#6B7280] text-xs">BIM Score</p>
                  <p className="text-[#10B981] text-lg font-bold mt-1">
                    {athlete.bimScore || "N/A"}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {featuredAthletes.length === 0 && (
            <div className="col-span-full text-center py-20">
              <TrendingUp className="w-16 h-16 text-[#374151] mx-auto" />
              <p className="text-[#6B7280] mt-4">
                No featured athletes yet.
                <br />
                Check back soon!
              </p>
            </div>
          )}
        </div>

        {/* Tier Progression */}
        <div className="mt-12">
          <h2 className="text-[#F3F4F6] text-xl font-bold mb-4">
            🏆 Tier Benefits
          </h2>

          <div className="bg-[#111827] border border-[#1F2937] rounded-xl p-6">
            <TierBenefitRow
              tier="Bronze"
              unlocked={true}
              benefit="Basic metadata access"
            />
            <TierBenefitRow
              tier="Silver"
              unlocked={
                currentTier === "tier_2" ||
                currentTier === "tier_3" ||
                currentTier === "vault"
              }
              benefit="Enhanced insights + 1.5x multiplier"
            />
            <TierBenefitRow
              tier="Gold"
              unlocked={currentTier === "tier_3" || currentTier === "vault"}
              benefit="Premium content + 2x multiplier"
            />
            <TierBenefitRow
              tier="Vault"
              unlocked={currentTier === "vault"}
              benefit="Exclusive access + 3x multiplier"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function TierBenefitRow({ tier, unlocked, benefit }) {
  const Icon = unlocked ? Unlock : Lock;
  const color = unlocked ? "#10B981" : "#6B7280";
  const textColor = unlocked ? "#F3F4F6" : "#6B7280";

  return (
    <div className="flex items-center gap-3 mb-4 last:mb-0">
      <Icon className="w-4 h-4" style={{ color }} />
      <span className="font-semibold text-sm" style={{ color: textColor }}>
        {tier}:
      </span>
      <span className="text-[#9CA3AF] text-sm flex-1">{benefit}</span>
    </div>
  );
}
