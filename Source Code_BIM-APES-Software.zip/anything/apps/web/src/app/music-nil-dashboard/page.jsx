"use client";

import { useState, useEffect } from "react";
import {
  Music,
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  BarChart3,
  Award,
  AlertCircle,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function MusicNILDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [artistData, setArtistData] = useState(null);
  const [portfolioData, setPortfolioData] = useState(null);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoadingData(true);

      // Fetch artist portfolio data
      const portfolioRes = await fetch("/api/music-nil/portfolio");
      if (portfolioRes.ok) {
        const data = await portfolioRes.json();
        setPortfolioData(data);
      }

      // Fetch featured artist data
      const artistRes = await fetch("/api/music-nil/featured-artists");
      if (artistRes.ok) {
        const data = await artistRes.json();
        setArtistData(data);
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-indigo-900 flex items-center justify-center">
        <div className="text-center">
          <Music className="w-16 h-16 text-purple-400 animate-pulse mx-auto mb-4" />
          <p className="text-white text-xl">Loading Music NIL Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-indigo-900">
      {/* Header */}
      <header className="border-b border-purple-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Music className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Music NIL Advisory
                </h1>
                <p className="text-purple-300 text-sm">
                  Concert Performance · Tour Valuation · Artist Indices
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-purple-300">Logged in as</p>
                <p className="text-white font-semibold">
                  {user?.name || user?.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="border-b border-purple-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "overview", label: "Overview", icon: BarChart3 },
              { id: "artists", label: "Artist Portfolio", icon: Users },
              { id: "tours", label: "Tour Analytics", icon: Calendar },
              { id: "valuations", label: "NIL Valuations", icon: DollarSign },
              {
                id: "performance",
                label: "Performance Index",
                icon: TrendingUp,
              },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-purple-400 text-purple-400"
                    : "border-transparent text-purple-300 hover:text-purple-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && (
          <OverviewTab portfolioData={portfolioData} />
        )}
        {activeTab === "artists" && (
          <ArtistPortfolioTab artistData={artistData} />
        )}
        {activeTab === "tours" && <TourAnalyticsTab />}
        {activeTab === "valuations" && <NILValuationsTab />}
        {activeTab === "performance" && <PerformanceIndexTab />}
      </div>
    </div>
  );
}

function OverviewTab({ portfolioData }) {
  const metrics = portfolioData?.summary || {
    totalArtists: 12,
    totalTourRevenue: 45600000,
    avgNILValue: 185000,
    topPerformer: "Artist A",
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Artists"
          value={metrics.totalArtists}
          icon={Users}
          trend="+2 this month"
          color="purple"
        />
        <MetricCard
          title="Tour Revenue (Projected)"
          value={`$${(metrics.totalTourRevenue / 1000000).toFixed(1)}M`}
          icon={DollarSign}
          trend="+18% vs last quarter"
          color="green"
        />
        <MetricCard
          title="Avg NIL Value"
          value={`$${(metrics.avgNILValue / 1000).toFixed(0)}K`}
          icon={TrendingUp}
          trend="+12% this month"
          color="blue"
        />
        <MetricCard
          title="Top Performer"
          value={metrics.topPerformer}
          icon={Award}
          trend="Concert CPS: 0.92"
          color="pink"
        />
      </div>

      {/* Portfolio Performance */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-purple-400" />
          Portfolio Performance Overview
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-purple-300 uppercase">
              Genre Distribution
            </h3>
            <GenreDistributionChart />
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-purple-300 uppercase">
              Concert Consistency Scores
            </h3>
            <ConsistencyChart />
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Recent Concert Scans
        </h2>
        <div className="space-y-3">
          {[
            {
              artist: "Artist A",
              genre: "Hip-Hop",
              cps: 0.92,
              date: "2 hours ago",
            },
            {
              artist: "Artist B",
              genre: "Pop",
              cps: 0.88,
              date: "5 hours ago",
            },
            { artist: "Artist C", genre: "EDM", cps: 0.85, date: "1 day ago" },
          ].map((scan, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-4 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <Music className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">{scan.artist}</p>
                  <p className="text-sm text-purple-300">{scan.genre}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold text-lg">
                  CPS {(scan.cps * 100).toFixed(0)}
                </p>
                <p className="text-sm text-purple-300">{scan.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ArtistPortfolioTab({ artistData }) {
  const artists = artistData?.artists || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Artist Portfolio</h2>
        <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors">
          Add Artist
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {artists.length > 0
          ? artists.map((artist, i) => <ArtistCard key={i} artist={artist} />)
          : // Placeholder data
            [
              {
                name: "Artist A",
                genre: "Hip-Hop",
                cps: 0.92,
                consistency: 0.88,
                tourValue: 19200000,
              },
              {
                name: "Artist B",
                genre: "Pop",
                cps: 0.88,
                consistency: 0.85,
                tourValue: 15600000,
              },
              {
                name: "Artist C",
                genre: "EDM",
                cps: 0.85,
                consistency: 0.82,
                tourValue: 12800000,
              },
            ].map((artist, i) => <ArtistCard key={i} artist={artist} />)}
      </div>
    </div>
  );
}

function TourAnalyticsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Tour Analytics & Projections
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Active Tours</h3>
        <div className="space-y-4">
          {[
            {
              artist: "Artist A",
              tour: "World Tour 2026",
              shows: 50,
              avgRevenue: 192000,
              status: "Active",
            },
            {
              artist: "Artist B",
              tour: "Stadium Series",
              shows: 30,
              avgRevenue: 156000,
              status: "Planning",
            },
          ].map((tour, i) => (
            <div
              key={i}
              className="p-4 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-white font-bold">
                    {tour.artist} - {tour.tour}
                  </p>
                  <p className="text-sm text-purple-300">
                    {tour.shows} shows projected
                  </p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    tour.status === "Active"
                      ? "bg-green-500/20 text-green-300"
                      : "bg-yellow-500/20 text-yellow-300"
                  }`}
                >
                  {tour.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-purple-300">Avg Revenue/Show</p>
                  <p className="text-lg font-bold text-white">
                    ${(tour.avgRevenue / 1000).toFixed(0)}K
                  </p>
                </div>
                <div>
                  <p className="text-xs text-purple-300">Total Tour Value</p>
                  <p className="text-lg font-bold text-white">
                    ${((tour.avgRevenue * tour.shows) / 1000000).toFixed(1)}M
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function NILValuationsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">NIL Valuations</h2>

      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <div className="space-y-4">
          {[
            {
              artist: "Artist A",
              nilValue: 185000,
              change: 12,
              performance: 0.92,
            },
            {
              artist: "Artist B",
              nilValue: 142000,
              change: 8,
              performance: 0.88,
            },
            {
              artist: "Artist C",
              nilValue: 128000,
              change: -3,
              performance: 0.85,
            },
          ].map((item, i) => (
            <div
              key={i}
              className="p-4 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold text-lg">{item.artist}</p>
                  <p className="text-sm text-purple-300">
                    Performance Score: {(item.performance * 100).toFixed(0)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-white">
                    ${(item.nilValue / 1000).toFixed(0)}K
                  </p>
                  <p
                    className={`text-sm font-semibold ${item.change >= 0 ? "text-green-400" : "text-red-400"}`}
                  >
                    {item.change >= 0 ? "+" : ""}
                    {item.change}% this month
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PerformanceIndexTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Concert Performance Index (CPI)
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <p className="text-purple-300 mb-6">
          The Concert Performance Index (CPI) tracks real-time artist
          performance across multiple concert metrics, similar to sports
          performance indices.
        </p>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <IndexCard title="Overall CPI" value="92.5" trend="+2.3" />
            <IndexCard title="Vocal Stamina Index" value="88.7" trend="+1.8" />
            <IndexCard
              title="Crowd Engagement Index"
              value="94.2"
              trend="+3.1"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color }) {
  const colorClasses = {
    purple: "from-purple-500 to-purple-600",
    green: "from-green-500 to-green-600",
    blue: "from-blue-500 to-blue-600",
    pink: "from-pink-500 to-pink-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-purple-300 uppercase">
          {title}
        </p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function ArtistCard({ artist }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6 hover:border-purple-400 transition-all cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
          <Music className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-lg">{artist.name}</p>
          <p className="text-sm text-purple-300">{artist.genre}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-purple-300">Concert CPS</span>
          <span className="text-white font-bold">
            {(artist.cps * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-purple-300">Consistency</span>
          <span className="text-white font-bold">
            {(artist.consistency * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-purple-300">100-Show Tour Value</span>
          <span className="text-white font-bold">
            ${(artist.tourValue / 1000000).toFixed(1)}M
          </span>
        </div>
      </div>
    </div>
  );
}

function GenreDistributionChart() {
  const genres = [
    { name: "Hip-Hop", count: 4, color: "bg-purple-500" },
    { name: "Pop", count: 3, color: "bg-pink-500" },
    { name: "EDM", count: 3, color: "bg-blue-500" },
    { name: "Rock", count: 2, color: "bg-red-500" },
  ];

  return (
    <div className="space-y-3">
      {genres.map((genre, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-white">{genre.name}</span>
              <span className="text-sm text-purple-300">
                {genre.count} artists
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2">
              <div
                className={`${genre.color} h-2 rounded-full`}
                style={{ width: `${(genre.count / 12) * 100}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ConsistencyChart() {
  const data = [
    { label: "Excellent (>85)", count: 5, color: "bg-green-500" },
    { label: "Good (70-85)", count: 4, color: "bg-yellow-500" },
    { label: "Fair (<70)", count: 3, color: "bg-red-500" },
  ];

  return (
    <div className="space-y-3">
      {data.map((item, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-white">{item.label}</span>
              <span className="text-sm text-purple-300">
                {item.count} artists
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2">
              <div
                className={`${item.color} h-2 rounded-full`}
                style={{ width: `${(item.count / 12) * 100}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function IndexCard({ title, value, trend }) {
  return (
    <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-4">
      <p className="text-sm text-purple-300 mb-2">{title}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm text-green-400">+{trend}</p>
      </div>
    </div>
  );
}
