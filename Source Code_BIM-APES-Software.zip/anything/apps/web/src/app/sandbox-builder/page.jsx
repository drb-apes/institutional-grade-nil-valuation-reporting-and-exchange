"use client";

import { useState } from "react";
import {
  Package,
  Users,
  TrendingUp,
  Shield,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function SandboxBuilder() {
  const { data: user, loading } = useUser();
  const [step, setStep] = useState(1);
  const [sandboxConfig, setSandboxConfig] = useState({
    tenantType: "",
    sandboxType: "",
    sandboxName: "",
    sport: "",
    apexBudget: 1000,
    ttlHours: 720,
    policyBundle: "",
    dataDomains: [],
    useCases: [],
  });
  const [createdSandbox, setCreatedSandbox] = useState(null);
  const [error, setError] = useState(null);
  const [loadingSubmit, setLoadingSubmit] = useState(false);

  const handleCreateSandbox = async () => {
    setLoadingSubmit(true);
    setError(null);

    try {
      // Create tenant first
      const tenantResponse = await fetch("/api/sandbox/tenants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tenantType: sandboxConfig.tenantType,
          tenantName: sandboxConfig.sandboxName + " Tenant",
          contactEmail: user?.email,
          sportFocus: [sandboxConfig.sport],
          tierLevel: "standard",
        }),
      });

      if (!tenantResponse.ok) {
        throw new Error("Failed to create tenant");
      }

      const tenantData = await tenantResponse.json();

      // Create sandbox
      const sandboxResponse = await fetch("/api/sandbox/sandboxes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tenantId: tenantData.tenantId,
          sandboxType: sandboxConfig.sandboxType,
          sandboxName: sandboxConfig.sandboxName,
          apexBudget: sandboxConfig.apexBudget,
          ttlHours: sandboxConfig.ttlHours,
          allowedDataDomains: sandboxConfig.dataDomains,
          allowedUseCases: sandboxConfig.useCases,
        }),
      });

      if (!sandboxResponse.ok) {
        throw new Error("Failed to create sandbox");
      }

      const sandboxData = await sandboxResponse.json();
      setCreatedSandbox(sandboxData);
      setStep(4);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingSubmit(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-blue-400 underline">
            sign in
          </a>{" "}
          to build sandboxes
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-5xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Package className="w-10 h-10 text-blue-400" />
          <h1 className="text-4xl font-bold text-white">Sandbox Builder</h1>
        </div>
        <p className="text-blue-200 text-lg">
          Create isolated environments for NIL analytics and campaign testing
        </p>
      </div>

      <div className="max-w-5xl mx-auto">
        {/* Progress Bar */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 mb-8">
          <div className="flex items-center justify-between mb-4">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                    step >= s
                      ? "bg-blue-600 text-white"
                      : "bg-slate-700 text-slate-400"
                  }`}
                >
                  {s < step ? <CheckCircle className="w-6 h-6" /> : s}
                </div>
                {s < 4 && (
                  <div
                    className={`w-24 h-1 transition-all ${
                      step > s ? "bg-blue-600" : "bg-slate-700"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm">
            <span
              className={
                step >= 1 ? "text-white font-medium" : "text-slate-400"
              }
            >
              Tenant Type
            </span>
            <span
              className={
                step >= 2 ? "text-white font-medium" : "text-slate-400"
              }
            >
              Sandbox Config
            </span>
            <span
              className={
                step >= 3 ? "text-white font-medium" : "text-slate-400"
              }
            >
              Data Permissions
            </span>
            <span
              className={
                step >= 4 ? "text-white font-medium" : "text-slate-400"
              }
            >
              Complete
            </span>
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8 border border-white/20">
          {step === 1 && (
            <div>
              <h2 className="text-2xl font-bold text-white mb-6">
                Step 1: Select Tenant Type
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    value: "sponsor",
                    label: "Sponsor",
                    desc: "Brand activation & ROI tracking",
                  },
                  {
                    value: "federation",
                    label: "Federation",
                    desc: "League-wide analytics",
                  },
                  {
                    value: "research",
                    label: "Research Lab",
                    desc: "Academic studies",
                  },
                  {
                    value: "media",
                    label: "Media",
                    desc: "Content creation & highlights",
                  },
                  {
                    value: "agency",
                    label: "NIL Agency",
                    desc: "Athlete representation",
                  },
                  {
                    value: "hedge_fund",
                    label: "Hedge Fund",
                    desc: "NIL portfolio management",
                  },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() =>
                      setSandboxConfig({
                        ...sandboxConfig,
                        tenantType: option.value,
                      })
                    }
                    className={`p-6 rounded-xl border-2 text-left transition-all ${
                      sandboxConfig.tenantType === option.value
                        ? "border-blue-400 bg-blue-500/20"
                        : "border-slate-600 bg-slate-800/50 hover:border-slate-500"
                    }`}
                  >
                    <h3 className="text-white font-bold text-lg mb-2">
                      {option.label}
                    </h3>
                    <p className="text-slate-300 text-sm">{option.desc}</p>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setStep(2)}
                disabled={!sandboxConfig.tenantType}
                className="mt-8 w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue to Sandbox Configuration
              </button>
            </div>
          )}

          {step === 2 && (
            <div>
              <h2 className="text-2xl font-bold text-white mb-6">
                Step 2: Configure Sandbox
              </h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-blue-200 mb-2 font-medium">
                    Sandbox Name
                  </label>
                  <input
                    type="text"
                    value={sandboxConfig.sandboxName}
                    onChange={(e) =>
                      setSandboxConfig({
                        ...sandboxConfig,
                        sandboxName: e.target.value,
                      })
                    }
                    className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                    placeholder="e.g., Nike Basketball Campaign Q1 2026"
                  />
                </div>

                <div>
                  <label className="block text-blue-200 mb-2 font-medium">
                    Sandbox Type
                  </label>
                  <select
                    value={sandboxConfig.sandboxType}
                    onChange={(e) =>
                      setSandboxConfig({
                        ...sandboxConfig,
                        sandboxType: e.target.value,
                      })
                    }
                    className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                  >
                    <option value="">Select type...</option>
                    <option value="sponsor_sandbox">Sponsor Sandbox</option>
                    <option value="research_sandbox">Research Sandbox</option>
                    <option value="media_sandbox">Media Sandbox</option>
                    <option value="training_sandbox">Training Sandbox</option>
                  </select>
                </div>

                <div>
                  <label className="block text-blue-200 mb-2 font-medium">
                    Primary Sport
                  </label>
                  <select
                    value={sandboxConfig.sport}
                    onChange={(e) =>
                      setSandboxConfig({
                        ...sandboxConfig,
                        sport: e.target.value,
                      })
                    }
                    className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                  >
                    <option value="">Select sport...</option>
                    <option value="basketball">Basketball</option>
                    <option value="soccer">Soccer</option>
                    <option value="wrestling">Wrestling</option>
                    <option value="tennis">Tennis</option>
                    <option value="football">American Football</option>
                    <option value="music">Music/Entertainment</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-blue-200 mb-2 font-medium">
                      APEX Budget
                    </label>
                    <input
                      type="number"
                      value={sandboxConfig.apexBudget}
                      onChange={(e) =>
                        setSandboxConfig({
                          ...sandboxConfig,
                          apexBudget: parseInt(e.target.value) || 0,
                        })
                      }
                      className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                    />
                    <p className="text-slate-400 text-xs mt-1">
                      Compute credits for analytics
                    </p>
                  </div>
                  <div>
                    <label className="block text-blue-200 mb-2 font-medium">
                      TTL (hours)
                    </label>
                    <input
                      type="number"
                      value={sandboxConfig.ttlHours}
                      onChange={(e) =>
                        setSandboxConfig({
                          ...sandboxConfig,
                          ttlHours: parseInt(e.target.value) || 0,
                        })
                      }
                      className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-blue-400 focus:outline-none"
                    />
                    <p className="text-slate-400 text-xs mt-1">
                      Time until auto-expire
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 bg-slate-700 text-white py-3 px-6 rounded-lg font-semibold hover:bg-slate-600 transition-all"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={
                    !sandboxConfig.sandboxName ||
                    !sandboxConfig.sandboxType ||
                    !sandboxConfig.sport
                  }
                  className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue to Permissions
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <h2 className="text-2xl font-bold text-white mb-6">
                Step 3: Data Permissions
              </h2>

              <div className="space-y-6">
                <div>
                  <label className="block text-blue-200 mb-3 font-medium">
                    Allowed Data Domains
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      "biometric_data",
                      "performance_metrics",
                      "nil_valuation",
                      "social_data",
                      "video_archives",
                      "motion_scans",
                    ].map((domain) => (
                      <label
                        key={domain}
                        className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50 border border-slate-600 hover:border-blue-400 cursor-pointer transition-all"
                      >
                        <input
                          type="checkbox"
                          checked={sandboxConfig.dataDomains.includes(domain)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSandboxConfig({
                                ...sandboxConfig,
                                dataDomains: [
                                  ...sandboxConfig.dataDomains,
                                  domain,
                                ],
                              });
                            } else {
                              setSandboxConfig({
                                ...sandboxConfig,
                                dataDomains: sandboxConfig.dataDomains.filter(
                                  (d) => d !== domain,
                                ),
                              });
                            }
                          }}
                          className="w-5 h-5"
                        />
                        <span className="text-white text-sm capitalize">
                          {domain.replace("_", " ")}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-blue-200 mb-3 font-medium">
                    Allowed Use Cases
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      "roi_tracking",
                      "athlete_scouting",
                      "campaign_optimization",
                      "injury_prediction",
                      "nil_valuation",
                      "performance_coaching",
                    ].map((useCase) => (
                      <label
                        key={useCase}
                        className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50 border border-slate-600 hover:border-blue-400 cursor-pointer transition-all"
                      >
                        <input
                          type="checkbox"
                          checked={sandboxConfig.useCases.includes(useCase)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSandboxConfig({
                                ...sandboxConfig,
                                useCases: [...sandboxConfig.useCases, useCase],
                              });
                            } else {
                              setSandboxConfig({
                                ...sandboxConfig,
                                useCases: sandboxConfig.useCases.filter(
                                  (u) => u !== useCase,
                                ),
                              });
                            }
                          }}
                          className="w-5 h-5"
                        />
                        <span className="text-white text-sm capitalize">
                          {useCase.replace("_", " ")}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {error && (
                <div className="mt-6 bg-red-500/20 border border-red-500 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-300 mt-0.5" />
                  <p className="text-red-200">{error}</p>
                </div>
              )}

              <div className="flex gap-4 mt-8">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 bg-slate-700 text-white py-3 px-6 rounded-lg font-semibold hover:bg-slate-600 transition-all"
                >
                  Back
                </button>
                <button
                  onClick={handleCreateSandbox}
                  disabled={
                    loadingSubmit || sandboxConfig.dataDomains.length === 0
                  }
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loadingSubmit ? "Creating Sandbox..." : "Create Sandbox"}
                </button>
              </div>
            </div>
          )}

          {step === 4 && createdSandbox && (
            <div className="text-center">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-12 h-12 text-green-400" />
              </div>

              <h2 className="text-3xl font-bold text-white mb-4">
                Sandbox Created Successfully!
              </h2>
              <p className="text-blue-200 mb-8">
                Your isolated environment is ready for analytics and campaign
                testing.
              </p>

              <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600 mb-8 text-left">
                <div className="space-y-3">
                  <div>
                    <span className="text-slate-400 text-sm">Sandbox ID:</span>
                    <p className="text-white font-mono">
                      {createdSandbox.sandboxId}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-sm">Tenant ID:</span>
                    <p className="text-white font-mono">
                      {createdSandbox.tenantId}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-sm">APEX Budget:</span>
                    <p className="text-white font-mono">
                      {createdSandbox.apexBudget} credits
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-sm">Expires:</span>
                    <p className="text-white">
                      {new Date(createdSandbox.expiresAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => {
                    setStep(1);
                    setCreatedSandbox(null);
                    setSandboxConfig({
                      tenantType: "",
                      sandboxType: "",
                      sandboxName: "",
                      sport: "",
                      apexBudget: 1000,
                      ttlHours: 720,
                      policyBundle: "",
                      dataDomains: [],
                      useCases: [],
                    });
                  }}
                  className="flex-1 bg-slate-700 text-white py-3 px-6 rounded-lg font-semibold hover:bg-slate-600 transition-all"
                >
                  Create Another Sandbox
                </button>
                <button
                  onClick={() =>
                    (window.location.href = "/analytics-dashboard")
                  }
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all"
                >
                  Go to Intelligence Dashboard
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Quick Stats */}
        {step < 4 && (
          <div className="grid grid-cols-3 gap-4 mt-8">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20 text-center">
              <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">6</p>
              <p className="text-slate-300 text-sm">Tenant Types</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20 text-center">
              <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">47+</p>
              <p className="text-slate-300 text-sm">Sports Supported</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20 text-center">
              <Shield className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">100%</p>
              <p className="text-slate-300 text-sm">NIL Compliant</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
