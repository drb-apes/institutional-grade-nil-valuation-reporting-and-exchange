"use client";

import { useState } from "react";
import {
  Eye,
  Layers,
  Play,
  Users,
  Activity,
  Maximize2,
  Settings,
} from "lucide-react";
import useUser from "@/utils/useUser";
import BiomechFlowCapsule, {
  CAPSULE_MODES,
} from "@/components/BiomechFlowCapsule/BiomechFlowCapsule";
import ThreeDSkeletonRenderer from "@/components/BiomechFlowCapsule/ThreeDSkeletonRenderer";

const JOINT_POSITIONS = {
  head: { x: 0, y: 1.7, z: 0 },
  neck: { x: 0, y: 1.5, z: 0 },
  shoulderLeft: { x: -0.3, y: 1.4, z: 0 },
  shoulderRight: { x: 0.3, y: 1.4, z: 0 },
  elbowLeft: { x: -0.3, y: 1.1, z: 0 },
  elbowRight: { x: 0.3, y: 1.1, z: 0 },
  wristLeft: { x: -0.3, y: 0.8, z: 0 },
  wristRight: { x: 0.3, y: 0.8, z: 0 },
  spine: { x: 0, y: 1.0, z: 0 },
  hipLeft: { x: -0.15, y: 0.9, z: 0 },
  hipRight: { x: 0.15, y: 0.9, z: 0 },
  kneeLeft: { x: -0.15, y: 0.5, z: 0 },
  kneeRight: { x: 0.15, y: 0.5, z: 0 },
  ankleLeft: { x: -0.15, y: 0.1, z: 0 },
  ankleRight: { x: 0.15, y: 0.1, z: 0 },
};

export default function ARBiomechViewer() {
  const { data: user, loading } = useUser();
  const [viewMode, setViewMode] = useState("capsule");
  const [selectedMode, setSelectedMode] = useState("neutral");
  const [showOverlay, setShowOverlay] = useState(true);
  const [autoRotate, setAutoRotate] = useState(false);

  // Sample athlete data
  const athlete1Data = {
    id: 1,
    name: "Marcus Johnson",
    sport: "Basketball",
    position: "Guard",
    bimScore: 87.5,
    capsuleData: {
      shoulderRight: {
        stressLoad: 75,
        fatigue: 60,
        nilMomentum: 85,
        recoveryVelocity: 15,
        subProbability: 25,
        injuryRisk: 65,
      },
      kneeLeft: {
        stressLoad: 85,
        fatigue: 80,
        nilMomentum: 70,
        recoveryVelocity: -10,
        subProbability: 45,
        injuryRisk: 80,
      },
      ankleRight: {
        stressLoad: 70,
        fatigue: 65,
        nilMomentum: 75,
        recoveryVelocity: 5,
        subProbability: 30,
        injuryRisk: 60,
      },
    },
  };

  const athlete2Data = {
    id: 2,
    name: "Jamal Williams",
    sport: "Basketball",
    position: "Forward",
    bimScore: 92.3,
    capsuleData: {
      shoulderRight: {
        stressLoad: 45,
        fatigue: 35,
        nilMomentum: 90,
        recoveryVelocity: 25,
        subProbability: 15,
        injuryRisk: 30,
      },
      kneeLeft: {
        stressLoad: 55,
        fatigue: 50,
        nilMomentum: 85,
        recoveryVelocity: 10,
        subProbability: 20,
        injuryRisk: 45,
      },
      ankleRight: {
        stressLoad: 40,
        fatigue: 30,
        nilMomentum: 88,
        recoveryVelocity: 20,
        subProbability: 12,
        injuryRisk: 25,
      },
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-blue-400 underline">
            sign in
          </a>{" "}
          to access AR Biomech Viewer
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Eye className="w-10 h-10 text-blue-400" />
          <h1 className="text-4xl font-bold text-white">
            AR BiomechFlow Viewer
          </h1>
        </div>
        <p className="text-blue-200 text-lg">
          3D Skeleton Renderer · BiomechFlow Capsules · Coach Comparison Mode
        </p>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* View Mode Selector */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex gap-4 flex-wrap">
            <ViewModeButton
              icon={<Layers />}
              label="Capsule Gallery"
              active={viewMode === "capsule"}
              onClick={() => setViewMode("capsule")}
            />
            <ViewModeButton
              icon={<Activity />}
              label="3D Skeleton"
              active={viewMode === "skeleton"}
              onClick={() => setViewMode("skeleton")}
            />
            <ViewModeButton
              icon={<Users />}
              label="Coach Comparison"
              active={viewMode === "comparison"}
              onClick={() => setViewMode("comparison")}
            />
          </div>
        </div>

        {/* Capsule Gallery View */}
        {viewMode === "capsule" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-4">
                Capsule Mode Presets
              </h2>
              <div className="flex gap-4 flex-wrap mb-6">
                {Object.entries(CAPSULE_MODES).map(([key, mode]) => (
                  <button
                    key={mode}
                    onClick={() => setSelectedMode(mode)}
                    className={`px-4 py-2 rounded-lg font-semibold uppercase text-sm transition-all ${
                      selectedMode === mode
                        ? "bg-blue-600 text-white"
                        : "bg-slate-800 text-blue-300 hover:bg-slate-700"
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>

              <div className="flex justify-center items-center p-12 bg-slate-900/50 rounded-xl">
                <BiomechFlowCapsule
                  mode={selectedMode}
                  size="large"
                  interactive={true}
                  onTap={(data) => console.log("Capsule tapped:", data)}
                />
              </div>

              <div className="mt-6 text-center">
                <p className="text-blue-300 text-sm">
                  Click or hover the capsule to see detailed metrics
                </p>
              </div>
            </div>

            {/* Legend */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <LegendCard
                title="Glow Ring"
                description="NIL Momentum"
                colors={[
                  { label: "High", hex: "#FFCC33", note: "150-200% bloom" },
                  { label: "Neutral", hex: "#F2F2F2", note: "80-100% bloom" },
                  { label: "Low", hex: "#6B6B6B", note: "20-40% bloom" },
                ]}
              />
              <LegendCard
                title="Top Arc"
                description="Stress Load"
                colors={[
                  { label: "Low", hex: "#4DA6FF", note: "Thin arc" },
                  { label: "Moderate", hex: "#1E5FA8", note: "Medium arc" },
                  { label: "High", hex: "#002B66", note: "Thick arc" },
                ]}
              />
              <LegendCard
                title="Bottom Arc"
                description="Fatigue Level"
                colors={[
                  { label: "Low", hex: "#3CFF7A", note: "Ready" },
                  { label: "Moderate", hex: "#FFD93C", note: "Monitor" },
                  { label: "High", hex: "#FF3C3C", note: "Sub alert" },
                ]}
              />
            </div>
          </div>
        )}

        {/* 3D Skeleton View */}
        {viewMode === "skeleton" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-white">
                  3D Biomechanical Skeleton
                </h2>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowOverlay(!showOverlay)}
                    className={`px-4 py-2 rounded-lg font-semibold text-sm ${
                      showOverlay
                        ? "bg-blue-600 text-white"
                        : "bg-slate-800 text-blue-300"
                    }`}
                  >
                    {showOverlay ? "Hide" : "Show"} Capsules
                  </button>
                  <button
                    onClick={() => setAutoRotate(!autoRotate)}
                    className={`px-4 py-2 rounded-lg font-semibold text-sm ${
                      autoRotate
                        ? "bg-blue-600 text-white"
                        : "bg-slate-800 text-blue-300"
                    }`}
                  >
                    <Play className="w-4 h-4 inline mr-2" />
                    {autoRotate ? "Stop" : "Start"} Rotation
                  </button>
                </div>
              </div>

              <div className="flex justify-center">
                <ThreeDSkeletonRenderer
                  jointData={JOINT_POSITIONS}
                  capsuleData={athlete1Data.capsuleData}
                  highlightJoints={["shoulderRight", "kneeLeft", "ankleRight"]}
                  showCapsules={showOverlay}
                  autoRotate={autoRotate}
                  width={600}
                  height={800}
                />
              </div>
            </div>

            {/* Joint Status Panel */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">
                Joint Status Overview
              </h3>
              <div className="grid grid-cols-3 gap-4">
                {Object.entries(athlete1Data.capsuleData).map(
                  ([joint, data]) => (
                    <JointStatusCard key={joint} joint={joint} data={data} />
                  ),
                )}
              </div>
            </div>
          </div>
        )}

        {/* Coach Comparison View */}
        {viewMode === "comparison" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="flex items-center gap-3 mb-6">
                <Users className="w-8 h-8 text-purple-400" />
                <h2 className="text-2xl font-bold text-white">
                  Coach Comparison Mode
                </h2>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Athlete 1 */}
                <div className="space-y-4">
                  <div className="bg-blue-600/20 rounded-lg p-4 border border-blue-400/30">
                    <h3 className="text-xl font-bold text-white mb-1">
                      {athlete1Data.name}
                    </h3>
                    <p className="text-blue-200 text-sm">
                      {athlete1Data.sport} · {athlete1Data.position}
                    </p>
                    <p className="text-blue-400 text-sm mt-2">
                      BIM Score:{" "}
                      <span className="font-bold">{athlete1Data.bimScore}</span>
                    </p>
                  </div>

                  <div className="flex justify-center">
                    <ThreeDSkeletonRenderer
                      jointData={JOINT_POSITIONS}
                      capsuleData={athlete1Data.capsuleData}
                      highlightJoints={["shoulderRight", "kneeLeft"]}
                      showCapsules={true}
                      autoRotate={autoRotate}
                      width={400}
                      height={600}
                    />
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-white font-semibold mb-3">
                      Injury Risk Profile
                    </h4>
                    {Object.entries(athlete1Data.capsuleData).map(
                      ([joint, data]) => (
                        <ComparisonMetric
                          key={joint}
                          label={joint}
                          value={data.injuryRisk}
                          color="blue"
                        />
                      ),
                    )}
                  </div>
                </div>

                {/* Athlete 2 */}
                <div className="space-y-4">
                  <div className="bg-purple-600/20 rounded-lg p-4 border border-purple-400/30">
                    <h3 className="text-xl font-bold text-white mb-1">
                      {athlete2Data.name}
                    </h3>
                    <p className="text-purple-200 text-sm">
                      {athlete2Data.sport} · {athlete2Data.position}
                    </p>
                    <p className="text-purple-400 text-sm mt-2">
                      BIM Score:{" "}
                      <span className="font-bold">{athlete2Data.bimScore}</span>
                    </p>
                  </div>

                  <div className="flex justify-center">
                    <ThreeDSkeletonRenderer
                      jointData={JOINT_POSITIONS}
                      capsuleData={athlete2Data.capsuleData}
                      highlightJoints={["shoulderRight", "kneeLeft"]}
                      showCapsules={true}
                      autoRotate={autoRotate}
                      width={400}
                      height={600}
                    />
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-white font-semibold mb-3">
                      Injury Risk Profile
                    </h4>
                    {Object.entries(athlete2Data.capsuleData).map(
                      ([joint, data]) => (
                        <ComparisonMetric
                          key={joint}
                          label={joint}
                          value={data.injuryRisk}
                          color="purple"
                        />
                      ),
                    )}
                  </div>
                </div>
              </div>

              {/* Comparison Summary */}
              <div className="mt-8 bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                <h4 className="text-white font-semibold mb-4">
                  Comparison Insights
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <ComparisonInsight
                    title="Higher Injury Risk"
                    winner={athlete1Data.name}
                    metric="Knee (L): 80% vs 45%"
                    advantage="negative"
                  />
                  <ComparisonInsight
                    title="Better Recovery"
                    winner={athlete2Data.name}
                    metric="Shoulder (R): +25 vs +15"
                    advantage="positive"
                  />
                  <ComparisonInsight
                    title="NIL Momentum"
                    winner={athlete2Data.name}
                    metric="Avg: 87.7% vs 76.7%"
                    advantage="positive"
                  />
                </div>

                <div className="mt-6 pt-6 border-t border-slate-700">
                  <p className="text-white font-semibold mb-3">
                    Coaching Recommendation
                  </p>
                  <div className="bg-blue-500/10 rounded-lg p-4 border border-blue-400/30">
                    <p className="text-blue-200 text-sm">
                      <span className="font-bold">{athlete1Data.name}</span>{" "}
                      shows higher injury risk in left knee (80%) with negative
                      recovery velocity. Consider load management and monitor
                      closely during next 72 hours.
                    </p>
                    <p className="text-blue-300 text-xs mt-2 italic">
                      Recommendation: Reduce contact drills, focus on mobility
                      work, consider rest day before next game.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Controls Panel */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-400" />
            Visualization Controls
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ControlButton
              label="Auto Rotate"
              active={autoRotate}
              onClick={() => setAutoRotate(!autoRotate)}
              icon={<Play />}
            />
            <ControlButton
              label="Show Overlays"
              active={showOverlay}
              onClick={() => setShowOverlay(!showOverlay)}
              icon={<Layers />}
            />
            <ControlButton
              label="Full Screen"
              active={false}
              onClick={() => {}}
              icon={<Maximize2 />}
            />
            <ControlButton
              label="Export View"
              active={false}
              onClick={() => {}}
              icon={<Activity />}
            />
          </div>
        </div>

        {/* Documentation */}
        <div className="bg-gradient-to-r from-blue-600/10 to-purple-600/10 backdrop-blur-lg rounded-xl p-6 border border-blue-400/30">
          <h3 className="text-xl font-bold text-white mb-4">
            BiomechFlow Capsule Specification
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-blue-200 text-sm font-semibold mb-2">
                Core Components
              </p>
              <ul className="text-blue-300 text-sm space-y-1">
                <li>
                  • <span className="font-bold">Glow Ring</span> → NIL Momentum
                  (bloom intensity 20-200%)
                </li>
                <li>
                  • <span className="font-bold">Top Arc</span> → Stress Load
                  (thickness 2-10px)
                </li>
                <li>
                  • <span className="font-bold">Bottom Arc</span> → Fatigue
                  Level (color gradient)
                </li>
                <li>
                  • <span className="font-bold">Center Line</span> → Recovery
                  Velocity (slope ±45°)
                </li>
                <li>
                  • <span className="font-bold">Left Bar</span> → Substitution
                  Probability (10-60px)
                </li>
                <li>
                  • <span className="font-bold">Right Bar</span> → Injury Risk
                  Premium (10-60px)
                </li>
              </ul>
            </div>
            <div>
              <p className="text-blue-200 text-sm font-semibold mb-2">
                Animation Behavior
              </p>
              <ul className="text-blue-300 text-sm space-y-1">
                <li>• Pulse frequencies: 0.5–1.5 Hz</li>
                <li>• Sweep animations: 0.6–1.0s duration</li>
                <li>• Critical flashes: 0.2s (red/gold/blue)</li>
                <li>• Auto-brightness for arena lighting</li>
                <li>• Occlusion-aware rendering</li>
                <li>• Interactive tap to expand full metrics</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-blue-400/20">
            <p className="text-blue-200 text-sm font-semibold mb-3">
              Export Formats for Designers
            </p>
            <div className="flex gap-3 flex-wrap">
              <span className="px-3 py-1 bg-slate-800 rounded text-blue-300 text-xs">
                SVG (Vector)
              </span>
              <span className="px-3 py-1 bg-slate-800 rounded text-blue-300 text-xs">
                GLB/FBX (3D)
              </span>
              <span className="px-3 py-1 bg-slate-800 rounded text-blue-300 text-xs">
                Lottie JSON (Animation)
              </span>
              <span className="px-3 py-1 bg-slate-800 rounded text-blue-300 text-xs">
                After Effects (Motion)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ViewModeButton({ icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 px-6 py-3 rounded-lg font-semibold transition-all ${
        active
          ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
          : "bg-slate-800 text-blue-300 hover:bg-slate-700"
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function LegendCard({ title, description, colors }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-white font-semibold mb-1">{title}</h3>
      <p className="text-blue-300 text-sm mb-4">{description}</p>
      <div className="space-y-2">
        {colors.map((colorItem, idx) => (
          <div key={idx} className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded-full border-2 border-white/30"
              style={{ backgroundColor: colorItem.hex }}
            />
            <div>
              <p className="text-white text-sm font-medium">
                {colorItem.label}
              </p>
              <p className="text-blue-300 text-xs">{colorItem.note}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function JointStatusCard({ joint, data }) {
  const riskLevel =
    data.injuryRisk > 70 ? "high" : data.injuryRisk > 40 ? "medium" : "low";
  const riskColor =
    riskLevel === "high"
      ? "text-red-400"
      : riskLevel === "medium"
        ? "text-yellow-400"
        : "text-green-400";

  return (
    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
      <p className="text-white font-semibold mb-2 capitalize">
        {joint.replace(/([A-Z])/g, " $1").trim()}
      </p>
      <div className="space-y-1 text-xs">
        <div className="flex justify-between">
          <span className="text-slate-400">Injury Risk</span>
          <span className={`${riskColor} font-bold`}>
            {data.injuryRisk.toFixed(0)}%
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">Fatigue</span>
          <span className="text-white">{data.fatigue.toFixed(0)}%</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">NIL Momentum</span>
          <span className="text-blue-400">{data.nilMomentum.toFixed(0)}%</span>
        </div>
      </div>
    </div>
  );
}

function ComparisonMetric({ label, value, color }) {
  const barColor = color === "blue" ? "bg-blue-500" : "bg-purple-500";

  return (
    <div className="bg-slate-800/50 rounded-lg p-3">
      <div className="flex justify-between items-center mb-1">
        <span className="text-white text-sm capitalize">
          {label.replace(/([A-Z])/g, " $1").trim()}
        </span>
        <span className="text-white text-sm font-mono">
          {value.toFixed(0)}%
        </span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-1.5">
        <div
          className={`${barColor} h-1.5 rounded-full transition-all duration-300`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

function ComparisonInsight({ title, winner, metric, advantage }) {
  const bgColor =
    advantage === "positive" ? "bg-green-500/10" : "bg-red-500/10";
  const borderColor =
    advantage === "positive" ? "border-green-500/30" : "border-red-500/30";

  return (
    <div className={`${bgColor} rounded-lg p-4 border ${borderColor}`}>
      <p className="text-blue-300 text-xs mb-1">{title}</p>
      <p className="text-white font-semibold mb-2">{winner}</p>
      <p className="text-slate-400 text-xs">{metric}</p>
    </div>
  );
}

function ControlButton({ label, active, onClick, icon }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-semibold text-sm transition-all ${
        active
          ? "bg-blue-600 text-white"
          : "bg-slate-800 text-blue-300 hover:bg-slate-700"
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}
