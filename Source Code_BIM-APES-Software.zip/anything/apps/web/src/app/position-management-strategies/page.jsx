"use client";

import { useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Brain,
  Target,
  Users,
  Shuffle,
  Zap,
  Shield,
} from "lucide-react";

export default function PositionManagementStrategies() {
  const [selectedMethod, setSelectedMethod] = useState(
    "adaptive_trailing_stop",
  );

  const strategies = [
    {
      id: "adaptive_trailing_stop",
      name: "Adaptive Trailing Stop",
      icon: <TrendingUp className="w-6 h-6" />,
      category: "realistic",
      color: "from-green-500 to-emerald-500",
      description:
        "Dynamically adjusts trailing exit threshold in response to real-time biometric drawdown signals",
      keyMechanism: "Dynamic, metric-based trailing",
      pros: [
        "Optimizes exit timing",
        "Low risk",
        "Automated",
        "Leading biometric signals",
      ],
      cons: ["Requires robust real-time data", "Complex parameter tuning"],
      suitability: "Realistic - Production Ready",
      details:
        "When player performance indicators start to weaken (fatigue, declining recovery, increased volatility), the system tightens the exit trigger, maximizing gains while minimizing late-stage risk. This approach capitalizes on the leading nature of physiological signals, outperforming purely price-based trails.",
      formula:
        "Adaptive Trail % = Base Trail % × (1 + Biometric Drawdown × 0.5)",
      exitConditions: [
        "Trail distance ≥ Adaptive trail percentage",
        "Biometric drawdown > 70%",
        "Heart rate volatility spike",
      ],
    },
    {
      id: "pattern_only_exit",
      name: "Pattern-Only Exit",
      icon: <Target className="w-6 h-6" />,
      category: "moderate",
      color: "from-blue-500 to-cyan-500",
      description:
        "Uses classical candlestick signals and price patterns for exit decisions",
      keyMechanism: "Classical candlestick signals",
      pros: ["Simple", "Easy to test", "Well-understood"],
      cons: ["Ignores unique biometric edge", "Lagging indicator"],
      suitability: "Moderate - Baseline Comparison",
      details:
        "Relies on traditional technical analysis patterns like evening star, bearish engulfing, and shooting star formations. Does not utilize the unique biometric advantage of PhysiobioFIN.",
      formula: "Exit if bearish pattern detected in last N candles",
      exitConditions: [
        "Evening star pattern",
        "Bearish engulfing",
        "Shooting star formation",
      ],
    },
    {
      id: "hybrid_ai_weighted",
      name: "Hybrid AI Weighted",
      icon: <Brain className="w-6 h-6" />,
      category: "realistic",
      color: "from-purple-500 to-pink-500",
      description:
        "AI-driven blend of all signal sources with adaptive weighting",
      keyMechanism: "AI-learned blend of all factors",
      pros: [
        "Most robust",
        "Adapts to new data",
        "Flexible risk control",
        "Continuously improves",
      ],
      cons: ["Requires AI tuning", "Complex to interpret"],
      suitability: "Realistic - Production Ready (Advanced)",
      details:
        "Merges all signal sources (market patterns, live biometrics, opponent modeling, session context) using an AI-driven adaptive weighting scheme. The AI learns optimal blend weights for each scenario, continuously improving over time. Most robust to changing conditions.",
      formula:
        "Composite Signal = Σ(Signal_i × Weight_i) for all signal sources",
      exitConditions: [
        "Composite signal ≥ Exit threshold (typically 0.6)",
        "Confidence interval > 80%",
        "No conflicting operator override",
      ],
    },
    {
      id: "volatility_event_driven",
      name: "Volatility Event-Driven",
      icon: <Zap className="w-6 h-6" />,
      category: "moderate",
      color: "from-yellow-500 to-orange-500",
      description: "Hard thresholds for performance volatility spikes",
      keyMechanism: "Event-triggered on volatility spikes",
      pros: ["Strong safety", "Quick response", "Simple logic"],
      cons: ["Can whipsaw in choppy sessions", "Misses gradual degradation"],
      suitability: "Moderate - Event-Based",
      details:
        "Monitors performance volatility and heart rate volatility for sudden spikes. When volatility exceeds thresholds, exits immediately to avoid whipsaw risk.",
      formula:
        "Exit if Performance Volatility > Threshold OR HR Volatility > Threshold",
      exitConditions: [
        "Performance volatility > 60%",
        "Heart rate volatility > 30 BPM",
        "Combined volatility spike",
      ],
    },
    {
      id: "operator_override",
      name: "Operator Override",
      icon: <Users className="w-6 h-6" />,
      category: "moderate",
      color: "from-indigo-500 to-blue-500",
      description:
        "Human operator supervises AI with manual override capability",
      keyMechanism: "Human supervises AI",
      pros: [
        "Combines tech + discretion",
        "Handles edge cases",
        "Regulatory compliance",
      ],
      cons: ["Inconsistent", "Slower", "Human bias"],
      suitability: "Moderate - Hybrid Control",
      details:
        "Allows human operators to supervise AI recommendations and override when needed. Useful for regulatory compliance and handling unusual market conditions.",
      formula: "Decision = Operator Input OR AI Recommendation",
      exitConditions: [
        "Operator manual exit command",
        "AI recommendation with operator approval",
        "Emergency stop conditions",
      ],
    },
    {
      id: "milestone_partial_exit",
      name: "Milestone-Based Partial Exit",
      icon: <Shield className="w-6 h-6" />,
      category: "realistic",
      color: "from-teal-500 to-green-500",
      description: "Staged exit at performance milestones",
      keyMechanism: "Incremental exits at milestones",
      pros: [
        "Reduces peak miss risk",
        "Smooth risk reduction",
        "Accommodates volatility",
      ],
      cons: ["More complex tracking", "Partial profit taking"],
      suitability: "Realistic - Risk Management",
      details:
        "Divides each full trade into increments, exiting a portion at each significant biometric or performance milestone. For example, 25% exits at force threshold, 25% at peak recovery, with final exits determined by standard pattern logic.",
      formula: "Exit % = Σ(Milestone Exit %) for triggered milestones",
      exitConditions: [
        "Force threshold reached (25% exit)",
        "Distance milestone (25% exit)",
        "Recovery drop (25% exit)",
        "Fatigue spike (25% exit)",
      ],
    },
    {
      id: "randomized_exit",
      name: "Randomized Exit",
      icon: <Shuffle className="w-6 h-6" />,
      category: "benchmark",
      color: "from-gray-500 to-slate-500",
      description: "Random exit decisions for baseline comparison",
      keyMechanism: "Random number generator",
      pros: ["Useful baseline", "No bias"],
      cons: ["Zero intelligence", "Not for production"],
      suitability: "Benchmark - Testing Only",
      details:
        "Included mainly for baseline comparison, not real-world deployment. Helps quantify the value-add of intelligent strategies.",
      formula: "Exit if Random(0,1) > 0.7",
      exitConditions: ["Random signal > 70%"],
    },
    {
      id: "max_risk_all_in",
      name: "Max Risk/All-In Exit",
      icon: <AlertTriangle className="w-6 h-6" />,
      category: "long_shot",
      color: "from-red-500 to-rose-500",
      description: "⚠️ DANGEROUS: Waits for maximum fatigue limits",
      keyMechanism: "Waits for max limit",
      pros: ['Rare "big win" moments'],
      cons: [
        "⚠️ ABSURD DRAWDOWN RISK",
        "⚠️ CATASTROPHIC LOSSES",
        "⚠️ NOT RECOMMENDED",
      ],
      suitability: "Long Shot - DO NOT USE",
      details:
        "⚠️ WARNING EXAMPLE: Ignores all interim signals and exits only when metrics hit extreme limits. This can expose traders to catastrophic drawdowns and is not aligned with sound risk management. Included as a warning example.",
      formula: "Exit ONLY if Fatigue ≥ 95% OR HR ≥ 210 BPM",
      exitConditions: ["Fatigue index ≥ 95%", "Heart rate ≥ 210 BPM"],
    },
    {
      id: "biometric_inverse_martingale",
      name: "Biometric Inverse Martingale",
      icon: <TrendingDown className="w-6 h-6" />,
      category: "long_shot",
      color: "from-red-600 to-orange-600",
      description: "⚠️ DANGEROUS: Compounds risk on positive signals",
      keyMechanism: 'Risk increases on "wins"',
      pros: ["Feels exciting"],
      cons: [
        "⚠️ EXPOSES TO OUTSIZED LOSSES",
        "⚠️ STATISTICALLY DANGEROUS",
        "⚠️ NOT RECOMMENDED",
      ],
      suitability: "Long Shot - DO NOT USE",
      details:
        "⚠️ WARNING EXAMPLE: Rapidly compounds risk on positive signals and exits on first negative—a statistically dangerous position-sizing method that can lead to unwarranted losses. Included as a warning example.",
      formula: "Increase risk on positive signals, exit on first negative",
      exitConditions: ["First negative signal after positive run"],
    },
    {
      id: "distributed_multi_manager",
      name: "Distributed Multi-Manager",
      icon: <Users className="w-6 h-6" />,
      category: "moderate",
      color: "from-violet-500 to-purple-500",
      description: "Blends multiple strategies via consensus",
      keyMechanism: "Multi-method consensus",
      pros: ["Reduces idiosyncratic error", "Diversified signals", "Robust"],
      cons: ["Diluted edge", "More complex audits", "Slower decisions"],
      suitability: "Moderate - Ensemble Approach",
      details:
        "Runs multiple strategies in parallel and aggregates their decisions via majority vote or weighted consensus. Reduces risk of single-strategy failure.",
      formula: "Exit if 2+ strategies agree on exit",
      exitConditions: [
        "Majority vote (≥2/3 strategies)",
        "Weighted consensus ≥ threshold",
      ],
    },
  ];

  const selectedStrategy = strategies.find((s) => s.id === selectedMethod);

  const getCategoryBadge = (category) => {
    const badges = {
      realistic: {
        label: "Production Ready",
        color: "bg-green-500/20 text-green-300 border-green-500/30",
      },
      moderate: {
        label: "Moderate Use",
        color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
      },
      benchmark: {
        label: "Baseline Only",
        color: "bg-gray-500/20 text-gray-300 border-gray-500/30",
      },
      long_shot: {
        label: "⚠️ WARNING",
        color: "bg-red-500/20 text-red-300 border-red-500/30",
      },
    };
    return badges[category];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <TrendingUp className="w-10 h-10 text-indigo-400" />
          <h1 className="text-4xl font-bold text-white">
            Position Management Strategies
          </h1>
        </div>
        <p className="text-indigo-200 text-lg">
          10 Methods for NIL-Backed Performance Position Exits
        </p>
        <p className="text-indigo-300 text-sm mt-2">
          PhysiobioFIN Trading Intelligence Layer
        </p>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Strategy Selector */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 lg:col-span-1">
          <h2 className="text-xl font-bold text-white mb-4">Select Strategy</h2>

          <div className="space-y-2">
            {strategies.map((strategy) => {
              const badge = getCategoryBadge(strategy.category);
              return (
                <button
                  key={strategy.id}
                  onClick={() => setSelectedMethod(strategy.id)}
                  className={`w-full text-left p-4 rounded-lg border transition-all ${
                    selectedMethod === strategy.id
                      ? "bg-white/20 border-white/40"
                      : "bg-slate-800/50 border-slate-600 hover:bg-slate-700/50"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-lg bg-gradient-to-r ${strategy.color}`}
                    >
                      {strategy.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-semibold text-sm">
                        {strategy.name}
                      </h3>
                      <div
                        className={`mt-1 inline-block px-2 py-0.5 rounded text-xs border ${badge.color}`}
                      >
                        {badge.label}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Strategy Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Overview */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-start gap-4 mb-4">
              <div
                className={`p-4 rounded-xl bg-gradient-to-r ${selectedStrategy.color}`}
              >
                {selectedStrategy.icon}
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-2">
                  {selectedStrategy.name}
                </h2>
                <div
                  className={`inline-block px-3 py-1 rounded-lg text-sm border ${getCategoryBadge(selectedStrategy.category).color}`}
                >
                  {getCategoryBadge(selectedStrategy.category).label}
                </div>
              </div>
            </div>

            <p className="text-indigo-200 mb-4">
              {selectedStrategy.description}
            </p>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-indigo-300 text-sm mb-1">Key Mechanism</p>
                <p className="text-white font-semibold">
                  {selectedStrategy.keyMechanism}
                </p>
              </div>
              <div>
                <p className="text-indigo-300 text-sm mb-1">Suitability</p>
                <p className="text-white font-semibold">
                  {selectedStrategy.suitability}
                </p>
              </div>
            </div>

            <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
              <p className="text-white text-sm leading-relaxed">
                {selectedStrategy.details}
              </p>
            </div>
          </div>

          {/* Formula */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">
              Algorithm Formula
            </h3>
            <div className="bg-slate-900 rounded-lg p-4 border border-indigo-500/30">
              <code className="text-indigo-300 font-mono text-sm">
                {selectedStrategy.formula}
              </code>
            </div>
          </div>

          {/* Pros & Cons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">
                ✅ Advantages
              </h3>
              <ul className="space-y-2">
                {selectedStrategy.pros.map((pro, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-2" />
                    <span className="text-green-200 text-sm">{pro}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">
                ⚠️ Disadvantages
              </h3>
              <ul className="space-y-2">
                {selectedStrategy.cons.map((con, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-2" />
                    <span
                      className={`text-sm ${selectedStrategy.category === "long_shot" ? "text-red-300 font-semibold" : "text-red-200"}`}
                    >
                      {con}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Exit Conditions */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">
              Exit Conditions
            </h3>
            <div className="space-y-2">
              {selectedStrategy.exitConditions.map((condition, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-3 border border-slate-600"
                >
                  <div className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-white text-xs font-bold">
                    {idx + 1}
                  </div>
                  <span className="text-indigo-200 text-sm">{condition}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Warning for Long Shot strategies */}
          {selectedStrategy.category === "long_shot" && (
            <div className="bg-red-500/10 backdrop-blur-lg rounded-xl p-6 border-2 border-red-500/50">
              <div className="flex items-start gap-4">
                <AlertTriangle className="w-8 h-8 text-red-400 flex-shrink-0" />
                <div>
                  <h3 className="text-xl font-bold text-red-300 mb-2">
                    ⚠️ EXTREME RISK WARNING
                  </h3>
                  <p className="text-red-200 text-sm mb-3">
                    This strategy is included as a{" "}
                    <strong>warning example</strong>. It is{" "}
                    <strong>NOT RECOMMENDED</strong> for real trading and can
                    lead to catastrophic losses.
                  </p>
                  <p className="text-red-300 text-sm font-semibold">
                    Use only for educational comparison to understand the
                    importance of sound risk management.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Comparison Summary Table */}
      <div className="max-w-7xl mx-auto mt-12">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-6">
            Strategy Comparison Matrix
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/20">
                  <th className="text-left py-3 px-4 text-indigo-200">
                    Method
                  </th>
                  <th className="text-left py-3 px-4 text-indigo-200">
                    Key Mechanism
                  </th>
                  <th className="text-left py-3 px-4 text-indigo-200">
                    Category
                  </th>
                  <th className="text-left py-3 px-4 text-indigo-200">
                    Risk Level
                  </th>
                </tr>
              </thead>
              <tbody>
                {strategies.map((strategy, idx) => (
                  <tr
                    key={strategy.id}
                    className={`border-b border-white/10 ${selectedMethod === strategy.id ? "bg-white/10" : ""}`}
                  >
                    <td className="py-3 px-4 text-white font-medium">
                      {strategy.name}
                    </td>
                    <td className="py-3 px-4 text-indigo-200">
                      {strategy.keyMechanism}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-1 rounded text-xs border ${getCategoryBadge(strategy.category).color}`}
                      >
                        {getCategoryBadge(strategy.category).label}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-xs font-semibold ${
                          strategy.category === "long_shot"
                            ? "text-red-400"
                            : strategy.category === "realistic"
                              ? "text-green-400"
                              : "text-yellow-400"
                        }`}
                      >
                        {strategy.category === "long_shot"
                          ? "EXTREME"
                          : strategy.category === "realistic"
                            ? "LOW-MED"
                            : "MEDIUM"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
