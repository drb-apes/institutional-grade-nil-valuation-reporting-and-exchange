"use client";

import { useState } from "react";
import { Activity, BarChart3, Layers, Zap, Eye } from "lucide-react";
import useUser from "@/utils/useUser";
import ARBiomechanicalOverlay from "@/components/BIMVisualization/ARBiomechanicalOverlay";
import BiomechflowChart from "@/components/BIMVisualization/BiomechflowChart";
import SportSelector from "@/components/BIMVisualization/SportSelector";
import ChartTypeSelector from "@/components/BIMVisualization/ChartTypeSelector";
import LicensingFooter from "@/components/LicensingFooter";

const CHART_TYPES = [
  { id: "ar-overlay", name: "AR Biomechanical Overlay", icon: Eye },
  { id: "biomechflow", name: "Biomechflow Chart", icon: BarChart3 },
  { id: "both", name: "Split View", icon: Layers },
];

const SPORT_CATEGORIES = [
  {
    category: "Combat Sports",
    sports: ["wrestling", "boxing", "mma", "judo", "taekwondo", "karate"],
  },
  {
    category: "Tactical Sports",
    sports: ["soccer", "basketball", "rugby", "hockey", "handball", "lacrosse"],
  },
  {
    category: "Racket Sports",
    sports: ["tennis", "pickleball", "badminton", "table_tennis", "squash"],
  },
  {
    category: "Track & Field",
    sports: [
      "sprinting",
      "distance_running",
      "hurdles",
      "long_jump",
      "high_jump",
      "pole_vault",
    ],
  },
  {
    category: "Aquatic Sports",
    sports: ["swimming", "diving", "water_polo", "synchronized_swimming"],
  },
  {
    category: "Endurance Sports",
    sports: ["cycling", "triathlon", "rowing", "cross_country_skiing"],
  },
  {
    category: "Precision Sports",
    sports: ["archery", "shooting", "golf", "bowling", "darts"],
  },
  {
    category: "Gymnastic Sports",
    sports: [
      "artistic_gymnastics",
      "rhythmic_gymnastics",
      "trampoline",
      "cheerleading",
    ],
  },
  {
    category: "Entertainment",
    sports: ["live_concert", "theater_performance", "dance", "figure_skating"],
  },
  {
    category: "Winter Sports",
    sports: ["alpine_skiing", "snowboarding", "ice_hockey", "speed_skating"],
  },
  {
    category: "Strength Sports",
    sports: ["weightlifting", "powerlifting", "strongman", "crossfit"],
  },
];

export default function BIMVisualizationDashboard() {
  const { data: user, loading } = useUser();
  const [selectedSport, setSelectedSport] = useState("wrestling");
  const [chartType, setChartType] = useState("both");
  const [athleteId, setAthleteId] = useState("");
  const [sessionId, setSessionId] = useState("");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);

  const handleLoadData = async () => {
    if (!athleteId) {
      alert("Please enter an athlete ID");
      return;
    }

    setLoadingData(true);

    // Simulate data loading - in production this would call the appropriate sport API
    setTimeout(() => {
      // Generate mock biomechanical data based on sport
      const mockData = generateMockBiomechanicalData(selectedSport);
      setPerformanceData(mockData);
      setLoadingData(false);
    }, 1000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-indigo-400 underline">
            sign in
          </a>{" "}
          to access this dashboard
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-[1800px] mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Activity className="w-12 h-12 text-indigo-400" />
          <div>
            <h1 className="text-4xl font-bold text-white">
              BIM Visualization Suite
            </h1>
            <p className="text-indigo-200 text-lg">
              AR Biomechanical Overlay & Biomechflow Charts
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4 mt-4">
          <div className="flex items-center gap-2 text-green-400">
            <Zap className="w-5 h-5" />
            <span className="text-sm font-semibold">47 Sports Supported</span>
          </div>
          <div className="flex items-center gap-2 text-blue-400">
            <Eye className="w-5 h-5" />
            <span className="text-sm font-semibold">
              Real-Time Biomechanics
            </span>
          </div>
          <div className="flex items-center gap-2 text-purple-400">
            <BarChart3 className="w-5 h-5" />
            <span className="text-sm font-semibold">Multi-Phase Analysis</span>
          </div>
        </div>
      </div>

      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Control Panel */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Athlete Input */}
            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                Athlete ID
              </label>
              <input
                type="number"
                value={athleteId}
                onChange={(e) => setAthleteId(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-indigo-400 focus:outline-none"
                placeholder="Enter ID"
              />
            </div>

            {/* Session Input */}
            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                Session ID (Optional)
              </label>
              <input
                type="text"
                value={sessionId}
                onChange={(e) => setSessionId(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-indigo-400 focus:outline-none"
                placeholder="Leave blank for latest"
              />
            </div>

            {/* Sport Selector */}
            <div>
              <label className="block text-indigo-200 mb-2 font-medium text-sm">
                Selected Sport
              </label>
              <div className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold text-center capitalize">
                {selectedSport.replace("_", " ")}
              </div>
            </div>

            {/* Load Button */}
            <div className="flex items-end">
              <button
                onClick={handleLoadData}
                disabled={loadingData}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 px-6 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all disabled:opacity-50"
              >
                {loadingData ? "Loading..." : "Load Data"}
              </button>
            </div>
          </div>
        </div>

        {/* Sport Selector */}
        <SportSelector
          sportCategories={SPORT_CATEGORIES}
          selectedSport={selectedSport}
          onSelectSport={setSelectedSport}
        />

        {/* Chart Type Selector */}
        <ChartTypeSelector
          chartTypes={CHART_TYPES}
          selectedType={chartType}
          onSelectType={setChartType}
        />

        {/* Visualization Area */}
        {!performanceData ? (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 flex flex-col items-center justify-center min-h-[500px]">
            <Activity className="w-20 h-20 text-indigo-400/50 mb-4" />
            <p className="text-indigo-300 text-xl mb-2">No Data Loaded</p>
            <p className="text-indigo-200 text-sm">
              Enter an athlete ID and click "Load Data" to visualize
              biomechanics
            </p>
          </div>
        ) : (
          <div
            className={`grid ${chartType === "both" ? "grid-cols-1 xl:grid-cols-2" : "grid-cols-1"} gap-6`}
          >
            {/* AR Biomechanical Overlay */}
            {(chartType === "ar-overlay" || chartType === "both") && (
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="flex items-center gap-3 mb-6">
                  <Eye className="w-6 h-6 text-indigo-400" />
                  <h2 className="text-2xl font-bold text-white">
                    AR Biomechanical Overlay
                  </h2>
                </div>
                <ARBiomechanicalOverlay
                  sport={selectedSport}
                  performanceData={performanceData}
                />
              </div>
            )}

            {/* Biomechflow Chart */}
            {(chartType === "biomechflow" || chartType === "both") && (
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="flex items-center gap-3 mb-6">
                  <BarChart3 className="w-6 h-6 text-purple-400" />
                  <h2 className="text-2xl font-bold text-white">
                    Biomechflow Chart
                  </h2>
                </div>
                <BiomechflowChart
                  sport={selectedSport}
                  performanceData={performanceData}
                />
              </div>
            )}
          </div>
        )}

        {/* Performance Metrics Summary */}
        {performanceData && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">
              Performance Summary
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricCard
                label="BIM Score"
                value={performanceData.bimScore.toFixed(1)}
                color="indigo"
              />
              <MetricCard
                label="Tier"
                value={performanceData.tier}
                color="purple"
              />
              <MetricCard
                label="Peak Power"
                value={`${performanceData.peakPower} W`}
                color="green"
              />
              <MetricCard
                label="Efficiency"
                value={`${performanceData.efficiency}%`}
                color="blue"
              />
            </div>
          </div>
        )}
      </div>

      {/* Licensing Footer */}
      <div className="max-w-[1800px] mx-auto mt-12">
        <LicensingFooter />
      </div>
    </div>
  );
}

function MetricCard({ label, value, color }) {
  const colorClasses = {
    indigo: "bg-indigo-500/20 border-indigo-400/30 text-indigo-400",
    purple: "bg-purple-500/20 border-purple-400/30 text-purple-400",
    green: "bg-green-500/20 border-green-400/30 text-green-400",
    blue: "bg-blue-500/20 border-blue-400/30 text-blue-400",
  };

  return (
    <div className={`rounded-lg p-4 border ${colorClasses[color]}`}>
      <p className="text-white/70 text-sm mb-1">{label}</p>
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
  );
}

// Mock data generator
function generateMockBiomechanicalData(sport) {
  const baseScore = 70 + Math.random() * 25;
  const tier =
    baseScore >= 90
      ? "Elite"
      : baseScore >= 80
        ? "High Performer"
        : baseScore >= 70
          ? "Developing"
          : "Foundational";

  const sportSpecificPhases = {
    wrestling: ["Setup", "Penetration", "Control", "Finish", "Recovery"],
    boxing: ["Stance", "Jab", "Cross", "Hook", "Defense"],
    soccer: ["Approach", "Plant", "Strike", "Follow-Through", "Recovery"],
    basketball: ["Load", "Takeoff", "Flight", "Release", "Landing"],
    tennis: [
      "Preparation",
      "Backswing",
      "Forward Swing",
      "Contact",
      "Follow-Through",
    ],
    live_concert: ["Verse 1", "Pre-Chorus", "Chorus", "Verse 2", "Bridge"],
    sprinting: [
      "Start",
      "Acceleration",
      "Max Velocity",
      "Deceleration",
      "Finish",
    ],
  };

  const phases = sportSpecificPhases[sport] || [
    "Phase 1",
    "Phase 2",
    "Phase 3",
    "Phase 4",
    "Phase 5",
  ];

  const biomechanicalData = phases.map((phase, idx) => ({
    phase,
    power: 200 + Math.random() * 800,
    force: 300 + Math.random() * 1200,
    velocity: 1 + Math.random() * 9,
    efficiency: 60 + Math.random() * 35,
    timestamp: idx * 0.5,
  }));

  const jointAngles = {
    shoulder: 45 + Math.random() * 90,
    elbow: 30 + Math.random() * 120,
    hip: 60 + Math.random() * 90,
    knee: 20 + Math.random() * 140,
    ankle: 70 + Math.random() * 40,
  };

  return {
    bimScore: baseScore,
    tier,
    peakPower: Math.max(...biomechanicalData.map((d) => d.power)).toFixed(0),
    efficiency: (
      biomechanicalData.reduce((sum, d) => sum + d.efficiency, 0) /
      biomechanicalData.length
    ).toFixed(1),
    biomechanicalData,
    jointAngles,
    sport,
  };
}
