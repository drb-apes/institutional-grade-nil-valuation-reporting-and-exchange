"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function UniversalDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [sportProfiles, setSportProfiles] = useState([]);
  const [orgProfiles, setOrgProfiles] = useState([]);
  const [selectedSport, setSelectedSport] = useState(null);
  const [selectedOrg, setSelectedOrg] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [activeView, setActiveView] = useState("context");

  // Load sport and org profiles on mount
  useEffect(() => {
    loadProfiles();
  }, []);

  const loadProfiles = async () => {
    try {
      const [sportRes, orgRes] = await Promise.all([
        fetch("/api/context/sport-profiles"),
        fetch("/api/context/org-profiles"),
      ]);

      if (sportRes.ok && orgRes.ok) {
        const sportData = await sportRes.json();
        const orgData = await orgRes.json();
        setSportProfiles(sportData.profiles || []);
        setOrgProfiles(orgData.profiles || []);
      }
    } catch (error) {
      console.error("Failed to load profiles:", error);
    }
  };

  const runAnalytics = async () => {
    if (!selectedSport || !selectedOrg) {
      alert("Please select both a sport and organization");
      return;
    }

    setLoading(true);
    try {
      // Simulate analytics run with sample data
      const response = await fetch("/api/analytics/universal-engine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sport_id: selectedSport.id,
          org_id: selectedOrg.id,
          analysis_type: "full_analysis",
          raw_metrics: generateSampleMetrics(selectedSport),
          historical_ppis: generateSampleHistory(),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setAnalytics(data);
        setActiveView("analytics");
      }
    } catch (error) {
      console.error("Analytics failed:", error);
      alert("Failed to run analytics");
    } finally {
      setLoading(false);
    }
  };

  const generateSampleMetrics = (sport) => {
    const metrics = {};
    if (sport.featureMap) {
      Object.values(sport.featureMap)
        .flat()
        .forEach((feature) => {
          metrics[feature] = Math.random() * 80 + 20; // Random value 20-100
        });
    }
    return metrics;
  };

  const generateSampleHistory = () => {
    return Array.from({ length: 10 }, (_, i) => ({
      ppi: 50 + i * 2 + Math.random() * 10,
      timestamp: new Date(
        Date.now() - (10 - i) * 7 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    }));
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#0A0E27] flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0E27] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-white text-2xl mb-4">Authentication Required</h2>
          <a href="/account/signin" className="text-[#00D9FF] hover:underline">
            Sign in to continue
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0E27]">
      {/* Header */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-white mb-2">
            BIM-APES Universal Dashboard
          </h1>
          <p className="text-gray-400">
            Multi-sport, multi-org performance analytics engine
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-6">
            <button
              onClick={() => setActiveView("context")}
              className={`px-4 py-3 font-medium transition-colors ${
                activeView === "context"
                  ? "text-[#00D9FF] border-b-2 border-[#00D9FF]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              Context Selection
            </button>
            <button
              onClick={() => setActiveView("analytics")}
              className={`px-4 py-3 font-medium transition-colors ${
                activeView === "analytics"
                  ? "text-[#00D9FF] border-b-2 border-[#00D9FF]"
                  : "text-gray-400 hover:text-white"
              }`}
              disabled={!analytics}
            >
              Analytics Results
            </button>
            <button
              onClick={() => setActiveView("architecture")}
              className={`px-4 py-3 font-medium transition-colors ${
                activeView === "architecture"
                  ? "text-[#00D9FF] border-b-2 border-[#00D9FF]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              System Architecture
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {activeView === "context" && (
          <ContextSelectionView
            sportProfiles={sportProfiles}
            orgProfiles={orgProfiles}
            selectedSport={selectedSport}
            selectedOrg={selectedOrg}
            onSportSelect={setSelectedSport}
            onOrgSelect={setSelectedOrg}
            onRunAnalytics={runAnalytics}
            loading={loading}
          />
        )}

        {activeView === "analytics" && analytics && (
          <AnalyticsResultsView analytics={analytics} />
        )}

        {activeView === "architecture" && <ArchitectureView />}
      </div>
    </div>
  );
}

function ContextSelectionView({
  sportProfiles,
  orgProfiles,
  selectedSport,
  selectedOrg,
  onSportSelect,
  onOrgSelect,
  onRunAnalytics,
  loading,
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Sport Selection */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h2 className="text-xl font-bold text-white mb-4">Select Sport</h2>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {sportProfiles.map((sport) => (
            <button
              key={sport.id}
              onClick={() => onSportSelect(sport)}
              className={`w-full text-left p-4 rounded-lg border transition-all ${
                selectedSport?.id === sport.id
                  ? "border-[#00D9FF] bg-[#00D9FF]/10"
                  : "border-gray-700 hover:border-gray-600 bg-[#0A0E27]"
              }`}
            >
              <div className="font-medium text-white mb-1">{sport.name}</div>
              <div className="text-sm text-gray-400">
                Category: {sport.category}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Organization Selection */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h2 className="text-xl font-bold text-white mb-4">
          Select Organization
        </h2>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {orgProfiles.map((org) => (
            <button
              key={org.id}
              onClick={() => onOrgSelect(org)}
              className={`w-full text-left p-4 rounded-lg border transition-all ${
                selectedOrg?.id === org.id
                  ? "border-[#00D9FF] bg-[#00D9FF]/10"
                  : "border-gray-700 hover:border-gray-600 bg-[#0A0E27]"
              }`}
            >
              <div className="font-medium text-white mb-1">{org.name}</div>
              <div className="text-sm text-gray-400">Tier: {org.tier}</div>
              <div className="text-sm text-gray-400">
                Age Range: {org.ageRange.min}-{org.ageRange.max}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Selected Context Summary */}
      {(selectedSport || selectedOrg) && (
        <div className="md:col-span-2 bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
          <h2 className="text-xl font-bold text-white mb-4">
            Selected Context
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <div className="text-sm text-gray-400 mb-2">Sport</div>
              {selectedSport ? (
                <div>
                  <div className="text-white font-medium">
                    {selectedSport.name}
                  </div>
                  <div className="text-sm text-gray-400">
                    Category: {selectedSport.category}
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">No sport selected</div>
              )}
            </div>
            <div>
              <div className="text-sm text-gray-400 mb-2">Organization</div>
              {selectedOrg ? (
                <div>
                  <div className="text-white font-medium">
                    {selectedOrg.name}
                  </div>
                  <div className="text-sm text-gray-400">
                    Tier: {selectedOrg.tier}
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">No organization selected</div>
              )}
            </div>
          </div>
          <button
            onClick={onRunAnalytics}
            disabled={!selectedSport || !selectedOrg || loading}
            className="w-full bg-[#00D9FF] text-black font-semibold py-3 px-6 rounded-lg hover:bg-[#00B8DB] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Running Analytics..." : "Run Universal Analytics"}
          </button>
        </div>
      )}
    </div>
  );
}

function AnalyticsResultsView({ analytics }) {
  const { result } = analytics;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-2">
          Analytics Results
        </h2>
        <div className="text-gray-400">
          Sport: {analytics.sport_name} | Organization: {analytics.org_name}
        </div>
      </div>

      {/* PPI Score */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4">
          Player Performance Index (PPI)
        </h3>
        <div className="flex items-center gap-6">
          <div className="text-6xl font-bold text-[#00D9FF]">
            {result.ppi.ppi}
          </div>
          <div>
            <div className="text-2xl font-semibold text-white capitalize">
              {result.ppi.tier}
            </div>
            <div className="text-sm text-gray-400">Performance Tier</div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Velocity"
          value={result.velocity}
          suffix="/week"
          description="Rate of improvement"
          color={result.velocity > 0 ? "text-green-400" : "text-red-400"}
        />
        <MetricCard
          title="Consistency"
          value={result.consistency}
          suffix="%"
          description="Performance stability"
          color="text-[#00D9FF]"
        />
        <MetricCard
          title="Learning Rate"
          value={result.learningRate}
          suffix="/session"
          description="Adaptation speed"
          color={result.learningRate > 0 ? "text-green-400" : "text-yellow-400"}
        />
      </div>

      {/* Forecasts */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4">PPI Forecasts</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ForecastCard days={30} forecast={result.forecasts.forecast30} />
          <ForecastCard days={60} forecast={result.forecasts.forecast60} />
          <ForecastCard days={90} forecast={result.forecasts.forecast90} />
        </div>
      </div>

      {/* Risk Assessment */}
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4">Risk Assessment</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="text-sm text-gray-400 mb-2">Injury Risk Score</div>
            <div className="flex items-baseline gap-2">
              <div
                className={`text-4xl font-bold ${
                  result.injuryRisk.riskLevel === "high"
                    ? "text-red-400"
                    : result.injuryRisk.riskLevel === "medium"
                      ? "text-yellow-400"
                      : "text-green-400"
                }`}
              >
                {result.injuryRisk.riskScore}
              </div>
              <div
                className={`text-lg font-medium capitalize ${
                  result.injuryRisk.riskLevel === "high"
                    ? "text-red-400"
                    : result.injuryRisk.riskLevel === "medium"
                      ? "text-yellow-400"
                      : "text-green-400"
                }`}
              >
                {result.injuryRisk.riskLevel}
              </div>
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-2">
              Breakout Probability
            </div>
            <div className="text-4xl font-bold text-[#00D9FF]">
              {result.breakoutProbability}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, suffix, description, color }) {
  return (
    <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
      <div className="text-sm text-gray-400 mb-2">{title}</div>
      <div className={`text-3xl font-bold ${color} mb-1`}>
        {typeof value === "number" ? value.toFixed(2) : value}
        {suffix}
      </div>
      <div className="text-sm text-gray-500">{description}</div>
    </div>
  );
}

function ForecastCard({ days, forecast }) {
  if (!forecast) return null;

  return (
    <div className="bg-[#0A0E27] rounded-lg p-4 border border-gray-700">
      <div className="text-sm text-gray-400 mb-2">{days}-Day Forecast</div>
      <div className="text-2xl font-bold text-white mb-2">
        {forecast.forecast}
      </div>
      <div className="flex items-center gap-2 text-sm text-gray-400">
        <span>{forecast.confidenceLow}</span>
        <div className="flex-1 h-1 bg-gray-700 rounded-full overflow-hidden">
          <div className="h-full bg-[#00D9FF]" style={{ width: "60%" }} />
        </div>
        <span>{forecast.confidenceHigh}</span>
      </div>
    </div>
  );
}

function ArchitectureView() {
  return (
    <div className="space-y-6">
      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-4">
          5-Layer System Architecture
        </h2>
        <p className="text-gray-400 mb-6">
          BIM-APES is now a universal biometric finance engine that abstracts to
          any sport and any organization tier.
        </p>

        <div className="space-y-4">
          <LayerCard
            number="1"
            title="Collection Layer"
            description="Sport-agnostic data capture via mobile app, device mesh, and manual input"
            features={[
              "Motion capture",
              "Bluetooth sensors",
              "Mesh networking",
              "Offline sync",
              "NIL onboarding",
            ]}
          />
          <LayerCard
            number="2"
            title="Context Layer"
            description="Sport + organization adapters that define rules, constraints, and metrics"
            features={[
              "Sport profiles (10 sports)",
              "Organization profiles (9 org types)",
              "Feature mapping",
              "Policy constraints",
              "Visibility rules",
            ]}
          />
          <LayerCard
            number="3"
            title="Analytics Layer"
            description="Universal performance engine that computes PPI/TPI/LPI for any context"
            features={[
              "PPI calculation",
              "TPI aggregation",
              "LPI indices",
              "Velocity tracking",
              "Forecasting",
              "Risk assessment",
            ]}
          />
          <LayerCard
            number="4"
            title="Market Layer"
            description="NIL valuation, swaps, and trading engine (context-aware)"
            features={[
              "Biometric NIL valuation",
              "Player/Team/Index swaps",
              "Mesh trading",
              "Automated triggers",
              "Contribution pools",
            ]}
          />
          <LayerCard
            number="5"
            title="Governance Layer"
            description="Web3 milestones, stipends, treasury, and DAO governance"
            features={[
              "Milestone contracts",
              "Micro-stipends",
              "Treasury management",
              "DAO proposals",
              "Cross-org governance",
            ]}
          />
        </div>
      </div>

      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4">
          Supported Sports (10 total)
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            "Wrestling",
            "Basketball",
            "Tennis",
            "Pickleball",
            "American Football",
            "Rugby",
            "Soccer",
            "Track & Field",
            "Esports",
            "Motorsport",
          ].map((sport) => (
            <div
              key={sport}
              className="bg-[#0A0E27] rounded px-3 py-2 text-sm text-white border border-gray-700"
            >
              {sport}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[#1A1F3A] rounded-lg p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4">
          Supported Organizations (9 tiers)
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            "Youth Academy",
            "High School",
            "Junior College",
            "NCAA D1",
            "NCAA D2",
            "Semi-Pro",
            "Professional",
            "National Federation",
            "Multi-Sport Coalition",
          ].map((org) => (
            <div
              key={org}
              className="bg-[#0A0E27] rounded px-3 py-2 text-sm text-white border border-gray-700"
            >
              {org}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function LayerCard({ number, title, description, features }) {
  return (
    <div className="bg-[#0A0E27] rounded-lg p-4 border border-gray-700">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-full bg-[#00D9FF] flex items-center justify-center text-black font-bold flex-shrink-0">
          {number}
        </div>
        <div className="flex-1">
          <h4 className="text-lg font-bold text-white mb-1">{title}</h4>
          <p className="text-sm text-gray-400 mb-3">{description}</p>
          <div className="flex flex-wrap gap-2">
            {features.map((feature) => (
              <span
                key={feature}
                className="text-xs bg-[#1A1F3A] text-gray-300 px-2 py-1 rounded border border-gray-700"
              >
                {feature}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
