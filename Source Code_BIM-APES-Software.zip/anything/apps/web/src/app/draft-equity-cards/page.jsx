import React from "react";
import DraftEquityCardGallery from "@/components/DraftEquityCard/DraftEquityCardGallery";

export default function DraftEquityCardsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">
            🏆 Draft Equity Cards
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Coalition-verified athlete profiles showcasing biometric indices,
            valuation summaries, and contributor credits for draft-eligible
            prospects across all sports.
          </p>
        </div>

        {/* Card Gallery */}
        <DraftEquityCardGallery />
      </div>
    </div>
  );
}
