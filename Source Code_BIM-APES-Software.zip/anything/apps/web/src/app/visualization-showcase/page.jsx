"use client";

import { useState } from "react";
import { BarChart3, TrendingUp, Target, Zap } from "lucide-react";
import HeatmapChart from "@/components/AdvancedVisualizations/HeatmapChart";
import RadarChart from "@/components/AdvancedVisualizations/RadarChart";
import TrendlineChart from "@/components/AdvancedVisualizations/TrendlineChart";
import CandlestickChart from "@/components/AdvancedVisualizations/CandlestickChart";

export default function VisualizationShowcase() {
  const [activeTab, setActiveTab] = useState("radar");

  // Sample data generators
  const wrestlingHeatmapData = () => {
    const data = [];
    for (let y = 0; y < 10; y++) {
      for (let x = 0; x < 10; x++) {
        // Create hotspots in specific zones
        let value = Math.random() * 20;

        // Top positions (more takedowns)
        if (y >= 7) value += Math.random() * 40;

        // Center control zone
        if (x >= 4 && x <= 6 && y >= 4 && y <= 6) value += Math.random() * 30;

        data.push({
          x,
          y,
          value,
          label: `Zone (${x},${y})`,
        });
      }
    }
    return data;
  };

  const athleteRadarData = () => [
    { label: "Speed", value: 85, max: 100 },
    { label: "Strength", value: 92, max: 100 },
    { label: "Endurance", value: 78, max: 100 },
    { label: "Skill", value: 88, max: 100 },
    { label: "Consistency", value: 82, max: 100 },
    { label: "Mental", value: 90, max: 100 },
  ];

  const nilRadarData = () => ({
    axes: [
      { label: "Performance", max: 100 },
      { label: "Social Media", max: 100 },
      { label: "Brand Fit", max: 100 },
      { label: "Engagement", max: 100 },
      { label: "Marketability", max: 100 },
      { label: "Consistency", max: 100 },
    ],
    datasets: [
      {
        label: "Current NIL Profile",
        data: [88, 75, 82, 90, 85, 78],
        borderColor: "rgb(59, 130, 246)",
        backgroundColor: "rgba(59, 130, 246, 0.2)",
      },
    ],
  });

  const performanceTrendData = () => [
    {
      label: "Week 1",
      value: 72,
      timestamp: Date.now() - 6 * 7 * 24 * 60 * 60 * 1000,
    },
    {
      label: "Week 2",
      value: 75,
      timestamp: Date.now() - 5 * 7 * 24 * 60 * 60 * 1000,
    },
    {
      label: "Week 3",
      value: 71,
      timestamp: Date.now() - 4 * 7 * 24 * 60 * 60 * 1000,
    },
    {
      label: "Week 4",
      value: 78,
      timestamp: Date.now() - 3 * 7 * 24 * 60 * 60 * 1000,
    },
    {
      label: "Week 5",
      value: 82,
      timestamp: Date.now() - 2 * 7 * 24 * 60 * 60 * 1000,
    },
    {
      label: "Week 6",
      value: 85,
      timestamp: Date.now() - 1 * 7 * 24 * 60 * 60 * 1000,
    },
    { label: "Week 7", value: 88, timestamp: Date.now() },
  ];

  const nilCandlestickData = () => {
    const data = [];
    const baseValue = 50000;

    for (let i = 0; i < 14; i++) {
      const volatility = Math.random() * 5000;
      const trend = i * 500;
      const open = baseValue + trend + (Math.random() - 0.5) * 2000;
      const close = open + (Math.random() - 0.5) * 4000;
      const high = Math.max(open, close) + Math.random() * volatility;
      const low = Math.min(open, close) - Math.random() * volatility;

      data.push({
        label: `Day ${i + 1}`,
        open,
        high,
        low,
        close,
        volume: Math.floor(Math.random() * 10000) + 5000,
      });
    }

    return data;
  };

  const trendlineData = () => ({
    timeSeries: [
      { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 65, label: "Jan 1" },
      { x: Date.now() - 25 * 24 * 60 * 60 * 1000, y: 68, label: "Jan 6" },
      { x: Date.now() - 20 * 24 * 60 * 60 * 1000, y: 70, label: "Jan 11" },
      { x: Date.now() - 15 * 24 * 60 * 60 * 1000, y: 72, label: "Jan 16" },
      { x: Date.now() - 10 * 24 * 60 * 60 * 1000, y: 75, label: "Jan 21" },
      { x: Date.now() - 5 * 24 * 60 * 60 * 1000, y: 78, label: "Jan 26" },
      { x: Date.now(), y: 82, label: "Jan 31" },
    ],
    trendline: [
      { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 66 },
      { x: Date.now(), y: 80 },
    ],
    upperBound: [
      { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 75 },
      { x: Date.now(), y: 90 },
    ],
    lowerBound: [
      { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 57 },
      { x: Date.now(), y: 70 },
    ],
  });

  const tennisHeatmapData = () => ({
    data: [
      // Baseline left
      { xLabel: "Left", yLabel: "Baseline", value: 45, intensity: 75 },
      // Baseline center
      { xLabel: "Center", yLabel: "Baseline", value: 52, intensity: 85 },
      // Baseline right
      { xLabel: "Right", yLabel: "Baseline", value: 38, intensity: 65 },
      // Mid left
      { xLabel: "Left", yLabel: "Mid", value: 28, intensity: 50 },
      // Mid center
      { xLabel: "Center", yLabel: "Mid", value: 35, intensity: 60 },
      // Mid right
      { xLabel: "Right", yLabel: "Mid", value: 30, intensity: 55 },
      // Net left
      { xLabel: "Left", yLabel: "Net", value: 18, intensity: 35 },
      // Net center
      { xLabel: "Center", yLabel: "Net", value: 22, intensity: 40 },
      // Net right
      { xLabel: "Right", yLabel: "Net", value: 20, intensity: 38 },
    ],
    colorScale: {
      gradient: ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"],
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <BarChart3 className="w-10 h-10 text-indigo-400" />
          <h1 className="text-4xl font-bold text-white">
            Advanced Visualization Showcase
          </h1>
        </div>
        <p className="text-indigo-200 text-lg">
          BIM-APES Intelligence Visualization Suite
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-2 border border-white/20 inline-flex gap-2">
          {[
            { id: "radar", label: "Radar Charts", icon: Target },
            { id: "heatmap", label: "Heatmaps", icon: Zap },
            { id: "trendline", label: "Trendlines", icon: TrendingUp },
            { id: "candlestick", label: "Candlesticks", icon: BarChart3 },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === tab.id
                  ? "bg-indigo-600 text-white"
                  : "bg-transparent text-indigo-300 hover:bg-slate-800"
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto">
        {/* Radar Charts Tab */}
        {activeTab === "radar" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-2">
                Multi-Dimensional Athlete Profiles
              </h2>
              <p className="text-indigo-200 mb-6">
                Compare performance across multiple dimensions
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Athlete Profile Radar */}
                <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                  <RadarChart data={nilRadarData()} width={400} height={400} />
                  <div className="mt-4">
                    <h4 className="text-white font-semibold mb-2">
                      Use Cases:
                    </h4>
                    <ul className="text-blue-300 text-sm space-y-1">
                      <li>• Athlete skill assessment</li>
                      <li>• NIL component breakdown</li>
                      <li>• Tactical profile comparison</li>
                      <li>• Position-specific requirements</li>
                    </ul>
                  </div>
                </div>

                {/* NIL Components Radar */}
                <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                  <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg p-6 border border-blue-400/30">
                    <h4 className="text-white font-semibold mb-4">
                      NIL Value Components
                    </h4>
                    <div className="space-y-3">
                      <ComponentBar
                        label="Performance NIL"
                        value={88}
                        color="blue"
                      />
                      <ComponentBar
                        label="Social Media NIL"
                        value={75}
                        color="purple"
                      />
                      <ComponentBar
                        label="Brand Fit NIL"
                        value={82}
                        color="green"
                      />
                      <ComponentBar
                        label="Engagement NIL"
                        value={90}
                        color="yellow"
                      />
                      <ComponentBar
                        label="Marketability NIL"
                        value={85}
                        color="pink"
                      />
                      <ComponentBar
                        label="Consistency NIL"
                        value={78}
                        color="indigo"
                      />
                    </div>
                  </div>

                  <div className="mt-6">
                    <h4 className="text-white font-semibold mb-2">
                      Wrestling-Specific Metrics:
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      <MetricBox label="Takedown %" value="87.5" />
                      <MetricBox label="Escape %" value="92.3" />
                      <MetricBox label="Control %" value="68.4" />
                      <MetricBox label="Explosive Power" value="91.2" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tactical Sports Radar */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">
                Tactical Sports Efficiency Profile
              </h2>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {["Soccer", "Basketball", "Rugby"].map((sport) => (
                  <div
                    key={sport}
                    className="bg-slate-800/50 rounded-lg p-4 border border-slate-600"
                  >
                    <h4 className="text-white font-semibold mb-4 text-center">
                      {sport} Profile
                    </h4>
                    <div className="space-y-2">
                      <EfficiencyBar
                        label="Possession"
                        value={Math.random() * 30 + 70}
                      />
                      <EfficiencyBar
                        label="Passing"
                        value={Math.random() * 25 + 75}
                      />
                      <EfficiencyBar
                        label="Decision Making"
                        value={Math.random() * 20 + 70}
                      />
                      <EfficiencyBar
                        label="Spatial Awareness"
                        value={Math.random() * 30 + 65}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Heatmaps Tab */}
        {activeTab === "heatmap" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-2">
                Spatial & Temporal Performance Heatmaps
              </h2>
              <p className="text-indigo-200 mb-6">
                Visualize intensity patterns across space and time
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Wrestling Grip Dominance */}
                <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                  <HeatmapChart
                    data={wrestlingHeatmapData()}
                    title="Wrestling Mat Control Zones"
                    xLabel="Mat Width"
                    yLabel="Mat Length"
                    colorScheme="blue-red"
                    gridSize={10}
                  />
                </div>

                {/* Tennis Shot Placement */}
                <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                  <HeatmapChart
                    data={tennisHeatmapData()}
                    width={400}
                    height={300}
                  />
                  <div className="mt-4">
                    <h4 className="text-white font-semibold mb-2">
                      Use Cases:
                    </h4>
                    <ul className="text-blue-300 text-sm space-y-1">
                      <li>• Shot placement analysis (tennis, pickleball)</li>
                      <li>• Field positioning (soccer, basketball)</li>
                      <li>• Crowd engagement by venue section (concerts)</li>
                      <li>• Takedown zones (wrestling, judo)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Concert Crowd Engagement Heatmap */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">
                Concert Venue Engagement Heatmap
              </h2>
              <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                <div className="grid grid-cols-5 gap-2 mb-4">
                  {Array.from({ length: 25 }).map((_, idx) => {
                    const row = Math.floor(idx / 5);
                    const col = idx % 5;

                    // Center stage has higher engagement
                    let engagement = 50;
                    if (row === 0 || row === 1) engagement += 30;
                    if (col === 2) engagement += 20;
                    engagement += Math.random() * 10;

                    return (
                      <div
                        key={idx}
                        className="aspect-square rounded-lg border border-slate-700 flex items-center justify-center"
                        style={{
                          backgroundColor: `rgba(236, 72, 153, ${engagement / 100})`,
                        }}
                      >
                        <span className="text-white text-xs font-bold">
                          {Math.floor(engagement)}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <div className="text-center">
                  <div className="inline-block bg-gradient-to-r from-pink-600 to-purple-600 text-white px-6 py-2 rounded-lg font-semibold">
                    🎤 STAGE
                  </div>
                </div>
                <p className="text-blue-300 text-sm text-center mt-4">
                  Engagement intensity by venue section (0-100 scale)
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Trendlines Tab */}
        {activeTab === "trendline" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-2">
                Performance & NIL Trajectory Analysis
              </h2>
              <p className="text-indigo-200 mb-6">
                Track trends, identify momentum, predict future performance
              </p>

              <div className="grid grid-cols-1 gap-6">
                {/* BIM Score Trendline */}
                <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                  <TrendlineChart
                    data={trendlineData()}
                    width={800}
                    height={300}
                  />
                  <div className="mt-4 grid grid-cols-4 gap-4">
                    <TrendStat label="Current Value" value="82" trend="up" />
                    <TrendStat label="7-Day Change" value="+10" trend="up" />
                    <TrendStat label="Peak Value" value="85" trend="neutral" />
                    <TrendStat label="Trend Slope" value="+0.57" trend="up" />
                  </div>
                </div>

                {/* Use Cases Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                    <h4 className="text-white font-semibold mb-4">
                      Sports Applications
                    </h4>
                    <ul className="space-y-2">
                      <UseCaseItem
                        title="Session-to-Session Improvement"
                        description="Track BIM score progression over training cycles"
                      />
                      <UseCaseItem
                        title="Recovery Curves"
                        description="Monitor fatigue and readiness trends"
                      />
                      <UseCaseItem
                        title="Skill Development"
                        description="Measure technique mastery over time"
                      />
                    </ul>
                  </div>

                  <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                    <h4 className="text-white font-semibold mb-4">
                      Concert/Entertainment
                    </h4>
                    <ul className="space-y-2">
                      <UseCaseItem
                        title="Tour Performance Trajectory"
                        description="Track artist performance across show dates"
                      />
                      <UseCaseItem
                        title="Social Momentum"
                        description="Measure engagement growth patterns"
                      />
                      <UseCaseItem
                        title="Vocal Stamina Curves"
                        description="Monitor vocal quality across tour duration"
                      />
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Candlestick Tab */}
        {activeTab === "candlestick" && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-2">
                Volatility & Range Analysis
              </h2>
              <p className="text-indigo-200 mb-6">
                Measure performance variability and NIL value fluctuations
              </p>

              <div className="grid grid-cols-1 gap-6">
                {/* NIL Valuation Candlestick */}
                <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                  <CandlestickChart
                    data={nilCandlestickData()}
                    title="14-Day NIL Valuation Volatility"
                    xLabel="Trading Days"
                    yLabel="NIL Value ($)"
                    showVolume={true}
                  />
                </div>

                {/* Volatility Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <VolatilityCard
                    title="Average Daily Range"
                    value="$4,250"
                    change="+12.3%"
                    trend="up"
                  />
                  <VolatilityCard
                    title="Peak Volatility"
                    value="$8,500"
                    change="Day 7"
                    trend="neutral"
                  />
                  <VolatilityCard
                    title="Trend Direction"
                    value="Bullish"
                    change="+18.5% (14d)"
                    trend="up"
                  />
                </div>

                {/* Application Examples */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                    <h4 className="text-white font-semibold mb-4">
                      Performance Volatility Analysis
                    </h4>
                    <ul className="space-y-2">
                      <UseCaseItem
                        title="Match-to-Match Consistency"
                        description="High-Low-Open-Close for session performance"
                      />
                      <UseCaseItem
                        title="Training Load Fluctuation"
                        description="Workload variability across weekly cycles"
                      />
                      <UseCaseItem
                        title="Injury Risk Windows"
                        description="Identify high-volatility periods"
                      />
                    </ul>
                  </div>

                  <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
                    <h4 className="text-white font-semibold mb-4">
                      NIL Trading Signals
                    </h4>
                    <ul className="space-y-2">
                      <UseCaseItem
                        title="Arbitrage Opportunities"
                        description="Fair value vs. market value spreads"
                      />
                      <UseCaseItem
                        title="Hedging Windows"
                        description="Protect against NIL volatility"
                      />
                      <UseCaseItem
                        title="Scalping Moments"
                        description="Short-term momentum bursts"
                      />
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Helper Components
function ComponentBar({ label, value, color }) {
  const colors = {
    blue: "from-blue-500 to-blue-600",
    purple: "from-purple-500 to-purple-600",
    green: "from-green-500 to-green-600",
    yellow: "from-yellow-500 to-yellow-600",
    pink: "from-pink-500 to-pink-600",
    indigo: "from-indigo-500 to-indigo-600",
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <span className="text-blue-200 text-sm">{label}</span>
        <span className="text-white font-mono font-semibold">{value}</span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className={`bg-gradient-to-r ${colors[color]} h-2 rounded-full transition-all duration-300`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

function MetricBox({ label, value }) {
  return (
    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-700">
      <p className="text-blue-300 text-xs mb-1">{label}</p>
      <p className="text-white text-lg font-bold">{value}</p>
    </div>
  );
}

function EfficiencyBar({ label, value }) {
  const percentage = Math.min(100, Math.max(0, value));

  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-green-200 text-sm">{label}</span>
        <span className="text-white text-sm font-mono">
          {percentage.toFixed(1)}%
        </span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className="bg-gradient-to-r from-green-400 to-emerald-400 h-2 rounded-full transition-all duration-300"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

function TrendStat({ label, value, trend }) {
  const icons = {
    up: "↗",
    down: "↘",
    neutral: "→",
  };

  const colors = {
    up: "text-green-400",
    down: "text-red-400",
    neutral: "text-yellow-400",
  };

  return (
    <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
      <p className="text-blue-300 text-xs mb-1">{label}</p>
      <div className="flex items-center gap-2">
        <span className={`text-2xl ${colors[trend]}`}>{icons[trend]}</span>
        <p className="text-white text-xl font-bold">{value}</p>
      </div>
    </div>
  );
}

function UseCaseItem({ title, description }) {
  return (
    <li className="flex gap-3">
      <div className="w-2 h-2 bg-indigo-400 rounded-full mt-1.5 flex-shrink-0"></div>
      <div>
        <p className="text-white text-sm font-semibold">{title}</p>
        <p className="text-blue-300 text-xs">{description}</p>
      </div>
    </li>
  );
}

function VolatilityCard({ title, value, change, trend }) {
  const colors = {
    up: "text-green-400",
    down: "text-red-400",
    neutral: "text-yellow-400",
  };

  return (
    <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-600">
      <p className="text-blue-300 text-sm mb-2">{title}</p>
      <p className="text-white text-3xl font-bold mb-2">{value}</p>
      <p className={`text-sm font-semibold ${colors[trend]}`}>{change}</p>
    </div>
  );
}
