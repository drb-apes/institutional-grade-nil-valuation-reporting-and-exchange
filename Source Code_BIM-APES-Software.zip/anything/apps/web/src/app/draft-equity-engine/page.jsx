"use client";
import React from "react";
import useUser from "@/utils/useUser";
import { useDraftEquityEngine } from "@/hooks/useDraftEquityEngine";

import DraftEquityEngineHeader from "@/components/DraftEquityEngine/DraftEquityEngineHeader";
import SportTierSelector from "@/components/DraftEquityEngine/SportTierSelector";
import InputPanel from "@/components/DraftEquityEngine/InputPanel";
import Sidebar from "@/components/DraftEquityEngine/Sidebar";
import ContributorModal from "@/components/DraftEquityEngine/ContributorModal";
import LoadingView from "@/components/DraftEquityEngine/LoadingView";

export default function DraftEquityEngine() {
  const { data: user, loading } = useUser();
  const draftEquityHook = useDraftEquityEngine(user);

  if (loading) {
    return <LoadingView />;
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <DraftEquityEngineHeader user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SportTierSelector
          selectedTier={draftEquityHook.selectedTier}
          onTierSelect={draftEquityHook.setSelectedTier}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <InputPanel
            activeTab={draftEquityHook.activeTab}
            setActiveTab={draftEquityHook.setActiveTab}
            simulation={draftEquityHook.simulation}
            currentTier={draftEquityHook.currentTier}
            draftPosition={draftEquityHook.draftPosition}
            setDraftPosition={draftEquityHook.setDraftPosition}
            teamFitScore={draftEquityHook.teamFitScore}
            setTeamFitScore={draftEquityHook.setTeamFitScore}
            teamName={draftEquityHook.teamName}
            setTeamName={draftEquityHook.setTeamName}
            getSelectionTierForPosition={
              draftEquityHook.getSelectionTierForPosition
            }
            biometrics={draftEquityHook.biometrics}
            handleBiometricChange={draftEquityHook.handleBiometricChange}
            calculateBiometricIndex={draftEquityHook.calculateBiometricIndex}
            contributors={draftEquityHook.contributors}
            removeContributor={draftEquityHook.removeContributor}
            setShowContributorModal={draftEquityHook.setShowContributorModal}
            runSimulation={draftEquityHook.runSimulation}
            isProcessing={draftEquityHook.isProcessing}
          />

          <Sidebar
            currentTier={draftEquityHook.currentTier}
            simulationHistory={draftEquityHook.simulationHistory}
          />
        </div>
      </div>

      <ContributorModal
        show={draftEquityHook.showContributorModal}
        onClose={() => draftEquityHook.setShowContributorModal(false)}
        onAddContributor={draftEquityHook.addContributor}
      />
    </div>
  );
}
