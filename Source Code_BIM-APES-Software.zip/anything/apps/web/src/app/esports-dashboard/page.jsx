"use client";

import { useState, useEffect } from "react";
import {
  Monitor,
  Zap,
  Target,
  Clock,
  Users,
  TrendingUp,
  Gamepad2,
  MousePointer2,
  Brain,
  Award,
  BarChart3,
  Settings,
  Trophy,
  Activity,
  Headphones,
  Eye,
  Shield,
  Star,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function EsportsDashboard() {
  const { data: user, loading } = useUser();
  const [selectedGameType, setSelectedGameType] = useState("moba");
  const [performanceData, setPerformanceData] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [gameSession, setGameSession] = useState({
    match_duration: 1800, // 30 minutes
    clicks: 2400,
    keystrokes: 1800,
    mouse_movements: 1200,
    reaction_times: [185, 175, 195, 165, 180],
    accuracy: 0.78,
    eliminations: 12,
    assists: 8,
  });

  const gameTypes = [
    {
      id: "moba",
      name: "MOBA",
      icon: Shield,
      color: "bg-purple-500",
      games: ["League of Legends", "Dota 2", "Heroes of the Storm"],
    },
    {
      id: "fps",
      name: "FPS",
      icon: Target,
      color: "bg-red-500",
      games: ["Valorant", "CS2", "Apex Legends"],
    },
    {
      id: "fighting",
      name: "Fighting",
      icon: Award,
      color: "bg-orange-500",
      games: ["Street Fighter 6", "Tekken 8", "Mortal Kombat"],
    },
    {
      id: "battle_royale",
      name: "Battle Royale",
      icon: Eye,
      color: "bg-green-500",
      games: ["Fortnite", "PUBG", "Warzone"],
    },
  ];

  const performanceMetrics = [
    {
      key: "apm",
      label: "APM",
      description: "Actions Per Minute",
      icon: MousePointer2,
      color: "text-blue-600",
      suffix: "",
    },
    {
      key: "reaction_time",
      label: "Reaction Time",
      description: "Average Response Speed",
      icon: Zap,
      color: "text-yellow-600",
      suffix: "ms",
    },
    {
      key: "game_sense",
      label: "Game Sense",
      description: "Decision Making Quality",
      icon: Brain,
      color: "text-purple-600",
      suffix: "",
    },
    {
      key: "clutch_performance",
      label: "Clutch Performance",
      description: "Performance Under Pressure",
      icon: Trophy,
      color: "text-gold-600",
      suffix: "",
    },
    {
      key: "team_synergy",
      label: "Team Synergy",
      description: "Communication & Coordination",
      icon: Users,
      color: "text-green-600",
      suffix: "",
    },
    {
      key: "tactical_efficiency",
      label: "Tactical Efficiency",
      description: "Strategic Execution",
      icon: Target,
      color: "text-red-600",
      suffix: "",
    },
  ];

  const runPerformanceAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      // Add game-type specific data
      const gameSpecificData = { ...gameSession };

      switch (selectedGameType) {
        case "moba":
          gameSpecificData.map_awareness = 0.75;
          gameSpecificData.vision_score = 0.8;
          gameSpecificData.objective_participation = 0.85;
          gameSpecificData.teamfight_positioning = 0.7;
          gameSpecificData.solo_kill_rate = 0.2;
          gameSpecificData.multi_kill_frequency = 0.15;
          break;
        case "fps":
          gameSpecificData.crosshair_placement = 0.82;
          gameSpecificData.angle_control = 0.75;
          gameSpecificData.utility_efficiency = 0.68;
          gameSpecificData.headshot_percentage = 0.35;
          gameSpecificData.first_blood_rate = 0.25;
          break;
        case "fighting":
          gameSpecificData.combo_efficiency = 0.78;
          gameSpecificData.frame_advantage = 0.72;
          gameSpecificData.spacing_control = 0.8;
          gameSpecificData.mixup_effectiveness = 0.75;
          gameSpecificData.perfect_round_rate = 0.12;
          gameSpecificData.combo_completion_rate = 0.85;
          break;
        case "battle_royale":
          gameSpecificData.positioning_score = 0.8;
          gameSpecificData.zone_positioning = 0.75;
          gameSpecificData.rotation_timing = 0.82;
          gameSpecificData.third_party_avoidance = 0.7;
          gameSpecificData.high_elim_game_rate = 0.25;
          gameSpecificData.squad_wipe_rate = 0.15;
          break;
      }

      gameSpecificData.clutch_situations = [
        { won: true },
        { won: false },
        { won: true },
        { won: true },
      ];
      gameSpecificData.communication_score = 0.75;

      const response = await fetch("/api/bim-performance/esports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          game_data: gameSpecificData,
          game_type: selectedGameType,
          match_metadata: {
            game_mode: "ranked",
            map: "Summoner's Rift",
            duration: gameSession.match_duration,
          },
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setPerformanceData(data);
      } else {
        console.error("Analysis failed");
      }
    } catch (error) {
      console.error("Error running analysis:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#00D4AA] mx-auto mb-4"></div>
          <p className="text-gray-400">Loading esports dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1A1A2E] to-[#16213E] border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 bg-gradient-to-r from-[#00D4AA] to-[#00A885] rounded-lg flex items-center justify-center">
                  <Gamepad2 className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-3xl font-bold">
                  Esports Performance Dashboard
                </h1>
              </div>
              <p className="text-gray-400">
                Advanced performance analytics for competitive gaming
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-400">Current Tier</div>
              <div className="text-2xl font-bold text-[#00D4AA]">
                Silver Pro
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Game Type Selection */}
          <div className="lg:col-span-1">
            <div className="bg-[#1A1A2E] rounded-xl p-6 border border-gray-800">
              <h2 className="text-xl font-semibold mb-6 flex items-center space-x-2">
                <Monitor className="w-5 h-5" />
                <span>Game Type</span>
              </h2>
              <div className="space-y-3">
                {gameTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.id}
                      onClick={() => setSelectedGameType(type.id)}
                      className={`w-full p-4 rounded-lg border-2 transition-all ${
                        selectedGameType === type.id
                          ? "border-[#00D4AA] bg-[#00D4AA]/10"
                          : "border-gray-700 bg-[#0F0F1A] hover:border-gray-600"
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-10 h-10 ${type.color} rounded-lg flex items-center justify-center`}
                        >
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div className="text-left flex-1">
                          <div className="font-medium">{type.name}</div>
                          <div className="text-sm text-gray-400">
                            {type.games[0]}
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Session Configuration */}
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-4">Session Settings</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">
                      Match Duration (minutes)
                    </label>
                    <input
                      type="number"
                      value={Math.round(gameSession.match_duration / 60)}
                      onChange={(e) =>
                        setGameSession({
                          ...gameSession,
                          match_duration: parseInt(e.target.value) * 60,
                        })
                      }
                      className="w-full bg-[#0F0F1A] border border-gray-700 rounded-lg px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">
                      Total Eliminations
                    </label>
                    <input
                      type="number"
                      value={gameSession.eliminations}
                      onChange={(e) =>
                        setGameSession({
                          ...gameSession,
                          eliminations: parseInt(e.target.value),
                        })
                      }
                      className="w-full bg-[#0F0F1A] border border-gray-700 rounded-lg px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">
                      Accuracy (%)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={Math.round(gameSession.accuracy * 100)}
                      onChange={(e) =>
                        setGameSession({
                          ...gameSession,
                          accuracy: parseInt(e.target.value) / 100,
                        })
                      }
                      className="w-full bg-[#0F0F1A] border border-gray-700 rounded-lg px-3 py-2 text-white"
                    />
                  </div>
                </div>

                <button
                  onClick={runPerformanceAnalysis}
                  disabled={isAnalyzing}
                  className="w-full mt-6 bg-gradient-to-r from-[#00D4AA] to-[#00A885] hover:from-[#00A885] hover:to-[#007A63] text-white py-3 px-4 rounded-lg font-medium transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                  {isAnalyzing ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <Activity className="w-5 h-5" />
                      <span>Analyze Performance</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="lg:col-span-2">
            {performanceData ? (
              <div className="space-y-6">
                {/* Overall Score */}
                <div className="bg-gradient-to-r from-[#1A1A2E] to-[#16213E] rounded-xl p-6 border border-gray-800">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-2xl font-bold">Performance Index</h2>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-[#00D4AA]">
                        {performanceData.performance_metrics.overall_score}
                      </div>
                      <div className="text-sm text-gray-400">
                        {performanceData.performance_metrics.scale_type ===
                        "professional_esports"
                          ? "Pro Scale"
                          : "Amateur Scale"}
                      </div>
                    </div>
                  </div>
                  <div className="text-gray-300">{performanceData.message}</div>
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {performanceMetrics.map((metric) => {
                    const Icon = metric.icon;
                    const value =
                      performanceData.performance_metrics[metric.key];

                    return (
                      <div
                        key={metric.key}
                        className="bg-[#1A1A2E] rounded-xl p-6 border border-gray-800"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center`}
                            >
                              <Icon className={`w-5 h-5 ${metric.color}`} />
                            </div>
                            <div>
                              <div className="font-medium">{metric.label}</div>
                              <div className="text-sm text-gray-400">
                                {metric.description}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-white">
                              {value}
                              {metric.suffix}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Insights */}
                {performanceData.insights && (
                  <div className="bg-[#1A1A2E] rounded-xl p-6 border border-gray-800">
                    <h3 className="text-xl font-semibold mb-6 flex items-center space-x-2">
                      <Brain className="w-5 h-5" />
                      <span>Performance Insights</span>
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {performanceData.insights.strengths.length > 0 && (
                        <div>
                          <h4 className="font-medium text-green-400 mb-3 flex items-center space-x-2">
                            <TrendingUp className="w-4 h-4" />
                            <span>Strengths</span>
                          </h4>
                          <ul className="space-y-2">
                            {performanceData.insights.strengths.map(
                              (strength, index) => (
                                <li
                                  key={index}
                                  className="text-sm text-gray-300 flex items-center space-x-2"
                                >
                                  <Star className="w-3 h-3 text-green-400" />
                                  <span>{strength}</span>
                                </li>
                              ),
                            )}
                          </ul>
                        </div>
                      )}

                      {performanceData.insights.improvements.length > 0 && (
                        <div>
                          <h4 className="font-medium text-yellow-400 mb-3 flex items-center space-x-2">
                            <Target className="w-4 h-4" />
                            <span>Focus Areas</span>
                          </h4>
                          <ul className="space-y-2">
                            {performanceData.insights.improvements.map(
                              (improvement, index) => (
                                <li
                                  key={index}
                                  className="text-sm text-gray-300 flex items-center space-x-2"
                                >
                                  <Target className="w-3 h-3 text-yellow-400" />
                                  <span>{improvement}</span>
                                </li>
                              ),
                            )}
                          </ul>
                        </div>
                      )}

                      {performanceData.insights.game_specific_tips.length >
                        0 && (
                        <div>
                          <h4 className="font-medium text-blue-400 mb-3 flex items-center space-x-2">
                            <Settings className="w-4 h-4" />
                            <span>Game-Specific Tips</span>
                          </h4>
                          <ul className="space-y-2">
                            {performanceData.insights.game_specific_tips.map(
                              (tip, index) => (
                                <li
                                  key={index}
                                  className="text-sm text-gray-300 flex items-center space-x-2"
                                >
                                  <Headphones className="w-3 h-3 text-blue-400" />
                                  <span>{tip}</span>
                                </li>
                              ),
                            )}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-[#1A1A2E] rounded-xl p-12 border border-gray-800 text-center">
                <Gamepad2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-400 mb-2">
                  Ready to Analyze Performance
                </h3>
                <p className="text-gray-500">
                  Configure your game session and click "Analyze Performance" to
                  see detailed metrics
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
