"use client";

import { useState, useEffect } from "react";
import {
  TrendingUp,
  Zap,
  DollarSign,
  Bitcoin,
  Award,
  Users,
  ShoppingCart,
  BarChart3,
  AlertCircle,
  CheckCircle,
  Clock,
  Target,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function TeamOwnerDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [ownerProfile, setOwnerProfile] = useState(null);
  const [credits, setCredits] = useState([]);
  const [deployments, setDeployments] = useState([]);
  const [scenarios, setScenarios] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    if (user?.id) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Load owner profile
      const profileRes = await fetch(
        "/api/strategy-exchange/team-owner/onboard",
      );
      const profileData = await profileRes.json();

      if (profileData.exists) {
        setOwnerProfile(profileData.owner);

        // Load credits
        const creditsRes = await fetch(
          "/api/strategy-exchange/buy-in-credits/purchase",
        );
        const creditsData = await creditsRes.json();
        setCredits(creditsData.credits || []);

        // Load deployments
        const deploymentsRes = await fetch(
          "/api/strategy-exchange/credits/deploy",
        );
        const deploymentsData = await deploymentsRes.json();
        setDeployments(deploymentsData.deployments || []);

        // Load scenarios
        const scenariosRes = await fetch(
          "/api/strategy-exchange/hfg/scenarios",
        );
        const scenariosData = await scenariosRes.json();
        setScenarios(scenariosData.scenarios || []);
      }
    } catch (error) {
      console.error("Error loading dashboard:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#C8A882] mx-auto"></div>
          <p className="text-[#E8DCC8] mt-4">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <AlertCircle className="w-16 h-16 text-[#9CA3AF] mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">
            Sign In Required
          </h1>
          <p className="text-[#E8DCC8]">
            Please sign in to access the Team Owner Dashboard
          </p>
          <a
            href="/account/signin"
            className="inline-block mt-6 px-6 py-3 bg-[#C8A882] text-[#1B3A57] font-bold rounded-lg hover:bg-[#D4B896] transition shadow-lg"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (!ownerProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <Users className="w-16 h-16 text-[#9CA3AF] mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">
            Team Owner Profile Required
          </h1>
          <p className="text-[#E8DCC8] mb-6">
            Create a team owner profile to access the BIM-APES Strategy Exchange
          </p>
          <a
            href="/strategy-exchange/onboard"
            className="inline-block px-6 py-3 bg-[#C8A882] text-[#1B3A57] font-bold rounded-lg hover:bg-[#D4B896] transition shadow-lg"
          >
            Create Profile
          </a>
        </div>
      </div>
    );
  }

  const activeCreditCount = credits.filter(
    (c) => c.credit_status === "active",
  ).length;
  const deployedCreditCount = credits.filter(
    (c) => c.credit_status === "deployed",
  ).length;
  const activeScenarios = scenarios.filter(
    (s) => s.scenario_status === "executing",
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#152E45] via-[#1B3A57] to-[#2A4A68]">
      {/* Header */}
      <div className="bg-[#1B3A57]/90 border-b-2 border-[#C8A882] backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">
                BIM-APES Strategy Exchange™
              </h1>
              <p className="text-[#E8DCC8] mt-1">Team Owner Dashboard</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-white/10 px-4 py-2 rounded-lg border border-[#C8A882]/20">
                <div className="text-xs text-[#9CA3AF]">Organization</div>
                <div className="text-sm font-semibold text-white">
                  {ownerProfile.organization_name}
                </div>
              </div>
              <div className="bg-white/10 px-4 py-2 rounded-lg border border-[#C8A882]/20">
                <div className="text-xs text-[#9CA3AF]">Status</div>
                <div className="flex items-center gap-1">
                  {ownerProfile.verification_status === "verified" ? (
                    <>
                      <CheckCircle className="w-3 h-3 text-green-400" />
                      <span className="text-sm font-semibold text-green-400">
                        Verified
                      </span>
                    </>
                  ) : (
                    <>
                      <Clock className="w-3 h-3 text-yellow-400" />
                      <span className="text-sm font-semibold text-yellow-400">
                        Pending
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <StatCard
            icon={Zap}
            label="Active Credits"
            value={activeCreditCount}
            color="#10B981"
          />
          <StatCard
            icon={Target}
            label="Deployed Credits"
            value={deployedCreditCount}
            color="#3B82F6"
          />
          <StatCard
            icon={BarChart3}
            label="Active Scenarios"
            value={activeScenarios}
            color="#F59E0B"
          />
          <StatCard
            icon={DollarSign}
            label="Total Invested"
            value={`$${ownerProfile.total_spend_usd?.toLocaleString() || 0}`}
            color="#8B5CF6"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-[#1F2937]">
          <TabButton
            active={activeTab === "overview"}
            onClick={() => setActiveTab("overview")}
          >
            Overview
          </TabButton>
          <TabButton
            active={activeTab === "credits"}
            onClick={() => setActiveTab("credits")}
          >
            Buy-In Credits
          </TabButton>
          <TabButton
            active={activeTab === "deployments"}
            onClick={() => setActiveTab("deployments")}
          >
            Deployments
          </TabButton>
          <TabButton
            active={activeTab === "scenarios"}
            onClick={() => setActiveTab("scenarios")}
          >
            HFG Scenarios
          </TabButton>
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <OverviewTab
            ownerProfile={ownerProfile}
            credits={credits}
            deployments={deployments}
            scenarios={scenarios}
          />
        )}

        {activeTab === "credits" && (
          <CreditsTab credits={credits} onReload={loadDashboardData} />
        )}

        {activeTab === "deployments" && (
          <DeploymentsTab deployments={deployments} />
        )}

        {activeTab === "scenarios" && (
          <ScenariosTab scenarios={scenarios} onReload={loadDashboardData} />
        )}
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <div className="bg-white/5 border border-[#C8A882]/20 rounded-lg p-4 backdrop-blur-lg">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-[#9CA3AF] mb-1">{label}</div>
          <div className="text-2xl font-bold text-white">{value}</div>
        </div>
        <Icon className="w-8 h-8 text-[#C8A882]" />
      </div>
    </div>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 font-semibold transition ${
        active
          ? "text-[#C8A882] border-b-2 border-[#C8A882]"
          : "text-[#E8DCC8] hover:text-white"
      }`}
    >
      {children}
    </button>
  );
}

function OverviewTab({ ownerProfile, credits, deployments, scenarios }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-[#111827] border border-[#1F2937] rounded-lg p-6">
        <h3 className="text-lg font-bold text-[#F3F4F6] mb-4">
          Account Summary
        </h3>
        <div className="space-y-3">
          <SummaryRow
            label="Point Balance"
            value={ownerProfile.point_balance?.toLocaleString() || 0}
          />
          <SummaryRow
            label="Total Credits Purchased"
            value={ownerProfile.total_credits_purchased || 0}
          />
          <SummaryRow
            label="Total Spend (USD)"
            value={`$${ownerProfile.total_spend_usd?.toLocaleString() || 0}`}
          />
          <SummaryRow
            label="Tier Level"
            value={ownerProfile.tier_level?.toUpperCase() || "ENTRY"}
          />
        </div>
      </div>

      <div className="bg-[#111827] border border-[#1F2937] rounded-lg p-6">
        <h3 className="text-lg font-bold text-[#F3F4F6] mb-4">Quick Actions</h3>
        <div className="space-y-2">
          <ActionButton href="/strategy-exchange/purchase-credits">
            <ShoppingCart className="w-4 h-4" />
            Purchase Credits
          </ActionButton>
          <ActionButton href="/strategy-exchange/create-scenario">
            <BarChart3 className="w-4 h-4" />
            Create HFG Scenario
          </ActionButton>
          <ActionButton href="/strategy-exchange/point-packs">
            <Bitcoin className="w-4 h-4" />
            Buy Point Packs
          </ActionButton>
        </div>
      </div>
    </div>
  );
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex justify-between items-center py-2 border-b border-[#1F2937]">
      <span className="text-[#9CA3AF]">{label}</span>
      <span className="text-[#F3F4F6] font-semibold">{value}</span>
    </div>
  );
}

function ActionButton({ href, children }) {
  return (
    <a
      href={href}
      className="flex items-center gap-2 w-full px-4 py-3 bg-[#1F2937] hover:bg-[#374151] text-[#F3F4F6] rounded-lg transition"
    >
      {children}
    </a>
  );
}

function CreditsTab({ credits, onReload }) {
  const creditTypes = {
    performance_boost: {
      name: "Performance Boost",
      color: "#10B981",
      duration: "24h",
    },
    momentum_stabilizer: {
      name: "Momentum Stabilizer",
      color: "#3B82F6",
      duration: "48h",
    },
    spotlight: { name: "Spotlight", color: "#F59E0B", duration: "24h" },
    event_window: { name: "Event Window", color: "#8B5CF6", duration: "72h" },
  };

  return (
    <div className="bg-[#111827] border border-[#1F2937] rounded-lg">
      <div className="p-6 border-b border-[#1F2937] flex justify-between items-center">
        <h3 className="text-lg font-bold text-[#F3F4F6]">Buy-In Credits</h3>
        <a
          href="/strategy-exchange/purchase-credits"
          className="px-4 py-2 bg-[#10B981] text-white rounded-lg hover:bg-[#059669] transition"
        >
          Purchase Credits
        </a>
      </div>
      <div className="divide-y divide-[#1F2937]">
        {credits.length === 0 ? (
          <div className="p-8 text-center text-[#6B7280]">
            No credits purchased yet
          </div>
        ) : (
          credits.map((credit) => {
            const type = creditTypes[credit.credit_type] || {};
            return (
              <div
                key={credit.id}
                className="p-4 hover:bg-[#1F2937] transition"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div
                      className="font-semibold text-[#F3F4F6]"
                      style={{ color: type.color }}
                    >
                      {type.name || credit.credit_type}
                    </div>
                    <div className="text-sm text-[#9CA3AF]">
                      Duration: {type.duration} • Effect: +
                      {credit.effect_magnitude}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-[#F3F4F6]">
                      {credit.credit_status.toUpperCase()}
                    </div>
                    <div className="text-xs text-[#9CA3AF]">
                      ${credit.purchase_price}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function DeploymentsTab({ deployments }) {
  return (
    <div className="bg-[#111827] border border-[#1F2937] rounded-lg">
      <div className="p-6 border-b border-[#1F2937]">
        <h3 className="text-lg font-bold text-[#F3F4F6]">Credit Deployments</h3>
      </div>
      <div className="divide-y divide-[#1F2937]">
        {deployments.length === 0 ? (
          <div className="p-8 text-center text-[#6B7280]">
            No deployments yet
          </div>
        ) : (
          deployments.map((deployment) => (
            <div
              key={deployment.id}
              className="p-4 hover:bg-[#1F2937] transition"
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold text-[#F3F4F6]">
                    {deployment.athlete_name}
                  </div>
                  <div className="text-sm text-[#9CA3AF]">
                    {deployment.credit_type} • +{deployment.index_lift_target}{" "}
                    index points
                  </div>
                  <div className="text-xs text-[#6B7280] mt-1">
                    {new Date(deployment.deployed_at).toLocaleString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-semibold text-[#10B981]">
                    {deployment.duration_hours}h duration
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function ScenariosTab({ scenarios, onReload }) {
  return (
    <div className="bg-[#111827] border border-[#1F2937] rounded-lg">
      <div className="p-6 border-b border-[#1F2937] flex justify-between items-center">
        <h3 className="text-lg font-bold text-[#F3F4F6]">HFG Scenarios</h3>
        <a
          href="/strategy-exchange/create-scenario"
          className="px-4 py-2 bg-[#10B981] text-white rounded-lg hover:bg-[#059669] transition"
        >
          Create Scenario
        </a>
      </div>
      <div className="divide-y divide-[#1F2937]">
        {scenarios.length === 0 ? (
          <div className="p-8 text-center text-[#6B7280]">
            No scenarios created yet
          </div>
        ) : (
          scenarios.map((scenario) => (
            <div
              key={scenario.id}
              className="p-4 hover:bg-[#1F2937] transition"
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold text-[#F3F4F6]">
                    {scenario.scenario_name}
                  </div>
                  <div className="text-sm text-[#9CA3AF]">
                    {scenario.scenario_type.replace("_", " ").toUpperCase()}
                  </div>
                  <div className="text-xs text-[#6B7280] mt-1">
                    Created:{" "}
                    {new Date(scenario.created_at).toLocaleDateString()}
                  </div>
                </div>
                <div className="text-right">
                  <StatusBadge status={scenario.scenario_status} />
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const styles = {
    draft: { bg: "#374151", text: "#9CA3AF" },
    approved: { bg: "#10B98120", text: "#10B981" },
    executing: { bg: "#3B82F620", text: "#3B82F6" },
    completed: { bg: "#8B5CF620", text: "#8B5CF6" },
  };

  const style = styles[status] || styles.draft;

  return (
    <div
      className="px-3 py-1 rounded-full text-xs font-semibold"
      style={{ backgroundColor: style.bg, color: style.text }}
    >
      {status.toUpperCase()}
    </div>
  );
}
