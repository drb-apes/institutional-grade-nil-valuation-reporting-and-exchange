"use client";

import { useState, useEffect } from "react";
import {
  Music,
  TrendingUp,
  Users,
  Zap,
  Activity,
  DollarSign,
  Play,
  Pause,
  SkipForward,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function LiveConcertNILDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("live");
  const [concertData, setConcertData] = useState(null);
  const [isLive, setIsLive] = useState(false);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchConcertData();
    }
  }, [user]);

  const fetchConcertData = async () => {
    try {
      setLoadingData(true);

      // Mock live concert data
      const mockData = {
        artist: "Featured Artist",
        venue: "Madison Square Garden",
        currentSong: 3,
        totalSongs: 18,
        setlist: generateSetlist(),
        nilValue: 285000,
        nilChange: 12500,
        performanceUnits: {
          songPerformance: 0.92,
          verseDelivery: 0.89,
          chorusExecution: 0.94,
          highIntensityMoments: 0.88,
          crowdEngagement: 0.96,
        },
        realTimeMetrics: {
          vocalStability: 0.91,
          breathControl: 0.87,
          energyLevel: 0.93,
          crowdParticipation: 0.95,
          streamingSpike: 1847,
        },
      };

      setConcertData(mockData);
    } catch (error) {
      console.error("Failed to fetch concert data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900 flex items-center justify-center">
        <div className="text-center">
          <Music className="w-16 h-16 text-purple-400 mx-auto mb-4 animate-pulse" />
          <p className="text-white text-xl mt-4">
            Loading Live Concert NIL Dashboard...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900">
      {/* Header */}
      <header className="border-b border-purple-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Music className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Live Concert NIL Valuation
                </h1>
                <p className="text-purple-300 text-sm">
                  Real-Time Performance → NIL Updates
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div
                className={`px-4 py-2 rounded-lg ${isLive ? "bg-red-500/20 border border-red-500" : "bg-gray-500/20 border border-gray-500"}`}
              >
                <div className="flex items-center gap-2">
                  {isLive && (
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  )}
                  <span className="text-white font-semibold">
                    {isLive ? "LIVE" : "STANDBY"}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIsLive(!isLive)}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
              >
                {isLive ? (
                  <Pause className="w-5 h-5" />
                ) : (
                  <Play className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="border-b border-purple-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "live", label: "Live Feed", icon: Activity },
              { id: "performance", label: "Performance Units", icon: Zap },
              { id: "nil", label: "NIL Tracker", icon: DollarSign },
              { id: "setlist", label: "Setlist Analysis", icon: Music },
              { id: "crowd", label: "Crowd Engagement", icon: Users },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-purple-400 text-purple-400"
                    : "border-transparent text-purple-300 hover:text-purple-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "live" && (
          <LiveFeedTab concertData={concertData} isLive={isLive} />
        )}
        {activeTab === "performance" && (
          <PerformanceUnitsTab concertData={concertData} />
        )}
        {activeTab === "nil" && <NILTrackerTab concertData={concertData} />}
        {activeTab === "setlist" && (
          <SetlistAnalysisTab concertData={concertData} />
        )}
        {activeTab === "crowd" && (
          <CrowdEngagementTab concertData={concertData} />
        )}
      </div>
    </div>
  );
}

function LiveFeedTab({ concertData, isLive }) {
  return (
    <div className="space-y-6">
      {/* Current Status */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">
              {concertData.artist}
            </h2>
            <p className="text-purple-300">{concertData.venue}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-purple-300">Current NIL Value</p>
            <p className="text-3xl font-bold text-white">
              ${(concertData.nilValue / 1000).toFixed(0)}K
            </p>
            <p className="text-sm text-green-400">
              +${(concertData.nilChange / 1000).toFixed(1)}K this show
            </p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-purple-300 text-sm">Show Progress</span>
            <span className="text-white text-sm">
              Song {concertData.currentSong} / {concertData.totalSongs}
            </span>
          </div>
          <div className="w-full bg-purple-900/30 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full transition-all duration-500"
              style={{
                width: `${(concertData.currentSong / concertData.totalSongs) * 100}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Real-Time Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Vocal Stability"
          value={(concertData.realTimeMetrics.vocalStability * 100).toFixed(0)}
          icon={Music}
          trend={isLive ? "Live" : "Paused"}
          color="purple"
          isLive={isLive}
        />
        <MetricCard
          title="Energy Level"
          value={(concertData.realTimeMetrics.energyLevel * 100).toFixed(0)}
          icon={Zap}
          trend={isLive ? "Live" : "Paused"}
          color="pink"
          isLive={isLive}
        />
        <MetricCard
          title="Crowd Participation"
          value={(concertData.realTimeMetrics.crowdParticipation * 100).toFixed(
            0,
          )}
          icon={Users}
          trend={isLive ? "Live" : "Paused"}
          color="blue"
          isLive={isLive}
        />
      </div>

      {/* Current Song Performance */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">
          Current Song:{" "}
          {concertData.setlist[concertData.currentSong - 1]?.title}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <PerformanceUnit title="Verse Quality" value="92" />
          <PerformanceUnit title="Hook Impact" value="94" />
          <PerformanceUnit title="Dance Energy" value="88" />
          <PerformanceUnit title="Crowd Response" value="96" />
          <PerformanceUnit title="Vocal Power" value="91" />
        </div>
      </div>

      {/* Live Activity Feed */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">
          Live Activity Feed
        </h3>
        <div className="space-y-3">
          {generateLiveActivities(isLive).map((activity, i) => (
            <div
              key={i}
              className="flex items-center gap-4 p-3 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="w-2 h-2 bg-purple-400 rounded-full" />
              <div className="flex-1">
                <p className="text-white">{activity.event}</p>
                <p className="text-sm text-purple-300">{activity.timestamp}</p>
              </div>
              <div
                className={`px-3 py-1 rounded ${activity.impact === "positive" ? "bg-green-500/20 text-green-300" : "bg-yellow-500/20 text-yellow-300"}`}
              >
                {activity.nilChange > 0 ? "+" : ""}
                {activity.nilChange}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PerformanceUnitsTab({ concertData }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Concert Performance Units (CPUs)
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Song Performance Units
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Overall Quality</span>
              <span className="text-white font-bold">
                {(concertData.performanceUnits.songPerformance * 100).toFixed(
                  0,
                )}
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2">
              <div
                className="bg-purple-500 h-2 rounded-full"
                style={{
                  width: `${concertData.performanceUnits.songPerformance * 100}%`,
                }}
              />
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Verse Delivery Units
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Clarity & Flow</span>
              <span className="text-white font-bold">
                {(concertData.performanceUnits.verseDelivery * 100).toFixed(0)}
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2">
              <div
                className="bg-pink-500 h-2 rounded-full"
                style={{
                  width: `${concertData.performanceUnits.verseDelivery * 100}%`,
                }}
              />
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Chorus/Hook Execution
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Impact & Power</span>
              <span className="text-white font-bold">
                {(concertData.performanceUnits.chorusExecution * 100).toFixed(
                  0,
                )}
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full"
                style={{
                  width: `${concertData.performanceUnits.chorusExecution * 100}%`,
                }}
              />
            </div>
          </div>
        </div>

        <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            High-Intensity Moments
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-300">Vocal Runs & Bursts</span>
              <span className="text-white font-bold">
                {(
                  concertData.performanceUnits.highIntensityMoments * 100
                ).toFixed(0)}
              </span>
            </div>
            <div className="w-full bg-purple-900/30 rounded-full h-2">
              <div
                className="bg-yellow-500 h-2 rounded-full"
                style={{
                  width: `${concertData.performanceUnits.highIntensityMoments * 100}%`,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* CPU Breakdown */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">
          Performance Unit Breakdown
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <CPUCard title="Verse Precision" count="142" efficiency="89%" />
          <CPUCard title="Hook Landings" count="38" efficiency="94%" />
          <CPUCard title="Dance Sequences" count="24" efficiency="88%" />
          <CPUCard title="Crowd Interactions" count="67" efficiency="96%" />
          <CPUCard title="Vocal Runs" count="31" efficiency="91%" />
          <CPUCard title="Transitions" count="17" efficiency="87%" />
        </div>
      </div>
    </div>
  );
}

function NILTrackerTab({ concertData }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Real-Time NIL Valuation</h2>

      {/* NIL Summary */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div>
            <p className="text-sm text-purple-300 mb-2">Pre-Show NIL</p>
            <p className="text-2xl font-bold text-white">
              $
              {((concertData.nilValue - concertData.nilChange) / 1000).toFixed(
                0,
              )}
              K
            </p>
          </div>
          <div>
            <p className="text-sm text-purple-300 mb-2">Current NIL</p>
            <p className="text-2xl font-bold text-white">
              ${(concertData.nilValue / 1000).toFixed(0)}K
            </p>
          </div>
          <div>
            <p className="text-sm text-purple-300 mb-2">Show Gain</p>
            <p className="text-2xl font-bold text-green-400">
              +${(concertData.nilChange / 1000).toFixed(1)}K
            </p>
          </div>
          <div>
            <p className="text-sm text-purple-300 mb-2">Projected Final</p>
            <p className="text-2xl font-bold text-purple-400">
              ${((concertData.nilValue + 3500) / 1000).toFixed(0)}K
            </p>
          </div>
        </div>
      </div>

      {/* NIL Change Drivers */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">
          NIL Change Drivers
        </h3>
        <div className="space-y-4">
          <DriverCard
            title="Performance Quality"
            contribution="+$4,200"
            percentage="34%"
          />
          <DriverCard
            title="Crowd Engagement"
            contribution="+$5,100"
            percentage="41%"
          />
          <DriverCard
            title="Streaming Spike"
            contribution="+$2,300"
            percentage="18%"
          />
          <DriverCard
            title="Social Momentum"
            contribution="+$900"
            percentage="7%"
          />
        </div>
      </div>

      {/* Song-by-Song NIL Impact */}
      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">
          Song-by-Song NIL Impact
        </h3>
        <div className="space-y-2">
          {concertData.setlist
            .slice(0, concertData.currentSong)
            .map((song, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-purple-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{song.title}</p>
                  <p className="text-sm text-purple-300">Song {i + 1}</p>
                </div>
                <div className="text-right">
                  <p
                    className={`font-bold ${song.nilImpact > 0 ? "text-green-400" : "text-red-400"}`}
                  >
                    {song.nilImpact > 0 ? "+" : ""}$
                    {(song.nilImpact / 1000).toFixed(1)}K
                  </p>
                  <p className="text-xs text-purple-300">
                    {song.performance}% quality
                  </p>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

function SetlistAnalysisTab({ concertData }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Setlist Performance Analysis
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {concertData.setlist.map((song, i) => (
          <div
            key={i}
            className={`bg-black/40 backdrop-blur-lg border rounded-xl p-6 ${
              i + 1 === concertData.currentSong
                ? "border-purple-500 bg-purple-900/20"
                : "border-purple-500/30"
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-white font-bold">{song.title}</p>
                <p className="text-sm text-purple-300">Song {i + 1}</p>
              </div>
              {i + 1 === concertData.currentSong && (
                <span className="px-3 py-1 bg-purple-500 text-white text-xs font-semibold rounded-full">
                  NOW PLAYING
                </span>
              )}
            </div>

            {i + 1 <= concertData.currentSong ? (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-purple-300">Performance</span>
                  <span className="text-white">{song.performance}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-300">Crowd Response</span>
                  <span className="text-white">{song.crowdResponse}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-300">NIL Impact</span>
                  <span
                    className={
                      song.nilImpact > 0 ? "text-green-400" : "text-red-400"
                    }
                  >
                    {song.nilImpact > 0 ? "+" : ""}$
                    {(song.nilImpact / 1000).toFixed(1)}K
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-purple-300/50 text-sm">Not performed yet</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function CrowdEngagementTab({ concertData }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Crowd Engagement Analytics
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <EngagementCard title="Overall Participation" value="96%" trend="+8%" />
        <EngagementCard title="Singing Along" value="89%" trend="+12%" />
        <EngagementCard title="Energy Level" value="94%" trend="+6%" />
      </div>

      <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-4">
          Engagement Moments
        </h3>
        <div className="space-y-3">
          {[
            {
              moment: "Opening Song - Crowd eruption",
              engagement: 98,
              time: "7:32 PM",
            },
            {
              moment: "Hit Single - Full venue singing",
              engagement: 99,
              time: "8:15 PM",
            },
            {
              moment: "Acoustic Set - Intimate connection",
              engagement: 94,
              time: "8:45 PM",
            },
            {
              moment: "Dance Break - High energy",
              engagement: 97,
              time: "9:10 PM",
            },
          ].map((item, i) => (
            <div
              key={i}
              className="p-4 bg-purple-900/20 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-semibold">{item.moment}</p>
                  <p className="text-sm text-purple-300">{item.time}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-white">
                    {item.engagement}%
                  </p>
                  <p className="text-xs text-purple-300">engagement</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color, isLive }) {
  const colorClasses = {
    purple: "from-purple-500 to-purple-600",
    pink: "from-pink-500 to-pink-600",
    blue: "from-blue-500 to-blue-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-purple-300 uppercase">
          {title}
        </p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg ${isLive ? "animate-pulse" : ""}`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-purple-300">{trend}</p>
    </div>
  );
}

function PerformanceUnit({ title, value }) {
  return (
    <div className="p-3 bg-purple-900/20 rounded-lg border border-purple-500/20">
      <p className="text-xs text-purple-300 mb-1">{title}</p>
      <p className="text-xl font-bold text-white">{value}</p>
    </div>
  );
}

function CPUCard({ title, count, efficiency }) {
  return (
    <div className="p-4 bg-purple-900/20 rounded-lg border border-purple-500/20">
      <p className="text-sm text-purple-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{count}</p>
      <p className="text-xs text-green-400">{efficiency} efficiency</p>
    </div>
  );
}

function DriverCard({ title, contribution, percentage }) {
  return (
    <div className="flex items-center justify-between p-4 bg-purple-900/20 rounded-lg border border-purple-500/20">
      <span className="text-white font-semibold">{title}</span>
      <div className="text-right">
        <p className="text-white font-bold">{contribution}</p>
        <p className="text-xs text-purple-300">{percentage} of total</p>
      </div>
    </div>
  );
}

function EngagementCard({ title, value, trend }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-purple-500/30 rounded-xl p-6">
      <p className="text-sm text-purple-300 mb-2">{title}</p>
      <p className="text-3xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function generateSetlist() {
  const songs = [
    "Opening Anthem",
    "Hit Single #1",
    "Deep Cut",
    "Fan Favorite",
    "New Release",
    "Ballad",
    "Dance Track",
    "Acoustic Song",
    "Throwback",
    "Collaboration",
    "High Energy",
    "Emotional Moment",
    "Crowd Singalong",
    "Break Section",
    "Comeback Track",
    "Viral Hit",
    "Album Closer",
    "Encore",
  ];

  return songs.map((title, i) => ({
    title,
    performance: Math.floor(85 + Math.random() * 15),
    crowdResponse: Math.floor(85 + Math.random() * 15),
    nilImpact: Math.floor((Math.random() * 2 - 0.3) * 1500),
  }));
}

function generateLiveActivities(isLive) {
  if (!isLive) {
    return [
      {
        event: "Show paused",
        timestamp: "Just now",
        nilChange: 0,
        impact: "neutral",
      },
    ];
  }

  return [
    {
      event: "Chorus hook landed clean - crowd erupts",
      timestamp: "2 seconds ago",
      nilChange: 850,
      impact: "positive",
    },
    {
      event: "Verse flow precision +12%",
      timestamp: "8 seconds ago",
      nilChange: 320,
      impact: "positive",
    },
    {
      event: "Breath control dip detected",
      timestamp: "15 seconds ago",
      nilChange: -150,
      impact: "negative",
    },
    {
      event: "Dance sequence completed - high energy",
      timestamp: "23 seconds ago",
      nilChange: 620,
      impact: "positive",
    },
    {
      event: "Streaming spike: +847 concurrent",
      timestamp: "31 seconds ago",
      nilChange: 290,
      impact: "positive",
    },
  ];
}
