"use client";

import { useState } from "react";
import {
  Network,
  Repeat,
  TrendingDown,
  User,
  Users,
  Trophy,
  Zap,
  ArrowRightLeft,
  Bell,
  Layers,
  GitBranch,
  Download,
  Maximize2,
  Activity,
  Heart,
  Watch,
  Radio,
  Database,
  BarChart3,
  Shield,
  Target,
  AlertTriangle,
  ChevronRight,
  Cpu,
} from "lucide-react";

export default function BIMAPESVisualDiagrams() {
  const [activeDiagram, setActiveDiagram] = useState("wearable-mesh");
  const [animationEnabled, setAnimationEnabled] = useState(true);

  const diagrams = [
    {
      id: "wearable-mesh",
      name: "Wearable Mesh Architecture",
      icon: Network,
      category: "Infrastructure",
    },
    {
      id: "nil-swap",
      name: "NIL Swap Protocol Engine",
      icon: Repeat,
      category: "Trading",
    },
    {
      id: "lpi-hedge",
      name: "Index Hedge Flow (LPI)",
      icon: Trophy,
      category: "Hedging",
    },
    {
      id: "ppi-hedge",
      name: "Player Hedge Flow (PPI)",
      icon: User,
      category: "Hedging",
    },
    {
      id: "tpi-hedge",
      name: "Team Hedge Flow (TPI)",
      icon: Users,
      category: "Hedging",
    },
    {
      id: "scalping-loop",
      name: "Scalping Loop",
      icon: Zap,
      category: "Trading",
    },
    {
      id: "arbitrage-loop",
      name: "Arbitrage Loop",
      icon: ArrowRightLeft,
      category: "Trading",
    },
    {
      id: "sponsor-dashboard",
      name: "Sponsor Dashboard Triggers",
      icon: Bell,
      category: "Monitoring",
    },
    {
      id: "physiobiofin",
      name: "PhysiobioFIN Architecture",
      icon: Layers,
      category: "Infrastructure",
    },
    {
      id: "coalition-pipeline",
      name: "Coalition Deployment",
      icon: GitBranch,
      category: "Deployment",
    },
  ];

  const categories = [
    "All",
    "Infrastructure",
    "Trading",
    "Hedging",
    "Monitoring",
    "Deployment",
  ];
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredDiagrams =
    activeCategory === "All"
      ? diagrams
      : diagrams.filter((d) => d.category === activeCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0E27] via-[#1A1F3A] to-[#2C3E50]">
      {/* Header */}
      <header className="bg-[#1D2B3D]/80 backdrop-blur-lg border-b-2 border-[#B8860B]">
        <div className="max-w-[1800px] mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-gradient-to-br from-[#B8860B] to-[#FFD700] rounded-xl flex items-center justify-center">
                <Network className="w-8 h-8 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white mb-1">
                  BIM-APES Visual Diagram Pack
                </h1>
                <p className="text-[#B8860B] font-medium">
                  Interactive architecture & flow visualizations
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => setAnimationEnabled(!animationEnabled)}
                className={`px-4 py-2 rounded-lg border transition-all ${
                  animationEnabled
                    ? "bg-[#B8860B] border-[#B8860B] text-black"
                    : "bg-[#1A1F3A] border-[#B8860B]/30 text-gray-400"
                }`}
              >
                <Activity className="w-5 h-5 inline mr-2" />
                {animationEnabled ? "Animations On" : "Animations Off"}
              </button>

              <button className="px-4 py-2 bg-[#00D9FF]/20 hover:bg-[#00D9FF]/30 text-[#00D9FF] border border-[#00D9FF]/30 rounded-lg transition-all">
                <Download className="w-5 h-5 inline mr-2" />
                Export All
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-[1800px] mx-auto px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="sticky top-8 space-y-4">
              {/* Category Filter */}
              <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-4">
                <h3 className="text-white font-bold mb-3">Categories</h3>
                <div className="space-y-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`w-full text-left px-3 py-2 rounded-lg transition-all text-sm ${
                        activeCategory === cat
                          ? "bg-[#B8860B] text-black font-semibold"
                          : "text-gray-400 hover:bg-[#1A1F3A]/50"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Diagram List */}
              <nav className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-4">
                <h3 className="text-white font-bold mb-3">Diagrams</h3>
                <div className="space-y-2">
                  {filteredDiagrams.map((diagram) => {
                    const Icon = diagram.icon;
                    return (
                      <button
                        key={diagram.id}
                        onClick={() => setActiveDiagram(diagram.id)}
                        className={`w-full text-left px-3 py-2 rounded-lg transition-all ${
                          activeDiagram === diagram.id
                            ? "bg-[#B8860B] text-black"
                            : "bg-[#1A1F3A]/30 text-gray-300 hover:bg-[#1A1F3A]/50"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" />
                          <span className="text-sm font-medium">
                            {diagram.name}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="lg:col-span-4">
            <DiagramRenderer
              diagramId={activeDiagram}
              animated={animationEnabled}
            />
          </main>
        </div>
      </div>
    </div>
  );
}

function DiagramRenderer({ diagramId, animated }) {
  const diagrams = {
    "wearable-mesh": <WearableMeshDiagram animated={animated} />,
    "nil-swap": <NILSwapDiagram animated={animated} />,
    "lpi-hedge": <LPIHedgeDiagram animated={animated} />,
    "ppi-hedge": <PPIHedgeDiagram animated={animated} />,
    "tpi-hedge": <TPIHedgeDiagram animated={animated} />,
    "scalping-loop": <ScalpingLoopDiagram animated={animated} />,
    "arbitrage-loop": <ArbitrageLoopDiagram animated={animated} />,
    "sponsor-dashboard": <SponsorDashboardDiagram animated={animated} />,
    physiobiofin: <PhysiobioFINDiagram animated={animated} />,
    "coalition-pipeline": <CoalitionPipelineDiagram animated={animated} />,
  };

  return diagrams[diagramId] || null;
}

// Wearable Mesh Architecture Diagram
function WearableMeshDiagram({ animated }) {
  const devices = [
    { name: "Smartwatch", icon: Watch, color: "blue-500" },
    { name: "Smart Ring", icon: Radio, color: "purple-500" },
    { name: "GPS Tracker", icon: Target, color: "green-500" },
    { name: "Chest Strap", icon: Heart, color: "red-500" },
    { name: "Sport Sensor", icon: Activity, color: "yellow-500" },
  ];

  const indices = [
    { name: "PPI", full: "Player Performance Index", color: "cyan" },
    { name: "TPI", full: "Team Performance Index", color: "purple" },
    { name: "LPI", full: "League Performance Index", color: "gold" },
  ];

  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Plug-and-Play Wearable Mesh Architecture
          </h2>
          <p className="text-gray-400">
            How wearable devices feed biometric data into BIM-APES performance
            indices
          </p>
        </div>
        <button className="px-4 py-2 bg-[#1A1F3A] hover:bg-[#1A1F3A]/80 text-white rounded-lg transition-all">
          <Maximize2 className="w-5 h-5 inline mr-2" />
          Expand
        </button>
      </div>

      {/* Diagram */}
      <div className="space-y-8">
        {/* Header Box */}
        <div className="flex justify-center">
          <div className="bg-gradient-to-r from-[#B8860B]/20 to-[#FFD700]/20 border-2 border-[#B8860B] rounded-xl px-8 py-4">
            <div className="flex items-center gap-3">
              <Network className="w-6 h-6 text-[#B8860B]" />
              <span className="text-xl font-bold text-white">
                BIM-APES Wearable Mesh
              </span>
            </div>
          </div>
        </div>

        {/* Devices Row */}
        <div className="grid grid-cols-5 gap-4">
          {devices.map((device, idx) => {
            const Icon = device.icon;
            return (
              <div
                key={idx}
                className={`bg-[#1A1F3A] border border-${device.color}/30 rounded-lg p-4 text-center ${
                  animated
                    ? "hover:scale-105 transition-transform duration-300"
                    : ""
                }`}
              >
                <Icon className={`w-8 h-8 text-${device.color} mx-auto mb-2`} />
                <div className="text-white text-sm font-semibold">
                  {device.name}
                </div>
              </div>
            );
          })}
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <ChevronRight
            className={`w-8 h-8 text-[#B8860B] rotate-90 ${
              animated ? "animate-bounce" : ""
            }`}
          />
        </div>

        {/* Ingestion Hub */}
        <div className="flex justify-center">
          <div className="bg-[#1A1F3A] border border-[#00D9FF]/30 rounded-xl px-8 py-4 w-96">
            <div className="flex items-center gap-3 justify-center">
              <Database className="w-6 h-6 text-[#00D9FF]" />
              <span className="text-lg font-bold text-white">
                Biometric Ingestion Hub
              </span>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <ChevronRight
            className={`w-8 h-8 text-[#B8860B] rotate-90 ${
              animated ? "animate-bounce" : ""
            }`}
          />
        </div>

        {/* Normalization */}
        <div className="flex justify-center">
          <div className="bg-[#1A1F3A] border border-[#00D9FF]/30 rounded-xl px-8 py-4 w-96">
            <div className="flex items-center gap-3 justify-center">
              <Cpu className="w-6 h-6 text-[#00D9FF]" />
              <span className="text-lg font-bold text-white">
                Signal Normalization
              </span>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <ChevronRight
            className={`w-8 h-8 text-[#B8860B] rotate-90 ${
              animated ? "animate-bounce" : ""
            }`}
          />
        </div>

        {/* Indices Row */}
        <div className="grid grid-cols-3 gap-6">
          {indices.map((index, idx) => (
            <div
              key={idx}
              className={`bg-gradient-to-br from-[#1A1F3A] to-[#0A0E27] border-2 border-[#B8860B] rounded-xl p-6 ${
                animated
                  ? "hover:shadow-lg hover:shadow-[#B8860B]/50 transition-all duration-300"
                  : ""
              }`}
            >
              <div className="text-center">
                <div className="text-3xl font-bold text-[#B8860B] mb-2">
                  {index.name}
                </div>
                <div className="text-sm text-gray-400">{index.full}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// NIL Swap Protocol Diagram
function NILSwapDiagram({ animated }) {
  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            NIL Swap Protocol Engine
          </h2>
          <p className="text-gray-400">
            How fixed and floating NIL values determine payouts
          </p>
        </div>
      </div>

      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-center">
          <div className="bg-gradient-to-r from-[#B8860B]/20 to-[#FFD700]/20 border-2 border-[#B8860B] rounded-xl px-8 py-4">
            <div className="flex items-center gap-3">
              <Repeat className="w-6 h-6 text-[#B8860B]" />
              <span className="text-xl font-bold text-white">
                NIL Swap Protocol Engine
              </span>
            </div>
          </div>
        </div>

        {/* Input Values */}
        <div className="grid grid-cols-2 gap-8">
          <div className="bg-[#1A1F3A] border-2 border-green-500/30 rounded-xl p-6">
            <div className="text-center">
              <div className="text-green-500 text-sm font-semibold mb-2">
                INPUT
              </div>
              <div className="text-2xl font-bold text-white mb-1">
                Fixed NIL Value
              </div>
              <div className="text-gray-400 text-sm">Guaranteed baseline</div>
            </div>
          </div>

          <div className="bg-[#1A1F3A] border-2 border-purple-500/30 rounded-xl p-6">
            <div className="text-center">
              <div className="text-purple-500 text-sm font-semibold mb-2">
                INPUT
              </div>
              <div className="text-2xl font-bold text-white mb-1">
                Floating NIL Value
              </div>
              <div className="text-gray-400 text-sm">Performance-based</div>
            </div>
          </div>
        </div>

        {/* Arrows converging */}
        <div className="flex justify-center items-center gap-4">
          <ChevronRight
            className={`w-8 h-8 text-green-500 rotate-90 ${
              animated ? "animate-bounce" : ""
            }`}
          />
          <ChevronRight
            className={`w-8 h-8 text-purple-500 rotate-90 ${
              animated ? "animate-bounce" : ""
            }`}
          />
        </div>

        {/* Swap Settlement */}
        <div className="flex justify-center">
          <div className="bg-gradient-to-br from-[#1A1F3A] to-[#0A0E27] border-2 border-[#B8860B] rounded-xl px-12 py-6 w-full max-w-md">
            <div className="text-center">
              <ArrowRightLeft className="w-10 h-10 text-[#B8860B] mx-auto mb-3" />
              <div className="text-2xl font-bold text-white mb-2">
                Swap Settlement
              </div>
              <div className="text-gray-400 text-sm">
                Calculate differential & execute payout
              </div>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <ChevronRight
            className={`w-8 h-8 text-[#B8860B] rotate-90 ${
              animated ? "animate-bounce" : ""
            }`}
          />
        </div>

        {/* Payout Recipients */}
        <div className="bg-[#1A1F3A] border border-[#00D9FF]/30 rounded-xl p-6">
          <div className="text-center">
            <div className="text-[#00D9FF] text-sm font-semibold mb-3">
              PAYOUT TO
            </div>
            <div className="flex items-center justify-center gap-8">
              <div className="flex items-center gap-2">
                <Users className="w-6 h-6 text-white" />
                <span className="text-white font-semibold">Team</span>
              </div>
              <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
              <div className="flex items-center gap-2">
                <Target className="w-6 h-6 text-white" />
                <span className="text-white font-semibold">Sponsor</span>
              </div>
              <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
              <div className="flex items-center gap-2">
                <Trophy className="w-6 h-6 text-white" />
                <span className="text-white font-semibold">Coalition</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// LPI Hedge Flow Diagram
function LPIHedgeDiagram({ animated }) {
  const steps = [
    { name: "League Biometrics", icon: Trophy, color: "gold" },
    { name: "LPI Computation", icon: BarChart3, color: "cyan" },
    { name: "Fixed vs Floating NIL Swap", icon: Repeat, color: "purple" },
    { name: "Conditional Payout", icon: Shield, color: "green" },
  ];

  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Index Hedge Flow (LPI)
          </h2>
          <p className="text-gray-400">
            League-level biometric hedging and coalition protection
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <div key={idx}>
              <div
                className={`bg-[#1A1F3A] border-2 border-[#B8860B]/30 rounded-xl p-6 ${
                  animated
                    ? "hover:border-[#B8860B] transition-all duration-300"
                    : ""
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-[#B8860B] rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-black" />
                  </div>
                  <div className="flex-1">
                    <div className="text-lg font-bold text-white mb-1">
                      {step.name}
                    </div>
                    {idx === 3 && (
                      <div className="text-sm text-gray-400 space-y-1">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span>
                            If LPI &lt; Floor → Coalition Receives Payout
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span>
                            If LPI ≥ Floor → Coalition Pays Small Premium
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {idx < steps.length - 1 && (
                <div className="flex justify-center my-2">
                  <ChevronRight
                    className={`w-6 h-6 text-[#B8860B] rotate-90 ${
                      animated ? "animate-bounce" : ""
                    }`}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// PPI Hedge Flow Diagram
function PPIHedgeDiagram({ animated }) {
  const steps = [
    { name: "Player Biometrics", desc: "Individual performance data" },
    { name: "PPI Calculation", desc: "Player Performance Index computed" },
    {
      name: "Player NIL Swap Contract",
      desc: "Fixed vs. floating swap established",
    },
    { name: "Conditional Payout", desc: "Trigger-based settlement" },
  ];

  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Player Hedge Flow (PPI)
          </h2>
          <p className="text-gray-400">
            Individual player performance hedging for teams and sponsors
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {steps.map((step, idx) => (
          <div key={idx}>
            <div
              className={`bg-[#1A1F3A] border-2 border-[#00D9FF]/30 rounded-xl p-6 ${
                animated
                  ? "hover:border-[#00D9FF] transition-all duration-300"
                  : ""
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#00D9FF] rounded-full flex items-center justify-center flex-shrink-0 text-black font-bold text-xl">
                  {idx + 1}
                </div>
                <div className="flex-1">
                  <div className="text-lg font-bold text-white mb-1">
                    {step.name}
                  </div>
                  <div className="text-sm text-gray-400">{step.desc}</div>

                  {idx === 3 && (
                    <div className="mt-3 space-y-1">
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-gray-300">
                          If PPI Drops → Team/Sponsor Receives Payout
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-gray-300">
                          If PPI Rises → NIL Value Appreciates
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {idx < steps.length - 1 && (
              <div className="flex justify-center my-2">
                <ChevronRight
                  className={`w-6 h-6 text-[#00D9FF] rotate-90 ${
                    animated ? "animate-bounce" : ""
                  }`}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// TPI Hedge Flow Diagram
function TPIHedgeDiagram({ animated }) {
  const steps = [
    { name: "Team Aggregate Biometrics", icon: Users },
    { name: "TPI Calculation", icon: BarChart3 },
    { name: "Team Basket NIL Swap", icon: Repeat },
    { name: "Conditional Payout", icon: Shield },
  ];

  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Team Hedge Flow (TPI)
          </h2>
          <p className="text-gray-400">
            Team-level basket hedging and collective NIL management
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <div key={idx}>
              <div
                className={`bg-[#1A1F3A] border-2 border-purple-500/30 rounded-xl p-6 ${
                  animated
                    ? "hover:border-purple-500 transition-all duration-300"
                    : ""
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-lg font-bold text-white">
                      {step.name}
                    </div>

                    {idx === 3 && (
                      <div className="mt-3 space-y-1">
                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-gray-300">
                            If TPI Declines → Hedge Pays
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-gray-300">
                            If TPI Improves → Team Gains NIL Upside
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {idx < steps.length - 1 && (
                <div className="flex justify-center my-2">
                  <ChevronRight
                    className={`w-6 h-6 text-purple-500 rotate-90 ${
                      animated ? "animate-bounce" : ""
                    }`}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Scalping Loop Diagram
function ScalpingLoopDiagram({ animated }) {
  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Scalping Loop</h2>
          <p className="text-gray-400">
            Capture micro-volatility in biometric data for short-term NIL gains
          </p>
        </div>
      </div>

      <div className="relative">
        <div className="space-y-6">
          <div className="bg-[#1A1F3A] border-2 border-[#B8860B] rounded-xl p-6">
            <div className="flex items-center gap-3">
              <Activity className="w-6 h-6 text-[#B8860B]" />
              <div>
                <div className="text-lg font-bold text-white">
                  Real-Time Biometric Feed
                </div>
                <div className="text-sm text-gray-400">
                  Continuous monitoring
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <ChevronRight className="w-6 h-6 text-[#B8860B] rotate-90" />
          </div>

          <div className="bg-[#1A1F3A] border-2 border-yellow-500/30 rounded-xl p-6">
            <div className="flex items-center gap-3">
              <Zap className="w-6 h-6 text-yellow-500" />
              <div>
                <div className="text-lg font-bold text-white">
                  Micro-Delta Detector
                </div>
                <div className="text-sm text-gray-400">
                  Identify rapid changes
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <ChevronRight className="w-6 h-6 text-yellow-500 rotate-90" />
          </div>

          <div className="bg-gradient-to-r from-red-500/20 to-yellow-500/20 border-2 border-yellow-500 rounded-xl p-6">
            <div className="text-center">
              <div className="text-sm text-yellow-500 font-semibold mb-2">
                TRIGGER CONDITIONS
              </div>
              <div className="grid grid-cols-3 gap-4 text-white text-sm">
                <div>Reaction Spike</div>
                <div>Lap Delta</div>
                <div>Fatigue Jump</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <ChevronRight className="w-6 h-6 text-yellow-500 rotate-90" />
          </div>

          <div className="bg-[#1A1F3A] border-2 border-green-500/30 rounded-xl p-6">
            <div className="flex items-center gap-3">
              <ArrowRightLeft className="w-6 h-6 text-green-500" />
              <div>
                <div className="text-lg font-bold text-white">
                  Enter Micro NIL Swap
                </div>
                <div className="text-sm text-gray-400">Capture upside</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <ChevronRight className="w-6 h-6 text-green-500 rotate-90" />
          </div>

          <div className="bg-[#1A1F3A] border-2 border-blue-500/30 rounded-xl p-6">
            <div className="flex items-center gap-3">
              <TrendingDown className="w-6 h-6 text-blue-500" />
              <div>
                <div className="text-lg font-bold text-white">
                  Exit on Reversion
                </div>
                <div className="text-sm text-gray-400">Lock in profit</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <ChevronRight className="w-6 h-6 text-[#B8860B] rotate-90" />
          </div>

          <div className="bg-gradient-to-r from-[#B8860B]/20 to-[#FFD700]/20 border-2 border-[#B8860B] rounded-xl p-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#B8860B] mb-2">
                Repeat Continuously
              </div>
              <div className="text-gray-400 text-sm">
                Automated scalping engine
              </div>
            </div>
          </div>
        </div>

        {/* Loop Arrow */}
        {animated && (
          <div className="absolute top-0 right-0 transform translate-x-16">
            <div className="w-12 border-r-4 border-[#B8860B] h-full rounded-r-full" />
          </div>
        )}
      </div>
    </div>
  );
}

// Arbitrage Loop Diagram
function ArbitrageLoopDiagram({ animated }) {
  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Arbitrage Loop</h2>
          <p className="text-gray-400">
            Identify and exploit mispricing between Model NIL and Market NIL
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Model vs Market */}
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-[#1A1F3A] border-2 border-blue-500/30 rounded-xl p-6">
            <div className="text-center">
              <div className="text-blue-500 text-sm font-semibold mb-2">
                FUNDAMENTAL VALUE
              </div>
              <div className="text-xl font-bold text-white mb-1">Model NIL</div>
              <div className="text-gray-400 text-xs">
                ← Biometrics + History
              </div>
            </div>
          </div>

          <div className="bg-[#1A1F3A] border-2 border-purple-500/30 rounded-xl p-6">
            <div className="text-center">
              <div className="text-purple-500 text-sm font-semibold mb-2">
                MARKET PRICE
              </div>
              <div className="text-xl font-bold text-white mb-1">
                Market NIL
              </div>
              <div className="text-gray-400 text-xs">
                ← Media + Hype + Demand
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <ChevronRight className="w-6 h-6 text-[#B8860B] rotate-90" />
        </div>

        <div className="bg-[#1A1F3A] border-2 border-[#B8860B]/30 rounded-xl p-6">
          <div className="text-center">
            <ArrowRightLeft className="w-8 h-8 text-[#B8860B] mx-auto mb-2" />
            <div className="text-lg font-bold text-white mb-1">
              Compare Values
            </div>
            <div className="text-sm text-gray-400">
              Detect mispricing spread
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <ChevronRight className="w-6 h-6 text-[#B8860B] rotate-90" />
        </div>

        <div className="bg-gradient-to-r from-yellow-500/20 to-red-500/20 border-2 border-yellow-500 rounded-xl p-6">
          <div className="text-center">
            <div className="text-sm text-yellow-500 font-semibold mb-2">
              ARBITRAGE OPPORTUNITY
            </div>
            <div className="text-lg font-bold text-white mb-1">
              If Mispriced → Enter Arbitrage Swap
            </div>
            <div className="text-gray-400 text-xs">
              Buy undervalued / Sell overvalued
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <ChevronRight className="w-6 h-6 text-yellow-500 rotate-90" />
        </div>

        <div className="bg-[#1A1F3A] border-2 border-green-500/30 rounded-xl p-6">
          <div className="text-center">
            <div className="text-lg font-bold text-white mb-1">
              Convergence Event
            </div>
            <div className="text-sm text-gray-400">
              Market corrects mispricing
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <ChevronRight className="w-6 h-6 text-green-500 rotate-90" />
        </div>

        <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 border-2 border-green-500 rounded-xl p-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500 mb-1">
              Exit Position
            </div>
            <div className="text-lg text-white">→ Capture Spread</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Sponsor Dashboard Diagram
function SponsorDashboardDiagram({ animated }) {
  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Sponsor Dashboard Trigger Map
          </h2>
          <p className="text-gray-400">
            Real-time alerts from biometric and NIL data streams
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Dashboard Header */}
        <div className="bg-gradient-to-r from-[#B8860B]/20 to-[#FFD700]/20 border-2 border-[#B8860B] rounded-xl px-8 py-4">
          <div className="flex items-center justify-center gap-3">
            <Bell className="w-6 h-6 text-[#B8860B]" />
            <span className="text-xl font-bold text-white">
              Sponsor Dashboard
            </span>
          </div>
        </div>

        {/* Trigger Categories */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              name: "Performance Surges",
              icon: TrendingDown,
              color: "green-500",
              desc: "+15% BIM spike",
            },
            {
              name: "NIL Value Spikes",
              icon: BarChart3,
              color: "blue-500",
              desc: "Market momentum",
            },
            {
              name: "Injury Risk Alerts",
              icon: AlertTriangle,
              color: "red-500",
              desc: "Elevated fatigue",
            },
            {
              name: "Market Volatility",
              icon: Activity,
              color: "yellow-500",
              desc: "±20% swings",
            },
          ].map((trigger, idx) => {
            const Icon = trigger.icon;
            return (
              <div
                key={idx}
                className={`bg-[#1A1F3A] border-2 border-${trigger.color}/30 rounded-xl p-4 text-center ${
                  animated
                    ? "hover:scale-105 transition-transform duration-300"
                    : ""
                }`}
              >
                <Icon
                  className={`w-8 h-8 text-${trigger.color} mx-auto mb-2`}
                />
                <div className="text-white font-semibold text-sm mb-1">
                  {trigger.name}
                </div>
                <div className="text-gray-400 text-xs">{trigger.desc}</div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-center">
          <ChevronRight className="w-6 h-6 text-[#B8860B] rotate-90" />
        </div>

        {/* Engine Layer */}
        <div className="bg-[#1A1F3A] border-2 border-[#00D9FF]/30 rounded-xl p-6">
          <div className="text-center">
            <Database className="w-8 h-8 text-[#00D9FF] mx-auto mb-2" />
            <div className="text-lg font-bold text-white">
              Biometric Index Engine
            </div>
            <div className="text-sm text-gray-400">Real-time computation</div>
          </div>
        </div>

        <div className="flex justify-center">
          <ChevronRight className="w-6 h-6 text-[#00D9FF] rotate-90" />
        </div>

        {/* Source Layer */}
        <div className="bg-[#1A1F3A] border-2 border-purple-500/30 rounded-xl p-6">
          <div className="text-center">
            <Network className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <div className="text-lg font-bold text-white">
              Wearable Mesh Pipeline
            </div>
            <div className="text-sm text-gray-400">Device data ingestion</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// PhysiobioFIN Architecture Diagram
function PhysiobioFINDiagram({ animated }) {
  const layers = [
    {
      name: "Defense Layer",
      color: "blue-500",
      items: ["Index Hedges", "Player Hedges", "Defensive Baskets"],
    },
    {
      name: "Offense Layer",
      color: "green-500",
      items: ["Scalping Engine", "Arbitrage Engine", "NIL Short Exposure"],
    },
    {
      name: "Market Intelligence",
      color: "purple-500",
      items: ["Model NIL Engine", "Market NIL Feed", "Volatility Scanner"],
    },
  ];

  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            PhysiobioFIN Full-Stack Architecture
          </h2>
          <p className="text-gray-400">
            Three-layer quantitative fund structure: Defense, Offense,
            Intelligence
          </p>
        </div>
      </div>

      <div className="space-y-8">
        {/* Fund Header */}
        <div className="bg-gradient-to-r from-[#B8860B]/20 to-[#FFD700]/20 border-2 border-[#B8860B] rounded-xl px-8 py-4">
          <div className="flex items-center justify-center gap-3">
            <Layers className="w-6 h-6 text-[#B8860B]" />
            <span className="text-xl font-bold text-white">
              PhysiobioFIN Fund
            </span>
          </div>
        </div>

        {/* Layers */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {layers.map((layer, idx) => (
            <div
              key={idx}
              className={`bg-[#1A1F3A] border-2 border-${layer.color}/30 rounded-xl p-6 ${
                animated
                  ? "hover:scale-105 transition-transform duration-300"
                  : ""
              }`}
            >
              <div
                className={`text-${layer.color} font-bold text-lg mb-4 text-center`}
              >
                {layer.name}
              </div>
              <div className="space-y-3">
                {layer.items.map((item, itemIdx) => (
                  <div
                    key={itemIdx}
                    className="bg-[#0A0E27] rounded-lg p-3 text-center"
                  >
                    <div className="text-white text-sm font-medium">{item}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Coalition Deployment Pipeline Diagram
function CoalitionPipelineDiagram({ animated }) {
  const steps = [
    { name: "Wearable Onboarding", icon: Watch, desc: "Connect devices" },
    { name: "Biometric Ingestion", icon: Database, desc: "Collect signals" },
    {
      name: "Index Computation",
      icon: BarChart3,
      desc: "Calculate PPI/TPI/LPI",
    },
    {
      name: "NIL Valuation Engine",
      icon: Target,
      desc: "Determine asset value",
    },
    {
      name: "Hedging Strategy Selection",
      icon: Shield,
      desc: "Choose protection",
    },
    {
      name: "Swap Execution + Monitoring",
      icon: Repeat,
      desc: "Execute & track",
    },
    { name: "Sponsor Dashboard Activation", icon: Bell, desc: "Enable alerts" },
    {
      name: "Continuous Coalition Oversight",
      icon: Activity,
      desc: "Ongoing governance",
    },
  ];

  return (
    <div className="bg-[#1D2B3D]/50 backdrop-blur-lg border border-[#B8860B]/20 rounded-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Coalition Deployment Pipeline
          </h2>
          <p className="text-gray-400">
            End-to-end process for launching a coalition on BIM-APES
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <div key={idx}>
              <div
                className={`bg-[#1A1F3A] border-2 border-[#B8860B]/30 rounded-xl p-4 ${
                  animated
                    ? "hover:border-[#B8860B] transition-all duration-300"
                    : ""
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-[#B8860B] rounded-full flex items-center justify-center flex-shrink-0 text-black font-bold">
                    {idx + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className="w-5 h-5 text-[#B8860B]" />
                      <div className="text-white font-bold">{step.name}</div>
                    </div>
                    <div className="text-sm text-gray-400">{step.desc}</div>
                  </div>
                </div>
              </div>

              {idx < steps.length - 1 && (
                <div className="flex justify-center my-1">
                  <ChevronRight
                    className={`w-5 h-5 text-[#B8860B] rotate-90 ${
                      animated ? "animate-bounce" : ""
                    }`}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
