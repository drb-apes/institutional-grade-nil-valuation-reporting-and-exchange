"use client";

import { useState } from "react";
import useUser from "@/utils/useUser";
import ClubBusinessDashboard from "@/components/ClubBusinessDashboard/ClubBusinessDashboard";

export default function ClubBusinessDashboardPage() {
  const { data: user, loading } = useUser();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-400 mb-4"></div>
          <p className="text-white text-lg">
            Loading Club Business Dashboard...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold text-white mb-4">
            Authentication Required
          </h2>
          <p className="text-gray-300 mb-6">
            Please sign in to access the Club Business Dashboard
          </p>
          <a
            href="/account/signin"
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return <ClubBusinessDashboard user={user} />;
}
