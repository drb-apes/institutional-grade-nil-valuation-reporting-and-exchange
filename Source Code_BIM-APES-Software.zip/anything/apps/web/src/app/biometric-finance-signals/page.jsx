"use client";

import { useBiometricFinanceSignals } from "@/hooks/useBiometricFinanceSignals";
import { PageHeader } from "@/components/BiometricFinanceSignals/PageHeader";
import { SignalTypeNavigation } from "@/components/BiometricFinanceSignals/SignalTypeNavigation";
import { SportCategorySelector } from "@/components/BiometricFinanceSignals/SportCategorySelector";
import { CompositeIndicesView } from "@/components/BiometricFinanceSignals/CompositeIndicesView";
import { CoreSignalsView } from "@/components/BiometricFinanceSignals/CoreSignalsView";
import { VolatilityAnalysisView } from "@/components/BiometricFinanceSignals/VolatilityAnalysisView";
import { SentimentTrackingView } from "@/components/BiometricFinanceSignals/SentimentTrackingView";
import { ComplianceScoringView } from "@/components/BiometricFinanceSignals/ComplianceScoringView";
import { CoalitionAlignmentView } from "@/components/BiometricFinanceSignals/CoalitionAlignmentView";
import { APESMarketView } from "@/components/BiometricFinanceSignals/APESMarketView";
import { BiometricValueIndexView } from "@/components/BiometricFinanceSignals/BiometricValueIndexView";
import { TacticalEfficiencyView } from "@/components/BiometricFinanceSignals/TacticalEfficiencyView";
import { FundingDecisionMatrixView } from "@/components/BiometricFinanceSignals/FundingDecisionMatrixView";
import { CoachingUnlocksView } from "@/components/BiometricFinanceSignals/CoachingUnlocksView";
import { CombatSportsAnalysisView } from "@/components/BiometricFinanceSignals/CombatSportsAnalysisView";
import {
  signalTypes,
  sportCategories,
  compositeIndices,
  coreSignals,
} from "@/components/BiometricFinanceSignals/constants";

export default function BiometricFinanceSignalsPage() {
  const {
    activeSignalType,
    setActiveSignalType,
    selectedSport,
    setSelectedSport,
    realTimeData,
  } = useBiometricFinanceSignals();

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1B2951] to-[#2A3B5C]">
      <PageHeader realTimeData={realTimeData} />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8 space-y-4">
          <SignalTypeNavigation
            signalTypes={signalTypes}
            activeSignalType={activeSignalType}
            onSignalTypeChange={setActiveSignalType}
          />

          <SportCategorySelector
            sportCategories={sportCategories}
            selectedSport={selectedSport}
            onSportChange={setSelectedSport}
          />
        </div>

        {/* BIM Market Core Signal Types */}
        {activeSignalType === "bvi" && (
          <BiometricValueIndexView selectedSport={selectedSport} />
        )}

        {activeSignalType === "tactical" && (
          <TacticalEfficiencyView selectedSport={selectedSport} />
        )}

        {activeSignalType === "apes" && (
          <APESMarketView selectedSport={selectedSport} />
        )}

        {activeSignalType === "funding" && (
          <FundingDecisionMatrixView selectedSport={selectedSport} />
        )}

        {activeSignalType === "coaching" && (
          <CoachingUnlocksView selectedSport={selectedSport} />
        )}

        {/* Combat Sports Analysis */}
        {activeSignalType === "combat" && (
          <CombatSportsAnalysisView selectedSport={selectedSport} />
        )}

        {/* Original Signal Types */}
        {activeSignalType === "composite" && (
          <CompositeIndicesView compositeIndices={compositeIndices} />
        )}

        {activeSignalType === "core" && (
          <CoreSignalsView coreSignals={coreSignals} />
        )}

        {activeSignalType === "volatility" && <VolatilityAnalysisView />}

        {activeSignalType === "sentiment" && <SentimentTrackingView />}

        {activeSignalType === "compliance" && <ComplianceScoringView />}

        {activeSignalType === "coalition" && <CoalitionAlignmentView />}
      </div>
    </div>
  );
}
