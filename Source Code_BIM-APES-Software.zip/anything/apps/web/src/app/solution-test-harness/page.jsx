"use client";

import { useState, useEffect } from "react";
import {
  Play,
  RotateCcw,
  CheckCircle,
  XCircle,
  Bug,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

const testCases = [
  {
    name: "Elite Basketball Player",
    athleteName: "Jordan Martinez",
    biometricScore: 92,
    sport: "basketball",
    expected: { tier: "Elite", value: "High" },
  },
  {
    name: "Developing Soccer Player",
    athleteName: "Taylor Chen",
    biometricScore: 75,
    sport: "soccer",
    expected: { tier: "Developing", value: "Medium" },
  },
  {
    name: "Wrestling Champion",
    athleteName: "Alex Thompson",
    biometricScore: 88,
    sport: "wrestling",
    expected: { tier: "Elite", value: "High" },
  },
  {
    name: "Tennis Rising Star",
    athleteName: "Casey Williams",
    biometricScore: 82,
    sport: "tennis",
    expected: { tier: "Promising", value: "Medium-High" },
  },
];

const availableFunctions = [
  {
    name: "runValuation",
    endpoint: "/api/valuation-request",
    inputs: ["athleteName", "biometricScore", "sport"],
    description: "Calculate athlete valuation based on biometric performance",
  },
  {
    name: "calculateBIMPerformance",
    endpoint: "/api/bim-performance/calculate",
    inputs: ["athleteName", "biometricScore", "sport"],
    description: "Generate BIM performance analysis and tier classification",
  },
  {
    name: "generateMotionScan",
    endpoint: "/api/motion-scans/create",
    inputs: ["athleteName", "biometricScore", "sport"],
    description: "Create motion scan analysis for athlete performance",
  },
];

export default function SolutionTestHarness() {
  const [selectedFunction, setSelectedFunction] = useState(
    availableFunctions[0],
  );
  const [selectedTestCase, setSelectedTestCase] = useState(testCases[0]);
  const [customInputs, setCustomInputs] = useState({
    athleteName: "",
    biometricScore: "",
    sport: "basketball",
  });
  const [useCustom, setUseCustom] = useState(false);
  const [results, setResults] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [debugOpen, setDebugOpen] = useState(false);

  const getCurrentInputs = () => {
    return useCustom
      ? customInputs
      : {
          athleteName: selectedTestCase.athleteName,
          biometricScore: selectedTestCase.biometricScore,
          sport: selectedTestCase.sport,
        };
  };

  const runFunctionTest = async () => {
    setIsRunning(true);
    const inputs = getCurrentInputs();

    const testResult = {
      id: Date.now(),
      function: selectedFunction.name,
      inputs: { ...inputs },
      timestamp: new Date().toLocaleTimeString(),
      status: "running",
    };

    setResults((prev) => [testResult, ...prev]);

    try {
      const response = await fetch(selectedFunction.endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inputs),
      });

      const output = await response.json();

      const success = response.ok;
      const updatedResult = {
        ...testResult,
        output,
        status: success ? "success" : "error",
        responseTime: `${Date.now() - testResult.id}ms`,
      };

      setResults((prev) =>
        prev.map((r) => (r.id === testResult.id ? updatedResult : r)),
      );
    } catch (error) {
      const updatedResult = {
        ...testResult,
        output: { error: error.message },
        status: "error",
        responseTime: `${Date.now() - testResult.id}ms`,
      };

      setResults((prev) =>
        prev.map((r) => (r.id === testResult.id ? updatedResult : r)),
      );
    }

    setIsRunning(false);
  };

  const runAllTests = async () => {
    for (const testCase of testCases) {
      setSelectedTestCase(testCase);
      setUseCustom(false);
      await new Promise((resolve) => setTimeout(resolve, 500));
      await runFunctionTest();
    }
  };

  const clearResults = () => {
    setResults([]);
  };

  const handleCustomInputChange = (field, value) => {
    setCustomInputs((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 mb-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-[#1D2B3D] mb-2">
                Coalition Function Validator
              </h1>
              <p className="text-gray-600">
                Test and validate core app functions with real-time output
                monitoring
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              <span className="text-sm text-gray-600">System Online</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Test Configuration
              </h2>

              {/* Function Selection */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Function to Test
                </label>
                <select
                  value={selectedFunction.name}
                  onChange={(e) =>
                    setSelectedFunction(
                      availableFunctions.find((f) => f.name === e.target.value),
                    )
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  {availableFunctions.map((func) => (
                    <option key={func.name} value={func.name}>
                      {func.name}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  {selectedFunction.description}
                </p>
              </div>

              {/* Input Mode Toggle */}
              <div className="mb-4">
                <div className="flex items-center space-x-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      checked={!useCustom}
                      onChange={() => setUseCustom(false)}
                      className="mr-2"
                    />
                    <span className="text-sm">Predefined Test Cases</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      checked={useCustom}
                      onChange={() => setUseCustom(true)}
                      className="mr-2"
                    />
                    <span className="text-sm">Custom Inputs</span>
                  </label>
                </div>
              </div>

              {/* Test Case Selection or Custom Inputs */}
              {!useCustom ? (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Test Case
                  </label>
                  <select
                    value={selectedTestCase.name}
                    onChange={(e) =>
                      setSelectedTestCase(
                        testCases.find((tc) => tc.name === e.target.value),
                      )
                    }
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    {testCases.map((testCase) => (
                      <option key={testCase.name} value={testCase.name}>
                        {testCase.name}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="space-y-3 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Athlete Name
                    </label>
                    <input
                      type="text"
                      value={customInputs.athleteName}
                      onChange={(e) =>
                        handleCustomInputChange("athleteName", e.target.value)
                      }
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter athlete name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Biometric Score
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={customInputs.biometricScore}
                      onChange={(e) =>
                        handleCustomInputChange(
                          "biometricScore",
                          parseInt(e.target.value) || 0,
                        )
                      }
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter score (0-100)"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Sport
                    </label>
                    <select
                      value={customInputs.sport}
                      onChange={(e) =>
                        handleCustomInputChange("sport", e.target.value)
                      }
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="basketball">Basketball</option>
                      <option value="soccer">Soccer</option>
                      <option value="wrestling">Wrestling</option>
                      <option value="tennis">Tennis</option>
                      <option value="american-football">
                        American Football
                      </option>
                      <option value="rugby">Rugby</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  onClick={runFunctionTest}
                  disabled={isRunning}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors disabled:opacity-50"
                >
                  <Play className="w-4 h-4" />
                  <span>{isRunning ? "Running..." : "Run Test"}</span>
                </button>

                <button
                  onClick={runAllTests}
                  disabled={isRunning}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors disabled:opacity-50"
                >
                  <Play className="w-4 h-4" />
                  <span>Run All Tests</span>
                </button>

                <button
                  onClick={clearResults}
                  className="w-full bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Clear Results</span>
                </button>
              </div>
            </div>

            {/* Current Inputs Preview */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">
                Current Inputs
              </h3>
              <div className="space-y-2 text-xs">
                {Object.entries(getCurrentInputs()).map(([key, value]) => (
                  <div key={key} className="flex justify-between">
                    <span className="text-gray-600">{key}:</span>
                    <span className="font-mono text-gray-900">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">
                  Test Results
                </h2>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">
                    {results.length} test{results.length !== 1 ? "s" : ""}{" "}
                    executed
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {results.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Play className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500">
                      No tests executed yet. Run a test to see results.
                    </p>
                  </div>
                ) : (
                  results.map((result) => (
                    <div
                      key={result.id}
                      className={`border rounded-lg p-4 ${
                        result.status === "success"
                          ? "border-green-200 bg-green-50"
                          : result.status === "error"
                            ? "border-red-200 bg-red-50"
                            : "border-yellow-200 bg-yellow-50"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          {result.status === "success" && (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          )}
                          {result.status === "error" && (
                            <XCircle className="w-5 h-5 text-red-600" />
                          )}
                          {result.status === "running" && (
                            <div className="w-5 h-5 border-2 border-yellow-600 border-t-transparent rounded-full animate-spin" />
                          )}
                          <span className="font-semibold text-gray-900">
                            {result.function}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 flex items-center space-x-2">
                          <span>{result.timestamp}</span>
                          {result.responseTime && (
                            <span>({result.responseTime})</span>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="font-medium text-gray-700 mb-1">
                            Inputs:
                          </div>
                          <div className="bg-gray-100 rounded p-2 font-mono text-xs">
                            {JSON.stringify(result.inputs, null, 2)}
                          </div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-700 mb-1">
                            Output:
                          </div>
                          <div className="bg-gray-100 rounded p-2 font-mono text-xs max-h-32 overflow-y-auto">
                            {JSON.stringify(result.output, null, 2)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Debug Console */}
        <div className="mt-6 bg-white rounded-xl shadow-sm border border-gray-200">
          <button
            onClick={() => setDebugOpen(!debugOpen)}
            className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center space-x-2">
              <Bug className="w-5 h-5 text-gray-600" />
              <span className="font-semibold text-gray-900">Debug Console</span>
            </div>
            {debugOpen ? (
              <ChevronUp className="w-5 h-5" />
            ) : (
              <ChevronDown className="w-5 h-5" />
            )}
          </button>

          {debugOpen && (
            <div className="border-t border-gray-200 p-4">
              <div className="bg-black rounded-lg p-4 font-mono text-green-400 text-xs max-h-64 overflow-y-auto">
                <div>[SYSTEM] Coalition Function Validator initialized</div>
                <div>
                  [INFO] Available functions: {availableFunctions.length}
                </div>
                <div>[INFO] Loaded test cases: {testCases.length}</div>
                {results.map((result) => (
                  <div key={result.id}>
                    <div>
                      [{result.timestamp}] Executing {result.function}
                    </div>
                    <div>
                      [{result.timestamp}] Status: {result.status}
                    </div>
                    {result.responseTime && (
                      <div>
                        [{result.timestamp}] Response time:{" "}
                        {result.responseTime}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
