"use client";

import { useState, useEffect } from "react";
import {
  Wallet,
  User,
  TrendingUp,
  Shield,
  Activity,
  QrCode,
  ArrowUpRight,
  ArrowDownLeft,
  Vote,
  Gift,
  Calendar,
  DollarSign,
  Target,
  Trophy,
  Users,
  Settings,
  Bell,
  CreditCard,
  Smartphone,
  MapPin,
  Clock,
  CheckCircle,
  AlertTriangle,
  Star,
  Zap,
  PieChart,
  BarChart3,
  Camera,
  Brain,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function DigitalWalletPage() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [walletData, setWalletData] = useState(null);
  const [recentActivity, setRecentActivity] = useState([]);

  // Mock wallet data - in production this would come from API
  useEffect(() => {
    setWalletData({
      balance: 180.0,
      assetScore: 72.4,
      tier: "Silver",
      tierColor: "#C0C0C0",
      insurance: {
        active: true,
        coverage: ["Injury Protection", "Equipment Coverage"],
        nextPayment: "2025-04-15",
      },
      daoVotingPower: 25,
      reinvestmentRate: 10,
    });

    setRecentActivity([
      {
        id: 1,
        type: "milestone_payout",
        description: "Milestone Hit: Clean Takedowns",
        amount: 25.0,
        date: "2 hours ago",
        status: "completed",
        icon: Target,
      },
      {
        id: 2,
        type: "dao_vote",
        description: "DAO Vote: Gear Stipend Approved",
        amount: null,
        date: "1 day ago",
        status: "completed",
        icon: Vote,
      },
      {
        id: 3,
        type: "summit_rsvp",
        description: "Summit RSVP: Queens Showcase",
        amount: -15.0,
        date: "2 days ago",
        status: "completed",
        icon: Calendar,
      },
      {
        id: 4,
        type: "auto_reinvest",
        description: "Auto-Reinvestment to Treasury",
        amount: -18.0,
        date: "3 days ago",
        status: "completed",
        icon: ArrowUpRight,
      },
    ]);
  }, []);

  const getTierColor = (tier) => {
    switch (tier) {
      case "Bronze":
        return "#CD7F32";
      case "Silver":
        return "#C0C0C0";
      case "Gold":
        return "#FFD700";
      case "Bluechip":
        return "#4169E1";
      case "Platinum":
        return "#E5E4E2";
      case "Elite":
        return "#B8860B";
      default:
        return "#C0C0C0";
    }
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case "milestone_payout":
        return Target;
      case "dao_vote":
        return Vote;
      case "summit_rsvp":
        return Calendar;
      case "auto_reinvest":
        return ArrowUpRight;
      case "purchase":
        return CreditCard;
      case "transfer":
        return ArrowDownLeft;
      default:
        return Activity;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#B8860B] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading wallet...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1D2B3D] to-[#2C3E50] text-white">
        <div className="px-6 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-[#B8860B] rounded-full flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">
                    BIM-APES Digital Wallet
                  </h1>
                  <p className="text-gray-300">
                    Motion-Backed Finance Platform
                  </p>
                </div>
              </div>
              <button className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>
            </div>

            {/* Wallet Header Card */}
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* User Info */}
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#B8860B] rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-300">Athlete</p>
                    <p className="font-semibold">{user?.name || "J. Rivera"}</p>
                    <div className="flex items-center space-x-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{
                          backgroundColor: getTierColor(walletData?.tier),
                        }}
                      ></div>
                      <span className="text-sm text-[#B8860B]">
                        {walletData?.tier} Tier
                      </span>
                    </div>
                  </div>
                </div>

                {/* Balance */}
                <div>
                  <p className="text-sm text-gray-300">Wallet Balance</p>
                  <p className="text-3xl font-bold text-[#B8860B]">
                    ${walletData?.balance?.toFixed(2) || "0.00"}
                  </p>
                </div>

                {/* Asset Score */}
                <div>
                  <p className="text-sm text-gray-300">Asset Score</p>
                  <p className="text-3xl font-bold text-green-400">
                    {walletData?.assetScore || "0.0"}
                  </p>
                </div>

                {/* Insurance Status */}
                <div>
                  <p className="text-sm text-gray-300">Insurance</p>
                  <div className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-green-400" />
                    <span className="font-semibold text-green-400">Active</span>
                  </div>
                  <p className="text-xs text-gray-400">Injury + Gear</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-8 bg-white rounded-lg p-1 border border-gray-200 shadow-sm">
          {[
            { id: "overview", label: "Overview", icon: BarChart3 },
            { id: "activity", label: "Activity", icon: Activity },
            { id: "dao", label: "DAO Governance", icon: Vote },
            { id: "spend", label: "Spend Funds", icon: CreditCard },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? "bg-[#1D2B3D] text-white"
                    : "text-gray-600 hover:text-[#1D2B3D] hover:bg-gray-50"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm mb-6">
                <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D] flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>Recent Activity</span>
                </h3>

                <div className="space-y-4">
                  {recentActivity.map((activity) => {
                    const ActivityIcon = getActivityIcon(activity.type);
                    return (
                      <div
                        key={activity.id}
                        className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg border border-gray-200"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-[#1D2B3D]/10 rounded-lg flex items-center justify-center">
                            <ActivityIcon className="w-5 h-5 text-[#1D2B3D]" />
                          </div>
                          <div>
                            <h4 className="font-medium text-[#1D2B3D]">
                              {activity.description}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {activity.date}
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          {activity.amount && (
                            <div
                              className={`font-bold ${
                                activity.amount > 0
                                  ? "text-green-600"
                                  : "text-red-600"
                              }`}
                            >
                              {activity.amount > 0 ? "+" : ""}$
                              {Math.abs(activity.amount).toFixed(2)}
                            </div>
                          )}
                          <div className="flex items-center space-x-1">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm text-green-600 capitalize">
                              {activity.status}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Performance Metrics */}
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D] flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Performance Metrics</span>
                </h3>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                    <div className="text-2xl font-bold text-[#B8860B] mb-1">
                      3
                    </div>
                    <div className="text-sm text-gray-600">Milestones Hit</div>
                  </div>
                  <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                    <div className="text-2xl font-bold text-green-600 mb-1">
                      87%
                    </div>
                    <div className="text-sm text-gray-600">Success Rate</div>
                  </div>
                  <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      25
                    </div>
                    <div className="text-sm text-gray-600">DAO Votes</div>
                  </div>
                  <div className="text-center p-4 bg-[#F5F5F0] rounded-lg">
                    <div className="text-2xl font-bold text-purple-600 mb-1">
                      12
                    </div>
                    <div className="text-sm text-gray-600">Supporters</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-4 text-[#1D2B3D] flex items-center space-x-2">
                  <Zap className="w-5 h-5" />
                  <span>Quick Actions</span>
                </h3>

                <div className="space-y-3">
                  <button className="w-full bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-4 py-3 rounded-lg flex items-center space-x-2 transition-colors">
                    <QrCode className="w-4 h-4" />
                    <span>QR Checkout</span>
                  </button>
                  <button className="w-full bg-[#B8860B] hover:bg-[#A0750A] text-white px-4 py-3 rounded-lg flex items-center space-x-2 transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                    <span>Transfer Funds</span>
                  </button>
                  <button className="w-full bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] px-4 py-3 rounded-lg flex items-center space-x-2 transition-colors">
                    <Calendar className="w-4 h-4" />
                    <span>Summit RSVP</span>
                  </button>
                  <button className="w-full bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] px-4 py-3 rounded-lg flex items-center space-x-2 transition-colors">
                    <Target className="w-4 h-4" />
                    <span>Stake Again</span>
                  </button>
                </div>
              </div>

              {/* DAO Governance Access */}
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-4 text-[#1D2B3D] flex items-center space-x-2">
                  <Vote className="w-5 h-5" />
                  <span>DAO Governance</span>
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Voting Power</span>
                    <span className="font-bold text-[#B8860B]">
                      {walletData?.daoVotingPower}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <button className="w-full text-left p-3 bg-[#F5F5F0] hover:bg-gray-200 rounded-lg transition-colors">
                      <div className="text-sm font-medium text-[#1D2B3D]">
                        Vote on athlete tiers
                      </div>
                      <div className="text-xs text-gray-600">
                        2 active proposals
                      </div>
                    </button>
                    <button className="w-full text-left p-3 bg-[#F5F5F0] hover:bg-gray-200 rounded-lg transition-colors">
                      <div className="text-sm font-medium text-[#1D2B3D]">
                        Propose milestone types
                      </div>
                      <div className="text-xs text-gray-600">
                        Submit new ideas
                      </div>
                    </button>
                    <button className="w-full text-left p-3 bg-[#F5F5F0] hover:bg-gray-200 rounded-lg transition-colors">
                      <div className="text-sm font-medium text-[#1D2B3D]">
                        Treasury audit trail
                      </div>
                      <div className="text-xs text-gray-600">
                        View all transactions
                      </div>
                    </button>
                  </div>
                </div>
              </div>

              {/* Insurance Status */}
              <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
                <h3 className="text-xl font-semibold mb-4 text-[#1D2B3D] flex items-center space-x-2">
                  <Shield className="w-5 h-5" />
                  <span>Insurance Coverage</span>
                </h3>

                <div className="space-y-3">
                  {walletData?.insurance?.coverage?.map((coverage, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-sm text-gray-700">{coverage}</span>
                    </div>
                  ))}
                  <div className="pt-3 border-t border-gray-200">
                    <p className="text-xs text-gray-600">
                      Next Payment: {walletData?.insurance?.nextPayment}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "activity" && (
          <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
              Full Activity History
            </h3>
            <div className="space-y-4">
              {recentActivity.map((activity) => {
                const ActivityIcon = getActivityIcon(activity.type);
                return (
                  <div
                    key={activity.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-[#1D2B3D]/10 rounded-lg flex items-center justify-center">
                        <ActivityIcon className="w-5 h-5 text-[#1D2B3D]" />
                      </div>
                      <div>
                        <h4 className="font-medium text-[#1D2B3D]">
                          {activity.description}
                        </h4>
                        <p className="text-sm text-gray-600">{activity.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      {activity.amount && (
                        <div
                          className={`font-bold ${
                            activity.amount > 0
                              ? "text-green-600"
                              : "text-red-600"
                          }`}
                        >
                          {activity.amount > 0 ? "+" : ""}$
                          {Math.abs(activity.amount).toFixed(2)}
                        </div>
                      )}
                      <div className="text-sm text-gray-500 capitalize">
                        {activity.status}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === "dao" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
              <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                Active Proposals
              </h3>
              <div className="space-y-4">
                <div className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-medium text-[#1D2B3D] mb-2">
                    Zone Dominance Tracking
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Add zone dominance as new milestone category for combat
                    sports
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">
                      Ends in 2 days
                    </span>
                    <button className="bg-[#B8860B] text-white px-4 py-2 rounded-lg text-sm">
                      Vote
                    </button>
                  </div>
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-medium text-[#1D2B3D] mb-2">
                    Gear Stipend Increase
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Increase monthly equipment allowance for Silver+ tier
                    athletes
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">
                      Ends in 5 days
                    </span>
                    <button className="bg-[#B8860B] text-white px-4 py-2 rounded-lg text-sm">
                      Vote
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
              <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                Your DAO Profile
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Voting Power</span>
                  <span className="font-bold text-[#B8860B]">25 votes</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Proposals Voted</span>
                  <span className="font-bold">8</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Proposals Created</span>
                  <span className="font-bold">1</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Treasury Contribution</span>
                  <span className="font-bold text-green-600">$18.00</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "spend" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
              <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                Spending Options
              </h3>
              <div className="space-y-4">
                <button className="w-full bg-[#1D2B3D] hover:bg-[#B8860B] text-white p-4 rounded-lg flex items-center space-x-3 transition-colors">
                  <QrCode className="w-6 h-6" />
                  <div className="text-left">
                    <div className="font-semibold">QR Code Checkout</div>
                    <div className="text-sm opacity-90">
                      Scan to pay at approved merchants
                    </div>
                  </div>
                </button>
                <button className="w-full bg-[#B8860B] hover:bg-[#A0750A] text-white p-4 rounded-lg flex items-center space-x-3 transition-colors">
                  <Smartphone className="w-6 h-6" />
                  <div className="text-left">
                    <div className="font-semibold">NFC Payment</div>
                    <div className="text-sm opacity-90">
                      Tap to pay with phone
                    </div>
                  </div>
                </button>
                <button className="w-full bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] p-4 rounded-lg flex items-center space-x-3 transition-colors">
                  <Calendar className="w-6 h-6" />
                  <div className="text-left">
                    <div className="font-semibold">Event RSVP</div>
                    <div className="text-sm text-gray-600">
                      Reserve spots at BIM-APES events
                    </div>
                  </div>
                </button>
                <button className="w-full bg-gray-100 hover:bg-gray-200 text-[#1D2B3D] p-4 rounded-lg flex items-center space-x-3 transition-colors">
                  <Target className="w-6 h-6" />
                  <div className="text-left">
                    <div className="font-semibold">Reinvest in Milestones</div>
                    <div className="text-sm text-gray-600">
                      Stake on your next performance goals
                    </div>
                  </div>
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
              <h3 className="text-xl font-semibold mb-6 text-[#1D2B3D]">
                Auto-Settings
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                  <div>
                    <div className="font-medium text-[#1D2B3D]">
                      Auto-Reinvestment
                    </div>
                    <div className="text-sm text-gray-600">
                      Automatically reinvest earnings
                    </div>
                  </div>
                  <div className="text-[#B8860B] font-bold">
                    {walletData?.reinvestmentRate}%
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                  <div>
                    <div className="font-medium text-[#1D2B3D]">
                      Insurance Auto-Pay
                    </div>
                    <div className="text-sm text-gray-600">
                      Monthly coverage payment
                    </div>
                  </div>
                  <div className="text-green-600 font-bold">Active</div>
                </div>
                <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                  <div>
                    <div className="font-medium text-[#1D2B3D]">
                      DAO Vote Notifications
                    </div>
                    <div className="text-sm text-gray-600">
                      Alerts for new proposals
                    </div>
                  </div>
                  <div className="text-blue-600 font-bold">Enabled</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around py-3">
          <a
            href="/"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <BarChart3 className="w-6 h-6" />
            <span className="text-xs">Home</span>
          </a>
          <a
            href="/record"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <Camera className="w-6 h-6" />
            <span className="text-xs">Record</span>
          </a>
          <a
            href="/dashboard"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <PieChart className="w-6 h-6" />
            <span className="text-xs">Dashboard</span>
          </a>
          <a
            href="/wallet"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-[#B8860B]"
          >
            <Wallet className="w-6 h-6" />
            <span className="text-xs">Wallet</span>
          </a>
          <a
            href="/settings"
            className="flex flex-col items-center space-y-1 px-4 py-2 text-gray-500 hover:text-[#1D2B3D]"
          >
            <Settings className="w-6 h-6" />
            <span className="text-xs">Settings</span>
          </a>
        </div>
      </div>
    </div>
  );
}
