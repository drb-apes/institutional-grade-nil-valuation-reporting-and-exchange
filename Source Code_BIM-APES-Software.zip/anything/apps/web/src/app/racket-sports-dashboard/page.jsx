"use client";

import { useState } from "react";
import {
  Zap,
  Award,
  Target,
  TrendingUp,
  AlertCircle,
  ChevronRight,
  Activity,
} from "lucide-react";
import useUser from "@/utils/useUser";
import Footer from "@/components/Footer";

const SPORTS = {
  tennis: {
    label: "🎾 Tennis",
    color: "#FFCC33",
    desc: "Serve · Return · Break Points",
  },
  pickleball: {
    label: "🏓 Pickleball",
    color: "#3CFF7A",
    desc: "Kitchen · Dinks · Third Shot",
  },
  badminton: {
    label: "🏸 Badminton",
    color: "#4DA6FF",
    desc: "Smash · Drop · Net Play",
  },
  table_tennis: {
    label: "🏓 Table Tennis",
    color: "#FF8C33",
    desc: "Spin · Speed · Placement",
  },
};

const DEFAULTS = {
  tennis: {
    firstServePercentage: 65,
    firstServePointsWon: 72,
    secondServePointsWon: 52,
    acesCount: 6,
    doubleFaults: 2,
    winnersCount: 28,
    unforcedErrors: 16,
    breakPointsConverted: 3,
    breakPointsTotal: 7,
    totalPoints: 85,
    pointsWon: 48,
  },
  pickleball: {
    firstServePercentage: 72,
    firstServePointsWon: 68,
    secondServePointsWon: 58,
    acesCount: 2,
    doubleFaults: 1,
    winnersCount: 22,
    unforcedErrors: 12,
    breakPointsConverted: 4,
    breakPointsTotal: 8,
    totalPoints: 70,
    pointsWon: 42,
  },
  badminton: {
    firstServePercentage: 80,
    firstServePointsWon: 75,
    secondServePointsWon: 60,
    acesCount: 1,
    doubleFaults: 0,
    winnersCount: 18,
    unforcedErrors: 10,
    breakPointsConverted: 5,
    breakPointsTotal: 9,
    totalPoints: 60,
    pointsWon: 38,
  },
  table_tennis: {
    firstServePercentage: 85,
    firstServePointsWon: 70,
    secondServePointsWon: 62,
    acesCount: 0,
    doubleFaults: 0,
    winnersCount: 30,
    unforcedErrors: 14,
    breakPointsConverted: 6,
    breakPointsTotal: 10,
    totalPoints: 80,
    pointsWon: 50,
  },
};

// ── Spike Meter ─────────────────────────────────────────────────────────────
function SpikeMeter({ value, color, size = 160 }) {
  const r = 60,
    cx = 80,
    cy = 85;
  const circ = Math.PI * r;
  const offset = circ * (1 - Math.min(100, Math.max(0, value)) / 100);
  const grade =
    value >= 85
      ? "ELITE"
      : value >= 70
        ? "ADVANCED"
        : value >= 55
          ? "SOLID"
          : "DEVELOPING";

  return (
    <div style={{ textAlign: "center" }}>
      <svg width={size * 1} height={size * 0.75} viewBox="0 0 160 120">
        <path
          d={`M 20 85 A 60 60 0 0 1 140 85`}
          fill="none"
          stroke="#1a2a4a"
          strokeWidth="14"
          strokeLinecap="round"
        />
        <path
          d={`M 20 85 A 60 60 0 0 1 140 85`}
          fill="none"
          stroke={color}
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1s ease" }}
        />
        <text
          x={cx}
          y={cy - 14}
          textAnchor="middle"
          fill={color}
          fontSize="26"
          fontWeight="900"
          fontFamily="monospace"
        >
          {value?.toFixed(0)}
        </text>
        <text x={cx} y={cy + 6} textAnchor="middle" fill="#666" fontSize="9">
          SPIKE SCORE
        </text>
        <text
          x={cx}
          y={cy + 22}
          textAnchor="middle"
          fill={color}
          fontSize="11"
          fontWeight="700"
          letterSpacing="2"
        >
          {grade}
        </text>
      </svg>
    </div>
  );
}

// ── Court Heatmap (visual only) ──────────────────────────────────────────────
function CourtVisual({ sport, metrics }) {
  const isPickleball = sport === "pickleball";
  const serveZoneOpacity = (metrics?.serve?.firstServePercentage || 65) / 100;
  const pressureZoneOpacity =
    (metrics?.pressure?.breakPointConversion || 50) / 100;

  return (
    <svg
      viewBox="0 0 220 140"
      style={{
        width: "100%",
        maxWidth: 280,
        display: "block",
        margin: "0 auto",
      }}
    >
      {/* Court outline */}
      <rect
        x="10"
        y="10"
        width="200"
        height="120"
        rx="4"
        fill="none"
        stroke="#334"
        strokeWidth="2"
      />
      <rect x="10" y="10" width="200" height="120" rx="4" fill="#0a1628" />
      {/* Court lines */}
      <line
        x1="110"
        y1="10"
        x2="110"
        y2="130"
        stroke="#1a3a6a"
        strokeWidth="1"
      />
      <line x1="10" y1="70" x2="210" y2="70" stroke="#1a3a6a" strokeWidth="1" />
      {isPickleball && (
        <>
          <rect
            x="10"
            y="10"
            width="50"
            height="120"
            fill="rgba(60,255,122,0.06)"
          />
          <rect
            x="160"
            y="10"
            width="50"
            height="120"
            fill="rgba(60,255,122,0.06)"
          />
        </>
      )}
      {/* Serve zone */}
      <rect
        x="10"
        y="10"
        width="100"
        height="60"
        rx="0"
        fill={`rgba(255,204,51,${serveZoneOpacity * 0.25})`}
      />
      <text
        x="60"
        y="44"
        textAnchor="middle"
        fill="#FFCC33"
        fontSize="9"
        opacity="0.8"
      >
        SERVE {(metrics?.serve?.firstServePercentage || 0).toFixed(0)}%
      </text>
      {/* Pressure zone */}
      <rect
        x="110"
        y="70"
        width="100"
        height="60"
        rx="0"
        fill={`rgba(255,60,60,${pressureZoneOpacity * 0.3})`}
      />
      <text
        x="160"
        y="104"
        textAnchor="middle"
        fill="#FF3C3C"
        fontSize="9"
        opacity="0.8"
      >
        BP {(metrics?.pressure?.breakPointConversion || 0).toFixed(0)}%
      </text>
      {/* Winner zone */}
      <ellipse cx="110" cy="70" rx="25" ry="18" fill={`rgba(77,166,255,0.2)`} />
      <text x="110" y="74" textAnchor="middle" fill="#4DA6FF" fontSize="8">
        NET
      </text>
    </svg>
  );
}

// ── Momentum Peak Card ───────────────────────────────────────────────────────
function MomentumCard({ peak, color }) {
  const intColors = { HIGH: "#FF3C3C", MEDIUM: "#FFD93C", LOW: "#3CFF7A" };
  const c = intColors[peak.intensity] || "#4DA6FF";
  return (
    <div
      style={{
        background: `${c}11`,
        border: `1px solid ${c}30`,
        borderRadius: 10,
        padding: "10px 14px",
        display: "flex",
        alignItems: "center",
        gap: 10,
      }}
    >
      <Zap className="w-4 h-4 flex-shrink-0" style={{ color: c }} />
      <div>
        <p className="text-white text-sm font-semibold">{peak.phase}</p>
        <p className="text-slate-400 text-xs">{peak.label}</p>
      </div>
      <span
        style={{
          marginLeft: "auto",
          background: c + "22",
          color: c,
          fontSize: 10,
          fontWeight: 700,
          padding: "2px 8px",
          borderRadius: 20,
          letterSpacing: 1,
        }}
      >
        {peak.intensity}
      </span>
    </div>
  );
}

export default function RacketSportsDashboard() {
  const { data: user, loading } = useUser();
  const [sport, setSport] = useState("tennis");
  const [athleteId, setAthleteId] = useState("1");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);
  const [matchData, setMatchData] = useState(DEFAULTS.tennis);

  const changeSport = (s) => {
    setSport(s);
    setMatchData(DEFAULTS[s]);
    setPerformanceData(null);
  };
  const upd = (f, v) =>
    setMatchData((p) => ({ ...p, [f]: parseFloat(v) || 0 }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }
    setLoadingData(true);
    setError(null);
    try {
      const res = await fetch(
        "/api/sport-specific/racket-sports/spike-analysis",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            sport,
            matchData,
          }),
        },
      );
      if (!res.ok) throw new Error(`Server error: ${res.status}`);
      setPerformanceData(await res.json());
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  const sc = SPORTS[sport];

  if (loading)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #0d0d2b, #1a0d33)" }}
      >
        <div className="text-white text-xl">
          Loading Racket Intelligence Module...
        </div>
      </div>
    );
  if (!user)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #0d0d2b, #1a0d33)" }}
      >
        <div className="text-center">
          <Zap className="w-16 h-16 text-purple-400 mx-auto mb-4" />
          <p className="text-white text-xl mb-4">
            Racket Sports Spike Analysis
          </p>
          <a
            href="/account/signin"
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold"
          >
            Sign In
          </a>
        </div>
      </div>
    );

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "linear-gradient(135deg, #0d0d2b, #1a0d33, #0d0d2b)",
      }}
    >
      {/* Header */}
      <div className="border-b border-white/10 bg-black/20 backdrop-blur-lg sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: sc.color + "22" }}
          >
            <Zap className="w-6 h-6" style={{ color: sc.color }} />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg">
              Racket Sports Spike Analysis
            </h1>
            <p className="text-xs" style={{ color: sc.color }}>
              BIM-APES · {sc.desc}
            </p>
          </div>
        </div>
      </div>

      {/* Sport Selector */}
      <div className="max-w-7xl mx-auto w-full px-4 md:px-6 pt-5 pb-0">
        <div className="flex gap-2 flex-wrap">
          {Object.entries(SPORTS).map(([key, s]) => (
            <button
              key={key}
              onClick={() => changeSport(key)}
              className="px-4 py-2 rounded-xl font-semibold text-sm transition-all"
              style={{
                background: sport === key ? s.color : "rgba(255,255,255,0.05)",
                color: sport === key ? "#000" : "#aaa",
              }}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-4 md:p-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Panel */}
          <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
            <h2 className="text-white font-bold text-base mb-4">
              Match Statistics
            </h2>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label
                  className="block text-xs uppercase tracking-wider mb-1"
                  style={{ color: sc.color }}
                >
                  Athlete ID
                </label>
                <input
                  type="number"
                  value={athleteId}
                  onChange={(e) => setAthleteId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                />
              </div>

              {[
                ["firstServePercentage", "1st Serve %"],
                ["firstServePointsWon", "1st Serve Pts Won %"],
                ["secondServePointsWon", "2nd Serve Pts Won %"],
                ["acesCount", "Aces"],
                ["doubleFaults", "Double Faults"],
                ["winnersCount", "Winners"],
                ["unforcedErrors", "Unforced Errors"],
                ["breakPointsConverted", "Break Pts Won"],
                ["breakPointsTotal", "Break Pts Total"],
                ["totalPoints", "Total Points"],
                ["pointsWon", "Points Won"],
              ].map(([f, l]) => (
                <div key={f}>
                  <label className="block text-slate-400 text-xs mb-1">
                    {l}
                  </label>
                  <input
                    type="number"
                    value={matchData[f]}
                    min="0"
                    onChange={(e) => upd(f, e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  />
                </div>
              ))}

              {error && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3">
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loadingData}
                className="w-full py-3 px-6 rounded-xl font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50"
                style={{
                  background: loadingData
                    ? "#334"
                    : `linear-gradient(135deg, ${sc.color}, ${sc.color}99)`,
                  color: "#000",
                }}
              >
                {loadingData
                  ? "⚡ Analyzing Spikes..."
                  : "⚡ Run Spike Analysis"}
              </button>
            </form>
          </div>

          {/* Results */}
          <div className="lg:col-span-2 space-y-5">
            {!performanceData ? (
              <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-12 border border-white/10 flex flex-col items-center min-h-[400px] justify-center">
                <Award
                  className="w-20 h-20 opacity-20 mb-4"
                  style={{ color: sc.color }}
                />
                <p className="text-slate-400 text-lg">Spike Analysis Ready</p>
                <p className="text-slate-500 text-sm mt-1">
                  Enter match stats to detect performance spikes and momentum
                  shifts
                </p>
              </div>
            ) : (
              <>
                {/* Spike Meter + Court */}
                <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                  <h3 className="text-white font-bold text-base mb-4">
                    Spike Intelligence Index
                  </h3>
                  <div className="flex flex-col md:flex-row gap-6 items-center justify-center">
                    <SpikeMeter
                      value={performanceData.spikeScore}
                      color={sc.color}
                    />
                    <div className="flex-1 w-full">
                      <CourtVisual sport={sport} metrics={performanceData} />
                      <p className="text-center text-slate-500 text-xs mt-1">
                        Court Performance Heatmap
                      </p>
                    </div>
                    <SpikeMeter
                      value={performanceData.consistencyScore}
                      color="#4DA6FF"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-3 mt-4">
                    {[
                      ["Spike", performanceData.spikeScore, sc.color],
                      [
                        "Consistency",
                        performanceData.consistencyScore,
                        "#4DA6FF",
                      ],
                      ["BIM Score", performanceData.bimScore, "#FFCC33"],
                    ].map(([l, v, c]) => (
                      <div key={l} className="text-center">
                        <p className="text-slate-400 text-xs uppercase tracking-wider">
                          {l}
                        </p>
                        <p
                          style={{
                            color: c,
                            fontFamily: "monospace",
                            fontSize: 20,
                            fontWeight: 900,
                          }}
                        >
                          {v?.toFixed(1)}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Serve/Return/Pressure Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Serve */}
                  <div className="bg-white/5 rounded-2xl p-4 border border-white/10">
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">
                      Serve
                    </p>
                    {[
                      [
                        "1st Serve In",
                        `${performanceData.serve?.firstServePercentage?.toFixed(1)}%`,
                      ],
                      ["Aces", performanceData.serve?.aces],
                      ["Double Faults", performanceData.serve?.doubleFaults],
                      [
                        "1st Serve Pts Won",
                        `${performanceData.serve?.firstServePointsWon?.toFixed(0)}%`,
                      ],
                    ].map(([l, v]) => (
                      <div
                        key={l}
                        className="flex justify-between py-1 border-b border-white/5"
                      >
                        <span className="text-slate-400 text-xs">{l}</span>
                        <span
                          style={{
                            color: sc.color,
                            fontFamily: "monospace",
                            fontSize: 12,
                            fontWeight: 700,
                          }}
                        >
                          {v}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Aggression */}
                  <div className="bg-white/5 rounded-2xl p-4 border border-white/10">
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">
                      Aggression
                    </p>
                    {[
                      ["Winners", performanceData.efficiency?.winners],
                      [
                        "Unforced Errors",
                        performanceData.efficiency?.unforcedErrors,
                      ],
                      [
                        "W:E Ratio",
                        performanceData.efficiency?.winnerErrorRatio?.toFixed(
                          2,
                        ),
                      ],
                      [
                        "Aggression Score",
                        `${performanceData.efficiency?.score?.toFixed(1)}`,
                      ],
                    ].map(([l, v]) => (
                      <div
                        key={l}
                        className="flex justify-between py-1 border-b border-white/5"
                      >
                        <span className="text-slate-400 text-xs">{l}</span>
                        <span
                          style={{
                            color: "#FFCC33",
                            fontFamily: "monospace",
                            fontSize: 12,
                            fontWeight: 700,
                          }}
                        >
                          {v}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Pressure */}
                  <div className="bg-white/5 rounded-2xl p-4 border border-white/10">
                    <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">
                      Pressure
                    </p>
                    {[
                      [
                        "Break Pt Conv.",
                        `${performanceData.pressure?.breakPointConversion?.toFixed(1)}%`,
                      ],
                      [
                        "Win %",
                        `${performanceData.pressure?.winPercentage?.toFixed(1)}%`,
                      ],
                      [
                        "Pressure Score",
                        `${performanceData.pressure?.score?.toFixed(1)}`,
                      ],
                      [
                        "Consistency",
                        `${performanceData.consistencyScore?.toFixed(1)}`,
                      ],
                    ].map(([l, v]) => (
                      <div
                        key={l}
                        className="flex justify-between py-1 border-b border-white/5"
                      >
                        <span className="text-slate-400 text-xs">{l}</span>
                        <span
                          style={{
                            color: "#FF3C3C",
                            fontFamily: "monospace",
                            fontSize: 12,
                            fontWeight: 700,
                          }}
                        >
                          {v}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Momentum Peaks */}
                {performanceData.momentum?.peakPeriods?.length > 0 && (
                  <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                    <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2">
                      <TrendingUp
                        className="w-5 h-5"
                        style={{ color: sc.color }}
                      />{" "}
                      Momentum Peaks Detected
                    </h3>
                    <div className="space-y-2">
                      {performanceData.momentum.peakPeriods.map((p, i) => (
                        <MomentumCard key={i} peak={p} color={sc.color} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Insights */}
                {performanceData.insights &&
                  performanceData.insights.length > 0 && (
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-yellow-400" />{" "}
                        Coaching Insights
                      </h3>
                      <div className="space-y-3">
                        {performanceData.insights.map((ins, i) => {
                          const types = {
                            strength: "#3CFF7A",
                            weakness: "#FF3C3C",
                            warning: "#FFD93C",
                          };
                          const c = types[ins.type] || "#FFD93C";
                          return (
                            <div
                              key={i}
                              style={{
                                background: `${c}0d`,
                                border: `1px solid ${c}30`,
                                borderRadius: 10,
                                padding: "12px 14px",
                              }}
                            >
                              <div className="flex items-center gap-2 mb-1">
                                <div
                                  style={{
                                    width: 8,
                                    height: 8,
                                    borderRadius: "50%",
                                    background: c,
                                  }}
                                />
                                <span
                                  style={{
                                    color: c,
                                    fontSize: 11,
                                    fontWeight: 700,
                                    textTransform: "uppercase",
                                    letterSpacing: 1,
                                  }}
                                >
                                  {ins.area}
                                </span>
                              </div>
                              <p className="text-white text-sm mb-1">
                                {ins.message}
                              </p>
                              {ins.recommendation && (
                                <p className="text-slate-400 text-xs flex items-start gap-1">
                                  <ChevronRight className="w-3 h-3 mt-0.5" />
                                  {ins.recommendation}
                                </p>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                {/* NIL Block */}
                <div
                  style={{
                    background: `linear-gradient(135deg, ${sc.color}11, rgba(77,166,255,0.08))`,
                    border: `1px solid ${sc.color}30`,
                    borderRadius: 16,
                    padding: 20,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                        NIL Market Value ({sport})
                      </p>
                      <p
                        style={{
                          color: sc.color,
                          fontSize: 26,
                          fontWeight: 900,
                          fontFamily: "monospace",
                        }}
                      >
                        ${(performanceData.bimScore * 1050).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-slate-400 text-xs mb-1">
                        Investment Signal
                      </p>
                      <p
                        style={{
                          color:
                            performanceData.bimScore >= 70
                              ? "#3CFF7A"
                              : "#FFD93C",
                          fontWeight: 900,
                          fontSize: 16,
                        }}
                      >
                        {performanceData.tier?.toUpperCase() || "COMPETITIVE"}
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
