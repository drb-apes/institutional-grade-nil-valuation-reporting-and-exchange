"use client";

import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

const SPORTS = [
  {
    id: "american_football",
    name: "American Football",
    icon: "🏈",
    color: "emerald",
  },
  { id: "basketball", name: "Basketball", icon: "🏀", color: "orange" },
  { id: "soccer", name: "Soccer", icon: "⚽", color: "green" },
  { id: "mma", name: "MMA", icon: "🥊", color: "red" },
  { id: "esports", name: "eSports", icon: "🎮", color: "purple" },
  { id: "goalwrestling", name: "Goalwrestling", icon: "🤼⚽", color: "blue" },
  { id: "baseball", name: "Baseball", icon: "⚾", color: "yellow" },
  { id: "motorcross", name: "Motorcross", icon: "🏍️", color: "zinc" },
  { id: "wrestling", name: "Wrestling", icon: "🤼", color: "amber" },
];

export default function MultiSportDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const [selectedSport, setSelectedSport] = useState("american_football");
  const [sportProfile, setSportProfile] = useState(null);
  const [liveSignals, setLiveSignals] = useState([]);
  const [athleteMetrics, setAthleteMetrics] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user && selectedSport) {
      loadSportData();
    }
  }, [user, selectedSport]);

  const loadSportData = async () => {
    setLoading(true);
    try {
      await Promise.all([loadSportProfile(), loadLiveSignals()]);
    } catch (error) {
      console.error("Load sport data error:", error);
    }
    setLoading(false);
  };

  const loadSportProfile = async () => {
    try {
      const res = await fetch(
        `/api/bim-apes/sport-metrics?sport=${selectedSport}`,
      );
      const data = await res.json();
      setSportProfile(data);
    } catch (error) {
      console.error("Load sport profile error:", error);
    }
  };

  const loadLiveSignals = async () => {
    try {
      const res = await fetch(`/api/scalping/capture?limit=20`);
      const data = await res.json();

      // Filter for current sport
      const sportSignals =
        data.moments?.filter(
          (m) => m.moment_metadata?.sport === selectedSport,
        ) || [];

      setLiveSignals(sportSignals);
    } catch (error) {
      console.error("Load signals error:", error);
    }
  };

  const calculateAthleteMetrics = async () => {
    const athleteId = 1; // Example
    const sampleMetrics = generateSampleMetrics(selectedSport);

    try {
      const res = await fetch("/api/bim-apes/sport-metrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "calculate_metrics",
          sport: selectedSport,
          athleteId,
          metrics: sampleMetrics,
        }),
      });
      const data = await res.json();
      setAthleteMetrics(data);
    } catch (error) {
      console.error("Calculate metrics error:", error);
    }
  };

  const simulateLiveEvent = async () => {
    const athleteId = 1;
    const eventData = generateSampleEvent(selectedSport);

    try {
      const res = await fetch("/api/bim-apes/sport-scalping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sport: selectedSport,
          athleteId,
          eventData,
        }),
      });
      const data = await res.json();

      if (data.success) {
        alert(
          `🎯 ${data.signalsDetected} signals detected!\n\nAction: ${data.aggregated.tradingAction}`,
        );
        loadLiveSignals();
      }
    } catch (error) {
      console.error("Simulate event error:", error);
    }
  };

  if (userLoading || !user) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  const currentSport = SPORTS.find((s) => s.id === selectedSport);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header */}
      <div className="border-b border-[#1a1a1a] bg-black">
        <div className="max-w-[1800px] mx-auto px-8 py-6">
          <h1 className="text-3xl font-bold text-white mb-2">
            Multi-Sport BIM-APES Platform
          </h1>
          <p className="text-gray-400">
            Sport-Specific Performance Analytics & Trading Signals
          </p>
        </div>
      </div>

      {/* Sport Selector */}
      <div className="max-w-[1800px] mx-auto px-8 py-6">
        <div className="flex gap-3 overflow-x-auto pb-4">
          {SPORTS.map((sport) => (
            <button
              key={sport.id}
              onClick={() => setSelectedSport(sport.id)}
              className={`px-6 py-4 rounded-xl border-2 transition-all flex-shrink-0 ${
                selectedSport === sport.id
                  ? `border-${sport.color}-500 bg-${sport.color}-900/20`
                  : "border-[#222] bg-[#111] hover:border-[#333]"
              }`}
            >
              <div className="text-3xl mb-2">{sport.icon}</div>
              <div className="text-sm font-medium text-white">{sport.name}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1800px] mx-auto px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Sport Profile Card */}
          <div className="bg-[#111] border border-[#222] rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">Sport Profile</h3>
              <div className="text-4xl">{currentSport.icon}</div>
            </div>

            {sportProfile && sportProfile.success ? (
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-400 mb-1">
                    NIL Multiplier
                  </div>
                  <div className="text-2xl font-bold text-emerald-400">
                    {sportProfile.configuration.nilMultiplier}x
                  </div>
                </div>

                <div>
                  <div className="text-sm text-gray-400 mb-2">
                    Primary Metrics
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {sportProfile.configuration.primaryMetrics.map((metric) => (
                      <span
                        key={metric}
                        className="px-2 py-1 bg-[#222] rounded text-xs text-white"
                      >
                        {metric.replace("_", " ")}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-sm text-gray-400 mb-2">
                    Scalping Triggers
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {sportProfile.configuration.scalpingTriggers.map(
                      (trigger) => (
                        <span
                          key={trigger}
                          className="px-2 py-1 bg-purple-900/30 text-purple-400 rounded text-xs"
                        >
                          {trigger.replace("_", " ")}
                        </span>
                      ),
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-gray-400 text-sm">
                Loading sport profile...
              </div>
            )}
          </div>

          {/* Quick Actions Card */}
          <div className="bg-[#111] border border-[#222] rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button
                onClick={calculateAthleteMetrics}
                className="w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-all text-left"
              >
                <div className="text-sm font-medium">Calculate Performance</div>
                <div className="text-xs text-blue-200">
                  Get NIL impact & metrics
                </div>
              </button>

              <button
                onClick={simulateLiveEvent}
                className="w-full px-4 py-3 bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-all text-left"
              >
                <div className="text-sm font-medium">Simulate Live Event</div>
                <div className="text-xs text-emerald-200">
                  Generate scalping signals
                </div>
              </button>

              <button
                onClick={loadSportData}
                className="w-full px-4 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition-all text-left"
              >
                <div className="text-sm font-medium">Refresh Data</div>
                <div className="text-xs text-purple-200">Reload sport data</div>
              </button>
            </div>
          </div>

          {/* Stats Summary */}
          <div className="bg-[#111] border border-[#222] rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Live Stats</h3>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-400 mb-1">Signals Today</div>
                <div className="text-3xl font-bold text-white">
                  {liveSignals.length}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-1">
                  Active Positions
                </div>
                <div className="text-3xl font-bold text-emerald-400">
                  {Math.floor(Math.random() * 20)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-1">Arbitrage Opps</div>
                <div className="text-3xl font-bold text-blue-400">
                  {Math.floor(Math.random() * 10)}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Athlete Metrics Results */}
        {athleteMetrics && athleteMetrics.success && (
          <div className="bg-[#111] border border-[#222] rounded-xl p-6 mb-8">
            <h3 className="text-xl font-bold text-white mb-6">
              Athlete Performance Analysis
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div>
                <div className="text-sm text-gray-400 mb-1">
                  Performance Index
                </div>
                <div className="text-2xl font-bold text-white">
                  {athleteMetrics.metrics.performanceIndex}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-1">
                  Position Multiplier
                </div>
                <div className="text-2xl font-bold text-emerald-400">
                  {athleteMetrics.metrics.positionMultiplier}x
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-1">Risk Score</div>
                <div
                  className={`text-2xl font-bold ${
                    athleteMetrics.metrics.riskScore > 70
                      ? "text-red-400"
                      : athleteMetrics.metrics.riskScore > 50
                        ? "text-yellow-400"
                        : "text-green-400"
                  }`}
                >
                  {athleteMetrics.metrics.riskScore}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-1">NIL Impact</div>
                <div className="text-2xl font-bold text-blue-400">
                  {athleteMetrics.metrics.nilImpact}
                </div>
              </div>
            </div>

            <div className="border-t border-[#222] pt-6">
              <h4 className="text-lg font-bold text-white mb-3">
                Recommendations
              </h4>
              <div className="space-y-2">
                {athleteMetrics.recommendations.map((rec, index) => (
                  <div
                    key={index}
                    className="p-3 bg-[#0a0a0a] rounded-lg text-sm text-gray-300"
                  >
                    {rec}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Live Signals Feed */}
        <div className="bg-[#111] border border-[#222] rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-white">
              Live Scalping Signals
            </h3>
            <span className="px-3 py-1 bg-emerald-900/30 text-emerald-400 rounded-full text-xs font-medium">
              {liveSignals.length} Active
            </span>
          </div>

          {liveSignals.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                No signals for {currentSport.name} yet
              </div>
              <button
                onClick={simulateLiveEvent}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-all"
              >
                Simulate Live Event
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {liveSignals.slice(0, 10).map((signal) => (
                <div
                  key={signal.id}
                  className="bg-[#0a0a0a] border border-[#222] rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className="px-3 py-1 bg-purple-900/30 text-purple-400 rounded-lg text-sm font-medium">
                        {signal.type}
                      </span>
                      <span className="text-gray-400 text-sm">
                        Athlete #{signal.athleteId}
                      </span>
                    </div>
                    <span className="text-gray-400 text-sm">
                      {new Date(signal.capturedAt).toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="grid grid-cols-4 gap-4">
                    <div>
                      <div className="text-xs text-gray-400">Intensity</div>
                      <div className="text-lg font-bold text-white">
                        {(signal.intensity * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">Spotlight</div>
                      <div className="text-lg font-bold text-emerald-400">
                        {signal.spotlightCredits}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">Event Window</div>
                      <div className="text-lg font-bold text-blue-400">
                        {signal.eventWindowCredits}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">Boost</div>
                      <div className="text-lg font-bold text-purple-400">
                        {signal.boostCredits}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Helper: Generate sample metrics for testing
function generateSampleMetrics(sport) {
  const baseMetrics = {
    position: "default",
  };

  switch (sport) {
    case "american_football":
      return {
        ...baseMetrics,
        position: "quarterback",
        completion_percentage: 65 + Math.random() * 20,
        yards_per_carry: 4 + Math.random() * 3,
        tackles: Math.floor(Math.random() * 10),
        forty_yard_dash: 4.4 + Math.random() * 0.5,
      };

    case "basketball":
      return {
        ...baseMetrics,
        position: "point_guard",
        points_per_game: 15 + Math.random() * 15,
        assists: 5 + Math.random() * 5,
        rebounds: 3 + Math.random() * 5,
        field_goal_percentage: 40 + Math.random() * 20,
      };

    case "soccer":
      return {
        ...baseMetrics,
        position: "striker",
        goals: Math.floor(Math.random() * 20),
        assists: Math.floor(Math.random() * 10),
        pass_completion: 75 + Math.random() * 15,
        distance_covered: 9000 + Math.random() * 2000,
      };

    case "mma":
      return {
        ...baseMetrics,
        position: "lightweight",
        strikes_landed: 50 + Math.random() * 100,
        takedown_accuracy: 40 + Math.random() * 40,
        submission_attempts: Math.floor(Math.random() * 5),
        fight_iq: 70 + Math.random() * 30,
      };

    case "esports":
      return {
        ...baseMetrics,
        position: "fps_player",
        kda_ratio: 1 + Math.random() * 2,
        apm: 150 + Math.random() * 150,
        accuracy: 40 + Math.random() * 40,
        game_sense: 60 + Math.random() * 40,
      };

    case "goalwrestling":
      return {
        ...baseMetrics,
        position: "all_around",
        takedown_success: 50 + Math.random() * 40,
        ball_control: 60 + Math.random() * 30,
        scoring_rate: 40 + Math.random() * 40,
        defensive_rating: 70 + Math.random() * 20,
      };

    case "baseball":
      return {
        ...baseMetrics,
        position: "pitcher",
        batting_average: 0.25 + Math.random() * 0.15,
        era: 2.5 + Math.random() * 2,
        on_base_percentage: 0.3 + Math.random() * 0.15,
        slugging: 0.4 + Math.random() * 0.2,
      };

    case "motorcross":
      return {
        ...baseMetrics,
        position: "supercross",
        lap_times: 60 + Math.random() * 10,
        jump_consistency: 70 + Math.random() * 20,
        cornering_speed: 65 + Math.random() * 25,
        starts: 70 + Math.random() * 20,
      };

    case "wrestling":
      return {
        ...baseMetrics,
        position: "middleweight",
        takedown_rate: 50 + Math.random() * 40,
        escape_percentage: 70 + Math.random() * 20,
        reversal_rate: 40 + Math.random() * 30,
        pinning_ability: 60 + Math.random() * 30,
      };

    default:
      return baseMetrics;
  }
}

// Helper: Generate sample event for testing
function generateSampleEvent(sport) {
  switch (sport) {
    case "american_football":
      return {
        touchdown: Math.random() > 0.7,
        playYards: Math.floor(Math.random() * 80),
        sack: Math.random() > 0.8,
        interception: Math.random() > 0.9,
        quarter: Math.floor(Math.random() * 4) + 1,
      };

    case "basketball":
      return {
        consecutiveMakes: Math.floor(Math.random() * 6),
        tripleDouble: Math.random() > 0.95,
        clutchShot: Math.random() > 0.85,
        timeRemaining: Math.floor(Math.random() * 120),
        scoreDifferential: Math.floor(Math.random() * 10),
      };

    case "soccer":
      return {
        goal: Math.random() > 0.8,
        assist: Math.random() > 0.7,
        cleanSheet: Math.random() > 0.6,
        minute: Math.floor(Math.random() * 90),
        position: Math.random() > 0.8 ? "goalkeeper" : "striker",
      };

    case "mma":
      return {
        knockdown: Math.random() > 0.8,
        submissionAttempt: Math.random() > 0.7,
        roundScore: Math.random() > 0.9 ? "10-8" : "10-9",
        round: Math.floor(Math.random() * 3) + 1,
      };

    case "esports":
      return {
        ace: Math.random() > 0.95,
        clutch: Math.random() > 0.8,
        mvpRound: Math.random() > 0.7,
        enemiesRemaining: Math.floor(Math.random() * 4) + 1,
        kda: (1 + Math.random() * 3).toFixed(2),
      };

    case "goalwrestling":
      return {
        goal: Math.random() > 0.7,
        defensiveStop: Math.random() > 0.6,
        momentumShift: Math.random() > 0.8,
        scoreDifferentialChange: Math.floor(Math.random() * 4),
      };

    case "baseball":
      return {
        homeRun: Math.random() > 0.9,
        strikeout: Math.random() > 0.6,
        stolenBase: Math.random() > 0.8,
        role: Math.random() > 0.5 ? "pitcher" : "batter",
        inning: Math.floor(Math.random() * 9) + 1,
      };

    case "motorcross":
      return {
        holeshot: Math.random() > 0.8,
        pass: Math.random() > 0.6,
        fastestLap: Math.random() > 0.85,
        lap: Math.floor(Math.random() * 20) + 1,
      };

    case "wrestling":
      return {
        pin: Math.random() > 0.9,
        technicalFall: Math.random() > 0.85,
        comeback: Math.random() > 0.8,
        deficitOvercome: Math.floor(Math.random() * 10),
        period: Math.floor(Math.random() * 3) + 1,
      };

    default:
      return {};
  }
}
