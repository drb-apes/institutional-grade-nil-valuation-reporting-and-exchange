"use client";

import { useState, useEffect } from "react";
import {
  Film,
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  BarChart3,
  Award,
  Camera,
  Clapperboard,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function ActingNILDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [actorData, setActorData] = useState(null);
  const [portfolioData, setPortfolioData] = useState(null);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoadingData(true);

      // Fetch actor portfolio data (simulated)
      // In production, this would call actual API endpoints
      const mockPortfolio = {
        summary: {
          totalActors: 18,
          totalProjectValue: 67800000,
          avgNILValue: 245000,
          topPerformer: "Actor A",
        },
        actors: [],
      };

      setPortfolioData(mockPortfolio);
      setActorData({ actors: [] });
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-purple-900 flex items-center justify-center">
        <div className="text-center">
          <Film className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-red-400 rounded-full opacity-100" />
            <div className="w-2 h-2 bg-red-400 rounded-full opacity-75" />
            <div className="w-2 h-2 bg-red-400 rounded-full opacity-50" />
          </div>
          <p className="text-white text-xl mt-4">
            Loading Hollywood NIL Advisory...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-purple-900">
      {/* Header */}
      <header className="border-b border-red-500/30 bg-black/40 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-red-500 to-purple-500 p-3 rounded-xl">
                <Film className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">
                  Hollywood NIL Advisory
                </h1>
                <p className="text-red-300 text-sm">
                  Acting Performance · Digital Double Valuation · Studio
                  Intelligence
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-red-300">Logged in as</p>
                <p className="text-white font-semibold">
                  {user?.name || user?.email}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="border-b border-red-500/30 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-6">
            {[
              { id: "overview", label: "Overview", icon: BarChart3 },
              { id: "actors", label: "Actor Portfolio", icon: Users },
              { id: "projects", label: "Project Analytics", icon: Calendar },
              { id: "digital", label: "Digital Assets", icon: Camera },
              {
                id: "performance",
                label: "Performance Index",
                icon: TrendingUp,
              },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-all ${
                  activeTab === tab.id
                    ? "border-red-400 text-red-400"
                    : "border-transparent text-red-300 hover:text-red-200"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && (
          <OverviewTab portfolioData={portfolioData} />
        )}
        {activeTab === "actors" && <ActorPortfolioTab actorData={actorData} />}
        {activeTab === "projects" && <ProjectAnalyticsTab />}
        {activeTab === "digital" && <DigitalAssetsTab />}
        {activeTab === "performance" && <PerformanceIndexTab />}
      </div>
    </div>
  );
}

function OverviewTab({ portfolioData }) {
  const metrics = portfolioData?.summary || {
    totalActors: 18,
    totalProjectValue: 67800000,
    avgNILValue: 245000,
    topPerformer: "Actor A",
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Actors"
          value={metrics.totalActors}
          icon={Users}
          trend="+3 this quarter"
          color="red"
        />
        <MetricCard
          title="Project Value (Projected)"
          value={`$${(metrics.totalProjectValue / 1000000).toFixed(1)}M`}
          icon={DollarSign}
          trend="+22% vs last quarter"
          color="green"
        />
        <MetricCard
          title="Avg NIL Value"
          value={`$${(metrics.avgNILValue / 1000).toFixed(0)}K`}
          icon={TrendingUp}
          trend="+15% this quarter"
          color="blue"
        />
        <MetricCard
          title="Top Performer"
          value={metrics.topPerformer}
          icon={Award}
          trend="APS: 0.94"
          color="purple"
        />
      </div>

      {/* Portfolio Performance */}
      <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-red-400" />
          Portfolio Performance Overview
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-red-300 uppercase">
              Role Distribution
            </h3>
            <RoleDistributionChart />
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-red-300 uppercase">
              Performance Scores (APS)
            </h3>
            <PerformanceScoreChart />
          </div>
        </div>
      </div>

      {/* Recent Performance Scans */}
      <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">
          Recent Performance Scans
        </h2>
        <div className="space-y-3">
          {[
            {
              actor: "Actor A",
              role: "Lead",
              aps: 0.94,
              project: "Feature Film",
              date: "3 hours ago",
            },
            {
              actor: "Actor B",
              role: "Supporting",
              aps: 0.89,
              project: "TV Series",
              date: "6 hours ago",
            },
            {
              actor: "Actor C",
              role: "Stunt",
              aps: 0.91,
              project: "Action Film",
              date: "1 day ago",
            },
          ].map((scan, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-4 bg-red-900/20 rounded-lg border border-red-500/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-purple-500 rounded-full flex items-center justify-center">
                  <Film className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">{scan.actor}</p>
                  <p className="text-sm text-red-300">
                    {scan.role} · {scan.project}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold text-lg">
                  APS {(scan.aps * 100).toFixed(0)}
                </p>
                <p className="text-sm text-red-300">{scan.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Digital Asset Highlights */}
      <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Camera className="w-5 h-5 text-red-400" />
          Digital Asset Portfolio Value
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <DigitalAssetCard
            title="AI Likeness Rights"
            value="$12.4M"
            trend="+18%"
          />
          <DigitalAssetCard
            title="Performance Capture"
            value="$9.8M"
            trend="+22%"
          />
          <DigitalAssetCard
            title="De-Aging Rights"
            value="$11.2M"
            trend="+15%"
          />
        </div>
      </div>
    </div>
  );
}

function ActorPortfolioTab({ actorData }) {
  const actors = actorData?.actors || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Actor Portfolio</h2>
        <button className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
          Add Actor
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {actors.length > 0
          ? actors.map((actor, i) => <ActorCard key={i} actor={actor} />)
          : // Placeholder data
            [
              {
                name: "Actor A",
                role: "Lead",
                aps: 0.94,
                retakeEfficiency: 0.88,
                digitalValue: 420000,
              },
              {
                name: "Actor B",
                role: "Supporting",
                aps: 0.89,
                retakeEfficiency: 0.85,
                digitalValue: 350000,
              },
              {
                name: "Actor C",
                role: "Stunt",
                aps: 0.91,
                retakeEfficiency: 0.82,
                digitalValue: 380000,
              },
            ].map((actor, i) => <ActorCard key={i} actor={actor} />)}
      </div>
    </div>
  );
}

function ProjectAnalyticsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Project Analytics & Valuations
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Active Projects
        </h3>
        <div className="space-y-4">
          {[
            {
              actor: "Actor A",
              project: "Feature Film X",
              role: "Lead",
              shootDays: 90,
              dayRate: 35000,
              status: "Active",
            },
            {
              actor: "Actor B",
              project: "TV Series Y",
              role: "Supporting",
              shootDays: 120,
              dayRate: 18000,
              status: "Active",
            },
            {
              actor: "Actor C",
              project: "Action Film Z",
              role: "Stunt",
              shootDays: 60,
              dayRate: 12000,
              status: "Planning",
            },
          ].map((project, i) => (
            <div
              key={i}
              className="p-4 bg-red-900/20 rounded-lg border border-red-500/20"
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-white font-bold">
                    {project.actor} - {project.project}
                  </p>
                  <p className="text-sm text-red-300">
                    {project.role} · {project.shootDays} shoot days
                  </p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    project.status === "Active"
                      ? "bg-green-500/20 text-green-300"
                      : "bg-yellow-500/20 text-yellow-300"
                  }`}
                >
                  {project.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-red-300">Day Rate</p>
                  <p className="text-lg font-bold text-white">
                    ${(project.dayRate / 1000).toFixed(0)}K
                  </p>
                </div>
                <div>
                  <p className="text-xs text-red-300">Total Project Value</p>
                  <p className="text-lg font-bold text-white">
                    $
                    {((project.dayRate * project.shootDays) / 1000000).toFixed(
                      1,
                    )}
                    M
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DigitalAssetsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Digital Asset Valuations
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* AI Likeness Rights */}
        <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Camera className="w-5 h-5 text-red-400" />
            AI Likeness Rights
          </h3>
          <div className="space-y-3">
            {[
              { actor: "Actor A", value: 120000, usage: "Full CGI Recreation" },
              { actor: "Actor B", value: 85000, usage: "Partial Replacement" },
              { actor: "Actor C", value: 95000, usage: "Stunt Double AI" },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-red-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.actor}</p>
                  <p className="text-sm text-red-300">{item.usage}</p>
                </div>
                <p className="text-white font-bold">
                  ${(item.value / 1000).toFixed(0)}K
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Capture */}
        <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Clapperboard className="w-5 h-5 text-red-400" />
            Performance Capture Rights
          </h3>
          <div className="space-y-3">
            {[
              { actor: "Actor A", value: 95000, usage: "Motion Capture" },
              { actor: "Actor B", value: 68000, usage: "Facial Capture" },
              { actor: "Actor C", value: 110000, usage: "Full Body + Face" },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-red-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.actor}</p>
                  <p className="text-sm text-red-300">{item.usage}</p>
                </div>
                <p className="text-white font-bold">
                  ${(item.value / 1000).toFixed(0)}K
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Voice Model Rights */}
        <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            Voice Model Licensing
          </h3>
          <div className="space-y-3">
            {[
              { actor: "Actor A", value: 72000, usage: "AI Voice Clone" },
              { actor: "Actor B", value: 55000, usage: "Dubbing Rights" },
              { actor: "Actor C", value: 48000, usage: "ADR Replacement" },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-red-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.actor}</p>
                  <p className="text-sm text-red-300">{item.usage}</p>
                </div>
                <p className="text-white font-bold">
                  ${(item.value / 1000).toFixed(0)}K
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* De-Aging Rights */}
        <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            De-Aging / Re-Aging Rights
          </h3>
          <div className="space-y-3">
            {[
              { actor: "Actor A", value: 108000, usage: "10-Year De-Aging" },
              { actor: "Actor B", value: 82000, usage: "5-Year De-Aging" },
              { actor: "Actor C", value: 65000, usage: "Age Progression" },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 bg-red-900/20 rounded-lg"
              >
                <div>
                  <p className="text-white font-semibold">{item.actor}</p>
                  <p className="text-sm text-red-300">{item.usage}</p>
                </div>
                <p className="text-white font-bold">
                  ${(item.value / 1000).toFixed(0)}K
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PerformanceIndexTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">
        Acting Performance Index (API)
      </h2>

      <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
        <p className="text-red-300 mb-6">
          The Acting Performance Index (API) tracks real-time actor performance
          across multiple metrics, including scene execution, emotional depth,
          retake efficiency, and digital asset value.
        </p>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <IndexCard title="Overall API" value="91.8" trend="+3.2" />
            <IndexCard
              title="Emotional Stamina Index"
              value="87.3"
              trend="+2.1"
            />
            <IndexCard
              title="Retake Efficiency Index"
              value="93.5"
              trend="+4.2"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <IndexCard
              title="Scene Execution Index"
              value="89.2"
              trend="+1.8"
            />
            <IndexCard
              title="Technical Proficiency"
              value="92.1"
              trend="+2.7"
            />
            <IndexCard
              title="Digital Double Value Index"
              value="88.6"
              trend="+5.3"
            />
          </div>
        </div>
      </div>

      {/* Studio Benchmarks */}
      <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Studio Performance Benchmarks
        </h3>
        <div className="space-y-3">
          {[
            {
              studio: "Warner Bros.",
              avgAPS: 0.88,
              actorCount: 42,
              trend: "+2.1%",
            },
            {
              studio: "Paramount",
              avgAPS: 0.85,
              actorCount: 38,
              trend: "+1.8%",
            },
            {
              studio: "Universal",
              avgAPS: 0.91,
              actorCount: 51,
              trend: "+3.2%",
            },
          ].map((studio, i) => (
            <div
              key={i}
              className="p-4 bg-red-900/20 rounded-lg border border-red-500/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-bold">{studio.studio}</p>
                  <p className="text-sm text-red-300">
                    {studio.actorCount} actors tracked
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-white">
                    {(studio.avgAPS * 100).toFixed(1)}
                  </p>
                  <p className="text-sm text-green-400">{studio.trend}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, color }) {
  const colorClasses = {
    red: "from-red-500 to-red-600",
    green: "from-green-500 to-green-600",
    blue: "from-blue-500 to-blue-600",
    purple: "from-purple-500 to-purple-600",
  };

  return (
    <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold text-red-300 uppercase">{title}</p>
        <div
          className={`bg-gradient-to-br ${colorClasses[color]} p-2 rounded-lg`}
        >
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className="text-3xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-green-400">{trend}</p>
    </div>
  );
}

function ActorCard({ actor }) {
  return (
    <div className="bg-black/40 backdrop-blur-lg border border-red-500/30 rounded-xl p-6 hover:border-red-400 transition-all cursor-pointer">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-purple-500 rounded-full flex items-center justify-center">
          <Film className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-lg">{actor.name}</p>
          <p className="text-sm text-red-300">{actor.role}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-red-300">Acting APS</span>
          <span className="text-white font-bold">
            {(actor.aps * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-red-300">Retake Efficiency</span>
          <span className="text-white font-bold">
            {(actor.retakeEfficiency * 100).toFixed(0)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-red-300">Digital Asset Value</span>
          <span className="text-white font-bold">
            ${(actor.digitalValue / 1000).toFixed(0)}K
          </span>
        </div>
      </div>
    </div>
  );
}

function RoleDistributionChart() {
  const roles = [
    { name: "Lead", count: 6, color: "bg-red-500" },
    { name: "Supporting", count: 5, color: "bg-purple-500" },
    { name: "Ensemble", count: 4, color: "bg-blue-500" },
    { name: "Stunt", count: 3, color: "bg-green-500" },
  ];

  return (
    <div className="space-y-3">
      {roles.map((role, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-white">{role.name}</span>
              <span className="text-sm text-red-300">{role.count} actors</span>
            </div>
            <div className="w-full bg-red-900/30 rounded-full h-2">
              <div
                className={`${role.color} h-2 rounded-full`}
                style={{ width: `${(role.count / 18) * 100}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function PerformanceScoreChart() {
  const data = [
    { label: "Elite (>90)", count: 6, color: "bg-green-500" },
    { label: "High (80-90)", count: 8, color: "bg-yellow-500" },
    { label: "Standard (<80)", count: 4, color: "bg-red-500" },
  ];

  return (
    <div className="space-y-3">
      {data.map((item, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-white">{item.label}</span>
              <span className="text-sm text-red-300">{item.count} actors</span>
            </div>
            <div className="w-full bg-red-900/30 rounded-full h-2">
              <div
                className={`${item.color} h-2 rounded-full`}
                style={{ width: `${(item.count / 18) * 100}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function IndexCard({ title, value, trend }) {
  return (
    <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4">
      <p className="text-sm text-red-300 mb-2">{title}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm text-green-400">+{trend}</p>
      </div>
    </div>
  );
}

function DigitalAssetCard({ title, value, trend }) {
  return (
    <div className="p-4 bg-red-900/20 rounded-lg border border-red-500/20">
      <p className="text-sm text-red-300 mb-2">{title}</p>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-sm text-green-400">{trend} this quarter</p>
    </div>
  );
}
