import useAuth from "@/utils/useAuth";
import { LogOut, Brain } from "lucide-react";

function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 bg-[#B8860B]/20 px-4 py-2 rounded-full border border-[#B8860B]/30 mb-6">
            <Brain className="w-5 h-5 text-[#B8860B]" />
            <span className="text-[#1D2B3D] font-medium">BIM-APES System</span>
          </div>
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-[#1D2B3D] via-[#B8860B] to-[#1D2B3D] bg-clip-text text-transparent">
            Sign Out
          </h1>
          <p className="text-gray-600">
            You're about to leave your motion finance dashboard
          </p>
        </div>

        {/* Sign Out Form */}
        <div className="bg-white backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
          <div className="text-center space-y-6">
            <div className="bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-lg p-4">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-[#B8860B] rounded-full"></div>
                <p className="text-[#B8860B] font-medium text-sm">
                  Signing out will:
                </p>
              </div>
              <ul className="text-[#1D2B3D] text-xs space-y-1">
                <li>• End your current session</li>
                <li>• Require re-authentication for dashboard access</li>
                <li>• Preserve your motion data and wallet balance</li>
              </ul>
            </div>

            <button
              onClick={handleSignOut}
              className="w-full bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] hover:from-[#B8860B] hover:to-[#1D2B3D] px-6 py-3 rounded-lg font-semibold text-white transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
            >
              <LogOut className="w-5 h-5" />
              <span>Sign Out</span>
            </button>

            <a
              href="/dashboard"
              className="block w-full bg-transparent border-2 border-[#1D2B3D]/30 hover:border-[#B8860B]/50 px-6 py-3 rounded-lg font-semibold text-[#1D2B3D] hover:text-[#B8860B] transition-all duration-300 text-center"
            >
              Cancel & Return to Dashboard
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LogoutPage;
