import { useState } from "react";
import useAuth from "@/utils/useAuth";
import { Shield, Mail, Lock, Brain, UserPlus } from "lucide-react";

function SignUpPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { signUpWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password) {
      setError("Please fill in all fields");
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters long");
      setLoading(false);
      return;
    }

    try {
      await signUpWithCredentials({
        email,
        password,
        callbackUrl: "/dashboard",
        redirect: true,
      });
    } catch (err) {
      const errorMessages = {
        OAuthSignin:
          "Couldn't start sign-up. Please try again or use a different method.",
        OAuthCallback: "Sign-up failed after redirecting. Please try again.",
        OAuthCreateAccount:
          "Couldn't create an account with this sign-up option. Try another one.",
        EmailCreateAccount:
          "This email can't be used. It may already be registered.",
        Callback: "Something went wrong during sign-up. Please try again.",
        OAuthAccountNotLinked:
          "This account is linked to a different sign-in method. Try using that instead.",
        CredentialsSignin:
          "Invalid email or password. If you already have an account, try signing in instead.",
        AccessDenied: "You don't have permission to sign up.",
        Configuration:
          "Sign-up isn't working right now. Please try again later.",
        Verification: "Your sign-up link has expired. Request a new one.",
      };

      setError(
        errorMessages[err.message] || "Something went wrong. Please try again.",
      );
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 bg-[#B8860B]/20 px-4 py-2 rounded-full border border-[#B8860B]/30 mb-6">
            <Brain className="w-5 h-5 text-[#B8860B]" />
            <span className="text-[#1D2B3D] font-medium">BIM-APES System</span>
          </div>
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-[#1D2B3D] via-[#B8860B] to-[#1D2B3D] bg-clip-text text-transparent">
            Join the Revolution
          </h1>
          <p className="text-gray-600">
            Create your account to transform motion into wealth
          </p>
        </div>

        {/* Sign Up Form */}
        <form
          onSubmit={onSubmit}
          className="bg-white backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg"
        >
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-sm font-medium text-[#1D2B3D]">
                <Mail className="w-4 h-4" />
                <span>Email</span>
              </label>
              <div className="relative">
                <input
                  required
                  name="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full bg-[#F5F5F0]/50 border border-[#1D2B3D]/30 rounded-lg px-4 py-3 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:ring-2 focus:ring-[#B8860B]/20 focus:outline-none transition-all duration-300"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-sm font-medium text-[#1D2B3D]">
                <Lock className="w-4 h-4" />
                <span>Password</span>
              </label>
              <div className="relative">
                <input
                  required
                  name="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password (min 6 chars)"
                  className="w-full bg-[#F5F5F0]/50 border border-[#1D2B3D]/30 rounded-lg px-4 py-3 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:ring-2 focus:ring-[#B8860B]/20 focus:outline-none transition-all duration-300"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-400/30 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              </div>
            )}

            <div className="bg-[#B8860B]/10 border border-[#B8860B]/30 rounded-lg p-4">
              <div className="flex items-start space-x-2">
                <Shield className="w-4 h-4 text-[#B8860B] mt-0.5" />
                <div className="text-sm text-[#1D2B3D]">
                  <p className="font-medium mb-1 text-[#B8860B]">
                    Account Benefits:
                  </p>
                  <ul className="space-y-1 text-xs">
                    <li>• Motion verification & milestone tracking</li>
                    <li>• Digital wallet with QR/NFC payments</li>
                    <li>• DAO voting rights & treasury access</li>
                    <li>• Asset simulation & earnings distribution</li>
                  </ul>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#1D2B3D] to-[#B8860B] hover:from-[#B8860B] hover:to-[#1D2B3D] disabled:opacity-50 px-6 py-3 rounded-lg font-semibold text-white transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
            >
              <UserPlus className="w-5 h-5" />
              <span>{loading ? "Creating Account..." : "Create Account"}</span>
            </button>
          </div>
        </form>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-gray-600 text-sm">
            Already have an account?{" "}
            <a
              href={`/account/signin${typeof window !== "undefined" ? window.location.search : ""}`}
              className="text-[#B8860B] hover:text-[#1D2B3D] font-medium transition-colors duration-300"
            >
              Sign in here
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default SignUpPage;
