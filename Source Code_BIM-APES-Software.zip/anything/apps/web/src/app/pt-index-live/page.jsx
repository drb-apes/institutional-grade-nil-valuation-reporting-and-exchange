"use client";

import { useState, useEffect } from "react";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Zap,
  DollarSign,
  Users,
  BarChart3,
  AlertCircle,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function PTIndexLivePage() {
  const { data: user, loading: authLoading } = useUser();
  const [selectedIndex, setSelectedIndex] = useState("pt-sprint-001");
  const [liveData, setLiveData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Simulate live PT Index data
  useEffect(() => {
    const generateLiveData = () => {
      const now = new Date();
      const gameMinute = Math.floor((now.getSeconds() % 48) + 1); // Simulate 48-minute game

      // Biometric triggers during the game
      const triggers = [];
      if (gameMinute >= 12 && gameMinute < 13) {
        triggers.push({
          type: "Sprint Burst",
          impact: "+3%",
          time: "12:00",
          speed: "18.2 mph",
        });
      }
      if (gameMinute >= 24 && gameMinute < 25) {
        triggers.push({
          type: "Acceleration Spike",
          impact: "+1%",
          time: "24:00",
          accel: "2.7 m/s²",
        });
      }
      if (gameMinute >= 46 && gameMinute < 48) {
        triggers.push({
          type: "Clutch Moment",
          impact: "+5%",
          time: "46:00",
          context: "Final 2 min",
        });
      }

      // Calculate PT token price based on triggers
      let priceMovement = 0;
      triggers.forEach((t) => {
        const impactValue = parseFloat(t.impact.replace("%", ""));
        priceMovement += impactValue;
      });

      const basePrice = 0.1;
      const currentPrice = basePrice * (1 + priceMovement / 100);

      // Fan activity
      const activeFans = 10000;
      const avgTip = 0.5;
      const fanTipVolume = activeFans * avgTip * (gameMinute / 48);

      // Trading volume (scalping + arbitrage + hedging)
      const tradingVolume = 250000 * (gameMinute / 48);

      // Revenue splits (from case study)
      const fanTipRoyalty = fanTipVolume * 0.1; // 10% sponsor royalty
      const tradingRoyalty = tradingVolume * 0.1 * 0.1; // 10% of 10% BIM take
      const tokenAppreciation = 100000 * (currentPrice - basePrice);
      const totalRevenue = fanTipRoyalty + tradingRoyalty + tokenAppreciation;

      return {
        gameMinute,
        ptPrice: currentPrice.toFixed(4),
        priceChange: priceMovement.toFixed(2),
        triggers,
        fanStats: {
          active: activeFans,
          avgTip: avgTip.toFixed(2),
          totalVolume: fanTipVolume.toFixed(2),
          royalty: fanTipRoyalty.toFixed(2),
        },
        tradingStats: {
          volume: tradingVolume.toFixed(2),
          scalping: (tradingVolume * 0.4).toFixed(2),
          arbitrage: (tradingVolume * 0.35).toFixed(2),
          hedging: (tradingVolume * 0.25).toFixed(2),
          royalty: tradingRoyalty.toFixed(2),
        },
        sponsorRevenue: {
          fanTipRoyalty: fanTipRoyalty.toFixed(2),
          tradingRoyalty: tradingRoyalty.toFixed(2),
          tokenAppreciation: tokenAppreciation.toFixed(2),
          total: totalRevenue.toFixed(2),
          seasonProjection: (totalRevenue * 82).toFixed(2),
        },
      };
    };

    const interval = setInterval(() => {
      setLiveData(generateLiveData());
      setLoading(false);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#B8860B] mb-4"></div>
          <p className="text-slate-400">Loading PT Index Live Trading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900/50 border border-slate-800 rounded-lg p-8 text-center">
          <Activity className="w-16 h-16 text-[#B8860B] mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-4">
            Sign In Required
          </h2>
          <p className="text-slate-400 mb-6">
            Access live PT Index trading and biometric-triggered price action
          </p>
          <a
            href="/account/signin"
            className="inline-block px-6 py-3 bg-[#B8860B] hover:bg-[#9A7209] text-black font-semibold rounded-lg transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (!liveData) return null;

  const priceChangePositive = parseFloat(liveData.priceChange) >= 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#B8860B]/10 to-green-600/10 border-b border-[#B8860B]/30">
        <div className="max-w-[1600px] mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Activity className="w-8 h-8 text-[#B8860B]" />
                <h1 className="text-3xl font-bold text-white">
                  PT Sprint Index • Live Trading
                </h1>
                <span className="px-3 py-1 bg-green-600/20 text-green-400 text-sm rounded-full flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  LIVE
                </span>
              </div>
              <p className="text-slate-400">
                Dashawn Bledsoe • Track & Field • Game Minute{" "}
                {liveData.gameMinute}/48
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-400">PT Token Price</div>
              <div className="flex items-center gap-2">
                <div className="text-3xl font-bold text-white">
                  ${liveData.ptPrice}
                </div>
                <div
                  className={`px-3 py-1 rounded-lg flex items-center gap-1 ${
                    priceChangePositive
                      ? "bg-green-600/20 text-green-400"
                      : "bg-red-600/20 text-red-400"
                  }`}
                >
                  {priceChangePositive ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                  {priceChangePositive ? "+" : ""}
                  {liveData.priceChange}%
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1600px] mx-auto px-4 py-6 space-y-6">
        {/* Biometric Triggers */}
        <div className="bg-gradient-to-br from-purple-600/20 to-purple-600/5 border border-purple-600/30 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-6 h-6 text-purple-400" />
            <h2 className="text-xl font-bold text-white">Biometric Triggers</h2>
            <span className="text-sm text-slate-400">
              Real-time performance events
            </span>
          </div>
          {liveData.triggers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {liveData.triggers.map((trigger, idx) => (
                <div
                  key={idx}
                  className="bg-slate-900/50 border border-purple-600/30 rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm font-semibold text-white">
                      {trigger.type}
                    </div>
                    <div className="text-lg font-bold text-green-400">
                      {trigger.impact}
                    </div>
                  </div>
                  <div className="text-xs text-slate-400">
                    {trigger.time} •{" "}
                    {
                      Object.entries(trigger).find(
                        ([k]) => !["type", "impact", "time"].includes(k),
                      )?.[1]
                    }
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              No triggers yet this game... watching for sprint bursts,
              acceleration spikes, and clutch moments
            </div>
          )}
        </div>

        {/* Revenue Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Fan Engagement */}
          <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-6 h-6 text-blue-400" />
              <h3 className="text-lg font-bold text-white">Fan Engagement</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-slate-400">Active Fans</div>
                <div className="text-2xl font-bold text-white">
                  {liveData.fanStats.active.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-sm text-slate-400">Avg Micro-Tip</div>
                <div className="text-2xl font-bold text-white">
                  ${liveData.fanStats.avgTip}
                </div>
              </div>
              <div>
                <div className="text-sm text-slate-400">Total Tip Volume</div>
                <div className="text-2xl font-bold text-blue-400">
                  ${liveData.fanStats.totalVolume}
                </div>
              </div>
              <div className="border-t border-slate-700 pt-4">
                <div className="text-sm text-slate-400">
                  Sponsor Royalty (10%)
                </div>
                <div className="text-xl font-bold text-green-400">
                  ${liveData.fanStats.royalty}
                </div>
              </div>
            </div>
          </div>

          {/* Trading Activity */}
          <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <BarChart3 className="w-6 h-6 text-purple-400" />
              <h3 className="text-lg font-bold text-white">Trading Activity</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-slate-400">Total Volume</div>
                <div className="text-2xl font-bold text-white">
                  ${liveData.tradingStats.volume}
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Scalping</span>
                  <span className="text-white">
                    ${liveData.tradingStats.scalping}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Arbitrage</span>
                  <span className="text-white">
                    ${liveData.tradingStats.arbitrage}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Hedging</span>
                  <span className="text-white">
                    ${liveData.tradingStats.hedging}
                  </span>
                </div>
              </div>
              <div className="border-t border-slate-700 pt-4">
                <div className="text-sm text-slate-400">
                  Sponsor Royalty (10% of 10%)
                </div>
                <div className="text-xl font-bold text-green-400">
                  ${liveData.tradingStats.royalty}
                </div>
              </div>
            </div>
          </div>

          {/* Sponsor Revenue */}
          <div className="bg-gradient-to-br from-[#B8860B]/20 to-[#B8860B]/5 border border-[#B8860B]/30 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <DollarSign className="w-6 h-6 text-[#B8860B]" />
              <h3 className="text-lg font-bold text-white">Sponsor Revenue</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-slate-400">Fan-Tip Royalty</div>
                <div className="text-xl font-bold text-white">
                  ${liveData.sponsorRevenue.fanTipRoyalty}
                </div>
              </div>
              <div>
                <div className="text-sm text-slate-400">Trading Royalty</div>
                <div className="text-xl font-bold text-white">
                  ${liveData.sponsorRevenue.tradingRoyalty}
                </div>
              </div>
              <div>
                <div className="text-sm text-slate-400">Token Appreciation</div>
                <div className="text-xl font-bold text-white">
                  ${liveData.sponsorRevenue.tokenAppreciation}
                </div>
              </div>
              <div className="border-t border-[#B8860B]/30 pt-4">
                <div className="text-sm text-slate-400">Game Total</div>
                <div className="text-2xl font-bold text-[#B8860B]">
                  ${liveData.sponsorRevenue.total}
                </div>
              </div>
              <div className="border-t border-[#B8860B]/30 pt-4">
                <div className="text-sm text-slate-400">
                  Season Projection (82 games)
                </div>
                <div className="text-xl font-bold text-green-400">
                  ${liveData.sponsorRevenue.seasonProjection}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Case Study Breakdown */}
        <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="w-6 h-6 text-[#B8860B]" />
            <h3 className="text-lg font-bold text-white">
              Hedge-Fund-Grade Revenue Model
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-semibold text-slate-300 mb-3">
                Revenue Streams
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">
                    • 10,000 fans × $0.50 avg tip × 10% sponsor royalty
                  </span>
                  <span className="text-white">
                    ${liveData.fanStats.royalty}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">
                    • $250K trading volume × 10% BIM × 10% sponsor
                  </span>
                  <span className="text-white">
                    ${liveData.tradingStats.royalty}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">
                    • 100,000 PT tokens × {liveData.priceChange}% price increase
                  </span>
                  <span className="text-white">
                    ${liveData.sponsorRevenue.tokenAppreciation}
                  </span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-300 mb-3">
                This Is Sports Finance, Not Marketing
              </h4>
              <div className="space-y-2 text-sm text-slate-400">
                <div>✓ Real-time biometric triggers drive price action</div>
                <div>✓ Fans and traders create hedge-fund-style liquidity</div>
                <div>✓ Sponsors earn royalties from all trading activity</div>
                <div>✓ Token appreciation provides upside participation</div>
                <div className="pt-2 text-[#B8860B]">
                  → Season revenue: ${liveData.sponsorRevenue.seasonProjection}{" "}
                  from $6M base investment
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
