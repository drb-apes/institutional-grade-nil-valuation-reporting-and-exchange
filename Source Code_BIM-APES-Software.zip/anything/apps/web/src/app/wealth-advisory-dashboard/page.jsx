"use client";

import { useState, useEffect } from "react";
import {
  DollarSign,
  TrendingUp,
  Users,
  Target,
  Shield,
  Briefcase,
  GraduationCap,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function WealthAdvisoryDashboard() {
  const { data: user, loading } = useUser();
  const [athleteId, setAthleteId] = useState("");
  const [activeTab, setActiveTab] = useState("overview");
  const [nilAccountData, setNilAccountData] = useState(null);
  const [brandProfile, setBrandProfile] = useState(null);
  const [familyOffice, setFamilyOffice] = useState(null);
  const [legacyPlanning, setLegacyPlanning] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  const loadAthleteData = async () => {
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }

    setLoadingData(true);
    setError(null);

    try {
      // Load NIL account
      const nilResponse = await fetch(
        `/api/wealth-management/nil-accounts?athleteId=${athleteId}`,
      );
      if (nilResponse.ok) {
        const nilData = await nilResponse.json();
        setNilAccountData(nilData);
      }

      // Load brand profile
      const brandResponse = await fetch(
        `/api/wealth-management/brand-profile?athleteId=${athleteId}`,
      );
      if (brandResponse.ok) {
        const brandData = await brandResponse.json();
        setBrandProfile(brandData);
      }

      // Load family office
      const familyResponse = await fetch(
        `/api/wealth-management/family-office?athleteId=${athleteId}`,
      );
      if (familyResponse.ok) {
        const familyData = await familyResponse.json();
        setFamilyOffice(familyData);
      }

      // Load legacy planning
      const legacyResponse = await fetch(
        `/api/wealth-management/legacy-planning?athleteId=${athleteId}`,
      );
      if (legacyResponse.ok) {
        const legacyData = await legacyResponse.json();
        setLegacyPlanning(legacyData);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to load athlete data");
    } finally {
      setLoadingData(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-indigo-400 underline">
            sign in
          </a>{" "}
          to access the Wealth Advisory Dashboard
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Briefcase className="w-12 h-12 text-indigo-400" />
          <div>
            <h1 className="text-4xl font-bold text-white">
              Wealth Management & Family Advisory
            </h1>
            <p className="text-indigo-200 text-lg">
              BIM-APES Comprehensive Financial Services
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Athlete Selector */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex gap-4">
            <input
              type="number"
              value={athleteId}
              onChange={(e) => setAthleteId(e.target.value)}
              placeholder="Enter Athlete ID"
              className="flex-1 px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-indigo-400 focus:outline-none"
            />
            <button
              onClick={loadAthleteData}
              disabled={loadingData}
              className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all disabled:opacity-50"
            >
              {loadingData ? "Loading..." : "Load Portfolio"}
            </button>
          </div>
          {error && (
            <div className="mt-4 bg-red-500/20 border border-red-500 rounded-lg p-3">
              <p className="text-red-200">{error}</p>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        {nilAccountData && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-2 border border-white/20">
            <div className="flex gap-2 flex-wrap">
              <TabButton
                active={activeTab === "overview"}
                onClick={() => setActiveTab("overview")}
                icon={<DollarSign className="w-4 h-4" />}
                label="Portfolio Overview"
              />
              <TabButton
                active={activeTab === "nil"}
                onClick={() => setActiveTab("nil")}
                icon={<TrendingUp className="w-4 h-4" />}
                label="NIL Account"
              />
              <TabButton
                active={activeTab === "brand"}
                onClick={() => setActiveTab("brand")}
                icon={<Target className="w-4 h-4" />}
                label="Brand Profile"
              />
              <TabButton
                active={activeTab === "family"}
                onClick={() => setActiveTab("family")}
                icon={<Users className="w-4 h-4" />}
                label="Family Office"
              />
              <TabButton
                active={activeTab === "legacy"}
                onClick={() => setActiveTab("legacy")}
                icon={<GraduationCap className="w-4 h-4" />}
                label="Legacy Planning"
              />
            </div>
          </div>
        )}

        {/* Content Area */}
        {!nilAccountData ? (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 flex flex-col items-center justify-center">
            <Briefcase className="w-20 h-20 text-indigo-400/50 mb-4" />
            <p className="text-indigo-300 text-lg">
              Enter an athlete ID to view their wealth management portfolio
            </p>
          </div>
        ) : (
          <>
            {activeTab === "overview" && (
              <OverviewTab
                data={{
                  nilAccountData,
                  brandProfile,
                  familyOffice,
                  legacyPlanning,
                }}
              />
            )}
            {activeTab === "nil" && <NILAccountTab data={nilAccountData} />}
            {activeTab === "brand" && <BrandProfileTab data={brandProfile} />}
            {activeTab === "family" && <FamilyOfficeTab data={familyOffice} />}
            {activeTab === "legacy" && (
              <LegacyPlanningTab data={legacyPlanning} />
            )}
          </>
        )}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
        active
          ? "bg-indigo-600 text-white"
          : "bg-slate-800/50 text-indigo-300 hover:bg-slate-700"
      }`}
    >
      {icon}
      <span className="hidden md:inline">{label}</span>
    </button>
  );
}

function OverviewTab({ data }) {
  const { nilAccountData, brandProfile, familyOffice, legacyPlanning } = data;
  const currentValuation = parseFloat(
    nilAccountData?.account?.current_valuation || 0,
  );
  const playerIndex = parseFloat(nilAccountData?.account?.player_index || 0);

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MetricCard
          label="NIL Valuation"
          value={`$${currentValuation.toLocaleString()}`}
          change="+12.5%"
          positive={true}
          icon={<DollarSign className="w-6 h-6 text-green-400" />}
        />
        <MetricCard
          label="Player Index"
          value={playerIndex.toFixed(1)}
          change="+5.2"
          positive={true}
          icon={<TrendingUp className="w-6 h-6 text-blue-400" />}
        />
        <MetricCard
          label="Brand Equity"
          value={brandProfile?.profile?.brand_equity_score.toFixed(1) || "0"}
          change="+8.3"
          positive={true}
          icon={<Target className="w-6 h-6 text-purple-400" />}
        />
        <MetricCard
          label="Financial Health"
          value={familyOffice?.financialHealth?.score || 0}
          change={familyOffice?.financialHealth?.rating || "N/A"}
          positive={true}
          icon={<Shield className="w-6 h-6 text-yellow-400" />}
        />
      </div>

      {/* Account Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">Account Details</h3>
          <div className="space-y-3">
            <DetailRow
              label="Account Number"
              value={nilAccountData?.account?.account_number || "N/A"}
            />
            <DetailRow
              label="Account Type"
              value={nilAccountData?.account?.account_type || "N/A"}
            />
            <DetailRow
              label="Risk Tolerance"
              value={nilAccountData?.account?.risk_tolerance || "N/A"}
            />
            <DetailRow
              label="Margin Enabled"
              value={nilAccountData?.account?.margin_enabled ? "Yes" : "No"}
            />
            <DetailRow
              label="Account Status"
              value={nilAccountData?.account?.account_status || "N/A"}
            />
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">
            Recent Adjustments
          </h3>
          {nilAccountData?.contractAdjustments &&
          nilAccountData.contractAdjustments.length > 0 ? (
            <div className="space-y-2 max-h-[200px] overflow-y-auto">
              {nilAccountData.contractAdjustments
                .slice(0, 5)
                .map((adj, idx) => (
                  <div
                    key={idx}
                    className="flex justify-between items-center py-2 border-b border-slate-600 last:border-0"
                  >
                    <span className="text-indigo-300 text-sm capitalize">
                      {adj.adjustment_type.replace(/_/g, " ")}
                    </span>
                    <span
                      className={`text-sm font-semibold ${parseFloat(adj.adjustment_amount) >= 0 ? "text-green-400" : "text-red-400"}`}
                    >
                      {parseFloat(adj.adjustment_amount) >= 0 ? "+" : ""}$
                      {parseFloat(adj.adjustment_amount).toLocaleString()}
                    </span>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-indigo-300 text-sm">No adjustments recorded</p>
          )}
        </div>
      </div>

      {/* Chart: Player Index History */}
      {nilAccountData?.indexHistory &&
        nilAccountData.indexHistory.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">
              Player Index Trend (30 Days)
            </h3>
            <div className="h-64 flex items-end gap-1">
              {nilAccountData.indexHistory
                .slice(0, 30)
                .reverse()
                .map((point, idx) => {
                  const height = (parseFloat(point.index_value) / 100) * 100;
                  return (
                    <div
                      key={idx}
                      className="flex-1 bg-gradient-to-t from-indigo-600 to-purple-600 rounded-t transition-all hover:opacity-80"
                      style={{ height: `${height}%` }}
                      title={`${parseFloat(point.index_value).toFixed(1)}`}
                    />
                  );
                })}
            </div>
          </div>
        )}
    </div>
  );
}

function NILAccountTab({ data }) {
  const account = data?.account;
  const marginAccount = data?.marginAccount;

  if (!account) {
    return <div className="text-white">No NIL account data available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Valuation Summary */}
      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 backdrop-blur-lg rounded-xl p-8 border border-green-400/30">
        <h3 className="text-2xl font-bold text-white mb-6">
          NIL Valuation Summary
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <p className="text-green-200 text-sm mb-2">Current Valuation</p>
            <p className="text-4xl font-bold text-white">
              ${parseFloat(account.current_valuation).toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-green-200 text-sm mb-2">Player Index</p>
            <p className="text-4xl font-bold text-green-400">
              {parseFloat(account.player_index).toFixed(1)}
            </p>
          </div>
          <div>
            <p className="text-green-200 text-sm mb-2">Account Type</p>
            <p className="text-2xl font-bold text-white capitalize">
              {account.account_type.replace("_", " ")}
            </p>
          </div>
        </div>
      </div>

      {/* Margin Account */}
      {marginAccount && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Shield className="w-6 h-6 text-yellow-400" />
            Margin Account
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-indigo-300 text-sm mb-1">Available Margin</p>
              <p className="text-xl font-bold text-white">
                ${parseFloat(marginAccount.available_margin).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-indigo-300 text-sm mb-1">Utilized</p>
              <p className="text-xl font-bold text-yellow-400">
                ${parseFloat(marginAccount.utilized_margin).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-indigo-300 text-sm mb-1">Max Leverage</p>
              <p className="text-xl font-bold text-white">
                {parseFloat(marginAccount.max_leverage).toFixed(1)}x
              </p>
            </div>
            <div>
              <p className="text-indigo-300 text-sm mb-1">Margin Rate</p>
              <p className="text-xl font-bold text-white">
                {(parseFloat(marginAccount.margin_rate) * 100).toFixed(2)}%
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Contract Adjustments */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-4">
          Contract Adjustment History
        </h3>
        {data?.contractAdjustments && data.contractAdjustments.length > 0 ? (
          <div className="space-y-2">
            {data.contractAdjustments.map((adj, idx) => (
              <div
                key={idx}
                className="flex justify-between items-center p-4 bg-slate-800/50 rounded-lg border border-slate-600"
              >
                <div>
                  <p className="text-white font-medium capitalize">
                    {adj.adjustment_type.replace(/_/g, " ")}
                  </p>
                  <p className="text-indigo-300 text-sm">
                    {adj.adjustment_reason || "No reason provided"}
                  </p>
                  <p className="text-slate-400 text-xs mt-1">
                    {new Date(adj.adjustment_date).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <p
                    className={`text-2xl font-bold ${parseFloat(adj.adjustment_amount) >= 0 ? "text-green-400" : "text-red-400"}`}
                  >
                    {parseFloat(adj.adjustment_amount) >= 0 ? "+" : ""}$
                    {parseFloat(adj.adjustment_amount).toLocaleString()}
                  </p>
                  <p className="text-slate-400 text-xs">
                    {parseFloat(adj.previous_valuation).toLocaleString()} →{" "}
                    {parseFloat(adj.new_valuation).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-indigo-300">No adjustments recorded</p>
        )}
      </div>
    </div>
  );
}

function BrandProfileTab({ data }) {
  const profile = data?.profile;

  if (!profile) {
    return <div className="text-white">No brand profile data available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Brand Scores */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        <ScoreCard
          label="Brand Equity"
          score={parseFloat(profile.brand_equity_score)}
          color="purple"
        />
        <ScoreCard
          label="Fan Sentiment"
          score={parseFloat(profile.fan_sentiment_score)}
          color="blue"
        />
        <ScoreCard
          label="Sponsorship Potential"
          score={parseFloat(profile.sponsorship_potential)}
          color="green"
        />
        <ScoreCard
          label="Authenticity Index"
          score={parseFloat(profile.authenticity_index)}
          color="yellow"
        />
        <ScoreCard
          label="Social Reach"
          score={Math.min(100, parseInt(profile.social_reach) / 10000)}
          color="pink"
        />
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <p className="text-indigo-300 text-sm mb-2">Market Positioning</p>
          <p className="text-3xl font-bold text-white capitalize">
            {profile.market_positioning}
          </p>
        </div>
      </div>

      {/* Recommendations */}
      {data?.sponsorshipRecommendations &&
        data.sponsorshipRecommendations.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <h3 className="text-xl font-bold text-white mb-4">
              Sponsorship Recommendations
            </h3>
            <div className="space-y-4">
              {data.sponsorshipRecommendations.map((rec, idx) => (
                <div
                  key={idx}
                  className="bg-slate-800/50 rounded-lg p-4 border border-slate-600"
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-lg font-semibold text-white">
                      {rec.tier} Tier
                    </span>
                    <span className="text-green-400 font-semibold">
                      {rec.estimatedValue}
                    </span>
                  </div>
                  <p className="text-indigo-300 text-sm mb-2">
                    Target Brands: {rec.brands.join(", ")}
                  </p>
                  <p className="text-slate-400 text-xs">{rec.requirements}</p>
                </div>
              ))}
            </div>
          </div>
        )}
    </div>
  );
}

function FamilyOfficeTab({ data }) {
  const profile = data?.profile;
  const financialHealth = data?.financialHealth;

  if (!profile) {
    return <div className="text-white">No family office data available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Financial Health Score */}
      <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 backdrop-blur-lg rounded-xl p-8 border border-yellow-400/30">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-2xl font-bold text-white">
            Financial Health Score
          </h3>
          <span className="text-5xl font-bold text-yellow-400">
            {financialHealth?.score || 0}
          </span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-yellow-400 to-orange-400 h-3 rounded-full transition-all duration-500"
            style={{ width: `${financialHealth?.score || 0}%` }}
          />
        </div>
        <p className="text-yellow-300 mt-3">
          Rating:{" "}
          <span className="font-bold">{financialHealth?.rating || "N/A"}</span>
        </p>
      </div>

      {/* Profile Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-lg font-semibold text-white mb-4">
            Family Information
          </h4>
          <div className="space-y-3">
            <DetailRow label="Family Size" value={profile.family_size} />
            <DetailRow
              label="Annual Income"
              value={`$${parseFloat(profile.annual_income).toLocaleString()}`}
            />
            <DetailRow
              label="Net Worth"
              value={`$${parseFloat(profile.current_net_worth).toLocaleString()}`}
            />
            <DetailRow
              label="Tax Jurisdiction"
              value={profile.tax_jurisdiction}
            />
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-lg font-semibold text-white mb-4">
            Planning Status
          </h4>
          <div className="space-y-3">
            <StatusRow
              label="Tax Strategy"
              active={
                profile.tax_strategy &&
                Object.keys(profile.tax_strategy).length > 0
              }
            />
            <StatusRow
              label="Estate Plan"
              active={
                profile.estate_plan &&
                Object.keys(profile.estate_plan).length > 0
              }
            />
            <StatusRow
              label="Philanthropic Plan"
              active={
                profile.philanthropic_plan &&
                Object.keys(profile.philanthropic_plan).length > 0
              }
            />
            <StatusRow
              label="Profile Status"
              active={profile.profile_status === "active"}
            />
          </div>
        </div>
      </div>

      {/* Action Items */}
      {data?.actionItems && data.actionItems.length > 0 && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-lg font-semibold text-white mb-4">
            Recommended Actions
          </h4>
          <div className="space-y-3">
            {data.actionItems.map((item, idx) => (
              <div
                key={idx}
                className={`rounded-lg p-4 border ${
                  item.priority === "high"
                    ? "bg-red-500/10 border-red-500/30"
                    : item.priority === "medium"
                      ? "bg-yellow-500/10 border-yellow-500/30"
                      : "bg-blue-500/10 border-blue-500/30"
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-white font-medium">{item.action}</span>
                  <span className="text-xs px-2 py-1 bg-slate-700 rounded-full text-white uppercase">
                    {item.priority}
                  </span>
                </div>
                <p className="text-indigo-300 text-sm">
                  Timeline: {item.timeline}
                </p>
                <p className="text-slate-400 text-xs mt-1">
                  Impact: {item.impact}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function LegacyPlanningTab({ data }) {
  const profile = data?.profile;

  if (!profile) {
    return <div className="text-white">No legacy planning data available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Career Timeline */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-4">
          Career Transition Timeline
        </h3>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-32 text-indigo-300 font-medium">Current Age</div>
            <div className="flex-1 text-white text-xl font-bold">
              {profile.current_age}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-32 text-indigo-300 font-medium">Career Stage</div>
            <div className="flex-1 text-white text-xl font-bold capitalize">
              {profile.career_stage.replace(/_/g, " ")}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-32 text-indigo-300 font-medium">
              Retirement Age
            </div>
            <div className="flex-1 text-white text-xl font-bold">
              {profile.estimated_retirement_age}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-32 text-indigo-300 font-medium">
              Years Remaining
            </div>
            <div className="flex-1 text-white text-xl font-bold">
              {profile.years_to_retirement} years
            </div>
          </div>
        </div>
        <div className="mt-6 w-full bg-slate-700 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-indigo-400 to-purple-400 h-3 rounded-full transition-all duration-500"
            style={{
              width: `${Math.min(100, ((profile.estimated_retirement_age - profile.current_age - profile.years_to_retirement) / (profile.estimated_retirement_age - profile.current_age)) * 100)}%`,
            }}
          />
        </div>
      </div>

      {/* Transition Readiness */}
      {data?.readinessScore !== undefined && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-lg font-semibold text-white mb-4">
            Transition Readiness Score
          </h4>
          <div className="flex items-center gap-6">
            <div className="text-6xl font-bold text-indigo-400">
              {data.readinessScore}
            </div>
            <div className="flex-1">
              <div className="w-full bg-slate-700 rounded-full h-4">
                <div
                  className="bg-gradient-to-r from-indigo-400 to-purple-400 h-4 rounded-full transition-all duration-500"
                  style={{ width: `${data.readinessScore}%` }}
                />
              </div>
              <p className="text-indigo-300 mt-2">
                {data.readinessScore >= 70
                  ? "Well Prepared"
                  : data.readinessScore >= 40
                    ? "Developing"
                    : "Needs Attention"}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Next Steps */}
      {data?.nextSteps && data.nextSteps.length > 0 && (
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-lg font-semibold text-white mb-4">
            Recommended Next Steps
          </h4>
          <div className="space-y-3">
            {data.nextSteps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-start gap-4 p-4 bg-slate-800/50 rounded-lg border border-slate-600"
              >
                <div
                  className={`w-2 h-2 rounded-full mt-2 ${
                    step.priority === "high"
                      ? "bg-red-400"
                      : step.priority === "medium"
                        ? "bg-yellow-400"
                        : "bg-blue-400"
                  }`}
                />
                <div className="flex-1">
                  <p className="text-white font-medium">{step.action}</p>
                  <p className="text-indigo-300 text-sm">
                    Timeline: {step.timeline}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MetricCard({ label, value, change, positive, icon }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-3">
        {icon}
        <span className="text-indigo-300 text-sm font-medium">{label}</span>
      </div>
      <div className="text-3xl font-bold text-white mb-2">{value}</div>
      <div
        className={`text-sm font-medium ${positive ? "text-green-400" : "text-red-400"}`}
      >
        {change}
      </div>
    </div>
  );
}

function ScoreCard({ label, score, color }) {
  const colorClasses = {
    purple: "from-purple-400 to-pink-400 border-purple-400/30",
    blue: "from-blue-400 to-cyan-400 border-blue-400/30",
    green: "from-green-400 to-emerald-400 border-green-400/30",
    yellow: "from-yellow-400 to-orange-400 border-yellow-400/30",
    pink: "from-pink-400 to-purple-400 border-pink-400/30",
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <p className="text-indigo-300 text-sm mb-3">{label}</p>
      <div className="flex items-center justify-between mb-3">
        <span className="text-3xl font-bold text-white">
          {score.toFixed(1)}
        </span>
        <span className="text-indigo-400">/100</span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className={`bg-gradient-to-r ${colorClasses[color]} h-2 rounded-full transition-all duration-500`}
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}

function DetailRow({ label, value }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-indigo-300 text-sm">{label}</span>
      <span className="text-white font-semibold">{value}</span>
    </div>
  );
}

function StatusRow({ label, active }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-indigo-300 text-sm">{label}</span>
      <div className="flex items-center gap-2">
        <div
          className={`w-2 h-2 rounded-full ${active ? "bg-green-400" : "bg-red-400"}`}
        />
        <span className="text-white text-sm font-semibold">
          {active ? "Active" : "Pending"}
        </span>
      </div>
    </div>
  );
}
