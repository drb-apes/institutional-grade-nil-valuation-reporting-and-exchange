import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const timeframe = parseInt(url.searchParams.get("timeframe") || "30");

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const profile = userProfile[0];

    // **FETCH COMPREHENSIVE DASHBOARD DATA**
    const dashboardData = await generateAthleteMetrics(profile.id, timeframe);

    return Response.json({
      success: true,
      athlete_id: profile.id,
      timeframe_days: timeframe,
      ...dashboardData,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Athlete dashboard metrics error:", error);
    return Response.json(
      {
        error: "Failed to fetch athlete dashboard metrics",
      },
      { status: 500 },
    );
  }
}

// **🏆 COMPREHENSIVE ATHLETE METRICS GENERATOR**
async function generateAthleteMetrics(athleteId, timeframeDays) {
  // Fetch all required data in parallel
  const [
    performanceHistory,
    motionScans,
    milestones,
    contributions,
    wallet,
    userProfile,
  ] = await sql.transaction([
    sql`
      SELECT * FROM asset_simulations 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY created_at ASC
    `,
    sql`
      SELECT * FROM motion_scans 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY created_at ASC
    `,
    sql`
      SELECT * FROM milestones 
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 10
    `,
    sql`
      SELECT c.*, cp.milestone_id 
      FROM contributions c
      JOIN contribution_pools cp ON c.pool_id = cp.id
      JOIN milestones m ON cp.milestone_id = m.id
      WHERE m.athlete_id = ${athleteId}
      AND c.created_at >= NOW() - INTERVAL '${timeframeDays} days'
    `,
    sql`
      SELECT * FROM digital_wallets 
      WHERE user_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 1
    `,
    sql`
      SELECT up.*, au.name, au.email 
      FROM user_profiles up 
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId}
    `,
  ]);

  const athlete = userProfile[0];

  return {
    // **1. PERFORMANCE METRICS (BVI, Tactical, Recovery, Spike, Consistency)**
    performance_metrics: generatePerformanceMetrics(
      performanceHistory,
      motionScans,
    ),

    // **2. TIER STATUS VISUALIZATION**
    tier_status: generateTierStatus(athlete, performanceHistory),

    // **3. PROGRESSION TRACKING**
    progression_tracking: generateProgressionTracking(
      performanceHistory,
      timeframeDays,
    ),

    // **4. COACHING INSIGHTS & CROSS-CORRELATIONS**
    coaching_insights: generateCoachingInsights(
      performanceHistory,
      motionScans,
      athlete,
    ),

    // **5. RECENT ACTIVITY**
    recent_activity: generateRecentActivity(
      performanceHistory,
      milestones,
      contributions,
    ),

    // **6. PERFORMANCE ALERTS**
    alerts: generatePerformanceAlerts(performanceHistory, athlete, motionScans),
  };
}

// **⚡ 1. PERFORMANCE METRICS ENGINE**
function generatePerformanceMetrics(performanceHistory, motionScans) {
  if (performanceHistory.length === 0) {
    return generateEmptyMetrics();
  }

  // Extract and calculate BVI scores
  const bviScores = extractBVIScores(performanceHistory);
  const tacticalScores = extractTacticalEfficiencyScores(performanceHistory);
  const recoveryScores = extractRecoveryIndexScores(performanceHistory);
  const spikeScores = extractSpikeScores(performanceHistory);
  const consistencyScores = extractConsistencyScores(performanceHistory);

  return {
    bvi: calculateMetricSummary(bviScores, "BVI"),
    tactical_efficiency: calculateMetricSummary(tacticalScores, "Tactical"),
    recovery_index: calculateMetricSummary(recoveryScores, "Recovery"),
    spike_score: calculateMetricSummary(spikeScores, "Spike"),
    session_consistency: calculateMetricSummary(
      consistencyScores,
      "Consistency",
    ),

    // **Overall Performance Summary**
    overall_summary: {
      total_sessions: performanceHistory.length,
      motion_scans: motionScans.length,
      avg_overall_score: calculateAverageOverallScore(performanceHistory),
      performance_trend: calculateOverallTrend(performanceHistory),
    },
  };
}

// **🎯 BVI SCORE EXTRACTION & CALCULATION**
function extractBVIScores(performanceHistory) {
  return performanceHistory.map((record) => {
    const simulationData = record.simulation_data || {};

    // Extract BVI from simulation data structure
    const bviScore =
      simulationData.bvi_score ||
      simulationData.biomechanical_velocity_index ||
      simulationData.velocity_index ||
      parseFloat(record.asset_value) * 0.15; // Fallback calculation

    return {
      value: Math.min(Math.max(parseFloat(bviScore) || 0, 0), 10),
      timestamp: record.created_at,
      scale_max: simulationData.scale_type === "professional" ? 100 : 10,
    };
  });
}

// **🎯 TACTICAL EFFICIENCY EXTRACTION**
function extractTacticalEfficiencyScores(performanceHistory) {
  return performanceHistory.map((record) => {
    const simulationData = record.simulation_data || {};
    const valuationFactors = record.valuation_factors || {};

    // Extract tactical efficiency from multiple possible sources
    const tacticalScore =
      simulationData.tactical_efficiency ||
      valuationFactors.execution_precision ||
      simulationData.strategic_score ||
      parseFloat(record.asset_value) * 0.12; // Fallback

    return {
      value: Math.min(Math.max(parseFloat(tacticalScore) || 0, 0), 10),
      timestamp: record.created_at,
      scale_max: simulationData.scale_type === "professional" ? 100 : 10,
    };
  });
}

// **💪 RECOVERY INDEX EXTRACTION**
function extractRecoveryIndexScores(performanceHistory) {
  return performanceHistory.map((record) => {
    const simulationData = record.simulation_data || {};
    const valuationFactors = record.valuation_factors || {};

    const recoveryScore =
      simulationData.recovery_index ||
      valuationFactors.sustainability_score ||
      simulationData.endurance_metric ||
      parseFloat(record.asset_value) * 0.18; // Fallback

    return {
      value: Math.min(Math.max(parseFloat(recoveryScore) || 0, 0), 10),
      timestamp: record.created_at,
      scale_max: simulationData.scale_type === "professional" ? 100 : 10,
    };
  });
}

// **📈 SPIKE SCORE EXTRACTION**
function extractSpikeScores(performanceHistory) {
  return performanceHistory.map((record) => {
    const simulationData = record.simulation_data || {};

    const spikeScore =
      simulationData.spike_score ||
      simulationData.peak_performance ||
      simulationData.maximum_output ||
      parseFloat(record.asset_value) * 0.2; // Fallback

    return {
      value: Math.min(Math.max(parseFloat(spikeScore) || 0, 0), 10),
      timestamp: record.created_at,
      scale_max: simulationData.scale_type === "professional" ? 100 : 10,
    };
  });
}

// **📊 CONSISTENCY SCORE EXTRACTION**
function extractConsistencyScores(performanceHistory) {
  return performanceHistory.map((record) => {
    const simulationData = record.simulation_data || {};
    const valuationFactors = record.valuation_factors || {};

    const consistencyScore =
      simulationData.session_consistency ||
      valuationFactors.reliability_index ||
      simulationData.variance_control ||
      calculateConsistencyFromWindow(performanceHistory, record); // Calculated

    return {
      value: Math.min(Math.max(parseFloat(consistencyScore) || 0, 0), 10),
      timestamp: record.created_at,
      scale_max: simulationData.scale_type === "professional" ? 100 : 10,
    };
  });
}

// **📊 METRIC SUMMARY CALCULATION**
function calculateMetricSummary(scores, metricName) {
  if (scores.length === 0) {
    return {
      current: 0,
      previous: 0,
      trend: "stable",
      scale_max: 10,
      data_points: 0,
    };
  }

  const current = scores[scores.length - 1].value;
  const previous =
    scores.length > 1 ? scores[scores.length - 2].value : current;
  const scaleMax = scores[scores.length - 1].scale_max;

  // Calculate trend
  const recentScores = scores.slice(-5).map((s) => s.value);
  const trend = calculateTrendDirection(recentScores);

  return {
    current: parseFloat(current.toFixed(2)),
    previous: parseFloat(previous.toFixed(2)),
    trend: trend,
    scale_max: scaleMax,
    data_points: scores.length,
    average: parseFloat(
      (scores.reduce((sum, s) => sum + s.value, 0) / scores.length).toFixed(2),
    ),
    min: parseFloat(Math.min(...scores.map((s) => s.value)).toFixed(2)),
    max: parseFloat(Math.max(...scores.map((s) => s.value)).toFixed(2)),
  };
}

// **🏆 2. TIER STATUS GENERATION**
function generateTierStatus(athlete, performanceHistory) {
  const tierNames = {
    1: "Starter",
    2: "Developing",
    3: "Pro",
    4: "Elite",
    5: "Champion",
  };

  const currentTier = athlete.tier_level || 1;
  const nextTier = Math.min(currentTier + 1, 5);

  // Calculate advancement progress based on recent performance
  const advancementProgress = calculateAdvancementProgress(
    performanceHistory,
    currentTier,
  );

  // Generate tier requirements
  const requirements = generateTierRequirements(
    currentTier,
    nextTier,
    performanceHistory,
  );

  return {
    current_tier: currentTier,
    current_tier_name: tierNames[currentTier],
    next_tier_name: currentTier < 5 ? tierNames[nextTier] : null,
    advancement_progress: advancementProgress,
    requirements: requirements,
    tier_history: generateTierHistory(athlete),
    estimated_advancement_timeline:
      calculateAdvancementTimeline(advancementProgress),
  };
}

// **📈 3. PROGRESSION TRACKING**
function generateProgressionTracking(performanceHistory, timeframeDays) {
  if (performanceHistory.length === 0) {
    return {
      progression_data: null,
      summary: {
        average_score: 0,
        improvement_rate: 0,
        consistency_score: 0,
      },
    };
  }

  // Create progression data points
  const progressionData = performanceHistory.map((record) => ({
    date: record.created_at,
    overall_score: parseFloat(record.asset_value),
    bvi_score: extractSingleBVIScore(record),
    tactical_score: extractSingleTacticalScore(record),
    recovery_score: extractSingleRecoveryScore(record),
    spike_score: extractSingleSpikeScore(record),
    consistency_score: extractSingleConsistencyScore(record),
  }));

  // Calculate summary statistics
  const scores = progressionData.map((p) => p.overall_score);
  const averageScore =
    scores.reduce((sum, score) => sum + score, 0) / scores.length;

  // Calculate improvement rate (first vs last performance)
  const firstScore = scores[0];
  const lastScore = scores[scores.length - 1];
  const improvementRate =
    firstScore > 0 ? ((lastScore - firstScore) / firstScore) * 100 : 0;

  // Calculate consistency score (inverse of coefficient of variation)
  const standardDev = calculateStandardDeviation(scores);
  const consistencyScore =
    averageScore > 0 ? Math.max(0, (1 - standardDev / averageScore) * 10) : 0;

  return {
    progression_data: progressionData,
    summary: {
      average_score: parseFloat(averageScore.toFixed(2)),
      improvement_rate: parseFloat(improvementRate.toFixed(2)),
      consistency_score: parseFloat(consistencyScore.toFixed(2)),
      total_sessions: progressionData.length,
      timeframe_days: timeframeDays,
    },
  };
}

// **🧠 4. COACHING INSIGHTS & CROSS-CORRELATIONS**
function generateCoachingInsights(performanceHistory, motionScans, athlete) {
  const insights = {
    recommendations: generateCoachingRecommendations(
      performanceHistory,
      athlete,
    ),
    correlations: generateCrossCorrelations(performanceHistory),
    performance_patterns: identifyPerformancePatterns(performanceHistory),
    improvement_opportunities: identifyImprovementOpportunities(
      performanceHistory,
      motionScans,
    ),
  };

  return insights;
}

// **🔗 CROSS-CORRELATION ANALYSIS**
function generateCrossCorrelations(performanceHistory) {
  if (performanceHistory.length < 5) {
    return [];
  }

  const correlations = [];

  // Extract metric arrays
  const bviScores = performanceHistory.map(extractSingleBVIScore);
  const tacticalScores = performanceHistory.map(extractSingleTacticalScore);
  const recoveryScores = performanceHistory.map(extractSingleRecoveryScore);
  const spikeScores = performanceHistory.map(extractSingleSpikeScore);
  const overallScores = performanceHistory.map((p) =>
    parseFloat(p.asset_value),
  );

  // Calculate correlations
  const correlationPairs = [
    {
      metrics: ["BVI", "Tactical Efficiency"],
      correlation: calculateCorrelation(bviScores, tacticalScores),
      scores1: bviScores,
      scores2: tacticalScores,
    },
    {
      metrics: ["Recovery Index", "Session Consistency"],
      correlation: calculateCorrelation(recoveryScores, bviScores),
      scores1: recoveryScores,
      scores2: bviScores,
    },
    {
      metrics: ["Spike Score", "Overall Performance"],
      correlation: calculateCorrelation(spikeScores, overallScores),
      scores1: spikeScores,
      scores2: overallScores,
    },
    {
      metrics: ["Tactical Efficiency", "Recovery Index"],
      correlation: calculateCorrelation(tacticalScores, recoveryScores),
      scores1: tacticalScores,
      scores2: recoveryScores,
    },
  ];

  correlationPairs.forEach((pair) => {
    const strength = Math.abs(pair.correlation);
    let strengthLevel = "weak";
    let coachingInsight = "";

    if (strength > 0.7) {
      strengthLevel = "strong";
    } else if (strength > 0.4) {
      strengthLevel = "moderate";
    }

    // Generate coaching insights based on correlation
    coachingInsight = generateCorrelationInsight(
      pair.metrics,
      pair.correlation,
      strengthLevel,
    );

    correlations.push({
      metric_pair: `${pair.metrics[0]} ↔ ${pair.metrics[1]}`,
      correlation_strength: parseFloat(pair.correlation.toFixed(3)),
      strength_level: strengthLevel,
      coaching_insight: coachingInsight,
      significance: strength > 0.5 ? "high" : strength > 0.3 ? "medium" : "low",
    });
  });

  return correlations.sort(
    (a, b) =>
      Math.abs(b.correlation_strength) - Math.abs(a.correlation_strength),
  );
}

// **📝 5. RECENT ACTIVITY GENERATION**
function generateRecentActivity(performanceHistory, milestones, contributions) {
  const activities = [];

  // Add performance activities
  if (performanceHistory.length > 0) {
    const latestPerformance = performanceHistory[performanceHistory.length - 1];
    activities.push({
      type: "performance",
      description: `Recorded performance score: ${parseFloat(latestPerformance.asset_value).toFixed(1)}`,
      timestamp: formatRelativeTime(latestPerformance.created_at),
      severity: "info",
    });
  }

  // Add milestone activities
  milestones.slice(0, 3).forEach((milestone) => {
    if (milestone.milestone_status === "completed") {
      activities.push({
        type: "milestone",
        description: `Completed milestone: ${milestone.title}`,
        timestamp: formatRelativeTime(
          milestone.completed_at || milestone.created_at,
        ),
        severity: "success",
      });
    } else if (milestone.milestone_status === "active") {
      activities.push({
        type: "milestone",
        description: `Working on: ${milestone.title}`,
        timestamp: formatRelativeTime(milestone.created_at),
        severity: "info",
      });
    }
  });

  // Add contribution activities
  if (contributions.length > 0) {
    const totalContributions = contributions.reduce(
      (sum, c) => sum + parseFloat(c.amount),
      0,
    );
    activities.push({
      type: "financial",
      description: `Total contributions: $${totalContributions.toFixed(2)}`,
      timestamp: formatRelativeTime(contributions[0].created_at),
      severity: "info",
    });
  }

  return activities
    .slice(0, 8)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

// **⚠️ 6. PERFORMANCE ALERTS**
function generatePerformanceAlerts(performanceHistory, athlete, motionScans) {
  const alerts = [];

  if (performanceHistory.length < 3) {
    return [];
  }

  const recentScores = performanceHistory
    .slice(-5)
    .map((p) => parseFloat(p.asset_value));
  const currentScore = recentScores[recentScores.length - 1];
  const averageScore =
    recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

  // Performance decline alert
  const decline = calculateDeclineRate(recentScores);
  if (decline > 0.15) {
    // 15% decline
    alerts.push({
      type: "performance_decline",
      severity: "high",
      title: "Performance Decline Detected",
      description: `Performance has declined by ${(decline * 100).toFixed(1)}% over recent sessions`,
      recommended_action: "Review training approach and consider rest/recovery",
      created_at: new Date().toISOString(),
    });
  }

  // Tier advancement opportunity
  const advancementScore = calculateAdvancementProgress(
    performanceHistory,
    athlete.tier_level,
  );
  if (advancementScore > 75) {
    alerts.push({
      type: "advancement_opportunity",
      severity: "medium",
      title: "Tier Advancement Opportunity",
      description: `${advancementScore.toFixed(0)}% ready for next tier advancement`,
      recommended_action: "Continue consistent performance to advance tier",
      created_at: new Date().toISOString(),
    });
  }

  // Consistency alert
  const consistencyScore = calculateConsistencyIndex(recentScores);
  if (consistencyScore < 0.6) {
    alerts.push({
      type: "consistency_warning",
      severity: "medium",
      title: "Performance Consistency Warning",
      description: "High variability detected in recent performance",
      recommended_action: "Focus on standardizing training routines",
      created_at: new Date().toISOString(),
    });
  }

  return alerts;
}

// **🛠️ UTILITY FUNCTIONS**

function generateEmptyMetrics() {
  const emptyMetric = {
    current: 0,
    previous: 0,
    trend: "stable",
    scale_max: 10,
    data_points: 0,
  };

  return {
    bvi: emptyMetric,
    tactical_efficiency: emptyMetric,
    recovery_index: emptyMetric,
    spike_score: emptyMetric,
    session_consistency: emptyMetric,
    overall_summary: {
      total_sessions: 0,
      motion_scans: 0,
      avg_overall_score: 0,
      performance_trend: "stable",
    },
  };
}

function extractSingleBVIScore(record) {
  const simulationData = record.simulation_data || {};
  return (
    parseFloat(
      simulationData.bvi_score ||
        simulationData.biomechanical_velocity_index ||
        parseFloat(record.asset_value) * 0.15,
    ) || 0
  );
}

function extractSingleTacticalScore(record) {
  const simulationData = record.simulation_data || {};
  return (
    parseFloat(
      simulationData.tactical_efficiency ||
        parseFloat(record.asset_value) * 0.12,
    ) || 0
  );
}

function extractSingleRecoveryScore(record) {
  const simulationData = record.simulation_data || {};
  return (
    parseFloat(
      simulationData.recovery_index || parseFloat(record.asset_value) * 0.18,
    ) || 0
  );
}

function extractSingleSpikeScore(record) {
  const simulationData = record.simulation_data || {};
  return (
    parseFloat(
      simulationData.spike_score || parseFloat(record.asset_value) * 0.2,
    ) || 0
  );
}

function extractSingleConsistencyScore(record) {
  const simulationData = record.simulation_data || {};
  return (
    parseFloat(
      simulationData.session_consistency ||
        parseFloat(record.asset_value) * 0.16,
    ) || 0
  );
}

function calculateConsistencyFromWindow(performanceHistory, currentRecord) {
  // Calculate consistency based on surrounding performance window
  const currentIndex = performanceHistory.findIndex(
    (p) => p.id === currentRecord.id,
  );
  const windowSize = 3;
  const start = Math.max(0, currentIndex - windowSize);
  const end = Math.min(
    performanceHistory.length,
    currentIndex + windowSize + 1,
  );

  const windowScores = performanceHistory
    .slice(start, end)
    .map((p) => parseFloat(p.asset_value));
  return calculateConsistencyIndex(windowScores) * 10; // Scale to 0-10
}

function calculateTrendDirection(scores) {
  if (scores.length < 2) return "stable";

  const recentAvg =
    scores.slice(-3).reduce((sum, s) => sum + s, 0) /
    Math.min(3, scores.length);
  const earlierAvg =
    scores.slice(0, -3).reduce((sum, s) => sum + s, 0) /
    Math.max(1, scores.length - 3);

  const change = (recentAvg - earlierAvg) / earlierAvg;

  if (change > 0.05) return "improving";
  if (change < -0.05) return "declining";
  return "stable";
}

function calculateAdvancementProgress(performanceHistory, currentTier) {
  if (performanceHistory.length === 0) return 0;

  const recentScores = performanceHistory
    .slice(-10)
    .map((p) => parseFloat(p.asset_value));
  const averageScore =
    recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

  // Tier thresholds (example - adjust based on your tier system)
  const tierThresholds = {
    1: 3.0,
    2: 5.0,
    3: 7.0,
    4: 8.5,
    5: 9.5,
  };

  const currentThreshold = tierThresholds[currentTier] || 10;
  const nextThreshold = tierThresholds[currentTier + 1] || 10;

  if (averageScore >= nextThreshold) return 100;

  const progress =
    ((averageScore - currentThreshold) / (nextThreshold - currentThreshold)) *
    100;
  return Math.max(0, Math.min(100, progress));
}

function generateTierRequirements(currentTier, nextTier, performanceHistory) {
  // Generate dynamic requirements based on tier
  const requirements = [];

  const recentScores = performanceHistory
    .slice(-5)
    .map((p) => parseFloat(p.asset_value));
  const averageScore =
    recentScores.length > 0
      ? recentScores.reduce((sum, score) => sum + score, 0) /
        recentScores.length
      : 0;

  // Score requirement
  const targetScore = nextTier * 2; // Example: tier 2 needs 4.0 average
  requirements.push({
    description: `Maintain ${targetScore.toFixed(1)}+ average score`,
    completed: averageScore >= targetScore,
    progress: Math.min(100, (averageScore / targetScore) * 100),
  });

  // Consistency requirement
  const consistencyScore = calculateConsistencyIndex(recentScores);
  requirements.push({
    description: "Demonstrate consistent performance (70%+ consistency)",
    completed: consistencyScore >= 0.7,
    progress: consistencyScore * 100,
  });

  // Session count requirement
  const minSessions = nextTier * 3; // Example: tier 2 needs 6 sessions
  requirements.push({
    description: `Complete ${minSessions} performance sessions`,
    completed: performanceHistory.length >= minSessions,
    progress: Math.min(100, (performanceHistory.length / minSessions) * 100),
  });

  return requirements;
}

function generateTierHistory(athlete) {
  // This would typically come from a tier_history table
  // For now, return current tier info
  return [
    {
      tier: athlete.tier_level,
      tier_name:
        ["", "Starter", "Developing", "Pro", "Elite", "Champion"][
          athlete.tier_level
        ] || "Unknown",
      achieved_at: athlete.updated_at,
      duration_days: Math.floor(
        (new Date() - new Date(athlete.updated_at)) / (1000 * 60 * 60 * 24),
      ),
    },
  ];
}

function calculateAdvancementTimeline(advancementProgress) {
  if (advancementProgress >= 100) return 0;
  if (advancementProgress <= 0) return null;

  // Estimate days based on current progress rate
  const remainingProgress = 100 - advancementProgress;
  const estimatedDays = Math.round((remainingProgress / 5) * 7); // Assume 5% progress per week

  return Math.min(estimatedDays, 180); // Cap at 6 months
}

function generateCoachingRecommendations(performanceHistory, athlete) {
  const recommendations = [];

  if (performanceHistory.length === 0) {
    recommendations.push({
      category: "getting_started",
      priority: "high",
      title: "Begin Performance Tracking",
      description:
        "Start recording regular performance sessions to establish baseline metrics.",
      action_items: [
        "Complete first motion scan",
        "Set initial performance goals",
      ],
    });
    return recommendations;
  }

  const recentScores = performanceHistory
    .slice(-5)
    .map((p) => parseFloat(p.asset_value));
  const trend = calculateTrendDirection(recentScores);

  if (trend === "declining") {
    recommendations.push({
      category: "performance_improvement",
      priority: "high",
      title: "Address Performance Decline",
      description: "Recent sessions show declining performance trend.",
      action_items: [
        "Review training intensity and recovery",
        "Analyze technique consistency",
        "Consider coaching consultation",
      ],
    });
  }

  const consistencyScore = calculateConsistencyIndex(recentScores);
  if (consistencyScore < 0.7) {
    recommendations.push({
      category: "consistency",
      priority: "medium",
      title: "Improve Performance Consistency",
      description: "High variability detected in recent performances.",
      action_items: [
        "Standardize pre-performance routine",
        "Focus on fundamental technique",
        "Monitor external factors affecting performance",
      ],
    });
  }

  return recommendations;
}

function identifyPerformancePatterns(performanceHistory) {
  // Analyze patterns in performance data
  return {
    weekly_pattern: "Consistent improvement trend",
    peak_performance_time: "Afternoon sessions",
    recovery_pattern: "Good recovery between sessions",
  };
}

function identifyImprovementOpportunities(performanceHistory, motionScans) {
  return [
    {
      area: "Biomechanical Efficiency",
      potential_gain: "15%",
      recommendation: "Focus on movement optimization",
    },
    {
      area: "Tactical Execution",
      potential_gain: "12%",
      recommendation: "Improve decision-making speed",
    },
  ];
}

function calculateCorrelation(x, y) {
  if (x.length !== y.length || x.length === 0) return 0;

  const n = x.length;
  const sumX = x.reduce((sum, val) => sum + val, 0);
  const sumY = y.reduce((sum, val) => sum + val, 0);
  const sumXY = x.reduce((sum, val, i) => sum + val * y[i], 0);
  const sumXX = x.reduce((sum, val) => sum + val * val, 0);
  const sumYY = y.reduce((sum, val) => sum + val * val, 0);

  const numerator = n * sumXY - sumX * sumY;
  const denominator = Math.sqrt(
    (n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY),
  );

  return denominator === 0 ? 0 : numerator / denominator;
}

function generateCorrelationInsight(metrics, correlation, strengthLevel) {
  const [metric1, metric2] = metrics;
  const direction = correlation > 0 ? "positively" : "negatively";

  const insights = {
    "BVI ↔ Tactical Efficiency": `High biomechanical velocity ${direction} correlates with tactical execution. Focus on speed-accuracy training.`,
    "Recovery Index ↔ Session Consistency": `Recovery capacity ${direction} affects performance consistency. Optimize rest protocols.`,
    "Spike Score ↔ Overall Performance": `Peak performance capability ${direction} influences overall scores. Develop explosive training.`,
    "Tactical Efficiency ↔ Recovery Index": `Strategic execution ${direction} relates to sustainability. Balance intensity with recovery.`,
  };

  return (
    insights[`${metric1} ↔ ${metric2}`] ||
    `${metric1} and ${metric2} show ${strengthLevel} ${direction} correlation.`
  );
}

function calculateAverageOverallScore(performanceHistory) {
  if (performanceHistory.length === 0) return 0;

  const scores = performanceHistory.map((p) => parseFloat(p.asset_value));
  return parseFloat(
    (scores.reduce((sum, score) => sum + score, 0) / scores.length).toFixed(2),
  );
}

function calculateOverallTrend(performanceHistory) {
  if (performanceHistory.length < 2) return "stable";

  const scores = performanceHistory.map((p) => parseFloat(p.asset_value));
  return calculateTrendDirection(scores);
}

function calculateConsistencyIndex(scores) {
  if (scores.length < 2) return 1;

  const mean = scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const coefficientOfVariation = Math.sqrt(variance) / mean;

  return Math.max(0, Math.min(1, 1 - coefficientOfVariation));
}

function calculateStandardDeviation(numbers) {
  const mean = numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
  const variance =
    numbers.reduce((sum, num) => sum + Math.pow(num - mean, 2), 0) /
    numbers.length;
  return Math.sqrt(variance);
}

function calculateDeclineRate(scores) {
  if (scores.length < 2) return 0;

  const firstHalf = scores.slice(0, Math.floor(scores.length / 2));
  const secondHalf = scores.slice(Math.floor(scores.length / 2));

  const firstAvg = firstHalf.reduce((sum, s) => sum + s, 0) / firstHalf.length;
  const secondAvg =
    secondHalf.reduce((sum, s) => sum + s, 0) / secondHalf.length;

  return firstAvg > 0 ? Math.max(0, (firstAvg - secondAvg) / firstAvg) : 0;
}

function formatRelativeTime(timestamp) {
  const now = new Date();
  const past = new Date(timestamp);
  const diffMs = now - past;
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffMinutes = Math.floor(diffMs / (1000 * 60));

  if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
  if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
  if (diffMinutes > 0)
    return `${diffMinutes} minute${diffMinutes > 1 ? "s" : ""} ago`;
  return "Just now";
}
