import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const formData = await request.json();

    // Validate required fields
    const requiredFields = [
      "rep_name",
      "rep_title",
      "rep_organization",
      "rep_email",
      "rep_type",
      "athlete_name",
      "athlete_age",
      "athlete_sport",
      "athlete_level",
      "standout_traits",
      "training_schedule",
      "milestone_potential",
      "agreement_terms",
      "data_accuracy",
    ];

    for (const field of requiredFields) {
      if (!formData[field]) {
        return Response.json(
          { error: `Missing required field: ${field}` },
          { status: 400 },
        );
      }
    }

    // Create athlete referral record in database
    const referralResult = await sql`
      INSERT INTO athlete_referrals (
        -- Representative info
        rep_name,
        rep_title,
        rep_organization,
        rep_email,
        rep_phone,
        rep_type,
        rep_credentials,
        
        -- Athlete info
        athlete_name,
        athlete_age,
        athlete_sport,
        athlete_position,
        athlete_level,
        athlete_location,
        
        -- Performance context
        standout_traits,
        adversity_overcome,
        community_impact,
        training_schedule,
        recent_achievements,
        milestone_potential,
        
        -- Technical details
        sample_footage_url,
        stat_sheet_notes,
        wallet_address,
        preferred_milestones,
        
        -- Status
        referral_status,
        created_at
      ) VALUES (
        ${formData.rep_name},
        ${formData.rep_title},
        ${formData.rep_organization},
        ${formData.rep_email},
        ${formData.rep_phone || null},
        ${formData.rep_type},
        ${formData.rep_credentials || null},
        
        ${formData.athlete_name},
        ${parseInt(formData.athlete_age)},
        ${formData.athlete_sport},
        ${formData.athlete_position || null},
        ${formData.athlete_level},
        ${formData.athlete_location || null},
        
        ${formData.standout_traits},
        ${formData.adversity_overcome || null},
        ${formData.community_impact || null},
        ${formData.training_schedule},
        ${formData.recent_achievements || null},
        ${formData.milestone_potential},
        
        ${formData.sample_footage_url || null},
        ${formData.stat_sheet_notes || null},
        ${formData.wallet_address || null},
        ${JSON.stringify(formData.preferred_milestones || [])},
        
        'pending_review',
        CURRENT_TIMESTAMP
      ) RETURNING id
    `;

    const referralId = referralResult[0].id;

    // Auto-process high-quality referrals from verified coaches
    const verifiedRepTypes = [
      "coach_high_school",
      "coach_college",
      "trainer_certified",
      "scout_summit",
      "validator_dao",
    ];

    if (
      verifiedRepTypes.includes(formData.rep_type) &&
      formData.preferred_milestones.length >= 2
    ) {
      // Auto-approve and begin athlete profile creation
      await processAthleteOnboarding(referralId, formData);
    }

    return Response.json({
      success: true,
      referral_id: referralId,
      message: "Athlete referral submitted successfully",
      estimated_processing_time: "24-48 hours",
    });
  } catch (error) {
    console.error("Referral submission error:", error);
    return Response.json(
      { error: "Failed to submit referral" },
      { status: 500 },
    );
  }
}

async function processAthleteOnboarding(referralId, formData) {
  try {
    // Create auth user (placeholder - they'll sign in later)
    const userResult = await sql`
      INSERT INTO auth_users (name, email, emailVerified)
      VALUES (
        ${formData.athlete_name},
        ${generateAthleteEmail(formData.athlete_name)},
        NULL
      ) RETURNING id
    `;

    const userId = userResult[0].id;

    // Create user profile
    const profileResult = await sql`
      INSERT INTO user_profiles (
        user_id,
        user_type,
        tier_level,
        reputation_score,
        total_contributions,
        total_earnings,
        created_at
      ) VALUES (
        ${userId},
        'athlete',
        1, -- Start at Bronze tier
        ${calculateInitialReputation(formData)},
        0,
        0,
        CURRENT_TIMESTAMP
      ) RETURNING id
    `;

    const profileId = profileResult[0].id;

    // Create milestones based on referral
    for (const milestoneType of formData.preferred_milestones) {
      await createMilestone(profileId, milestoneType, formData);
    }

    // Create digital wallet
    await sql`
      INSERT INTO digital_wallets (
        user_id,
        wallet_type,
        balance,
        available_balance,
        locked_balance,
        auto_reinvest_percentage,
        wallet_settings,
        created_at
      ) VALUES (
        ${profileId},
        'athlete',
        0,
        0,
        0,
        10,
        ${JSON.stringify({
          qr_enabled: true,
          nfc_enabled: true,
          auto_pay_insurance: true,
          dao_notifications: true,
        })},
        CURRENT_TIMESTAMP
      )
    `;

    // Update referral status
    await sql`
      UPDATE athlete_referrals 
      SET referral_status = 'approved',
          athlete_profile_id = ${profileId},
          processed_at = CURRENT_TIMESTAMP
      WHERE id = ${referralId}
    `;

    // Generate onboarding link (in production, send via SMS/email)
    const onboardingToken = generateOnboardingToken(userId);
    console.log(
      `Onboarding link generated for ${formData.athlete_name}: /onboard/${onboardingToken}`,
    );
  } catch (error) {
    console.error("Athlete onboarding error:", error);
    // Update referral status to failed
    await sql`
      UPDATE athlete_referrals 
      SET referral_status = 'processing_failed'
      WHERE id = ${referralId}
    `;
  }
}

async function createMilestone(athleteId, milestoneType, formData) {
  const milestoneConfig = getMilestoneConfig(milestoneType, formData);

  await sql`
    INSERT INTO milestones (
      athlete_id,
      title,
      description,
      target_metrics,
      current_progress,
      milestone_status,
      reward_pool,
      target_date,
      created_at
    ) VALUES (
      ${athleteId},
      ${milestoneConfig.title},
      ${milestoneConfig.description},
      ${JSON.stringify(milestoneConfig.target_metrics)},
      ${JSON.stringify({})},
      'active',
      ${milestoneConfig.initial_pool || 100},
      ${milestoneConfig.target_date},
      CURRENT_TIMESTAMP
    )
  `;

  // Create contribution pool for fan staking
  const milestoneResult = await sql`
    SELECT id FROM milestones 
    WHERE athlete_id = ${athleteId} 
    AND title = ${milestoneConfig.title}
    ORDER BY created_at DESC 
    LIMIT 1
  `;

  if (milestoneResult.length > 0) {
    await sql`
      INSERT INTO contribution_pools (
        milestone_id,
        total_amount,
        contributor_count,
        pool_status,
        distribution_rules,
        created_at
      ) VALUES (
        ${milestoneResult[0].id},
        0,
        0,
        'active',
        ${JSON.stringify({
          success_payout_percentage: 80,
          dao_treasury_percentage: 10,
          platform_fee_percentage: 10,
        })},
        CURRENT_TIMESTAMP
      )
    `;
  }
}

function getMilestoneConfig(milestoneType, formData) {
  const configs = {
    grip_symmetry: {
      title: "Grip Symmetry Mastery",
      description:
        "Demonstrate consistent grip control and symmetry across 5 consecutive matches",
      target_metrics: {
        grip_consistency_score: 85,
        match_count: 5,
        measurement_type: "motion_analysis",
      },
      initial_pool: 150,
      target_date: new Date(
        Date.now() + 90 * 24 * 60 * 60 * 1000,
      ).toISOString(), // 90 days
    },
    fatigue_decay: {
      title: "Fatigue Resistance Excellence",
      description:
        "Maintain performance within 10% of peak throughout extended training sessions",
      target_metrics: {
        performance_degradation_max: 10,
        session_duration_minutes: 120,
        measurement_type: "endurance_tracking",
      },
      initial_pool: 200,
      target_date: new Date(
        Date.now() + 60 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
    clean_takedowns: {
      title: "Clean Takedown Execution",
      description:
        "Execute 3 clean takedowns per match over 4 consecutive matches",
      target_metrics: {
        takedowns_per_match: 3,
        match_count: 4,
        technique_quality_threshold: 80,
      },
      initial_pool: 175,
      target_date: new Date(
        Date.now() + 75 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
    zone_dominance: {
      title: "Zone Dominance Control",
      description:
        "Maintain zone control for 70% of match time across competitive bouts",
      target_metrics: {
        zone_control_percentage: 70,
        match_count: 3,
        measurement_type: "spatial_analysis",
      },
      initial_pool: 180,
      target_date: new Date(
        Date.now() + 85 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
    rhythm_maintenance: {
      title: "Rhythm Consistency",
      description:
        "Maintain optimal rhythm for 2 full rounds without disruption",
      target_metrics: {
        rhythm_consistency_score: 90,
        round_count: 2,
        disruption_tolerance: 5,
      },
      initial_pool: 125,
      target_date: new Date(
        Date.now() + 45 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
    power_consistency: {
      title: "Power Output Consistency",
      description:
        "Maintain power output within 15% variance throughout competition",
      target_metrics: {
        power_variance_max: 15,
        measurement_duration: "full_match",
        consistency_threshold: 85,
      },
      initial_pool: 160,
      target_date: new Date(
        Date.now() + 70 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
    recovery_speed: {
      title: "Recovery Speed Index",
      description: "Achieve target recovery metrics between training sessions",
      target_metrics: {
        recovery_time_max: 48,
        performance_restoration: 95,
        measurement_type: "biometric_tracking",
      },
      initial_pool: 140,
      target_date: new Date(
        Date.now() + 30 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
    technique_precision: {
      title: "Technique Precision Excellence",
      description: "Demonstrate precise technique execution with 90%+ accuracy",
      target_metrics: {
        technique_accuracy: 90,
        execution_count: 10,
        assessment_type: "expert_review",
      },
      initial_pool: 190,
      target_date: new Date(
        Date.now() + 80 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    },
  };

  return configs[milestoneType] || configs.clean_takedowns;
}

function calculateInitialReputation(formData) {
  let reputation = 50; // Base reputation

  // Level adjustments
  const levelBonus = {
    high_school: 10,
    junior_college: 15,
    college_d1: 25,
    college_d2: 20,
    college_d3: 18,
    amateur_elite: 30,
    semi_professional: 35,
    professional: 40,
  };

  reputation += levelBonus[formData.athlete_level] || 0;

  // Achievement bonus
  if (formData.recent_achievements) {
    reputation += 15;
  }

  // Community impact bonus
  if (formData.community_impact) {
    reputation += 10;
  }

  // Training schedule bonus
  if (
    formData.training_schedule.includes("6") ||
    formData.training_schedule.includes("7")
  ) {
    reputation += 5;
  }

  return Math.min(100, reputation);
}

function generateAthleteEmail(athleteName) {
  const baseEmail = athleteName.toLowerCase().replace(/\s+/g, ".");
  return `${baseEmail}@bim-apes.athlete`;
}

function generateOnboardingToken(userId) {
  // In production, this would be a secure JWT or similar
  return Buffer.from(`${userId}:${Date.now()}`).toString("base64url");
}
