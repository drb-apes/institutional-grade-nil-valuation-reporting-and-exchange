import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { success: false, error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { athlete_id, amount } = body;

    if (!athlete_id || !amount || amount <= 0) {
      return Response.json(
        { success: false, error: "athlete_id and positive amount required" },
        { status: 400 },
      );
    }

    // Start transaction
    const result = await sql.transaction(async (txn) => {
      // Get fan's user_profile id
      const fanProfile = await txn`
        SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
      `;

      if (fanProfile.length === 0) {
        throw new Error("Fan profile not found");
      }

      const fan_id = fanProfile[0].id;

      // Check if fan has enough PT tokens
      const balance = await txn`
        SELECT available_balance FROM pt_token_balances WHERE user_id = ${fan_id}
      `;

      const available =
        balance.length > 0 ? parseFloat(balance[0].available_balance) : 0;

      if (available < amount) {
        throw new Error("Insufficient PT token balance");
      }

      // Check for active sponsor contract
      const sponsorContract = await txn`
        SELECT sc.*, up.user_id as sponsor_user_id
        FROM sponsor_contracts sc
        JOIN user_profiles up ON up.id = sc.sponsor_id
        WHERE sc.athlete_id = ${athlete_id}
        AND sc.contract_status = 'active'
        AND sc.contract_type = 'biometric_index'
        LIMIT 1
      `;

      const hasSponsor = sponsorContract.length > 0;
      const sponsorRoyalty = hasSponsor
        ? parseFloat(sponsorContract[0].yield_target?.fanTipRoyalty || 10)
        : 0;

      // Revenue splits
      const athleteShare = amount * 0.6;
      const teamShare = amount * 0.2;
      const bimShare = amount * 0.1;
      const sponsorShare = hasSponsor ? amount * (sponsorRoyalty / 100) : 0;

      // Deduct from fan's balance
      await txn`
        UPDATE pt_token_balances
        SET 
          available_balance = available_balance - ${amount},
          balance = balance - ${amount},
          total_spent = total_spent + ${amount},
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ${fan_id}
      `;

      // Add to athlete's balance (60%)
      await txn`
        INSERT INTO pt_token_balances (user_id, balance, available_balance, total_earned)
        VALUES (${athlete_id}, ${athleteShare}, ${athleteShare}, ${athleteShare})
        ON CONFLICT (user_id) DO UPDATE SET
          balance = pt_token_balances.balance + ${athleteShare},
          available_balance = pt_token_balances.available_balance + ${athleteShare},
          total_earned = pt_token_balances.total_earned + ${athleteShare},
          updated_at = CURRENT_TIMESTAMP
      `;

      // If sponsor exists, allocate sponsor royalty (10%)
      if (hasSponsor && sponsorShare > 0) {
        const sponsor_id = sponsorContract[0].sponsor_id;

        await txn`
          INSERT INTO pt_token_balances (user_id, balance, available_balance, total_earned)
          VALUES (${sponsor_id}, ${sponsorShare}, ${sponsorShare}, ${sponsorShare})
          ON CONFLICT (user_id) DO UPDATE SET
            balance = pt_token_balances.balance + ${sponsorShare},
            available_balance = pt_token_balances.available_balance + ${sponsorShare},
            total_earned = pt_token_balances.total_earned + ${sponsorShare},
            updated_at = CURRENT_TIMESTAMP
        `;

        // Record sponsor royalty revenue
        await txn`
          INSERT INTO treasury_transactions (
            transaction_type,
            amount,
            balance_after,
            reference_id,
            reference_type,
            description,
            authorized_by
          ) VALUES (
            'distribution',
            ${sponsorShare},
            ${sponsorShare},
            ${sponsorContract[0].id},
            'fan_tip_royalty',
            ${"Fan-tip royalty from athlete " + athlete_id + " - PT Index revenue"},
            ${sponsor_id}
          )
        `;
      }

      // Calculate engagement weight (tips have base weight of 1 per PT token)
      const engagement_weight = Math.floor(amount);

      // Record engagement action
      const action = await txn`
        INSERT INTO fan_engagement_actions (
          fan_id,
          athlete_id,
          action_type,
          pt_token_amount,
          engagement_weight,
          action_metadata
        ) VALUES (
          ${fan_id},
          ${athlete_id},
          'tip',
          ${amount},
          ${engagement_weight},
          ${JSON.stringify({
            timestamp: new Date().toISOString(),
            sponsorRoyalty: sponsorShare,
            revenueSplit: {
              athlete: athleteShare,
              team: teamShare,
              bim: bimShare,
              sponsor: sponsorShare,
            },
          })}
        )
        RETURNING *
      `;

      // Check if this qualifies for any badge unlocks
      const totalTips = await txn`
        SELECT COUNT(*) as tip_count FROM fan_engagement_actions
        WHERE fan_id = ${fan_id} AND action_type = 'tip'
      `;

      const tipCount = parseInt(totalTips[0].tip_count);
      let badgeUnlocked = null;

      // Check for "Early Supporter" badge (first 100 tips to athlete)
      const athleteTipCount = await txn`
        SELECT COUNT(DISTINCT fan_id) as supporter_count
        FROM fan_engagement_actions
        WHERE athlete_id = ${athlete_id} AND action_type = 'tip'
      `;

      if (athleteTipCount[0].supporter_count <= 100) {
        // Award Early Supporter badge
        const badge = await txn`
          SELECT id FROM badges WHERE badge_id = 'early_supporter'
        `;

        if (badge.length > 0) {
          await txn`
            INSERT INTO fan_badges (fan_id, badge_id)
            VALUES (${fan_id}, ${badge[0].id})
            ON CONFLICT (fan_id, badge_id) DO NOTHING
          `;
          badgeUnlocked = "early_supporter";
        }
      }

      return {
        action: action[0],
        badgeUnlocked,
        revenueSplit: {
          athlete: athleteShare,
          team: teamShare,
          bim: bimShare,
          sponsor: sponsorShare,
          hasSponsor: hasSponsor,
        },
      };
    });

    return Response.json({
      success: true,
      action: result.action,
      badgeUnlocked: result.badgeUnlocked,
      revenueSplit: result.revenueSplit,
      message: "Tip sent successfully",
    });
  } catch (error) {
    console.error("Error processing tip:", error);
    return Response.json(
      { success: false, error: error.message || "Failed to process tip" },
      { status: 500 },
    );
  }
}
