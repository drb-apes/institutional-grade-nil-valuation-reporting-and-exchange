import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { success: false, error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { athlete_id, amount } = body;

    if (!athlete_id || !amount || amount <= 0) {
      return Response.json(
        { success: false, error: "athlete_id and positive amount required" },
        { status: 400 },
      );
    }

    const result = await sql.transaction(async (txn) => {
      // Get fan's user_profile id
      const fanProfile = await txn`
        SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
      `;

      if (fanProfile.length === 0) {
        throw new Error("Fan profile not found");
      }

      const fan_id = fanProfile[0].id;

      // Check balance
      const balance = await txn`
        SELECT available_balance FROM pt_token_balances WHERE user_id = ${fan_id}
      `;

      const available =
        balance.length > 0 ? parseFloat(balance[0].available_balance) : 0;

      if (available < amount) {
        throw new Error("Insufficient PT token balance");
      }

      // Deduct from fan
      await txn`
        UPDATE pt_token_balances
        SET 
          available_balance = available_balance - ${amount},
          balance = balance - ${amount},
          total_spent = total_spent + ${amount},
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ${fan_id}
      `;

      // Boosts create metadata multipliers (not direct token transfer)
      // Multiplier: 1.5x for every 10 PT tokens
      const metadata_multiplier = 1 + (amount / 10) * 0.5;

      // Engagement weight: Boosts count 3x regular tips
      const engagement_weight = Math.floor(amount * 3);

      // Record boost action
      const action = await txn`
        INSERT INTO fan_engagement_actions (
          fan_id,
          athlete_id,
          action_type,
          pt_token_amount,
          metadata_multiplier,
          engagement_weight,
          action_metadata
        ) VALUES (
          ${fan_id},
          ${athlete_id},
          'boost',
          ${amount},
          ${metadata_multiplier},
          ${engagement_weight},
          ${JSON.stringify({
            timestamp: new Date().toISOString(),
            visibility_boost: metadata_multiplier,
          })}
        )
        RETURNING *
      `;

      // Check for Consistent Booster badge (10+ boosts)
      const boostCount = await txn`
        SELECT COUNT(*) as count FROM fan_engagement_actions
        WHERE fan_id = ${fan_id} AND action_type = 'boost'
      `;

      let badgeUnlocked = null;
      if (parseInt(boostCount[0].count) >= 10) {
        const badge = await txn`
          SELECT id FROM badges WHERE badge_id = 'consistent_booster'
        `;

        if (badge.length > 0) {
          await txn`
            INSERT INTO fan_badges (fan_id, badge_id)
            VALUES (${fan_id}, ${badge[0].id})
            ON CONFLICT (fan_id, badge_id) DO NOTHING
          `;
          badgeUnlocked = "consistent_booster";
        }
      }

      return { action: action[0], badgeUnlocked, metadata_multiplier };
    });

    return Response.json({
      success: true,
      action: result.action,
      badgeUnlocked: result.badgeUnlocked,
      metadata_multiplier: result.metadata_multiplier,
      message: "Boost applied successfully",
    });
  } catch (error) {
    console.error("Error processing boost:", error);
    return Response.json(
      { success: false, error: error.message || "Failed to process boost" },
      { status: 500 },
    );
  }
}
