import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { success: false, error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { athlete_id, amount, duration_days, badge_ids } = body;

    if (!athlete_id || !amount || amount <= 0) {
      return Response.json(
        { success: false, error: "athlete_id and positive amount required" },
        { status: 400 },
      );
    }

    const stakeDuration = duration_days || 30;

    const result = await sql.transaction(async (txn) => {
      // Get fan's user_profile id
      const fanProfile = await txn`
        SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
      `;

      if (fanProfile.length === 0) {
        throw new Error("Fan profile not found");
      }

      const fan_id = fanProfile[0].id;

      // Check balance
      const balance = await txn`
        SELECT available_balance FROM pt_token_balances WHERE user_id = ${fan_id}
      `;

      const available =
        balance.length > 0 ? parseFloat(balance[0].available_balance) : 0;

      if (available < amount) {
        throw new Error("Insufficient PT token balance");
      }

      // Move from available to staked
      await txn`
        UPDATE pt_token_balances
        SET 
          available_balance = available_balance - ${amount},
          staked_balance = staked_balance + ${amount},
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ${fan_id}
      `;

      // Determine metadata tier unlocked based on stake amount
      let metadata_tier = "tier_1";
      if (amount >= 1000) metadata_tier = "vault";
      else if (amount >= 500) metadata_tier = "tier_3";
      else if (amount >= 200) metadata_tier = "tier_2";

      // Engagement multiplier increases with duration
      const engagement_multiplier = 1.5 + (stakeDuration / 30) * 0.5;

      // Calculate expiration
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + stakeDuration);

      // Create staking position
      const position = await txn`
        INSERT INTO staking_positions (
          staker_id,
          athlete_id,
          stake_type,
          pt_amount,
          badge_ids,
          stake_duration_days,
          metadata_tier_unlocked,
          engagement_multiplier,
          expires_at
        ) VALUES (
          ${fan_id},
          ${athlete_id},
          ${badge_ids && badge_ids.length > 0 ? "hybrid" : "pt_token"},
          ${amount},
          ${badge_ids || []},
          ${stakeDuration},
          ${metadata_tier},
          ${engagement_multiplier},
          ${expiresAt.toISOString()}
        )
        RETURNING *
      `;

      // If badges are staked, mark them as staked
      if (badge_ids && badge_ids.length > 0) {
        await txn`
          UPDATE fan_badges
          SET is_staked = true, staked_at = CURRENT_TIMESTAMP
          WHERE fan_id = ${fan_id} AND badge_id = ANY(${badge_ids})
        `;
      }

      // Record engagement action
      const engagement_weight = Math.floor(amount * engagement_multiplier * 5);

      const action = await txn`
        INSERT INTO fan_engagement_actions (
          fan_id,
          athlete_id,
          action_type,
          pt_token_amount,
          metadata_multiplier,
          engagement_weight,
          action_metadata
        ) VALUES (
          ${fan_id},
          ${athlete_id},
          'stake',
          ${amount},
          ${engagement_multiplier},
          ${engagement_weight},
          ${JSON.stringify({
            duration_days: stakeDuration,
            metadata_tier,
            timestamp: new Date().toISOString(),
          })}
        )
        RETURNING *
      `;

      // Unlock metadata tier
      await txn`
        INSERT INTO metadata_unlocks (
          fan_id,
          athlete_id,
          unlock_type,
          unlock_source,
          metadata_content,
          expires_at
        ) VALUES (
          ${fan_id},
          ${athlete_id},
          ${metadata_tier},
          'stake',
          ${JSON.stringify({
            tier: metadata_tier,
            stake_amount: amount,
            duration: stakeDuration,
          })},
          ${expiresAt.toISOString()}
        )
      `;

      // Check for Loyal Staker badge (90+ day stake)
      let badgeUnlocked = null;
      if (stakeDuration >= 90) {
        const badge = await txn`
          SELECT id FROM badges WHERE badge_id = 'loyal_staker'
        `;

        if (badge.length > 0) {
          await txn`
            INSERT INTO fan_badges (fan_id, badge_id)
            VALUES (${fan_id}, ${badge[0].id})
            ON CONFLICT (fan_id, badge_id) DO NOTHING
          `;
          badgeUnlocked = "loyal_staker";
        }
      }

      return {
        position: position[0],
        action: action[0],
        badgeUnlocked,
        metadata_tier,
      };
    });

    return Response.json({
      success: true,
      position: result.position,
      action: result.action,
      badgeUnlocked: result.badgeUnlocked,
      metadata_tier: result.metadata_tier,
      message: "Stake created successfully",
    });
  } catch (error) {
    console.error("Error processing stake:", error);
    return Response.json(
      { success: false, error: error.message || "Failed to process stake" },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { success: false, error: "Authentication required" },
        { status: 401 },
      );
    }

    const fanProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (fanProfile.length === 0) {
      return Response.json(
        { success: false, error: "Fan profile not found" },
        { status: 404 },
      );
    }

    const fan_id = fanProfile[0].id;

    // Get active stakes
    const stakes = await sql`
      SELECT 
        sp.*,
        up.user_type as athlete_user_type,
        au.name as athlete_name
      FROM staking_positions sp
      LEFT JOIN user_profiles up ON sp.athlete_id = up.id
      LEFT JOIN auth_users au ON up.user_id = au.id
      WHERE sp.staker_id = ${fan_id} AND sp.is_active = true
      ORDER BY sp.staked_at DESC
    `;

    return Response.json({
      success: true,
      stakes,
      count: stakes.length,
    });
  } catch (error) {
    console.error("Error fetching stakes:", error);
    return Response.json(
      { success: false, error: "Failed to fetch stakes" },
      { status: 500 },
    );
  }
}
