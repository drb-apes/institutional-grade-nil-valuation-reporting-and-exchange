import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { scan_data, ai_score, motion_type, sport, metadata, athlete_id } =
      await request.json();

    // Validate required fields
    if (!scan_data || !ai_score || !motion_type) {
      return Response.json(
        {
          error: "Missing required fields: scan_data, ai_score, motion_type",
        },
        { status: 400 },
      );
    }

    let targetAthleteId;

    // If athlete_id is provided, validate it exists
    if (athlete_id) {
      const athleteExists = await sql`
        SELECT id FROM user_profiles WHERE id = ${athlete_id}
      `;

      if (athleteExists.length === 0) {
        return Response.json(
          { error: `Athlete with ID ${athlete_id} not found in user_profiles` },
          { status: 400 },
        );
      }

      targetAthleteId = athlete_id;
    } else {
      // Get or create user profile for current user
      let userProfile = await sql`
        SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
      `;

      if (userProfile.length === 0) {
        // Create profile if it doesn't exist
        userProfile = await sql`
          INSERT INTO user_profiles (user_id, user_type, tier_level)
          VALUES (${session.user.id}, 'athlete', 1)
          RETURNING id
        `;
      }

      targetAthleteId = userProfile[0].id;
    }

    // Double-check the athlete_id exists before inserting
    const finalAthleteCheck = await sql`
      SELECT id FROM user_profiles WHERE id = ${targetAthleteId}
    `;

    if (finalAthleteCheck.length === 0) {
      return Response.json(
        {
          error: `Final validation failed: athlete_id ${targetAthleteId} not found`,
        },
        { status: 500 },
      );
    }

    // Determine verification status based on AI score
    let verificationStatus = "pending";
    if (ai_score >= 80) {
      verificationStatus = "verified";
    } else if (ai_score < 50) {
      verificationStatus = "rejected";
    }

    // Create motion scan record with validated athlete_id
    const motionScan = await sql`
      INSERT INTO motion_scans (
        athlete_id, 
        scan_data, 
        ai_score, 
        verification_status, 
        motion_type, 
        metadata,
        verified_at
      ) VALUES (
        ${targetAthleteId},
        ${JSON.stringify(scan_data)},
        ${ai_score},
        ${verificationStatus},
        ${motion_type},
        ${JSON.stringify({ ...metadata, sport: sport || "general" })},
        ${verificationStatus === "verified" ? new Date().toISOString() : null}
      )
      RETURNING *
    `;

    // **BIM PERFORMANCE INDEX INTEGRATION**
    let bimResults = null;
    if (verificationStatus === "verified") {
      try {
        console.log(
          "Starting BIM Performance calculation for verified scan:",
          motionScan[0].id,
        );

        // Call BIM Performance Index calculation
        const bimResponse = await fetch(
          `${process.env.NEXTAUTH_URL || "http://localhost:3000"}/api/bim-performance/calculate`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Cookie: request.headers.get("Cookie"), // Pass authentication
            },
            body: JSON.stringify({
              motion_scan_data: {
                ...scan_data,
                scan_id: motionScan[0].id,
              },
              athlete_data: {
                athlete_id: targetAthleteId,
                height: 1.75, // Default height for calculations
                weight: 70, // Default weight for calculations
              },
              session_context: {
                scan_type: "motion_verification",
                timestamp: new Date().toISOString(),
                processing_version: "v2.1",
                sport: sport || "general", // Pass sport information to BIM calculation
              },
            }),
          },
        );

        console.log("BIM Response status:", bimResponse.status);

        if (bimResponse.ok) {
          bimResults = await bimResponse.json();
          console.log("BIM Performance calculation successful:", {
            simulationId: bimResults.simulation_id,
            overallScore: bimResults.performance_index?.overall_score,
            tierRecommendation:
              bimResults.tier_assessment?.tier_change_recommended,
          });
        } else {
          const errorText = await bimResponse.text();
          console.error("BIM Performance calculation failed:", {
            status: bimResponse.status,
            statusText: bimResponse.statusText,
            error: errorText,
          });
        }
      } catch (error) {
        console.error("BIM Performance calculation error:", {
          message: error.message,
          stack: error.stack,
          athleteId: targetAthleteId,
          scanId: motionScan[0].id,
        });
        // Continue without BIM results - don't fail the scan
      }
    } else {
      console.log(
        "Scan not verified (score:",
        ai_score,
        "), skipping BIM calculation",
      );
    }

    // Update user profile stats if verified
    if (verificationStatus === "verified") {
      const reputationBonus = bimResults?.tier_assessment
        ?.tier_change_recommended
        ? 20
        : 10;
      await sql`
        UPDATE user_profiles 
        SET reputation_score = reputation_score + ${reputationBonus},
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${targetAthleteId}
      `;
    }

    return Response.json({
      success: true,
      scan: motionScan[0],
      bim_performance: bimResults
        ? {
            performance_index: bimResults.performance_index,
            tier_assessment: bimResults.tier_assessment,
            coaching_insights: bimResults.coaching_insights,
            simulation_id: bimResults.simulation_id,
          }
        : null,
      message: `Motion scan ${verificationStatus} with AI score of ${ai_score}${bimResults ? " - BIM Performance Index calculated" : ""}`,
    });
  } catch (error) {
    console.error("Motion scan creation error:", error);
    return Response.json(
      {
        error: "Failed to create motion scan",
      },
      { status: 500 },
    );
  }
}
