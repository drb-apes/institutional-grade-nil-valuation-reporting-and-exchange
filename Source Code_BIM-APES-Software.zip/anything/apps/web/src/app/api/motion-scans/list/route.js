import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json({ scans: [] });
    }

    const athleteId = userProfile[0].id;

    // Get motion scans for this user
    const scans = await sql`
      SELECT 
        id,
        ai_score,
        verification_status,
        motion_type,
        created_at,
        verified_at,
        scan_data->>'duration' as duration,
        scan_data->>'frame_count' as frame_count
      FROM motion_scans 
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 20
    `;

    return Response.json({
      success: true,
      scans: scans,
    });
  } catch (error) {
    console.error("Motion scan list error:", error);
    return Response.json(
      {
        error: "Failed to fetch motion scans",
      },
      { status: 500 },
    );
  }
}
