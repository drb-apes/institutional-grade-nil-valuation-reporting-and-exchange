import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * BIM-APES INDEX CALCULATION ENGINE
 * Calculate PPI (Player Performance Index), TPI (Team Performance Index), LPI (League Performance Index)
 *
 * Architecture:
 * - Wearable data → Normalized metrics → Index calculation
 * - Real-time index updates with historical baselines
 * - Bull/Bear market detection
 * - Volatility analysis for hedging signals
 */

// Normalize wearable data into standardized metrics
function normalizeWearableData(rawData, deviceType, sport) {
  const normalized = {
    heartRate: null,
    heartRateVariability: null,
    speed: null,
    distance: null,
    acceleration: null,
    powerOutput: null,
    cadence: null,
    impactForce: null,
    fatigue: null,
    consistency: null,
    timestamp: rawData.timestamp,
  };

  // Extract based on device type
  if (deviceType.includes("heart_rate_monitor")) {
    normalized.heartRate = rawData.heart_rate || rawData.hr || rawData.bpm;
    normalized.heartRateVariability =
      rawData.hrv || rawData.heart_rate_variability;
  }

  if (deviceType.includes("gps_tracker")) {
    normalized.speed = rawData.speed || rawData.velocity;
    normalized.distance = rawData.distance || rawData.total_distance;
    normalized.acceleration = rawData.acceleration || rawData.accel;
  }

  if (deviceType.includes("force_plate")) {
    normalized.powerOutput =
      rawData.power || rawData.force * (rawData.velocity || 1);
    normalized.impactForce = rawData.force || rawData.ground_reaction_force;
  }

  if (deviceType.includes("imu_sensor")) {
    normalized.acceleration =
      rawData.acceleration ||
      Math.sqrt(
        Math.pow(rawData.accel_x || 0, 2) +
          Math.pow(rawData.accel_y || 0, 2) +
          Math.pow(rawData.accel_z || 0, 2),
      );
  }

  // Sport-specific calculations
  if (sport === "wrestling") {
    normalized.takedownForce = rawData.takedown_force || rawData.impact_force;
    normalized.grapplingIntensity =
      rawData.grappling_intensity || rawData.contact_intensity;
  }

  if (sport === "basketball" || sport === "soccer") {
    normalized.sprintCount = rawData.sprint_count;
    normalized.jumpHeight = rawData.jump_height || rawData.vertical;
  }

  if (sport === "tennis") {
    normalized.serveSpeed = rawData.serve_speed;
    normalized.shotAccuracy = rawData.shot_accuracy;
  }

  return normalized;
}

// Calculate PPI (Player Performance Index)
function calculatePPI(athleteData, historicalBaseline, sport) {
  const weights = {
    cardiovascular: 0.25,
    power: 0.25,
    consistency: 0.2,
    fatigue: 0.15,
    efficiency: 0.15,
  };

  // Cardiovascular score
  const cardiovascularScore =
    athleteData.heartRate && historicalBaseline.avgHeartRate
      ? Math.min(
          100,
          (historicalBaseline.avgHeartRate / athleteData.heartRate) * 100,
        )
      : 50;

  // Power score
  const powerScore =
    athleteData.powerOutput && historicalBaseline.avgPower
      ? Math.min(
          100,
          (athleteData.powerOutput / historicalBaseline.avgPower) * 100,
        )
      : 50;

  // Consistency score (inverse of coefficient of variation)
  const consistencyScore =
    athleteData.consistency || historicalBaseline.avgConsistency || 70;

  // Fatigue score (inverse - lower fatigue = higher score)
  const fatigueScore = athleteData.fatigue
    ? Math.max(0, 100 - athleteData.fatigue)
    : 70;

  // Efficiency score (HRV-based)
  const efficiencyScore =
    athleteData.heartRateVariability && historicalBaseline.avgHRV
      ? Math.min(
          100,
          (athleteData.heartRateVariability / historicalBaseline.avgHRV) * 100,
        )
      : 60;

  // Weighted PPI
  const ppi =
    cardiovascularScore * weights.cardiovascular +
    powerScore * weights.power +
    consistencyScore * weights.consistency +
    fatigueScore * weights.fatigue +
    efficiencyScore * weights.efficiency;

  // Normalize to 0-100 scale
  return Math.min(100, Math.max(0, ppi));
}

// Calculate TPI (Team Performance Index)
function calculateTPI(teamPPIs, teamSize) {
  if (!teamPPIs || teamPPIs.length === 0) return 50;

  // Weighted average with top performers weighted higher
  const sortedPPIs = [...teamPPIs].sort((a, b) => b - a);

  let weightedSum = 0;
  let totalWeight = 0;

  sortedPPIs.forEach((ppi, idx) => {
    const weight = Math.max(0.5, 1 - idx / (teamSize * 2)); // Top players weighted more
    weightedSum += ppi * weight;
    totalWeight += weight;
  });

  const tpi = weightedSum / totalWeight;

  // Add team cohesion factor (variance penalty)
  const variance =
    sortedPPIs.reduce((sum, ppi) => sum + Math.pow(ppi - tpi, 2), 0) /
    sortedPPIs.length;
  const cohesionFactor = Math.max(0.8, 1 - variance / 1000); // Penalize high variance

  return Math.min(100, Math.max(0, tpi * cohesionFactor));
}

// Calculate LPI (League Performance Index)
function calculateLPI(teamTPIs, leagueSize) {
  if (!teamTPIs || teamTPIs.length === 0) return 50;

  // Market-weighted average
  const avgTPI = teamTPIs.reduce((sum, tpi) => sum + tpi, 0) / teamTPIs.length;

  // Add momentum factor (recent trend)
  const recentTrend =
    teamTPIs.slice(-5).reduce((sum, tpi) => sum + tpi, 0) /
    Math.min(5, teamTPIs.length);
  const momentumFactor = recentTrend > avgTPI ? 1.05 : 0.95;

  const lpi = avgTPI * momentumFactor;

  return Math.min(100, Math.max(0, lpi));
}

// Detect market conditions
function detectMarketCondition(
  currentIndex,
  historicalIndices,
  volatilityWindow = 10,
) {
  if (historicalIndices.length < volatilityWindow) {
    return { condition: "neutral", volatility: 0, trend: "stable" };
  }

  const recentIndices = historicalIndices.slice(-volatilityWindow);
  const avgIndex =
    recentIndices.reduce((sum, val) => sum + val, 0) / recentIndices.length;

  // Calculate volatility (standard deviation)
  const variance =
    recentIndices.reduce((sum, val) => sum + Math.pow(val - avgIndex, 2), 0) /
    recentIndices.length;
  const volatility = Math.sqrt(variance);

  // Detect trend
  const oldAvg =
    recentIndices.slice(0, 5).reduce((sum, val) => sum + val, 0) / 5;
  const newAvg = recentIndices.slice(-5).reduce((sum, val) => sum + val, 0) / 5;
  const trendChange = ((newAvg - oldAvg) / oldAvg) * 100;

  let condition = "neutral";
  let trend = "stable";

  if (trendChange > 5) {
    condition = "bull";
    trend = "rising";
  } else if (trendChange < -5) {
    condition = "bear";
    trend = "declining";
  }

  // High volatility override
  if (volatility > 10) {
    condition = "volatile";
  }

  return {
    condition,
    volatility: parseFloat(volatility.toFixed(2)),
    trend,
    trendChange: parseFloat(trendChange.toFixed(2)),
    currentIndex,
    avgIndex: parseFloat(avgIndex.toFixed(2)),
  };
}

// POST - Calculate indices for athlete/team/league
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      athleteId,
      teamId,
      leagueId,
      sport,
      calculationType, // 'ppi', 'tpi', 'lpi', 'all'
      timeWindow, // hours to look back for data
      includeMarketCondition,
    } = body;

    const type = calculationType || "all";
    const window = timeWindow || 24; // Default 24 hours

    const results = {
      timestamp: new Date().toISOString(),
      calculationType: type,
      indices: {},
    };

    // Calculate PPI
    if ((type === "ppi" || type === "all") && athleteId) {
      // Get recent wearable data for athlete
      const recentData = await sql`
        SELECT 
          wds.raw_data,
          wds.processed_data,
          wds.timestamp,
          wdt.device_category,
          wdt.device_type_id
        FROM wearable_data_streams wds
        JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
        JOIN wearable_device_types wdt ON wd.device_type_id = wdt.device_type_id
        WHERE wd.owner_id = ${athleteId}
          AND wds.timestamp >= NOW() - INTERVAL '${window} hours'
        ORDER BY wds.timestamp DESC
        LIMIT 100
      `;

      if (recentData.length > 0) {
        // Get historical baseline
        const baselineData = await sql`
          SELECT 
            AVG((processed_data->>'heart_rate')::numeric) as avg_heart_rate,
            AVG((processed_data->>'power_output')::numeric) as avg_power,
            AVG((processed_data->>'hrv')::numeric) as avg_hrv,
            AVG((processed_data->>'consistency')::numeric) as avg_consistency
          FROM wearable_data_streams wds
          JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
          WHERE wd.owner_id = ${athleteId}
            AND wds.timestamp >= NOW() - INTERVAL '30 days'
            AND wds.timestamp < NOW() - INTERVAL '${window} hours'
        `;

        const baseline = {
          avgHeartRate: parseFloat(baselineData[0]?.avg_heart_rate || 70),
          avgPower: parseFloat(baselineData[0]?.avg_power || 200),
          avgHRV: parseFloat(baselineData[0]?.avg_hrv || 50),
          avgConsistency: parseFloat(baselineData[0]?.avg_consistency || 70),
        };

        // Normalize latest data
        const latestRaw =
          recentData[0].processed_data || recentData[0].raw_data;
        const normalized = normalizeWearableData(
          latestRaw,
          recentData[0].device_category,
          sport,
        );

        // Calculate PPI
        const ppi = calculatePPI(normalized, baseline, sport);

        // Get historical PPIs for market condition
        let marketCondition = null;
        if (includeMarketCondition) {
          const historicalPPIs = await sql`
            SELECT calculated_index
            FROM (
              SELECT 
                DATE_TRUNC('hour', wds.timestamp) as hour,
                AVG((processed_data->>'ppi')::numeric) as calculated_index
              FROM wearable_data_streams wds
              JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
              WHERE wd.owner_id = ${athleteId}
                AND wds.timestamp >= NOW() - INTERVAL '7 days'
              GROUP BY DATE_TRUNC('hour', wds.timestamp)
              ORDER BY hour DESC
              LIMIT 50
            ) subquery
          `;

          const historicalValues = historicalPPIs.map((row) =>
            parseFloat(row.calculated_index || ppi),
          );
          marketCondition = detectMarketCondition(ppi, historicalValues);
        }

        results.indices.ppi = {
          value: parseFloat(ppi.toFixed(2)),
          baseline,
          currentMetrics: normalized,
          marketCondition,
          dataPoints: recentData.length,
        };
      }
    }

    // Calculate TPI
    if ((type === "tpi" || type === "all") && teamId) {
      // Get all athletes on team
      const teamAthletes = await sql`
        SELECT DISTINCT owner_id
        FROM wearable_devices wd
        JOIN wearable_data_streams wds ON wd.device_uuid = wds.device_uuid
        WHERE wds.session_id LIKE ${teamId + "%"}
          AND wds.timestamp >= NOW() - INTERVAL '${window} hours'
      `;

      if (teamAthletes.length > 0) {
        // Calculate PPI for each athlete (simplified)
        const teamPPIs = [];
        for (const athlete of teamAthletes) {
          const athletePPI = await sql`
            SELECT AVG((processed_data->>'ppi')::numeric) as ppi
            FROM wearable_data_streams wds
            JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
            WHERE wd.owner_id = ${athlete.owner_id}
              AND wds.timestamp >= NOW() - INTERVAL '${window} hours'
          `;

          if (athletePPI[0]?.ppi) {
            teamPPIs.push(parseFloat(athletePPI[0].ppi));
          }
        }

        const tpi = calculateTPI(teamPPIs, teamAthletes.length);

        results.indices.tpi = {
          value: parseFloat(tpi.toFixed(2)),
          athleteCount: teamAthletes.length,
          teamPPIs: teamPPIs.map((p) => parseFloat(p.toFixed(2))),
          avgPPI: parseFloat(
            (teamPPIs.reduce((sum, p) => sum + p, 0) / teamPPIs.length).toFixed(
              2,
            ),
          ),
        };
      }
    }

    // Calculate LPI
    if ((type === "lpi" || type === "all") && leagueId) {
      // Get all teams in league (simplified - using session_id patterns)
      const leagueTeams = await sql`
        SELECT DISTINCT 
          SUBSTRING(session_id FROM 1 FOR POSITION('_' IN session_id) - 1) as team_id,
          AVG((processed_data->>'tpi')::numeric) as team_tpi
        FROM wearable_data_streams
        WHERE session_id LIKE ${leagueId + "%"}
          AND timestamp >= NOW() - INTERVAL '${window} hours'
        GROUP BY SUBSTRING(session_id FROM 1 FOR POSITION('_' IN session_id) - 1)
      `;

      if (leagueTeams.length > 0) {
        const teamTPIs = leagueTeams
          .filter((t) => t.team_tpi)
          .map((t) => parseFloat(t.team_tpi));

        const lpi = calculateLPI(teamTPIs, leagueTeams.length);

        results.indices.lpi = {
          value: parseFloat(lpi.toFixed(2)),
          teamCount: leagueTeams.length,
          teamTPIs: teamTPIs.map((t) => parseFloat(t.toFixed(2))),
          avgTPI: parseFloat(
            (teamTPIs.reduce((sum, t) => sum + t, 0) / teamTPIs.length).toFixed(
              2,
            ),
          ),
        };
      }
    }

    return Response.json({
      success: true,
      ...results,
    });
  } catch (error) {
    console.error("Index calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate indices",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
