/**
 * BIM-APES Player-Level Hedging Calculation Engine
 * Micro hedge for individual athlete performance
 */

/**
 * Calculate Player Performance Index (PPI)
 * Individual athlete composite score
 */
export function calculatePlayerPerformanceIndex(athleteMetrics) {
  if (!athleteMetrics) {
    return { ppi: 100, breakdown: {}, tier: "baseline" };
  }

  const weights = {
    reactionTime: 0.3,
    consistencyIndex: 0.25,
    lapDelta: 0.2,
    fatigueScore: 0.15,
    engagementScore: 0.1,
  };

  const normalized = {
    reactionTime: normalizeReactionTime(athleteMetrics.reactionTime),
    consistencyIndex: athleteMetrics.consistencyIndex || 100,
    lapDelta: normalizeLapDelta(athleteMetrics.lapDelta),
    fatigueScore: normalizeFatigue(athleteMetrics.fatigueScore),
    engagementScore: athleteMetrics.engagementScore || 100,
  };

  let ppi = 0;
  Object.keys(weights).forEach((metric) => {
    if (normalized[metric] !== undefined) {
      ppi += normalized[metric] * weights[metric];
    }
  });

  const tier = determineTier(ppi);

  return {
    ppi: Math.round(ppi * 100) / 100,
    breakdown: normalized,
    weights,
    tier,
    timestamp: new Date().toISOString(),
  };
}

/**
 * Normalize reaction time (lower is better)
 */
function normalizeReactionTime(reactionTimeMs) {
  if (!reactionTimeMs || reactionTimeMs <= 0) return 100;
  const baseline = 200;
  const score = (baseline / reactionTimeMs) * 100;
  return Math.max(0, Math.min(150, score));
}

/**
 * Normalize lap delta (negative is improvement)
 */
function normalizeLapDelta(lapDeltaSeconds) {
  if (lapDeltaSeconds === undefined || lapDeltaSeconds === null) return 100;
  const score = 100 - lapDeltaSeconds * 10;
  return Math.max(0, Math.min(150, score));
}

/**
 * Normalize fatigue score (lower is better)
 */
function normalizeFatigue(fatigueScore) {
  if (fatigueScore === undefined || fatigueScore === null) return 100;
  return Math.max(0, Math.min(100, 100 - fatigueScore));
}

/**
 * Determine performance tier based on PPI
 */
function determineTier(ppi) {
  if (ppi >= 120) return "elite";
  if (ppi >= 110) return "advanced";
  if (ppi >= 100) return "proficient";
  if (ppi >= 90) return "developing";
  return "baseline";
}

/**
 * Calculate player swap pricing (individual NIL swap)
 */
export function calculatePlayerSwapPricing({
  fixedPPI = 100,
  floatingPPI,
  notionalAmount,
  paymentFrequency = "monthly",
  remainingPeriods = 12,
  nilMultiplier = 1.0,
}) {
  const spread = floatingPPI - fixedPPI;
  const periodPayment = (spread / 100) * notionalAmount * nilMultiplier;

  // Calculate present value with athlete-specific risk discount
  const riskPremium = calculateRiskPremium(floatingPPI);
  const discountRate = 0.05 + riskPremium;
  const periodRate =
    discountRate /
    (paymentFrequency === "monthly"
      ? 12
      : paymentFrequency === "weekly"
        ? 52
        : 1);

  let presentValue = 0;
  for (let i = 1; i <= remainingPeriods; i++) {
    presentValue += periodPayment / Math.pow(1 + periodRate, i);
  }

  return {
    fixedLeg: fixedPPI,
    floatingLeg: floatingPPI,
    spread,
    periodPayment: Math.round(periodPayment * 100) / 100,
    presentValue: Math.round(presentValue * 100) / 100,
    notionalAmount,
    nilMultiplier,
    remainingPeriods,
    riskPremium: Math.round(riskPremium * 10000) / 100, // as percentage
    annualizedReturn: ((periodPayment * 12) / notionalAmount) * 100,
  };
}

/**
 * Calculate risk premium based on PPI volatility
 */
function calculateRiskPremium(ppi) {
  if (ppi >= 120) return 0.01; // Elite - low risk
  if (ppi >= 110) return 0.02; // Advanced
  if (ppi >= 100) return 0.03; // Proficient
  if (ppi >= 90) return 0.05; // Developing
  return 0.08; // Baseline - higher risk
}

/**
 * Calculate NIL valuation based on PPI
 */
export function calculateNILValuation({
  ppi,
  baseNILValue = 50000,
  sportMultiplier = 1.0,
  engagementBonus = 0,
  marketFactors = {},
}) {
  // Base NIL scales with PPI
  const ppiMultiplier = ppi / 100;
  let nilValue = baseNILValue * ppiMultiplier * sportMultiplier;

  // Add engagement bonus
  nilValue += engagementBonus;

  // Apply market factors
  const {
    brandDeals = 0,
    socialMediaReach = 0,
    performanceTrend = 0,
    injuryRisk = 0,
  } = marketFactors;

  nilValue += brandDeals;
  nilValue += (socialMediaReach / 1000) * 10; // $10 per 1k followers
  nilValue *= 1 + performanceTrend; // +10% if trending up
  nilValue *= 1 - injuryRisk; // -X% for injury risk

  return {
    totalNILValue: Math.round(nilValue * 100) / 100,
    breakdown: {
      basePPI: Math.round(baseNILValue * ppiMultiplier * 100) / 100,
      sportMultiplier: sportMultiplier,
      engagementBonus,
      brandDeals,
      socialMediaImpact: Math.round((socialMediaReach / 1000) * 10 * 100) / 100,
      performanceTrendImpact:
        Math.round(nilValue * performanceTrend * 100) / 100,
      injuryRiskImpact: Math.round(nilValue * injuryRisk * 100) / 100,
    },
    ppi,
    tier: determineTier(ppi),
  };
}

/**
 * Calculate player-level hedge payout (protection against underperformance)
 */
export function calculatePlayerHedgePayout({
  expectedPPI = 100,
  actualPPI,
  notionalAmount,
  nilValue,
  hedgeType = "performance", // 'performance', 'injury', 'fatigue', 'slump'
  triggerThreshold = 10, // PPI points below expected
}) {
  const ppidrop = expectedPPI - actualPPI;

  if (ppidrop < triggerThreshold) {
    return {
      payout: 0,
      trigger: false,
      reason: `PPI drop (${Math.round(ppidrop * 100) / 100}) below trigger threshold (${triggerThreshold})`,
    };
  }

  // Calculate payout based on hedge type
  let payoutMultiplier = 1.0;
  switch (hedgeType) {
    case "injury":
      payoutMultiplier = 1.5; // Higher payout for injury protection
      break;
    case "fatigue":
      payoutMultiplier = 1.2; // Moderate payout for fatigue
      break;
    case "slump":
      payoutMultiplier = 1.3; // Higher payout for extended slumps
      break;
    default:
      payoutMultiplier = 1.0;
  }

  const ppiDropPercentage = (ppidrop / expectedPPI) * 100;
  let payout = (ppidrop / 100) * notionalAmount * payoutMultiplier;

  // Link to NIL value impact if provided
  if (nilValue) {
    const expectedNIL = nilValue;
    const actualNIL = nilValue * (actualPPI / expectedPPI);
    const nilLoss = expectedNIL - actualNIL;
    payout = Math.max(payout, nilLoss * 0.8); // At least 80% of NIL loss
  }

  return {
    payout: Math.round(payout * 100) / 100,
    trigger: true,
    hedgeType,
    expectedPPI,
    actualPPI,
    ppiDrop: Math.round(ppidrop * 100) / 100,
    ppiDropPercentage: Math.round(ppiDropPercentage * 100) / 100,
    payoutMultiplier,
    nilImpact: nilValue
      ? {
          expectedNIL: Math.round(nilValue * 100) / 100,
          actualNIL:
            Math.round(nilValue * (actualPPI / expectedPPI) * 100) / 100,
          nilLoss:
            Math.round(
              (nilValue - nilValue * (actualPPI / expectedPPI)) * 100,
            ) / 100,
        }
      : null,
  };
}

/**
 * Create basket hedge (portfolio of players)
 */
export function calculateBasketHedge({
  players, // Array of { athleteId, ppi, weight, notional }
  hedgeType = "equal-weighted", // 'equal-weighted', 'ppi-weighted', 'risk-weighted'
  totalNotional,
}) {
  if (!players || players.length === 0) {
    return { error: "No players in basket" };
  }

  let weights = [];

  switch (hedgeType) {
    case "equal-weighted":
      weights = players.map(() => 1 / players.length);
      break;
    case "ppi-weighted":
      const totalPPI = players.reduce((sum, p) => sum + p.ppi, 0);
      weights = players.map((p) => p.ppi / totalPPI);
      break;
    case "risk-weighted":
      const totalRisk = players.reduce(
        (sum, p) => sum + calculateRiskPremium(p.ppi),
        0,
      );
      weights = players.map((p) => calculateRiskPremium(p.ppi) / totalRisk);
      break;
    default:
      weights = players.map(() => 1 / players.length);
  }

  const basketPPI = players.reduce((sum, p, i) => sum + p.ppi * weights[i], 0);
  const allocations = players.map((p, i) => ({
    athleteId: p.athleteId,
    weight: Math.round(weights[i] * 10000) / 100, // as percentage
    notional: Math.round(totalNotional * weights[i] * 100) / 100,
    ppi: p.ppi,
    tier: determineTier(p.ppi),
  }));

  return {
    basketPPI: Math.round(basketPPI * 100) / 100,
    totalNotional,
    hedgeType,
    playerCount: players.length,
    allocations,
    diversificationScore: calculateDiversification(players),
  };
}

/**
 * Calculate diversification score for basket
 */
function calculateDiversification(players) {
  if (players.length <= 1) return 0;

  // Simple diversification: spread across tiers
  const tiers = new Set(players.map((p) => determineTier(p.ppi)));
  const tierDiversity = (tiers.size / 5) * 100; // 5 possible tiers

  return Math.round(tierDiversity * 100) / 100;
}

/**
 * Monitor player position risk
 */
export function monitorPlayerRisk({
  currentPPI,
  historicalPPI = [], // Array of historical PPI values
  expectedPPI = 100,
  volatilityWindow = 10,
}) {
  const recentHistory = historicalPPI.slice(-volatilityWindow);

  if (recentHistory.length < 2) {
    return {
      riskLevel: "unknown",
      volatility: 0,
      trend: "stable",
    };
  }

  // Calculate volatility (standard deviation)
  const mean =
    recentHistory.reduce((sum, ppi) => sum + ppi, 0) / recentHistory.length;
  const variance =
    recentHistory.reduce((sum, ppi) => sum + Math.pow(ppi - mean, 2), 0) /
    recentHistory.length;
  const volatility = Math.sqrt(variance);

  // Determine trend
  const firstHalf = recentHistory.slice(
    0,
    Math.floor(recentHistory.length / 2),
  );
  const secondHalf = recentHistory.slice(Math.floor(recentHistory.length / 2));
  const firstAvg =
    firstHalf.reduce((sum, ppi) => sum + ppi, 0) / firstHalf.length;
  const secondAvg =
    secondHalf.reduce((sum, ppi) => sum + ppi, 0) / secondHalf.length;

  let trend = "stable";
  if (secondAvg > firstAvg + 3) trend = "improving";
  if (secondAvg < firstAvg - 3) trend = "declining";

  // Determine risk level
  let riskLevel = "low";
  if (volatility > 15 || currentPPI < expectedPPI - 10) riskLevel = "high";
  else if (volatility > 8 || currentPPI < expectedPPI - 5) riskLevel = "medium";

  return {
    riskLevel,
    volatility: Math.round(volatility * 100) / 100,
    trend,
    currentPPI,
    expectedPPI,
    deviation: Math.round((currentPPI - expectedPPI) * 100) / 100,
    recentAverage: Math.round(mean * 100) / 100,
    recommendation: generateRiskRecommendation(
      riskLevel,
      trend,
      currentPPI,
      expectedPPI,
    ),
  };
}

/**
 * Generate risk management recommendation
 */
function generateRiskRecommendation(riskLevel, trend, currentPPI, expectedPPI) {
  if (riskLevel === "high" && trend === "declining") {
    return "URGENT: Consider increasing hedge protection or reducing exposure";
  }
  if (riskLevel === "high") {
    return "HIGH RISK: Monitor closely, hedge protection recommended";
  }
  if (riskLevel === "medium" && trend === "declining") {
    return "CAUTION: Watch for further decline, consider partial hedge";
  }
  if (trend === "improving" && currentPPI > expectedPPI) {
    return "POSITIVE: Consider reducing hedge or taking profits";
  }
  return "STABLE: Current hedge levels appropriate";
}
