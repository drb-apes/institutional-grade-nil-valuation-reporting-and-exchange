import {
  calculateLeaguePerformanceScore,
  calculateIndexSwapPricing,
  calculateHedgePayout,
  checkRiskLimits,
} from "../../calculation-engines/index-level-hedging";
import sql from "@/app/api/utils/sql";

/**
 * POST /api/bim-apes/swap-pricing/index-level
 * Calculate index-level (macro) swap pricing
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athleteIds = [], // Optional: specific athletes, or all if empty
      sport = null,
      fixedLPS = 100,
      notionalAmount,
      paymentFrequency = "monthly",
      remainingPeriods = 12,
      calculatePayout = false,
      sponsorId = null,
    } = body;

    if (!notionalAmount || notionalAmount <= 0) {
      return Response.json(
        { error: "Valid notional amount required" },
        { status: 400 },
      );
    }

    // Fetch athlete metrics for league index calculation
    let athleteMetrics = [];

    if (athleteIds.length > 0) {
      // Specific athletes
      const placeholders = athleteIds.map((_, i) => `$${i + 1}`).join(",");
      athleteMetrics = await sql(
        `SELECT 
          id,
          user_id,
          reputation_score as consistencyIndex,
          created_at
        FROM user_profiles
        WHERE id IN (${placeholders}) AND user_type = 'athlete'`,
        athleteIds,
      );
    } else if (sport) {
      // All athletes in a sport (would need sport field in schema)
      athleteMetrics = await sql`
        SELECT 
          id,
          user_id,
          reputation_score as consistencyIndex,
          created_at
        FROM user_profiles
        WHERE user_type = 'athlete'
        LIMIT 100
      `;
    } else {
      // All athletes
      athleteMetrics = await sql`
        SELECT 
          id,
          user_id,
          reputation_score as consistencyIndex,
          created_at
        FROM user_profiles
        WHERE user_type = 'athlete'
        LIMIT 100
      `;
    }

    // Fetch recent biometric data to enhance metrics
    const athleteIdsForBiometrics = athleteMetrics.map((a) => a.id);
    let biometricData = [];

    if (athleteIdsForBiometrics.length > 0) {
      const placeholders = athleteIdsForBiometrics
        .map((_, i) => `$${i + 1}`)
        .join(",");
      biometricData = await sql(
        `SELECT 
          athlete_id,
          scan_data,
          ai_score,
          created_at
        FROM motion_scans
        WHERE athlete_id IN (${placeholders})
        AND verification_status = 'verified'
        ORDER BY created_at DESC`,
        athleteIdsForBiometrics,
      );
    }

    // Merge biometric data with athlete profiles
    const enrichedMetrics = athleteMetrics.map((athlete) => {
      const recentScans = biometricData.filter(
        (b) => b.athlete_id === athlete.id,
      );
      const latestScan = recentScans[0];

      return {
        athleteId: athlete.id,
        consistencyIndex: athlete.consistencyindex || 100,
        reactionTime: latestScan?.scan_data?.reactionTime || 200,
        fatigueScore: latestScan?.scan_data?.fatigueScore || 50,
        lapDelta: latestScan?.scan_data?.lapDelta || 0,
        engagementScore: (athlete.consistencyindex || 100) * 0.8,
      };
    });

    // Calculate League Performance Score
    const lpsResult = calculateLeaguePerformanceScore(enrichedMetrics);
    const floatingLPS = lpsResult.lps;

    // Calculate swap pricing
    const swapPricing = calculateIndexSwapPricing({
      fixedLPS,
      floatingLPS,
      notionalAmount,
      paymentFrequency,
      remainingPeriods,
    });

    // Optional: Calculate hedge payout if requested
    let hedgePayout = null;
    if (calculatePayout) {
      hedgePayout = calculateHedgePayout({
        expectedLPS: fixedLPS,
        actualLPS: floatingLPS,
        notionalAmount,
        maxPayoutCap: notionalAmount * 0.5, // 50% max payout
      });
    }

    // Check risk limits if sponsor provided
    let riskCheck = null;
    if (sponsorId) {
      // Get current exposure for this sponsor
      const existingPositions = await sql`
        SELECT 
          SUM(exposure_amount) as total_exposure
        FROM hedging_positions
        WHERE sponsor_id = ${sponsorId}
        AND hedge_status = 'active'
      `;

      const currentExposure = {
        total: Number(existingPositions[0]?.total_exposure || 0),
      };

      riskCheck = checkRiskLimits({
        currentExposure,
        maxNotionalPerSponsor: 1000000,
        maxTotalNotional: 10000000,
        proposedNotional: notionalAmount,
      });
    }

    return Response.json({
      success: true,
      leaguePerformanceScore: lpsResult,
      swapPricing,
      hedgePayout,
      riskCheck,
      metadata: {
        athleteCount: enrichedMetrics.length,
        sport,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Index swap pricing error:", error);
    return Response.json(
      {
        error: "Failed to calculate index swap pricing",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * GET /api/bim-apes/swap-pricing/index-level
 * Get current league index and pricing snapshot
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get("sport");
    const limit = parseInt(searchParams.get("limit") || "100");

    // Fetch recent athlete data
    let athleteMetrics = await sql`
      SELECT 
        id,
        user_id,
        reputation_score as consistencyIndex
      FROM user_profiles
      WHERE user_type = 'athlete'
      LIMIT ${limit}
    `;

    // Fetch recent biometric data
    const athleteIds = athleteMetrics.map((a) => a.id);
    let biometricData = [];

    if (athleteIds.length > 0) {
      const placeholders = athleteIds.map((_, i) => `$${i + 1}`).join(",");
      biometricData = await sql(
        `SELECT 
          athlete_id,
          scan_data,
          created_at
        FROM motion_scans
        WHERE athlete_id IN (${placeholders})
        AND verification_status = 'verified'
        ORDER BY created_at DESC`,
        athleteIds,
      );
    }

    // Enrich metrics
    const enrichedMetrics = athleteMetrics.map((athlete) => {
      const latestScan = biometricData.find((b) => b.athlete_id === athlete.id);

      return {
        athleteId: athlete.id,
        consistencyIndex: athlete.consistencyindex || 100,
        reactionTime: latestScan?.scan_data?.reactionTime || 200,
        fatigueScore: latestScan?.scan_data?.fatigueScore || 50,
        lapDelta: latestScan?.scan_data?.lapDelta || 0,
        engagementScore: (athlete.consistencyindex || 100) * 0.8,
      };
    });

    const lpsResult = calculateLeaguePerformanceScore(enrichedMetrics);

    return Response.json({
      success: true,
      currentLPS: lpsResult.lps,
      breakdown: lpsResult.breakdown,
      athleteCount: enrichedMetrics.length,
      sport,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Index snapshot error:", error);
    return Response.json(
      { error: "Failed to get index snapshot", details: error.message },
      { status: 500 },
    );
  }
}
