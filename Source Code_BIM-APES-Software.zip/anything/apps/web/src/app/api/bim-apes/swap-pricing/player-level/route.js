import {
  calculatePlayerPerformanceIndex,
  calculatePlayerSwapPricing,
  calculateNILValuation,
  calculatePlayerHedgePayout,
  calculateBasketHedge,
  monitorPlayerRisk,
} from "../../calculation-engines/player-level-hedging";
import sql from "@/app/api/utils/sql";

/**
 * POST /api/bim-apes/swap-pricing/player-level
 * Calculate player-level (micro) swap pricing
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athleteId,
      athleteIds = [], // For basket hedging
      fixedPPI = 100,
      notionalAmount,
      paymentFrequency = "monthly",
      remainingPeriods = 12,
      nilMultiplier = 1.0,
      calculateNIL = true,
      calculatePayout = false,
      hedgeType = "performance",
      basketHedgeType = "equal-weighted",
    } = body;

    // Validate input
    if (!athleteId && athleteIds.length === 0) {
      return Response.json(
        { error: "athleteId or athleteIds required" },
        { status: 400 },
      );
    }

    if (!notionalAmount || notionalAmount <= 0) {
      return Response.json(
        { error: "Valid notional amount required" },
        { status: 400 },
      );
    }

    // Single athlete swap pricing
    if (athleteId) {
      return await handleSingleAthleteSwap({
        athleteId,
        fixedPPI,
        notionalAmount,
        paymentFrequency,
        remainingPeriods,
        nilMultiplier,
        calculateNIL,
        calculatePayout,
        hedgeType,
      });
    }

    // Basket hedge (multiple athletes)
    if (athleteIds.length > 0) {
      return await handleBasketHedge({
        athleteIds,
        totalNotional: notionalAmount,
        basketHedgeType,
      });
    }
  } catch (error) {
    console.error("Player swap pricing error:", error);
    return Response.json(
      {
        error: "Failed to calculate player swap pricing",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * Handle single athlete swap pricing
 */
async function handleSingleAthleteSwap({
  athleteId,
  fixedPPI,
  notionalAmount,
  paymentFrequency,
  remainingPeriods,
  nilMultiplier,
  calculateNIL,
  calculatePayout,
  hedgeType,
}) {
  // Fetch athlete profile
  const athleteProfile = await sql`
    SELECT 
      id,
      user_id,
      reputation_score,
      tier_level,
      created_at
    FROM user_profiles
    WHERE id = ${athleteId} AND user_type = 'athlete'
  `;

  if (athleteProfile.length === 0) {
    return Response.json({ error: "Athlete not found" }, { status: 404 });
  }

  const athlete = athleteProfile[0];

  // Fetch recent biometric data
  const recentScans = await sql`
    SELECT 
      scan_data,
      ai_score,
      created_at
    FROM motion_scans
    WHERE athlete_id = ${athleteId}
    AND verification_status = 'verified'
    ORDER BY created_at DESC
    LIMIT 10
  `;

  const latestScan = recentScans[0];

  const athleteMetrics = {
    reactionTime: latestScan?.scan_data?.reactionTime || 200,
    consistencyIndex: athlete.reputation_score || 100,
    lapDelta: latestScan?.scan_data?.lapDelta || 0,
    fatigueScore: latestScan?.scan_data?.fatigueScore || 50,
    engagementScore: (athlete.reputation_score || 100) * 0.8,
  };

  // Calculate Player Performance Index
  const ppiResult = calculatePlayerPerformanceIndex(athleteMetrics);
  const floatingPPI = ppiResult.ppi;

  // Calculate swap pricing
  const swapPricing = calculatePlayerSwapPricing({
    fixedPPI,
    floatingPPI,
    notionalAmount,
    paymentFrequency,
    remainingPeriods,
    nilMultiplier,
  });

  // Optional: Calculate NIL valuation
  let nilValuation = null;
  if (calculateNIL) {
    // Fetch engagement metrics
    const engagementData = await sql`
      SELECT 
        COUNT(*) as total_actions,
        SUM(pt_token_amount) as total_tokens,
        SUM(engagement_weight) as total_engagement
      FROM fan_engagement_actions
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '30 days'
    `;

    const engagement = engagementData[0] || {};

    nilValuation = calculateNILValuation({
      ppi: floatingPPI,
      baseNILValue: 50000,
      sportMultiplier: 1.0,
      engagementBonus: Number(engagement.total_tokens || 0) * 0.1,
      marketFactors: {
        socialMediaReach: Number(engagement.total_actions || 0) * 100,
        performanceTrend: (floatingPPI - fixedPPI) / 100,
        injuryRisk: latestScan?.scan_data?.injuryRisk || 0,
      },
    });
  }

  // Optional: Calculate hedge payout
  let hedgePayout = null;
  if (calculatePayout) {
    hedgePayout = calculatePlayerHedgePayout({
      expectedPPI: fixedPPI,
      actualPPI: floatingPPI,
      notionalAmount,
      nilValue: nilValuation?.totalNILValue,
      hedgeType,
      triggerThreshold: 10,
    });
  }

  // Calculate risk monitoring
  const historicalPPI = recentScans.map((scan) => {
    const metrics = {
      reactionTime: scan.scan_data?.reactionTime || 200,
      consistencyIndex: athlete.reputation_score || 100,
      lapDelta: scan.scan_data?.lapDelta || 0,
      fatigueScore: scan.scan_data?.fatigueScore || 50,
      engagementScore: (athlete.reputation_score || 100) * 0.8,
    };
    const result = calculatePlayerPerformanceIndex(metrics);
    return result.ppi;
  });

  const riskMonitoring = monitorPlayerRisk({
    currentPPI: floatingPPI,
    historicalPPI,
    expectedPPI: fixedPPI,
    volatilityWindow: 10,
  });

  return Response.json({
    success: true,
    athleteId,
    athleteName: athlete.user_id,
    performanceIndex: ppiResult,
    swapPricing,
    nilValuation,
    hedgePayout,
    riskMonitoring,
    metadata: {
      recentScanCount: recentScans.length,
      tier: athlete.tier_level,
      timestamp: new Date().toISOString(),
    },
  });
}

/**
 * Handle basket hedge (multiple athletes)
 */
async function handleBasketHedge({
  athleteIds,
  totalNotional,
  basketHedgeType,
}) {
  // Fetch all athlete profiles
  const placeholders = athleteIds.map((_, i) => `$${i + 1}`).join(",");
  const athleteProfiles = await sql(
    `SELECT 
      id,
      user_id,
      reputation_score,
      tier_level
    FROM user_profiles
    WHERE id IN (${placeholders}) AND user_type = 'athlete'`,
    athleteIds,
  );

  // Fetch biometric data for all athletes
  const biometricData = await sql(
    `SELECT 
      athlete_id,
      scan_data,
      created_at
    FROM motion_scans
    WHERE athlete_id IN (${placeholders})
    AND verification_status = 'verified'
    ORDER BY created_at DESC`,
    athleteIds,
  );

  // Calculate PPI for each athlete
  const players = athleteProfiles.map((athlete) => {
    const latestScan = biometricData.find((b) => b.athlete_id === athlete.id);

    const metrics = {
      reactionTime: latestScan?.scan_data?.reactionTime || 200,
      consistencyIndex: athlete.reputation_score || 100,
      lapDelta: latestScan?.scan_data?.lapDelta || 0,
      fatigueScore: latestScan?.scan_data?.fatigueScore || 50,
      engagementScore: (athlete.reputation_score || 100) * 0.8,
    };

    const ppiResult = calculatePlayerPerformanceIndex(metrics);

    return {
      athleteId: athlete.id,
      athleteName: athlete.user_id,
      ppi: ppiResult.ppi,
      tier: ppiResult.tier,
    };
  });

  // Calculate basket hedge
  const basketResult = calculateBasketHedge({
    players,
    hedgeType: basketHedgeType,
    totalNotional,
  });

  return Response.json({
    success: true,
    basketHedge: basketResult,
    players,
    timestamp: new Date().toISOString(),
  });
}

/**
 * GET /api/bim-apes/swap-pricing/player-level?athleteId=X
 * Get current player PPI and pricing snapshot
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");

    if (!athleteId) {
      return Response.json({ error: "athleteId required" }, { status: 400 });
    }

    // Fetch athlete and latest scan
    const athleteProfile = await sql`
      SELECT 
        id,
        user_id,
        reputation_score,
        tier_level
      FROM user_profiles
      WHERE id = ${athleteId} AND user_type = 'athlete'
    `;

    if (athleteProfile.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteProfile[0];

    const latestScan = await sql`
      SELECT 
        scan_data,
        ai_score,
        created_at
      FROM motion_scans
      WHERE athlete_id = ${athleteId}
      AND verification_status = 'verified'
      ORDER BY created_at DESC
      LIMIT 1
    `;

    const scan = latestScan[0];

    const metrics = {
      reactionTime: scan?.scan_data?.reactionTime || 200,
      consistencyIndex: athlete.reputation_score || 100,
      lapDelta: scan?.scan_data?.lapDelta || 0,
      fatigueScore: scan?.scan_data?.fatigueScore || 50,
      engagementScore: (athlete.reputation_score || 100) * 0.8,
    };

    const ppiResult = calculatePlayerPerformanceIndex(metrics);

    return Response.json({
      success: true,
      athleteId,
      athleteName: athlete.user_id,
      currentPPI: ppiResult.ppi,
      tier: ppiResult.tier,
      breakdown: ppiResult.breakdown,
      lastUpdated: scan?.created_at || new Date().toISOString(),
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Player snapshot error:", error);
    return Response.json(
      { error: "Failed to get player snapshot", details: error.message },
      { status: 500 },
    );
  }
}
