/**
 * BIM-APES Index-Level Hedging Calculation Engine
 * Macro hedge for league-wide performance
 */

/**
 * Calculate League Performance Score (LPS)
 * Composite index from biometric metrics across all athletes
 */
export function calculateLeaguePerformanceScore(athleteMetrics) {
  if (!athleteMetrics || athleteMetrics.length === 0) {
    return { lps: 100, breakdown: {} };
  }

  const weights = {
    reactionTime: 0.25,
    consistencyIndex: 0.3,
    fatigueScore: 0.2,
    lapDelta: 0.15,
    engagementScore: 0.1,
  };

  let totalScore = 0;
  let totalWeight = 0;
  const breakdown = {};

  // Calculate weighted average across all athletes
  athleteMetrics.forEach((athlete) => {
    const normalized = {
      reactionTime: normalizeReactionTime(athlete.reactionTime),
      consistencyIndex: athlete.consistencyIndex || 100,
      fatigueScore: normalizeFatigue(athlete.fatigueScore),
      lapDelta: normalizeLapDelta(athlete.lapDelta),
      engagementScore: athlete.engagementScore || 100,
    };

    Object.keys(weights).forEach((metric) => {
      if (normalized[metric] !== undefined) {
        totalScore += normalized[metric] * weights[metric];
        totalWeight += weights[metric];
      }
    });
  });

  const lps =
    totalWeight > 0
      ? (totalScore / (totalWeight * athleteMetrics.length)) * 100
      : 100;

  return {
    lps: Math.round(lps * 100) / 100,
    breakdown: {
      athleteCount: athleteMetrics.length,
      weights,
      normalizedMetrics: athleteMetrics.length,
    },
  };
}

/**
 * Normalize reaction time (lower is better, normalize to 0-100 scale)
 * Baseline: 200ms = 100, 150ms = 125, 250ms = 75
 */
function normalizeReactionTime(reactionTimeMs) {
  if (!reactionTimeMs || reactionTimeMs <= 0) return 100;
  const baseline = 200;
  return Math.max(0, Math.min(150, (baseline / reactionTimeMs) * 100));
}

/**
 * Normalize fatigue score (lower is better, invert to 0-100)
 * Fatigue of 0 = 100, Fatigue of 100 = 0
 */
function normalizeFatigue(fatigueScore) {
  if (fatigueScore === undefined || fatigueScore === null) return 100;
  return Math.max(0, Math.min(100, 100 - fatigueScore));
}

/**
 * Normalize lap delta (negative is improvement, normalize to 0-100)
 * -2s delta = 120, 0s = 100, +2s = 80
 */
function normalizeLapDelta(lapDeltaSeconds) {
  if (!lapDeltaSeconds) return 100;
  return Math.max(0, Math.min(150, 100 - lapDeltaSeconds * 10));
}

/**
 * Calculate index swap pricing (fixed vs floating)
 */
export function calculateIndexSwapPricing({
  fixedLPS = 100,
  floatingLPS,
  notionalAmount,
  paymentFrequency = "monthly",
  remainingPeriods = 12,
}) {
  const spread = floatingLPS - fixedLPS;
  const periodPayment = (spread / 100) * notionalAmount;

  // Calculate present value of swap
  const discountRate = 0.05; // 5% annual discount rate
  const periodRate =
    discountRate /
    (paymentFrequency === "monthly"
      ? 12
      : paymentFrequency === "weekly"
        ? 52
        : 1);

  let presentValue = 0;
  for (let i = 1; i <= remainingPeriods; i++) {
    presentValue += periodPayment / Math.pow(1 + periodRate, i);
  }

  return {
    fixedLeg: fixedLPS,
    floatingLeg: floatingLPS,
    spread,
    periodPayment: Math.round(periodPayment * 100) / 100,
    presentValue: Math.round(presentValue * 100) / 100,
    notionalAmount,
    remainingPeriods,
    annualizedReturn: ((periodPayment * 12) / notionalAmount) * 100,
  };
}

/**
 * Calculate hedge payout based on performance drop
 */
export function calculateHedgePayout({
  expectedLPS = 100,
  actualLPS,
  notionalAmount,
  maxPayoutCap = null,
}) {
  if (actualLPS >= expectedLPS) {
    return {
      payout: 0,
      trigger: false,
      reason: "Performance at or above expected level",
    };
  }

  const performanceDrop = expectedLPS - actualLPS;
  const dropPercentage = (performanceDrop / expectedLPS) * 100;
  let payout = (performanceDrop / 100) * notionalAmount;

  if (maxPayoutCap && payout > maxPayoutCap) {
    payout = maxPayoutCap;
  }

  return {
    payout: Math.round(payout * 100) / 100,
    trigger: true,
    expectedLPS,
    actualLPS,
    performanceDrop: Math.round(performanceDrop * 100) / 100,
    dropPercentage: Math.round(dropPercentage * 100) / 100,
    cappedAtMax: maxPayoutCap && payout >= maxPayoutCap,
  };
}

/**
 * Aggregate risk limits and exposure checks
 */
export function checkRiskLimits({
  currentExposure,
  maxNotionalPerSponsor = 1000000,
  maxTotalNotional = 10000000,
  proposedNotional,
}) {
  const newTotalExposure = currentExposure.total + proposedNotional;
  const warnings = [];
  const breaches = [];

  if (newTotalExposure > maxTotalNotional) {
    breaches.push({
      type: "TOTAL_NOTIONAL_BREACH",
      limit: maxTotalNotional,
      proposed: newTotalExposure,
    });
  }

  if (proposedNotional > maxNotionalPerSponsor) {
    breaches.push({
      type: "SPONSOR_NOTIONAL_BREACH",
      limit: maxNotionalPerSponsor,
      proposed: proposedNotional,
    });
  }

  if (newTotalExposure > maxTotalNotional * 0.8) {
    warnings.push({
      type: "APPROACHING_LIMIT",
      utilization: (newTotalExposure / maxTotalNotional) * 100,
    });
  }

  return {
    allowed: breaches.length === 0,
    currentExposure: currentExposure.total,
    proposedExposure: newTotalExposure,
    availableCapacity: maxTotalNotional - currentExposure.total,
    warnings,
    breaches,
  };
}
