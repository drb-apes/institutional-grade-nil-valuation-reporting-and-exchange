import sql from "@/app/api/utils/sql";

/**
 * SPORT-SPECIFIC SCALPING SIGNALS
 * Generates real-time signals for each sport
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const { sport, athleteId, eventData } = body;

    if (!sport || !athleteId || !eventData) {
      return Response.json(
        {
          error: "Missing required fields: sport, athleteId, eventData",
        },
        { status: 400 },
      );
    }

    const signals = await generateSportScalpingSignals(
      sport,
      athleteId,
      eventData,
    );

    // Store signals
    if (signals.signals.length > 0) {
      for (const signal of signals.signals) {
        await sql`
          INSERT INTO scalping_moments (
            athlete_id, moment_type, moment_intensity,
            spotlight_credits, event_window_credits, boost_credits,
            moment_metadata, engagement_spike
          ) VALUES (
            ${athleteId},
            ${signal.type},
            ${signal.intensity},
            ${signal.credits.spotlight},
            ${signal.credits.eventWindow},
            ${signal.credits.boost},
            ${JSON.stringify({ sport, ...signal.metadata })},
            ${signal.engagementSpike}
          )
        `;
      }
    }

    return Response.json(signals);
  } catch (error) {
    console.error("Sport Scalping Error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// Generate sport-specific scalping signals
async function generateSportScalpingSignals(sport, athleteId, eventData) {
  const signals = [];

  switch (sport) {
    case "american_football":
      signals.push(...detectFootballSignals(athleteId, eventData));
      break;
    case "basketball":
      signals.push(...detectBasketballSignals(athleteId, eventData));
      break;
    case "soccer":
      signals.push(...detectSoccerSignals(athleteId, eventData));
      break;
    case "mma":
      signals.push(...detectMMASignals(athleteId, eventData));
      break;
    case "esports":
      signals.push(...detectEsportsSignals(athleteId, eventData));
      break;
    case "goalwrestling":
      signals.push(...detectGoalwrestlingSignals(athleteId, eventData));
      break;
    case "baseball":
      signals.push(...detectBaseballSignals(athleteId, eventData));
      break;
    case "motorcross":
      signals.push(...detectMotocrossSignals(athleteId, eventData));
      break;
    case "wrestling":
      signals.push(...detectWrestlingSignals(athleteId, eventData));
      break;
    default:
      return { success: false, error: "Sport not supported" };
  }

  const totalCredits = signals.reduce((sum, s) => sum + s.credits.spotlight, 0);

  return {
    success: true,
    sport,
    athleteId,
    signalsDetected: signals.length,
    signals,
    aggregated: {
      totalSpotlightCredits: Math.round(totalCredits),
      totalEventWindowCredits: Math.round(totalCredits * 0.5),
      totalBoostCredits: Math.round(totalCredits * 0.3),
      tradingAction: generateTradingAction(totalCredits, signals),
    },
    timestamp: new Date().toISOString(),
  };
}

// AMERICAN FOOTBALL SIGNALS
function detectFootballSignals(athleteId, data) {
  const signals = [];

  // Touchdown signal
  if (data.touchdown) {
    signals.push({
      type: "highlight",
      trigger: "TOUCHDOWN",
      intensity: 0.95,
      credits: { spotlight: 950, eventWindow: 475, boost: 285 },
      engagementSpike: 95,
      metadata: { quarter: data.quarter, yards: data.touchdownYards },
    });
  }

  // Big play (40+ yards)
  if (data.playYards && data.playYards >= 40) {
    signals.push({
      type: "dunk",
      trigger: "BIG_PLAY",
      intensity: Math.min(1, data.playYards / 100),
      credits: {
        spotlight: Math.round(data.playYards * 15),
        eventWindow: Math.round(data.playYards * 7.5),
        boost: Math.round(data.playYards * 4.5),
      },
      engagementSpike: Math.round(data.playYards / 2),
      metadata: { yards: data.playYards, playType: data.playType },
    });
  }

  // Sack (defense)
  if (data.sack) {
    signals.push({
      type: "milestone",
      trigger: "SACK",
      intensity: 0.85,
      credits: { spotlight: 850, eventWindow: 425, boost: 255 },
      engagementSpike: 85,
      metadata: { sackYards: data.sackYards },
    });
  }

  // Interception
  if (data.interception) {
    signals.push({
      type: "highlight",
      trigger: "INTERCEPTION",
      intensity: 0.9,
      credits: { spotlight: 900, eventWindow: 450, boost: 270 },
      engagementSpike: 90,
      metadata: { returnYards: data.returnYards },
    });
  }

  return signals;
}

// BASKETBALL SIGNALS
function detectBasketballSignals(athleteId, data) {
  const signals = [];

  // Hot streak (3+ consecutive made shots)
  if (data.consecutiveMakes && data.consecutiveMakes >= 3) {
    signals.push({
      type: "sprint",
      trigger: "HOT_STREAK",
      intensity: Math.min(1, data.consecutiveMakes / 5),
      credits: {
        spotlight: data.consecutiveMakes * 200,
        eventWindow: data.consecutiveMakes * 100,
        boost: data.consecutiveMakes * 60,
      },
      engagementSpike: data.consecutiveMakes * 20,
      metadata: { makes: data.consecutiveMakes },
    });
  }

  // Triple double
  if (data.tripleDouble) {
    signals.push({
      type: "milestone",
      trigger: "TRIPLE_DOUBLE",
      intensity: 1.0,
      credits: { spotlight: 1000, eventWindow: 500, boost: 300 },
      engagementSpike: 100,
      metadata: { stats: data.tripleDoubleStats },
    });
  }

  // Clutch shot (last 2 minutes, close game)
  if (
    data.clutchShot &&
    data.timeRemaining < 120 &&
    data.scoreDifferential <= 5
  ) {
    signals.push({
      type: "highlight",
      trigger: "CLUTCH_SHOT",
      intensity: 0.95,
      credits: { spotlight: 950, eventWindow: 475, boost: 285 },
      engagementSpike: 95,
      metadata: {
        timeRemaining: data.timeRemaining,
        scoreDiff: data.scoreDifferential,
      },
    });
  }

  return signals;
}

// SOCCER SIGNALS
function detectSoccerSignals(athleteId, data) {
  const signals = [];

  // Goal
  if (data.goal) {
    signals.push({
      type: "highlight",
      trigger: "GOAL",
      intensity: 0.95,
      credits: { spotlight: 950, eventWindow: 475, boost: 285 },
      engagementSpike: 95,
      metadata: { minute: data.minute, goalType: data.goalType },
    });
  }

  // Assist
  if (data.assist) {
    signals.push({
      type: "milestone",
      trigger: "ASSIST",
      intensity: 0.75,
      credits: { spotlight: 750, eventWindow: 375, boost: 225 },
      engagementSpike: 75,
      metadata: { minute: data.minute },
    });
  }

  // Clean sheet (goalkeeper)
  if (data.cleanSheet && data.position === "goalkeeper") {
    signals.push({
      type: "celebration",
      trigger: "CLEAN_SHEET",
      intensity: 0.8,
      credits: { spotlight: 800, eventWindow: 400, boost: 240 },
      engagementSpike: 80,
      metadata: { saves: data.saves },
    });
  }

  return signals;
}

// MMA SIGNALS
function detectMMASignals(athleteId, data) {
  const signals = [];

  // Knockdown
  if (data.knockdown) {
    signals.push({
      type: "dunk",
      trigger: "KNOCKDOWN",
      intensity: 0.9,
      credits: { spotlight: 900, eventWindow: 450, boost: 270 },
      engagementSpike: 90,
      metadata: { round: data.round, timeInRound: data.timeInRound },
    });
  }

  // Submission attempt
  if (data.submissionAttempt) {
    signals.push({
      type: "highlight",
      trigger: "SUBMISSION_ATTEMPT",
      intensity: 0.85,
      credits: { spotlight: 850, eventWindow: 425, boost: 255 },
      engagementSpike: 85,
      metadata: { submissionType: data.submissionType },
    });
  }

  // Round dominance (10-8 or 10-7 score)
  if (
    data.roundScore &&
    (data.roundScore === "10-8" || data.roundScore === "10-7")
  ) {
    signals.push({
      type: "milestone",
      trigger: "ROUND_DOMINANCE",
      intensity: 0.95,
      credits: { spotlight: 950, eventWindow: 475, boost: 285 },
      engagementSpike: 95,
      metadata: { round: data.round, score: data.roundScore },
    });
  }

  return signals;
}

// ESPORTS SIGNALS
function detectEsportsSignals(athleteId, data) {
  const signals = [];

  // Ace (eliminated all opponents)
  if (data.ace) {
    signals.push({
      type: "highlight",
      trigger: "ACE",
      intensity: 1.0,
      credits: { spotlight: 1000, eventWindow: 500, boost: 300 },
      engagementSpike: 100,
      metadata: { game: data.game, round: data.round },
    });
  }

  // Clutch play (1vX situation won)
  if (data.clutch && data.enemiesRemaining >= 3) {
    signals.push({
      type: "dunk",
      trigger: "CLUTCH_PLAY",
      intensity: 0.9,
      credits: { spotlight: 900, eventWindow: 450, boost: 270 },
      engagementSpike: 90,
      metadata: { enemiesEliminated: data.enemiesRemaining },
    });
  }

  // MVP round
  if (data.mvpRound) {
    signals.push({
      type: "celebration",
      trigger: "MVP_ROUND",
      intensity: 0.8,
      credits: { spotlight: 800, eventWindow: 400, boost: 240 },
      engagementSpike: 80,
      metadata: { kda: data.kda },
    });
  }

  return signals;
}

// GOALWRESTLING SIGNALS
function detectGoalwrestlingSignals(athleteId, data) {
  const signals = [];

  // Goal scored
  if (data.goal) {
    signals.push({
      type: "highlight",
      trigger: "GOAL",
      intensity: 0.9,
      credits: { spotlight: 900, eventWindow: 450, boost: 270 },
      engagementSpike: 90,
      metadata: { period: data.period, technique: data.technique },
    });
  }

  // Defensive stop (prevented goal)
  if (data.defensiveStop) {
    signals.push({
      type: "milestone",
      trigger: "DEFENSIVE_STOP",
      intensity: 0.75,
      credits: { spotlight: 750, eventWindow: 375, boost: 225 },
      engagementSpike: 75,
      metadata: { stopType: data.stopType },
    });
  }

  // Momentum shift (comeback from behind)
  if (data.momentumShift && data.scoreDifferentialChange >= 2) {
    signals.push({
      type: "sprint",
      trigger: "MOMENTUM_SHIFT",
      intensity: 0.85,
      credits: { spotlight: 850, eventWindow: 425, boost: 255 },
      engagementSpike: 85,
      metadata: { scoreChange: data.scoreDifferentialChange },
    });
  }

  return signals;
}

// BASEBALL SIGNALS
function detectBaseballSignals(athleteId, data) {
  const signals = [];

  // Home run
  if (data.homeRun) {
    signals.push({
      type: "highlight",
      trigger: "HOME_RUN",
      intensity: 0.95,
      credits: { spotlight: 950, eventWindow: 475, boost: 285 },
      engagementSpike: 95,
      metadata: { inning: data.inning, runners: data.runnersOnBase },
    });
  }

  // Strikeout (pitcher)
  if (data.strikeout && data.role === "pitcher") {
    signals.push({
      type: "milestone",
      trigger: "STRIKEOUT",
      intensity: 0.7,
      credits: { spotlight: 700, eventWindow: 350, boost: 210 },
      engagementSpike: 70,
      metadata: { pitchType: data.pitchType, velocity: data.velocity },
    });
  }

  // Stolen base
  if (data.stolenBase) {
    signals.push({
      type: "sprint",
      trigger: "STOLEN_BASE",
      intensity: 0.75,
      credits: { spotlight: 750, eventWindow: 375, boost: 225 },
      engagementSpike: 75,
      metadata: { base: data.baseStolen },
    });
  }

  return signals;
}

// MOTORCROSS SIGNALS
function detectMotocrossSignals(athleteId, data) {
  const signals = [];

  // Holeshot (first into turn 1)
  if (data.holeshot) {
    signals.push({
      type: "sprint",
      trigger: "HOLESHOT",
      intensity: 0.85,
      credits: { spotlight: 850, eventWindow: 425, boost: 255 },
      engagementSpike: 85,
      metadata: { moto: data.moto },
    });
  }

  // Pass
  if (data.pass) {
    signals.push({
      type: "dunk",
      trigger: "PASS",
      intensity: 0.7,
      credits: { spotlight: 700, eventWindow: 350, boost: 210 },
      engagementSpike: 70,
      metadata: { lap: data.lap, position: data.newPosition },
    });
  }

  // Fastest lap
  if (data.fastestLap) {
    signals.push({
      type: "milestone",
      trigger: "FASTEST_LAP",
      intensity: 0.9,
      credits: { spotlight: 900, eventWindow: 450, boost: 270 },
      engagementSpike: 90,
      metadata: { lapTime: data.lapTime },
    });
  }

  return signals;
}

// WRESTLING SIGNALS
function detectWrestlingSignals(athleteId, data) {
  const signals = [];

  // Pin
  if (data.pin) {
    signals.push({
      type: "highlight",
      trigger: "PIN",
      intensity: 1.0,
      credits: { spotlight: 1000, eventWindow: 500, boost: 300 },
      engagementSpike: 100,
      metadata: { period: data.period, time: data.pinTime },
    });
  }

  // Technical fall (15+ point lead)
  if (data.technicalFall) {
    signals.push({
      type: "milestone",
      trigger: "TECHNICAL_FALL",
      intensity: 0.95,
      credits: { spotlight: 950, eventWindow: 475, boost: 285 },
      engagementSpike: 95,
      metadata: { scoreDifferential: data.scoreDifferential },
    });
  }

  // Comeback (overcame deficit)
  if (data.comeback && data.deficitOvercome >= 5) {
    signals.push({
      type: "celebration",
      trigger: "COMEBACK",
      intensity: 0.9,
      credits: { spotlight: 900, eventWindow: 450, boost: 270 },
      engagementSpike: 90,
      metadata: { deficitOvercome: data.deficitOvercome },
    });
  }

  return signals;
}

// Helper: Generate trading action
function generateTradingAction(totalCredits, signals) {
  const maxIntensity = Math.max(...signals.map((s) => s.intensity), 0);

  if (totalCredits > 800 && maxIntensity > 0.85) {
    return "STRONG SCALP: Multiple high-intensity signals - Execute aggressive micro-trade";
  }
  if (totalCredits > 500) {
    return "SCALP: Good signal strength - Enter position";
  }
  if (totalCredits > 300) {
    return "WATCH: Moderate signals - Wait for confirmation";
  }
  return "HOLD: Signals below threshold";
}
