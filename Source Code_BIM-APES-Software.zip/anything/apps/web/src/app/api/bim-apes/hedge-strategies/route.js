import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * BIM-APES HEDGE STRATEGY EXECUTION ENGINE
 * Execute scalping, arbitrage, and hedging strategies
 *
 * Strategies:
 * 1. SCALPING - Micro-volatility exploitation during games/drills
 * 2. ARBITRAGE - Model NIL vs Market NIL convergence
 * 3. BULL HEDGING - Protect gains during rising indices
 * 4. BEAR HEDGING - Protect against decline
 * 5. INDEX HEDGING - LPI/TPI basket protection
 */

// Execute scalping strategy
async function executeScalping(
  athleteId,
  microVolatility,
  scalpingWindow = 300,
) {
  // Detect micro-volatility spikes (during games)
  const recentPPIs = await sql`
    SELECT 
      timestamp,
      (processed_data->>'ppi')::numeric as ppi
    FROM wearable_data_streams wds
    JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
    WHERE wd.owner_id = ${athleteId}
      AND wds.timestamp >= NOW() - INTERVAL '${scalpingWindow} seconds'
    ORDER BY timestamp DESC
    LIMIT 20
  `;

  if (recentPPIs.length < 5) {
    return {
      strategy: "scalping",
      signal: "insufficient_data",
      action: "wait",
      confidence: 0,
    };
  }

  const ppis = recentPPIs.map((row) => parseFloat(row.ppi));
  const avgPPI = ppis.reduce((sum, val) => sum + val, 0) / ppis.length;
  const variance =
    ppis.reduce((sum, val) => sum + Math.pow(val - avgPPI, 2), 0) / ppis.length;
  const stdDev = Math.sqrt(variance);

  // Scalping threshold - look for quick reversions
  const latestPPI = ppis[0];
  const deviation = latestPPI - avgPPI;
  const zScore = stdDev > 0 ? deviation / stdDev : 0;

  let signal = "neutral";
  let action = "hold";
  let confidence = 50;

  if (zScore > 1.5) {
    // PPI spike - likely to revert down
    signal = "overbought";
    action = "sell_short";
    confidence = Math.min(85, 50 + Math.abs(zScore) * 10);
  } else if (zScore < -1.5) {
    // PPI dip - likely to revert up
    signal = "oversold";
    action = "buy_long";
    confidence = Math.min(85, 50 + Math.abs(zScore) * 10);
  }

  return {
    strategy: "scalping",
    signal,
    action,
    confidence: parseFloat(confidence.toFixed(2)),
    currentPPI: parseFloat(latestPPI.toFixed(2)),
    avgPPI: parseFloat(avgPPI.toFixed(2)),
    zScore: parseFloat(zScore.toFixed(2)),
    expectedReversion: signal !== "neutral" ? avgPPI : latestPPI,
    timeWindow: scalpingWindow,
  };
}

// Execute arbitrage strategy
async function executeArbitrage(
  athleteId,
  modelNIL,
  marketNIL,
  convergenceThreshold = 10,
) {
  const spread = modelNIL - marketNIL;
  const spreadPercentage = marketNIL > 0 ? (spread / marketNIL) * 100 : 0;

  let signal = "neutral";
  let action = "hold";
  let confidence = 50;
  let entryPrice = marketNIL;
  let targetPrice = modelNIL;

  if (Math.abs(spreadPercentage) > convergenceThreshold) {
    if (spreadPercentage > 0) {
      // Model > Market = Undervalued
      signal = "undervalued";
      action = "enter_long";
      confidence = Math.min(90, 50 + spreadPercentage);
    } else {
      // Market > Model = Overvalued
      signal = "overvalued";
      action = "enter_short";
      confidence = Math.min(90, 50 + Math.abs(spreadPercentage));
    }

    // Calculate expected convergence timeline
    const convergenceDays = Math.max(
      1,
      Math.min(30, Math.abs(spreadPercentage) / 2),
    );

    return {
      strategy: "arbitrage",
      signal,
      action,
      confidence: parseFloat(confidence.toFixed(2)),
      entryPrice: parseFloat(entryPrice.toFixed(2)),
      targetPrice: parseFloat(targetPrice.toFixed(2)),
      spread: parseFloat(spread.toFixed(2)),
      spreadPercentage: parseFloat(spreadPercentage.toFixed(2)),
      expectedConvergenceDays: Math.round(convergenceDays),
      potentialProfit: parseFloat(Math.abs(spread).toFixed(2)),
    };
  }

  // Existing position - check for exit
  if (Math.abs(spreadPercentage) < 5) {
    signal = "converged";
    action = "exit_position";
    confidence = 80;
  }

  return {
    strategy: "arbitrage",
    signal,
    action,
    confidence: parseFloat(confidence.toFixed(2)),
    spread: parseFloat(spread.toFixed(2)),
    spreadPercentage: parseFloat(spreadPercentage.toFixed(2)),
  };
}

// Execute bull hedging strategy
async function executeBullHedging(
  athleteId,
  currentPPI,
  historicalPPIs,
  exposureAmount,
) {
  // Bull market = Rising PPI, need to protect gains
  if (historicalPPIs.length < 10) {
    return {
      strategy: "bull_hedging",
      signal: "insufficient_data",
      action: "wait",
    };
  }

  const recentTrend = historicalPPIs.slice(0, 5);
  const olderTrend = historicalPPIs.slice(5, 10);

  const recentAvg =
    recentTrend.reduce((sum, val) => sum + val, 0) / recentTrend.length;
  const olderAvg =
    olderTrend.reduce((sum, val) => sum + val, 0) / olderTrend.length;

  const trendChange = ((recentAvg - olderAvg) / olderAvg) * 100;

  if (trendChange > 5) {
    // Bull market detected - set protective floor
    const protectiveFloor = currentPPI * 0.9; // 10% below current
    const upwardCap = currentPPI * 1.2; // 20% above current (for collar)

    return {
      strategy: "bull_hedging",
      signal: "bull_market",
      action: "set_collar",
      protectiveFloor: parseFloat(protectiveFloor.toFixed(2)),
      upwardCap: parseFloat(upwardCap.toFixed(2)),
      currentPPI: parseFloat(currentPPI.toFixed(2)),
      trendChange: parseFloat(trendChange.toFixed(2)),
      recommendation:
        "Lock in gains with floor at 90% of current PPI, sell upside above 120%",
      exposureProtected: parseFloat((exposureAmount * 0.9).toFixed(2)),
    };
  }

  return {
    strategy: "bull_hedging",
    signal: "neutral",
    action: "monitor",
    trendChange: parseFloat(trendChange.toFixed(2)),
  };
}

// Execute bear hedging strategy
async function executeBearHedging(
  athleteId,
  currentPPI,
  historicalPPIs,
  exposureAmount,
) {
  // Bear market = Declining PPI, need downside protection
  if (historicalPPIs.length < 10) {
    return {
      strategy: "bear_hedging",
      signal: "insufficient_data",
      action: "wait",
    };
  }

  const recentTrend = historicalPPIs.slice(0, 5);
  const olderTrend = historicalPPIs.slice(5, 10);

  const recentAvg =
    recentTrend.reduce((sum, val) => sum + val, 0) / recentTrend.length;
  const olderAvg =
    olderTrend.reduce((sum, val) => sum + val, 0) / olderTrend.length;

  const trendChange = ((recentAvg - olderAvg) / olderAvg) * 100;

  if (trendChange < -5) {
    // Bear market detected - enter protective swap
    const protectiveFloor = currentPPI * 0.85; // 15% below current
    const hedgeCost = exposureAmount * 0.03; // 3% of exposure

    return {
      strategy: "bear_hedging",
      signal: "bear_market",
      action: "enter_protective_swap",
      protectiveFloor: parseFloat(protectiveFloor.toFixed(2)),
      currentPPI: parseFloat(currentPPI.toFixed(2)),
      trendChange: parseFloat(trendChange.toFixed(2)),
      recommendation: "Enter NIL swap to protect against further decline",
      hedgeCost: parseFloat(hedgeCost.toFixed(2)),
      maxLoss: parseFloat((currentPPI - protectiveFloor).toFixed(2)),
      exposureProtected: parseFloat(exposureAmount.toFixed(2)),
    };
  }

  return {
    strategy: "bear_hedging",
    signal: "neutral",
    action: "monitor",
    trendChange: parseFloat(trendChange.toFixed(2)),
  };
}

// Execute index hedging (LPI/TPI basket)
async function executeIndexHedging(
  indexType,
  currentIndex,
  historicalIndices,
  basketSize,
) {
  if (historicalIndices.length < 10) {
    return {
      strategy: "index_hedging",
      signal: "insufficient_data",
      action: "wait",
    };
  }

  const recentTrend = historicalIndices.slice(0, 5);
  const olderTrend = historicalIndices.slice(5, 10);

  const recentAvg =
    recentTrend.reduce((sum, val) => sum + val, 0) / recentTrend.length;
  const olderAvg =
    olderTrend.reduce((sum, val) => sum + val, 0) / olderTrend.length;

  const trendChange = ((recentAvg - olderAvg) / olderAvg) * 100;

  let signal = "neutral";
  let action = "monitor";
  let hedgeRecommendation = null;

  if (trendChange < -10) {
    // Systemic decline - hedge entire basket
    signal = "systemic_decline";
    action = "hedge_basket";
    hedgeRecommendation = `Hedge ${basketSize} athletes in basket against ${indexType} decline`;
  } else if (trendChange > 10) {
    // Systemic rise - reduce hedges, increase exposure
    signal = "systemic_rise";
    action = "reduce_hedges";
    hedgeRecommendation = `Reduce hedges and increase exposure to rising ${indexType}`;
  }

  return {
    strategy: "index_hedging",
    indexType,
    signal,
    action,
    currentIndex: parseFloat(currentIndex.toFixed(2)),
    trendChange: parseFloat(trendChange.toFixed(2)),
    basketSize,
    hedgeRecommendation,
  };
}

// POST - Execute hedge strategy
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      strategyType, // 'scalping', 'arbitrage', 'bull_hedge', 'bear_hedge', 'index_hedge'
      athleteId,
      modelNIL,
      marketNIL,
      exposureAmount,
      indexType, // 'lpi', 'tpi'
      basketSize,
      scalpingWindow,
    } = body;

    if (!strategyType) {
      return Response.json(
        {
          error: "Missing required field: strategyType",
        },
        { status: 400 },
      );
    }

    let strategyResult = null;

    // Execute strategy based on type
    switch (strategyType) {
      case "scalping":
        if (!athleteId) {
          return Response.json(
            { error: "athleteId required for scalping" },
            { status: 400 },
          );
        }

        strategyResult = await executeScalping(athleteId, null, scalpingWindow);
        break;

      case "arbitrage":
        if (!athleteId || modelNIL === undefined || marketNIL === undefined) {
          return Response.json(
            {
              error:
                "athleteId, modelNIL, and marketNIL required for arbitrage",
            },
            { status: 400 },
          );
        }

        strategyResult = await executeArbitrage(athleteId, modelNIL, marketNIL);
        break;

      case "bull_hedge":
        if (!athleteId || !exposureAmount) {
          return Response.json(
            {
              error: "athleteId and exposureAmount required for bull hedging",
            },
            { status: 400 },
          );
        }

        // Get current PPI
        const currentPPIData = await sql`
          SELECT AVG((processed_data->>'ppi')::numeric) as current_ppi
          FROM wearable_data_streams wds
          JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
          WHERE wd.owner_id = ${athleteId}
            AND wds.timestamp >= NOW() - INTERVAL '1 hour'
        `;

        const currentPPI = parseFloat(currentPPIData[0]?.current_ppi || 50);

        // Get historical PPIs
        const historicalPPIData = await sql`
          SELECT 
            DATE_TRUNC('day', wds.timestamp) as day,
            AVG((processed_data->>'ppi')::numeric) as daily_ppi
          FROM wearable_data_streams wds
          JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
          WHERE wd.owner_id = ${athleteId}
            AND wds.timestamp >= NOW() - INTERVAL '14 days'
          GROUP BY DATE_TRUNC('day', wds.timestamp)
          ORDER BY day DESC
        `;

        const historicalPPIs = historicalPPIData.map((row) =>
          parseFloat(row.daily_ppi),
        );

        strategyResult = await executeBullHedging(
          athleteId,
          currentPPI,
          historicalPPIs,
          exposureAmount,
        );
        break;

      case "bear_hedge":
        if (!athleteId || !exposureAmount) {
          return Response.json(
            {
              error: "athleteId and exposureAmount required for bear hedging",
            },
            { status: 400 },
          );
        }

        // Get current PPI
        const bearCurrentPPIData = await sql`
          SELECT AVG((processed_data->>'ppi')::numeric) as current_ppi
          FROM wearable_data_streams wds
          JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
          WHERE wd.owner_id = ${athleteId}
            AND wds.timestamp >= NOW() - INTERVAL '1 hour'
        `;

        const bearCurrentPPI = parseFloat(
          bearCurrentPPIData[0]?.current_ppi || 50,
        );

        // Get historical PPIs
        const bearHistoricalPPIData = await sql`
          SELECT 
            DATE_TRUNC('day', wds.timestamp) as day,
            AVG((processed_data->>'ppi')::numeric) as daily_ppi
          FROM wearable_data_streams wds
          JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
          WHERE wd.owner_id = ${athleteId}
            AND wds.timestamp >= NOW() - INTERVAL '14 days'
          GROUP BY DATE_TRUNC('day', wds.timestamp)
          ORDER BY day DESC
        `;

        const bearHistoricalPPIs = bearHistoricalPPIData.map((row) =>
          parseFloat(row.daily_ppi),
        );

        strategyResult = await executeBearHedging(
          athleteId,
          bearCurrentPPI,
          bearHistoricalPPIs,
          exposureAmount,
        );
        break;

      case "index_hedge":
        if (!indexType || !basketSize) {
          return Response.json(
            {
              error: "indexType and basketSize required for index hedging",
            },
            { status: 400 },
          );
        }

        // Get current index value (simplified)
        const currentIndexData = await sql`
          SELECT AVG((processed_data->>'${indexType}')::numeric) as current_index
          FROM wearable_data_streams
          WHERE timestamp >= NOW() - INTERVAL '1 hour'
        `;

        const currentIndex = parseFloat(
          currentIndexData[0]?.current_index || 50,
        );

        // Get historical indices
        const historicalIndexData = await sql`
          SELECT 
            DATE_TRUNC('day', timestamp) as day,
            AVG((processed_data->>'${indexType}')::numeric) as daily_index
          FROM wearable_data_streams
          WHERE timestamp >= NOW() - INTERVAL '14 days'
          GROUP BY DATE_TRUNC('day', timestamp)
          ORDER BY day DESC
        `;

        const historicalIndices = historicalIndexData.map((row) =>
          parseFloat(row.daily_index),
        );

        strategyResult = await executeIndexHedging(
          indexType,
          currentIndex,
          historicalIndices,
          basketSize,
        );
        break;

      default:
        return Response.json(
          {
            error: `Invalid strategy type: ${strategyType}`,
          },
          { status: 400 },
        );
    }

    return Response.json({
      success: true,
      ...strategyResult,
      executedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Hedge strategy execution error:", error);
    return Response.json(
      {
        error: "Failed to execute hedge strategy",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
