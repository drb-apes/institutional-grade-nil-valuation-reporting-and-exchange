import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * BIM-APES NIL VALUATION ENGINE
 * Calculate Model NIL vs Market NIL for arbitrage opportunities
 *
 * Valuation Factors:
 * - Biometric performance (PPI)
 * - Historical volatility
 * - Engagement metrics
 * - Team success (TPI)
 * - Market sentiment
 * - Sport-specific multipliers
 */

// Calculate Model NIL (fundamental value based on performance)
function calculateModelNIL(ppi, tpi, engagementMetrics, sport, tierLevel) {
  // Base valuation from performance indices
  const performanceValue = (ppi * 0.6 + tpi * 0.4) * 100; // 0-10,000 range

  // Engagement multiplier
  const engagementMultiplier = 1 + engagementMetrics.totalEngagement / 10000;

  // Sport-specific multipliers
  const sportMultipliers = {
    basketball: 1.3,
    football: 1.3,
    baseball: 1.2,
    soccer: 1.2,
    wrestling: 1.0,
    tennis: 1.1,
    track_field: 0.9,
    swimming: 0.8,
  };
  const sportMultiplier = sportMultipliers[sport] || 1.0;

  // Tier multipliers
  const tierMultipliers = {
    tier_1: 0.5,
    tier_2: 1.0,
    tier_3: 2.0,
    tier_4: 4.0,
    tier_5: 8.0,
  };
  const tierMultiplier = tierMultipliers[tierLevel] || 1.0;

  // Model NIL calculation
  const modelNIL =
    performanceValue * engagementMultiplier * sportMultiplier * tierMultiplier;

  return modelNIL;
}

// Calculate Market NIL (current market price)
async function calculateMarketNIL(athleteId) {
  // Get recent sponsor contracts and hedging positions
  const contracts = await sql`
    SELECT SUM(exposure_amount) as total_exposure
    FROM sponsor_contracts
    WHERE athlete_id = ${athleteId}
      AND contract_status = 'active'
  `;

  const hedges = await sql`
    SELECT SUM(ht_token_amount) as total_hedged
    FROM hedging_positions
    WHERE athlete_id = ${athleteId}
      AND hedge_status = 'active'
  `;

  const sponsorExposure = parseFloat(contracts[0]?.total_exposure || 0);
  const hedgedAmount = parseFloat(hedges[0]?.total_hedged || 0);

  // Market NIL is implied from active positions
  const marketNIL = sponsorExposure + hedgedAmount;

  return marketNIL;
}

// Calculate arbitrage opportunity
function calculateArbitrage(modelNIL, marketNIL) {
  const spread = modelNIL - marketNIL;
  const spreadPercentage = marketNIL > 0 ? (spread / marketNIL) * 100 : 0;

  let opportunity = "none";
  let strategy = null;
  let confidence = 0;

  if (spreadPercentage > 15) {
    // Model > Market = Undervalued athlete
    opportunity = "long";
    strategy = "Buy NIL exposure, athlete is undervalued";
    confidence = Math.min(95, 50 + spreadPercentage);
  } else if (spreadPercentage < -15) {
    // Market > Model = Overvalued athlete
    opportunity = "short";
    strategy = "Sell/Hedge NIL exposure, athlete is overvalued";
    confidence = Math.min(95, 50 + Math.abs(spreadPercentage));
  } else if (Math.abs(spreadPercentage) > 5) {
    opportunity = "minor";
    strategy = "Small arbitrage opportunity, monitor closely";
    confidence = 40 + Math.abs(spreadPercentage);
  }

  return {
    opportunity,
    strategy,
    confidence: parseFloat(confidence.toFixed(2)),
    spread: parseFloat(spread.toFixed(2)),
    spreadPercentage: parseFloat(spreadPercentage.toFixed(2)),
    modelNIL: parseFloat(modelNIL.toFixed(2)),
    marketNIL: parseFloat(marketNIL.toFixed(2)),
  };
}

// Calculate volatility (for hedging decisions)
async function calculateVolatility(athleteId, days = 7) {
  // Get historical PPI values
  const historicalPPIs = await sql`
    SELECT 
      DATE_TRUNC('day', wds.timestamp) as day,
      AVG((processed_data->>'ppi')::numeric) as daily_ppi
    FROM wearable_data_streams wds
    JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
    WHERE wd.owner_id = ${athleteId}
      AND wds.timestamp >= NOW() - INTERVAL '${days} days'
    GROUP BY DATE_TRUNC('day', wds.timestamp)
    ORDER BY day DESC
  `;

  if (historicalPPIs.length < 2) {
    return { volatility: 0, stdDev: 0, meanPPI: 0 };
  }

  const ppis = historicalPPIs.map((row) => parseFloat(row.daily_ppi));
  const mean = ppis.reduce((sum, val) => sum + val, 0) / ppis.length;

  const variance =
    ppis.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / ppis.length;
  const stdDev = Math.sqrt(variance);

  // Annualized volatility
  const volatility = stdDev * Math.sqrt(365 / days);

  return {
    volatility: parseFloat(volatility.toFixed(2)),
    stdDev: parseFloat(stdDev.toFixed(2)),
    meanPPI: parseFloat(mean.toFixed(2)),
    dataPoints: ppis.length,
  };
}

// POST - Calculate NIL valuation and arbitrage
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { athleteId, sport, tierLevel, includeVolatility, volatilityDays } =
      body;

    if (!athleteId) {
      return Response.json(
        {
          error: "Missing required field: athleteId",
        },
        { status: 400 },
      );
    }

    // Get athlete profile
    const athleteProfile = await sql`
      SELECT * FROM user_profiles
      WHERE id = ${athleteId} AND user_type = 'athlete'
    `;

    if (athleteProfile.length === 0) {
      return Response.json(
        {
          error: "Athlete not found",
        },
        { status: 404 },
      );
    }

    // Calculate PPI
    const ppiData = await sql`
      SELECT AVG((processed_data->>'ppi')::numeric) as current_ppi
      FROM wearable_data_streams wds
      JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
      WHERE wd.owner_id = ${athleteId}
        AND wds.timestamp >= NOW() - INTERVAL '24 hours'
    `;

    const ppi = parseFloat(ppiData[0]?.current_ppi || 50);

    // Get TPI (if team data available)
    const tpiData = await sql`
      SELECT AVG((processed_data->>'tpi')::numeric) as current_tpi
      FROM wearable_data_streams wds
      WHERE wds.session_id LIKE ${"team_%"}
        AND wds.timestamp >= NOW() - INTERVAL '24 hours'
    `;

    const tpi = parseFloat(tpiData[0]?.current_tpi || 50);

    // Get engagement metrics
    const engagementData = await sql`
      SELECT 
        COUNT(*) as total_engagement,
        SUM(CASE WHEN action_type = 'tip' THEN pt_token_amount ELSE 0 END) as total_tips,
        SUM(CASE WHEN action_type = 'boost' THEN pt_token_amount ELSE 0 END) as total_boosts,
        SUM(CASE WHEN action_type = 'stake' THEN pt_token_amount ELSE 0 END) as total_staked
      FROM fan_engagement_actions
      WHERE athlete_id = ${athleteId}
        AND created_at >= NOW() - INTERVAL '30 days'
    `;

    const engagementMetrics = {
      totalEngagement: parseInt(engagementData[0]?.total_engagement || 0),
      totalTips: parseFloat(engagementData[0]?.total_tips || 0),
      totalBoosts: parseFloat(engagementData[0]?.total_boosts || 0),
      totalStaked: parseFloat(engagementData[0]?.total_staked || 0),
    };

    // Calculate Model NIL
    const modelNIL = calculateModelNIL(
      ppi,
      tpi,
      engagementMetrics,
      sport || "basketball",
      tierLevel || "tier_2",
    );

    // Calculate Market NIL
    const marketNIL = await calculateMarketNIL(athleteId);

    // Calculate arbitrage
    const arbitrage = calculateArbitrage(modelNIL, marketNIL);

    // Calculate volatility if requested
    let volatilityMetrics = null;
    if (includeVolatility) {
      volatilityMetrics = await calculateVolatility(
        athleteId,
        volatilityDays || 7,
      );
    }

    // Generate trading signals
    const signals = {
      hedgeRecommendation: null,
      scalingOpportunity: null,
      riskLevel: "medium",
    };

    if (volatilityMetrics && volatilityMetrics.volatility > 15) {
      signals.hedgeRecommendation =
        "High volatility detected. Consider protective hedging.";
      signals.riskLevel = "high";
    }

    if (arbitrage.opportunity === "long") {
      signals.scalingOpportunity = "Strong buy signal. Increase NIL exposure.";
    } else if (arbitrage.opportunity === "short") {
      signals.scalingOpportunity =
        "Overvalued. Consider reducing exposure or shorting.";
    }

    // Risk-adjusted valuation
    const volatilityDiscount = volatilityMetrics
      ? Math.max(0.8, 1 - volatilityMetrics.volatility / 100)
      : 1.0;

    const riskAdjustedNIL = modelNIL * volatilityDiscount;

    return Response.json({
      success: true,
      athleteId,
      sport: sport || "basketball",
      tierLevel: tierLevel || "tier_2",
      valuation: {
        modelNIL: parseFloat(modelNIL.toFixed(2)),
        marketNIL: parseFloat(marketNIL.toFixed(2)),
        riskAdjustedNIL: parseFloat(riskAdjustedNIL.toFixed(2)),
        valuationGap: parseFloat((modelNIL - marketNIL).toFixed(2)),
      },
      indices: {
        ppi: parseFloat(ppi.toFixed(2)),
        tpi: parseFloat(tpi.toFixed(2)),
      },
      engagement: engagementMetrics,
      arbitrage,
      volatility: volatilityMetrics,
      signals,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("NIL valuation error:", error);
    return Response.json(
      {
        error: "Failed to calculate NIL valuation",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
