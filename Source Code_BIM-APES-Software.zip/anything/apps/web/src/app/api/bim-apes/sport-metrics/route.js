import sql from "@/app/api/utils/sql";

/**
 * SPORT-SPECIFIC PERFORMANCE METRICS ENGINE
 * Calculates specialized metrics for each sport
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const { action, sport, athleteId, metrics } = body;

    switch (action) {
      case "calculate_metrics":
        return Response.json(
          await calculateSportMetrics(sport, athleteId, metrics),
        );

      case "get_sport_profile":
        return Response.json(await getSportProfile(sport));

      case "compare_athletes":
        return Response.json(
          await compareSportAthletes(sport, body.athleteIds),
        );

      default:
        return Response.json({ error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Sport Metrics Error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get("sport");

    if (sport) {
      return Response.json(await getSportProfile(sport));
    }

    return Response.json({
      sports: Object.keys(SPORT_CONFIGS),
      message: "Use ?sport={sport_name} to get specific sport profile",
    });
  } catch (error) {
    console.error("Sport Metrics GET Error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// Sport-Specific Configuration
const SPORT_CONFIGS = {
  american_football: {
    name: "American Football",
    nilMultiplier: 1.4,
    primaryMetrics: [
      "completion_percentage",
      "yards_per_carry",
      "tackles",
      "sacks",
    ],
    secondaryMetrics: ["forty_yard_dash", "vertical_jump", "bench_press"],
    scalpingTriggers: ["touchdown", "interception", "sack", "big_play"],
    riskFactors: [
      "injury_prone_position",
      "contact_frequency",
      "concussion_history",
    ],
    valuationFactors: {
      quarterback: 2.0,
      running_back: 1.3,
      wide_receiver: 1.4,
      defensive_end: 1.2,
      linebacker: 1.1,
      offensive_line: 0.9,
    },
  },

  basketball: {
    name: "Basketball",
    nilMultiplier: 1.5,
    primaryMetrics: [
      "points_per_game",
      "assists",
      "rebounds",
      "field_goal_percentage",
    ],
    secondaryMetrics: [
      "three_point_percentage",
      "free_throw_percentage",
      "plus_minus",
    ],
    scalpingTriggers: [
      "hot_streak",
      "triple_double",
      "clutch_shot",
      "defensive_stop",
    ],
    riskFactors: ["minutes_played", "back_to_back_games", "fatigue_index"],
    valuationFactors: {
      point_guard: 1.3,
      shooting_guard: 1.4,
      small_forward: 1.3,
      power_forward: 1.2,
      center: 1.3,
    },
  },

  soccer: {
    name: "Soccer",
    nilMultiplier: 1.2,
    primaryMetrics: ["goals", "assists", "pass_completion", "distance_covered"],
    secondaryMetrics: ["sprint_speed", "tackles_won", "aerial_duels"],
    scalpingTriggers: ["goal", "assist", "clean_sheet", "penalty_save"],
    riskFactors: ["match_congestion", "yellow_cards", "stamina_decline"],
    valuationFactors: {
      striker: 1.5,
      midfielder: 1.2,
      defender: 1.0,
      goalkeeper: 1.1,
    },
  },

  mma: {
    name: "Mixed Martial Arts",
    nilMultiplier: 1.3,
    primaryMetrics: [
      "strikes_landed",
      "takedown_accuracy",
      "submission_attempts",
      "fight_iq",
    ],
    secondaryMetrics: ["cardio_score", "chin_durability", "ground_game_rating"],
    scalpingTriggers: [
      "knockdown",
      "submission_attempt",
      "round_dominance",
      "fight_finish",
    ],
    riskFactors: [
      "cut_susceptibility",
      "weight_cut_difficulty",
      "injury_recovery_time",
    ],
    valuationFactors: {
      heavyweight: 1.4,
      light_heavyweight: 1.3,
      middleweight: 1.3,
      welterweight: 1.4,
      lightweight: 1.5,
      featherweight: 1.2,
    },
  },

  esports: {
    name: "eSports",
    nilMultiplier: 1.1,
    primaryMetrics: ["kda_ratio", "apm", "accuracy", "game_sense"],
    secondaryMetrics: ["reaction_time", "decision_speed", "clutch_factor"],
    scalpingTriggers: ["ace", "clutch_play", "mvp_round", "comeback"],
    riskFactors: ["burnout_index", "meta_changes", "team_synergy"],
    valuationFactors: {
      fps_player: 1.3,
      moba_player: 1.4,
      rts_player: 1.2,
      fighting_game: 1.1,
      sports_sim: 1.0,
    },
  },

  goalwrestling: {
    name: "Goalwrestling (Tech+Ball)",
    nilMultiplier: 1.0,
    primaryMetrics: [
      "takedown_success",
      "ball_control",
      "scoring_rate",
      "defensive_rating",
    ],
    secondaryMetrics: ["agility_score", "strength_index", "stamina"],
    scalpingTriggers: [
      "goal",
      "defensive_stop",
      "momentum_shift",
      "combo_play",
    ],
    riskFactors: ["hybrid_skill_gap", "adaptation_speed", "injury_rate"],
    valuationFactors: {
      striker: 1.3,
      defender: 1.1,
      all_around: 1.4,
    },
  },

  baseball: {
    name: "Baseball",
    nilMultiplier: 1.3,
    primaryMetrics: [
      "batting_average",
      "era",
      "on_base_percentage",
      "slugging",
    ],
    secondaryMetrics: ["exit_velocity", "spin_rate", "launch_angle"],
    scalpingTriggers: ["home_run", "strikeout", "stolen_base", "diving_catch"],
    riskFactors: [
      "pitcher_arm_health",
      "batter_slump_duration",
      "weather_sensitivity",
    ],
    valuationFactors: {
      pitcher: 1.5,
      catcher: 1.1,
      infielder: 1.2,
      outfielder: 1.3,
      designated_hitter: 1.2,
    },
  },

  motorcross: {
    name: "Motorcross",
    nilMultiplier: 0.9,
    primaryMetrics: [
      "lap_times",
      "jump_consistency",
      "cornering_speed",
      "starts",
    ],
    secondaryMetrics: [
      "endurance",
      "bike_setup_optimization",
      "weather_adaptation",
    ],
    scalpingTriggers: ["holeshot", "pass", "fastest_lap", "podium_finish"],
    riskFactors: ["crash_rate", "injury_severity", "equipment_reliability"],
    valuationFactors: {
      supercross: 1.2,
      motocross: 1.1,
      freestyle: 1.0,
    },
  },

  wrestling: {
    name: "Wrestling",
    nilMultiplier: 1.0,
    primaryMetrics: [
      "takedown_rate",
      "escape_percentage",
      "reversal_rate",
      "pinning_ability",
    ],
    secondaryMetrics: ["stamina", "strength_to_weight", "match_iq"],
    scalpingTriggers: ["pin", "technical_fall", "comeback", "dominance"],
    riskFactors: ["weight_cut_severity", "mat_burn_recovery", "overtraining"],
    valuationFactors: {
      heavyweight: 1.1,
      middleweight: 1.2,
      lightweight: 1.3,
    },
  },
};

// Calculate sport-specific metrics
async function calculateSportMetrics(sport, athleteId, rawMetrics) {
  const config = SPORT_CONFIGS[sport];

  if (!config) {
    return {
      error: `Sport '${sport}' not supported`,
      supportedSports: Object.keys(SPORT_CONFIGS),
    };
  }

  // Get athlete data
  const athlete = await sql`
    SELECT * FROM user_profiles WHERE id = ${athleteId}
  `;

  if (athlete.length === 0) {
    return { error: "Athlete not found" };
  }

  // Calculate sport-specific performance index
  const performanceIndex = calculatePerformanceIndex(sport, rawMetrics);

  // Calculate position multiplier
  const positionMultiplier =
    config.valuationFactors[rawMetrics.position] || 1.0;

  // Calculate risk score
  const riskScore = calculateRiskScore(sport, rawMetrics, config.riskFactors);

  // Calculate NIL impact
  const nilImpact =
    performanceIndex * config.nilMultiplier * positionMultiplier;

  return {
    success: true,
    sport: config.name,
    athleteId,
    metrics: {
      performanceIndex: Math.round(performanceIndex * 100) / 100,
      positionMultiplier: Math.round(positionMultiplier * 100) / 100,
      riskScore: Math.round(riskScore * 100) / 100,
      nilImpact: Math.round(nilImpact * 100) / 100,
    },
    breakdown: {
      primaryMetrics: extractMetrics(rawMetrics, config.primaryMetrics),
      secondaryMetrics: extractMetrics(rawMetrics, config.secondaryMetrics),
      scalpingOpportunities: identifyScalpingOpportunities(
        sport,
        rawMetrics,
        config.scalpingTriggers,
      ),
      riskFactors: assessRiskFactors(sport, rawMetrics, config.riskFactors),
    },
    recommendations: generateSportRecommendations(
      sport,
      performanceIndex,
      riskScore,
    ),
  };
}

// Get sport profile
async function getSportProfile(sport) {
  const config = SPORT_CONFIGS[sport];

  if (!config) {
    return {
      error: `Sport '${sport}' not supported`,
      supportedSports: Object.keys(SPORT_CONFIGS),
    };
  }

  return {
    success: true,
    sport: config.name,
    configuration: {
      nilMultiplier: config.nilMultiplier,
      primaryMetrics: config.primaryMetrics,
      secondaryMetrics: config.secondaryMetrics,
      scalpingTriggers: config.scalpingTriggers,
      riskFactors: config.riskFactors,
      positions: Object.keys(config.valuationFactors),
    },
    valuationFactors: config.valuationFactors,
  };
}

// Compare athletes in same sport
async function compareSportAthletes(sport, athleteIds) {
  const config = SPORT_CONFIGS[sport];

  if (!config) {
    return { error: `Sport '${sport}' not supported` };
  }

  const athletes = await sql`
    SELECT 
      up.*,
      au.name,
      COALESCE(AVG(ms.ai_score), 0) as avg_performance
    FROM user_profiles up
    JOIN auth_users au ON up.user_id = au.id
    LEFT JOIN motion_scans ms ON ms.athlete_id = up.id
    WHERE up.id = ANY(${athleteIds})
    GROUP BY up.id, au.name
  `;

  const comparisons = athletes.map((athlete) => {
    const performanceIndex = parseFloat(athlete.avg_performance);
    const nilImpact = performanceIndex * config.nilMultiplier;

    return {
      athleteId: athlete.id,
      name: athlete.name,
      performanceIndex: Math.round(performanceIndex * 100) / 100,
      nilImpact: Math.round(nilImpact * 100) / 100,
      reputationScore: athlete.reputation_score,
    };
  });

  // Rank athletes
  comparisons.sort((a, b) => b.nilImpact - a.nilImpact);
  comparisons.forEach((comp, index) => {
    comp.rank = index + 1;
  });

  return {
    success: true,
    sport: config.name,
    athletesCompared: comparisons.length,
    comparisons,
    insights: {
      topPerformer: comparisons[0],
      averageNILImpact:
        Math.round(
          (comparisons.reduce((sum, c) => sum + c.nilImpact, 0) /
            comparisons.length) *
            100,
        ) / 100,
      performanceSpread:
        Math.round(
          (comparisons[0].performanceIndex -
            comparisons[comparisons.length - 1].performanceIndex) *
            100,
        ) / 100,
    },
  };
}

// Helper: Calculate performance index
function calculatePerformanceIndex(sport, metrics) {
  const config = SPORT_CONFIGS[sport];
  let index = 100; // Base index

  // Weight primary metrics more heavily
  config.primaryMetrics.forEach((metric) => {
    if (metrics[metric] !== undefined) {
      index += metrics[metric] * 0.5;
    }
  });

  // Add secondary metrics
  config.secondaryMetrics.forEach((metric) => {
    if (metrics[metric] !== undefined) {
      index += metrics[metric] * 0.3;
    }
  });

  return Math.max(0, Math.min(200, index)); // Cap between 0-200
}

// Helper: Calculate risk score
function calculateRiskScore(sport, metrics, riskFactors) {
  let riskScore = 50; // Base risk

  riskFactors.forEach((factor) => {
    if (metrics[factor] !== undefined) {
      riskScore += metrics[factor] * 10;
    }
  });

  return Math.max(0, Math.min(100, riskScore)); // 0-100 scale
}

// Helper: Extract metrics
function extractMetrics(rawMetrics, metricNames) {
  const extracted = {};
  metricNames.forEach((name) => {
    if (rawMetrics[name] !== undefined) {
      extracted[name] = rawMetrics[name];
    }
  });
  return extracted;
}

// Helper: Identify scalping opportunities
function identifyScalpingOpportunities(sport, metrics, triggers) {
  const opportunities = [];

  triggers.forEach((trigger) => {
    if (metrics[trigger] !== undefined && metrics[trigger] > 0) {
      opportunities.push({
        trigger,
        intensity: Math.min(1, metrics[trigger] / 100),
        timestamp: new Date().toISOString(),
      });
    }
  });

  return opportunities;
}

// Helper: Assess risk factors
function assessRiskFactors(sport, metrics, factors) {
  const assessments = {};

  factors.forEach((factor) => {
    if (metrics[factor] !== undefined) {
      let severity = "low";
      if (metrics[factor] > 70) severity = "high";
      else if (metrics[factor] > 40) severity = "medium";

      assessments[factor] = {
        value: metrics[factor],
        severity,
      };
    }
  });

  return assessments;
}

// Helper: Generate recommendations
function generateSportRecommendations(sport, performanceIndex, riskScore) {
  const recommendations = [];

  if (performanceIndex > 150) {
    recommendations.push(
      `${SPORT_CONFIGS[sport].name}: Elite performer - Strong NIL investment candidate`,
    );
  } else if (performanceIndex > 120) {
    recommendations.push(
      `${SPORT_CONFIGS[sport].name}: Above average - Good growth potential`,
    );
  } else if (performanceIndex < 80) {
    recommendations.push(
      `${SPORT_CONFIGS[sport].name}: Below average - High risk investment`,
    );
  }

  if (riskScore > 70) {
    recommendations.push("HIGH RISK: Consider protective hedging strategies");
  } else if (riskScore > 50) {
    recommendations.push("MODERATE RISK: Monitor closely for changes");
  } else {
    recommendations.push("LOW RISK: Stable investment profile");
  }

  return recommendations;
}
