import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get("limit") || "10");

    // Fetch featured athletes with recent activity
    const athletes = await sql`
      SELECT 
        up.id,
        au.name,
        up.user_type,
        
        -- Get total boost count from fan_engagement_actions
        COALESCE((
          SELECT COUNT(*)
          FROM fan_engagement_actions fea
          WHERE fea.athlete_id = up.id
          AND fea.action_type = 'boost'
        ), 0) as total_boosts,
        
        -- Get latest motion scan score
        (
          SELECT ai_score
          FROM motion_scans ms
          WHERE ms.athlete_id = up.id
          AND ms.verification_status = 'verified'
          ORDER BY ms.created_at DESC
          LIMIT 1
        ) as bim_score,
        
        -- Get most recent milestone
        (
          SELECT title
          FROM milestones m
          WHERE m.athlete_id = up.id
          AND m.milestone_status = 'completed'
          ORDER BY m.completed_at DESC
          LIMIT 1
        ) as recent_milestone,
        
        up.created_at
      FROM user_profiles up
      JOIN auth_users au ON au.id = up.user_id
      WHERE up.user_type = 'athlete'
      ORDER BY total_boosts DESC, up.created_at DESC
      LIMIT ${limit}
    `;

    // Format response
    const formattedAthletes = athletes.map((athlete) => ({
      id: athlete.id,
      name: athlete.name || `Athlete ${athlete.id}`,
      sport: "Multi-Sport", // Would come from athlete profile in real system
      position: "Various", // Would come from athlete profile in real system
      totalBoosts: parseInt(athlete.total_boosts || 0),
      bimScore: athlete.bim_score
        ? parseFloat(athlete.bim_score).toFixed(2)
        : null,
      recentMilestone: athlete.recent_milestone,
      createdAt: athlete.created_at,
    }));

    return Response.json(formattedAthletes);
  } catch (error) {
    console.error("Error fetching featured athletes:", error);
    return Response.json(
      { error: "Failed to fetch featured athletes" },
      { status: 500 },
    );
  }
}
