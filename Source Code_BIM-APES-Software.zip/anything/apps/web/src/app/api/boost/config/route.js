// Tenant boost configuration endpoint
export async function GET(request) {
  try {
    // In production, this would query tenant settings from database
    // For now, return a default configuration

    // Example: Different tenants can have different configurations
    const tenantId = request.headers.get("x-tenant-id") || "default";

    // Default configurations by tenant type
    const configs = {
      default: {
        engagement_layer: "free",
        boost_cost: 0,
        boost_credits_per_action: 1,
        features: {
          tap_to_boost: true,
          mega_boost: false,
          milestone_funding: false,
        },
      },
      college_nil: {
        engagement_layer: "fiat",
        boost_cost: "0.10",
        boost_credits_per_action: 1,
        payment_currency: "USD",
        features: {
          tap_to_boost: true,
          mega_boost: true,
          milestone_funding: true,
        },
      },
      web3_league: {
        engagement_layer: "crypto",
        boost_cost: "0.00001",
        boost_credits_per_action: 1,
        payment_currency: "ETH",
        features: {
          tap_to_boost: true,
          mega_boost: true,
          milestone_funding: true,
        },
      },
      high_school: {
        engagement_layer: "free",
        boost_cost: 0,
        boost_credits_per_action: 1,
        features: {
          tap_to_boost: true,
          mega_boost: false,
          milestone_funding: false,
        },
      },
    };

    const config = configs[tenantId] || configs.default;

    return Response.json({
      tenantId,
      ...config,
      tier_system: {
        tier_1: {
          name: "Bronze",
          min_credits: 0,
          multiplier: 1.0,
          color: "#CD7F32",
        },
        tier_2: {
          name: "Silver",
          min_credits: 100,
          multiplier: 1.5,
          color: "#C0C0C0",
        },
        tier_3: {
          name: "Gold",
          min_credits: 500,
          multiplier: 2.0,
          color: "#FFD700",
        },
        vault: {
          name: "Vault",
          min_credits: 2000,
          multiplier: 3.0,
          color: "#9333EA",
        },
      },
    });
  } catch (error) {
    console.error("Error fetching boost config:", error);
    return Response.json(
      { error: "Failed to fetch configuration" },
      { status: 500 },
    );
  }
}
