import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return Response.json({ error: "userId is required" }, { status: 400 });
    }

    // Check if boost balance exists for user
    const existingBalance = await sql`
      SELECT 
        boost_credits,
        free_tier_credits,
        crypto_tier_credits,
        fiat_tier_credits,
        lifetime_free_boosts,
        lifetime_crypto_volume,
        lifetime_fiat_volume,
        current_tier,
        tier_progression,
        created_at,
        updated_at
      FROM boost_credit_balances
      WHERE fan_id = ${userId}
    `;

    if (existingBalance.length > 0) {
      const balance = existingBalance[0];
      return Response.json({
        boostCredits: balance.boost_credits || 0,
        currentTier: balance.current_tier || "tier_1",
        breakdown: {
          free: balance.free_tier_credits || 0,
          crypto: balance.crypto_tier_credits || 0,
          fiat: balance.fiat_tier_credits || 0,
        },
        lifetime: {
          freeBoosts: balance.lifetime_free_boosts || 0,
          cryptoVolume: parseFloat(balance.lifetime_crypto_volume || 0),
          fiatVolume: parseFloat(balance.lifetime_fiat_volume || 0),
        },
        tierProgression: balance.tier_progression || {},
        createdAt: balance.created_at,
        updatedAt: balance.updated_at,
      });
    }

    // Create initial balance if doesn't exist
    await sql`
      INSERT INTO boost_credit_balances (fan_id, boost_credits, current_tier)
      VALUES (${userId}, 0, 'tier_1')
      ON CONFLICT (fan_id) DO NOTHING
    `;

    return Response.json({
      boostCredits: 0,
      currentTier: "tier_1",
      breakdown: { free: 0, crypto: 0, fiat: 0 },
      lifetime: { freeBoosts: 0, cryptoVolume: 0, fiatVolume: 0 },
      tierProgression: {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error fetching boost balance:", error);
    return Response.json(
      { error: "Failed to fetch boost balance" },
      { status: 500 },
    );
  }
}
