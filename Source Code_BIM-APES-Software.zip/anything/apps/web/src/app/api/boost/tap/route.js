import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { fanId, athleteId, paymentLayer, paymentDetails } = body;

    if (!fanId || !athleteId || !paymentLayer) {
      return Response.json(
        { error: "fanId, athleteId, and paymentLayer are required" },
        { status: 400 },
      );
    }

    // Validate payment layer
    if (!["free", "crypto", "fiat"].includes(paymentLayer)) {
      return Response.json({ error: "Invalid payment layer" }, { status: 400 });
    }

    // Get current boost balance
    const balanceResult = await sql`
      SELECT boost_credits, current_tier, free_tier_credits, crypto_tier_credits, fiat_tier_credits
      FROM boost_credit_balances
      WHERE fan_id = ${fanId}
    `;

    let currentBalance = 0;
    let currentTier = "tier_1";
    let freeCredits = 0;
    let cryptoCredits = 0;
    let fiatCredits = 0;

    if (balanceResult.length > 0) {
      currentBalance = balanceResult[0].boost_credits || 0;
      currentTier = balanceResult[0].current_tier || "tier_1";
      freeCredits = balanceResult[0].free_tier_credits || 0;
      cryptoCredits = balanceResult[0].crypto_tier_credits || 0;
      fiatCredits = balanceResult[0].fiat_tier_credits || 0;
    }

    // Process payment based on layer
    let boostCreditsEarned = 1;
    let paymentAmount = 0;
    let paymentCurrency = null;

    if (paymentLayer === "free") {
      // Free tier - no payment required
      boostCreditsEarned = 1;
      freeCredits += 1;
    } else if (paymentLayer === "crypto") {
      // Crypto tier - would integrate with wallet
      // For now, simulate
      boostCreditsEarned = 1;
      paymentAmount = paymentDetails?.amount || 0.00001;
      paymentCurrency = paymentDetails?.currency || "ETH";
      cryptoCredits += 1;
    } else if (paymentLayer === "fiat") {
      // Fiat tier - would integrate with Stripe
      // For now, simulate
      boostCreditsEarned = 1;
      paymentAmount = paymentDetails?.amount || 0.1;
      paymentCurrency = "USD";
      fiatCredits += 1;
    }

    const newBalance = currentBalance + boostCreditsEarned;

    // Calculate tier based on new balance
    const newTier = calculateTier(newBalance);

    // Calculate engagement weight
    const tierMultiplier = getTierMultiplier(newTier);
    const engagementWeight = Math.floor(boostCreditsEarned * tierMultiplier);

    // Use transaction to ensure atomicity
    const result = await sql.transaction([
      // Update boost credit balance
      sql`
        INSERT INTO boost_credit_balances (
          fan_id,
          boost_credits,
          free_tier_credits,
          crypto_tier_credits,
          fiat_tier_credits,
          current_tier,
          updated_at
        )
        VALUES (
          ${fanId},
          ${newBalance},
          ${freeCredits},
          ${cryptoCredits},
          ${fiatCredits},
          ${newTier},
          CURRENT_TIMESTAMP
        )
        ON CONFLICT (fan_id) DO UPDATE SET
          boost_credits = ${newBalance},
          free_tier_credits = ${freeCredits},
          crypto_tier_credits = ${cryptoCredits},
          fiat_tier_credits = ${fiatCredits},
          current_tier = ${newTier},
          updated_at = CURRENT_TIMESTAMP
      `,

      // Record boost action
      sql`
        INSERT INTO boost_actions (
          fan_id,
          athlete_id,
          action_type,
          payment_layer,
          payment_currency,
          payment_amount,
          boost_credits_earned,
          engagement_weight,
          action_context,
          created_at
        )
        VALUES (
          ${fanId},
          ${athleteId},
          'tap_to_boost',
          ${paymentLayer},
          ${paymentCurrency},
          ${paymentAmount},
          ${boostCreditsEarned},
          ${engagementWeight},
          ${JSON.stringify({ source: "mobile_app" })},
          CURRENT_TIMESTAMP
        )
      `,

      // Record fan engagement action (for existing system compatibility)
      sql`
        INSERT INTO fan_engagement_actions (
          fan_id,
          athlete_id,
          action_type,
          pt_token_amount,
          engagement_weight,
          action_metadata,
          created_at
        )
        VALUES (
          ${fanId},
          ${athleteId},
          'boost',
          ${paymentAmount},
          ${engagementWeight},
          ${JSON.stringify({
            boost_credits: boostCreditsEarned,
            payment_layer: paymentLayer,
            tier: newTier,
          })},
          CURRENT_TIMESTAMP
        )
      `,
    ]);

    return Response.json({
      success: true,
      boostCreditsEarned,
      newBalance,
      currentTier: newTier,
      tierUpgrade: newTier !== currentTier,
      engagementWeight,
      athleteReceived: {
        layer: paymentLayer,
        currency: paymentCurrency,
        amount: paymentAmount,
      },
    });
  } catch (error) {
    console.error("Error processing boost:", error);
    return Response.json(
      { error: "Failed to process boost", details: error.message },
      { status: 500 },
    );
  }
}

function calculateTier(boostCredits) {
  if (boostCredits >= 2000) return "vault";
  if (boostCredits >= 500) return "tier_3";
  if (boostCredits >= 100) return "tier_2";
  return "tier_1";
}

function getTierMultiplier(tier) {
  const multipliers = {
    tier_1: 1.0,
    tier_2: 1.5,
    tier_3: 2.0,
    vault: 3.0,
  };
  return multipliers[tier] || 1.0;
}
