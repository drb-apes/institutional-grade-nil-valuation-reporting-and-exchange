import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (
      userProfile.length === 0 ||
      !["institutional", "dao_member"].includes(userProfile[0].user_type)
    ) {
      return Response.json(
        { error: "Club management access required" },
        { status: 403 },
      );
    }

    // Get available invoices for discounting
    const availableInvoices = await sql`
      SELECT 
        id,
        transaction_type,
        amount,
        description,
        reference_type,
        created_at,
        CASE 
          WHEN transaction_type = 'withdrawal' THEN amount * 0.85
          ELSE 0 
        END as discount_value,
        CASE 
          WHEN amount > 50000 THEN 'premium'
          WHEN amount > 20000 THEN 'standard'
          ELSE 'basic'
        END as discount_tier
      FROM treasury_transactions 
      WHERE transaction_type = 'withdrawal'
      AND created_at >= CURRENT_DATE - INTERVAL '30 days'
      ORDER BY amount DESC
    `;

    // Get existing financing partners
    const financingPartners = await sql`
      SELECT * FROM institutional_partners 
      WHERE partner_type = 'payment_processor' 
      AND integration_status = 'active'
    `;

    // AI-driven financing recommendations
    const aiRecommendations = await generateFinancingRecommendations(
      availableInvoices,
      userProfile[0],
    );

    return Response.json({
      success: true,
      invoice_discounting: {
        available_invoices: availableInvoices,
        total_available_value: availableInvoices.reduce(
          (sum, inv) => sum + parseFloat(inv.discount_value),
          0,
        ),
        financing_partners: financingPartners,
        ai_recommendations: aiRecommendations,
        discounting_terms: {
          advance_rate: "70-90%",
          processing_time: "24-48 hours",
          fees: "2-5% of invoice value",
          confidential: true,
        },
      },
    });
  } catch (error) {
    console.error("Invoice discounting error:", error);
    return Response.json(
      { error: "Failed to retrieve invoice data" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { action, invoice_data } = await request.json();

    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (
      userProfile.length === 0 ||
      !["institutional", "dao_member"].includes(userProfile[0].user_type)
    ) {
      return Response.json(
        { error: "Club management access required" },
        { status: 403 },
      );
    }

    if (action === "submit_for_discounting") {
      const { invoice_ids, urgency_level, use_case } = invoice_data;

      // Validate and calculate discount terms
      const selectedInvoices = await sql`
        SELECT * FROM treasury_transactions 
        WHERE id = ANY(${invoice_ids})
        AND transaction_type = 'withdrawal'
      `;

      if (selectedInvoices.length === 0) {
        return Response.json(
          { error: "No valid invoices selected" },
          { status: 400 },
        );
      }

      // Calculate advance amount and terms
      const totalInvoiceValue = selectedInvoices.reduce(
        (sum, inv) => sum + parseFloat(inv.amount),
        0,
      );
      const advanceRate = calculateAdvanceRate(
        totalInvoiceValue,
        urgency_level,
      );
      const advanceAmount = totalInvoiceValue * advanceRate;
      const feeAmount = totalInvoiceValue * 0.035; // 3.5% average fee

      // AI Risk Assessment and Compliance Check
      const riskAssessment = await assessDiscountingRisk(
        selectedInvoices,
        userProfile[0],
      );
      const complianceCheck = await performComplianceCheck(
        selectedInvoices,
        userProfile[0],
      );

      if (!complianceCheck.approved) {
        return Response.json(
          {
            error: "Compliance check failed",
            details: complianceCheck.issues,
          },
          { status: 400 },
        );
      }

      // Create financing record
      const financingRecord = await sql`
        INSERT INTO treasury_transactions (
          transaction_type,
          amount,
          balance_after,
          description,
          reference_type,
          authorized_by
        ) VALUES (
          'deposit',
          ${advanceAmount},
          (SELECT COALESCE(MAX(balance_after), 0) FROM treasury_transactions) + ${advanceAmount},
          ${"Invoice discounting advance for " + selectedInvoices.length + " invoices"},
          'invoice_discounting',
          ${userProfile[0].id}
        )
        RETURNING *
      `;

      // Update user profile with financing activity
      await sql`
        UPDATE user_profiles 
        SET total_contributions = total_contributions + ${advanceAmount},
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${userProfile[0].id}
      `;

      return Response.json({
        success: true,
        financing_approved: true,
        advance_amount: advanceAmount,
        fee_amount: feeAmount,
        advance_rate: advanceRate,
        processing_time: urgency_level === "urgent" ? "24 hours" : "48 hours",
        financing_record: financingRecord[0],
        risk_assessment: riskAssessment,
        compliance_status: complianceCheck,
        repayment_terms: {
          due_date: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000)
            .toISOString()
            .split("T")[0], // 60 days
          total_repayment: totalInvoiceValue,
          confidential_processing: true,
        },
      });
    }

    if (action === "get_financing_options") {
      const financingOptions = await generateFinancingOptions(userProfile[0]);
      return Response.json({
        success: true,
        financing_options: financingOptions,
      });
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Invoice discounting processing error:", error);
    return Response.json(
      { error: "Failed to process invoice discounting request" },
      { status: 500 },
    );
  }
}

async function generateFinancingRecommendations(invoices, userProfile) {
  const totalValue = invoices.reduce(
    (sum, inv) => sum + parseFloat(inv.amount),
    0,
  );

  const recommendations = {
    optimal_selection: [],
    timing_advice: "immediate",
    expected_advance: 0,
    strategic_benefits: [],
  };

  // Select high-value, recent invoices for optimal discounting
  const sortedInvoices = invoices
    .filter((inv) => parseFloat(inv.amount) > 5000)
    .sort((a, b) => parseFloat(b.amount) - parseFloat(a.amount))
    .slice(0, 5);

  recommendations.optimal_selection = sortedInvoices.map((inv) => ({
    id: inv.id,
    amount: inv.amount,
    discount_value: inv.discount_value,
    recommendation_reason:
      parseFloat(inv.amount) > 30000
        ? "High-value optimal for discounting"
        : "Good discounting candidate",
  }));

  recommendations.expected_advance = sortedInvoices.reduce(
    (sum, inv) => sum + parseFloat(inv.discount_value),
    0,
  );

  // Strategic benefits analysis
  if (totalValue > 100000) {
    recommendations.strategic_benefits.push(
      "Significant working capital available",
    );
    recommendations.strategic_benefits.push(
      "Can fund major facility upgrades or player acquisitions",
    );
  }

  if (sortedInvoices.length > 3) {
    recommendations.strategic_benefits.push(
      "Diversified invoice portfolio reduces risk",
    );
  }

  recommendations.strategic_benefits.push(
    "Maintain customer relationships - confidential processing",
  );
  recommendations.strategic_benefits.push(
    "No debt on balance sheet - off-balance-sheet financing",
  );

  return recommendations;
}

function calculateAdvanceRate(totalValue, urgencyLevel) {
  let baseRate = 0.8; // 80% base advance rate

  // Adjust for invoice value
  if (totalValue > 100000) baseRate += 0.05;
  else if (totalValue > 50000) baseRate += 0.02;

  // Adjust for urgency
  if (urgencyLevel === "urgent") baseRate -= 0.05; // Slight reduction for urgent processing

  return Math.min(baseRate, 0.9); // Cap at 90%
}

async function assessDiscountingRisk(invoices, userProfile) {
  const totalValue = invoices.reduce(
    (sum, inv) => sum + parseFloat(inv.amount),
    0,
  );
  const avgInvoiceAge =
    invoices.reduce((sum, inv) => {
      const ageInDays =
        (new Date() - new Date(inv.created_at)) / (1000 * 60 * 60 * 24);
      return sum + ageInDays;
    }, 0) / invoices.length;

  let riskScore = 0;

  // Age risk
  if (avgInvoiceAge > 30) riskScore += 20;
  else if (avgInvoiceAge > 14) riskScore += 10;

  // Value concentration risk
  if (totalValue > userProfile.total_contributions * 2) riskScore += 25;

  // User reputation risk
  if (userProfile.reputation_score < 50) riskScore += 15;

  return {
    risk_score: riskScore,
    risk_level: riskScore > 50 ? "high" : riskScore > 25 ? "medium" : "low",
    risk_factors: [
      ...(avgInvoiceAge > 30
        ? ["Older invoice portfolio increases payment risk"]
        : []),
      ...(totalValue > userProfile.total_contributions * 2
        ? ["High value relative to historical activity"]
        : []),
      ...(userProfile.reputation_score < 50 ? ["Limited credit history"] : []),
    ],
    mitigation_strategies:
      riskScore > 50
        ? [
            "Consider smaller advance amount",
            "Request additional payment guarantees",
            "Shorter repayment terms",
          ]
        : [],
  };
}

async function performComplianceCheck(invoices, userProfile) {
  const complianceIssues = [];

  // GDPR compliance for biometric/financial data
  if (!userProfile.wallet_address) {
    complianceIssues.push(
      "Digital wallet verification required for financial transactions",
    );
  }

  // AML/KYC checks
  const totalValue = invoices.reduce(
    (sum, inv) => sum + parseFloat(inv.amount),
    0,
  );

  if (totalValue > 50000 && userProfile.tier_level < 2) {
    complianceIssues.push(
      "Enhanced KYC verification required for high-value transactions",
    );
  }

  // Data privacy compliance
  const auditLog = {
    timestamp: new Date().toISOString(),
    user_id: userProfile.user_id,
    action: "invoice_discounting_compliance_check",
    data_processed: "financial_transaction_data",
    gdpr_consent: true,
    retention_period: "7_years",
  };

  return {
    approved: complianceIssues.length === 0,
    issues: complianceIssues,
    audit_log: auditLog,
    data_protection_status: "compliant",
    regulatory_framework: ["GDPR", "PCI_DSS", "AML_Directive"],
  };
}

async function generateFinancingOptions(userProfile) {
  return {
    selective_invoice_discounting: {
      available: true,
      advance_rate: "70-90%",
      processing_time: "24-48 hours",
      confidential: true,
      recommended: userProfile.total_contributions > 10000,
    },
    asset_based_lending: {
      available: userProfile.tier_level >= 2,
      advance_rate: "60-80%",
      processing_time: "5-7 days",
      collateral_required: true,
    },
    revenue_based_financing: {
      available: userProfile.total_earnings > 25000,
      advance_rate: "2-6x monthly revenue",
      processing_time: "7-14 days",
      revenue_share: "2-10%",
    },
    traditional_credit_line: {
      available: userProfile.reputation_score > 70,
      credit_limit: "Based on financial assessment",
      processing_time: "10-21 days",
      personal_guarantee_required: true,
    },
  };
}
