import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { action, query_data } = await request.json();

    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (
      userProfile.length === 0 ||
      !["institutional", "dao_member"].includes(userProfile[0].user_type)
    ) {
      return Response.json(
        { error: "Club management access required" },
        { status: 403 },
      );
    }

    if (action === "financial_analysis") {
      const financialAnalysis = await performComprehensiveFinancialAnalysis(
        userProfile[0],
      );
      return Response.json({
        success: true,
        ai_analysis: financialAnalysis,
      });
    }

    if (action === "strategic_recommendations") {
      const { time_horizon, investment_goals, risk_tolerance } = query_data;
      const strategicRecommendations = await generateStrategicRecommendations(
        userProfile[0],
        time_horizon,
        investment_goals,
        risk_tolerance,
      );
      return Response.json({
        success: true,
        strategic_recommendations: strategicRecommendations,
      });
    }

    if (action === "compliance_monitoring") {
      const complianceReport = await performComplianceMonitoring(
        userProfile[0],
      );
      return Response.json({
        success: true,
        compliance_report: complianceReport,
      });
    }

    if (action === "risk_assessment") {
      const riskAssessment = await performRiskAssessment(userProfile[0]);
      return Response.json({
        success: true,
        risk_assessment: riskAssessment,
      });
    }

    if (action === "capital_optimization") {
      const optimizationPlan = await generateCapitalOptimizationPlan(
        userProfile[0],
      );
      return Response.json({
        success: true,
        optimization_plan: optimizationPlan,
      });
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("AI Financial Advisor error:", error);
    return Response.json(
      { error: "Failed to process AI analysis" },
      { status: 500 },
    );
  }
}

async function performComprehensiveFinancialAnalysis(userProfile) {
  // Get comprehensive financial data
  const [treasuryData, transactionHistory, performanceMetrics] =
    await sql.transaction([
      sql`
      SELECT 
        SUM(CASE WHEN transaction_type IN ('deposit', 'dao_allocation') THEN amount ELSE -amount END) as current_balance,
        COUNT(*) as total_transactions,
        AVG(amount) as avg_transaction_size
      FROM treasury_transactions
      WHERE created_at >= CURRENT_DATE - INTERVAL '90 days'
    `,
      sql`
      SELECT 
        transaction_type,
        COUNT(*) as frequency,
        SUM(amount) as total_amount,
        AVG(amount) as avg_amount
      FROM treasury_transactions
      WHERE created_at >= CURRENT_DATE - INTERVAL '90 days'
      GROUP BY transaction_type
    `,
      sql`
      SELECT 
        COUNT(*) as athlete_count,
        AVG(total_contributions) as avg_contribution,
        SUM(total_earnings) as total_platform_earnings
      FROM user_profiles
      WHERE user_type = 'athlete'
    `,
    ]);

  const analysis = {
    financial_health_score: calculateFinancialHealthScore(
      treasuryData[0],
      transactionHistory,
    ),
    cash_flow_analysis: analyzeCashFlow(transactionHistory),
    liquidity_assessment: assessLiquidity(treasuryData[0]),
    growth_metrics: calculateGrowthMetrics(transactionHistory),
    efficiency_ratios: calculateEfficiencyRatios(
      treasuryData[0],
      performanceMetrics[0],
    ),
    ai_insights: generateAIInsights(
      treasuryData[0],
      transactionHistory,
      performanceMetrics[0],
    ),
    timestamp: new Date().toISOString(),
  };

  return analysis;
}

async function generateStrategicRecommendations(
  userProfile,
  timeHorizon,
  investmentGoals,
  riskTolerance,
) {
  const financialData = await sql`
    SELECT 
      SUM(CASE WHEN transaction_type IN ('deposit', 'dao_allocation') THEN amount ELSE -amount END) as balance,
      COUNT(*) as transaction_count
    FROM treasury_transactions
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
  `;

  const recommendations = {
    strategic_priorities: [],
    investment_opportunities: [],
    capital_allocation: {},
    timeline: timeHorizon,
    risk_mitigation: [],
    expected_outcomes: {},
  };

  const currentBalance = parseFloat(financialData[0].balance);

  // Strategic priorities based on goals and capital
  if (investmentGoals.includes("player_development")) {
    recommendations.strategic_priorities.push({
      priority: "High",
      action: "Player Development Investment",
      allocation: Math.min(currentBalance * 0.3, 50000),
      expected_roi: "15-25% performance improvement",
      timeline: "6-12 months",
    });
  }

  if (investmentGoals.includes("facility_upgrade")) {
    recommendations.strategic_priorities.push({
      priority: "Medium",
      action: "Facility Infrastructure Enhancement",
      allocation: Math.min(currentBalance * 0.4, 100000),
      expected_roi: "Long-term operational efficiency",
      timeline: "12-24 months",
    });
  }

  if (investmentGoals.includes("technology_integration")) {
    recommendations.strategic_priorities.push({
      priority: "High",
      action: "AI Technology Integration",
      allocation: Math.min(currentBalance * 0.2, 30000),
      expected_roi: "20-40% operational efficiency gain",
      timeline: "3-6 months",
    });
  }

  // Investment opportunities based on risk tolerance
  if (riskTolerance === "aggressive") {
    recommendations.investment_opportunities.push({
      type: "Performance Trading",
      description: "AI-driven athlete performance asset trading",
      potential_return: "25-45% annual",
      risk_level: "High",
      recommended_allocation: currentBalance * 0.15,
    });
  }

  if (riskTolerance === "moderate") {
    recommendations.investment_opportunities.push({
      type: "Coalition Diversification",
      description: "Multi-sport athlete portfolio development",
      potential_return: "12-20% annual",
      risk_level: "Medium",
      recommended_allocation: currentBalance * 0.25,
    });
  }

  if (riskTolerance === "conservative") {
    recommendations.investment_opportunities.push({
      type: "Revenue Stabilization",
      description: "Long-term sponsorship and partnership agreements",
      potential_return: "8-15% annual",
      risk_level: "Low",
      recommended_allocation: currentBalance * 0.35,
    });
  }

  // Capital allocation strategy
  recommendations.capital_allocation = {
    operating_expenses: currentBalance * 0.3,
    growth_investments: currentBalance * 0.4,
    emergency_reserves: currentBalance * 0.2,
    strategic_opportunities: currentBalance * 0.1,
  };

  // Risk mitigation strategies
  recommendations.risk_mitigation = [
    "Maintain 3-6 months operating expenses in reserve",
    "Diversify revenue streams across multiple sports/athletes",
    "Implement real-time financial monitoring with AI alerts",
    "Regular compliance audits for regulatory adherence",
  ];

  // Expected outcomes
  recommendations.expected_outcomes = {
    financial_growth: `${timeHorizon === "short" ? "15-25%" : "30-50%"} increase in club valuation`,
    operational_efficiency: "25-40% improvement in resource utilization",
    competitive_advantage: "Enhanced athlete performance and retention",
    market_position: "Top-tier status in target sports categories",
  };

  return recommendations;
}

async function performComplianceMonitoring(userProfile) {
  const recentTransactions = await sql`
    SELECT * FROM treasury_transactions
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
    ORDER BY created_at DESC
  `;

  const complianceReport = {
    gdpr_compliance: {
      status: "compliant",
      data_processing_audits: [],
      consent_management: "active",
      data_retention_policies: "enforced",
    },
    financial_compliance: {
      aml_status: "compliant",
      kyc_verification: "current",
      transaction_monitoring: "active",
      suspicious_activity: [],
    },
    biometric_data_compliance: {
      storage_encryption: "AES-256",
      access_controls: "role_based",
      consent_tracking: "granular",
      data_minimization: "enforced",
    },
    regulatory_frameworks: {
      gdpr: checkGDPRCompliance(recentTransactions),
      pci_dss: checkPCICompliance(recentTransactions),
      sox_compliance:
        userProfile.tier_level >= 3 ? "applicable" : "not_applicable",
    },
    audit_trail: {
      last_audit: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      next_scheduled: new Date(
        Date.now() + 60 * 24 * 60 * 60 * 1000,
      ).toISOString(),
      automated_monitoring: "enabled",
    },
    recommendations: generateComplianceRecommendations(
      recentTransactions,
      userProfile,
    ),
  };

  return complianceReport;
}

async function performRiskAssessment(userProfile) {
  const [financialData, performanceData] = await sql.transaction([
    sql`
      SELECT 
        transaction_type,
        amount,
        created_at
      FROM treasury_transactions
      WHERE created_at >= CURRENT_DATE - INTERVAL '90 days'
      ORDER BY created_at DESC
    `,
    sql`
      SELECT 
        asset_value,
        roi_projection,
        risk_score
      FROM asset_simulations
      WHERE athlete_id = ${userProfile.id}
      AND created_at >= CURRENT_DATE - INTERVAL '30 days'
    `,
  ]);

  const riskAssessment = {
    overall_risk_score: calculateOverallRiskScore(
      financialData,
      performanceData,
      userProfile,
    ),
    risk_categories: {
      financial_risk: assessFinancialRisk(financialData),
      operational_risk: assessOperationalRisk(userProfile),
      market_risk: assessMarketRisk(performanceData),
      compliance_risk: assessComplianceRisk(userProfile),
      technology_risk: assessTechnologyRisk(userProfile),
    },
    risk_mitigation_plan: generateRiskMitigationPlan(
      financialData,
      performanceData,
      userProfile,
    ),
    monitoring_alerts: {
      critical_thresholds: defineCriticalThresholds(userProfile),
      automated_alerts: "enabled",
      escalation_procedures: "defined",
    },
    stress_testing: {
      scenario_1: "30% revenue decline",
      scenario_2: "Major athlete injury/departure",
      scenario_3: "Regulatory change impact",
      recovery_strategies: [
        "Emergency funding",
        "Asset liquidation",
        "Insurance claims",
      ],
    },
  };

  return riskAssessment;
}

async function generateCapitalOptimizationPlan(userProfile) {
  const currentFinancials = await sql`
    SELECT 
      SUM(CASE WHEN transaction_type IN ('deposit', 'dao_allocation') THEN amount ELSE -amount END) as current_balance,
      AVG(amount) as avg_transaction
    FROM treasury_transactions
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
  `;

  const optimizationPlan = {
    current_capital_efficiency: calculateCapitalEfficiency(
      currentFinancials[0],
      userProfile,
    ),
    optimization_opportunities: [
      {
        area: "Working Capital Management",
        current_efficiency: "72%",
        potential_improvement: "15-20%",
        implementation: "Automated invoice discounting triggers",
      },
      {
        area: "Investment Portfolio Rebalancing",
        current_efficiency: "68%",
        potential_improvement: "25-30%",
        implementation: "AI-driven portfolio optimization",
      },
      {
        area: "Operational Cost Reduction",
        current_efficiency: "75%",
        potential_improvement: "10-15%",
        implementation: "Process automation and efficiency gains",
      },
    ],
    capital_allocation_model: {
      high_liquidity_reserve: "20%",
      growth_investments: "35%",
      operational_expenses: "30%",
      strategic_reserves: "15%",
    },
    performance_targets: {
      roi_improvement: "20-35%",
      cost_reduction: "10-15%",
      cash_flow_optimization: "25-40%",
      timeline: "6-12 months",
    },
    implementation_roadmap: generateImplementationRoadmap(),
  };

  return optimizationPlan;
}

// Helper functions for calculations and analysis

function calculateFinancialHealthScore(treasuryData, transactionHistory) {
  let score = 50; // Base score

  const balance = parseFloat(treasuryData.current_balance);
  const avgTransaction = parseFloat(treasuryData.avg_transaction_size);

  // Balance health
  if (balance > 100000) score += 25;
  else if (balance > 50000) score += 15;
  else if (balance > 10000) score += 5;
  else score -= 15;

  // Transaction diversity
  const transactionTypes = transactionHistory.length;
  if (transactionTypes >= 3) score += 15;
  else if (transactionTypes >= 2) score += 10;

  // Activity level
  if (treasuryData.total_transactions > 20) score += 10;
  else if (treasuryData.total_transactions > 10) score += 5;

  return Math.max(0, Math.min(100, score));
}

function analyzeCashFlow(transactionHistory) {
  const inflows = transactionHistory.filter((t) =>
    ["deposit", "dao_allocation"].includes(t.transaction_type),
  );
  const outflows = transactionHistory.filter((t) =>
    ["withdrawal", "distribution"].includes(t.transaction_type),
  );

  return {
    net_cash_flow:
      inflows.reduce((sum, t) => sum + parseFloat(t.total_amount), 0) -
      outflows.reduce((sum, t) => sum + parseFloat(t.total_amount), 0),
    inflow_consistency: calculateConsistency(inflows),
    outflow_pattern: analyzeOutflowPattern(outflows),
    cash_conversion_cycle: calculateCashConversionCycle(inflows, outflows),
  };
}

function generateComplianceRecommendations(transactions, userProfile) {
  const recommendations = [];

  const highValueTransactions = transactions.filter(
    (t) => parseFloat(t.amount) > 50000,
  );
  if (highValueTransactions.length > 0) {
    recommendations.push(
      "Enhanced KYC verification recommended for high-value transactions",
    );
  }

  if (userProfile.tier_level >= 3) {
    recommendations.push(
      "Consider SOX compliance implementation for institutional-grade operations",
    );
  }

  recommendations.push("Regular GDPR compliance audits scheduled quarterly");
  recommendations.push("Automated biometric data retention policy enforcement");

  return recommendations;
}

function checkGDPRCompliance(transactions) {
  return {
    data_processing_lawfulness: "confirmed",
    consent_mechanism: "granular_opt_in",
    data_subject_rights: "implemented",
    data_protection_impact_assessment: "current",
    privacy_by_design: "enabled",
  };
}

function checkPCICompliance(transactions) {
  return {
    secure_network: "maintained",
    cardholder_data_protection: "encrypted",
    vulnerability_management: "current",
    access_control: "strong_authentication",
    network_monitoring: "continuous",
  };
}

function generateImplementationRoadmap() {
  return {
    phase_1: {
      duration: "Months 1-2",
      objectives: [
        "Implement automated risk monitoring",
        "Optimize working capital processes",
      ],
      deliverables: ["Risk dashboard", "Invoice discounting automation"],
    },
    phase_2: {
      duration: "Months 3-4",
      objectives: ["Portfolio rebalancing", "Compliance automation"],
      deliverables: ["AI portfolio manager", "Compliance monitoring system"],
    },
    phase_3: {
      duration: "Months 5-6",
      objectives: ["Performance optimization", "Strategic growth initiatives"],
      deliverables: [
        "Optimized capital allocation",
        "Growth investment execution",
      ],
    },
  };
}

function calculateOverallRiskScore(
  financialData,
  performanceData,
  userProfile,
) {
  // Simplified risk calculation
  let riskScore = 30; // Base risk

  // Financial volatility
  const amounts = financialData.map((t) => parseFloat(t.amount));
  const variance = calculateVariance(amounts);
  if (variance > 10000) riskScore += 20;

  // Performance risk
  const avgRiskScore =
    performanceData.reduce((sum, p) => sum + parseFloat(p.risk_score), 0) /
    performanceData.length;
  riskScore += avgRiskScore || 0;

  return Math.min(100, riskScore);
}

function calculateVariance(numbers) {
  if (numbers.length === 0) return 0;
  const mean = numbers.reduce((sum, n) => sum + n, 0) / numbers.length;
  return (
    numbers.reduce((sum, n) => sum + Math.pow(n - mean, 2), 0) / numbers.length
  );
}

function assessFinancialRisk(financialData) {
  return {
    liquidity_risk: "low",
    credit_risk: "medium",
    market_risk: "medium",
    operational_risk: "low",
  };
}

function assessOperationalRisk(userProfile) {
  return {
    key_person_risk: userProfile.tier_level < 2 ? "high" : "medium",
    process_risk: "low",
    technology_risk: "low",
    regulatory_risk: "medium",
  };
}

function assessMarketRisk(performanceData) {
  return {
    performance_volatility: "medium",
    competitive_pressure: "medium",
    industry_trends: "positive",
    economic_sensitivity: "low",
  };
}

function assessComplianceRisk(userProfile) {
  return {
    regulatory_compliance: "low",
    data_privacy: "low",
    financial_reporting: userProfile.tier_level >= 3 ? "medium" : "low",
    operational_compliance: "low",
  };
}

function assessTechnologyRisk(userProfile) {
  return {
    system_availability: "low",
    data_security: "low",
    technology_obsolescence: "medium",
    integration_risk: "low",
  };
}

function generateRiskMitigationPlan(
  financialData,
  performanceData,
  userProfile,
) {
  return {
    immediate_actions: [
      "Implement real-time monitoring alerts",
      "Establish emergency funding protocols",
      "Update insurance coverage review",
    ],
    medium_term_strategies: [
      "Diversify revenue streams",
      "Strengthen operational processes",
      "Enhance compliance frameworks",
    ],
    long_term_initiatives: [
      "Build strategic reserves",
      "Develop alternative funding sources",
      "Create comprehensive risk management framework",
    ],
  };
}

function defineCriticalThresholds(userProfile) {
  return {
    cash_balance_minimum: userProfile.total_contributions * 0.1,
    transaction_volume_spike: 200, // % increase
    risk_score_maximum: 75,
    compliance_score_minimum: 85,
  };
}

function calculateCapitalEfficiency(financials, userProfile) {
  const balance = parseFloat(financials.current_balance);
  const totalContributions = userProfile.total_contributions;

  return {
    capital_utilization: (totalContributions / Math.max(balance, 1)) * 100,
    return_on_assets:
      (userProfile.total_earnings / Math.max(totalContributions, 1)) * 100,
    working_capital_turnover: financials.avg_transaction / Math.max(balance, 1),
  };
}

function calculateConsistency(transactions) {
  if (transactions.length < 2) return "insufficient_data";

  const amounts = transactions.map((t) => parseFloat(t.total_amount));
  const mean = amounts.reduce((sum, a) => sum + a, 0) / amounts.length;
  const variance =
    amounts.reduce((sum, a) => sum + Math.pow(a - mean, 2), 0) / amounts.length;
  const coefficient = Math.sqrt(variance) / mean;

  if (coefficient < 0.2) return "highly_consistent";
  if (coefficient < 0.5) return "moderately_consistent";
  return "inconsistent";
}

function analyzeOutflowPattern(outflows) {
  return {
    frequency: outflows.reduce((sum, t) => sum + t.frequency, 0),
    average_size:
      outflows.reduce((sum, t) => sum + parseFloat(t.avg_amount), 0) /
      outflows.length,
    pattern: "regular_operational",
  };
}

function calculateCashConversionCycle(inflows, outflows) {
  // Simplified calculation
  const avgInflowTime = 30; // days
  const avgOutflowTime = 15; // days
  return avgInflowTime - avgOutflowTime;
}

function assessLiquidity(treasuryData) {
  const balance = parseFloat(treasuryData.current_balance);

  return {
    current_liquidity: balance,
    liquidity_ratio: balance / Math.max(treasuryData.avg_transaction_size, 1),
    liquidity_status:
      balance > 50000
        ? "excellent"
        : balance > 20000
          ? "good"
          : balance > 5000
            ? "adequate"
            : "low",
    days_of_operations: Math.floor(
      balance / Math.max(treasuryData.avg_transaction_size, 1),
    ),
  };
}

function calculateGrowthMetrics(transactionHistory) {
  const totalVolume = transactionHistory.reduce(
    (sum, t) => sum + parseFloat(t.total_amount),
    0,
  );
  const avgTransactionSize =
    totalVolume / Math.max(transactionHistory.length, 1);

  return {
    transaction_growth_rate: transactionHistory.length > 5 ? "15%" : "8%",
    volume_growth_rate: totalVolume > 100000 ? "25%" : "12%",
    average_transaction_growth: avgTransactionSize > 10000 ? "18%" : "10%",
    growth_momentum: "positive",
  };
}

function calculateEfficiencyRatios(treasuryData, performanceData) {
  const balance = parseFloat(treasuryData.current_balance);
  const avgEarnings =
    parseFloat(performanceData.total_platform_earnings) /
    Math.max(performanceData.athlete_count, 1);

  return {
    asset_turnover:
      treasuryData.total_transactions / Math.max(balance / 1000, 1),
    earnings_efficiency: avgEarnings / Math.max(balance / 1000, 1),
    operational_efficiency:
      treasuryData.avg_transaction_size / Math.max(balance / 100, 1),
    capital_productivity:
      (avgEarnings * performanceData.athlete_count) / Math.max(balance, 1),
  };
}

function generateAIInsights(treasuryData, transactionHistory, performanceData) {
  const insights = [];
  const balance = parseFloat(treasuryData.current_balance);

  // Balance insights
  if (balance > 100000) {
    insights.push(
      "Excellent capital position enables strategic growth investments",
    );
  } else if (balance < 10000) {
    insights.push(
      "Consider immediate working capital solutions to maintain operational flexibility",
    );
  }

  // Transaction pattern insights
  const highValueTransactions = transactionHistory.filter(
    (t) => parseFloat(t.total_amount) > 50000,
  );
  if (highValueTransactions.length > 0) {
    insights.push(
      "High-value transaction activity indicates strong business scale",
    );
  }

  // Performance insights
  if (performanceData.athlete_count > 10) {
    insights.push(
      "Diversified athlete portfolio provides stable revenue foundation",
    );
  }

  // Growth insights
  if (performanceData.total_platform_earnings > 250000) {
    insights.push(
      "Platform earnings demonstrate strong monetization efficiency",
    );
  }

  return {
    key_insights: insights,
    recommended_actions: [
      "Optimize working capital allocation",
      "Consider automated investment strategies",
      "Implement real-time financial monitoring",
    ],
    growth_opportunities: [
      "Expand athlete development programs",
      "Enhance technology infrastructure",
      "Develop strategic partnerships",
    ],
  };
}
