import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (
      userProfile.length === 0 ||
      !["institutional", "dao_member"].includes(userProfile[0].user_type)
    ) {
      return Response.json(
        { error: "Club management access required" },
        { status: 403 },
      );
    }

    // Get club financial overview
    const [
      treasuryBalance,
      recentTransactions,
      activeInvoices,
      cashFlowProjection,
    ] = await sql.transaction([
      sql`
        SELECT 
          COALESCE(SUM(CASE WHEN transaction_type IN ('deposit', 'dao_allocation') THEN amount ELSE -amount END), 0) as current_balance
        FROM treasury_transactions
        WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
      `,
      sql`
        SELECT * FROM treasury_transactions 
        ORDER BY created_at DESC 
        LIMIT 10
      `,
      sql`
        SELECT 
          COUNT(*) as total_invoices,
          COALESCE(SUM(amount), 0) as total_value,
          AVG(amount) as avg_invoice_value
        FROM treasury_transactions 
        WHERE transaction_type = 'withdrawal' 
        AND created_at >= CURRENT_DATE - INTERVAL '7 days'
      `,
      sql`
        SELECT 
          DATE_TRUNC('week', created_at) as week,
          SUM(CASE WHEN transaction_type IN ('deposit', 'dao_allocation') THEN amount ELSE -amount END) as net_flow
        FROM treasury_transactions
        WHERE created_at >= CURRENT_DATE - INTERVAL '12 weeks'
        GROUP BY DATE_TRUNC('week', created_at)
        ORDER BY week DESC
      `,
    ]);

    // AI Financial Analysis
    const aiInsights = generateFinancialInsights(
      treasuryBalance[0],
      recentTransactions,
      cashFlowProjection,
    );

    return Response.json({
      success: true,
      financial_overview: {
        current_balance: treasuryBalance[0].current_balance,
        recent_transactions: recentTransactions,
        invoice_metrics: activeInvoices[0],
        cash_flow_trend: cashFlowProjection,
        ai_insights: aiInsights,
        last_updated: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Capital management error:", error);
    return Response.json(
      { error: "Failed to retrieve financial data" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { action, transaction_data } = await request.json();

    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (
      userProfile.length === 0 ||
      !["institutional", "dao_member"].includes(userProfile[0].user_type)
    ) {
      return Response.json(
        { error: "Club management access required" },
        { status: 403 },
      );
    }

    if (action === "create_transaction") {
      const { transaction_type, amount, description, reference_type } =
        transaction_data;

      // Get current balance
      const currentBalance = await sql`
        SELECT 
          COALESCE(SUM(CASE WHEN transaction_type IN ('deposit', 'dao_allocation') THEN amount ELSE -amount END), 0) as balance
        FROM treasury_transactions
      `;

      const newBalance =
        parseFloat(currentBalance[0].balance) +
        (["deposit", "dao_allocation"].includes(transaction_type)
          ? parseFloat(amount)
          : -parseFloat(amount));

      // Create transaction record
      const transaction = await sql`
        INSERT INTO treasury_transactions (
          transaction_type,
          amount,
          balance_after,
          description,
          reference_type,
          authorized_by
        ) VALUES (
          ${transaction_type},
          ${amount},
          ${newBalance},
          ${description},
          ${reference_type || "manual"},
          ${userProfile[0].id}
        )
        RETURNING *
      `;

      // AI Risk Assessment
      const riskAssessment = await analyzeTransactionRisk(
        transaction[0],
        newBalance,
      );

      return Response.json({
        success: true,
        transaction: transaction[0],
        new_balance: newBalance,
        risk_assessment: riskAssessment,
        compliance_status: "approved",
      });
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Transaction creation error:", error);
    return Response.json(
      { error: "Failed to process transaction" },
      { status: 500 },
    );
  }
}

function generateFinancialInsights(balance, transactions, cashFlow) {
  const insights = {
    cash_flow_health: "stable",
    recommendations: [],
    risk_factors: [],
    opportunities: [],
  };

  // Cash flow analysis
  const avgWeeklyFlow =
    cashFlow.reduce((sum, week) => sum + parseFloat(week.net_flow), 0) /
    cashFlow.length;

  if (avgWeeklyFlow < 0) {
    insights.cash_flow_health = "declining";
    insights.risk_factors.push("Negative weekly cash flow trend detected");
    insights.recommendations.push(
      "Consider invoice discounting for immediate working capital",
    );
  }

  // Balance analysis
  const currentBalance = parseFloat(balance.current_balance);

  if (currentBalance < 10000) {
    insights.risk_factors.push(
      "Low cash reserves - consider working capital solutions",
    );
    insights.recommendations.push(
      "Explore selective invoice discounting options",
    );
  }

  if (currentBalance > 100000) {
    insights.opportunities.push(
      "Excess cash available for strategic investments",
    );
    insights.recommendations.push(
      "Consider player development or facility upgrades",
    );
  }

  // Transaction pattern analysis
  const recentWithdrawals = transactions.filter(
    (t) => t.transaction_type === "withdrawal",
  ).length;

  if (recentWithdrawals > 5) {
    insights.recommendations.push(
      "High expense frequency - review budget optimization",
    );
  }

  return insights;
}

async function analyzeTransactionRisk(transaction, newBalance) {
  const riskScore = calculateRiskScore(transaction, newBalance);

  return {
    risk_score: riskScore,
    risk_level: riskScore > 70 ? "high" : riskScore > 40 ? "medium" : "low",
    compliance_flags: [],
    recommended_actions:
      riskScore > 70
        ? ["Review with financial advisor", "Consider alternative funding"]
        : [],
  };
}

function calculateRiskScore(transaction, balance) {
  let score = 0;

  // Large transaction risk
  if (parseFloat(transaction.amount) > 50000) score += 30;
  else if (parseFloat(transaction.amount) > 20000) score += 15;

  // Low balance risk
  if (balance < 5000) score += 40;
  else if (balance < 15000) score += 20;

  // Transaction type risk
  if (transaction.transaction_type === "withdrawal") score += 10;

  return Math.min(score, 100);
}
