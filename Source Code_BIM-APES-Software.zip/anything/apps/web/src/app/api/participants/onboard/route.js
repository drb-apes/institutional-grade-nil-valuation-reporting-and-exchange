import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      participantId,
      entityType,
      region,
      complianceTier,
      verificationStatus = "pending",
      organizationName,
      contactInfo,
      tradingCapacity,
      riskProfile,
    } = body;

    // Validate required fields
    if (!participantId || !entityType || !region || !complianceTier) {
      return Response.json(
        {
          error:
            "Missing required fields: participantId, entityType, region, complianceTier",
        },
        { status: 400 },
      );
    }

    // Validate enum values
    const validEntityTypes = ["institutional", "retail", "scout"];
    const validRegions = ["US", "EU", "APAC"];
    const validComplianceTiers = ["LSOC", "DoddFrank", "MiFIDII"];
    const validStatuses = ["pending", "verified"];

    if (!validEntityTypes.includes(entityType)) {
      return Response.json({ error: "Invalid entityType" }, { status: 400 });
    }

    if (!validRegions.includes(region)) {
      return Response.json({ error: "Invalid region" }, { status: 400 });
    }

    if (!validComplianceTiers.includes(complianceTier)) {
      return Response.json(
        { error: "Invalid complianceTier" },
        { status: 400 },
      );
    }

    if (!validStatuses.includes(verificationStatus)) {
      return Response.json(
        { error: "Invalid verificationStatus" },
        { status: 400 },
      );
    }

    // Check if participant already exists
    const existingParticipant = await sql`
      SELECT id FROM institutional_partners 
      WHERE api_credentials->>'participant_id' = ${participantId}
    `;

    if (existingParticipant.length > 0) {
      return Response.json(
        {
          error: "Participant already exists",
          participantId: participantId,
        },
        { status: 409 },
      );
    }

    // Determine integration status based on verification
    const integrationStatus =
      verificationStatus === "verified" ? "active" : "pending";

    // Create coalition participant record
    const participant = await sql`
      INSERT INTO institutional_partners (
        partner_name,
        partner_type,
        integration_status,
        api_credentials,
        service_offerings
      ) VALUES (
        ${organizationName || `${entityType}_${participantId}`},
        'coalition_participant',
        ${integrationStatus},
        ${JSON.stringify({
          participant_id: participantId,
          entity_type: entityType,
          region: region,
          compliance_tier: complianceTier,
          verification_status: verificationStatus,
          api_version: "v1",
          onboarded_at: new Date().toISOString(),
          scopes: [
            "biometric.read",
            "biometric.write",
            "coalition.verify",
            "trade.execute",
            "simulation.run",
          ],
        })},
        ${JSON.stringify({
          biometric_signals: true,
          trade_execution: entityType === "institutional",
          coalition_voting: true,
          simulation_access: true,
          transparency_tier: getTransparencyTier(complianceTier),
          risk_profile: riskProfile || "medium",
          trading_capacity:
            tradingCapacity || getDefaultTradingCapacity(entityType),
        })}
      ) RETURNING *
    `;

    // Create initial digital wallet for participant
    const wallet = await sql`
      INSERT INTO digital_wallets (
        user_id,
        wallet_type,
        balance,
        wallet_settings
      ) VALUES (
        ${session.user.id},
        'institutional',
        0,
        ${JSON.stringify({
          participant_id: participantId,
          entity_type: entityType,
          region: region,
          compliance_tier: complianceTier,
          auto_rebalancing: true,
          risk_limits: getRiskLimits(entityType, complianceTier),
        })}
      ) RETURNING *
    `;

    // Initialize biometric signal access
    const signalAccess = await initializeBiometricSignalAccess(
      participantId,
      entityType,
      complianceTier,
    );

    // Generate API credentials and access tokens
    const credentials = generateAPICredentials(
      participantId,
      entityType,
      complianceTier,
    );

    return Response.json({
      success: true,
      participant: {
        participantId: participantId,
        entityType: entityType,
        region: region,
        complianceTier: complianceTier,
        verificationStatus: verificationStatus,
        integrationStatus: integrationStatus,
        onboardingDate: new Date().toISOString(),
        transparencyPhase: getTransparencyPhase(complianceTier),
        apiVersion: "v1",
      },
      credentials: credentials,
      services: {
        biometric_signals: true,
        trade_execution: entityType === "institutional",
        coalition_voting: true,
        simulation_access: true,
        heatmap_generation: true,
        candlestick_visualization: true,
      },
      limits: {
        daily_api_calls: getDailyAPILimit(entityType),
        concurrent_simulations: getConcurrentSimulationLimit(entityType),
        data_retention_days: getDataRetentionDays(complianceTier),
      },
      partnerId: participant[0].id,
      walletId: wallet[0].id,
    });
  } catch (error) {
    console.error("Coalition participant onboarding error:", error);
    return Response.json(
      {
        error: "Failed to onboard coalition participant",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// Helper functions
function getTransparencyTier(complianceTier) {
  const tierMap = {
    LSOC: "I",
    DoddFrank: "II",
    MiFIDII: "III",
  };
  return tierMap[complianceTier] || "I";
}

function getTransparencyPhase(complianceTier) {
  return getTransparencyTier(complianceTier);
}

function getDefaultTradingCapacity(entityType) {
  const capacityMap = {
    institutional: "block",
    retail: "small",
    scout: "micro",
  };
  return capacityMap[entityType] || "small";
}

function getRiskLimits(entityType, complianceTier) {
  const baseRisk = entityType === "institutional" ? 1000000 : 50000;
  const complianceMultiplier = {
    LSOC: 1.5,
    DoddFrank: 1.2,
    MiFIDII: 1.0,
  };

  return {
    max_position_size: baseRisk * (complianceMultiplier[complianceTier] || 1.0),
    max_daily_volume: baseRisk * 10,
    var_limit: baseRisk * 0.05,
    concentration_limit: 0.15,
  };
}

async function initializeBiometricSignalAccess(
  participantId,
  entityType,
  complianceTier,
) {
  const signalTypes = [
    "BVI",
    "TacticalEfficiency",
    "RecoveryIndex",
    "BiasIndex",
    "TierForecast",
  ];

  const accessLevel =
    entityType === "institutional"
      ? "full"
      : entityType === "scout"
        ? "limited"
        : "basic";

  return {
    participant_id: participantId,
    access_level: accessLevel,
    available_signals: signalTypes,
    refresh_rate: entityType === "institutional" ? "realtime" : "delayed_15min",
    historical_depth: complianceTier === "MiFIDII" ? "2_years" : "1_year",
  };
}

function generateAPICredentials(participantId, entityType, complianceTier) {
  // In production, these would be properly generated JWT tokens
  const baseUrl = process.env.APP_URL || "https://api.bledsoeinfra.com/v1";

  return {
    api_key: `bim_${participantId}_${Date.now()}`,
    client_id: `coalition_${participantId}`,
    base_url: baseUrl,
    scopes: [
      "biometric.read",
      "biometric.write",
      "coalition.verify",
      entityType === "institutional" ? "trade.execute" : null,
      "simulation.run",
    ].filter(Boolean),
    rate_limits: {
      requests_per_minute: entityType === "institutional" ? 1000 : 100,
      burst_limit: entityType === "institutional" ? 200 : 50,
    },
    webhook_url: null, // To be configured by participant
    oauth_endpoints: {
      authorization: `${baseUrl}/oauth/authorize`,
      token: `${baseUrl}/oauth/token`,
      refresh: `${baseUrl}/oauth/refresh`,
    },
  };
}

function getDailyAPILimit(entityType) {
  const limits = {
    institutional: 100000,
    retail: 10000,
    scout: 5000,
  };
  return limits[entityType] || 1000;
}

function getConcurrentSimulationLimit(entityType) {
  const limits = {
    institutional: 50,
    retail: 10,
    scout: 5,
  };
  return limits[entityType] || 1;
}

function getDataRetentionDays(complianceTier) {
  const retention = {
    LSOC: 2555, // 7 years
    DoddFrank: 1825, // 5 years
    MiFIDII: 2555, // 7 years
  };
  return retention[complianceTier] || 365;
}
