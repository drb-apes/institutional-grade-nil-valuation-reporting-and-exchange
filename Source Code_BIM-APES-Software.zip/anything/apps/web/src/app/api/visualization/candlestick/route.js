import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const participantId = searchParams.get("participantId");
    const chartType = searchParams.get("chartType") || "standard";
    const timeRange = searchParams.get("timeRange") || "last7days";
    const instrumentFilter = searchParams.get("instrument");

    if (!participantId) {
      return Response.json(
        { error: "participantId required" },
        { status: 400 },
      );
    }

    // Validate participant
    const participant = await sql`
      SELECT * FROM institutional_partners 
      WHERE api_credentials->>'participant_id' = ${participantId}
      AND integration_status = 'active'
    `;

    if (participant.length === 0) {
      return Response.json({ error: "Invalid participant" }, { status: 403 });
    }

    // Generate candlestick data based on chart type
    const candlestickData = await generateCandlestickData({
      participantId,
      chartType,
      timeRange,
      instrumentFilter,
      participantData: participant[0],
    });

    return Response.json({
      success: true,
      candlestick_data: candlestickData,
      metadata: {
        participantId,
        chartType,
        timeRange,
        generated_at: new Date().toISOString(),
        total_candles: candlestickData.candles.length,
      },
    });
  } catch (error) {
    console.error("Candlestick visualization error:", error);
    return Response.json(
      {
        error: "Failed to generate candlestick data",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function generateCandlestickData({
  participantId,
  chartType,
  timeRange,
  instrumentFilter,
  participantData,
}) {
  const timeRanges = {
    last7days: 7,
    last30days: 30,
    last90days: 90,
    custom: 30,
  };

  const days = timeRanges[timeRange] || 7;
  const candles = [];

  // Generate candlestick data based on chart type
  for (let i = days - 1; i >= 0; i--) {
    const timestamp = new Date(Date.now() - i * 24 * 60 * 60 * 1000);

    let candleData;

    switch (chartType) {
      case "biometric":
        candleData = await generateBiometricCandle(timestamp, participantId);
        break;
      case "brandedInsert":
        candleData = await generateBrandedInsertCandle(
          timestamp,
          participantId,
          participantData,
        );
        break;
      case "swapTriggered":
        candleData = await generateSwapTriggeredCandle(
          timestamp,
          participantId,
        );
        break;
      default:
        candleData = await generateStandardCandle(timestamp, participantId);
    }

    candles.push(candleData);
  }

  return {
    candles: candles,
    chart_type: chartType,
    time_range: timeRange,
    participant_compliance: participantData.api_credentials.compliance_tier,
  };
}

async function generateBiometricCandle(timestamp, participantId) {
  // Get biometric signals for the timestamp
  const biometricBase = 70 + Math.random() * 20; // 70-90 base range
  const volatility = Math.random() * 8; // ±4 point volatility

  const open = biometricBase + (Math.random() - 0.5) * volatility;
  const close = open + (Math.random() - 0.5) * volatility;
  const high = Math.max(open, close) + Math.random() * 3;
  const low = Math.min(open, close) - Math.random() * 3;

  return {
    timestamp: timestamp.toISOString(),
    open: Math.round(open * 100) / 100,
    close: Math.round(close * 100) / 100,
    high: Math.round(high * 100) / 100,
    low: Math.round(low * 100) / 100,
    type: "biometric",
    insert: "bvi_score",
    metadata: {
      bvi_components: {
        tactical_efficiency: Math.round((70 + Math.random() * 25) * 100) / 100,
        recovery_index: Math.round((60 + Math.random() * 30) * 100) / 100,
        performance_consistency:
          Math.round((75 + Math.random() * 20) * 100) / 100,
      },
      signal_strength: Math.round((0.8 + Math.random() * 0.2) * 100) / 100,
    },
  };
}

async function generateBrandedInsertCandle(
  timestamp,
  participantId,
  participantData,
) {
  const complianceTier = participantData.api_credentials.compliance_tier;

  const priceBase = 95 + Math.random() * 10; // 95-105 base range
  const volatility = Math.random() * 6;

  const open = priceBase + (Math.random() - 0.5) * volatility;
  const close = open + (Math.random() - 0.5) * volatility;
  const high = Math.max(open, close) + Math.random() * 2;
  const low = Math.min(open, close) - Math.random() * 2;

  // Compliance badge based on tier
  const complianceBadges = {
    LSOC: "lsoc_verified",
    DoddFrank: "dodd_frank_compliant",
    MiFIDII: "mifid_transparent",
  };

  return {
    timestamp: timestamp.toISOString(),
    open: Math.round(open * 100) / 100,
    close: Math.round(close * 100) / 100,
    high: Math.round(high * 100) / 100,
    low: Math.round(low * 100) / 100,
    type: "branded",
    insert: complianceBadges[complianceTier] || "standard_badge",
    metadata: {
      compliance_tier: complianceTier,
      transparency_phase: getTransparencyPhase(complianceTier),
      regulatory_score: Math.round((85 + Math.random() * 15) * 100) / 100,
    },
  };
}

async function generateSwapTriggeredCandle(timestamp, participantId) {
  // Simulate swap-to-future migration scenarios
  const swapBase = 88 + Math.random() * 14; // 88-102 base range
  const futureAdjustment = Math.random() * 4 - 2; // ±2 point adjustment

  const open = swapBase;
  const close = swapBase + futureAdjustment;
  const high = Math.max(open, close) + Math.random() * 3;
  const low = Math.min(open, close) - Math.random() * 3;

  const swapTriggered = Math.random() > 0.7; // 30% chance of swap trigger

  return {
    timestamp: timestamp.toISOString(),
    open: Math.round(open * 100) / 100,
    close: Math.round(close * 100) / 100,
    high: Math.round(high * 100) / 100,
    low: Math.round(low * 100) / 100,
    type: "swap_triggered",
    insert: swapTriggered ? "futurization_alert" : "swap_stable",
    metadata: {
      swap_triggered: swapTriggered,
      cost_differential: swapTriggered
        ? Math.round((5 + Math.random() * 10) * 100) / 100
        : null,
      migration_recommendation: swapTriggered
        ? "consider_futures"
        : "maintain_swaps",
      efficiency_gain: swapTriggered
        ? Math.round((10 + Math.random() * 20) * 100) / 100
        : null,
    },
  };
}

async function generateStandardCandle(timestamp, participantId) {
  const priceBase = 100; // Standard base price
  const dailyVolatility = Math.random() * 5; // ±2.5% daily volatility

  const open = priceBase + (Math.random() - 0.5) * dailyVolatility;
  const close = open + (Math.random() - 0.5) * dailyVolatility;
  const high = Math.max(open, close) + Math.random() * 2;
  const low = Math.min(open, close) - Math.random() * 2;

  return {
    timestamp: timestamp.toISOString(),
    open: Math.round(open * 100) / 100,
    close: Math.round(close * 100) / 100,
    high: Math.round(high * 100) / 100,
    low: Math.round(low * 100) / 100,
    type: "standard",
    insert: null,
    metadata: {
      volume: Math.round((50000 + Math.random() * 200000) * 100) / 100,
      market_sentiment: Math.random() > 0.5 ? "bullish" : "bearish",
      liquidity_score: Math.round((0.7 + Math.random() * 0.3) * 100) / 100,
    },
  };
}

function getTransparencyPhase(complianceTier) {
  const phaseMap = {
    LSOC: "I",
    DoddFrank: "II",
    MiFIDII: "III",
  };
  return phaseMap[complianceTier] || "I";
}
