import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
} from "@/app/api/utils/security";

/**
 * Advanced Chart Data Generation
 *
 * Generates data for:
 * - Heatmaps (spatial + temporal performance intensity)
 * - Radar charts (multi-dimensional athlete profiles)
 * - Waterfall charts (NIL valuation attribution)
 * - Tactical maps (sport-specific spatial intelligence)
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      chartType: { required: true, type: "string" }, // 'heatmap' | 'radar' | 'waterfall' | 'tactical'
      athleteId: { required: false, type: "number" },
      sport: { required: false, type: "string" },
      timeRange: { required: false, type: "string" }, // '7d' | '30d' | '90d' | '1y'
      parameters: { required: false, type: "object" },
    });

    const {
      chartType,
      athleteId,
      sport,
      timeRange = "30d",
      parameters = {},
    } = body;

    let chartData;

    switch (chartType) {
      case "heatmap":
        chartData = await generateHeatmapData(
          athleteId,
          sport,
          timeRange,
          parameters,
        );
        break;

      case "radar":
        chartData = await generateRadarData(athleteId, sport);
        break;

      case "waterfall":
        chartData = await generateWaterfallData(athleteId);
        break;

      case "tactical":
        chartData = await generateTacticalMapData(athleteId, sport, parameters);
        break;

      default:
        return createSecureResponse(
          { error: "Invalid chart type" },
          { status: 400 },
        );
    }

    return createSecureResponse({
      success: true,
      chartType,
      data: chartData,
      metadata: {
        athleteId,
        sport,
        timeRange,
        generatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Chart generation error:", error);
    return createSecureResponse(
      { error: "Failed to generate chart data" },
      { status: 500 },
    );
  }
}

// Heatmap Data Generator
async function generateHeatmapData(athleteId, sport, timeRange, parameters) {
  const days =
    timeRange === "7d"
      ? 7
      : timeRange === "30d"
        ? 30
        : timeRange === "90d"
          ? 90
          : 365;

  // Get performance data over time period
  const performanceData = await sql`
    SELECT 
      ai_score,
      motion_type,
      metadata,
      created_at,
      DATE(created_at) as performance_date
    FROM motion_scans
    WHERE athlete_id = ${athleteId}
      AND created_at > NOW() - INTERVAL '${days} days'
    ORDER BY created_at ASC
  `;

  // Build heatmap grid (days x metrics)
  const heatmap = {
    xAxis: [], // dates
    yAxis: [
      "Performance",
      "Consistency",
      "Intensity",
      "Recovery",
      "Efficiency",
    ],
    data: [],
  };

  // Group by date
  const dateGroups = {};
  performanceData.forEach((scan) => {
    const date = scan.performance_date.toISOString().split("T")[0];
    if (!dateGroups[date]) {
      dateGroups[date] = [];
    }
    dateGroups[date].push(scan);
  });

  // Calculate metrics for each date
  Object.keys(dateGroups)
    .sort()
    .forEach((date, dateIdx) => {
      heatmap.xAxis.push(date);
      const scans = dateGroups[date];

      const avgScore =
        scans.reduce((sum, s) => sum + parseFloat(s.ai_score), 0) /
        scans.length;
      const consistency = calculateConsistency(scans);
      const intensity = calculateIntensity(scans);
      const recovery = calculateRecovery(scans);
      const efficiency = calculateEfficiency(scans);

      heatmap.data.push(
        [dateIdx, 0, Math.round(avgScore)], // Performance
        [dateIdx, 1, Math.round(consistency)], // Consistency
        [dateIdx, 2, Math.round(intensity)], // Intensity
        [dateIdx, 3, Math.round(recovery)], // Recovery
        [dateIdx, 4, Math.round(efficiency)], // Efficiency
      );
    });

  return heatmap;
}

// Radar Chart Data Generator
async function generateRadarData(athleteId, sport) {
  // Get recent performance metrics
  const recentScans = await sql`
    SELECT * FROM motion_scans
    WHERE athlete_id = ${athleteId}
    ORDER BY created_at DESC
    LIMIT 20
  `;

  if (recentScans.length === 0) {
    return {
      dimensions: [],
      values: [],
      maxValues: [],
    };
  }

  // Define sport-specific dimensions
  const dimensions = getSportDimensions(sport);

  // Calculate values for each dimension
  const values = dimensions.map((dim) =>
    calculateDimensionValue(recentScans, dim),
  );
  const maxValues = dimensions.map(() => 100);

  return {
    dimensions: dimensions.map((d) => d.name),
    values,
    maxValues,
    athlete: {
      id: athleteId,
      avgScore:
        recentScans.reduce((sum, s) => sum + parseFloat(s.ai_score), 0) /
        recentScans.length,
    },
  };
}

// Waterfall Chart Data Generator (NIL Valuation Attribution)
async function generateWaterfallData(athleteId) {
  // Get NIL account
  const nilAccount = await sql`
    SELECT * FROM nil_valuation_accounts
    WHERE athlete_id = ${athleteId}
    LIMIT 1
  `;

  if (nilAccount.length === 0) {
    return { categories: [], values: [] };
  }

  const baseValue = 100000; // Baseline NIL value
  const categories = ["Base NIL"];
  const values = [baseValue];

  // Get recent contract adjustments
  const adjustments = await sql`
    SELECT * FROM contract_adjustments
    WHERE nil_account_id = ${nilAccount[0].id}
    ORDER BY adjustment_date DESC
    LIMIT 10
  `;

  let runningTotal = baseValue;

  adjustments.forEach((adj) => {
    categories.push(adj.adjustment_type.replace(/_/g, " "));
    const amount = parseFloat(adj.adjustment_amount);
    values.push(amount);
    runningTotal += amount;
  });

  categories.push("Current NIL");
  values.push(runningTotal);

  return {
    categories,
    values,
    runningTotal,
    baseValue,
    currentValue: parseFloat(nilAccount[0].current_valuation),
  };
}

// Tactical Map Data Generator (Sport-Specific)
async function generateTacticalMapData(athleteId, sport, parameters) {
  // Sport-specific tactical data
  const tacticalData = {
    sport,
    zones: [],
    movements: [],
    heatpoints: [],
  };

  if (sport === "soccer" || sport === "basketball" || sport === "rugby") {
    // Field/court zones with activity intensity
    tacticalData.zones = [
      { zone: "Attacking Third", activity: 65, efficiency: 72 },
      { zone: "Middle Third", activity: 80, efficiency: 68 },
      { zone: "Defensive Third", activity: 55, efficiency: 85 },
    ];

    // Common movement patterns
    tacticalData.movements = [
      { from: [20, 50], to: [80, 50], frequency: 12, success: 0.75 },
      { from: [50, 20], to: [50, 80], frequency: 8, success: 0.62 },
    ];
  } else if (sport === "tennis" || sport === "pickleball") {
    // Court zones
    tacticalData.zones = [
      { zone: "Baseline", activity: 70, efficiency: 65 },
      { zone: "Net", activity: 30, efficiency: 80 },
      { zone: "Service Line", activity: 50, efficiency: 72 },
    ];
  } else if (sport === "wrestling") {
    // Position dominance
    tacticalData.zones = [
      { zone: "Top Position", activity: 60, efficiency: 78 },
      { zone: "Bottom Position", activity: 40, efficiency: 65 },
      { zone: "Neutral", activity: 50, efficiency: 70 },
    ];
  }

  return tacticalData;
}

// Helper functions
function calculateConsistency(scans) {
  if (scans.length < 2) return 50;

  const scores = scans.map((s) => parseFloat(s.ai_score));
  const mean = scores.reduce((sum, s) => sum + s, 0) / scores.length;
  const variance =
    scores.reduce((sum, s) => sum + Math.pow(s - mean, 2), 0) / scores.length;
  const stdDev = Math.sqrt(variance);

  // Lower standard deviation = higher consistency
  const consistencyScore = Math.max(0, 100 - stdDev * 5);
  return consistencyScore;
}

function calculateIntensity(scans) {
  // Based on motion type and metadata
  const intensityScores = scans.map((s) => {
    const metadata = s.metadata || {};
    return metadata.intensity || parseFloat(s.ai_score) * 0.8;
  });

  return intensityScores.reduce((sum, s) => sum + s, 0) / scans.length;
}

function calculateRecovery(scans) {
  // Analyze day-to-day recovery patterns
  let recoveryScore = 70; // Baseline

  for (let i = 1; i < scans.length; i++) {
    const current = parseFloat(scans[i].ai_score);
    const previous = parseFloat(scans[i - 1].ai_score);

    if (current >= previous) {
      recoveryScore += 2; // Good recovery
    } else if (current < previous - 10) {
      recoveryScore -= 5; // Poor recovery
    }
  }

  return Math.min(100, Math.max(0, recoveryScore));
}

function calculateEfficiency(scans) {
  // Ratio of performance output to effort
  const avgScore =
    scans.reduce((sum, s) => sum + parseFloat(s.ai_score), 0) / scans.length;
  return Math.min(100, avgScore * 1.1); // Slight bonus for high performers
}

function getSportDimensions(sport) {
  const sportDimensions = {
    wrestling: [
      { name: "Offensive", metric: "takedown_efficiency" },
      { name: "Defensive", metric: "escape_rate" },
      { name: "Control", metric: "control_time" },
      { name: "Explosive Power", metric: "explosive_movements" },
      { name: "Endurance", metric: "late_match_performance" },
      { name: "Technical", metric: "technique_score" },
    ],
    soccer: [
      { name: "Passing", metric: "pass_accuracy" },
      { name: "Possession", metric: "possession_efficiency" },
      { name: "Defensive", metric: "tackle_success" },
      { name: "Speed", metric: "sprint_performance" },
      { name: "Endurance", metric: "distance_covered" },
      { name: "Decision Making", metric: "tactical_awareness" },
    ],
    tennis: [
      { name: "Serve", metric: "serve_quality" },
      { name: "Forehand", metric: "forehand_consistency" },
      { name: "Backhand", metric: "backhand_consistency" },
      { name: "Net Play", metric: "net_efficiency" },
      { name: "Pressure Points", metric: "break_point_conversion" },
      { name: "Endurance", metric: "late_set_performance" },
    ],
  };

  return (
    sportDimensions[sport] || [
      { name: "Performance", metric: "overall" },
      { name: "Consistency", metric: "consistency" },
      { name: "Efficiency", metric: "efficiency" },
      { name: "Intensity", metric: "intensity" },
      { name: "Recovery", metric: "recovery" },
    ]
  );
}

function calculateDimensionValue(scans, dimension) {
  // Extract dimension-specific values from motion scan metadata
  const values = scans.map((scan) => {
    const metadata = scan.metadata || {};
    return metadata[dimension.metric] || parseFloat(scan.ai_score) * 0.8;
  });

  return values.reduce((sum, v) => sum + v, 0) / values.length;
}
