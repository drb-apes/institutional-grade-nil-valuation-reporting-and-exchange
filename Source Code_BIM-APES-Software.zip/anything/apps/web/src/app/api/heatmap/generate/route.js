import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      participantId,
      metrics,
      context,
      timeWindow,
      athleteId,
      sportType,
    } = body;

    if (!participantId || !metrics || !context) {
      return Response.json(
        {
          error: "Missing required fields: participantId, metrics, context",
        },
        { status: 400 },
      );
    }

    // Validate participant
    const participant = await sql`
      SELECT * FROM institutional_partners 
      WHERE api_credentials->>'participant_id' = ${participantId}
      AND integration_status = 'active'
    `;

    if (participant.length === 0) {
      return Response.json({ error: "Invalid participant" }, { status: 403 });
    }

    // Generate heatmap data
    const heatmapData = await generateAthleteHeatmap({
      participantId,
      metrics,
      context,
      timeWindow,
      athleteId,
      sportType,
    });

    // Create heatmap URL
    const heatmapId = `heatmap_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const heatmapUrl = `${process.env.APP_URL}/api/heatmap/${heatmapId}`;

    return Response.json({
      success: true,
      heatmapUrl: heatmapUrl,
      heatmapId: heatmapId,
      killzones: heatmapData.killzones,
      performance_insights: heatmapData.insights,
      sport_specific_data: heatmapData.sportSpecific,
      metadata: {
        participantId,
        metrics,
        context,
        timeWindow,
        generated_at: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Heatmap generation error:", error);
    return Response.json(
      {
        error: "Failed to generate heatmap",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function generateAthleteHeatmap({
  participantId,
  metrics,
  context,
  timeWindow,
  athleteId,
  sportType,
}) {
  const timeRange = parseTimeWindow(timeWindow);
  const heatmapData = {
    grid: [],
    killzones: [],
    insights: {},
    sportSpecific: {},
  };

  // Generate performance heatmap grid (24x7 for hours x days)
  for (let day = 0; day < 7; day++) {
    for (let hour = 0; hour < 24; hour++) {
      const cellData = await generateHeatmapCell({
        day,
        hour,
        metrics,
        context,
        timeRange,
        athleteId,
        sportType,
      });

      heatmapData.grid.push(cellData);

      // Identify killzones (high stress/fatigue periods)
      if (cellData.riskLevel === "high" || cellData.fatigueIndex > 80) {
        heatmapData.killzones.push(cellData.timestamp);
      }
    }
  }

  // Generate sport-specific insights
  heatmapData.sportSpecific = await generateSportSpecificInsights(
    sportType,
    heatmapData.grid,
  );

  // Generate performance insights
  heatmapData.insights = await generatePerformanceInsights(
    metrics,
    heatmapData.grid,
    context,
  );

  return heatmapData;
}

async function generateHeatmapCell({
  day,
  hour,
  metrics,
  context,
  timeRange,
  athleteId,
  sportType,
}) {
  const timestamp = new Date();
  timestamp.setDate(timestamp.getDate() - (6 - day));
  timestamp.setHours(hour, 0, 0, 0);

  // Base performance metrics
  const hrv = 40 + Math.random() * 20 + (hour > 6 && hour < 22 ? 10 : -5); // Better during day
  const fatigue = Math.max(
    0,
    Math.min(100, 30 + Math.random() * 40 + (hour > 20 || hour < 6 ? 20 : 0)),
  ); // Higher at night
  const gait = 70 + Math.random() * 25 + (context === "competition" ? 10 : 0);

  // Calculate composite score
  const performanceScore = (hrv + (100 - fatigue) + gait) / 3;

  // Risk assessment
  const riskFactors = {
    fatigue_risk: fatigue > 70,
    hrv_low: hrv < 45,
    performance_drop: performanceScore < 60,
    time_risk: hour > 22 || hour < 6,
  };

  const riskCount = Object.values(riskFactors).filter(Boolean).length;
  const riskLevel = riskCount >= 3 ? "high" : riskCount >= 2 ? "medium" : "low";

  return {
    timestamp: timestamp.toISOString(),
    day: day,
    hour: hour,
    metrics: {
      HRV: Math.round(hrv * 100) / 100,
      fatigue: Math.round(fatigue * 100) / 100,
      gait: Math.round(gait * 100) / 100,
    },
    performanceScore: Math.round(performanceScore * 100) / 100,
    fatigueIndex: fatigue,
    riskLevel: riskLevel,
    riskFactors: riskFactors,
    context: context,
    sportType: sportType || "general",
  };
}

async function generateSportSpecificInsights(sportType, gridData) {
  const sportInsights = {
    wrestling: {
      peakPerformanceWindows: ["14:00-16:00", "18:00-20:00"],
      recoveryNeeds: "High protein intake, 8+ hours sleep",
      tacticalRecommendations: "Focus technical drilling during peak windows",
      injuryRiskFactors: ["Shoulder fatigue", "Lower back stress"],
    },
    rugby: {
      peakPerformanceWindows: ["10:00-12:00", "15:00-17:00"],
      recoveryNeeds: "Active recovery, mobility work",
      tacticalRecommendations: "Contact training during high HRV periods",
      injuryRiskFactors: ["Concussion risk", "Knee ligament stress"],
    },
    soccer: {
      peakPerformanceWindows: ["09:00-11:00", "16:00-18:00"],
      recoveryNeeds: "Hydration focus, dynamic stretching",
      tacticalRecommendations: "Sprint work during low fatigue periods",
      injuryRiskFactors: ["Hamstring tightness", "Ankle instability"],
    },
    basketball: {
      peakPerformanceWindows: ["11:00-13:00", "17:00-19:00"],
      recoveryNeeds: "Plyometric recovery, sleep optimization",
      tacticalRecommendations: "Vertical training during peak power",
      injuryRiskFactors: ["Jump knee stress", "Ankle fatigue"],
    },
    tennis: {
      peakPerformanceWindows: ["08:00-10:00", "17:00-19:00"],
      recoveryNeeds: "Shoulder care, wrist stability",
      tacticalRecommendations: "Serve practice during optimal HRV",
      injuryRiskFactors: ["Rotator cuff stress", "Elbow overuse"],
    },
    pickleball: {
      peakPerformanceWindows: ["09:00-11:00", "15:00-17:00"],
      recoveryNeeds: "Joint mobility, reaction time drills",
      tacticalRecommendations: "Net play during high alertness",
      injuryRiskFactors: ["Achilles stress", "Shoulder impingement"],
    },
  };

  return sportInsights[sportType] || sportInsights.wrestling; // Default to wrestling
}

async function generatePerformanceInsights(metrics, gridData, context) {
  const avgPerformance =
    gridData.reduce((sum, cell) => sum + cell.performanceScore, 0) /
    gridData.length;
  const highRiskPeriods = gridData.filter(
    (cell) => cell.riskLevel === "high",
  ).length;
  const peakPeriods = gridData.filter(
    (cell) => cell.performanceScore > 80,
  ).length;

  // Identify patterns
  const hourlyAverages = {};
  for (let hour = 0; hour < 24; hour++) {
    const hourCells = gridData.filter((cell) => cell.hour === hour);
    hourlyAverages[hour] =
      hourCells.reduce((sum, cell) => sum + cell.performanceScore, 0) /
      hourCells.length;
  }

  const bestHours = Object.entries(hourlyAverages)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([hour]) => `${hour}:00`);

  const worstHours = Object.entries(hourlyAverages)
    .sort(([, a], [, b]) => a - b)
    .slice(0, 3)
    .map(([hour]) => `${hour}:00`);

  return {
    overall_performance: {
      average_score: Math.round(avgPerformance * 100) / 100,
      performance_trend:
        avgPerformance > 70
          ? "improving"
          : avgPerformance > 50
            ? "stable"
            : "declining",
      consistency_rating: calculateConsistency(gridData),
    },
    risk_analysis: {
      high_risk_periods: highRiskPeriods,
      risk_percentage:
        Math.round((highRiskPeriods / gridData.length) * 10000) / 100,
      primary_risk_factors: identifyPrimaryRiskFactors(gridData),
    },
    optimization_opportunities: {
      best_performance_hours: bestHours,
      worst_performance_hours: worstHours,
      recovery_windows: identifyRecoveryWindows(gridData),
      training_recommendations: generateTrainingRecommendations(
        gridData,
        context,
      ),
    },
    biometric_patterns: {
      hrv_trend: calculateMetricTrend(gridData, "HRV"),
      fatigue_pattern: calculateMetricTrend(gridData, "fatigue"),
      gait_stability: calculateMetricTrend(gridData, "gait"),
    },
  };
}

function parseTimeWindow(timeWindow) {
  if (!timeWindow) {
    return {
      start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      end: new Date(),
    };
  }

  const [startStr, endStr] = timeWindow.split(" to ");
  return {
    start: new Date(startStr),
    end: new Date(endStr),
  };
}

function calculateConsistency(gridData) {
  const scores = gridData.map((cell) => cell.performanceScore);
  const mean = scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const stdDev = Math.sqrt(variance);

  // Lower standard deviation = higher consistency
  const consistencyScore = Math.max(0, 100 - stdDev * 2);
  return Math.round(consistencyScore * 100) / 100;
}

function identifyPrimaryRiskFactors(gridData) {
  const riskCounts = {
    fatigue_risk: 0,
    hrv_low: 0,
    performance_drop: 0,
    time_risk: 0,
  };

  gridData.forEach((cell) => {
    Object.keys(cell.riskFactors).forEach((factor) => {
      if (cell.riskFactors[factor]) {
        riskCounts[factor]++;
      }
    });
  });

  return Object.entries(riskCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 2)
    .map(([factor]) => factor.replace("_", " "));
}

function identifyRecoveryWindows(gridData) {
  const lowStressPeriods = gridData
    .filter((cell) => cell.riskLevel === "low" && cell.fatigueIndex < 40)
    .map((cell) => `${String(cell.hour).padStart(2, "0")}:00`)
    .slice(0, 4);

  return lowStressPeriods;
}

function generateTrainingRecommendations(gridData, context) {
  const avgFatigue =
    gridData.reduce((sum, cell) => sum + cell.fatigueIndex, 0) /
    gridData.length;
  const avgPerformance =
    gridData.reduce((sum, cell) => sum + cell.performanceScore, 0) /
    gridData.length;

  const recommendations = [];

  if (avgFatigue > 60) {
    recommendations.push(
      "Increase recovery periods between high-intensity sessions",
    );
  }

  if (avgPerformance < 60) {
    recommendations.push(
      "Focus on technique refinement during low-energy periods",
    );
  }

  if (context === "competition") {
    recommendations.push(
      "Peak around performance windows, taper during high-risk periods",
    );
  } else {
    recommendations.push(
      "Build base fitness during consistent performance periods",
    );
  }

  return recommendations;
}

function calculateMetricTrend(gridData, metricName) {
  const values = gridData.map((cell) => cell.metrics[metricName]);
  const firstHalf = values.slice(0, Math.floor(values.length / 2));
  const secondHalf = values.slice(Math.floor(values.length / 2));

  const firstAvg =
    firstHalf.reduce((sum, val) => sum + val, 0) / firstHalf.length;
  const secondAvg =
    secondHalf.reduce((sum, val) => sum + val, 0) / secondHalf.length;

  const change = ((secondAvg - firstAvg) / firstAvg) * 100;

  return {
    direction: change > 2 ? "improving" : change < -2 ? "declining" : "stable",
    change_percentage: Math.round(change * 100) / 100,
    current_level:
      secondAvg > 70
        ? "optimal"
        : secondAvg > 50
          ? "moderate"
          : "needs_attention",
  };
}
