import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Monte Carlo Scenario Analysis Engine
function runMonteCarloScenarios({
  athleteData,
  sportType,
  scenarioCount = 1000,
  variables = {},
}) {
  const scenarios = [];

  for (let i = 0; i < scenarioCount; i++) {
    const scenario = generateScenarioVariation(
      athleteData,
      sportType,
      variables,
    );
    scenarios.push(scenario);
  }

  return {
    scenarios,
    statistics: calculateScenarioStatistics(scenarios),
    outcomes: categorizeOutcomes(scenarios, sportType),
    recommendations: generateScenarioRecommendations(scenarios, sportType),
  };
}

// Sport-Specific Scenario Generators
function generateScenarioVariation(athleteData, sportType, variables) {
  const basePerformance = athleteData.baseline_performance || 75;

  // Apply random variations based on sport and input variables
  const fatigue = variables.fatigue_level || Math.random() * 30 + 70; // 70-100%
  const weather =
    variables.weather_condition || getRandomWeatherImpact(sportType);
  const opponent = variables.opponent_strength || Math.random() * 40 + 60; // 60-100
  const position = variables.position_change || false;

  let performanceModifier = 1.0;

  // Sport-specific adjustments
  switch (sportType) {
    case "wrestling":
    case "goalwrestling":
      performanceModifier = calculateWrestlingScenario(
        fatigue,
        opponent,
        position,
      );
      break;
    case "rugby":
    case "soccer":
    case "basketball":
      performanceModifier = calculateTacticalSportsScenario(
        fatigue,
        weather,
        opponent,
        position,
      );
      break;
    case "tennis":
    case "pickleball":
      performanceModifier = calculateRacketSportsScenario(
        fatigue,
        weather,
        opponent,
      );
      break;
    case "american_football":
      performanceModifier = calculateAmericanFootballScenario(
        fatigue,
        weather,
        opponent,
        position,
      );
      break;
    default:
      performanceModifier = (fatigue / 100) * (1 - (opponent - 60) / 200);
  }

  const finalPerformance = Math.max(
    0,
    Math.min(100, basePerformance * performanceModifier),
  );

  return {
    performance_score: finalPerformance,
    factors: { fatigue, weather, opponent, position },
    sport_specific_metrics: generateSportMetrics(sportType, finalPerformance, {
      fatigue,
      weather,
      opponent,
    }),
    outcome_probability: calculateOutcomeProbability(
      finalPerformance,
      sportType,
    ),
    risk_assessment: assessScenarioRisk(finalPerformance, {
      fatigue,
      weather,
      opponent,
    }),
  };
}

function calculateScenarioStatistics(scenarios) {
  if (scenarios.length === 0) return {};

  const performances = scenarios.map((s) => s.performance_score);
  const risks = scenarios.map((s) => s.risk_assessment);
  const winProbs = scenarios.map((s) => s.outcome_probability);

  return {
    performance_stats: {
      mean: performances.reduce((a, b) => a + b, 0) / performances.length,
      median: performances.sort((a, b) => a - b)[
        Math.floor(performances.length / 2)
      ],
      min: Math.min(...performances),
      max: Math.max(...performances),
      std_dev: calculateStandardDeviation(performances),
    },
    risk_stats: {
      average_risk: risks.reduce((a, b) => a + b, 0) / risks.length,
      high_risk_scenarios: risks.filter((r) => r >= 7).length,
      low_risk_scenarios: risks.filter((r) => r <= 3).length,
    },
    win_probability: {
      mean: winProbs.reduce((a, b) => a + b, 0) / winProbs.length,
      high_confidence:
        winProbs.filter((p) => p >= 0.7).length / winProbs.length,
      low_confidence: winProbs.filter((p) => p <= 0.3).length / winProbs.length,
    },
  };
}

function categorizeOutcomes(scenarios, sportType) {
  const excellent = scenarios.filter((s) => s.performance_score >= 85).length;
  const good = scenarios.filter(
    (s) => s.performance_score >= 70 && s.performance_score < 85,
  ).length;
  const average = scenarios.filter(
    (s) => s.performance_score >= 55 && s.performance_score < 70,
  ).length;
  const poor = scenarios.filter((s) => s.performance_score < 55).length;

  return {
    excellent: {
      count: excellent,
      percentage: (excellent / scenarios.length) * 100,
    },
    good: { count: good, percentage: (good / scenarios.length) * 100 },
    average: { count: average, percentage: (average / scenarios.length) * 100 },
    poor: { count: poor, percentage: (poor / scenarios.length) * 100 },
    sport_context: getSportSpecificOutcomes(sportType, scenarios),
  };
}

function generateScenarioRecommendations(scenarios, sportType) {
  const stats = calculateScenarioStatistics(scenarios);
  const recommendations = [];

  // Performance-based recommendations
  if (stats.performance_stats.mean < 70) {
    recommendations.push({
      category: "Performance Improvement",
      priority: "high",
      recommendation: `Focus on baseline conditioning - average performance is ${stats.performance_stats.mean.toFixed(1)}%`,
      sport_specific: getSportSpecificImprovement(sportType, "low_performance"),
    });
  }

  // Risk management recommendations
  if (stats.risk_stats.high_risk_scenarios > scenarios.length * 0.3) {
    recommendations.push({
      category: "Risk Management",
      priority: "medium",
      recommendation:
        "High variability detected - implement consistency training protocols",
      sport_specific: getSportSpecificImprovement(sportType, "high_risk"),
    });
  }

  // Fatigue management
  const avgFatigue =
    scenarios.reduce((sum, s) => sum + s.factors.fatigue, 0) / scenarios.length;
  if (avgFatigue < 75) {
    recommendations.push({
      category: "Recovery",
      priority: "high",
      recommendation:
        "Fatigue levels impacting performance - adjust training load",
      sport_specific: getSportSpecificImprovement(sportType, "fatigue"),
    });
  }

  return recommendations;
}

function calculateStandardDeviation(values) {
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance =
    values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) /
    values.length;
  return Math.sqrt(variance);
}

function getSportSpecificOutcomes(sportType, scenarios) {
  // Return sport-specific outcome analysis
  switch (sportType) {
    case "wrestling":
      return {
        dominant_wins: scenarios.filter((s) => s.performance_score > 80).length,
      };
    case "tennis":
    case "pickleball":
      return {
        straight_sets: scenarios.filter((s) => s.performance_score > 75).length,
      };
    default:
      return {
        strong_performances: scenarios.filter((s) => s.performance_score > 75)
          .length,
      };
  }
}

function getSportSpecificImprovement(sportType, issueType) {
  const improvements = {
    wrestling: {
      low_performance: "Focus on takedown drills and endurance work",
      high_risk: "Practice defensive positioning and match simulation",
      fatigue: "Implement goal-wrestling specific conditioning",
    },
    tennis: {
      low_performance: "Work on serve consistency and court positioning",
      high_risk: "Practice pressure point scenarios and mental training",
      fatigue: "Improve match endurance with interval training",
    },
    basketball: {
      low_performance: "Focus on fundamentals and team coordination",
      high_risk: "Practice game situation scenarios",
      fatigue: "Improve cardiovascular base and recovery protocols",
    },
  };

  return (
    improvements[sportType]?.[issueType] ||
    "Implement sport-specific training protocols"
  );
}

// Sport-Specific Scenario Calculation Functions
function calculateWrestlingScenario(fatigue, opponent, positionChange) {
  let modifier = (fatigue / 100) * 0.8;

  // Wrestling-specific factors
  modifier *= 1 - (opponent - 60) / 300; // Opponent strength impact
  modifier *= positionChange ? 0.85 : 1.0; // Position change penalty

  // Wrestling endurance factor
  modifier += fatigue > 85 ? 0.1 : fatigue < 70 ? -0.15 : 0;

  return Math.max(0.4, Math.min(1.3, modifier));
}

function calculateTacticalSportsScenario(
  fatigue,
  weather,
  opponent,
  positionChange,
) {
  let modifier = (fatigue / 100) * 0.85;

  // Weather impact on outdoor sports
  modifier *= weather;
  modifier *= 1 - (opponent - 60) / 250;
  modifier *= positionChange ? 0.9 : 1.0; // Tactical adaptation

  return Math.max(0.5, Math.min(1.25, modifier));
}

function calculateRacketSportsScenario(fatigue, weather, opponent) {
  let modifier = (fatigue / 100) * 0.9;

  // Weather heavily impacts racket sports
  modifier *= weather;
  modifier *= 1 - (opponent - 60) / 200; // Skill differential

  // Precision sports benefit from good conditions
  if (weather > 0.9 && fatigue > 80) modifier += 0.1;

  return Math.max(0.3, Math.min(1.4, modifier));
}

function calculateAmericanFootballScenario(
  fatigue,
  weather,
  opponent,
  positionChange,
) {
  let modifier = (fatigue / 100) * 0.75;

  // Weather impact varies by position
  modifier *= weather;
  modifier *= 1 - (opponent - 60) / 280;

  // Position change has high impact in football
  modifier *= positionChange ? 0.8 : 1.0;

  return Math.max(0.4, Math.min(1.2, modifier));
}

// Question as a Service - Generate contextual questions based on user data
function generateQuestion({
  userTier,
  milestoneType,
  biometricData,
  performanceData,
}) {
  const questions = [];

  // Milestone-based questions
  if (milestoneType === "takedown") {
    questions.push({
      id: "zone_dominance",
      question: "What zone dominance pattern emerged in round 2?",
      category: "Performance Analysis",
      priority: "high",
      context: "Technical execution analysis for tactical improvement",
    });
  }

  if (milestoneType === "sprint") {
    questions.push({
      id: "acceleration_curve",
      question:
        "How does the acceleration curve compare to baseline projections?",
      category: "Biomechanics",
      priority: "medium",
      context: "Speed development and power output optimization",
    });
  }

  if (milestoneType === "endurance") {
    questions.push({
      id: "lactate_threshold",
      question:
        "What lactate threshold adjustments optimize performance sustainability?",
      category: "Physiological",
      priority: "high",
      context: "Cardiovascular efficiency and energy system development",
    });
  }

  // Biometric-based questions
  if (biometricData?.fatigueIndex > 15) {
    questions.push({
      id: "training_cadence",
      question: "Should this athlete shift training cadence next week?",
      category: "Recovery Management",
      priority: "urgent",
      context: "Fatigue management and injury prevention protocols",
    });
  }

  if (biometricData?.heartRateVariability < 30) {
    questions.push({
      id: "stress_adaptation",
      question: "What recovery protocols will optimize autonomic adaptation?",
      category: "Recovery Management",
      priority: "high",
      context: "Nervous system recovery and stress management",
    });
  }

  if (biometricData?.vo2Max && biometricData.vo2Max > 65) {
    questions.push({
      id: "elite_performance",
      question:
        "How can we leverage elite aerobic capacity for competitive advantage?",
      category: "Strategic Planning",
      priority: "medium",
      context: "Performance ceiling analysis and competitive positioning",
    });
  }

  // Investment tier-based questions
  if (userTier === "Gold" || userTier === "Bluechip") {
    questions.push({
      id: "dao_asset_bundling",
      question: "Should this milestone be bundled into a DAO-backed asset?",
      category: "Investment Strategy",
      priority: "medium",
      context:
        "Portfolio diversification and institutional investment opportunities",
    });

    questions.push({
      id: "institutional_exposure",
      question:
        "What institutional exposure maximizes ROI while minimizing risk?",
      category: "Risk Management",
      priority: "high",
      context: "Investment allocation and portfolio balance optimization",
    });
  }

  if (userTier === "Platinum" || userTier === "Elite") {
    questions.push({
      id: "syndicate_opportunity",
      question:
        "Should we structure this as a syndicated investment opportunity?",
      category: "Investment Strategy",
      priority: "high",
      context: "High-value asset structuring and institutional partnerships",
    });
  }

  // Performance-based investment questions
  if (performanceData?.roi > 15) {
    questions.push({
      id: "scaling_strategy",
      question:
        "How can we scale this performance model across similar athletes?",
      category: "Portfolio Expansion",
      priority: "medium",
      context: "Investment model replication and portfolio growth",
    });
  }

  if (performanceData?.riskScore < 3) {
    questions.push({
      id: "leverage_opportunity",
      question:
        "Should we increase investment leverage given the low risk profile?",
      category: "Risk Management",
      priority: "medium",
      context: "Capital efficiency and risk-adjusted returns optimization",
    });
  }

  // Add metadata to each question
  return questions.map((q) => ({
    ...q,
    timestamp: new Date().toISOString(),
    userTier,
    milestoneType,
    generated_by: "qaas_v1.0",
  }));
}

// Helper Functions for Scenario Analysis
function getRandomWeatherImpact(sportType) {
  const outdoor = [
    "rugby",
    "soccer",
    "american_football",
    "tennis",
    "pickleball",
  ];
  if (!outdoor.includes(sportType)) return 1.0; // Indoor sports unaffected

  // Weather conditions: 0.7 (poor) to 1.1 (ideal)
  return Math.random() * 0.4 + 0.7;
}

function generateSportMetrics(sportType, performance, factors) {
  const base = {
    overall_score: Math.round(performance),
    consistency_rating: Math.round(performance * (factors.fatigue / 100)),
    pressure_handling: Math.round(
      performance * (1 - (factors.opponent - 60) / 200),
    ),
  };

  switch (sportType) {
    case "wrestling":
    case "goalwrestling":
      return {
        ...base,
        takedown_efficiency: Math.round(performance * 0.9),
        grip_control: Math.round(performance * (factors.fatigue / 100)),
        endurance_rating: Math.round(factors.fatigue * 0.8 + 20),
      };
    case "rugby":
    case "soccer":
    case "basketball":
      return {
        ...base,
        tactical_efficiency: Math.round(performance * 0.85),
        team_coordination: Math.round(performance * factors.weather * 0.9),
        decision_making: Math.round(
          performance * (1 - (factors.opponent - 60) / 300),
        ),
      };
    case "tennis":
    case "pickleball":
      return {
        ...base,
        spike_score: Math.round(performance * factors.weather * 0.95),
        accuracy_rating: Math.round(performance * factors.weather * 0.8),
        power_consistency: Math.round(performance * (factors.fatigue / 100)),
      };
    case "american_football":
      return {
        ...base,
        session_consistency: Math.round(performance * 0.9),
        adaptability: Math.round(performance * (factors.position ? 0.8 : 1.0)),
        execution_rating: Math.round(performance * factors.weather * 0.85),
      };
    default:
      return base;
  }
}

function calculateOutcomeProbability(performance, sportType) {
  // Convert performance score to win probability
  let winProb = Math.min(0.95, Math.max(0.05, (performance - 20) / 80));

  // Sport-specific adjustments
  switch (sportType) {
    case "wrestling":
      // Wrestling has more decisive outcomes
      winProb = winProb > 0.6 ? winProb * 1.1 : winProb * 0.9;
      break;
    case "tennis":
    case "pickleball":
      // Racket sports can be more variable
      winProb = winProb * (0.9 + Math.random() * 0.2);
      break;
  }

  return Math.min(0.95, Math.max(0.05, winProb));
}

function assessScenarioRisk(performance, factors) {
  let riskScore = 5; // Base medium risk

  // Fatigue increases risk
  if (factors.fatigue < 70) riskScore += 2;
  else if (factors.fatigue > 85) riskScore -= 1;

  // Weather conditions
  if (factors.weather < 0.8) riskScore += 1;

  // Opponent strength
  if (factors.opponent > 85) riskScore += 2;

  // Performance level
  if (performance < 60) riskScore += 2;
  else if (performance > 85) riskScore -= 1;

  return Math.max(1, Math.min(10, riskScore));
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { milestoneId, biometricData, performanceData } = body;

    // Get user profile and tier information
    let userProfile = await sql`
      SELECT up.*, au.name, au.email
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      // Create profile if it doesn't exist
      const newProfile = await sql`
        INSERT INTO user_profiles (user_id, user_type, tier_level)
        VALUES (${session.user.id}, 'athlete', 1)
        RETURNING *
      `;

      // Get the complete profile with user data
      userProfile = await sql`
        SELECT up.*, au.name, au.email
        FROM user_profiles up
        JOIN auth_users au ON up.user_id = au.id
        WHERE up.id = ${newProfile[0].id}
      `;
    }

    const profile = userProfile[0];

    // Validate that profile.id exists before using it
    if (!profile || !profile.id) {
      return Response.json(
        { error: "Failed to create or retrieve user profile" },
        { status: 500 },
      );
    }

    // Get milestone information if provided
    let milestone = null;
    if (milestoneId) {
      const milestoneResult = await sql`
        SELECT * FROM milestones 
        WHERE id = ${milestoneId} AND athlete_id = ${profile.id}
      `;
      milestone = milestoneResult[0];
    }

    // Determine user tier based on profile data
    let userTier = "Bronze";
    if (profile.tier_level >= 5) userTier = "Elite";
    else if (profile.tier_level >= 4) userTier = "Platinum";
    else if (profile.tier_level >= 3) userTier = "Bluechip";
    else if (profile.tier_level >= 2) userTier = "Gold";
    else if (profile.tier_level >= 1) userTier = "Silver";

    // Extract milestone type from title/description
    let milestoneType = "general";
    if (milestone) {
      const title = milestone.title.toLowerCase();
      if (title.includes("takedown") || title.includes("wrestling"))
        milestoneType = "takedown";
      else if (title.includes("sprint") || title.includes("speed"))
        milestoneType = "sprint";
      else if (title.includes("endurance") || title.includes("distance"))
        milestoneType = "endurance";
      else if (title.includes("strength") || title.includes("power"))
        milestoneType = "strength";
    }

    // Generate questions using the service
    const questions = generateQuestion({
      userTier,
      milestoneType,
      biometricData: biometricData || {
        fatigueIndex: Math.floor(Math.random() * 25),
        heartRateVariability: Math.floor(Math.random() * 50) + 20,
        vo2Max: Math.floor(Math.random() * 30) + 50,
      },
      performanceData: performanceData || {
        roi: Math.floor(Math.random() * 25),
        riskScore: Math.floor(Math.random() * 8) + 1,
      },
    });

    // Store questions in database for tracking
    if (questions.length > 0) {
      for (const question of questions) {
        await sql`
          INSERT INTO motion_scans (
            athlete_id, 
            scan_data, 
            ai_score, 
            motion_type, 
            metadata
          ) VALUES (
            ${profile.id},
            ${JSON.stringify({ question: question.question, category: question.category })},
            ${Math.floor(Math.random() * 100)},
            ${"qaas_question"},
            ${JSON.stringify(question)}
          )
        `;
      }
    }

    return Response.json({
      success: true,
      questions,
      userProfile: {
        name: profile.name,
        tier: userTier,
        level: profile.tier_level,
      },
      milestone: milestone
        ? {
            id: milestone.id,
            title: milestone.title,
            type: milestoneType,
          }
        : null,
      metadata: {
        generated_at: new Date().toISOString(),
        total_questions: questions.length,
        service_version: "qaas_v1.0",
      },
    });
  } catch (error) {
    console.error("QaaS generation error:", error);
    return Response.json(
      { error: "Failed to generate questions" },
      { status: 500 },
    );
  }
}

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      athlete_id,
      sport_type,
      scenario_variables = {},
      scenario_count = 1000,
      baseline_performance,
    } = body;

    // Validate required parameters
    if (!athlete_id || !sport_type) {
      return Response.json(
        { error: "athlete_id and sport_type are required" },
        { status: 400 },
      );
    }

    // Get athlete data
    const athleteData = await sql`
      SELECT up.*, au.name, au.email, asim.simulation_data
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id  
      LEFT JOIN asset_simulations asim ON up.id = asim.athlete_id
      WHERE up.id = ${athlete_id}
      ORDER BY asim.created_at DESC
      LIMIT 1
    `;

    if (athleteData.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteData[0];

    // Determine baseline performance from recent data or provided value
    let athleteBaseline = baseline_performance;
    if (!athleteBaseline && athlete.simulation_data) {
      const simData = JSON.parse(athlete.simulation_data);
      athleteBaseline = simData.overall_score || 75;
    } else if (!athleteBaseline) {
      athleteBaseline = 75; // Default baseline
    }

    // Run Monte Carlo scenarios
    const scenarioAnalysis = runMonteCarloScenarios({
      athleteData: { baseline_performance: athleteBaseline },
      sportType: sport_type,
      scenarioCount: Math.min(scenario_count, 5000), // Cap at 5000 for performance
      variables: scenario_variables,
    });

    // Generate sport-specific "what if" questions
    const whatIfQuestions = generateWhatIfQuestions(
      sport_type,
      scenarioAnalysis,
      scenario_variables,
    );

    // Store scenario analysis for future reference
    const scenarioRecord = await sql`
      INSERT INTO motion_scans (
        athlete_id,
        scan_data,
        ai_score,
        motion_type,
        metadata
      ) VALUES (
        ${athlete_id},
        ${JSON.stringify({
          scenario_type: "monte_carlo_analysis",
          sport_type: sport_type,
          variables: scenario_variables,
          statistics: scenarioAnalysis.statistics,
        })},
        ${Math.round(scenarioAnalysis.statistics.performance_stats?.mean || 75)},
        ${"qaas_scenario"},
        ${JSON.stringify({
          scenario_count: scenario_count,
          baseline_performance: athleteBaseline,
          generated_by: "qaas_v2.0_monte_carlo",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      athlete: {
        id: athlete.id,
        name: athlete.name,
        sport_type: sport_type,
        baseline_performance: athleteBaseline,
      },
      scenario_analysis: scenarioAnalysis,
      what_if_questions: whatIfQuestions,
      scenario_id: scenarioRecord[0].id,
      metadata: {
        scenarios_run: scenario_count,
        generated_at: new Date().toISOString(),
        service_version: "qaas_v2.0_monte_carlo",
      },
    });
  } catch (error) {
    console.error("Monte Carlo scenario error:", error);
    return Response.json(
      { error: "Failed to run scenario analysis" },
      { status: 500 },
    );
  }
}

// Generate Sport-Specific "What If" Questions
function generateWhatIfQuestions(sportType, scenarioAnalysis, variables) {
  const questions = [];
  const stats = scenarioAnalysis.statistics;

  // Base scenario questions
  questions.push({
    id: "performance_variance",
    question: `With ${stats.performance_stats.std_dev.toFixed(1)}% performance variance, what training adjustments would reduce inconsistency?`,
    category: "Performance Optimization",
    sport_type: sportType,
    data_driven: true,
    scenario_context: "performance_variability",
  });

  // Sport-specific questions based on analysis
  switch (sportType) {
    case "wrestling":
    case "goalwrestling":
      if (stats.performance_stats.mean < 75) {
        questions.push({
          id: "wrestling_endurance",
          question:
            "What if we increased endurance training by 20% - how would this impact takedown efficiency in the third period?",
          category: "Wrestling Performance",
          sport_type: sportType,
          predicted_impact: "15-25% improvement in late-match performance",
        });
      }

      if (variables.opponent_strength > 80) {
        questions.push({
          id: "wrestling_strategy",
          question:
            "Against elite opponents, what position changes maximize scoring opportunities?",
          category: "Tactical Analysis",
          sport_type: sportType,
          scenario_context: "high_level_competition",
        });
      }
      break;

    case "rugby":
    case "soccer":
    case "basketball":
      if (stats.win_probability.mean < 0.6) {
        questions.push({
          id: "tactical_efficiency",
          question:
            "What if we improved team coordination by 15% - how would this affect win probability in close games?",
          category: "Tactical Sports Analysis",
          sport_type: sportType,
          predicted_impact: "10-20% increase in close game wins",
        });
      }

      if (variables.weather_condition < 0.8) {
        questions.push({
          id: "weather_adaptation",
          question:
            "What training modifications prepare the team for adverse weather conditions?",
          category: "Environmental Adaptation",
          sport_type: sportType,
          scenario_context: "weather_challenges",
        });
      }
      break;

    case "tennis":
    case "pickleball":
      if (scenarioAnalysis.outcomes.excellent.percentage < 30) {
        questions.push({
          id: "spike_score_optimization",
          question:
            "What if we focused 30% more training on spike score techniques - what's the projected ranking improvement?",
          category: "Racket Sports Performance",
          sport_type: sportType,
          predicted_impact: "2-4 ranking positions improvement",
        });
      }

      questions.push({
        id: "pressure_performance",
        question:
          "In high-pressure situations (opponent strength >85), what mental training reduces performance drop?",
        category: "Mental Performance",
        sport_type: sportType,
        scenario_context: "high_pressure_matches",
      });
      break;

    case "american_football":
      if (stats.performance_stats.std_dev > 15) {
        questions.push({
          id: "session_consistency",
          question:
            "What if we implemented position-specific consistency drills - how would this affect overall session reliability?",
          category: "American Football Performance",
          sport_type: sportType,
          predicted_impact: "20-30% reduction in performance variance",
        });
      }

      if (variables.position_change) {
        questions.push({
          id: "position_adaptability",
          question:
            "What cross-training reduces performance loss when switching positions mid-season?",
          category: "Positional Flexibility",
          sport_type: sportType,
          scenario_context: "position_transitions",
        });
      }
      break;
  }

  // Risk-based questions
  if (
    stats.risk_stats.high_risk_scenarios >
    scenarioAnalysis.scenarios.length * 0.25
  ) {
    questions.push({
      id: "risk_mitigation",
      question: `With ${((stats.risk_stats.high_risk_scenarios / scenarioAnalysis.scenarios.length) * 100).toFixed(1)}% high-risk scenarios, what preventive measures reduce injury probability?`,
      category: "Risk Management",
      sport_type: sportType,
      data_driven: true,
    });
  }

  return questions;
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Get recent QaaS questions for the user
    const recentQuestions = await sql`
      SELECT 
        ms.*,
        m.title as milestone_title
      FROM motion_scans ms
      LEFT JOIN milestones m ON (ms.metadata->>'milestoneId')::int = m.id
      WHERE ms.athlete_id = (
        SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
      )
      AND ms.motion_type = 'qaas_question'
      ORDER BY ms.created_at DESC
      LIMIT 20
    `;

    const formattedQuestions = recentQuestions.map((q) => ({
      id: q.id,
      question: q.scan_data.question,
      category: q.scan_data.category,
      milestone_title: q.milestone_title,
      created_at: q.created_at,
      metadata: q.metadata,
    }));

    return Response.json({
      success: true,
      recent_questions: formattedQuestions,
      total_count: recentQuestions.length,
    });
  } catch (error) {
    console.error("QaaS history error:", error);
    return Response.json(
      { error: "Failed to retrieve question history" },
      { status: 500 },
    );
  }
}
