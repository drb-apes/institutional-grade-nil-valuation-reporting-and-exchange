import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const sessionType = searchParams.get("session") || "training";
    const timeRange = searchParams.get("timeRange") || "24h";
    const includeHistory = searchParams.get("includeHistory") === "true";

    // Verify coach/scout access
    const userProfile = await sql`
      SELECT * FROM user_profiles 
      WHERE user_id = ${session.user.id} 
      AND user_type IN ('coach', 'scout', 'agent')
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "Coach/Scout access required" },
        { status: 403 },
      );
    }

    // Get time filter based on session type and range
    const timeFilter = getTimeFilter(timeRange);

    // Fetch team athletes and their latest biometric data
    const teamBiometrics = await sql`
      SELECT 
        up.id,
        up.user_id,
        au.name,
        au.email,
        up.tier_level,
        up.reputation_score,
        ms.ai_score as performance,
        ms.scan_data,
        ms.created_at as last_scan,
        COUNT(ms2.id) as total_scans
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN motion_scans ms ON up.id = ms.athlete_id
        AND ms.id = (
          SELECT ms_latest.id 
          FROM motion_scans ms_latest 
          WHERE ms_latest.athlete_id = up.id 
          ORDER BY ms_latest.created_at DESC 
          LIMIT 1
        )
      LEFT JOIN motion_scans ms2 ON up.id = ms2.athlete_id 
        ${timeFilter}
      WHERE up.user_type = 'athlete'
      GROUP BY up.id, up.user_id, au.name, au.email, up.tier_level, 
               up.reputation_score, ms.ai_score, ms.scan_data, ms.created_at
      ORDER BY ms.ai_score DESC NULLS LAST, up.tier_level DESC
      LIMIT 20
    `;

    // Process biometric data for each athlete
    const processedBiometrics = teamBiometrics.map((athlete) => {
      const biometricData = processBiometricData(
        athlete.scan_data,
        sessionType,
        athlete.total_scans,
      );

      return {
        id: athlete.id,
        name: athlete.name || `Athlete ${athlete.id}`,
        position: extractPosition(athlete.scan_data),
        performance: Math.round(athlete.performance || 0),
        tier: athlete.tier_level,
        lastScanTime: athlete.last_scan,
        totalScans: athlete.total_scans,
        ...biometricData,
        alerts: generateAthleteAlerts(biometricData, sessionType),
      };
    });

    // Calculate team-wide statistics
    const teamStats = calculateTeamStats(processedBiometrics, sessionType);

    // Get historical performance trends if requested
    let historicalTrends = null;
    if (includeHistory) {
      historicalTrends = await getHistoricalTrends(
        teamBiometrics.map((a) => a.id),
        timeRange,
      );
    }

    return Response.json({
      sessionType,
      timeRange,
      teamStats,
      athletes: processedBiometrics,
      historicalTrends,
      lastUpdated: new Date().toISOString(),
      metadata: {
        totalAthletes: processedBiometrics.length,
        averagePerformance: teamStats.averagePerformance,
        highAlertCount: processedBiometrics.filter((a) =>
          a.alerts.some((alert) => alert.severity === "high"),
        ).length,
      },
    });
  } catch (error) {
    console.error("Team biometrics API error:", error);
    return Response.json(
      {
        error: "Failed to fetch team biometrics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function getTimeFilter(timeRange) {
  switch (timeRange) {
    case "1h":
      return sql.unsafe(`AND ms2.created_at >= NOW() - INTERVAL '1 hour'`);
    case "24h":
      return sql.unsafe(`AND ms2.created_at >= NOW() - INTERVAL '24 hours'`);
    case "7d":
      return sql.unsafe(`AND ms2.created_at >= NOW() - INTERVAL '7 days'`);
    case "30d":
      return sql.unsafe(`AND ms2.created_at >= NOW() - INTERVAL '30 days'`);
    default:
      return sql.unsafe(`AND ms2.created_at >= NOW() - INTERVAL '24 hours'`);
  }
}

function processBiometricData(scanData, sessionType, totalScans) {
  if (!scanData) {
    return {
      stress: 50,
      fatigue: 50,
      heartRate: 75,
      recovery: 70,
      hydration: 80,
      focus: 75,
    };
  }

  // Extract biometric values from scan data
  const biometrics =
    scanData.biometric_calibration || scanData.biometrics || {};

  // Apply session-type specific adjustments
  const sessionMultipliers = {
    training: { stress: 0.8, fatigue: 1.0 },
    season: { stress: 1.2, fatigue: 1.1 },
    playoff: { stress: 1.5, fatigue: 1.2 },
  };

  const multiplier =
    sessionMultipliers[sessionType] || sessionMultipliers.training;

  // Calculate derived metrics
  const baseStress = (biometrics.stress || 3) * 20; // Convert 1-5 scale to percentage
  const baseFatigue = (biometrics.fatigue || 3) * 20;

  return {
    stress: Math.min(100, Math.round(baseStress * multiplier.stress)),
    fatigue: Math.min(100, Math.round(baseFatigue * multiplier.fatigue)),
    heartRate: calculateHeartRate(biometrics, sessionType),
    recovery: calculateRecovery(biometrics, totalScans),
    hydration: calculateHydration(biometrics, sessionType),
    focus: calculateFocus(biometrics, sessionType),
  };
}

function extractPosition(scanData) {
  if (!scanData) return "Unknown";

  // Try to extract position from various scan data fields
  const positionHints = [
    scanData.position,
    scanData.athlete_info?.position,
    scanData.profile_data?.position,
    scanData.metadata?.position,
  ];

  const position = positionHints.find((p) => p && typeof p === "string");
  return position || "ATH"; // Default to "Athlete"
}

function calculateHeartRate(biometrics, sessionType) {
  const baseRate = 70;
  const stressImpact = (biometrics.stress || 3) * 5;
  const sessionImpact = {
    training: 10,
    season: 20,
    playoff: 30,
  };

  return Math.round(
    baseRate + stressImpact + (sessionImpact[sessionType] || 10),
  );
}

function calculateRecovery(biometrics, totalScans) {
  const baseRecovery = 80;
  const fatigueImpact = (biometrics.fatigue || 3) * -8;
  const experienceBonus = Math.min(20, totalScans * 0.5); // More scans = better recovery tracking

  return Math.max(
    20,
    Math.min(100, Math.round(baseRecovery + fatigueImpact + experienceBonus)),
  );
}

function calculateHydration(biometrics, sessionType) {
  const baseHydration = 85;
  const sessionImpact = {
    training: -5,
    season: -10,
    playoff: -15,
  };

  return Math.max(
    50,
    Math.min(
      100,
      Math.round(baseHydration + (sessionImpact[sessionType] || -5)),
    ),
  );
}

function calculateFocus(biometrics, sessionType) {
  const baseFocus = 80;
  const stressImpact = (biometrics.stress || 3) * -5;
  const cohesionBonus = (biometrics.cohesion || 3) * 3;

  return Math.max(
    30,
    Math.min(100, Math.round(baseFocus + stressImpact + cohesionBonus)),
  );
}

function generateAthleteAlerts(biometricData, sessionType) {
  const alerts = [];

  // High stress alert
  if (biometricData.stress >= 80) {
    alerts.push({
      type: "stress",
      severity: "high",
      message: "Elevated stress levels detected",
      recommendation: "Consider mental wellness break",
    });
  }

  // High fatigue alert
  if (biometricData.fatigue >= 85) {
    alerts.push({
      type: "fatigue",
      severity: "high",
      message: "High fatigue levels",
      recommendation: "Rest and recovery recommended",
    });
  }

  // Low hydration alert
  if (biometricData.hydration <= 60) {
    alerts.push({
      type: "hydration",
      severity: "medium",
      message: "Hydration levels low",
      recommendation: "Increase fluid intake",
    });
  }

  // Low focus in critical sessions
  if (
    biometricData.focus <= 50 &&
    (sessionType === "playoff" || sessionType === "season")
  ) {
    alerts.push({
      type: "focus",
      severity: "high",
      message: "Focus levels concerning for critical session",
      recommendation: "Mental preparation needed",
    });
  }

  return alerts;
}

function calculateTeamStats(athletes, sessionType) {
  if (athletes.length === 0) {
    return {
      averagePerformance: 0,
      averageStress: 0,
      averageFatigue: 0,
      teamMorale: 50,
      readinessLevel: "Unknown",
    };
  }

  const totals = athletes.reduce(
    (acc, athlete) => {
      acc.performance += athlete.performance;
      acc.stress += athlete.stress;
      acc.fatigue += athlete.fatigue;
      acc.recovery += athlete.recovery;
      acc.focus += athlete.focus;
      return acc;
    },
    { performance: 0, stress: 0, fatigue: 0, recovery: 0, focus: 0 },
  );

  const count = athletes.length;
  const averagePerformance = Math.round(totals.performance / count);
  const averageStress = Math.round(totals.stress / count);
  const averageFatigue = Math.round(totals.fatigue / count);
  const averageRecovery = Math.round(totals.recovery / count);
  const averageFocus = Math.round(totals.focus / count);

  // Calculate team morale based on multiple factors
  const teamMorale = Math.round(
    averagePerformance * 0.3 +
      (100 - averageStress) * 0.2 +
      (100 - averageFatigue) * 0.2 +
      averageRecovery * 0.15 +
      averageFocus * 0.15,
  );

  // Determine readiness level
  let readinessLevel = "Ready";
  if (averageStress > 70 || averageFatigue > 75) {
    readinessLevel = "Caution";
  }
  if (averageStress > 85 || averageFatigue > 85) {
    readinessLevel = "Not Ready";
  }

  return {
    averagePerformance,
    averageStress,
    averageFatigue,
    averageRecovery,
    averageFocus,
    teamMorale,
    readinessLevel,
    sessionType,
    totalAthletes: count,
  };
}

async function getHistoricalTrends(athleteIds, timeRange) {
  if (athleteIds.length === 0) return null;

  const timeFilter = getTimeFilter(timeRange);

  const historicalData = await sql`
    SELECT 
      athlete_id,
      ai_score,
      scan_data,
      created_at,
      DATE_TRUNC('hour', created_at) as hour_bucket
    FROM motion_scans
    WHERE athlete_id = ANY(${athleteIds})
    ${timeFilter}
    ORDER BY created_at ASC
  `;

  // Group by hour and calculate averages
  const hourlyAverages = {};

  historicalData.forEach((scan) => {
    const hourKey = scan.hour_bucket.toISOString();
    if (!hourlyAverages[hourKey]) {
      hourlyAverages[hourKey] = {
        timestamp: hourKey,
        performances: [],
        stressLevels: [],
        fatigueLevels: [],
      };
    }

    hourlyAverages[hourKey].performances.push(scan.ai_score || 0);

    const biometrics = scan.scan_data?.biometric_calibration || {};
    hourlyAverages[hourKey].stressLevels.push((biometrics.stress || 3) * 20);
    hourlyAverages[hourKey].fatigueLevels.push((biometrics.fatigue || 3) * 20);
  });

  // Calculate averages for each hour
  const trends = Object.values(hourlyAverages).map((hour) => ({
    timestamp: hour.timestamp,
    averagePerformance: Math.round(
      hour.performances.reduce((a, b) => a + b, 0) / hour.performances.length,
    ),
    averageStress: Math.round(
      hour.stressLevels.reduce((a, b) => a + b, 0) / hour.stressLevels.length,
    ),
    averageFatigue: Math.round(
      hour.fatigueLevels.reduce((a, b) => a + b, 0) / hour.fatigueLevels.length,
    ),
    dataPoints: hour.performances.length,
  }));

  return trends.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
}
