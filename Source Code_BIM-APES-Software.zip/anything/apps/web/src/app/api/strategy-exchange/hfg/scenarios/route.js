import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Quant-style scenario modeling
export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      scenarioName,
      scenarioType,
      athletes, // Array of athlete IDs
      fanSignalProjection,
      creditDeploymentPlan,
      sponsorWindowId,
    } = await req.json();

    if (!scenarioName || !scenarioType || !athletes || athletes.length === 0) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    // Fetch athlete data
    const athleteData = await sql`
      SELECT 
        up.id,
        up.user_id,
        au.name,
        up.reputation_score,
        up.total_contributions,
        COALESCE(fe.total_boosts, 0) as total_boosts
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN (
        SELECT athlete_id, COUNT(*) as total_boosts
        FROM fan_engagement_actions
        WHERE action_type = 'boost'
        GROUP BY athlete_id
      ) fe ON up.id = fe.athlete_id
      WHERE up.id = ANY(${athletes})
    `;

    // Get recent fan signals
    const fanSignals = await sql`
      SELECT athlete_id, COUNT(*) as signal_count
      FROM strategy_exchange_signals
      WHERE athlete_id = ANY(${athletes})
      AND created_at > NOW() - INTERVAL '7 days'
      GROUP BY athlete_id
    `;

    // Build index lift model
    const indexLiftModel = {};
    for (const athlete of athleteData) {
      const signalData = fanSignals.find((s) => s.athlete_id === athlete.id);
      const signalCount = parseInt(signalData?.signal_count || 0);

      // Fan signal component
      const fanSignalLift = Math.min((signalCount / 5000) * 1.8, 3.8);

      // Credit deployment component
      const credits = creditDeploymentPlan?.[athlete.id] || [];
      const creditLift = credits.reduce((sum, c) => {
        const creditEffect =
          {
            performance_boost: 0.8,
            momentum_stabilizer: 0.6,
            spotlight: 1.0,
            event_window: 1.5,
          }[c.type] || 0.5;
        return sum + creditEffect * (c.quantity || 1);
      }, 0);

      // Team momentum component (simplified)
      const teamMomentumLift = 0.6;

      // Total index lift
      const totalIndexLift = fanSignalLift + creditLift + teamMomentumLift;

      // NIL valuation impact ($110-$160 per index point)
      const nilLiftLow = totalIndexLift * 110;
      const nilLiftHigh = totalIndexLift * 160;

      indexLiftModel[athlete.id] = {
        athleteName: athlete.name,
        fanSignalLift,
        creditLift,
        teamMomentumLift,
        totalIndexLift,
        nilLiftRange: {
          low: Math.round(nilLiftLow),
          high: Math.round(nilLiftHigh),
        },
      };
    }

    // Calculate sponsor ROI projection
    let sponsorROI = null;
    if (sponsorWindowId) {
      const [sponsorWindow] = await sql`
        SELECT * FROM sponsor_activation_windows
        WHERE id = ${sponsorWindowId}
      `;

      if (sponsorWindow) {
        const totalIndexLift = Object.values(indexLiftModel).reduce(
          (sum, m) => sum + m.totalIndexLift,
          0,
        );

        sponsorROI = {
          expectedImpressions: sponsorWindow.expected_impressions,
          impressionMultiplier: 1.0 + totalIndexLift * 0.15,
          engagementLift: Math.min(totalIndexLift * 3.5, 18),
          visibilityIncrease: Math.min(totalIndexLift * 1.5, 8),
          roiMultiplier: 1.0 + totalIndexLift * 0.2,
        };
      }
    }

    // Risk analysis
    const riskAnalysis = {
      volatilityRisk: "low",
      complianceRisk: "none",
      indexCap: "within_limits",
      fanSignalDependency: Object.values(indexLiftModel).some(
        (m) => m.fanSignalLift > 2.0,
      )
        ? "moderate"
        : "low",
      creditOverdeployment: "none",
    };

    // Quant desk report
    const quantDeskReport = {
      summary: `${scenarioType.replace("_", " ").toUpperCase()} scenario for ${athletes.length} athlete(s)`,
      expectedIndexLift:
        Object.values(indexLiftModel).reduce(
          (sum, m) => sum + m.totalIndexLift,
          0,
        ) / athletes.length,
      expectedNILLift: {
        low: Object.values(indexLiftModel).reduce(
          (sum, m) => sum + m.nilLiftRange.low,
          0,
        ),
        high: Object.values(indexLiftModel).reduce(
          (sum, m) => sum + m.nilLiftRange.high,
          0,
        ),
      },
      creditsRequired: Object.values(creditDeploymentPlan || {}).flat().length,
      fanSignalSynergy: Object.values(indexLiftModel).some(
        (m) => m.fanSignalLift > 1.5,
      ),
      complianceStatus: "clean",
      recommendation: "proceed",
    };

    // Create scenario
    const [scenario] = await sql`
      INSERT INTO hfg_scenarios (
        scenario_name,
        team_owner_id,
        scenario_type,
        athletes,
        fan_signal_projection,
        credit_deployment_plan,
        index_lift_model,
        nil_valuation_impact,
        sponsor_roi_projection,
        risk_analysis,
        quant_desk_report,
        scenario_status
      ) VALUES (
        ${scenarioName},
        ${owner.id},
        ${scenarioType},
        ${JSON.stringify(athleteData)},
        ${JSON.stringify(fanSignalProjection || {})},
        ${JSON.stringify(creditDeploymentPlan || {})},
        ${JSON.stringify(indexLiftModel)},
        ${JSON.stringify(quantDeskReport.expectedNILLift)},
        ${JSON.stringify(sponsorROI)},
        ${JSON.stringify(riskAnalysis)},
        ${JSON.stringify(quantDeskReport)},
        'draft'
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      scenario,
      indexLiftModel,
      sponsorROI,
      riskAnalysis,
      quantDeskReport,
    });
  } catch (error) {
    console.error("HFG scenario creation error:", error);
    return Response.json(
      { error: "Failed to create scenario" },
      { status: 500 },
    );
  }
}

export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const status = url.searchParams.get("status");

    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    let query = sql`
      SELECT * FROM hfg_scenarios
      WHERE team_owner_id = ${owner.id}
    `;

    if (status) {
      query = sql`
        SELECT * FROM hfg_scenarios
        WHERE team_owner_id = ${owner.id}
        AND scenario_status = ${status}
      `;
    }

    query = sql`${query} ORDER BY created_at DESC`;

    const scenarios = await query;

    return Response.json({ scenarios });
  } catch (error) {
    console.error("Get scenarios error:", error);
    return Response.json(
      { error: "Failed to fetch scenarios" },
      { status: 500 },
    );
  }
}
