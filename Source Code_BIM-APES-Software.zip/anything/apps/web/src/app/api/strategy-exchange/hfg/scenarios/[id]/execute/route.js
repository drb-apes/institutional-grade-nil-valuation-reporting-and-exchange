import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(req, { params }) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { id } = params;

    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    const [scenario] = await sql`
      SELECT * FROM hfg_scenarios
      WHERE id = ${parseInt(id)}
      AND team_owner_id = ${owner.id}
    `;

    if (!scenario) {
      return Response.json({ error: "Scenario not found" }, { status: 404 });
    }

    if (
      scenario.scenario_status !== "approved" &&
      scenario.scenario_status !== "draft"
    ) {
      return Response.json(
        { error: "Scenario cannot be executed" },
        { status: 400 },
      );
    }

    // Execute credit deployments
    const creditPlan = scenario.credit_deployment_plan;
    const deployments = [];

    for (const [athleteId, credits] of Object.entries(creditPlan)) {
      for (const credit of credits) {
        // Find available credit
        const [availableCredit] = await sql`
          SELECT * FROM buy_in_credits
          WHERE owner_id = ${owner.id}
          AND credit_type = ${credit.type}
          AND credit_status = 'active'
          LIMIT 1
        `;

        if (!availableCredit) {
          console.warn(
            `No available ${credit.type} credit for athlete ${athleteId}`,
          );
          continue;
        }

        // Deploy credit
        const now = new Date();
        const effectEnd = new Date(
          now.getTime() + availableCredit.duration_hours * 60 * 60 * 1000,
        );

        const [deployment] = await sql`
          INSERT INTO credit_deployments (
            credit_id,
            owner_id,
            athlete_id,
            deployment_type,
            index_lift_target,
            effect_start,
            effect_end,
            compliance_log
          ) VALUES (
            ${availableCredit.id},
            ${owner.id},
            ${parseInt(athleteId)},
            'hfg_scenario',
            ${availableCredit.effect_magnitude},
            ${now.toISOString()},
            ${effectEnd.toISOString()},
            ${JSON.stringify({
              scenarioId: scenario.id,
              scenarioName: scenario.scenario_name,
              deployedAt: now.toISOString(),
            })}
          )
          RETURNING *
        `;

        await sql`
          UPDATE buy_in_credits
          SET credit_status = 'deployed',
              deployed_at = ${now.toISOString()},
              expires_at = ${effectEnd.toISOString()},
              athlete_id = ${parseInt(athleteId)}
          WHERE id = ${availableCredit.id}
        `;

        deployments.push(deployment);
      }
    }

    // Update scenario status
    const [updated] = await sql`
      UPDATE hfg_scenarios
      SET 
        scenario_status = 'executing',
        executed_at = CURRENT_TIMESTAMP
      WHERE id = ${parseInt(id)}
      RETURNING *
    `;

    return Response.json({
      success: true,
      scenario: updated,
      deploymentsCreated: deployments.length,
      deployments,
    });
  } catch (error) {
    console.error("Execute scenario error:", error);
    return Response.json(
      { error: "Failed to execute scenario" },
      { status: 500 },
    );
  }
}
