import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      creditId,
      athleteId,
      deploymentType,
      sponsorWindowId,
      rivalryWeek = false,
      playoffWindow = false,
    } = await req.json();

    if (!creditId || !athleteId) {
      return Response.json(
        { error: "Credit ID and athlete ID required" },
        { status: 400 },
      );
    }

    // Get team owner
    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    // Get credit
    const [credit] = await sql`
      SELECT * FROM buy_in_credits
      WHERE id = ${creditId}
      AND owner_id = ${owner.id}
      AND credit_status = 'active'
    `;

    if (!credit) {
      return Response.json(
        { error: "Credit not found or already deployed" },
        { status: 404 },
      );
    }

    // Get athlete
    const [athlete] = await sql`
      SELECT * FROM user_profiles
      WHERE id = ${athleteId}
    `;

    if (!athlete) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const now = new Date();
    const effectEnd = new Date(
      now.getTime() + credit.duration_hours * 60 * 60 * 1000,
    );

    // Get recent fan signals for synergy calculation
    const recentSignals = await sql`
      SELECT COUNT(*) as count
      FROM strategy_exchange_signals
      WHERE athlete_id = ${athleteId}
      AND created_at > NOW() - INTERVAL '72 hours'
    `;

    const fanSignalCount = parseInt(recentSignals[0]?.count || 0);
    const fanSignalSynergy = Math.min(fanSignalCount / 1000, 2.0); // Cap at 2x

    // Calculate index lift target
    const indexLiftTarget =
      credit.effect_magnitude * (1 + fanSignalSynergy * 0.3);

    // Create deployment
    const [deployment] = await sql`
      INSERT INTO credit_deployments (
        credit_id,
        owner_id,
        athlete_id,
        deployment_type,
        index_lift_target,
        fan_signal_synergy,
        sponsor_window_id,
        rivalry_week,
        playoff_window,
        effect_start,
        effect_end,
        compliance_log
      ) VALUES (
        ${creditId},
        ${owner.id},
        ${athleteId},
        ${deploymentType},
        ${indexLiftTarget},
        ${fanSignalSynergy},
        ${sponsorWindowId || null},
        ${rivalryWeek},
        ${playoffWindow},
        ${now.toISOString()},
        ${effectEnd.toISOString()},
        ${JSON.stringify({
          deployedBy: session.user.email,
          deployedAt: now.toISOString(),
          complianceChecked: true,
          nonFinancialConfirmed: true,
        })}
      )
      RETURNING *
    `;

    // Update credit status
    await sql`
      UPDATE buy_in_credits
      SET 
        credit_status = 'deployed',
        deployed_at = ${now.toISOString()},
        expires_at = ${effectEnd.toISOString()},
        athlete_id = ${athleteId}
      WHERE id = ${creditId}
    `;

    // In production, this would trigger index recalculation
    // For now, simulate the effect
    const simulatedIndexLift = indexLiftTarget * (0.9 + Math.random() * 0.2);

    return Response.json({
      success: true,
      deployment,
      credit,
      athlete,
      projectedImpact: {
        indexLiftTarget,
        fanSignalSynergy,
        effectDuration: credit.duration_hours,
        effectEnd,
        estimatedNILLift: simulatedIndexLift * 120, // $110-160 per index point
      },
    });
  } catch (error) {
    console.error("Credit deployment error:", error);
    return Response.json({ error: "Failed to deploy credit" }, { status: 500 });
  }
}

export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const athleteId = url.searchParams.get("athleteId");

    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    let query = sql`
      SELECT 
        cd.*,
        bc.credit_type,
        bc.effect_magnitude,
        bc.duration_hours,
        up.user_id,
        au.name as athlete_name
      FROM credit_deployments cd
      JOIN buy_in_credits bc ON cd.credit_id = bc.id
      JOIN user_profiles up ON cd.athlete_id = up.id
      JOIN auth_users au ON up.user_id = au.id
      WHERE cd.owner_id = ${owner.id}
    `;

    if (athleteId) {
      query = sql`
        SELECT 
          cd.*,
          bc.credit_type,
          bc.effect_magnitude,
          bc.duration_hours,
          up.user_id,
          au.name as athlete_name
        FROM credit_deployments cd
        JOIN buy_in_credits bc ON cd.credit_id = bc.id
        JOIN user_profiles up ON cd.athlete_id = up.id
        JOIN auth_users au ON up.user_id = au.id
        WHERE cd.owner_id = ${owner.id}
        AND cd.athlete_id = ${parseInt(athleteId)}
      `;
    }

    query = sql`${query} ORDER BY cd.deployed_at DESC LIMIT 100`;

    const deployments = await query;

    return Response.json({ deployments });
  } catch (error) {
    console.error("Get deployments error:", error);
    return Response.json(
      { error: "Failed to fetch deployments" },
      { status: 500 },
    );
  }
}
