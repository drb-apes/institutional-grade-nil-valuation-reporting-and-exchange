import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { organizationName, leagueAffiliation, institutionalWallet } =
      await req.json();

    if (!organizationName) {
      return Response.json(
        { error: "Organization name is required" },
        { status: 400 },
      );
    }

    // Check if owner profile already exists
    const existing = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (existing.length > 0) {
      return Response.json(
        { error: "Team owner profile already exists" },
        { status: 400 },
      );
    }

    // Create team owner profile
    const [owner] = await sql`
      INSERT INTO team_owner_profiles (
        user_id,
        organization_name,
        league_affiliation,
        institutional_wallet,
        onboarding_step,
        verification_status
      ) VALUES (
        ${session.user.id},
        ${organizationName},
        ${leagueAffiliation || null},
        ${institutionalWallet || null},
        1,
        'pending'
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      owner,
      nextStep: "institutional_verification",
    });
  } catch (error) {
    console.error("Team owner onboarding error:", error);
    return Response.json(
      { error: "Failed to create team owner profile" },
      { status: 500 },
    );
  }
}

export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json({ exists: false });
    }

    return Response.json({
      exists: true,
      owner,
      onboardingComplete: owner.onboarding_completed,
      currentStep: owner.onboarding_step,
    });
  } catch (error) {
    console.error("Get team owner error:", error);
    return Response.json({ error: "Failed to fetch profile" }, { status: 500 });
  }
}

export async function PATCH(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { step, completeOnboarding } = await req.json();

    const updates = [];
    const values = [];

    if (step) {
      updates.push("onboarding_step = $" + (updates.length + 1));
      values.push(step);
    }

    if (completeOnboarding) {
      updates.push("onboarding_completed = $" + (updates.length + 1));
      values.push(true);
    }

    values.push(session.user.id);

    const [owner] = await sql(
      `UPDATE team_owner_profiles 
       SET ${updates.join(", ")}
       WHERE user_id = $${values.length}
       RETURNING *`,
      values,
    );

    return Response.json({ success: true, owner });
  } catch (error) {
    console.error("Update onboarding error:", error);
    return Response.json(
      { error: "Failed to update onboarding" },
      { status: 500 },
    );
  }
}
