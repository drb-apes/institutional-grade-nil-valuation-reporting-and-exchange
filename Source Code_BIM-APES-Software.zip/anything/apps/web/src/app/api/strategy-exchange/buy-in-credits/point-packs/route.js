import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

const POINT_PACKS = [
  { size: 1000, cost: 900, discount: 10 },
  { size: 5000, cost: 4000, discount: 20 },
  { size: 20000, cost: 14000, discount: 30 },
  { size: 50000, cost: 30000, discount: 40 },
];

export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      packSize,
      paymentMethod = "card",
      transactionId,
    } = await req.json();

    if (!packSize) {
      return Response.json({ error: "Pack size required" }, { status: 400 });
    }

    const pack = POINT_PACKS.find((p) => p.size === packSize);
    if (!pack) {
      return Response.json({ error: "Invalid pack size" }, { status: 400 });
    }

    // Get team owner profile
    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    if (owner.verification_status !== "verified") {
      return Response.json(
        { error: "Team owner not verified" },
        { status: 403 },
      );
    }

    // In production, process payment via Stripe/crypto here
    // For now, simulate successful payment

    // Record purchase
    const [purchase] = await sql`
      INSERT INTO point_pack_purchases (
        owner_id,
        pack_size,
        cost_usd,
        discount_percentage,
        points_awarded,
        purchase_method,
        transaction_hash
      ) VALUES (
        ${owner.id},
        ${pack.size},
        ${pack.cost},
        ${pack.discount},
        ${pack.size},
        ${paymentMethod},
        ${transactionId || null}
      )
      RETURNING *
    `;

    // Add points to owner balance
    const [updatedOwner] = await sql`
      UPDATE team_owner_profiles
      SET 
        point_balance = point_balance + ${pack.size},
        total_spend_usd = total_spend_usd + ${pack.cost}
      WHERE id = ${owner.id}
      RETURNING *
    `;

    return Response.json({
      success: true,
      purchase,
      newBalance: updatedOwner.point_balance,
      pointsAwarded: pack.size,
      costUSD: pack.cost,
      discount: pack.discount,
    });
  } catch (error) {
    console.error("Point pack purchase error:", error);
    return Response.json(
      { error: "Failed to purchase point pack" },
      { status: 500 },
    );
  }
}

export async function GET() {
  return Response.json({
    packs: POINT_PACKS.map((pack) => ({
      ...pack,
      baseValue: Math.round(pack.cost / (1 - pack.discount / 100)),
      savings: Math.round(pack.cost / (1 - pack.discount / 100)) - pack.cost,
    })),
  });
}
