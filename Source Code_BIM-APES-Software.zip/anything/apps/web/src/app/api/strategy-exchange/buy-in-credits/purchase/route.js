import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Pricing models for all three tiers
const HARD_ASSET_PRICING = {
  performance_boost: { price: 250, duration: 24, effect: 0.8 },
  momentum_stabilizer: { price: 400, duration: 48, effect: 0.6 },
  spotlight: { price: 600, duration: 24, effect: 1.0 },
  event_window: { price: 1200, duration: 72, effect: 1.5 },
};

const POINT_SYSTEM_COSTS = {
  performance_boost: 100,
  momentum_stabilizer: 180,
  spotlight: 250,
  event_window: 500,
};

const STABLECOIN_PRICING = {
  performance_boost: 250,
  momentum_stabilizer: 400,
  spotlight: 600,
  event_window: 1200,
};

export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      creditType,
      purchaseMethod,
      quantity = 1,
      stablecoinTxHash,
    } = await req.json();

    if (!creditType || !purchaseMethod) {
      return Response.json(
        { error: "Credit type and purchase method required" },
        { status: 400 },
      );
    }

    // Get team owner profile
    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    if (owner.verification_status !== "verified") {
      return Response.json(
        { error: "Team owner not verified" },
        { status: 403 },
      );
    }

    let purchasePrice = 0;
    let pointsCost = null;
    let stablecoinAmount = null;
    let duration = 24;
    let effectMagnitude = 1.0;

    // Calculate pricing based on method
    if (purchaseMethod === "hard_asset") {
      const pricing = HARD_ASSET_PRICING[creditType];
      if (!pricing) {
        return Response.json({ error: "Invalid credit type" }, { status: 400 });
      }
      purchasePrice = pricing.price * quantity;
      duration = pricing.duration;
      effectMagnitude = pricing.effect;
    } else if (purchaseMethod === "point_system") {
      const cost = POINT_SYSTEM_COSTS[creditType];
      if (!cost) {
        return Response.json({ error: "Invalid credit type" }, { status: 400 });
      }

      pointsCost = cost * quantity;

      // Check if owner has enough points
      if (owner.point_balance < pointsCost) {
        return Response.json(
          {
            error: "Insufficient points",
            required: pointsCost,
            available: owner.point_balance,
          },
          { status: 400 },
        );
      }

      // Deduct points
      await sql`
        UPDATE team_owner_profiles
        SET point_balance = point_balance - ${pointsCost}
        WHERE id = ${owner.id}
      `;

      purchasePrice = 0; // Points already purchased
      duration = HARD_ASSET_PRICING[creditType]?.duration || 24;
      effectMagnitude = HARD_ASSET_PRICING[creditType]?.effect || 1.0;
    } else if (purchaseMethod === "stablecoin") {
      const price = STABLECOIN_PRICING[creditType];
      if (!price) {
        return Response.json({ error: "Invalid credit type" }, { status: 400 });
      }

      stablecoinAmount = price * quantity;
      purchasePrice = price * quantity;
      duration = HARD_ASSET_PRICING[creditType]?.duration || 24;
      effectMagnitude = HARD_ASSET_PRICING[creditType]?.effect || 1.0;

      // In production, verify stablecoin transaction
      if (!stablecoinTxHash) {
        return Response.json(
          { error: "Stablecoin transaction hash required" },
          { status: 400 },
        );
      }
    }

    // Create credits
    const credits = [];
    for (let i = 0; i < quantity; i++) {
      const [credit] = await sql`
        INSERT INTO buy_in_credits (
          credit_type,
          owner_id,
          purchase_method,
          purchase_price,
          points_cost,
          stablecoin_amount,
          duration_hours,
          effect_magnitude
        ) VALUES (
          ${creditType},
          ${owner.id},
          ${purchaseMethod},
          ${purchasePrice / quantity},
          ${pointsCost ? pointsCost / quantity : null},
          ${stablecoinAmount || null},
          ${duration},
          ${effectMagnitude}
        )
        RETURNING *
      `;
      credits.push(credit);
    }

    // Update owner stats
    await sql`
      UPDATE team_owner_profiles
      SET 
        total_credits_purchased = total_credits_purchased + ${quantity},
        total_spend_usd = total_spend_usd + ${purchasePrice}
      WHERE id = ${owner.id}
    `;

    return Response.json({
      success: true,
      credits,
      totalCost: purchasePrice,
      pointsDeducted: pointsCost,
      stablecoinAmount,
      quantity,
    });
  } catch (error) {
    console.error("Buy-In Credit purchase error:", error);
    return Response.json(
      { error: "Failed to purchase credits" },
      { status: 500 },
    );
  }
}

export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const status = url.searchParams.get("status") || "active";

    const [owner] = await sql`
      SELECT * FROM team_owner_profiles
      WHERE user_id = ${session.user.id}
    `;

    if (!owner) {
      return Response.json(
        { error: "Team owner profile not found" },
        { status: 404 },
      );
    }

    const credits = await sql`
      SELECT * FROM buy_in_credits
      WHERE owner_id = ${owner.id}
      AND credit_status = ${status}
      ORDER BY purchased_at DESC
    `;

    return Response.json({
      credits,
      summary: {
        totalActive: credits.length,
        totalPurchased: owner.total_credits_purchased,
        totalSpent: owner.total_spend_usd,
        pointBalance: owner.point_balance,
      },
    });
  } catch (error) {
    console.error("Get credits error:", error);
    return Response.json({ error: "Failed to fetch credits" }, { status: 500 });
  }
}
