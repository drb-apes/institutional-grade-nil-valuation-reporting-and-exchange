/**
 * Example Secure API Route
 * Demonstrates proper usage of security utilities
 */

import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
  sanitizeInput,
} from "@/app/api/utils/security";
import sql from "@/app/api/utils/sql";

/**
 * POST /api/example-secure-route
 *
 * Demonstrates:
 * - Rate limiting
 * - Input validation & sanitization
 * - SQL injection prevention
 * - XSS protection
 * - Secure response headers
 */
export async function POST(request) {
  try {
    // 1. RATE LIMITING
    // Get client identifier (IP address or user ID)
    const ip =
      request.headers.get("x-forwarded-for") ||
      request.headers.get("x-real-ip") ||
      "unknown";

    const rateLimit = checkRateLimit(ip, {
      maxRequests: 10, // 10 requests
      windowMs: 60000, // per minute
    });

    if (!rateLimit.allowed) {
      return createSecureResponse(
        {
          error: "Too many requests",
          retryAfter: rateLimit.resetAt,
        },
        { status: 429 },
      );
    }

    // 2. INPUT VALIDATION & SANITIZATION
    const body = await validateRequestBody(request, {
      // Required fields
      name: {
        required: true,
        type: "string",
        minLength: 2,
        maxLength: 100,
      },
      email: {
        required: true,
        type: "email",
      },
      age: {
        required: true,
        type: "number",
        min: 13,
        max: 120,
        integer: true,
      },

      // Optional fields
      bio: {
        required: false,
        type: "string",
        maxLength: 500,
      },
      website: {
        required: false,
        type: "url",
      },

      // Custom validation
      username: {
        required: true,
        type: "string",
        minLength: 3,
        maxLength: 20,
        pattern: "^[a-zA-Z0-9_]+$", // Alphanumeric + underscore only
        validate: (value) => {
          // Custom logic: ensure username doesn't start with number
          return !/^\d/.test(value);
        },
      },
    });

    // Body is now validated AND sanitized (XSS-safe)
    // All HTML entities are escaped
    // Script tags removed
    // Event handlers stripped

    // 3. DATABASE OPERATION (SQL INJECTION SAFE)
    // The sql`` template tag automatically parameterizes queries
    const result = await sql`
      INSERT INTO users (name, email, age, bio, website, username)
      VALUES (
        ${body.name},
        ${body.email},
        ${body.age},
        ${body.bio || null},
        ${body.website || null},
        ${body.username}
      )
      RETURNING id, name, email, username
    `;

    // 4. ADDITIONAL SANITIZATION (if needed)
    // For user-generated content that will be displayed to other users
    const sanitizedBio = sanitizeInput(body.bio, {
      allowHtml: false,
      stripScripts: true,
      stripEvents: true,
      maxLength: 500,
    });

    // 5. SECURE RESPONSE
    // Automatically includes security headers:
    // - X-Content-Type-Options: nosniff
    // - X-Frame-Options: DENY
    // - X-XSS-Protection: 1; mode=block
    // - Referrer-Policy: strict-origin-when-cross-origin
    // - Permissions-Policy: camera=(), microphone=(), geolocation=()
    return createSecureResponse({
      success: true,
      data: {
        id: result[0].id,
        name: result[0].name,
        email: result[0].email,
        username: result[0].username,
        bio: sanitizedBio,
      },
    });
  } catch (error) {
    // Log error (but don't expose to client)
    console.error("[API Error]", error);

    // Return generic error message
    return createSecureResponse(
      {
        error: error.message.includes("Validation failed")
          ? error.message // Safe to expose validation errors
          : "An error occurred processing your request", // Generic for other errors
      },
      { status: 400 },
    );
  }
}

/**
 * GET /api/example-secure-route
 *
 * Demonstrates:
 * - Query parameter validation
 * - Pagination
 * - SQL injection prevention
 */
export async function GET(request) {
  try {
    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const search = searchParams.get("search") || "";

    // Validate query parameters
    if (page < 1 || page > 1000) {
      return createSecureResponse(
        { error: "Invalid page number" },
        { status: 400 },
      );
    }

    if (limit < 1 || limit > 100) {
      return createSecureResponse(
        { error: "Invalid limit (must be 1-100)" },
        { status: 400 },
      );
    }

    // Sanitize search input
    const sanitizedSearch = sanitizeInput(search, {
      allowHtml: false,
      maxLength: 100,
    });

    // Safe parameterized query
    const offset = (page - 1) * limit;

    let users;
    if (sanitizedSearch) {
      users = await sql`
        SELECT id, name, username, email
        FROM users
        WHERE 
          name ILIKE ${"%" + sanitizedSearch + "%"}
          OR username ILIKE ${"%" + sanitizedSearch + "%"}
        ORDER BY created_at DESC
        LIMIT ${limit}
        OFFSET ${offset}
      `;
    } else {
      users = await sql`
        SELECT id, name, username, email
        FROM users
        ORDER BY created_at DESC
        LIMIT ${limit}
        OFFSET ${offset}
      `;
    }

    // Get total count for pagination
    const countResult = await sql`
      SELECT COUNT(*) as total FROM users
    `;

    const total = parseInt(countResult[0].total);
    const totalPages = Math.ceil(total / limit);

    return createSecureResponse({
      success: true,
      data: users,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error("[API Error]", error);

    return createSecureResponse(
      { error: "An error occurred fetching data" },
      { status: 500 },
    );
  }
}
