import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");
    const sessionType = searchParams.get("sessionType");
    const sportCategory = searchParams.get("sportCategory");
    const privacyLevel = searchParams.get("privacyLevel");
    const limit = parseInt(searchParams.get("limit")) || 50;
    const offset = parseInt(searchParams.get("offset")) || 0;

    // Get user profile to determine role
    const userProfile = await sql`
      SELECT user_type, id as profile_id FROM user_profiles 
      WHERE user_id = ${session.user.id}
    `;

    const userType = userProfile[0]?.user_type || "fan";

    // Build dynamic query
    let whereConditions = [];
    let params = [];
    let paramIndex = 1;

    // Privacy filtering based on user role
    if (userType === "athlete") {
      whereConditions.push(
        `(va.athlete_id = $${paramIndex} OR va.privacy_level = 'public')`,
      );
      params.push(userProfile[0]?.profile_id);
      paramIndex++;
    } else if (userType === "fan") {
      whereConditions.push(`va.privacy_level = 'public'`);
    } else if (userType === "institutional") {
      // Coaches/scouts can see team_only and public videos
      whereConditions.push(`va.privacy_level IN ('public', 'team_only')`);
    }

    // Additional filters
    if (athleteId) {
      whereConditions.push(`va.athlete_id = $${paramIndex}`);
      params.push(athleteId);
      paramIndex++;
    }

    if (sessionType) {
      whereConditions.push(`va.session_type = $${paramIndex}`);
      params.push(sessionType);
      paramIndex++;
    }

    if (sportCategory) {
      whereConditions.push(`va.sport_category = $${paramIndex}`);
      params.push(sportCategory);
      paramIndex++;
    }

    if (
      privacyLevel &&
      (userType === "institutional" || userType === "dao_member")
    ) {
      whereConditions.push(`va.privacy_level = $${paramIndex}`);
      params.push(privacyLevel);
      paramIndex++;
    }

    const whereClause =
      whereConditions.length > 0
        ? `WHERE ${whereConditions.join(" AND ")}`
        : "";

    params.push(limit, offset);

    const videos = await sql(
      `
      SELECT 
        va.*,
        up.user_type as athlete_type,
        au.name as athlete_name,
        au.email as athlete_email,
        recorder.name as recorded_by_name
      FROM video_archives va
      LEFT JOIN user_profiles up ON va.athlete_id = up.id
      LEFT JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN auth_users recorder ON va.recorded_by = recorder.id
      ${whereClause}
      ORDER BY va.created_at DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `,
      params,
    );

    return Response.json({
      videos,
      userRole: userType,
      pagination: {
        limit,
        offset,
        hasMore: videos.length === limit,
      },
    });
  } catch (error) {
    console.error("Error fetching video archives:", error);
    return Response.json({ error: "Failed to fetch videos" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      video_title,
      video_url,
      thumbnail_url,
      athlete_id,
      session_type,
      sport_category,
      duration_seconds,
      file_size_mb,
      video_quality,
      performance_metrics,
      tags,
      privacy_level,
      access_permissions,
    } = body;

    // Validate required fields
    if (!video_title || !video_url || !session_type || !sport_category) {
      return Response.json(
        {
          error:
            "Missing required fields: video_title, video_url, session_type, sport_category",
        },
        { status: 400 },
      );
    }

    const newVideo = await sql`
      INSERT INTO video_archives (
        video_title,
        video_url,
        thumbnail_url,
        athlete_id,
        recorded_by,
        session_type,
        sport_category,
        duration_seconds,
        file_size_mb,
        video_quality,
        performance_metrics,
        tags,
        privacy_level,
        access_permissions,
        processing_status
      ) VALUES (
        ${video_title},
        ${video_url},
        ${thumbnail_url || null},
        ${athlete_id || null},
        ${session.user.id},
        ${session_type},
        ${sport_category},
        ${duration_seconds || null},
        ${file_size_mb || null},
        ${video_quality || "HD"},
        ${JSON.stringify(performance_metrics || {})},
        ${tags || []},
        ${privacy_level || "private"},
        ${JSON.stringify(access_permissions || {})},
        'completed'
      ) RETURNING *
    `;

    return Response.json({
      success: true,
      video: newVideo[0],
      message: "Video archived successfully",
    });
  } catch (error) {
    console.error("Error creating video archive:", error);
    return Response.json({ error: "Failed to archive video" }, { status: 500 });
  }
}
