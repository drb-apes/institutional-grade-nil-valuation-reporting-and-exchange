import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");
    const limit = Math.min(50, parseInt(searchParams.get("limit") || "20"));

    let rows;
    if (athleteId) {
      rows = await sql(
        `SELECT id, athlete_id, asset_value, roi_projection, risk_score, simulation_data, valuation_factors, created_at
         FROM asset_simulations
         WHERE athlete_id = $1
         ORDER BY created_at DESC
         LIMIT $2`,
        [parseInt(athleteId), limit],
      );
    } else {
      rows = await sql(
        `SELECT id, athlete_id, asset_value, roi_projection, risk_score, simulation_data, valuation_factors, created_at
         FROM asset_simulations
         ORDER BY created_at DESC
         LIMIT $1`,
        [limit],
      );
    }

    const history = rows.map((r) => ({
      id: r.id,
      athleteId: r.athlete_id,
      assetValue: parseFloat(r.asset_value) || 0,
      roiProjection: parseFloat(r.roi_projection) || 0,
      riskScore: parseFloat(r.risk_score) || 0,
      bimScore: parseFloat(r.simulation_data?.bimScore) || 0,
      tier: r.simulation_data?.tier || "developing",
      sessionType: r.simulation_data?.sessionType || "match",
      sport: r.simulation_data?.sport || "wrestling",
      simulationData: r.simulation_data,
      valuationFactors: r.valuation_factors,
      createdAt: r.created_at,
    }));

    return Response.json({ history, total: rows.length });
  } catch (error) {
    console.error("Simulation history error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
