import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Environmental Context API
 *
 * Captures and analyzes environmental factors affecting performance
 * Integrates with biomech capsules and spatial mapping
 * Supports: Weather conditions, venue conditions, real-time environmental monitoring
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      sessionId: { required: true, type: "string" },
      venueId: { required: true, type: "string" },
      environmentalReadings: { required: true, type: "object" },
      timestamp: { required: false, type: "number" },
    });

    const {
      sessionId,
      venueId,
      environmentalReadings,
      timestamp = Date.now(),
    } = body;

    // Process environmental readings
    const processed = {
      temperature: {
        value: environmentalReadings.temperature || null,
        unit: "celsius",
        impact: classifyTemperatureImpact(environmentalReadings.temperature),
      },
      humidity: {
        value: environmentalReadings.humidity || null,
        unit: "percentage",
        impact: classifyHumidityImpact(environmentalReadings.humidity),
      },
      altitude: {
        value: environmentalReadings.altitude || 0,
        unit: "meters",
        impact: classifyAltitudeImpact(environmentalReadings.altitude),
      },
      wind: {
        speed: environmentalReadings.windSpeed || 0,
        direction: environmentalReadings.windDirection || null,
        unit: "m/s",
        impact: classifyWindImpact(environmentalReadings.windSpeed),
      },
      air_quality: {
        aqi: environmentalReadings.airQualityIndex || null,
        impact: classifyAirQualityImpact(environmentalReadings.airQualityIndex),
      },
      lighting: {
        conditions: environmentalReadings.lightingConditions || "indoor",
        lux: environmentalReadings.lightingLux || null,
        impact: "neutral",
      },
    };

    // Calculate overall environmental impact score
    const impactScore = calculateEnvironmentalImpactScore(processed);

    // Generate recommendations
    const recommendations = generateEnvironmentalRecommendations(
      processed,
      impactScore,
    );

    // Store environmental context
    const contextData = {
      session_id: sessionId,
      venue_id: venueId,
      readings: processed,
      impact_score: impactScore,
      recommendations,
      timestamp: new Date(timestamp).toISOString(),
    };

    await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        user_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${sessionId},
        'environmental_monitor',
        ${session.user.id},
        'environmental_context',
        ${JSON.stringify(contextData)},
        to_timestamp(${timestamp / 1000}),
        NOW()
      )
    `;

    return createSecureResponse({
      success: true,
      environmentalContext: processed,
      impactScore,
      recommendations,
    });
  } catch (error) {
    console.error("Environmental context error:", error);
    return createSecureResponse(
      { error: "Failed to process environmental context" },
      { status: 500 },
    );
  }
}

// Classification functions
function classifyTemperatureImpact(temp) {
  if (temp === null || temp === undefined) return "unknown";
  if (temp < 5) return "severe_cold";
  if (temp < 10) return "cold";
  if (temp < 15) return "cool";
  if (temp < 25) return "optimal";
  if (temp < 30) return "warm";
  if (temp < 35) return "hot";
  return "severe_heat";
}

function classifyHumidityImpact(humidity) {
  if (humidity === null || humidity === undefined) return "unknown";
  if (humidity < 30) return "dry";
  if (humidity < 60) return "comfortable";
  if (humidity < 75) return "humid";
  return "very_humid";
}

function classifyAltitudeImpact(altitude) {
  if (altitude < 500) return "sea_level";
  if (altitude < 1500) return "moderate";
  if (altitude < 2500) return "elevated";
  return "high_altitude";
}

function classifyWindImpact(windSpeed) {
  if (windSpeed < 2) return "calm";
  if (windSpeed < 5) return "light";
  if (windSpeed < 10) return "moderate";
  if (windSpeed < 15) return "strong";
  return "severe";
}

function classifyAirQualityImpact(aqi) {
  if (aqi === null || aqi === undefined) return "unknown";
  if (aqi < 50) return "good";
  if (aqi < 100) return "moderate";
  if (aqi < 150) return "unhealthy_sensitive";
  if (aqi < 200) return "unhealthy";
  return "hazardous";
}

// Calculate overall environmental impact
function calculateEnvironmentalImpactScore(processed) {
  let impact = 0;

  // Temperature impact (0-25 points)
  const tempImpact = processed.temperature.impact;
  if (tempImpact === "severe_cold" || tempImpact === "severe_heat")
    impact += 25;
  else if (tempImpact === "cold" || tempImpact === "hot") impact += 15;
  else if (tempImpact === "cool" || tempImpact === "warm") impact += 5;

  // Humidity impact (0-15 points)
  const humidImpact = processed.humidity.impact;
  if (humidImpact === "very_humid") impact += 15;
  else if (humidImpact === "humid") impact += 8;
  else if (humidImpact === "dry") impact += 5;

  // Altitude impact (0-20 points)
  const altImpact = processed.altitude.impact;
  if (altImpact === "high_altitude") impact += 20;
  else if (altImpact === "elevated") impact += 10;

  // Wind impact (0-15 points)
  const windImpact = processed.wind.impact;
  if (windImpact === "severe") impact += 15;
  else if (windImpact === "strong") impact += 10;
  else if (windImpact === "moderate") impact += 5;

  // Air quality impact (0-25 points)
  const aqiImpact = processed.air_quality.impact;
  if (aqiImpact === "hazardous") impact += 25;
  else if (aqiImpact === "unhealthy") impact += 15;
  else if (aqiImpact === "unhealthy_sensitive") impact += 8;

  return Math.min(100, impact);
}

// Generate environmental recommendations
function generateEnvironmentalRecommendations(processed, impactScore) {
  const recommendations = [];

  if (impactScore < 20) {
    recommendations.push({
      priority: "info",
      category: "optimal_conditions",
      message: "Environmental conditions are optimal for performance.",
    });
    return recommendations;
  }

  // Temperature recommendations
  if (processed.temperature.impact === "severe_heat") {
    recommendations.push({
      priority: "critical",
      category: "heat_management",
      message: "Extreme heat detected. Implement cooling protocols.",
      actions: [
        "Increase hydration frequency",
        "Reduce session duration",
        "Use cooling vests",
        "Monitor core temperature",
      ],
    });
  } else if (processed.temperature.impact === "severe_cold") {
    recommendations.push({
      priority: "high",
      category: "cold_management",
      message: "Extreme cold detected. Implement warming protocols.",
      actions: [
        "Extended warm-up",
        "Layered clothing",
        "Reduce exposure time",
        "Monitor for frostbite",
      ],
    });
  }

  // Humidity recommendations
  if (processed.humidity.impact === "very_humid") {
    recommendations.push({
      priority: "high",
      category: "humidity_management",
      message:
        "High humidity detected. Adjust hydration and cooling strategies.",
      actions: [
        "Increase electrolyte intake",
        "More frequent breaks",
        "Enhanced ventilation",
      ],
    });
  }

  // Altitude recommendations
  if (processed.altitude.impact === "high_altitude") {
    recommendations.push({
      priority: "high",
      category: "altitude_management",
      message: "High altitude detected. Monitor oxygen saturation.",
      actions: [
        "Gradual acclimatization",
        "Reduce intensity",
        "Monitor SpO2 levels",
        "Extended recovery",
      ],
    });
  }

  // Air quality recommendations
  if (
    processed.air_quality.impact === "hazardous" ||
    processed.air_quality.impact === "unhealthy"
  ) {
    recommendations.push({
      priority: "critical",
      category: "air_quality",
      message:
        "Poor air quality detected. Consider rescheduling or moving indoors.",
      actions: [
        "Relocate to indoor facility",
        "Reduce intensity",
        "Monitor respiratory symptoms",
      ],
    });
  }

  return recommendations;
}
