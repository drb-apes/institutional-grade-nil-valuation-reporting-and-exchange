import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Biomech Capsule API
 *
 * Creates and manages biomechanical capsules localized to specific body joints or field positions
 * Enables granular analysis of stress, fatigue, and risk in spatial context
 * Supports: Joint-level tracking, spatial stress mapping, fatigue accumulation, injury risk scoring
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`biomech-capsules-${session.user.id}`, {
      maxRequests: 50,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      capsuleType: { required: true, type: "string" }, // 'joint' | 'field_position' | 'venue_zone'
      spatialContext: { required: true, type: "object" },
      biomechanicalData: { required: true, type: "object" },
      environmentalContext: { required: false, type: "object" },
      timestamp: { required: false, type: "number" },
    });

    const {
      athleteId,
      capsuleType,
      spatialContext,
      biomechanicalData,
      environmentalContext = {},
      timestamp = Date.now(),
    } = body;

    // Process spatial context
    const processedSpatial = processSpatialContext(capsuleType, spatialContext);

    // Calculate biomechanical metrics
    const biomechMetrics = calculateBiomechMetrics(
      biomechanicalData,
      capsuleType,
    );

    // Calculate stress score
    const stressScore = calculateStressScore(biomechMetrics);

    // Calculate fatigue accumulation
    const fatigueScore = calculateFatigueScore(
      biomechMetrics,
      biomechanicalData,
    );

    // Calculate injury risk
    const injuryRisk = calculateInjuryRisk(
      biomechMetrics,
      fatigueScore,
      stressScore,
    );

    // Create capsule data structure
    const capsuleData = {
      capsule_type: capsuleType,
      spatial_context: processedSpatial,
      biomechanical_metrics: biomechMetrics,
      environmental_context: environmentalContext,
      stress_score: stressScore,
      fatigue_score: fatigueScore,
      injury_risk: injuryRisk,
      timestamp: new Date(timestamp).toISOString(),
    };

    // Store in motion_scans with spatial metadata
    const result = await sql`
      INSERT INTO motion_scans (
        athlete_id,
        scan_data,
        ai_score,
        verification_status,
        motion_type,
        metadata,
        created_at
      ) VALUES (
        ${athleteId},
        ${JSON.stringify(capsuleData)},
        ${biomechMetrics.overall_score},
        'verified',
        'biomech_capsule',
        ${JSON.stringify({
          capsule_type: capsuleType,
          spatial_localization: processedSpatial.localization,
          stress_level: classifyStressLevel(stressScore),
          fatigue_level: classifyFatigueLevel(fatigueScore),
          injury_risk_category: classifyInjuryRisk(injuryRisk),
          environmental_factors: environmentalContext,
        })},
        NOW()
      )
      RETURNING *
    `;

    return createSecureResponse({
      success: true,
      capsuleId: result[0].id,
      capsuleType,
      metrics: {
        stress: stressScore,
        fatigue: fatigueScore,
        injuryRisk,
        overallScore: biomechMetrics.overall_score,
      },
      spatialLocalization: processedSpatial.localization,
      recommendations: generateCapsuleRecommendations(
        stressScore,
        fatigueScore,
        injuryRisk,
      ),
    });
  } catch (error) {
    console.error("Biomech capsule creation error:", error);
    return createSecureResponse(
      { error: "Failed to create biomech capsule" },
      { status: 500 },
    );
  }
}

// GET: Retrieve biomech capsules
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");
    const capsuleType = searchParams.get("capsuleType");
    const joint = searchParams.get("joint");
    const timeRange = searchParams.get("timeRange"); // 'hour' | 'day' | 'week'

    if (!athleteId) {
      return createSecureResponse(
        { error: "athleteId required" },
        { status: 400 },
      );
    }

    // Build time filter
    let timeFilter = "";
    if (timeRange === "hour") {
      timeFilter = "AND created_at > NOW() - INTERVAL '1 hour'";
    } else if (timeRange === "day") {
      timeFilter = "AND created_at > NOW() - INTERVAL '1 day'";
    } else if (timeRange === "week") {
      timeFilter = "AND created_at > NOW() - INTERVAL '1 week'";
    }

    // Query capsules
    const capsules = await sql`
      SELECT * FROM motion_scans
      WHERE athlete_id = ${parseInt(athleteId)}
        AND motion_type = 'biomech_capsule'
        ${capsuleType ? sql`AND metadata->>'capsule_type' = ${capsuleType}` : sql``}
        ${joint ? sql`AND scan_data->'spatial_context'->>'joint' = ${joint}` : sql``}
      ORDER BY created_at DESC
      LIMIT 100
    `;

    // Aggregate spatial intelligence
    const spatialIntelligence = aggregateSpatialIntelligence(capsules);

    return createSecureResponse({
      success: true,
      capsules,
      count: capsules.length,
      spatialIntelligence,
      timeRange: timeRange || "all",
    });
  } catch (error) {
    console.error("Biomech capsule fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch biomech capsules" },
      { status: 500 },
    );
  }
}

// Process spatial context based on capsule type
function processSpatialContext(capsuleType, spatialContext) {
  switch (capsuleType) {
    case "joint":
      return {
        localization: "joint",
        joint: spatialContext.joint, // 'shoulder', 'knee', 'ankle', 'hip', 'elbow', 'wrist'
        position3D: spatialContext.position3D || { x: 0, y: 0, z: 0 },
        orientation: spatialContext.orientation || {
          pitch: 0,
          roll: 0,
          yaw: 0,
        },
        jointAngle: spatialContext.jointAngle || 0,
        rangeOfMotion: spatialContext.rangeOfMotion || 0,
      };

    case "field_position":
      return {
        localization: "field_position",
        coordinates: spatialContext.coordinates || { lat: 0, lng: 0 },
        fieldZone: spatialContext.fieldZone || "center", // 'offensive_third', 'defensive_third', 'midfield', etc.
        position3D: spatialContext.position3D || { x: 0, y: 0, z: 0 },
        velocity: spatialContext.velocity || { x: 0, y: 0, z: 0 },
        acceleration: spatialContext.acceleration || { x: 0, y: 0, z: 0 },
      };

    case "venue_zone":
      return {
        localization: "venue_zone",
        venueId: spatialContext.venueId,
        zone: spatialContext.zone, // 'stage_center', 'court_baseline', 'mat_center', etc.
        position3D: spatialContext.position3D || { x: 0, y: 0, z: 0 },
        proximityToOthers: spatialContext.proximityToOthers || [],
        crowdDensity: spatialContext.crowdDensity || 0,
      };

    default:
      return {
        localization: "unknown",
        rawContext: spatialContext,
      };
  }
}

// Calculate biomechanical metrics
function calculateBiomechMetrics(biomechanicalData, capsuleType) {
  const metrics = {
    force: biomechanicalData.force || 0,
    torque: biomechanicalData.torque || 0,
    velocity: biomechanicalData.velocity || 0,
    acceleration: biomechanicalData.acceleration || 0,
    power: biomechanicalData.power || 0,
    range_of_motion: biomechanicalData.rangeOfMotion || 0,
    muscle_activation: biomechanicalData.muscleActivation || 0,
    joint_load: biomechanicalData.jointLoad || 0,
    impact_force: biomechanicalData.impactForce || 0,
    repetition_count: biomechanicalData.repetitionCount || 0,
  };

  // Calculate derived metrics
  metrics.explosive_power = (metrics.force * metrics.velocity) / 1000;
  metrics.mechanical_efficiency =
    metrics.power > 0 ? (metrics.force / metrics.power) * 100 : 0;

  // Calculate overall biomech score (0-100)
  let score = 50; // baseline

  // Force contribution (0-20 points)
  if (metrics.force > 0) {
    score += Math.min(20, (metrics.force / 1000) * 20);
  }

  // Power contribution (0-20 points)
  if (metrics.power > 0) {
    score += Math.min(20, (metrics.power / 500) * 20);
  }

  // Range of motion contribution (0-15 points)
  score += Math.min(15, (metrics.range_of_motion / 180) * 15);

  // Muscle activation contribution (0-15 points)
  score += Math.min(15, metrics.muscle_activation * 0.15);

  // Penalties for high impact/load
  if (metrics.impact_force > 5000) score -= 10;
  if (metrics.joint_load > 80) score -= 10;

  metrics.overall_score = Math.max(0, Math.min(100, score));

  return metrics;
}

// Calculate stress score
function calculateStressScore(biomechMetrics) {
  let stress = 0;

  // Force-based stress
  if (biomechMetrics.force > 1000) stress += 20;
  else if (biomechMetrics.force > 500) stress += 10;

  // Impact-based stress
  if (biomechMetrics.impact_force > 5000) stress += 30;
  else if (biomechMetrics.impact_force > 2000) stress += 15;

  // Joint load stress
  if (biomechMetrics.joint_load > 80) stress += 25;
  else if (biomechMetrics.joint_load > 60) stress += 12;

  // Repetition stress
  if (biomechMetrics.repetition_count > 100) stress += 15;
  else if (biomechMetrics.repetition_count > 50) stress += 8;

  // Power output stress
  if (biomechMetrics.power > 1000) stress += 10;

  return Math.min(100, stress);
}

// Calculate fatigue score
function calculateFatigueScore(biomechMetrics, rawData) {
  let fatigue = 0;

  // Repetition-based fatigue
  fatigue += Math.min(30, (biomechMetrics.repetition_count / 200) * 30);

  // Power decline (if available in raw data)
  if (rawData.powerDecline) {
    fatigue += Math.min(25, rawData.powerDecline * 25);
  }

  // Range of motion restriction
  if (biomechMetrics.range_of_motion < 90) {
    fatigue += 20;
  } else if (biomechMetrics.range_of_motion < 120) {
    fatigue += 10;
  }

  // Muscle activation decline
  if (biomechMetrics.muscle_activation < 50) {
    fatigue += 15;
  }

  // Velocity decline
  if (rawData.velocityDecline) {
    fatigue += Math.min(10, rawData.velocityDecline * 10);
  }

  return Math.min(100, fatigue);
}

// Calculate injury risk
function calculateInjuryRisk(biomechMetrics, fatigueScore, stressScore) {
  let risk = 0;

  // High stress + high fatigue = high risk
  risk += stressScore * 0.4;
  risk += fatigueScore * 0.3;

  // Impact force risk
  if (biomechMetrics.impact_force > 10000) risk += 20;
  else if (biomechMetrics.impact_force > 5000) risk += 10;

  // Joint load risk
  if (biomechMetrics.joint_load > 90) risk += 15;
  else if (biomechMetrics.joint_load > 75) risk += 8;

  // Range of motion restriction risk
  if (biomechMetrics.range_of_motion < 60) risk += 15;

  // Mechanical inefficiency risk
  if (biomechMetrics.mechanical_efficiency < 30) risk += 10;

  return Math.min(100, risk);
}

// Classify stress level
function classifyStressLevel(score) {
  if (score < 20) return "low";
  if (score < 40) return "moderate";
  if (score < 60) return "elevated";
  if (score < 80) return "high";
  return "critical";
}

// Classify fatigue level
function classifyFatigueLevel(score) {
  if (score < 20) return "fresh";
  if (score < 40) return "slight";
  if (score < 60) return "moderate";
  if (score < 80) return "significant";
  return "severe";
}

// Classify injury risk
function classifyInjuryRisk(score) {
  if (score < 20) return "minimal";
  if (score < 40) return "low";
  if (score < 60) return "moderate";
  if (score < 80) return "high";
  return "critical";
}

// Generate recommendations
function generateCapsuleRecommendations(stress, fatigue, injuryRisk) {
  const recommendations = [];

  if (stress > 60) {
    recommendations.push({
      type: "stress_management",
      priority: "high",
      message: "Elevated stress detected. Consider recovery protocol.",
      actions: [
        "Reduce training intensity",
        "Increase rest intervals",
        "Apply compression therapy",
      ],
    });
  }

  if (fatigue > 60) {
    recommendations.push({
      type: "fatigue_management",
      priority: "high",
      message: "Significant fatigue accumulation. Rest recommended.",
      actions: [
        "Extended rest period",
        "Nutritional support",
        "Sleep optimization",
      ],
    });
  }

  if (injuryRisk > 60) {
    recommendations.push({
      type: "injury_prevention",
      priority: "critical",
      message: "High injury risk detected. Immediate intervention required.",
      actions: [
        "Stop current activity",
        "Medical evaluation",
        "Modify training load",
      ],
    });
  }

  if (stress < 30 && fatigue < 30 && injuryRisk < 30) {
    recommendations.push({
      type: "optimal_state",
      priority: "info",
      message: "Optimal biomechanical state. Continue training.",
      actions: ["Maintain current load", "Monitor for changes"],
    });
  }

  return recommendations;
}

// Aggregate spatial intelligence
function aggregateSpatialIntelligence(capsules) {
  if (capsules.length === 0) {
    return {
      avgStress: 0,
      avgFatigue: 0,
      avgInjuryRisk: 0,
      hotspots: [],
      trendAnalysis: {},
    };
  }

  // Calculate averages
  const avgStress =
    capsules.reduce((sum, c) => sum + (c.scan_data?.stress_score || 0), 0) /
    capsules.length;
  const avgFatigue =
    capsules.reduce((sum, c) => sum + (c.scan_data?.fatigue_score || 0), 0) /
    capsules.length;
  const avgInjuryRisk =
    capsules.reduce((sum, c) => sum + (c.scan_data?.injury_risk || 0), 0) /
    capsules.length;

  // Identify stress hotspots (joints/zones with consistently high stress)
  const jointStressMap = {};
  capsules.forEach((c) => {
    const joint = c.scan_data?.spatial_context?.joint;
    const stress = c.scan_data?.stress_score || 0;

    if (joint) {
      if (!jointStressMap[joint]) {
        jointStressMap[joint] = { total: 0, count: 0, max: 0 };
      }
      jointStressMap[joint].total += stress;
      jointStressMap[joint].count += 1;
      jointStressMap[joint].max = Math.max(jointStressMap[joint].max, stress);
    }
  });

  const hotspots = Object.entries(jointStressMap)
    .map(([joint, data]) => ({
      joint,
      avgStress: data.total / data.count,
      maxStress: data.max,
      occurrences: data.count,
    }))
    .filter((h) => h.avgStress > 50)
    .sort((a, b) => b.avgStress - a.avgStress);

  // Trend analysis (last 10 vs previous)
  const recent = capsules.slice(0, Math.min(10, capsules.length));
  const previous = capsules.slice(10, Math.min(20, capsules.length));

  const recentAvgStress =
    recent.reduce((sum, c) => sum + (c.scan_data?.stress_score || 0), 0) /
    Math.max(1, recent.length);
  const previousAvgStress =
    previous.length > 0
      ? previous.reduce((sum, c) => sum + (c.scan_data?.stress_score || 0), 0) /
        previous.length
      : recentAvgStress;

  const trendAnalysis = {
    stressTrend:
      recentAvgStress > previousAvgStress ? "increasing" : "decreasing",
    stressChange:
      ((recentAvgStress - previousAvgStress) / Math.max(1, previousAvgStress)) *
      100,
  };

  return {
    avgStress: Math.round(avgStress * 10) / 10,
    avgFatigue: Math.round(avgFatigue * 10) / 10,
    avgInjuryRisk: Math.round(avgInjuryRisk * 10) / 10,
    hotspots,
    trendAnalysis,
    totalCapsules: capsules.length,
  };
}
