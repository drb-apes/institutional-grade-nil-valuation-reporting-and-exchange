import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { createSecureResponse, checkRateLimit } from "@/app/api/utils/security";

/**
 * 3D Timeline Match Data API
 *
 * Retrieves timestamped match data for 3D playback visualization
 * Includes: Capsule states, player positions, tactical formations, biometric streams
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`3d-timeline-${session.user.id}`, {
      maxRequests: 30,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const { searchParams } = new URL(request.url);
    const matchId = searchParams.get("matchId");
    const athleteId = searchParams.get("athleteId");
    const startTime = searchParams.get("startTime");
    const endTime = searchParams.get("endTime");
    const resolution = parseInt(searchParams.get("resolution") || "1000"); // ms granularity

    if (!matchId && !athleteId) {
      return createSecureResponse(
        { error: "matchId or athleteId required" },
        { status: 400 },
      );
    }

    // Build timeline query
    let timelineData;

    if (matchId) {
      // Get match-specific timeline (all athletes in match)
      timelineData = await buildMatchTimeline(
        matchId,
        startTime,
        endTime,
        resolution,
      );
    } else {
      // Get athlete-specific timeline
      timelineData = await buildAthleteTimeline(
        athleteId,
        startTime,
        endTime,
        resolution,
      );
    }

    return createSecureResponse({
      success: true,
      timeline: timelineData.timeline,
      metadata: timelineData.metadata,
      athletes: timelineData.athletes,
      events: timelineData.events,
      capsuleStates: timelineData.capsuleStates,
    });
  } catch (error) {
    console.error("3D timeline fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch timeline data" },
      { status: 500 },
    );
  }
}

async function buildMatchTimeline(matchId, startTime, endTime, resolution) {
  // Get all wearable data streams for the match session
  const streams = await sql`
    SELECT 
      wds.device_uuid,
      wds.stream_type,
      wds.processed_data,
      wds.timestamp,
      wds.data_quality_score,
      wd.owner_id as athlete_id
    FROM wearable_data_streams wds
    JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
    WHERE wds.session_id = ${matchId}
    ${startTime ? sql`AND wds.timestamp >= to_timestamp(${parseInt(startTime) / 1000})` : sql``}
    ${endTime ? sql`AND wds.timestamp <= to_timestamp(${parseInt(endTime) / 1000})` : sql``}
    ORDER BY wds.timestamp ASC
  `;

  // Get athlete profiles
  const athleteIds = [...new Set(streams.map((s) => s.athlete_id))];
  const athletes = await sql`
    SELECT 
      up.id,
      up.user_id,
      au.name,
      up.tier_level
    FROM user_profiles up
    JOIN auth_users au ON up.user_id = au.id
    WHERE up.id = ANY(${athleteIds})
  `;

  // Organize data by timestamp buckets
  const timeline = organizeTimelineBuckets(streams, resolution);

  // Generate capsule states for each timestamp
  const capsuleStates = generateCapsuleTimeline(streams, resolution);

  // Extract key events (spikes, drops, thresholds)
  const events = extractKeyEvents(streams);

  return {
    timeline,
    metadata: {
      matchId,
      startTime: streams[0]?.timestamp || null,
      endTime: streams[streams.length - 1]?.timestamp || null,
      duration:
        streams.length > 0
          ? new Date(streams[streams.length - 1].timestamp) -
            new Date(streams[0].timestamp)
          : 0,
      resolution,
      dataPointCount: streams.length,
    },
    athletes: athletes.map((a) => ({
      id: a.id,
      name: a.name,
      tier: a.tier_level,
    })),
    events,
    capsuleStates,
  };
}

async function buildAthleteTimeline(athleteId, startTime, endTime, resolution) {
  // Get athlete's wearable data
  const streams = await sql`
    SELECT 
      wds.device_uuid,
      wds.stream_type,
      wds.processed_data,
      wds.timestamp,
      wds.data_quality_score,
      wds.session_id
    FROM wearable_data_streams wds
    JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
    WHERE wd.owner_id = ${parseInt(athleteId)}
    ${startTime ? sql`AND wds.timestamp >= to_timestamp(${parseInt(startTime) / 1000})` : sql``}
    ${endTime ? sql`AND wds.timestamp <= to_timestamp(${parseInt(endTime) / 1000})` : sql``}
    ORDER BY wds.timestamp ASC
  `;

  // Get athlete profile
  const athlete = await sql`
    SELECT 
      up.id,
      up.user_id,
      au.name,
      up.tier_level
    FROM user_profiles up
    JOIN auth_users au ON up.user_id = au.id
    WHERE up.id = ${parseInt(athleteId)}
  `;

  const timeline = organizeTimelineBuckets(streams, resolution);
  const capsuleStates = generateCapsuleTimeline(streams, resolution);
  const events = extractKeyEvents(streams);

  return {
    timeline,
    metadata: {
      athleteId,
      startTime: streams[0]?.timestamp || null,
      endTime: streams[streams.length - 1]?.timestamp || null,
      duration:
        streams.length > 0
          ? new Date(streams[streams.length - 1].timestamp) -
            new Date(streams[0].timestamp)
          : 0,
      resolution,
      dataPointCount: streams.length,
    },
    athletes: athlete.map((a) => ({
      id: a.id,
      name: a.name,
      tier: a.tier_level,
    })),
    events,
    capsuleStates,
  };
}

function organizeTimelineBuckets(streams, resolution) {
  if (streams.length === 0) return [];

  const startTimestamp = new Date(streams[0].timestamp).getTime();
  const endTimestamp = new Date(
    streams[streams.length - 1].timestamp,
  ).getTime();

  const buckets = [];
  let currentBucket = startTimestamp;

  while (currentBucket <= endTimestamp) {
    const bucketEnd = currentBucket + resolution;

    const bucketStreams = streams.filter((s) => {
      const ts = new Date(s.timestamp).getTime();
      return ts >= currentBucket && ts < bucketEnd;
    });

    if (bucketStreams.length > 0) {
      buckets.push({
        timestamp: currentBucket,
        duration: resolution,
        dataPoints: bucketStreams.length,
        streams: aggregateStreams(bucketStreams),
      });
    }

    currentBucket = bucketEnd;
  }

  return buckets;
}

function aggregateStreams(bucketStreams) {
  const aggregated = {};

  bucketStreams.forEach((stream) => {
    const key = `${stream.athlete_id}_${stream.stream_type}`;

    if (!aggregated[key]) {
      aggregated[key] = {
        athleteId: stream.athlete_id,
        streamType: stream.stream_type,
        values: [],
      };
    }

    aggregated[key].values.push(stream.processed_data);
  });

  // Calculate averages for each stream type
  Object.keys(aggregated).forEach((key) => {
    const streamData = aggregated[key];
    streamData.average = calculateAverageStreamData(
      streamData.values,
      streamData.streamType,
    );
  });

  return Object.values(aggregated);
}

function calculateAverageStreamData(values, streamType) {
  if (values.length === 0) return {};

  const avg = {};

  if (streamType === "heart_rate") {
    avg.bpm = values.reduce((sum, v) => sum + (v.bpm || 0), 0) / values.length;
    avg.hrv = values.reduce((sum, v) => sum + (v.hrv || 0), 0) / values.length;
    avg.zone = values[values.length - 1]?.zone || "unknown";
  } else if (streamType === "acceleration") {
    avg.magnitude =
      values.reduce((sum, v) => sum + (v.magnitude || 0), 0) / values.length;
    avg.impact = values[values.length - 1]?.impact || "light";
  } else if (streamType === "gps") {
    avg.lat = values.reduce((sum, v) => sum + (v.lat || 0), 0) / values.length;
    avg.lng = values.reduce((sum, v) => sum + (v.lng || 0), 0) / values.length;
    avg.speed =
      values.reduce((sum, v) => sum + (v.speed || 0), 0) / values.length;
  }

  return avg;
}

function generateCapsuleTimeline(streams, resolution) {
  if (streams.length === 0) return [];

  const startTimestamp = new Date(streams[0].timestamp).getTime();
  const endTimestamp = new Date(
    streams[streams.length - 1].timestamp,
  ).getTime();

  const capsuleTimeline = [];
  let currentTime = startTimestamp;

  while (currentTime <= endTimestamp) {
    const bucketEnd = currentTime + resolution;

    const bucketStreams = streams.filter((s) => {
      const ts = new Date(s.timestamp).getTime();
      return ts >= currentTime && ts < bucketEnd;
    });

    const athleteIds = [...new Set(bucketStreams.map((s) => s.athlete_id))];

    const capsuleFrame = {
      timestamp: currentTime,
      athletes: athleteIds.map((athleteId) => {
        const athleteStreams = bucketStreams.filter(
          (s) => s.athlete_id === athleteId,
        );
        return buildCapsuleState(athleteId, athleteStreams);
      }),
    };

    capsuleTimeline.push(capsuleFrame);
    currentTime = bucketEnd;
  }

  return capsuleTimeline;
}

function buildCapsuleState(athleteId, streams) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");
  const forceStream = streams.find((s) => s.stream_type === "force");

  // Capsule component values
  const bpm = hrStream?.processed_data?.bpm || 0;
  const hrZone = hrStream?.processed_data?.zone || "recovery";
  const impact = accelStream?.processed_data?.magnitude || 0;
  const force = forceStream?.processed_data?.newton || 0;

  // Calculate capsule visual properties
  const fatigueLevel = calculateFatigueFromHR(bpm, hrZone);
  const stressLoad = calculateStressFromImpact(impact, force);
  const injuryRisk = calculateInjuryRisk(fatigueLevel, stressLoad, impact);
  const subProbability = calculateSubProbability(fatigueLevel, injuryRisk);
  const nilMomentum = calculateNILMomentum(bpm, impact, fatigueLevel);
  const recoveryVelocity = calculateRecoveryVelocity(bpm, hrZone);

  return {
    athleteId,
    timestamp: streams[0]?.timestamp || new Date().toISOString(),
    capsule: {
      glowRing: {
        color:
          nilMomentum > 70
            ? "#FFCC33"
            : nilMomentum > 40
              ? "#F2F2F2"
              : "#6B6B6B",
        intensity: nilMomentum / 100,
        bloom: nilMomentum > 70 ? 2.0 : nilMomentum > 40 ? 1.0 : 0.4,
      },
      topArc: {
        color:
          stressLoad > 70 ? "#002B66" : stressLoad > 40 ? "#1E5FA8" : "#4DA6FF",
        thickness: Math.max(2, stressLoad / 10),
      },
      bottomArc: {
        gradient:
          fatigueLevel > 70
            ? "#FF3C3C"
            : fatigueLevel > 40
              ? "#FFD93C"
              : "#3CFF7A",
        pulseFrequency: fatigueLevel > 70 ? 1.2 : 0,
      },
      centerLine: {
        slope: recoveryVelocity > 0 ? 30 : recoveryVelocity < 0 ? -30 : 0,
        color:
          recoveryVelocity > 0
            ? "#3CFF7A"
            : recoveryVelocity < 0
              ? "#FF3C3C"
              : "#F2F2F2",
      },
      leftBar: {
        height: subProbability,
        color:
          subProbability > 60
            ? "#D90000"
            : subProbability > 30
              ? "#FF8C33"
              : "#33FFF3",
      },
      rightBar: {
        height: injuryRisk,
        color:
          injuryRisk > 60 ? "#D90000" : injuryRisk > 30 ? "#FF8C33" : "#33FFF3",
      },
    },
    biometrics: {
      heartRate: bpm,
      hrZone,
      fatigue: fatigueLevel,
      stress: stressLoad,
      injuryRisk,
    },
    position: extractPosition(streams),
  };
}

function extractPosition(streams) {
  const gpsStream = streams.find((s) => s.stream_type === "gps");
  if (gpsStream?.processed_data) {
    return {
      lat: gpsStream.processed_data.lat,
      lng: gpsStream.processed_data.lng,
      speed: gpsStream.processed_data.speed || 0,
    };
  }
  return null;
}

function extractKeyEvents(streams) {
  const events = [];

  // Group by athlete
  const athleteStreams = {};
  streams.forEach((s) => {
    if (!athleteStreams[s.athlete_id]) {
      athleteStreams[s.athlete_id] = [];
    }
    athleteStreams[s.athlete_id].push(s);
  });

  // Detect events for each athlete
  Object.keys(athleteStreams).forEach((athleteId) => {
    const data = athleteStreams[athleteId];

    // Heart rate spikes
    data.forEach((stream, idx) => {
      if (
        stream.stream_type === "heart_rate" &&
        stream.processed_data?.bpm > 180
      ) {
        events.push({
          athleteId: parseInt(athleteId),
          timestamp: stream.timestamp,
          eventType: "hr_spike",
          severity: "high",
          value: stream.processed_data.bpm,
          description: `Heart rate spike: ${stream.processed_data.bpm} BPM`,
        });
      }

      // Impact events
      if (
        stream.stream_type === "acceleration" &&
        stream.processed_data?.magnitude > 20
      ) {
        events.push({
          athleteId: parseInt(athleteId),
          timestamp: stream.timestamp,
          eventType: "high_impact",
          severity:
            stream.processed_data.impact === "severe" ? "critical" : "medium",
          value: stream.processed_data.magnitude,
          description: `High impact detected: ${stream.processed_data.magnitude.toFixed(1)}g`,
        });
      }

      // Force events
      if (
        stream.stream_type === "force" &&
        stream.processed_data?.newton > 1000
      ) {
        events.push({
          athleteId: parseInt(athleteId),
          timestamp: stream.timestamp,
          eventType: "high_force",
          severity: "high",
          value: stream.processed_data.newton,
          description: `High force event: ${stream.processed_data.newton}N`,
        });
      }
    });
  });

  return events.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
}

// Capsule calculation functions
function calculateFatigueFromHR(bpm, hrZone) {
  if (hrZone === "anaerobic") return 85;
  if (hrZone === "vo2max") return 70;
  if (hrZone === "threshold") return 55;
  if (hrZone === "aerobic") return 35;
  return 15;
}

function calculateStressFromImpact(magnitude, force) {
  const impactScore = Math.min(100, magnitude * 2);
  const forceScore = Math.min(100, force / 20);
  return (impactScore + forceScore) / 2;
}

function calculateInjuryRisk(fatigue, stress, impact) {
  const fatigueWeight = 0.4;
  const stressWeight = 0.3;
  const impactWeight = 0.3;

  return Math.min(
    100,
    fatigue * fatigueWeight + stress * stressWeight + impact * impactWeight,
  );
}

function calculateSubProbability(fatigue, injuryRisk) {
  return Math.min(100, fatigue * 0.6 + injuryRisk * 0.4);
}

function calculateNILMomentum(bpm, impact, fatigue) {
  // High performance + low fatigue = high NIL momentum
  const performanceScore = Math.min(100, (bpm - 60) / 1.6);
  const impactScore = Math.min(100, impact * 2);
  const fatigueBoost = 100 - fatigue;

  return performanceScore * 0.4 + impactScore * 0.3 + fatigueBoost * 0.3;
}

function calculateRecoveryVelocity(bpm, hrZone) {
  // Positive = recovering, negative = fatiguing
  if (hrZone === "recovery") return 50;
  if (hrZone === "aerobic") return 20;
  if (hrZone === "threshold") return 0;
  if (hrZone === "vo2max") return -30;
  if (hrZone === "anaerobic") return -50;
  return 0;
}
