import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * PHYSI OBIOFIN DASHBOARD DATA API (Institutional Edition)
 * Aggregates data from Risk Management, Arbitrage, and Scalping systems
 * Provides standard institutional dashboard views
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const tab = searchParams.get("tab") || "positions";
    const sponsorId = parseInt(
      searchParams.get("sponsorId") || session.user.id,
    );

    let data = null;

    switch (tab) {
      case "positions":
        data = await getPositionsTab(sponsorId);
        break;
      case "arbitrage":
        data = await getArbitrageTab(sponsorId);
        break;
      case "scalping":
        data = await getScalpingTab(sponsorId);
        break;
      case "risk":
        data = await getRiskTab(sponsorId);
        break;
      default:
        return Response.json(
          { error: "Invalid tab parameter" },
          { status: 400 },
        );
    }

    return Response.json({
      success: true,
      tab,
      sponsorId,
      timestamp: new Date().toISOString(),
      ...data,
    });
  } catch (error) {
    console.error("Dashboard Data Error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// POSITIONS TAB
async function getPositionsTab(sponsorId) {
  const positions = await sql`
    SELECT 
      hp.id as position_id,
      hp.athlete_id,
      au.name as athlete_name,
      hp.hedge_type,
      hp.ht_token_amount as notional,
      hp.hedge_status as status,
      hp.created_at as entry_date,
      hp.hedge_trigger as entry_metadata
    FROM hedging_positions hp
    JOIN user_profiles up ON hp.athlete_id = up.id
    JOIN auth_users au ON up.user_id = au.id
    WHERE hp.sponsor_id = ${sponsorId}
      AND hp.hedge_status IN ('active', 'triggered')
    ORDER BY hp.created_at DESC
    LIMIT 100
  `;

  // Calculate unrealized P&L for each position
  const positionsWithPnL = await Promise.all(
    positions.map(async (pos) => {
      // Get current performance
      const currentPerf = await sql`
      SELECT AVG(ai_score) as current_score
      FROM motion_scans
      WHERE athlete_id = ${pos.athlete_id}
        AND created_at >= NOW() - INTERVAL '24 hours'
    `;

      const entryScore = pos.entry_metadata?.performanceScore || 100;
      const currentScore = parseFloat(
        currentPerf[0]?.current_score || entryScore,
      );

      // Simple P&L calculation
      const scoreDelta = currentScore - entryScore;
      const notional = parseFloat(pos.notional);
      const unrealizedPnL = (scoreDelta / entryScore) * notional;

      return {
        positionId: pos.position_id,
        athleteId: pos.athlete_id,
        athleteName: pos.athlete_name,
        hedgeType: pos.hedge_type,
        notional: Math.round(notional),
        entryPrice: Math.round(entryScore * 100) / 100,
        currentFairValue: Math.round(currentScore * 100) / 100,
        unrealizedPnL: Math.round(unrealizedPnL),
        unrealizedPnLPercent:
          Math.round((unrealizedPnL / notional) * 1000) / 10,
        status: pos.status,
        entryDate: pos.entry_date,
        daysHeld: Math.floor(
          (new Date() - new Date(pos.entry_date)) / (1000 * 60 * 60 * 24),
        ),
      };
    }),
  );

  // Summary metrics
  const totalNotional = positionsWithPnL.reduce(
    (sum, p) => sum + p.notional,
    0,
  );
  const totalPnL = positionsWithPnL.reduce(
    (sum, p) => sum + p.unrealizedPnL,
    0,
  );
  const avgPnLPercent =
    positionsWithPnL.length > 0
      ? positionsWithPnL.reduce((sum, p) => sum + p.unrealizedPnLPercent, 0) /
        positionsWithPnL.length
      : 0;

  return {
    summary: {
      activePositions: positionsWithPnL.filter((p) => p.status === "active")
        .length,
      totalNotional: Math.round(totalNotional),
      totalUnrealizedPnL: Math.round(totalPnL),
      avgReturnPercent: Math.round(avgPnLPercent * 10) / 10,
    },
    positions: positionsWithPnL.slice(0, 50),
    hedgeTypeBreakdown: getHedgeTypeBreakdown(positionsWithPnL),
  };
}

// ARBITRAGE TAB
async function getArbitrageTab(sponsorId) {
  // Get athletes with recent performance data
  const athletes = await sql`
    SELECT 
      up.id as athlete_id,
      au.name as athlete_name,
      up.reputation_score,
      AVG(ms.ai_score) as avg_performance,
      COUNT(ms.id) as scan_count
    FROM user_profiles up
    JOIN auth_users au ON up.user_id = au.id
    LEFT JOIN motion_scans ms ON ms.athlete_id = up.id
    WHERE up.user_type = 'athlete'
      AND ms.created_at >= NOW() - INTERVAL '7 days'
    GROUP BY up.id, au.name, up.reputation_score
    HAVING COUNT(ms.id) > 3
    ORDER BY AVG(ms.ai_score) DESC
    LIMIT 100
  `;

  const opportunities = [];

  for (const athlete of athletes) {
    // Simple Model NIL calculation
    const performance = parseFloat(athlete.avg_performance || 0);
    const modelNIL = performance * 500 + athlete.reputation_score * 50;

    // Simple Market NIL (based on reputation)
    const marketNIL = athlete.reputation_score * 100;

    const spread = ((modelNIL - marketNIL) / marketNIL) * 100;

    if (Math.abs(spread) > 10) {
      opportunities.push({
        athleteId: athlete.athlete_id,
        athleteName: athlete.athlete_name,
        modelNIL: Math.round(modelNIL),
        marketNIL: Math.round(marketNIL),
        spread: Math.round(spread * 10) / 10,
        spreadAbsolute: Math.round(modelNIL - marketNIL),
        signal: spread > 0 ? "BUY" : "SELL",
        category: Math.abs(spread) > 25 ? "high_conviction" : "moderate",
        performance: Math.round(performance * 100) / 100,
      });
    }
  }

  // Sort by absolute spread
  opportunities.sort((a, b) => Math.abs(b.spread) - Math.abs(a.spread));

  const undervalued = opportunities.filter((o) => o.spread > 0).slice(0, 20);
  const overvalued = opportunities.filter((o) => o.spread < 0).slice(0, 20);

  return {
    summary: {
      totalOpportunities: opportunities.length,
      undervaluedCount: undervalued.length,
      overvaluedCount: overvalued.length,
      avgSpread:
        opportunities.length > 0
          ? Math.round(
              (opportunities.reduce((sum, o) => sum + Math.abs(o.spread), 0) /
                opportunities.length) *
                10,
            ) / 10
          : 0,
    },
    undervalued,
    overvalued,
    topOpportunities: opportunities.slice(0, 10),
  };
}

// SCALPING TAB
async function getScalpingTab(sponsorId) {
  // Get recent scalping moments (signals)
  const signals = await sql`
    SELECT 
      sm.*,
      au.name as athlete_name
    FROM scalping_moments sm
    JOIN user_profiles up ON sm.athlete_id = up.id
    JOIN auth_users au ON up.user_id = au.id
    WHERE sm.captured_at >= NOW() - INTERVAL '24 hours'
    ORDER BY sm.captured_at DESC
    LIMIT 100
  `;

  const processedSignals = signals.map((s) => ({
    signalId: s.id,
    athleteId: s.athlete_id,
    athleteName: s.athlete_name,
    momentType: s.moment_type,
    intensity: parseFloat(s.moment_intensity),
    intensityPercent: Math.round(parseFloat(s.moment_intensity) * 100),
    spotlightCredits: parseFloat(s.spotlight_credits),
    eventWindowCredits: parseFloat(s.event_window_credits),
    boostCredits: parseFloat(s.boost_credits),
    engagementSpike: s.engagement_spike,
    capturedAt: s.captured_at,
    metadata: s.moment_metadata,
    tradingAction: generateScalpingAction(
      parseFloat(s.spotlight_credits),
      parseFloat(s.moment_intensity),
    ),
  }));

  // Group by athlete
  const athleteSignals = {};
  processedSignals.forEach((s) => {
    if (!athleteSignals[s.athleteId]) {
      athleteSignals[s.athleteId] = {
        athleteId: s.athleteId,
        athleteName: s.athleteName,
        signalCount: 0,
        totalCredits: 0,
        avgIntensity: 0,
        signals: [],
      };
    }
    athleteSignals[s.athleteId].signalCount += 1;
    athleteSignals[s.athleteId].totalCredits += s.spotlightCredits;
    athleteSignals[s.athleteId].signals.push(s);
  });

  // Calculate averages
  Object.values(athleteSignals).forEach((a) => {
    a.avgIntensity = Math.round(
      (a.signals.reduce((sum, s) => sum + s.intensity, 0) / a.signals.length) *
        100,
    );
    a.totalCredits = Math.round(a.totalCredits);
  });

  const topAthletes = Object.values(athleteSignals)
    .sort((a, b) => b.totalCredits - a.totalCredits)
    .slice(0, 10);

  return {
    summary: {
      totalSignals: processedSignals.length,
      activeAthletes: Object.keys(athleteSignals).length,
      avgIntensity:
        processedSignals.length > 0
          ? Math.round(
              (processedSignals.reduce((sum, s) => sum + s.intensity, 0) /
                processedSignals.length) *
                100,
            )
          : 0,
      totalCredits: Math.round(
        processedSignals.reduce((sum, s) => sum + s.spotlightCredits, 0),
      ),
    },
    recentSignals: processedSignals.slice(0, 20),
    topAthletes,
    signalTypes: getSignalTypeBreakdown(processedSignals),
  };
}

// RISK TAB
async function getRiskTab(sponsorId) {
  const positions = await sql`
    SELECT 
      hp.*,
      au.name as athlete_name
    FROM hedging_positions hp
    JOIN user_profiles up ON hp.athlete_id = up.id
    JOIN auth_users au ON up.user_id = au.id
    WHERE hp.sponsor_id = ${sponsorId}
      AND hp.hedge_status = 'active'
  `;

  const totalExposure = positions.reduce(
    (sum, p) => sum + parseFloat(p.ht_token_amount),
    0,
  );

  // Group by athlete
  const athleteExposure = {};
  positions.forEach((p) => {
    if (!athleteExposure[p.athlete_id]) {
      athleteExposure[p.athlete_id] = {
        athleteId: p.athlete_id,
        athleteName: p.athlete_name,
        exposure: 0,
        positions: 0,
      };
    }
    athleteExposure[p.athlete_id].exposure += parseFloat(p.ht_token_amount);
    athleteExposure[p.athlete_id].positions += 1;
  });

  const exposureByAthlete = Object.values(athleteExposure)
    .map((a) => ({
      ...a,
      exposure: Math.round(a.exposure),
      concentrationPercent:
        Math.round((a.exposure / totalExposure) * 1000) / 10,
    }))
    .sort((a, b) => b.exposure - a.exposure);

  // Risk limits
  const MAX_TOTAL_EXPOSURE = 5000000;
  const MAX_EXPOSURE_PER_ATHLETE = 500000;
  const CONCENTRATION_LIMIT = 0.2;

  // Calculate risks
  const topAthleteExposure = exposureByAthlete[0]?.exposure || 0;
  const concentrationRisk =
    totalExposure > 0 ? (topAthleteExposure / totalExposure) * 100 : 0;

  // Diversification score
  const herfindahl = exposureByAthlete.reduce((sum, a) => {
    const share = a.exposure / totalExposure;
    return sum + share * share;
  }, 0);
  const diversificationScore = totalExposure > 0 ? (1 - herfindahl) * 100 : 0;

  const risks = [];
  const warnings = [];

  // Check for limit breaches
  if (totalExposure > MAX_TOTAL_EXPOSURE * 0.9) {
    warnings.push({
      type: "APPROACHING_MAX_EXPOSURE",
      message: `Total exposure at ${((totalExposure / MAX_TOTAL_EXPOSURE) * 100).toFixed(1)}% of limit`,
      severity: "medium",
    });
  }

  if (concentrationRisk > CONCENTRATION_LIMIT * 100) {
    risks.push({
      type: "CONCENTRATION_RISK",
      message: `${concentrationRisk.toFixed(1)}% concentrated in ${exposureByAthlete[0]?.athleteName}`,
      severity: "high",
    });
  }

  if (diversificationScore < 30) {
    warnings.push({
      type: "LOW_DIVERSIFICATION",
      message: `Diversification score: ${diversificationScore.toFixed(1)}/100`,
      severity: "medium",
    });
  }

  // Portfolio health score
  let healthScore = 100;
  const utilization = totalExposure / MAX_TOTAL_EXPOSURE;
  if (utilization > 0.9) healthScore -= 20;
  else if (utilization > 0.7) healthScore -= 10;
  if (concentrationRisk > 30) healthScore -= 20;
  else if (concentrationRisk > 20) healthScore -= 10;
  if (diversificationScore < 30) healthScore -= 20;
  else if (diversificationScore < 50) healthScore -= 10;

  return {
    summary: {
      totalExposure: Math.round(totalExposure),
      maxExposureLimit: MAX_TOTAL_EXPOSURE,
      utilizationRate:
        Math.round((totalExposure / MAX_TOTAL_EXPOSURE) * 1000) / 10,
      activePositions: positions.length,
      uniqueAthletes: exposureByAthlete.length,
      concentrationRisk: Math.round(concentrationRisk * 10) / 10,
      diversificationScore: Math.round(diversificationScore * 10) / 10,
      healthScore: Math.max(0, healthScore),
    },
    exposureByAthlete: exposureByAthlete.slice(0, 10),
    risks,
    warnings,
    stopLossTriggers: await getStopLossTriggers(positions),
    cooldownStatus: {
      message: "Cooldown tracking requires per-athlete/hedge-type query",
    },
  };
}

// Helper: Get stop-loss triggers
async function getStopLossTriggers(positions) {
  const triggers = [];
  const STOP_LOSS_THRESHOLD = 0.15;

  for (const pos of positions.slice(0, 10)) {
    const entryScore = pos.hedge_trigger?.performanceScore || 100;

    const currentPerf = await sql`
      SELECT AVG(ai_score) as current_score
      FROM motion_scans
      WHERE athlete_id = ${pos.athlete_id}
        AND created_at >= NOW() - INTERVAL '24 hours'
    `;

    const currentScore = parseFloat(
      currentPerf[0]?.current_score || entryScore,
    );
    const performanceDrop = (entryScore - currentScore) / entryScore;

    if (performanceDrop >= STOP_LOSS_THRESHOLD * 0.8) {
      triggers.push({
        positionId: pos.id,
        athleteId: pos.athlete_id,
        entryScore,
        currentScore,
        dropPercent: Math.round(performanceDrop * 1000) / 10,
        threshold: STOP_LOSS_THRESHOLD * 100,
        status:
          performanceDrop >= STOP_LOSS_THRESHOLD ? "TRIGGERED" : "WARNING",
      });
    }
  }

  return triggers;
}

// Helper: Get hedge type breakdown
function getHedgeTypeBreakdown(positions) {
  const breakdown = {};
  positions.forEach((p) => {
    if (!breakdown[p.hedgeType]) {
      breakdown[p.hedgeType] = {
        count: 0,
        notional: 0,
      };
    }
    breakdown[p.hedgeType].count += 1;
    breakdown[p.hedgeType].notional += p.notional;
  });

  return Object.entries(breakdown).map(([type, data]) => ({
    hedgeType: type,
    count: data.count,
    notional: Math.round(data.notional),
  }));
}

// Helper: Get signal type breakdown
function getSignalTypeBreakdown(signals) {
  const breakdown = {};
  signals.forEach((s) => {
    if (!breakdown[s.momentType]) {
      breakdown[s.momentType] = {
        count: 0,
        totalCredits: 0,
        avgIntensity: 0,
      };
    }
    breakdown[s.momentType].count += 1;
    breakdown[s.momentType].totalCredits += s.spotlightCredits;
  });

  Object.values(breakdown).forEach((b) => {
    b.totalCredits = Math.round(b.totalCredits);
  });

  return Object.entries(breakdown).map(([type, data]) => ({
    signalType: type,
    ...data,
  }));
}

// Helper: Generate scalping action recommendation
function generateScalpingAction(credits, intensity) {
  if (credits > 800 && intensity > 0.85) {
    return "STRONG SCALP: Execute aggressive micro-trade";
  }
  if (credits > 500) {
    return "SCALP: Enter position";
  }
  if (credits > 300) {
    return "WATCH: Monitor for confirmation";
  }
  return "HOLD: Below threshold";
}
