import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const [
      athleteCount,
      motionScanCount,
      milestoneCount,
      contributionSum,
      simulationCount,
      referralCount,
      recentSimulations,
      recentMilestones,
    ] = await sql.transaction([
      sql`SELECT COUNT(*) AS count FROM user_profiles WHERE user_type = 'athlete'`,
      sql`SELECT COUNT(*) AS count FROM motion_scans`,
      sql`SELECT COUNT(*) AS count, COALESCE(SUM(reward_pool), 0) AS total_reward_pool FROM milestones`,
      sql`SELECT COALESCE(SUM(amount), 0) AS total FROM contributions`,
      sql`SELECT COUNT(*) AS count FROM asset_simulations`,
      sql`SELECT COUNT(*) AS count FROM athlete_referrals`,
      sql`
        SELECT
          s.id,
          s.asset_value,
          s.roi_projection,
          s.risk_score,
          s.created_at,
          s.simulation_data
        FROM asset_simulations s
        ORDER BY s.created_at DESC
        LIMIT 8
      `,
      sql`
        SELECT
          m.id,
          m.title,
          m.milestone_status,
          m.reward_pool,
          m.target_date,
          m.created_at
        FROM milestones m
        ORDER BY m.created_at DESC
        LIMIT 5
      `,
    ]);

    const totalContributions = parseFloat(contributionSum[0]?.total || 0);
    const totalRewardPool = parseFloat(
      milestoneCount[0]?.total_reward_pool || 0,
    );
    const aum = totalContributions + totalRewardPool;

    const simulations = recentSimulations.map((s) => ({
      id: s.id,
      assetValue: parseFloat(s.asset_value) || 0,
      roiProjection: parseFloat(s.roi_projection) || 0,
      riskScore: parseFloat(s.risk_score) || 0,
      createdAt: s.created_at,
      sessionType: s.simulation_data?.sessionType || "match",
      bimScore: parseFloat(s.simulation_data?.bimScore) || 0,
      tier: s.simulation_data?.tier || "developing",
    }));

    return Response.json({
      stats: {
        athleteCount: parseInt(athleteCount[0]?.count || 0),
        motionScanCount: parseInt(motionScanCount[0]?.count || 0),
        activeMilestones: parseInt(milestoneCount[0]?.count || 0),
        totalContributions,
        aum: aum > 0 ? aum : 0,
        simulationCount: parseInt(simulationCount[0]?.count || 0),
        referralCount: parseInt(referralCount[0]?.count || 0),
      },
      recentSimulations: simulations,
      recentMilestones,
    });
  } catch (error) {
    console.error("Dashboard stats error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
