import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      alert_types = ["all"],
      athlete_ids = [],
      severity_threshold = "medium",
      timeframe_hours = 24,
    } = await request.json();

    // **PERFORMANCE TREND ALERTS ENGINE**
    const alerts = await generatePerformanceAlerts(
      alert_types,
      athlete_ids,
      severity_threshold,
      timeframe_hours,
    );

    return Response.json({
      success: true,
      alerts,
      alert_types,
      severity_threshold,
      timeframe_hours,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Performance alerts error:", error);
    return Response.json(
      {
        error: "Failed to generate performance alerts",
      },
      { status: 500 },
    );
  }
}

// **🚨 COMPREHENSIVE PERFORMANCE ALERTS ENGINE**
async function generatePerformanceAlerts(
  alertTypes,
  athleteIds,
  severityThreshold,
  timeframeHours,
) {
  // Determine which athletes to monitor
  const monitoredAthletes =
    athleteIds.length > 0 ? athleteIds : await getAllActiveAthletes();

  const allAlerts = [];

  // Process each alert type
  for (const alertType of alertTypes) {
    if (alertType === "all" || alertType === "performance_threshold") {
      const thresholdAlerts = await generatePerformanceThresholdAlerts(
        monitoredAthletes,
        timeframeHours,
      );
      allAlerts.push(...thresholdAlerts);
    }

    if (alertType === "all" || alertType === "tier_movement") {
      const tierAlerts = await generateTierMovementAlerts(
        monitoredAthletes,
        timeframeHours,
      );
      allAlerts.push(...tierAlerts);
    }

    if (alertType === "all" || alertType === "volatility") {
      const volatilityAlerts = await generateVolatilityAlerts(
        monitoredAthletes,
        timeframeHours,
      );
      allAlerts.push(...volatilityAlerts);
    }

    if (alertType === "all" || alertType === "milestone_progress") {
      const milestoneAlerts = await generateMilestoneProgressAlerts(
        monitoredAthletes,
        timeframeHours,
      );
      allAlerts.push(...milestoneAlerts);
    }

    if (alertType === "all" || alertType === "investment_opportunity") {
      const investmentAlerts = await generateInvestmentOpportunityAlerts(
        monitoredAthletes,
        timeframeHours,
      );
      allAlerts.push(...investmentAlerts);
    }

    if (alertType === "all" || alertType === "risk_warning") {
      const riskAlerts = await generateRiskWarningAlerts(
        monitoredAthletes,
        timeframeHours,
      );
      allAlerts.push(...riskAlerts);
    }
  }

  // Filter by severity threshold
  const filteredAlerts = filterAlertsBySeverity(allAlerts, severityThreshold);

  // Sort by priority and timestamp
  const sortedAlerts = sortAlertsByPriority(filteredAlerts);

  return {
    total_alerts: sortedAlerts.length,
    alerts_by_severity: categorizeAlertsBySeverity(sortedAlerts),
    alerts_by_type: categorizeAlertsByType(sortedAlerts),
    active_alerts: sortedAlerts,
    summary: generateAlertsSummary(sortedAlerts),
    recommended_actions: generateRecommendedActions(sortedAlerts),
  };
}

// **📊 GET ALL ACTIVE ATHLETES**
async function getAllActiveAthletes() {
  const athletes = await sql`
    SELECT id FROM user_profiles 
    WHERE user_type = 'athlete'
    ORDER BY updated_at DESC
    LIMIT 50
  `;

  return athletes.map((athlete) => athlete.id);
}

// **🎯 1. PERFORMANCE THRESHOLD ALERTS**
async function generatePerformanceThresholdAlerts(athleteIds, timeframeHours) {
  const alerts = [];

  for (const athleteId of athleteIds) {
    try {
      // Get recent performance data
      const [athlete, recentPerformance] = await sql.transaction([
        sql`
          SELECT up.*, au.name 
          FROM user_profiles up 
          JOIN auth_users au ON up.user_id = au.id
          WHERE up.id = ${athleteId}
        `,
        sql`
          SELECT * FROM asset_simulations 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '${timeframeHours} hours'
          ORDER BY created_at DESC
          LIMIT 10
        `,
      ]);

      if (athlete.length === 0 || recentPerformance.length === 0) continue;

      const athleteData = athlete[0];
      const latestScore = parseFloat(recentPerformance[0].asset_value);
      const scores = recentPerformance.map((p) => parseFloat(p.asset_value));

      // **PERFORMANCE THRESHOLD CHECKS**

      // 1. Tier Demotion Risk
      const tierThresholds = getTierThresholds(athleteData.tier_level);
      if (latestScore < tierThresholds.demotion_threshold) {
        alerts.push({
          id: generateAlertId(),
          type: "performance_threshold",
          subtype: "tier_demotion_risk",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "high",
          priority: "urgent",
          title: "Tier Demotion Risk",
          message: `${athleteData.name} performance (${latestScore.toFixed(1)}) below tier ${athleteData.tier_level} threshold (${tierThresholds.demotion_threshold})`,
          current_value: latestScore,
          threshold_value: tierThresholds.demotion_threshold,
          deviation: (
            ((latestScore - tierThresholds.demotion_threshold) /
              tierThresholds.demotion_threshold) *
            100
          ).toFixed(1),
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          actions: [
            "immediate_performance_review",
            "training_intervention",
            "risk_mitigation_plan",
          ],
        });
      }

      // 2. Exceptional Performance
      if (latestScore > tierThresholds.advancement_threshold) {
        alerts.push({
          id: generateAlertId(),
          type: "performance_threshold",
          subtype: "advancement_opportunity",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "medium",
          priority: "high",
          title: "Tier Advancement Opportunity",
          message: `${athleteData.name} performance (${latestScore.toFixed(1)}) exceeds advancement threshold (${tierThresholds.advancement_threshold})`,
          current_value: latestScore,
          threshold_value: tierThresholds.advancement_threshold,
          deviation: (
            ((latestScore - tierThresholds.advancement_threshold) /
              tierThresholds.advancement_threshold) *
            100
          ).toFixed(1),
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
          actions: [
            "tier_advancement_review",
            "validation_assessment",
            "investment_opportunity_analysis",
          ],
        });
      }

      // 3. Performance Volatility Spike
      if (scores.length >= 3) {
        const volatility = calculateVolatility(scores);
        if (volatility > 0.25) {
          // 25% volatility threshold
          alerts.push({
            id: generateAlertId(),
            type: "performance_threshold",
            subtype: "volatility_spike",
            athlete_id: athleteId,
            athlete_name: athleteData.name,
            severity: "medium",
            priority: "medium",
            title: "Performance Volatility Alert",
            message: `${athleteData.name} showing high performance volatility (${(volatility * 100).toFixed(1)}%)`,
            current_value: volatility,
            threshold_value: 0.25,
            deviation: (((volatility - 0.25) / 0.25) * 100).toFixed(1),
            created_at: new Date().toISOString(),
            expires_at: new Date(
              Date.now() + 12 * 60 * 60 * 1000,
            ).toISOString(),
            actions: [
              "stability_analysis",
              "consistency_training",
              "risk_assessment_update",
            ],
          });
        }
      }
    } catch (error) {
      console.error(
        `Performance threshold alert error for athlete ${athleteId}:`,
        error,
      );
    }
  }

  return alerts;
}

// **🎭 2. TIER MOVEMENT ALERTS**
async function generateTierMovementAlerts(athleteIds, timeframeHours) {
  const alerts = [];

  for (const athleteId of athleteIds) {
    try {
      // Get comprehensive athlete data
      const [athlete, performanceHistory, tierMovementHistory] =
        await sql.transaction([
          sql`
          SELECT up.*, au.name 
          FROM user_profiles up 
          JOIN auth_users au ON up.user_id = au.id
          WHERE up.id = ${athleteId}
        `,
          sql`
          SELECT * FROM asset_simulations 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '7 days'
          ORDER BY created_at ASC
        `,
          sql`
          SELECT tier_level, updated_at
          FROM user_profiles 
          WHERE id = ${athleteId}
          ORDER BY updated_at DESC
          LIMIT 5
        `,
        ]);

      if (athlete.length === 0 || performanceHistory.length < 5) continue;

      const athleteData = athlete[0];
      const scores = performanceHistory.map((p) => parseFloat(p.asset_value));

      // Calculate advancement probability
      const advancementProbability = calculateTierAdvancementProbability(
        scores,
        athleteData.tier_level,
      );

      // **TIER MOVEMENT ALERTS**

      // 1. High Advancement Probability
      if (advancementProbability > 0.75) {
        alerts.push({
          id: generateAlertId(),
          type: "tier_movement",
          subtype: "advancement_likely",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "medium",
          priority: "high",
          title: "Tier Advancement Likely",
          message: `${athleteData.name} has ${(advancementProbability * 100).toFixed(0)}% probability of tier advancement`,
          current_value: advancementProbability,
          threshold_value: 0.75,
          metadata: {
            current_tier: athleteData.tier_level,
            target_tier: athleteData.tier_level + 1,
            estimated_timeline: estimateAdvancementTimeline(
              scores,
              advancementProbability,
            ),
          },
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString(),
          actions: [
            "advancement_preparation",
            "tier_validation_scheduling",
            "investment_positioning",
          ],
        });
      }

      // 2. Demotion Risk
      const demotionRisk = calculateTierDemotionRisk(
        scores,
        athleteData.tier_level,
      );
      if (demotionRisk > 0.6) {
        alerts.push({
          id: generateAlertId(),
          type: "tier_movement",
          subtype: "demotion_risk",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "high",
          priority: "urgent",
          title: "Tier Demotion Risk",
          message: `${athleteData.name} at ${(demotionRisk * 100).toFixed(0)}% risk of tier demotion`,
          current_value: demotionRisk,
          threshold_value: 0.6,
          metadata: {
            current_tier: athleteData.tier_level,
            risk_tier: Math.max(1, athleteData.tier_level - 1),
            intervention_required: true,
          },
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          actions: [
            "immediate_intervention",
            "performance_stabilization",
            "risk_mitigation_planning",
          ],
        });
      }
    } catch (error) {
      console.error(
        `Tier movement alert error for athlete ${athleteId}:`,
        error,
      );
    }
  }

  return alerts;
}

// **📈 3. VOLATILITY ALERTS**
async function generateVolatilityAlerts(athleteIds, timeframeHours) {
  const alerts = [];

  for (const athleteId of athleteIds) {
    try {
      const [athlete, recentData] = await sql.transaction([
        sql`
          SELECT up.*, au.name 
          FROM user_profiles up 
          JOIN auth_users au ON up.user_id = au.id
          WHERE up.id = ${athleteId}
        `,
        sql`
          SELECT * FROM asset_simulations 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '${Math.max(timeframeHours, 48)} hours'
          ORDER BY created_at ASC
        `,
      ]);

      if (athlete.length === 0 || recentData.length < 5) continue;

      const athleteData = athlete[0];
      const scores = recentData.map((p) => parseFloat(p.asset_value));

      // Calculate various volatility metrics
      const shortTermVolatility = calculateVolatility(scores.slice(-5));
      const mediumTermVolatility = calculateVolatility(scores.slice(-10));
      const overallVolatility = calculateVolatility(scores);

      // **VOLATILITY ALERTS**

      // 1. Sudden Volatility Increase
      if (
        shortTermVolatility > mediumTermVolatility * 2 &&
        shortTermVolatility > 0.2
      ) {
        alerts.push({
          id: generateAlertId(),
          type: "volatility",
          subtype: "volatility_spike",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "medium",
          priority: "medium",
          title: "Volatility Spike Detected",
          message: `${athleteData.name} short-term volatility (${(shortTermVolatility * 100).toFixed(1)}%) significantly above baseline`,
          current_value: shortTermVolatility,
          threshold_value: mediumTermVolatility * 2,
          metadata: {
            short_term_volatility: shortTermVolatility,
            medium_term_volatility: mediumTermVolatility,
            volatility_ratio: shortTermVolatility / mediumTermVolatility,
          },
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString(),
          actions: [
            "volatility_investigation",
            "stability_monitoring",
            "risk_adjustment",
          ],
        });
      }

      // 2. Extreme Low Volatility (Potential stagnation)
      if (overallVolatility < 0.05 && scores.length >= 10) {
        alerts.push({
          id: generateAlertId(),
          type: "volatility",
          subtype: "low_volatility",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "low",
          priority: "low",
          title: "Performance Stagnation Warning",
          message: `${athleteData.name} showing very low volatility (${(overallVolatility * 100).toFixed(1)}%) - potential stagnation`,
          current_value: overallVolatility,
          threshold_value: 0.05,
          metadata: {
            stagnation_indicator: true,
            growth_potential: "limited",
          },
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          actions: [
            "performance_stimulation",
            "training_diversification",
            "growth_strategy_review",
          ],
        });
      }
    } catch (error) {
      console.error(`Volatility alert error for athlete ${athleteId}:`, error);
    }
  }

  return alerts;
}

// **🎯 4. MILESTONE PROGRESS ALERTS**
async function generateMilestoneProgressAlerts(athleteIds, timeframeHours) {
  const alerts = [];

  for (const athleteId of athleteIds) {
    try {
      const [athlete, activeMilestones, recentProgress] = await sql.transaction(
        [
          sql`
          SELECT up.*, au.name 
          FROM user_profiles up 
          JOIN auth_users au ON up.user_id = au.id
          WHERE up.id = ${athleteId}
        `,
          sql`
          SELECT * FROM milestones 
          WHERE athlete_id = ${athleteId}
          AND milestone_status = 'active'
          ORDER BY target_date ASC
        `,
          sql`
          SELECT * FROM asset_simulations 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '7 days'
          ORDER BY created_at DESC
          LIMIT 10
        `,
        ],
      );

      if (athlete.length === 0 || activeMilestones.length === 0) continue;

      const athleteData = athlete[0];

      for (const milestone of activeMilestones) {
        // **MILESTONE ALERTS**

        // 1. Approaching Deadline
        const timeToDeadline = milestone.target_date
          ? (new Date(milestone.target_date) - new Date()) /
            (1000 * 60 * 60 * 24)
          : null;

        if (
          timeToDeadline !== null &&
          timeToDeadline <= 7 &&
          timeToDeadline > 0
        ) {
          const progressStatus = analyzeMilestoneProgress(
            milestone,
            recentProgress,
          );

          alerts.push({
            id: generateAlertId(),
            type: "milestone_progress",
            subtype: "deadline_approaching",
            athlete_id: athleteId,
            athlete_name: athleteData.name,
            severity: timeToDeadline <= 3 ? "high" : "medium",
            priority: timeToDeadline <= 3 ? "urgent" : "high",
            title: "Milestone Deadline Approaching",
            message: `${milestone.title} deadline in ${Math.ceil(timeToDeadline)} days`,
            current_value: timeToDeadline,
            threshold_value: 7,
            metadata: {
              milestone_id: milestone.id,
              milestone_title: milestone.title,
              progress_status: progressStatus,
              completion_probability: progressStatus.completion_probability,
            },
            created_at: new Date().toISOString(),
            expires_at: milestone.target_date,
            actions: [
              "progress_acceleration",
              "milestone_review",
              "resource_allocation",
            ],
          });
        }

        // 2. Behind Schedule
        const progressAnalysis = analyzeMilestoneProgress(
          milestone,
          recentProgress,
        );
        if (progressAnalysis.behind_schedule) {
          alerts.push({
            id: generateAlertId(),
            type: "milestone_progress",
            subtype: "behind_schedule",
            athlete_id: athleteId,
            athlete_name: athleteData.name,
            severity: "medium",
            priority: "medium",
            title: "Milestone Behind Schedule",
            message: `${milestone.title} progress below expected trajectory`,
            current_value: progressAnalysis.completion_percentage,
            threshold_value: progressAnalysis.expected_percentage,
            metadata: {
              milestone_id: milestone.id,
              milestone_title: milestone.title,
              progress_gap: progressAnalysis.progress_gap,
            },
            created_at: new Date().toISOString(),
            expires_at: new Date(
              Date.now() + 48 * 60 * 60 * 1000,
            ).toISOString(),
            actions: [
              "intervention_planning",
              "progress_review",
              "support_escalation",
            ],
          });
        }
      }
    } catch (error) {
      console.error(
        `Milestone progress alert error for athlete ${athleteId}:`,
        error,
      );
    }
  }

  return alerts;
}

// **💰 5. INVESTMENT OPPORTUNITY ALERTS**
async function generateInvestmentOpportunityAlerts(athleteIds, timeframeHours) {
  const alerts = [];

  for (const athleteId of athleteIds) {
    try {
      const [athlete, performanceData, contributions] = await sql.transaction([
        sql`
          SELECT up.*, au.name 
          FROM user_profiles up 
          JOIN auth_users au ON up.user_id = au.id
          WHERE up.id = ${athleteId}
        `,
        sql`
          SELECT * FROM asset_simulations 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '7 days'
          ORDER BY created_at ASC
        `,
        sql`
          SELECT c.*, cp.milestone_id 
          FROM contributions c
          JOIN contribution_pools cp ON c.pool_id = cp.id
          JOIN milestones m ON cp.milestone_id = m.id
          WHERE m.athlete_id = ${athleteId}
          AND c.created_at >= NOW() - INTERVAL '30 days'
        `,
      ]);

      if (athlete.length === 0 || performanceData.length < 5) continue;

      const athleteData = athlete[0];
      const scores = performanceData.map((p) => parseFloat(p.asset_value));

      // **INVESTMENT OPPORTUNITY ALERTS**

      // 1. Strong Performance Streak
      const recentScores = scores.slice(-5);
      const isOnStreak = recentScores.every(
        (score, index) => index === 0 || score >= recentScores[index - 1],
      );

      if (isOnStreak && recentScores.length >= 5) {
        const streakGrowth =
          (recentScores[recentScores.length - 1] - recentScores[0]) /
          recentScores[0];

        if (streakGrowth > 0.1) {
          // 10% growth streak
          alerts.push({
            id: generateAlertId(),
            type: "investment_opportunity",
            subtype: "performance_streak",
            athlete_id: athleteId,
            athlete_name: athleteData.name,
            severity: "medium",
            priority: "medium",
            title: "Strong Performance Streak",
            message: `${athleteData.name} on ${recentScores.length}-session improvement streak (+${(streakGrowth * 100).toFixed(1)}%)`,
            current_value: streakGrowth,
            threshold_value: 0.1,
            metadata: {
              streak_length: recentScores.length,
              growth_rate: streakGrowth,
              investment_window: "optimal",
            },
            created_at: new Date().toISOString(),
            expires_at: new Date(
              Date.now() + 48 * 60 * 60 * 1000,
            ).toISOString(),
            actions: [
              "investment_analysis",
              "momentum_assessment",
              "contribution_opportunity",
            ],
          });
        }
      }

      // 2. Low Contribution Volume (Undervalued)
      const totalContributions = contributions.reduce(
        (sum, c) => sum + parseFloat(c.amount),
        0,
      );
      const avgPerformance =
        scores.reduce((sum, score) => sum + score, 0) / scores.length;

      if (avgPerformance > 70 && totalContributions < 1000) {
        // High performance, low investment
        alerts.push({
          id: generateAlertId(),
          type: "investment_opportunity",
          subtype: "undervalued_asset",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "low",
          priority: "medium",
          title: "Undervalued Investment Opportunity",
          message: `${athleteData.name} showing strong performance (${avgPerformance.toFixed(1)}) with low contribution volume ($${totalContributions.toFixed(0)})`,
          current_value: totalContributions,
          threshold_value: 1000,
          metadata: {
            performance_score: avgPerformance,
            contribution_volume: totalContributions,
            value_opportunity: "high",
          },
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString(),
          actions: [
            "value_assessment",
            "investment_positioning",
            "market_analysis",
          ],
        });
      }
    } catch (error) {
      console.error(
        `Investment opportunity alert error for athlete ${athleteId}:`,
        error,
      );
    }
  }

  return alerts;
}

// **⚠️ 6. RISK WARNING ALERTS**
async function generateRiskWarningAlerts(athleteIds, timeframeHours) {
  const alerts = [];

  for (const athleteId of athleteIds) {
    try {
      const [athlete, performanceData, motionScans] = await sql.transaction([
        sql`
          SELECT up.*, au.name 
          FROM user_profiles up 
          JOIN auth_users au ON up.user_id = au.id
          WHERE up.id = ${athleteId}
        `,
        sql`
          SELECT * FROM asset_simulations 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '14 days'
          ORDER BY created_at ASC
        `,
        sql`
          SELECT * FROM motion_scans 
          WHERE athlete_id = ${athleteId}
          AND created_at >= NOW() - INTERVAL '7 days'
          ORDER BY created_at DESC
          LIMIT 5
        `,
      ]);

      if (athlete.length === 0 || performanceData.length < 5) continue;

      const athleteData = athlete[0];
      const scores = performanceData.map((p) => parseFloat(p.asset_value));

      // **RISK WARNING ALERTS**

      // 1. Performance Decline Pattern
      const recentScores = scores.slice(-7);
      const declineCount = recentScores.filter(
        (score, index) => index > 0 && score < recentScores[index - 1],
      ).length;

      if (declineCount >= 4) {
        // Declining trend
        const declinePercentage =
          (recentScores[0] - recentScores[recentScores.length - 1]) /
          recentScores[0];

        alerts.push({
          id: generateAlertId(),
          type: "risk_warning",
          subtype: "performance_decline",
          athlete_id: athleteId,
          athlete_name: athleteData.name,
          severity: "high",
          priority: "urgent",
          title: "Performance Decline Pattern",
          message: `${athleteData.name} showing consistent decline pattern (-${(declinePercentage * 100).toFixed(1)}% over ${recentScores.length} sessions)`,
          current_value: declinePercentage,
          threshold_value: -0.1,
          metadata: {
            decline_sessions: declineCount,
            total_sessions: recentScores.length,
            decline_percentage: declinePercentage,
          },
          created_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          actions: [
            "immediate_assessment",
            "decline_investigation",
            "intervention_planning",
          ],
        });
      }

      // 2. Motion Scan Quality Degradation
      if (motionScans.length >= 3) {
        const aiScores = motionScans.map((scan) => parseFloat(scan.ai_score));
        const qualityTrend = calculateTrend(aiScores.reverse()); // Reverse to get chronological order

        if (qualityTrend < -0.05) {
          // Declining motion quality
          alerts.push({
            id: generateAlertId(),
            type: "risk_warning",
            subtype: "technique_degradation",
            athlete_id: athleteId,
            athlete_name: athleteData.name,
            severity: "medium",
            priority: "medium",
            title: "Technique Quality Declining",
            message: `${athleteData.name} motion scan quality declining (trend: ${(qualityTrend * 100).toFixed(1)}% per session)`,
            current_value: qualityTrend,
            threshold_value: -0.05,
            metadata: {
              quality_trend: qualityTrend,
              recent_ai_scores: aiScores.slice(-3),
              technical_risk: "elevated",
            },
            created_at: new Date().toISOString(),
            expires_at: new Date(
              Date.now() + 48 * 60 * 60 * 1000,
            ).toISOString(),
            actions: [
              "technique_review",
              "coaching_intervention",
              "injury_prevention_check",
            ],
          });
        }
      }
    } catch (error) {
      console.error(
        `Risk warning alert error for athlete ${athleteId}:`,
        error,
      );
    }
  }

  return alerts;
}

// **🛠️ UTILITY FUNCTIONS**

function generateAlertId() {
  return "alert_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
}

function getTierThresholds(tierLevel) {
  const isProfessional = tierLevel >= 3;

  if (isProfessional) {
    return {
      demotion_threshold: tierLevel === 3 ? 70 : tierLevel === 2 ? 50 : 30,
      advancement_threshold: tierLevel === 1 ? 70 : tierLevel === 2 ? 85 : 95,
    };
  } else {
    return {
      demotion_threshold: tierLevel === 3 ? 7 : tierLevel === 2 ? 5 : 3,
      advancement_threshold: tierLevel === 1 ? 7 : tierLevel === 2 ? 8.5 : 9.5,
    };
  }
}

function calculateVolatility(values) {
  if (values.length < 2) return 0;

  const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
  const variance =
    values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) /
    values.length;

  return Math.sqrt(variance) / (mean || 1);
}

function calculateTierAdvancementProbability(scores, currentTier) {
  if (scores.length < 5) return 0;

  const avgScore =
    scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const trend = calculateTrend(scores);
  const consistency = 1 - calculateVolatility(scores);

  const thresholds = getTierThresholds(currentTier);
  const scoreProgress = Math.min(
    1,
    avgScore / thresholds.advancement_threshold,
  );

  // Weighted probability calculation
  return scoreProgress * 0.5 + trend * 0.3 + consistency * 0.2;
}

function calculateTierDemotionRisk(scores, currentTier) {
  if (scores.length < 3) return 0;

  const avgScore =
    scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const trend = calculateTrend(scores);
  const volatility = calculateVolatility(scores);

  const thresholds = getTierThresholds(currentTier);
  const belowThreshold = avgScore < thresholds.demotion_threshold;
  const negativeTrend = trend < -0.05;
  const highVolatility = volatility > 0.3;

  let risk = 0;
  if (belowThreshold) risk += 0.4;
  if (negativeTrend) risk += 0.3;
  if (highVolatility) risk += 0.3;

  return Math.min(1, risk);
}

function calculateTrend(values) {
  if (values.length < 2) return 0;

  const n = values.length;
  const x = Array.from({ length: n }, (_, i) => i);

  const sumX = x.reduce((sum, val) => sum + val, 0);
  const sumY = values.reduce((sum, val) => sum + val, 0);
  const sumXY = x.reduce((sum, val, i) => sum + val * values[i], 0);
  const sumXX = x.reduce((sum, val) => sum + val * val, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  return slope / (sumY / n); // Normalize by average value
}

function estimateAdvancementTimeline(scores, probability) {
  if (probability < 0.5) return "unlikely";
  if (probability < 0.7) return "2-3_months";
  if (probability < 0.85) return "4-8_weeks";
  return "1-3_weeks";
}

function analyzeMilestoneProgress(milestone, recentProgress) {
  // Simplified milestone progress analysis
  const targetMetrics = milestone.target_metrics;
  const currentProgress = milestone.current_progress || {};

  // Calculate completion percentage (simplified)
  let completionPercentage = 0;
  if (targetMetrics && typeof targetMetrics === "object") {
    const targetKeys = Object.keys(targetMetrics);
    const completedKeys = targetKeys.filter(
      (key) =>
        currentProgress[key] && currentProgress[key] >= targetMetrics[key],
    );
    completionPercentage = (completedKeys.length / targetKeys.length) * 100;
  }

  // Expected percentage based on time elapsed
  const timeElapsed = milestone.target_date
    ? (Date.now() - new Date(milestone.created_at)) /
      (new Date(milestone.target_date) - new Date(milestone.created_at))
    : 0.5;
  const expectedPercentage = Math.min(100, timeElapsed * 100);

  return {
    completion_percentage: completionPercentage,
    expected_percentage: expectedPercentage,
    behind_schedule: completionPercentage < expectedPercentage - 20,
    progress_gap: expectedPercentage - completionPercentage,
    completion_probability: Math.min(
      1,
      completionPercentage / expectedPercentage,
    ),
  };
}

function filterAlertsBySeverity(alerts, severityThreshold) {
  const severityOrder = { low: 1, medium: 2, high: 3 };
  const threshold = severityOrder[severityThreshold] || 2;

  return alerts.filter((alert) => severityOrder[alert.severity] >= threshold);
}

function sortAlertsByPriority(alerts) {
  const priorityOrder = { low: 1, medium: 2, high: 3, urgent: 4 };

  return alerts.sort((a, b) => {
    const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
    if (priorityDiff !== 0) return priorityDiff;

    // Secondary sort by creation time (newest first)
    return new Date(b.created_at) - new Date(a.created_at);
  });
}

function categorizeAlertsBySeverity(alerts) {
  return {
    low: alerts.filter((alert) => alert.severity === "low").length,
    medium: alerts.filter((alert) => alert.severity === "medium").length,
    high: alerts.filter((alert) => alert.severity === "high").length,
  };
}

function categorizeAlertsByType(alerts) {
  const types = {};
  alerts.forEach((alert) => {
    types[alert.type] = (types[alert.type] || 0) + 1;
  });
  return types;
}

function generateAlertsSummary(alerts) {
  const urgentAlerts = alerts.filter(
    (alert) => alert.priority === "urgent",
  ).length;
  const highPriorityAlerts = alerts.filter(
    (alert) => alert.priority === "high",
  ).length;

  let status = "normal";
  if (urgentAlerts > 0) status = "critical";
  else if (highPriorityAlerts > 2) status = "elevated";
  else if (alerts.length > 5) status = "active";

  return {
    total_alerts: alerts.length,
    urgent_alerts: urgentAlerts,
    high_priority_alerts: highPriorityAlerts,
    status: status,
    requires_immediate_attention: urgentAlerts > 0,
    affected_athletes: [...new Set(alerts.map((alert) => alert.athlete_id))]
      .length,
  };
}

function generateRecommendedActions(alerts) {
  const actionCounts = {};
  alerts.forEach((alert) => {
    alert.actions.forEach((action) => {
      actionCounts[action] = (actionCounts[action] || 0) + 1;
    });
  });

  // Sort actions by frequency
  const prioritizedActions = Object.entries(actionCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([action, count]) => ({
      action: action,
      frequency: count,
      description: getActionDescription(action),
    }));

  return prioritizedActions;
}

function getActionDescription(action) {
  const descriptions = {
    immediate_performance_review: "Conduct urgent performance assessment",
    training_intervention: "Implement targeted training modifications",
    risk_mitigation_plan: "Develop comprehensive risk management strategy",
    tier_advancement_review: "Evaluate readiness for tier progression",
    validation_assessment: "Perform advancement validation tests",
    investment_opportunity_analysis: "Analyze investment potential and timing",
    stability_analysis: "Investigate performance stability factors",
    consistency_training: "Focus on performance consistency development",
    immediate_intervention: "Take immediate corrective action",
    performance_stabilization: "Implement performance stabilization measures",
    advancement_preparation: "Prepare for tier advancement process",
    volatility_investigation: "Investigate causes of performance volatility",
    progress_acceleration: "Accelerate milestone progress initiatives",
    intervention_planning: "Plan targeted intervention strategies",
    investment_analysis: "Conduct detailed investment analysis",
    momentum_assessment: "Assess performance momentum sustainability",
  };

  return descriptions[action] || action.replace(/_/g, " ");
}

export async function GET(request) {
  return Response.json({
    message: "Performance Alerts API - Use POST method",
    endpoints: {
      alerts: "POST /api/coach-portal/performance-alerts",
      parameters: {
        alert_types:
          'array - ["all", "performance_threshold", "tier_movement", "volatility", "milestone_progress", "investment_opportunity", "risk_warning"]',
        athlete_ids:
          "array - specific athletes to monitor (empty = all athletes)",
        severity_threshold: "low | medium | high",
        timeframe_hours: "number - lookback period in hours (default 24)",
      },
    },
    alert_types: {
      performance_threshold:
        "Tier thresholds, exceptional performance, volatility spikes",
      tier_movement: "Advancement opportunities, demotion risks",
      volatility: "Volatility spikes, stagnation warnings",
      milestone_progress: "Deadline alerts, progress behind schedule",
      investment_opportunity: "Performance streaks, undervalued assets",
      risk_warning: "Performance decline, technique degradation",
    },
  });
}
