import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      athlete_ids = [],
      scoring_type = "comprehensive",
      timeframe_days = 90,
      risk_tolerance = "medium",
    } = await request.json();

    if (athlete_ids.length === 0) {
      return Response.json(
        { error: "At least one athlete ID required" },
        { status: 400 },
      );
    }

    // **INVESTMENT POTENTIAL SCORING ENGINE**
    const investmentScoring = await generateInvestmentScoring(
      athlete_ids,
      scoring_type,
      timeframe_days,
      risk_tolerance,
    );

    return Response.json({
      success: true,
      investment_scoring: investmentScoring,
      scoring_type,
      risk_tolerance,
      timeframe_days,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Investment scoring error:", error);
    return Response.json(
      {
        error: "Failed to generate investment scoring",
      },
      { status: 500 },
    );
  }
}

// **💰 COMPREHENSIVE INVESTMENT SCORING ENGINE**
async function generateInvestmentScoring(
  athleteIds,
  scoringType,
  timeframeDays,
  riskTolerance,
) {
  // Process each athlete
  const athleteScores = await Promise.all(
    athleteIds.map((id) =>
      scoreAthleteInvestmentPotential(id, timeframeDays, riskTolerance),
    ),
  );

  const scoring = {
    // **1. INDIVIDUAL ATHLETE SCORES**
    individual_scores: athleteScores.filter(
      (score) => score.status === "success",
    ),

    // **2. COMPARATIVE RANKINGS**
    comparative_rankings: generateComparativeRankings(athleteScores),

    // **3. PORTFOLIO OPTIMIZATION**
    portfolio_optimization: generatePortfolioOptimization(
      athleteScores,
      riskTolerance,
    ),

    // **4. RISK-RETURN ANALYSIS**
    risk_return_analysis: generateRiskReturnAnalysis(athleteScores),

    // **5. INVESTMENT RECOMMENDATIONS**
    investment_recommendations: generateInvestmentRecommendations(
      athleteScores,
      riskTolerance,
    ),

    // **6. MARKET INSIGHTS**
    market_insights: generateMarketInsights(athleteScores),

    // **7. PERFORMANCE PROJECTIONS**
    performance_projections: generatePerformanceProjections(athleteScores),
  };

  return scoring;
}

// **🎯 INDIVIDUAL ATHLETE INVESTMENT SCORING**
async function scoreAthleteInvestmentPotential(
  athleteId,
  timeframeDays,
  riskTolerance,
) {
  try {
    // Gather comprehensive athlete data
    const athleteData = await gatherAthleteInvestmentData(
      athleteId,
      timeframeDays,
    );

    if (!athleteData.athlete) {
      return {
        athlete_id: athleteId,
        status: "athlete_not_found",
        score: null,
      };
    }

    // **INVESTMENT SCORE CALCULATION (0-100 scale)**
    const scoreComponents = {
      // **PERFORMANCE METRICS (35% weight)**
      current_performance: calculateCurrentPerformanceScore(athleteData) * 0.2,
      performance_consistency:
        calculatePerformanceConsistencyScore(athleteData) * 0.1,
      performance_trajectory:
        calculatePerformanceTrajectoryScore(athleteData) * 0.05,

      // **GROWTH POTENTIAL (25% weight)**
      growth_velocity: calculateGrowthVelocityScore(athleteData) * 0.15,
      learning_rate: calculateLearningRateScore(athleteData) * 0.1,

      // **MARKET FACTORS (20% weight)**
      tier_advancement_potential:
        calculateTierAdvancementScore(athleteData) * 0.1,
      competitive_positioning:
        calculateCompetitivePositioningScore(athleteData) * 0.05,
      market_demand: calculateMarketDemandScore(athleteData) * 0.05,

      // **RISK FACTORS (15% weight)**
      stability_score: calculateStabilityScore(athleteData) * 0.1,
      injury_resilience: calculateInjuryResilienceScore(athleteData) * 0.05,

      // **EXECUTION FACTORS (5% weight)**
      milestone_completion:
        calculateMilestoneCompletionScore(athleteData) * 0.03,
      engagement_level: calculateEngagementLevelScore(athleteData) * 0.02,
    };

    const totalScore = Object.values(scoreComponents).reduce(
      (sum, score) => sum + score,
      0,
    );

    // **INVESTMENT CLASSIFICATION**
    const classification = classifyInvestmentPotential(totalScore);

    // **ROI PROJECTIONS**
    const roiProjections = calculateROIProjections(athleteData, totalScore);

    // **RISK ASSESSMENT**
    const riskAssessment = assessInvestmentRisk(athleteData, riskTolerance);

    // **INVESTMENT THESIS**
    const investmentThesis = generateInvestmentThesis(
      athleteData,
      scoreComponents,
      totalScore,
    );

    return {
      athlete_id: athleteId,
      athlete_name: athleteData.athlete.name,
      status: "success",

      // **OVERALL SCORE**
      investment_score: parseFloat(totalScore.toFixed(2)),
      classification: classification,

      // **DETAILED SCORING**
      score_breakdown: {
        current_performance: parseFloat(
          scoreComponents.current_performance.toFixed(2),
        ),
        performance_consistency: parseFloat(
          scoreComponents.performance_consistency.toFixed(2),
        ),
        performance_trajectory: parseFloat(
          scoreComponents.performance_trajectory.toFixed(2),
        ),
        growth_velocity: parseFloat(scoreComponents.growth_velocity.toFixed(2)),
        learning_rate: parseFloat(scoreComponents.learning_rate.toFixed(2)),
        tier_advancement_potential: parseFloat(
          scoreComponents.tier_advancement_potential.toFixed(2),
        ),
        competitive_positioning: parseFloat(
          scoreComponents.competitive_positioning.toFixed(2),
        ),
        market_demand: parseFloat(scoreComponents.market_demand.toFixed(2)),
        stability_score: parseFloat(scoreComponents.stability_score.toFixed(2)),
        injury_resilience: parseFloat(
          scoreComponents.injury_resilience.toFixed(2),
        ),
        milestone_completion: parseFloat(
          scoreComponents.milestone_completion.toFixed(2),
        ),
        engagement_level: parseFloat(
          scoreComponents.engagement_level.toFixed(2),
        ),
      },

      // **FINANCIAL PROJECTIONS**
      roi_projections: roiProjections,

      // **RISK ANALYSIS**
      risk_assessment: riskAssessment,

      // **INVESTMENT THESIS**
      investment_thesis: investmentThesis,

      // **RECOMMENDATIONS**
      recommended_allocation: calculateRecommendedAllocation(
        totalScore,
        riskTolerance,
      ),
      investment_timeline: calculateOptimalInvestmentTimeline(athleteData),

      // **KEY METRICS**
      key_metrics: {
        current_tier: athleteData.athlete.tier_level,
        total_contributions: athleteData.contributions.reduce(
          (sum, c) => sum + parseFloat(c.amount),
          0,
        ),
        active_milestones: athleteData.milestones.filter(
          (m) => m.milestone_status === "active",
        ).length,
        performance_trend: calculatePerformanceTrend(
          athleteData.performance_history,
        ),
      },
    };
  } catch (error) {
    console.error(`Investment scoring error for athlete ${athleteId}:`, error);
    return {
      athlete_id: athleteId,
      status: "error",
      error: error.message,
      score: null,
    };
  }
}

// **📊 ATHLETE DATA GATHERING**
async function gatherAthleteInvestmentData(athleteId, timeframeDays) {
  const [
    athlete,
    performanceHistory,
    motionScans,
    milestones,
    contributions,
    wallet,
  ] = await sql.transaction([
    sql`
      SELECT up.*, au.name, au.email 
      FROM user_profiles up 
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId}
    `,
    sql`
      SELECT * FROM asset_simulations 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY created_at ASC
    `,
    sql`
      SELECT * FROM motion_scans 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY created_at ASC
    `,
    sql`
      SELECT * FROM milestones 
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 10
    `,
    sql`
      SELECT c.*, cp.milestone_id 
      FROM contributions c
      JOIN contribution_pools cp ON c.pool_id = cp.id
      JOIN milestones m ON cp.milestone_id = m.id
      WHERE m.athlete_id = ${athleteId}
      AND c.created_at >= NOW() - INTERVAL '${timeframeDays} days'
    `,
    sql`
      SELECT * FROM digital_wallets 
      WHERE user_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 1
    `,
  ]);

  return {
    athlete: athlete[0] || null,
    performance_history: performanceHistory,
    motion_scans: motionScans,
    milestones: milestones,
    contributions: contributions,
    wallet: wallet[0] || null,
  };
}

// **🏆 PERFORMANCE SCORING FUNCTIONS**

function calculateCurrentPerformanceScore(data) {
  const { performance_history } = data;

  if (performance_history.length === 0) return 50; // Default middle score

  const recentScores = performance_history
    .slice(-5)
    .map((h) => parseFloat(h.asset_value));
  const avgScore =
    recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

  // Normalize to 0-100 scale (assuming max possible score is around 100)
  return Math.min(100, Math.max(0, avgScore));
}

function calculatePerformanceConsistencyScore(data) {
  const { performance_history } = data;

  if (performance_history.length < 3) return 50;

  const scores = performance_history.map((h) => parseFloat(h.asset_value));
  const mean = scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const cv = Math.sqrt(variance) / (mean || 1);

  // Convert coefficient of variation to consistency score (lower CV = higher consistency)
  const consistencyRatio = Math.max(0, Math.min(1, 1 - cv));
  return consistencyRatio * 100;
}

function calculatePerformanceTrajectoryScore(data) {
  const { performance_history } = data;

  if (performance_history.length < 5) return 50;

  const scores = performance_history.map((h) => parseFloat(h.asset_value));
  const n = scores.length;
  const x = Array.from({ length: n }, (_, i) => i);

  // Calculate linear regression slope
  const sumX = x.reduce((sum, val) => sum + val, 0);
  const sumY = scores.reduce((sum, val) => sum + val, 0);
  const sumXY = x.reduce((sum, val, i) => sum + val * scores[i], 0);
  const sumXX = x.reduce((sum, val) => sum + val * val, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);

  // Convert slope to 0-100 score (positive slope = better trajectory)
  return Math.max(0, Math.min(100, 50 + slope * 10));
}

function calculateGrowthVelocityScore(data) {
  const { performance_history } = data;

  if (performance_history.length < 6) return 50;

  const scores = performance_history.map((h) => parseFloat(h.asset_value));
  const recent = scores.slice(-3);
  const earlier = scores.slice(-6, -3);

  const recentAvg = recent.reduce((sum, s) => sum + s, 0) / recent.length;
  const earlierAvg = earlier.reduce((sum, s) => sum + s, 0) / earlier.length;

  const growthRate = (recentAvg - earlierAvg) / (earlierAvg || 1);

  // Convert growth rate to 0-100 score
  return Math.max(0, Math.min(100, 50 + growthRate * 100));
}

function calculateLearningRateScore(data) {
  const { motion_scans } = data;

  if (motion_scans.length < 3) return 50;

  // Analyze improvement in AI scores over time
  const aiScores = motion_scans.map((scan) => parseFloat(scan.ai_score));
  const improvements = [];

  for (let i = 1; i < aiScores.length; i++) {
    improvements.push(aiScores[i] - aiScores[i - 1]);
  }

  const avgImprovement =
    improvements.reduce((sum, imp) => sum + imp, 0) / improvements.length;

  // Convert to 0-100 score
  return Math.max(0, Math.min(100, 50 + avgImprovement * 2));
}

function calculateTierAdvancementScore(data) {
  const { athlete, performance_history } = data;

  if (!athlete || performance_history.length < 3) return 50;

  const currentTier = athlete.tier_level;
  const recentScores = performance_history
    .slice(-5)
    .map((h) => parseFloat(h.asset_value));
  const avgScore =
    recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

  // Define advancement thresholds
  const thresholds = {
    1: 70, // Tier 1 to 2
    2: 85, // Tier 2 to 3
    3: 95, // Tier 3 to 4
  };

  const nextTierThreshold = thresholds[currentTier];
  if (!nextTierThreshold) return 100; // Already at max tier

  const advancementProgress = Math.min(1, avgScore / nextTierThreshold);
  return advancementProgress * 100;
}

function calculateCompetitivePositioningScore(data) {
  const { athlete, performance_history } = data;

  if (!athlete || performance_history.length === 0) return 50;

  // Simplified competitive positioning based on tier and recent performance
  const tierMultiplier = athlete.tier_level * 15; // Higher tier = better positioning
  const recentScores = performance_history
    .slice(-3)
    .map((h) => parseFloat(h.asset_value));
  const avgScore =
    recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

  const performanceComponent = Math.min(40, avgScore * 0.5);

  return Math.min(100, tierMultiplier + performanceComponent);
}

function calculateMarketDemandScore(data) {
  const { athlete, contributions } = data;

  if (!athlete) return 50;

  // Base score on tier level and investment interest
  const tierScore = athlete.tier_level * 20;
  const contributionScore = Math.min(30, contributions.length * 5);

  return Math.min(100, tierScore + contributionScore);
}

function calculateStabilityScore(data) {
  const { performance_history } = data;

  if (performance_history.length < 5) return 50;

  const scores = performance_history.map((h) => parseFloat(h.asset_value));
  const volatility = calculateVolatility(scores);

  // Lower volatility = higher stability score
  const stabilityRatio = Math.max(0, 1 - volatility);
  return stabilityRatio * 100;
}

function calculateInjuryResilienceScore(data) {
  const { motion_scans } = data;

  if (motion_scans.length === 0) return 50;

  // Analyze motion scan consistency as proxy for injury resilience
  const aiScores = motion_scans.map((scan) => parseFloat(scan.ai_score));
  const consistency = calculateConsistency(aiScores);

  return consistency * 100;
}

function calculateMilestoneCompletionScore(data) {
  const { milestones } = data;

  if (milestones.length === 0) return 50;

  const completedMilestones = milestones.filter(
    (m) => m.milestone_status === "completed",
  ).length;
  const completionRate = completedMilestones / milestones.length;

  return completionRate * 100;
}

function calculateEngagementLevelScore(data) {
  const { performance_history, motion_scans, milestones } = data;

  // Base engagement on frequency of activities
  const totalActivities =
    performance_history.length + motion_scans.length + milestones.length;

  // Normalize to reasonable scale
  return Math.min(100, Math.max(20, totalActivities * 2));
}

// **📈 CLASSIFICATION AND RECOMMENDATIONS**

function classifyInvestmentPotential(score) {
  if (score >= 85)
    return {
      category: "elite",
      description: "Exceptional investment opportunity with elite potential",
      recommendation: "strong_buy",
      confidence: "very_high",
    };

  if (score >= 75)
    return {
      category: "premium",
      description: "High-quality investment with strong growth potential",
      recommendation: "buy",
      confidence: "high",
    };

  if (score >= 65)
    return {
      category: "quality",
      description: "Solid investment opportunity with moderate risk",
      recommendation: "moderate_buy",
      confidence: "medium",
    };

  if (score >= 50)
    return {
      category: "developing",
      description: "Emerging talent with development potential",
      recommendation: "watch",
      confidence: "medium",
    };

  if (score >= 35)
    return {
      category: "speculative",
      description: "High-risk, high-reward speculative opportunity",
      recommendation: "small_position",
      confidence: "low",
    };

  return {
    category: "avoid",
    description: "High risk with limited upside potential",
    recommendation: "avoid",
    confidence: "high",
  };
}

function calculateROIProjections(data, investmentScore) {
  const baseROI = investmentScore * 0.002; // Base 0.2% per point

  return {
    "30_day": {
      conservative: parseFloat((baseROI * 0.5).toFixed(4)),
      moderate: parseFloat(baseROI.toFixed(4)),
      aggressive: parseFloat((baseROI * 1.5).toFixed(4)),
    },
    "90_day": {
      conservative: parseFloat((baseROI * 1.5).toFixed(4)),
      moderate: parseFloat((baseROI * 2.5).toFixed(4)),
      aggressive: parseFloat((baseROI * 4.0).toFixed(4)),
    },
    "180_day": {
      conservative: parseFloat((baseROI * 2.5).toFixed(4)),
      moderate: parseFloat((baseROI * 4.5).toFixed(4)),
      aggressive: parseFloat((baseROI * 7.0).toFixed(4)),
    },
  };
}

function assessInvestmentRisk(data, riskTolerance) {
  const { performance_history } = data;

  const volatility =
    performance_history.length > 0
      ? calculateVolatility(
          performance_history.map((h) => parseFloat(h.asset_value)),
        )
      : 0.5;

  let riskLevel = "medium";
  if (volatility < 0.15) riskLevel = "low";
  else if (volatility > 0.35) riskLevel = "high";

  const riskScore = Math.min(100, volatility * 200);

  return {
    risk_level: riskLevel,
    risk_score: parseFloat(riskScore.toFixed(2)),
    volatility: parseFloat(volatility.toFixed(4)),
    risk_tolerance_match: assessRiskToleranceMatch(riskLevel, riskTolerance),
    key_risk_factors: identifyKeyRiskFactors(data),
  };
}

function generateInvestmentThesis(data, scoreComponents, totalScore) {
  const { athlete } = data;

  const strengths = [];
  const concerns = [];

  // Identify key strengths
  if (scoreComponents.current_performance > 15)
    strengths.push("Strong current performance");
  if (scoreComponents.performance_consistency > 8)
    strengths.push("Consistent execution");
  if (scoreComponents.growth_velocity > 10)
    strengths.push("Positive growth trajectory");
  if (scoreComponents.tier_advancement_potential > 7)
    strengths.push("Clear advancement path");

  // Identify concerns
  if (scoreComponents.stability_score < 6)
    concerns.push("Performance volatility");
  if (scoreComponents.current_performance < 10)
    concerns.push("Below-average performance");
  if (scoreComponents.growth_velocity < 5)
    concerns.push("Limited growth momentum");

  return {
    overall_thesis: generateOverallThesis(totalScore, athlete),
    key_strengths: strengths,
    key_concerns: concerns,
    investment_rationale: generateInvestmentRationale(data, scoreComponents),
    upside_scenarios: generateUpsideScenarios(data),
    downside_risks: generateDownsideRisks(data),
  };
}

// **🛠️ UTILITY FUNCTIONS**

function calculateVolatility(values) {
  if (values.length < 2) return 0;

  const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
  const variance =
    values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) /
    values.length;

  return Math.sqrt(variance) / (mean || 1);
}

function calculateConsistency(values) {
  if (values.length < 2) return 0.5;

  const volatility = calculateVolatility(values);
  return Math.max(0, Math.min(1, 1 - volatility));
}

function calculatePerformanceTrend(history) {
  if (history.length < 3) return "stable";

  const scores = history.slice(-5).map((h) => parseFloat(h.asset_value));
  const recent = scores.slice(-2);
  const earlier = scores.slice(0, 2);

  if (recent.length === 0 || earlier.length === 0) return "stable";

  const recentAvg = recent.reduce((sum, s) => sum + s, 0) / recent.length;
  const earlierAvg = earlier.reduce((sum, s) => sum + s, 0) / earlier.length;

  const change = (recentAvg - earlierAvg) / earlierAvg;

  if (change > 0.05) return "improving";
  if (change < -0.05) return "declining";
  return "stable";
}

function calculateRecommendedAllocation(score, riskTolerance) {
  const baseAllocation = score / 100;

  const riskMultipliers = {
    conservative: 0.6,
    medium: 1.0,
    aggressive: 1.4,
  };

  const multiplier = riskMultipliers[riskTolerance] || 1.0;
  const allocation = baseAllocation * multiplier;

  return {
    percentage: parseFloat((allocation * 100).toFixed(2)),
    allocation_tier:
      allocation > 0.8
        ? "large"
        : allocation > 0.5
          ? "medium"
          : allocation > 0.2
            ? "small"
            : "minimal",
  };
}

function calculateOptimalInvestmentTimeline(data) {
  const { athlete, performance_history } = data;

  const trend = calculatePerformanceTrend(performance_history);
  const currentTier = athlete?.tier_level || 1;

  if (trend === "improving" && currentTier >= 2) return "immediate";
  if (trend === "improving") return "1-2_weeks";
  if (trend === "stable") return "2-4_weeks";
  return "1-2_months";
}

function assessRiskToleranceMatch(riskLevel, riskTolerance) {
  const compatibilityMatrix = {
    conservative: { low: "excellent", medium: "good", high: "poor" },
    medium: { low: "good", medium: "excellent", high: "good" },
    aggressive: { low: "poor", medium: "good", high: "excellent" },
  };

  return compatibilityMatrix[riskTolerance]?.[riskLevel] || "unknown";
}

function identifyKeyRiskFactors(data) {
  const { performance_history } = data;
  const risks = [];

  if (performance_history.length < 5) risks.push("Limited performance history");

  const scores = performance_history.map((h) => parseFloat(h.asset_value));
  const volatility = calculateVolatility(scores);

  if (volatility > 0.3) risks.push("High performance volatility");
  if (scores.length > 0 && Math.max(...scores) - Math.min(...scores) > 30)
    risks.push("Wide performance range");

  return risks;
}

function generateOverallThesis(score, athlete) {
  if (score >= 80)
    return `Elite investment opportunity with ${athlete?.name || "athlete"} demonstrating exceptional potential across multiple performance dimensions.`;
  if (score >= 65)
    return `Strong investment candidate with solid fundamentals and clear growth trajectory.`;
  if (score >= 50)
    return `Moderate investment opportunity with balanced risk-return profile.`;
  return `Speculative investment requiring careful monitoring and risk management.`;
}

function generateInvestmentRationale(data, components) {
  const topFactors = Object.entries(components)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([factor]) => factor.replace(/_/g, " "));

  return `Investment primarily supported by: ${topFactors.join(", ")}`;
}

function generateUpsideScenarios(data) {
  return [
    "Tier advancement triggering valuation premium",
    "Sustained performance improvement attracting institutional interest",
    "Successful milestone completion driving fan engagement",
  ];
}

function generateDownsideRisks(data) {
  return [
    "Performance decline impacting tier status",
    "Increased volatility reducing investor confidence",
    "Market saturation limiting growth potential",
  ];
}

// **📊 COMPARATIVE AND PORTFOLIO FUNCTIONS**

function generateComparativeRankings(athleteScores) {
  const validScores = athleteScores.filter(
    (score) => score.status === "success",
  );

  if (validScores.length === 0)
    return { rankings: [], status: "no_valid_scores" };

  // Sort by investment score
  validScores.sort((a, b) => b.investment_score - a.investment_score);

  return {
    rankings: validScores.map((score, index) => ({
      rank: index + 1,
      athlete_id: score.athlete_id,
      athlete_name: score.athlete_name,
      investment_score: score.investment_score,
      classification: score.classification,
      percentile: ((validScores.length - index) / validScores.length) * 100,
    })),
    status: "complete",
    total_athletes: validScores.length,
  };
}

function generatePortfolioOptimization(athleteScores, riskTolerance) {
  const validScores = athleteScores.filter(
    (score) => score.status === "success",
  );

  if (validScores.length < 2) return { status: "insufficient_athletes" };

  // Simple portfolio optimization based on risk-adjusted returns
  const portfolioWeights = optimizePortfolioWeights(validScores, riskTolerance);

  return {
    status: "complete",
    recommended_portfolio: portfolioWeights,
    expected_return: calculatePortfolioReturn(validScores, portfolioWeights),
    portfolio_risk: calculatePortfolioRisk(validScores, portfolioWeights),
    diversification_score: calculateDiversificationScore(portfolioWeights),
  };
}

function generateRiskReturnAnalysis(athleteScores) {
  const validScores = athleteScores.filter(
    (score) => score.status === "success",
  );

  return {
    risk_return_scatter: validScores.map((score) => ({
      athlete_id: score.athlete_id,
      athlete_name: score.athlete_name,
      expected_return: score.roi_projections["90_day"].moderate,
      risk_score: score.risk_assessment.risk_score,
      investment_score: score.investment_score,
    })),
    efficient_frontier: calculateEfficientFrontier(validScores),
    risk_categories: categorizeByRisk(validScores),
  };
}

function generateInvestmentRecommendations(athleteScores, riskTolerance) {
  const validScores = athleteScores.filter(
    (score) => score.status === "success",
  );

  const recommendations = {
    top_picks: validScores
      .filter(
        (score) =>
          score.classification.recommendation === "strong_buy" ||
          score.classification.recommendation === "buy",
      )
      .slice(0, 5),

    value_opportunities: validScores
      .filter(
        (score) =>
          score.investment_score > 60 &&
          score.risk_assessment.risk_level === "low",
      )
      .slice(0, 3),

    growth_candidates: validScores
      .filter((score) => score.score_breakdown.growth_velocity > 10)
      .slice(0, 3),

    watch_list: validScores
      .filter((score) => score.classification.recommendation === "watch")
      .slice(0, 5),
  };

  return recommendations;
}

function generateMarketInsights(athleteScores) {
  const validScores = athleteScores.filter(
    (score) => score.status === "success",
  );

  const avgScore =
    validScores.reduce((sum, score) => sum + score.investment_score, 0) /
    validScores.length;
  const scoreDistribution = calculateScoreDistribution(validScores);

  return {
    market_average_score: parseFloat(avgScore.toFixed(2)),
    score_distribution: scoreDistribution,
    market_sentiment:
      avgScore > 65 ? "bullish" : avgScore > 50 ? "neutral" : "bearish",
    top_performers: validScores.slice(0, 3),
    undervalued_opportunities: identifyUndervaluedOpportunities(validScores),
  };
}

function generatePerformanceProjections(athleteScores) {
  const validScores = athleteScores.filter(
    (score) => score.status === "success",
  );

  return {
    individual_projections: validScores.map((score) => ({
      athlete_id: score.athlete_id,
      athlete_name: score.athlete_name,
      projected_30_day_return: score.roi_projections["30_day"].moderate,
      projected_90_day_return: score.roi_projections["90_day"].moderate,
      confidence_level: score.classification.confidence,
    })),
    portfolio_projections: calculatePortfolioProjections(validScores),
  };
}

// Additional utility functions for portfolio optimization...

function optimizePortfolioWeights(scores, riskTolerance) {
  // Simplified equal weight optimization
  const weights = {};
  const weightPerAthlete = 1 / scores.length;

  scores.forEach((score) => {
    weights[score.athlete_id] = {
      weight: parseFloat(weightPerAthlete.toFixed(4)),
      allocation_reasoning: `Equal weight allocation (${(weightPerAthlete * 100).toFixed(1)}%)`,
    };
  });

  return weights;
}

function calculatePortfolioReturn(scores, weights) {
  return scores.reduce((totalReturn, score) => {
    const weight = weights[score.athlete_id]?.weight || 0;
    const expectedReturn = score.roi_projections["90_day"].moderate;
    return totalReturn + weight * expectedReturn;
  }, 0);
}

function calculatePortfolioRisk(scores, weights) {
  // Simplified risk calculation
  return scores.reduce((totalRisk, score) => {
    const weight = weights[score.athlete_id]?.weight || 0;
    const riskScore = score.risk_assessment.risk_score / 100;
    return totalRisk + weight * riskScore;
  }, 0);
}

function calculateDiversificationScore(weights) {
  const weightValues = Object.values(weights).map((w) => w.weight);
  const concentration = Math.max(...weightValues);
  return (1 - concentration) * 100; // Higher score = better diversification
}

function calculateEfficientFrontier(scores) {
  // Simplified efficient frontier calculation
  return [
    { risk: 0.1, return: 0.05, label: "Conservative" },
    { risk: 0.2, return: 0.12, label: "Moderate" },
    { risk: 0.35, return: 0.22, label: "Aggressive" },
  ];
}

function categorizeByRisk(scores) {
  const categories = { low: [], medium: [], high: [] };

  scores.forEach((score) => {
    const riskLevel = score.risk_assessment.risk_level;
    if (categories[riskLevel]) {
      categories[riskLevel].push({
        athlete_id: score.athlete_id,
        athlete_name: score.athlete_name,
        investment_score: score.investment_score,
      });
    }
  });

  return categories;
}

function calculateScoreDistribution(scores) {
  const ranges = {
    "80-100": 0,
    "60-79": 0,
    "40-59": 0,
    "20-39": 0,
    "0-19": 0,
  };

  scores.forEach((score) => {
    const s = score.investment_score;
    if (s >= 80) ranges["80-100"]++;
    else if (s >= 60) ranges["60-79"]++;
    else if (s >= 40) ranges["40-59"]++;
    else if (s >= 20) ranges["20-39"]++;
    else ranges["0-19"]++;
  });

  return ranges;
}

function identifyUndervaluedOpportunities(scores) {
  return scores
    .filter(
      (score) =>
        score.investment_score > 65 &&
        score.risk_assessment.risk_level === "low",
    )
    .slice(0, 3);
}

function calculatePortfolioProjections(scores) {
  const avgReturn30 =
    scores.reduce(
      (sum, score) => sum + score.roi_projections["30_day"].moderate,
      0,
    ) / scores.length;
  const avgReturn90 =
    scores.reduce(
      (sum, score) => sum + score.roi_projections["90_day"].moderate,
      0,
    ) / scores.length;

  return {
    portfolio_30_day_return: parseFloat(avgReturn30.toFixed(4)),
    portfolio_90_day_return: parseFloat(avgReturn90.toFixed(4)),
    confidence: "medium",
  };
}

export async function GET(request) {
  return Response.json({
    message: "Investment Scoring API - Use POST method",
    endpoints: {
      scoring: "POST /api/coach-portal/investment-scoring",
      parameters: {
        athlete_ids: "array - athlete IDs to score",
        scoring_type: "comprehensive | performance | risk_adjusted",
        timeframe_days: "number - default 90",
        risk_tolerance: "conservative | medium | aggressive",
      },
    },
  });
}
