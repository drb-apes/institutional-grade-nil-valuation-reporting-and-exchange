import sql from "@/app/api/utils/sql";
import { SPORT_PROFILES } from "@/app/api/context/sport-profiles/route";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sport = searchParams.get("sport") || "wrestling";
  const org = searchParams.get("org") || "ncaa_d1";

  try {
    // Fetch all user profiles who are athletes
    const athletes = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.tier_level,
        up.total_contributions,
        au.name,
        au.email
      FROM user_profiles up
      INNER JOIN auth_users au ON up.user_id = au.id
      WHERE up.user_type = 'athlete'
      ORDER BY up.tier_level DESC, up.total_contributions DESC
      LIMIT 50
    `;

    // For each athlete, fetch their latest motion scan and compute analytics
    const roster = await Promise.all(
      athletes.map(async (athlete) => {
        // Fetch recent motion scans
        const scans = await sql`
          SELECT * FROM motion_scans
          WHERE athlete_id = ${athlete.id}
          ORDER BY created_at DESC
          LIMIT 10
        `;

        if (scans.length === 0) {
          return {
            id: athlete.id,
            name: athlete.name || `Athlete ${athlete.id}`,
            position: null,
            ppi: 0,
            tier: "amateur",
            velocity: 0,
            injury_risk: "low",
            consistency: 0,
            breakout_probability: 0,
          };
        }

        // Extract PPIs from scans
        const historicalPPIs = scans.map((scan) => ({
          ppi: scan.ai_score || 0,
          timestamp: scan.created_at,
        }));

        // Calculate velocity (simple slope)
        let velocity = 0;
        if (historicalPPIs.length >= 2) {
          const recent = historicalPPIs.slice(0, 5);
          const oldestPPI = recent[recent.length - 1].ppi;
          const newestPPI = recent[0].ppi;
          velocity = newestPPI - oldestPPI;
        }

        // Calculate consistency (inverse of variance)
        const ppis = historicalPPIs.map((h) => h.ppi);
        const mean = ppis.reduce((sum, v) => sum + v, 0) / ppis.length;
        const variance =
          ppis.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / ppis.length;
        const consistency = Math.max(0, 100 - variance);

        // Simple injury risk based on load (from latest scan)
        const latestScan = scans[0];
        const loadMetric =
          latestScan.scan_data?.load || latestScan.scan_data?.loadFatigue || 0;
        const injury_risk =
          loadMetric > 70 ? "high" : loadMetric > 40 ? "medium" : "low";

        // Breakout probability (velocity + consistency)
        const breakout_probability = Math.min(
          100,
          Math.max(0, velocity * 10 + consistency * 0.3),
        );

        // Determine tier based on PPI
        const currentPPI = historicalPPIs[0].ppi;
        const sportProfile = SPORT_PROFILES[sport];
        let tier = "amateur";
        if (sportProfile) {
          for (const [tierName, bounds] of Object.entries(
            sportProfile.tierBoundaries,
          )) {
            if (currentPPI >= bounds.ppi_min && currentPPI <= bounds.ppi_max) {
              tier = tierName;
              break;
            }
          }
        }

        return {
          id: athlete.id,
          name: athlete.name || `Athlete ${athlete.id}`,
          position: latestScan.metadata?.position || null,
          ppi: currentPPI,
          tier,
          velocity,
          injury_risk,
          consistency,
          breakout_probability: Math.round(breakout_probability),
        };
      }),
    );

    return Response.json({
      sport,
      org,
      roster,
      count: roster.length,
    });
  } catch (error) {
    console.error("Error fetching roster:", error);
    return Response.json(
      { error: "Failed to fetch roster", details: error.message },
      { status: 500 },
    );
  }
}
