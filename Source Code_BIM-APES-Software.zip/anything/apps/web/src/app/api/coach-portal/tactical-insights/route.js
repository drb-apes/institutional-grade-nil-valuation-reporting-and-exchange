import { SPORT_PROFILES } from "@/app/api/context/sport-profiles/route";

// Sport-specific tactical insights generator
function generateTacticalInsights(sport) {
  const insights = {
    wrestling: [
      {
        title: "Control Time Optimization",
        description:
          "Average control time has increased 12% over last 3 sessions",
        metrics: {
          avg_control_time: "2.4 min",
          improvement: "+12%",
          best_performer: "Athlete #3",
          consistency: "87%",
        },
        recommendations: [
          "Focus on maintaining position during third period",
          "Increase mat time for athletes scoring below 2.0 min",
          "Implement control drills in warmup rotation",
        ],
      },
      {
        title: "Takedown Speed Analysis",
        description: "Explosive takedowns correlate with 68% win probability",
        metrics: {
          avg_takedown_speed: "1.8 sec",
          win_correlation: "68%",
          top_quartile: "1.2 sec",
          improvement_needed: "0.6 sec",
        },
        recommendations: [
          "Add reaction time drills to daily practice",
          "Review tape of sub-1.5 sec takedowns",
          "Partner faster athletes with those needing improvement",
        ],
      },
    ],
    basketball: [
      {
        title: "Spacing Efficiency",
        description:
          "Optimal floor spacing increases offensive rating by 14 points",
        metrics: {
          current_spacing: "16.2 ft",
          optimal_spacing: "18.5 ft",
          offensive_rating: "+14 pts",
          spacing_violations: "23%",
        },
        recommendations: [
          "Run spacing drills with visual markers",
          "Review film highlighting spacing breakdowns",
          "Assign spacing accountability metrics to guards",
        ],
      },
      {
        title: "Transition Speed",
        description: "Fast break efficiency up 18% when pace exceeds 95",
        metrics: {
          avg_pace: "92 possessions",
          fast_break_pct: "18%",
          target_pace: "95+",
          points_per_possession: "1.21",
        },
        recommendations: [
          "Increase conditioning focus on sprint intervals",
          "Reward fast break initiations in practice",
          "Track transition metrics per player",
        ],
      },
    ],
    soccer: [
      {
        title: "Pressing Trigger Points",
        description:
          "High press success rate of 61% when triggered in final third",
        metrics: {
          press_success: "61%",
          recoveries: "8.4/game",
          optimal_zone: "Final Third",
          turnovers_created: "12",
        },
        recommendations: [
          "Drill compact pressing shape in final third",
          "Identify individual press triggers for each player",
          "Review successful press sequences from match film",
        ],
      },
    ],
    rugby: [
      {
        title: "Ruck Speed & Ball Retention",
        description:
          "Quick ruck ball (under 3 sec) leads to 74% possession retention",
        metrics: {
          avg_ruck_speed: "2.8 sec",
          retention_rate: "74%",
          target_speed: "<3 sec",
          turnovers_avoided: "9",
        },
        recommendations: [
          "Focus on cleanout technique in training",
          "Assign dedicated ruck specialists",
          "Track ruck speed metrics per forward",
        ],
      },
    ],
    tennis: [
      {
        title: "First Serve Percentage Impact",
        description: "Points won on first serve: 68% vs 52% on second serve",
        metrics: {
          first_serve_pct: "58%",
          first_serve_win: "68%",
          second_serve_win: "52%",
          target: "65%",
        },
        recommendations: [
          "Increase first serve consistency drills",
          "Add pressure serving scenarios",
          "Review serve placement patterns",
        ],
      },
    ],
    pickleball: [
      {
        title: "Kitchen Line Dominance",
        description: "Teams controlling kitchen line win 78% of rallies",
        metrics: {
          kitchen_time: "62%",
          rally_win_rate: "78%",
          dink_consistency: "84%",
          approach_success: "71%",
        },
        recommendations: [
          "Drill third-shot drop consistency",
          "Practice kitchen line positioning",
          "Review successful approach strategies",
        ],
      },
    ],
    american_football: [
      {
        title: "Third Down Conversion Efficiency",
        description: "Play-action on 3rd & medium increases conversion by 22%",
        metrics: {
          third_down_pct: "42%",
          play_action_boost: "+22%",
          avg_distance: "6.8 yds",
          target_rate: "50%",
        },
        recommendations: [
          "Increase play-action reps in 3rd down packages",
          "Study film of successful 3rd & medium conversions",
          "Add situational 3rd down period to practice",
        ],
      },
    ],
  };

  return (
    insights[sport] || [
      {
        title: "General Performance Insights",
        description: "Sport-specific tactical analysis coming soon",
        metrics: {
          status: "In Development",
        },
        recommendations: [
          "Continue collecting performance data",
          "Review general performance trends",
          "Contact support for custom insights",
        ],
      },
    ]
  );
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sport = searchParams.get("sport") || "wrestling";

  try {
    const sportProfile = SPORT_PROFILES[sport];
    if (!sportProfile) {
      return Response.json({ error: "Invalid sport profile" }, { status: 404 });
    }

    const insights = generateTacticalInsights(sport);

    return Response.json({
      sport,
      sport_name: sportProfile.name,
      insights,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error generating tactical insights:", error);
    return Response.json(
      { error: "Failed to generate insights", details: error.message },
      { status: 500 },
    );
  }
}
