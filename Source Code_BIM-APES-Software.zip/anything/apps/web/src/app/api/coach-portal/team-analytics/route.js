import sql from "@/app/api/utils/sql";
import { SPORT_PROFILES } from "@/app/api/context/sport-profiles/route";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sport = searchParams.get("sport") || "wrestling";
  const org = searchParams.get("org") || "ncaa_d1";

  try {
    // Fetch roster data (reuse logic from roster endpoint)
    const athletes = await sql`
      SELECT up.id
      FROM user_profiles up
      WHERE up.user_type = 'athlete'
      LIMIT 50
    `;

    // Collect all athlete PPIs
    const athletePPIs = [];

    for (const athlete of athletes) {
      const scans = await sql`
        SELECT ai_score FROM motion_scans
        WHERE athlete_id = ${athlete.id}
        ORDER BY created_at DESC
        LIMIT 1
      `;

      if (scans.length > 0) {
        athletePPIs.push({
          athleteId: athlete.id,
          ppi: scans[0].ai_score || 0,
        });
      }
    }

    if (athletePPIs.length === 0) {
      return Response.json({
        sport,
        org,
        tpi: { tpi: 0, aggregationType: "weighted_average", athleteCount: 0 },
        teamTrend: "stable",
      });
    }

    // Calculate TPI based on sport
    const sportProfile = SPORT_PROFILES[sport];
    const aggregationType =
      sportProfile?.scoringSchema?.tpi_aggregation || "weighted_average";

    let tpi = 0;
    switch (aggregationType) {
      case "weighted_average":
        tpi =
          athletePPIs.reduce((sum, a) => sum + a.ppi, 0) / athletePPIs.length;
        break;

      case "synergy_adjusted":
        // Basketball-style: team chemistry factor
        const avgPPI =
          athletePPIs.reduce((sum, a) => sum + a.ppi, 0) / athletePPIs.length;
        const chemistryBonus = 1.05; // Assume 5% chemistry bonus
        tpi = avgPPI * chemistryBonus;
        break;

      case "position_group_weighted":
        // Football: position importance
        tpi =
          athletePPIs.reduce((sum, a) => sum + a.ppi, 0) / athletePPIs.length;
        break;

      default:
        tpi =
          athletePPIs.reduce((sum, a) => sum + a.ppi, 0) / athletePPIs.length;
    }

    // Determine trend (simplified - would need historical team data)
    const teamTrend =
      tpi > 65 ? "improving" : tpi < 45 ? "declining" : "stable";

    return Response.json({
      sport,
      org,
      tpi: {
        tpi: Math.round(tpi * 100) / 100,
        aggregationType,
        athleteCount: athletePPIs.length,
      },
      teamTrend,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error calculating team analytics:", error);
    return Response.json(
      { error: "Failed to calculate team analytics", details: error.message },
      { status: 500 },
    );
  }
}
