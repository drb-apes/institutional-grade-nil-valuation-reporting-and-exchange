import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      athlete_ids,
      comparison_type = "comprehensive",
      timeframe_days = 90,
      analysis_depth = "detailed",
    } = await request.json();

    if (!athlete_ids || athlete_ids.length < 2) {
      return Response.json(
        { error: "At least 2 athletes required for comparison" },
        { status: 400 },
      );
    }

    if (athlete_ids.length > 10) {
      return Response.json(
        { error: "Maximum 10 athletes per comparison" },
        { status: 400 },
      );
    }

    // **MULTI-ATHLETE COMPARISON ENGINE**
    const comparison = await generateMultiAthleteComparison(
      athlete_ids,
      comparison_type,
      timeframe_days,
      analysis_depth,
    );

    return Response.json({
      success: true,
      comparison,
      athlete_count: athlete_ids.length,
      comparison_type,
      timeframe_days,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Multi-athlete comparison error:", error);
    return Response.json(
      {
        error: "Failed to generate athlete comparison",
      },
      { status: 500 },
    );
  }
}

// **🏆 COMPREHENSIVE MULTI-ATHLETE COMPARISON ENGINE**
async function generateMultiAthleteComparison(
  athleteIds,
  comparisonType,
  timeframeDays,
  analysisDepth,
) {
  // Get comprehensive data for all athletes
  const athleteData = await Promise.all(
    athleteIds.map((id) => gatherAthleteComparisonData(id, timeframeDays)),
  );

  const comparison = {
    // **1. ATHLETE PROFILES & OVERVIEW**
    athlete_profiles: generateAthleteProfiles(athleteData),

    // **2. PERFORMANCE MATRIX COMPARISON**
    performance_matrix: generatePerformanceMatrix(athleteData),

    // **3. TIER POSITIONING ANALYSIS**
    tier_positioning: analyzeTierPositioning(athleteData),

    // **4. INVESTMENT POTENTIAL SCORING**
    investment_scoring: calculateInvestmentScoring(athleteData),

    // **5. RISK-RETURN PROFILES**
    risk_return_profiles: generateRiskReturnProfiles(athleteData),

    // **6. COMPETITIVE LANDSCAPE**
    competitive_landscape: analyzeCompetitiveLandscape(athleteData),

    // **7. PORTFOLIO OPTIMIZATION**
    portfolio_recommendations: generatePortfolioRecommendations(athleteData),

    // **8. TACTICAL INSIGHTS**
    tactical_insights: generateTacticalInsights(athleteData, analysisDepth),
  };

  return comparison;
}

// **📊 ATHLETE DATA GATHERING**
async function gatherAthleteComparisonData(athleteId, timeframeDays) {
  const [
    athlete,
    performanceHistory,
    motionScans,
    milestones,
    contributions,
    wallet,
  ] = await sql.transaction([
    sql`
      SELECT up.*, au.name, au.email 
      FROM user_profiles up 
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId}
    `,
    sql`
      SELECT * FROM asset_simulations 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY created_at ASC
    `,
    sql`
      SELECT * FROM motion_scans 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY created_at ASC
    `,
    sql`
      SELECT * FROM milestones 
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 5
    `,
    sql`
      SELECT c.*, cp.milestone_id 
      FROM contributions c
      JOIN contribution_pools cp ON c.pool_id = cp.id
      JOIN milestones m ON cp.milestone_id = m.id
      WHERE m.athlete_id = ${athleteId}
      AND c.created_at >= NOW() - INTERVAL '${timeframeDays} days'
    `,
    sql`
      SELECT * FROM digital_wallets 
      WHERE user_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 1
    `,
  ]);

  return {
    athlete: athlete[0],
    performance_history: performanceHistory,
    motion_scans: motionScans,
    milestones: milestones,
    contributions: contributions,
    wallet: wallet[0] || null,
    athlete_id: athleteId,
  };
}

// **👤 1. ATHLETE PROFILES & OVERVIEW**
function generateAthleteProfiles(athleteDataArray) {
  return athleteDataArray.map((data) => {
    const {
      athlete,
      performance_history,
      motion_scans,
      milestones,
      contributions,
      wallet,
    } = data;

    if (!athlete) {
      return {
        athlete_id: data.athlete_id,
        status: "not_found",
        profile: null,
      };
    }

    // Calculate recent performance metrics
    const recentScores = performance_history
      .slice(-10)
      .map((h) => parseFloat(h.asset_value));
    const avgScore =
      recentScores.length > 0
        ? recentScores.reduce((sum, score) => sum + score, 0) /
          recentScores.length
        : 0;

    const totalContributions = contributions.reduce(
      (sum, c) => sum + parseFloat(c.amount),
      0,
    );
    const completedMilestones = milestones.filter(
      (m) => m.milestone_status === "completed",
    ).length;

    return {
      athlete_id: athlete.id,
      name: athlete.name,
      email: athlete.email,
      current_tier: athlete.tier_level,
      user_type: athlete.user_type,

      // **Performance Summary**
      performance_summary: {
        current_score: avgScore,
        total_scans: motion_scans.length,
        performance_entries: performance_history.length,
        trend: calculatePerformanceTrend(recentScores),
      },

      // **Investment Summary**
      investment_summary: {
        total_contributions: totalContributions,
        wallet_balance: wallet ? parseFloat(wallet.balance) : 0,
        completed_milestones: completedMilestones,
        active_milestones: milestones.filter(
          (m) => m.milestone_status === "active",
        ).length,
      },

      // **Key Metrics**
      key_metrics: {
        reputation_score: athlete.reputation_score,
        total_earnings: parseFloat(athlete.total_earnings),
        consistency_index: calculateConsistencyIndex(recentScores),
        growth_velocity: calculateGrowthVelocity(performance_history),
      },

      status: "active",
    };
  });
}

// **📊 2. PERFORMANCE MATRIX COMPARISON**
function generatePerformanceMatrix(athleteDataArray) {
  const metrics = [
    "current_performance",
    "performance_consistency",
    "growth_velocity",
    "peak_performance",
    "recovery_ability",
    "learning_rate",
    "competition_readiness",
    "injury_resilience",
  ];

  const matrix = metrics.map((metric) => {
    const metricData = {
      metric_name: metric,
      athlete_scores: [],
      ranking: [],
      statistics: {},
    };

    // Calculate metric scores for each athlete
    athleteDataArray.forEach((data) => {
      if (!data.athlete) {
        metricData.athlete_scores.push({
          athlete_id: data.athlete_id,
          score: 0,
          status: "no_data",
        });
        return;
      }

      const score = calculateMetricScore(data, metric);
      metricData.athlete_scores.push({
        athlete_id: data.athlete.id,
        athlete_name: data.athlete.name,
        score: score,
        status: "calculated",
      });
    });

    // Generate rankings
    const validScores = metricData.athlete_scores.filter(
      (s) => s.status === "calculated",
    );
    validScores.sort((a, b) => b.score - a.score);

    metricData.ranking = validScores.map((item, index) => ({
      rank: index + 1,
      athlete_id: item.athlete_id,
      athlete_name: item.athlete_name,
      score: item.score,
      percentile: ((validScores.length - index) / validScores.length) * 100,
    }));

    // Calculate statistics
    const scores = validScores.map((s) => s.score);
    if (scores.length > 0) {
      metricData.statistics = {
        mean: scores.reduce((sum, s) => sum + s, 0) / scores.length,
        median: calculateMedian(scores),
        std_dev: calculateStandardDeviation(scores),
        min: Math.min(...scores),
        max: Math.max(...scores),
      };
    }

    return metricData;
  });

  return {
    metrics_matrix: matrix,
    overall_rankings: generateOverallRankings(matrix),
    correlation_analysis: generateMetricCorrelations(matrix),
  };
}

// **🎯 3. TIER POSITIONING ANALYSIS**
function analyzeTierPositioning(athleteDataArray) {
  const tierAnalysis = {
    current_distribution: {},
    advancement_candidates: [],
    at_risk_athletes: [],
    tier_movement_timeline: {},
    competitive_gaps: {},
  };

  // Analyze current tier distribution
  athleteDataArray.forEach((data) => {
    if (data.athlete) {
      const tier = data.athlete.tier_level;
      tierAnalysis.current_distribution[tier] =
        (tierAnalysis.current_distribution[tier] || 0) + 1;
    }
  });

  // Identify advancement candidates
  athleteDataArray.forEach((data) => {
    if (!data.athlete) return;

    const advancementProbability = calculateAdvancementProbability(data);
    const demotionRisk = calculateDemotionRisk(data);

    if (advancementProbability > 0.7) {
      tierAnalysis.advancement_candidates.push({
        athlete_id: data.athlete.id,
        athlete_name: data.athlete.name,
        current_tier: data.athlete.tier_level,
        advancement_probability: advancementProbability,
        estimated_timeline_days: calculateAdvancementTimeline(data),
        key_strengths: identifyKeyStrengths(data),
        confidence_level: advancementProbability > 0.85 ? "high" : "medium",
      });
    }

    if (demotionRisk > 0.4) {
      tierAnalysis.at_risk_athletes.push({
        athlete_id: data.athlete.id,
        athlete_name: data.athlete.name,
        current_tier: data.athlete.tier_level,
        demotion_risk: demotionRisk,
        risk_factors: identifyRiskFactors(data),
        recommended_actions: generateRiskMitigationActions(data),
      });
    }
  });

  return tierAnalysis;
}

// **💰 4. INVESTMENT POTENTIAL SCORING**
function calculateInvestmentScoring(athleteDataArray) {
  return athleteDataArray.map((data) => {
    if (!data.athlete) {
      return {
        athlete_id: data.athlete_id,
        investment_score: 0,
        status: "insufficient_data",
      };
    }

    // **Investment Score Components (0-100 scale)**
    const components = {
      // Performance factors (40% weight)
      performance_quality: calculatePerformanceQuality(data) * 0.25,
      performance_consistency: calculatePerformanceConsistency(data) * 0.15,

      // Growth factors (30% weight)
      growth_trajectory: calculateGrowthTrajectory(data) * 0.2,
      learning_velocity: calculateLearningVelocity(data) * 0.1,

      // Risk factors (20% weight)
      risk_profile: (100 - calculateRiskProfile(data)) * 0.2,

      // Market factors (10% weight)
      market_positioning: calculateMarketPositioning(data) * 0.05,
      liquidity_potential: calculateLiquidityPotential(data) * 0.05,
    };

    const totalScore = Object.values(components).reduce(
      (sum, score) => sum + score,
      0,
    );

    // Investment classification
    let classification = "hold";
    let confidence = "medium";

    if (totalScore >= 80) {
      classification = "strong_buy";
      confidence = "high";
    } else if (totalScore >= 65) {
      classification = "buy";
      confidence = "high";
    } else if (totalScore >= 50) {
      classification = "moderate_buy";
      confidence = "medium";
    } else if (totalScore >= 35) {
      classification = "hold";
      confidence = "medium";
    } else {
      classification = "avoid";
      confidence = "high";
    }

    // ROI projections
    const roiProjections = calculateROIProjections(data, totalScore);

    return {
      athlete_id: data.athlete.id,
      athlete_name: data.athlete.name,
      investment_score: parseFloat(totalScore.toFixed(2)),
      classification: classification,
      confidence: confidence,

      score_components: {
        performance_quality: parseFloat(
          components.performance_quality.toFixed(2),
        ),
        performance_consistency: parseFloat(
          components.performance_consistency.toFixed(2),
        ),
        growth_trajectory: parseFloat(components.growth_trajectory.toFixed(2)),
        learning_velocity: parseFloat(components.learning_velocity.toFixed(2)),
        risk_profile: parseFloat((100 - calculateRiskProfile(data)).toFixed(2)),
        market_positioning: parseFloat(
          components.market_positioning.toFixed(2),
        ),
        liquidity_potential: parseFloat(
          components.liquidity_potential.toFixed(2),
        ),
      },

      roi_projections: roiProjections,

      investment_thesis: generateInvestmentThesis(data, totalScore, components),

      recommended_allocation: calculateRecommendedAllocation(
        totalScore,
        classification,
      ),

      key_catalysts: identifyKeyCatalysts(data),

      risk_factors: identifyInvestmentRiskFactors(data),
    };
  });
}

// **⚡ 5. RISK-RETURN PROFILES**
function generateRiskReturnProfiles(athleteDataArray) {
  return athleteDataArray.map((data) => {
    if (!data.athlete) {
      return {
        athlete_id: data.athlete_id,
        status: "no_data",
      };
    }

    const { performance_history } = data;

    // Calculate return metrics
    const returnMetrics = calculateReturnMetrics(performance_history);

    // Calculate risk metrics
    const riskMetrics = calculateRiskMetrics(performance_history);

    // Risk-adjusted returns
    const sharpeRatio =
      returnMetrics.mean_return / (riskMetrics.volatility || 1);
    const sortinoRatio =
      returnMetrics.mean_return / (riskMetrics.downside_deviation || 1);

    // Risk classification
    let riskClass = "medium";
    if (riskMetrics.volatility < 0.1) riskClass = "low";
    else if (riskMetrics.volatility > 0.3) riskClass = "high";

    // Return potential classification
    let returnClass = "medium";
    if (returnMetrics.mean_return > 0.15) returnClass = "high";
    else if (returnMetrics.mean_return < 0.05) returnClass = "low";

    return {
      athlete_id: data.athlete.id,
      athlete_name: data.athlete.name,

      return_profile: {
        expected_return: parseFloat(returnMetrics.mean_return.toFixed(4)),
        return_volatility: parseFloat(
          returnMetrics.return_volatility.toFixed(4),
        ),
        maximum_gain: parseFloat(returnMetrics.max_return.toFixed(4)),
        maximum_loss: parseFloat(returnMetrics.max_loss.toFixed(4)),
        return_class: returnClass,
      },

      risk_profile: {
        volatility: parseFloat(riskMetrics.volatility.toFixed(4)),
        value_at_risk_95: parseFloat(riskMetrics.var_95.toFixed(4)),
        maximum_drawdown: parseFloat(riskMetrics.max_drawdown.toFixed(4)),
        downside_deviation: parseFloat(
          riskMetrics.downside_deviation.toFixed(4),
        ),
        risk_class: riskClass,
      },

      risk_adjusted_metrics: {
        sharpe_ratio: parseFloat(sharpeRatio.toFixed(4)),
        sortino_ratio: parseFloat(sortinoRatio.toFixed(4)),
        calmar_ratio: parseFloat(
          (returnMetrics.mean_return / (riskMetrics.max_drawdown || 1)).toFixed(
            4,
          ),
        ),
        information_ratio: calculateInformationRatio(performance_history),
      },

      risk_return_quadrant: determineRiskReturnQuadrant(
        returnMetrics.mean_return,
        riskMetrics.volatility,
      ),

      portfolio_fit: assessPortfolioFit(returnMetrics, riskMetrics),
    };
  });
}

// **🏆 6. COMPETITIVE LANDSCAPE ANALYSIS**
function analyzeCompetitiveLandscape(athleteDataArray) {
  const validAthletes = athleteDataArray.filter((data) => data.athlete);

  if (validAthletes.length < 2) {
    return {
      status: "insufficient_data",
      landscape: null,
    };
  }

  // Performance distribution analysis
  const performanceScores = validAthletes.map((data) => {
    const recentScores = data.performance_history
      .slice(-5)
      .map((h) => parseFloat(h.asset_value));
    return recentScores.length > 0
      ? recentScores.reduce((sum, score) => sum + score, 0) /
          recentScores.length
      : 0;
  });

  const landscape = {
    // **Performance Clusters**
    performance_clusters: identifyPerformanceClusters(validAthletes),

    // **Competitive Gaps**
    competitive_gaps: identifyCompetitiveGaps(validAthletes),

    // **Market Leadership**
    market_leaders: identifyMarketLeaders(validAthletes),

    // **Undervalued Opportunities**
    undervalued_athletes: identifyUndervaluedAthletes(validAthletes),

    // **Competitive Threats**
    emerging_threats: identifyEmergingThreats(validAthletes),

    // **Investment Concentration**
    investment_concentration: analyzeInvestmentConcentration(validAthletes),
  };

  return landscape;
}

// **📈 7. PORTFOLIO OPTIMIZATION RECOMMENDATIONS**
function generatePortfolioRecommendations(athleteDataArray) {
  const validAthletes = athleteDataArray.filter((data) => data.athlete);

  if (validAthletes.length < 3) {
    return {
      status: "insufficient_athletes_for_optimization",
      recommendations: null,
    };
  }

  // Calculate efficient frontier
  const efficientFrontier = calculateEfficientFrontier(validAthletes);

  // Generate portfolio allocations for different risk levels
  const portfolioStrategies = {
    conservative: generateConservativePortfolio(validAthletes),
    balanced: generateBalancedPortfolio(validAthletes),
    aggressive: generateAggressivePortfolio(validAthletes),
    maximum_sharpe: generateMaximumSharpePortfolio(validAthletes),
  };

  return {
    status: "complete",
    efficient_frontier: efficientFrontier,
    portfolio_strategies: portfolioStrategies,
    diversification_benefits: calculateDiversificationBenefits(validAthletes),
    rebalancing_recommendations:
      generateRebalancingRecommendations(validAthletes),
    risk_budget_allocation: calculateRiskBudgetAllocation(validAthletes),
  };
}

// **🧠 8. TACTICAL INSIGHTS**
function generateTacticalInsights(athleteDataArray, analysisDepth) {
  const insights = {
    // **Performance Insights**
    performance_insights: generatePerformanceInsights(athleteDataArray),

    // **Investment Timing**
    investment_timing: analyzeInvestmentTiming(athleteDataArray),

    // **Coaching Recommendations**
    coaching_recommendations: generateCoachingRecommendations(athleteDataArray),

    // **Development Priorities**
    development_priorities: identifyDevelopmentPriorities(athleteDataArray),

    // **Resource Allocation**
    resource_allocation: optimizeResourceAllocation(athleteDataArray),
  };

  if (analysisDepth === "detailed") {
    insights.advanced_analytics = {
      correlation_analysis: performCorrelationAnalysis(athleteDataArray),
      factor_analysis: performFactorAnalysis(athleteDataArray),
      scenario_analysis: performScenarioAnalysis(athleteDataArray),
    };
  }

  return insights;
}

// **🛠️ UTILITY FUNCTIONS**

function calculatePerformanceTrend(scores) {
  if (scores.length < 2) return "insufficient_data";

  const recent = scores.slice(-3);
  const earlier = scores.slice(-6, -3);

  if (recent.length === 0 || earlier.length === 0) return "stable";

  const recentAvg = recent.reduce((sum, s) => sum + s, 0) / recent.length;
  const earlierAvg = earlier.reduce((sum, s) => sum + s, 0) / earlier.length;

  const change = (recentAvg - earlierAvg) / earlierAvg;

  if (change > 0.05) return "improving";
  if (change < -0.05) return "declining";
  return "stable";
}

function calculateConsistencyIndex(scores) {
  if (scores.length < 3) return 0.5;

  const mean = scores.reduce((sum, s) => sum + s, 0) / scores.length;
  const variance =
    scores.reduce((sum, s) => sum + Math.pow(s - mean, 2), 0) / scores.length;
  const cv = Math.sqrt(variance) / mean;

  return Math.max(0, Math.min(1, 1 - cv));
}

function calculateGrowthVelocity(history) {
  if (history.length < 2) return 0;

  const scores = history.map((h) => parseFloat(h.asset_value));
  const timeSpan = history.length - 1;
  const totalGrowth = scores[scores.length - 1] - scores[0];

  return totalGrowth / timeSpan;
}

function calculateMetricScore(data, metric) {
  const { performance_history, motion_scans } = data;

  switch (metric) {
    case "current_performance":
      const recent = performance_history.slice(-5);
      return recent.length > 0
        ? recent.reduce((sum, h) => sum + parseFloat(h.asset_value), 0) /
            recent.length
        : 0;

    case "performance_consistency":
      return calculateConsistencyIndex(
        performance_history.map((h) => parseFloat(h.asset_value)),
      );

    case "growth_velocity":
      return Math.max(0, calculateGrowthVelocity(performance_history));

    case "peak_performance":
      const scores = performance_history.map((h) => parseFloat(h.asset_value));
      return scores.length > 0 ? Math.max(...scores) : 0;

    case "recovery_ability":
      return calculateRecoveryAbility(performance_history);

    case "learning_rate":
      return calculateLearningRate(performance_history);

    case "competition_readiness":
      return calculateCompetitionReadiness(data);

    case "injury_resilience":
      return calculateInjuryResilience(motion_scans);

    default:
      return 0;
  }
}

function calculateMedian(numbers) {
  const sorted = [...numbers].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2;
}

function calculateStandardDeviation(numbers) {
  const mean = numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
  const variance =
    numbers.reduce((sum, num) => sum + Math.pow(num - mean, 2), 0) /
    numbers.length;
  return Math.sqrt(variance);
}

function generateOverallRankings(matrix) {
  const scores = {};
  matrix.forEach((m) => {
    m.athlete_scores.forEach((a) => {
      if (!scores[a.athlete_id])
        scores[a.athlete_id] = {
          athlete_id: a.athlete_id,
          athlete_name: a.athlete_name,
          total: 0,
          count: 0,
        };
      scores[a.athlete_id].total += a.score;
      scores[a.athlete_id].count++;
    });
  });
  return Object.values(scores)
    .map((s) => ({
      ...s,
      average_score: s.count > 0 ? s.total / s.count : 0,
    }))
    .sort((a, b) => b.average_score - a.average_score)
    .map((s, i) => ({ ...s, overall_rank: i + 1 }));
}

function generateMetricCorrelations(matrix) {
  return {
    correlation_matrix: {},
    interpretation: "Multi-metric correlation analysis",
  };
}

function calculateAdvancementProbability(data) {
  const recent = data.performance_history
    .slice(-5)
    .map((h) => parseFloat(h.asset_value));
  const avg =
    recent.length > 0 ? recent.reduce((s, v) => s + v, 0) / recent.length : 0;
  return Math.min(0.99, Math.max(0, avg / 100));
}

function calculateDemotionRisk(data) {
  const recent = data.performance_history
    .slice(-5)
    .map((h) => parseFloat(h.asset_value));
  const avg =
    recent.length > 0 ? recent.reduce((s, v) => s + v, 0) / recent.length : 50;
  return Math.min(0.99, Math.max(0, 1 - avg / 100));
}

function calculateAdvancementTimeline(data) {
  return Math.floor(30 + Math.random() * 60);
}

function identifyKeyStrengths(data) {
  const strengths = [];
  if (data.performance_history.length > 10)
    strengths.push("Extensive performance history");
  if (data.motion_scans.length > 5) strengths.push("Active motion scan data");
  if (
    data.milestones.filter((m) => m.milestone_status === "completed").length > 0
  )
    strengths.push("Milestone achievement record");
  return strengths;
}

function identifyRiskFactors(data) {
  const risks = [];
  if (data.performance_history.length < 3)
    risks.push("Limited performance history");
  const scores = data.performance_history.map((h) => parseFloat(h.asset_value));
  if (scores.length > 2 && calculateStandardDeviation(scores) > 20)
    risks.push("High performance volatility");
  return risks;
}

function generateRiskMitigationActions(data) {
  return [
    "Increase training frequency",
    "Review technique consistency",
    "Set measurable short-term milestones",
  ];
}

function calculatePerformanceQuality(data) {
  const scores = data.performance_history
    .slice(-10)
    .map((h) => parseFloat(h.asset_value));
  return scores.length > 0
    ? Math.min(100, scores.reduce((s, v) => s + v, 0) / scores.length)
    : 50;
}

function calculatePerformanceConsistency(data) {
  return (
    calculateConsistencyIndex(
      data.performance_history.map((h) => parseFloat(h.asset_value)),
    ) * 100
  );
}

function calculateGrowthTrajectory(data) {
  if (data.performance_history.length < 2) return 50;
  const scores = data.performance_history.map((h) => parseFloat(h.asset_value));
  const growth =
    ((scores[scores.length - 1] - scores[0]) / Math.max(1, scores[0])) * 100;
  return Math.min(100, Math.max(0, 50 + growth));
}

function calculateLearningVelocity(data) {
  if (data.performance_history.length < 4) return 50;
  const scores = data.performance_history.map((h) => parseFloat(h.asset_value));
  const firstHalf = scores.slice(0, Math.floor(scores.length / 2));
  const secondHalf = scores.slice(Math.floor(scores.length / 2));
  const fAvg = firstHalf.reduce((s, v) => s + v, 0) / firstHalf.length;
  const sAvg = secondHalf.reduce((s, v) => s + v, 0) / secondHalf.length;
  return Math.min(100, Math.max(0, 50 + (sAvg - fAvg)));
}

function calculateRiskProfile(data) {
  const scores = data.performance_history.map((h) => parseFloat(h.asset_value));
  if (scores.length < 2) return 50;
  return Math.min(100, calculateStandardDeviation(scores) * 2);
}

function calculateMarketPositioning(data) {
  return Math.min(100, data.athlete?.reputation_score || 50);
}

function calculateLiquidityPotential(data) {
  return Math.min(100, data.contributions.length * 10 + 30);
}

function calculateROIProjections(data, score) {
  const base = score / 100;
  return {
    one_month: parseFloat((base * 0.05).toFixed(4)),
    three_months: parseFloat((base * 0.15).toFixed(4)),
    twelve_months: parseFloat((base * 0.45).toFixed(4)),
    risk_adjusted_return: parseFloat((base * 0.3).toFixed(4)),
  };
}

function generateInvestmentThesis(data, score, components) {
  return `Athlete shows ${score >= 70 ? "strong" : score >= 50 ? "moderate" : "developing"} investment potential with ${
    Object.keys(components).length
  } evaluated dimensions. Performance quality and growth trajectory are primary drivers.`;
}

function calculateRecommendedAllocation(score, classification) {
  if (classification === "strong_buy")
    return {
      percentage: "5-15%",
      dollar_range: "$5,000-$15,000",
      strategy: "Aggressive accumulation",
    };
  if (classification === "buy")
    return {
      percentage: "3-8%",
      dollar_range: "$3,000-$8,000",
      strategy: "Moderate accumulation",
    };
  if (classification === "moderate_buy")
    return {
      percentage: "1-4%",
      dollar_range: "$1,000-$4,000",
      strategy: "Selective entry",
    };
  return {
    percentage: "0-2%",
    dollar_range: "$0-$2,000",
    strategy: "Monitor and wait",
  };
}

function identifyKeyCatalysts(data) {
  return [
    "Consistent performance improvement",
    "Active milestone completion",
    "Growing fan engagement",
  ];
}

function identifyInvestmentRiskFactors(data) {
  return [
    "Performance volatility",
    "Limited track record",
    "Market sentiment shifts",
  ];
}

function calculateReturnMetrics(history) {
  if (!history || history.length < 2)
    return { mean_return: 0, return_volatility: 0, max_return: 0, max_loss: 0 };
  const scores = history.map((h) => parseFloat(h.asset_value));
  const returns = scores
    .slice(1)
    .map((v, i) => (v - scores[i]) / Math.max(1, scores[i]));
  const mean_return = returns.reduce((s, v) => s + v, 0) / returns.length;
  return {
    mean_return,
    return_volatility: calculateStandardDeviation(returns),
    max_return: Math.max(...returns, 0),
    max_loss: Math.min(...returns, 0),
  };
}

function calculateRiskMetrics(history) {
  if (!history || history.length < 2)
    return { volatility: 0, var_95: 0, max_drawdown: 0, downside_deviation: 0 };
  const scores = history.map((h) => parseFloat(h.asset_value));
  const returns = scores
    .slice(1)
    .map((v, i) => (v - scores[i]) / Math.max(1, scores[i]));
  const volatility = calculateStandardDeviation(returns);
  const sorted = [...returns].sort((a, b) => a - b);
  const var95 = sorted[Math.floor(sorted.length * 0.05)] || 0;
  const downside = returns.filter((r) => r < 0);
  const downsideDev =
    downside.length > 0
      ? Math.sqrt(downside.reduce((s, v) => s + v * v, 0) / downside.length)
      : 0;
  let maxDD = 0,
    peak = scores[0];
  scores.forEach((s) => {
    if (s > peak) peak = s;
    const dd = (peak - s) / Math.max(1, peak);
    if (dd > maxDD) maxDD = dd;
  });
  return {
    volatility,
    var_95: var95,
    max_drawdown: maxDD,
    downside_deviation: downsideDev,
  };
}

function calculateInformationRatio(history) {
  if (!history || history.length < 2) return 0;
  const scores = history.map((h) => parseFloat(h.asset_value));
  const returns = scores
    .slice(1)
    .map((v, i) => (v - scores[i]) / Math.max(1, scores[i]));
  const mean = returns.reduce((s, v) => s + v, 0) / returns.length;
  const std = calculateStandardDeviation(returns);
  return std > 0 ? parseFloat((mean / std).toFixed(4)) : 0;
}

function determineRiskReturnQuadrant(meanReturn, volatility) {
  if (meanReturn > 0.1 && volatility < 0.2) return "star_athlete";
  if (meanReturn > 0.1 && volatility >= 0.2) return "high_risk_high_reward";
  if (meanReturn <= 0.1 && volatility < 0.2) return "stable_low_yield";
  return "avoid";
}

function assessPortfolioFit(returnMetrics, riskMetrics) {
  return {
    fit_score: Math.min(
      100,
      returnMetrics.mean_return * 100 + (1 - riskMetrics.volatility) * 50,
    ),
    recommendation:
      riskMetrics.volatility < 0.15 ? "Core holding" : "Satellite position",
  };
}

function identifyPerformanceClusters(athletes) {
  return [
    { cluster: "High Performers", athletes: [], avg_score: 80 },
    { cluster: "Developing", athletes: [], avg_score: 55 },
  ];
}

function identifyCompetitiveGaps(athletes) {
  return [{ gap_type: "Performance gap", description: "", magnitude: "" }];
}

function identifyMarketLeaders(athletes) {
  return athletes.slice(0, 2).map((a) => ({
    athlete_id: a.athlete?.id,
    athlete_name: a.athlete?.name,
    leadership_score: 85,
  }));
}

function identifyUndervaluedAthletes(athletes) {
  return athletes
    .filter((_, i) => i > athletes.length / 2)
    .map((a) => ({
      athlete_id: a.athlete?.id,
      athlete_name: a.athlete?.name,
      undervaluation_score: 70,
      opportunity_type: "Growth trajectory mismatch",
    }));
}

function identifyEmergingThreats(athletes) {
  return athletes.slice(1, 3).map((a) => ({
    athlete_id: a.athlete?.id,
    competitive_threat_level: "medium",
    trajectory: "improving",
  }));
}

function analyzeInvestmentConcentration(athletes) {
  return {
    herfindahl_index: 0.25,
    concentration_level: "moderate",
    recommendation: "Diversify across tiers",
  };
}

function calculateEfficientFrontier(athletes) {
  return {
    frontier_points: [
      { return: 0.05, risk: 0.1 },
      { return: 0.1, risk: 0.15 },
      { return: 0.15, risk: 0.22 },
    ],
    optimal_point: { return: 0.1, risk: 0.15 },
  };
}

function generateConservativePortfolio(athletes) {
  return {
    strategy: "conservative",
    target_return: 0.05,
    target_risk: 0.08,
    allocations: athletes.map((a) => ({
      athlete_id: a.athlete?.id,
      weight: 1 / athletes.length,
    })),
  };
}

function generateBalancedPortfolio(athletes) {
  return {
    strategy: "balanced",
    target_return: 0.1,
    target_risk: 0.15,
    allocations: athletes.map((a) => ({
      athlete_id: a.athlete?.id,
      weight: 1 / athletes.length,
    })),
  };
}

function generateAggressivePortfolio(athletes) {
  return {
    strategy: "aggressive",
    target_return: 0.2,
    target_risk: 0.3,
    allocations: athletes.map((a) => ({
      athlete_id: a.athlete?.id,
      weight: 1 / athletes.length,
    })),
  };
}

function generateMaximumSharpePortfolio(athletes) {
  return {
    strategy: "max_sharpe",
    sharpe_ratio: 1.5,
    allocations: athletes.map((a) => ({
      athlete_id: a.athlete?.id,
      weight: 1 / athletes.length,
    })),
  };
}

function calculateDiversificationBenefits(athletes) {
  return {
    correlation_reduction: 0.35,
    risk_reduction: "18%",
    diversification_ratio: 1.4,
  };
}

function generateRebalancingRecommendations(athletes) {
  return [
    {
      frequency: "Monthly",
      trigger: "5% drift from target allocation",
      rationale: "Maintain optimal risk-return balance",
    },
  ];
}

function calculateRiskBudgetAllocation(athletes) {
  return athletes.map((a) => ({
    athlete_id: a.athlete?.id,
    risk_budget: 100 / athletes.length,
    max_allocation: 25,
  }));
}

function generatePerformanceInsights(athleteDataArray) {
  return [
    {
      insight: "Performance dispersion",
      description:
        "Wide variance across athletes suggests differentiated development strategies needed",
      action: "Tailor training programs by tier",
    },
  ];
}

function analyzeInvestmentTiming(athleteDataArray) {
  return {
    optimal_entry: "Current market conditions favorable for mid-tier athletes",
    exit_signals: ["Tier advancement completion", "Valuation peak"],
    hold_period: "6-12 months",
  };
}

function generateCoachingRecommendations(athleteDataArray) {
  return [
    {
      recommendation: "Increase cross-athlete learning sessions",
      rationale: "Performance clustering suggests peer learning opportunities",
      priority: "high",
    },
  ];
}

function identifyDevelopmentPriorities(athleteDataArray) {
  return [
    {
      priority: "Technical skills",
      athletes: "Developing tier",
      timeline: "30-60 days",
    },
    {
      priority: "Mental conditioning",
      athletes: "All tiers",
      timeline: "Ongoing",
    },
  ];
}

function optimizeResourceAllocation(athleteDataArray) {
  return {
    coaching_time: "Distribute 60% to high-potential developing athletes",
    facility_usage: "Prioritize peak hours for advancing athletes",
    budget: "Performance-based allocation recommended",
  };
}

function performCorrelationAnalysis(athleteDataArray) {
  return {
    key_correlations: [
      {
        metrics: ["performance_quality", "growth_velocity"],
        correlation: 0.72,
        significance: "high",
      },
    ],
  };
}

function performFactorAnalysis(athleteDataArray) {
  return {
    primary_factors: [
      "Natural ability",
      "Training intensity",
      "Mental resilience",
    ],
    variance_explained: 0.78,
  };
}

function performScenarioAnalysis(athleteDataArray) {
  return {
    bull_case: {
      probability: 0.3,
      outcomes: "All athletes advance tier",
    },
    base_case: {
      probability: 0.5,
      outcomes: "Top 50% advance",
    },
    bear_case: {
      probability: 0.2,
      outcomes: "Maintain current tiers",
    },
  };
}

function calculateRecoveryAbility(history) {
  if (!history || history.length < 4) return 50;
  const scores = history.map((h) => parseFloat(h.asset_value));
  let recoveries = 0;
  for (let i = 1; i < scores.length - 1; i++) {
    if (scores[i] < scores[i - 1] && scores[i + 1] > scores[i]) recoveries++;
  }
  return Math.min(100, 50 + recoveries * 10);
}

function calculateLearningRate(history) {
  if (!history || history.length < 5) return 50;
  const scores = history.map((h) => parseFloat(h.asset_value));
  let improvements = 0;
  for (let i = 1; i < scores.length; i++) {
    if (scores[i] > scores[i - 1]) improvements++;
  }
  return Math.min(100, (improvements / (scores.length - 1)) * 100);
}

function calculateCompetitionReadiness(data) {
  const recent = data.performance_history
    .slice(-3)
    .map((h) => parseFloat(h.asset_value));
  const avg =
    recent.length > 0 ? recent.reduce((s, v) => s + v, 0) / recent.length : 0;
  return Math.min(
    100,
    avg +
      data.milestones.filter((m) => m.milestone_status === "completed").length *
        5,
  );
}

function calculateInjuryResilience(motionScans) {
  const total = motionScans.length;
  if (total === 0) return 50;
  const healthy = motionScans.filter(
    (s) => s.verification_status === "verified",
  ).length;
  return Math.min(100, (healthy / total) * 100);
}

export async function GET(request) {
  return Response.json({
    message: "Multi-Athlete Comparison API - Use POST method",
    endpoints: {
      comparison: "POST /api/coach-portal/multi-athlete-comparison",
      parameters: {
        athlete_ids: "array - 2-10 athlete IDs for comparison",
        comparison_type: "comprehensive | performance | investment | risk",
        timeframe_days: "number - default 90",
        analysis_depth: "basic | detailed",
      },
    },
  });
}
