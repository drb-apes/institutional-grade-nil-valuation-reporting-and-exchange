import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const action = url.searchParams.get("action");
    const athleteId = url.searchParams.get("athlete_id");

    // Validate required parameters
    if (!action) {
      return Response.json(
        { error: "Action parameter required" },
        { status: 400 },
      );
    }

    // Get or create user profile to ensure we have a valid athlete_id
    let userProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      // Create profile if it doesn't exist
      userProfile = await sql`
        INSERT INTO user_profiles (user_id, user_type, tier_level)
        VALUES (${session.user.id}, 'athlete', 1)
        RETURNING id
      `;
    }

    // Use the user's own profile ID if no specific athlete_id provided, or validate the provided one
    const targetAthleteId = athleteId || userProfile[0].id;

    // If a specific athlete_id was provided, verify it exists
    if (athleteId) {
      const athleteExists = await sql`
        SELECT id FROM user_profiles WHERE id = ${athleteId}
      `;
      if (athleteExists.length === 0) {
        return Response.json({ error: "Athlete not found" }, { status: 404 });
      }
    }

    if (action === "coaching_insights") {
      return await generateCoachingInsights(targetAthleteId);
    } else if (action === "performance_recommendations") {
      return await getPerformanceRecommendations(targetAthleteId);
    } else if (action === "training_plan") {
      return await generateAITrainingPlan(targetAthleteId);
    } else if (action === "real_time_feedback") {
      return await getRealTimeFeedback(targetAthleteId);
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("AI coaching integration error:", error);
    return Response.json(
      {
        error: "Failed to process coaching request",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { action, coaching_data = {} } = await request.json();

    // Validate required parameters
    if (!action) {
      return Response.json(
        { error: "Action parameter required" },
        { status: 400 },
      );
    }

    if (action === "create_training_session") {
      return await createAITrainingSession(coaching_data);
    } else if (action === "analyze_performance_data") {
      return await analyzePerformanceData(coaching_data);
    } else if (action === "generate_feedback") {
      return await generateAIFeedback(coaching_data);
    } else if (action === "update_training_plan") {
      return await updateTrainingPlan(coaching_data);
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Coaching action error:", error);
    return Response.json(
      {
        error: "Failed to process coaching action",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function generateCoachingInsights(athleteId) {
  if (!athleteId) {
    return Response.json({ error: "Athlete ID required" }, { status: 400 });
  }

  // Get athlete's recent performance data
  const [athleteData, recentScans, milestones, simulationData] =
    await sql.transaction([
      sql`
      SELECT u.*, up.tier_level, up.user_type
      FROM auth_users u
      JOIN user_profiles up ON u.id = up.user_id
      WHERE up.id = ${athleteId}
    `,
      sql`
      SELECT * FROM motion_scans
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 10
    `,
      sql`
      SELECT * FROM milestones
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 5
    `,
      sql`
      SELECT * FROM asset_simulations
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 5
    `,
    ]);

  if (athleteData.length === 0) {
    return Response.json({ error: "Athlete not found" }, { status: 404 });
  }

  const athlete = athleteData[0];
  const insights = await generateAdvancedCoachingInsights(
    athlete,
    recentScans,
    milestones,
    simulationData,
  );

  return Response.json({
    success: true,
    athlete_id: athleteId,
    coaching_insights: insights,
    generated_at: new Date().toISOString(),
  });
}

async function getPerformanceRecommendations(athleteId) {
  if (!athleteId) {
    return Response.json({ error: "Athlete ID required" }, { status: 400 });
  }

  const performanceData = await sql`
    SELECT 
      ms.*,
      asim.simulation_data,
      asim.valuation_factors
    FROM motion_scans ms
    LEFT JOIN asset_simulations asim ON ms.athlete_id = asim.athlete_id
    WHERE ms.athlete_id = ${athleteId}
    ORDER BY ms.created_at DESC
    LIMIT 5
  `;

  const recommendations = await generateAIRecommendations(performanceData);

  return Response.json({
    success: true,
    athlete_id: athleteId,
    recommendations: recommendations,
    priority_areas: identifyPriorityImprovementAreas(performanceData),
    next_steps: generateNextSteps(performanceData),
  });
}

async function generateAITrainingPlan(athleteId) {
  if (!athleteId) {
    return Response.json({ error: "Athlete ID required" }, { status: 400 });
  }

  const [athleteProfile, performanceHistory, currentMilestones] =
    await sql.transaction([
      sql`
      SELECT up.*, u.name, u.email
      FROM user_profiles up
      JOIN auth_users u ON up.user_id = u.id
      WHERE up.id = ${athleteId}
    `,
      sql`
      SELECT simulation_data, created_at
      FROM asset_simulations
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 10
    `,
      sql`
      SELECT * FROM milestones
      WHERE athlete_id = ${athleteId} AND milestone_status = 'active'
    `,
    ]);

  if (athleteProfile.length === 0) {
    return Response.json(
      { error: "Athlete profile not found" },
      { status: 404 },
    );
  }

  const trainingPlan = await createPersonalizedTrainingPlan(
    athleteProfile[0],
    performanceHistory,
    currentMilestones,
  );

  return Response.json({
    success: true,
    athlete_id: athleteId,
    training_plan: trainingPlan,
    plan_duration: "12_weeks",
    created_at: new Date().toISOString(),
  });
}

async function getRealTimeFeedback(athleteId) {
  if (!athleteId) {
    return Response.json({ error: "Athlete ID required" }, { status: 400 });
  }

  const latestScan = await sql`
    SELECT * FROM motion_scans
    WHERE athlete_id = ${athleteId}
    ORDER BY created_at DESC
    LIMIT 1
  `;

  if (latestScan.length === 0) {
    return Response.json(
      { error: "No recent motion scans found" },
      { status: 404 },
    );
  }

  const feedback = await generateRealTimeFeedback(latestScan[0]);

  return Response.json({
    success: true,
    athlete_id: athleteId,
    real_time_feedback: feedback,
    scan_timestamp: latestScan[0].created_at,
    feedback_generated_at: new Date().toISOString(),
  });
}

async function createAITrainingSession(coachingData) {
  const { athlete_id, session_type, duration, focus_areas, difficulty_level } =
    coachingData;

  const trainingSession = await generateTrainingSession({
    athlete_id,
    session_type,
    duration,
    focus_areas,
    difficulty_level,
  });

  // Store the training session
  const sessionRecord = await sql`
    INSERT INTO milestones (
      athlete_id,
      title,
      description,
      target_metrics,
      milestone_status
    ) VALUES (
      ${athlete_id},
      ${`AI Training Session: ${session_type}`},
      ${`AI-generated training session focusing on: ${focus_areas.join(", ")}`},
      ${JSON.stringify(trainingSession.target_metrics)},
      'active'
    )
    RETURNING *
  `;

  return Response.json({
    success: true,
    training_session: trainingSession,
    session_record: sessionRecord[0],
    estimated_completion_time: trainingSession.estimated_duration,
  });
}

async function analyzePerformanceData(coachingData) {
  const { athlete_id, performance_data, analysis_type } = coachingData;

  const analysis = await performAdvancedAnalysis(
    athlete_id,
    performance_data,
    analysis_type,
  );

  return Response.json({
    success: true,
    analysis_type: analysis_type,
    performance_analysis: analysis,
    confidence_score: analysis.confidence_level,
    recommendations: analysis.improvement_recommendations,
  });
}

async function generateAIFeedback(coachingData) {
  const { athlete_id, motion_data, session_context } = coachingData;

  const feedback = await createIntelligentFeedback(
    athlete_id,
    motion_data,
    session_context,
  );

  return Response.json({
    success: true,
    athlete_id: athlete_id,
    ai_feedback: feedback,
    feedback_type: "real_time_motion_analysis",
    actionable_insights: feedback.actionable_points,
  });
}

async function updateTrainingPlan(coachingData) {
  const { athlete_id, plan_updates, performance_feedback } = coachingData;

  const updatedPlan = await adaptTrainingPlan(
    athlete_id,
    plan_updates,
    performance_feedback,
  );

  return Response.json({
    success: true,
    athlete_id: athlete_id,
    updated_training_plan: updatedPlan,
    adaptation_reason: updatedPlan.adaptation_reason,
    plan_version: updatedPlan.version,
  });
}

// AI Coaching Implementation Functions

async function generateAdvancedCoachingInsights(
  athlete,
  recentScans,
  milestones,
  simulationData,
) {
  const sportType =
    simulationData.length > 0
      ? JSON.parse(simulationData[0].simulation_data)?.sport_type || "general"
      : "general";

  const insights = {
    athlete_profile: {
      name: athlete.name,
      tier_level: athlete.tier_level,
      user_type: athlete.user_type,
      sport_focus: sportType,
    },
    performance_trends: analyzePerformanceTrends(simulationData),
    technique_analysis: analyzeTechnique(recentScans, sportType),
    milestone_progress: analyzeMilestoneProgress(milestones),
    ai_recommendations: generateCoachingRecommendations(
      sportType,
      simulationData,
      recentScans,
    ),
    focus_areas: identifyCoachingFocusAreas(sportType, simulationData),
    training_adjustments: suggestTrainingAdjustments(athlete, simulationData),
  };

  return insights;
}

function analyzePerformanceTrends(simulationData) {
  if (simulationData.length === 0) {
    return {
      trend: "insufficient_data",
      recommendation: "Need more performance data",
    };
  }

  const scores = simulationData
    .map((sim) => {
      const data = JSON.parse(sim.simulation_data);
      return data.overall_score || 0;
    })
    .reverse(); // Chronological order

  const trend = calculateTrend(scores);
  const consistency = calculateConsistency(scores);

  return {
    trend_direction:
      trend > 0.05 ? "improving" : trend < -0.05 ? "declining" : "stable",
    trend_strength: Math.abs(trend),
    consistency_score: consistency,
    latest_score: scores[scores.length - 1],
    improvement_potential: assessImprovementPotential(scores),
  };
}

function analyzeTechnique(recentScans, sportType) {
  if (recentScans.length === 0) {
    return {
      analysis: "no_recent_scans",
      recommendation: "Schedule motion analysis session",
    };
  }

  const latestScan = recentScans[0];
  const scanData = JSON.parse(latestScan.scan_data);
  const aiScore = latestScan.ai_score;

  const technique = {
    overall_technique_score: Math.round(aiScore * 100),
    sport_specific_analysis: generateSportSpecificTechniqueAnalysis(
      sportType,
      scanData,
    ),
    improvement_areas: identifyTechniqueImprovements(scanData, sportType),
    verification_status: latestScan.verification_status,
  };

  return technique;
}

function analyzeMilestoneProgress(milestones) {
  if (milestones.length === 0) {
    return {
      status: "no_active_milestones",
      recommendation: "Set performance milestones",
    };
  }

  const activeMilestones = milestones.filter(
    (m) => m.milestone_status === "active",
  );
  const completedMilestones = milestones.filter(
    (m) => m.milestone_status === "completed",
  );

  return {
    active_count: activeMilestones.length,
    completed_count: completedMilestones.length,
    completion_rate:
      milestones.length > 0
        ? completedMilestones.length / milestones.length
        : 0,
    next_milestone: activeMilestones.length > 0 ? activeMilestones[0] : null,
    milestone_insights: generateMilestoneInsights(milestones),
  };
}

function generateCoachingRecommendations(
  sportType,
  simulationData,
  recentScans,
) {
  const recommendations = [];

  // Sport-specific recommendations
  switch (sportType) {
    case "wrestling":
    case "goalwrestling":
      recommendations.push(
        ...getWrestlingCoachingRecommendations(simulationData, recentScans),
      );
      break;
    case "rugby":
    case "soccer":
    case "basketball":
      recommendations.push(
        ...getTacticalSportsRecommendations(simulationData, recentScans),
      );
      break;
    case "tennis":
    case "pickleball":
      recommendations.push(
        ...getRacketSportsRecommendations(simulationData, recentScans),
      );
      break;
    case "american_football":
      recommendations.push(
        ...getAmericanFootballRecommendations(simulationData, recentScans),
      );
      break;
    default:
      recommendations.push(
        ...getGeneralCoachingRecommendations(simulationData, recentScans),
      );
  }

  return recommendations;
}

function identifyCoachingFocusAreas(sportType, simulationData) {
  const focusAreas = [];

  if (simulationData.length > 0) {
    const latestData = JSON.parse(simulationData[0].simulation_data);

    // Analyze specific metrics based on sport
    if (latestData.tactical_efficiency < 70) {
      focusAreas.push({
        area: "tactical_efficiency",
        priority: "high",
        current_score: latestData.tactical_efficiency,
        target_score: 85,
        training_focus:
          sportType === "wrestling"
            ? "positional_awareness"
            : "team_coordination",
      });
    }

    if (latestData.recovery_index < 70) {
      focusAreas.push({
        area: "recovery_index",
        priority: "medium",
        current_score: latestData.recovery_index,
        target_score: 80,
        training_focus: "conditioning_and_recovery",
      });
    }

    if (latestData.spike_score < 70) {
      focusAreas.push({
        area: "spike_score",
        priority:
          sportType.includes("tennis") || sportType.includes("pickleball")
            ? "high"
            : "medium",
        current_score: latestData.spike_score,
        target_score: 85,
        training_focus: "power_and_precision",
      });
    }

    if (latestData.session_consistency < 70) {
      focusAreas.push({
        area: "session_consistency",
        priority: sportType === "american_football" ? "high" : "medium",
        current_score: latestData.session_consistency,
        target_score: 80,
        training_focus: "consistent_performance",
      });
    }
  }

  return focusAreas;
}

function suggestTrainingAdjustments(athlete, simulationData) {
  const adjustments = [];

  if (athlete.tier_level < 3) {
    adjustments.push({
      adjustment: "increase_training_frequency",
      reason: "Tier advancement opportunity",
      recommendation: "Add 2 additional training sessions per week",
    });
  }

  if (simulationData.length > 2) {
    const scores = simulationData.map(
      (sim) => JSON.parse(sim.simulation_data).overall_score,
    );
    const trend = calculateTrend(scores);

    if (trend < 0) {
      adjustments.push({
        adjustment: "modify_training_intensity",
        reason: "Declining performance trend detected",
        recommendation: "Reduce intensity, focus on technique refinement",
      });
    }
  }

  return adjustments;
}

// Sport-specific coaching functions
function getWrestlingCoachingRecommendations(simulationData, recentScans) {
  return [
    {
      category: "technique",
      recommendation: "Focus on takedown efficiency drills",
      priority: "high",
      expected_improvement: "15-20% in takedown success rate",
    },
    {
      category: "conditioning",
      recommendation: "Implement goal-wrestling specific cardio",
      priority: "medium",
      expected_improvement: "Improved match endurance",
    },
    {
      category: "defensive",
      recommendation: "Practice defensive positioning and escapes",
      priority: "high",
      expected_improvement: "Reduced points conceded",
    },
  ];
}

function getTacticalSportsRecommendations(simulationData, recentScans) {
  return [
    {
      category: "tactical_awareness",
      recommendation: "Study game film and practice decision-making drills",
      priority: "high",
      expected_improvement: "Better field/court awareness",
    },
    {
      category: "team_coordination",
      recommendation: "Focus on communication and team play exercises",
      priority: "medium",
      expected_improvement: "Improved team efficiency",
    },
    {
      category: "execution",
      recommendation: "Practice high-pressure situation scenarios",
      priority: "high",
      expected_improvement: "Better performance under pressure",
    },
  ];
}

function getRacketSportsRecommendations(simulationData, recentScans) {
  return [
    {
      category: "power_generation",
      recommendation: "Work on core strength and rotation mechanics",
      priority: "high",
      expected_improvement: "10-15% increase in shot power",
    },
    {
      category: "accuracy",
      recommendation: "Practice precision targeting drills",
      priority: "high",
      expected_improvement: "Improved shot placement accuracy",
    },
    {
      category: "consistency",
      recommendation: "Focus on repeatable motion patterns",
      priority: "medium",
      expected_improvement: "Reduced unforced errors",
    },
  ];
}

function getAmericanFootballRecommendations(simulationData, recentScans) {
  return [
    {
      category: "consistency",
      recommendation: "Establish regular training routine",
      priority: "high",
      expected_improvement: "More predictable performance",
    },
    {
      category: "skill_development",
      recommendation: "Position-specific skill drills",
      priority: "high",
      expected_improvement: "Enhanced role-specific abilities",
    },
    {
      category: "game_preparation",
      recommendation: "Mental preparation and visualization",
      priority: "medium",
      expected_improvement: "Better game-day performance",
    },
  ];
}

function getGeneralCoachingRecommendations(simulationData, recentScans) {
  return [
    {
      category: "general_fitness",
      recommendation: "Comprehensive fitness assessment and program",
      priority: "medium",
      expected_improvement: "Overall athletic improvement",
    },
    {
      category: "skill_development",
      recommendation: "Sport-specific skill training",
      priority: "high",
      expected_improvement: "Technical skill enhancement",
    },
    {
      category: "mental_preparation",
      recommendation: "Mental coaching and sports psychology",
      priority: "medium",
      expected_improvement: "Better focus and confidence",
    },
  ];
}

// Helper functions
function calculateTrend(scores) {
  if (scores.length < 2) return 0;

  const n = scores.length;
  const sumX = (n * (n - 1)) / 2; // Sum of indices 0, 1, 2, ..., n-1
  const sumY = scores.reduce((a, b) => a + b, 0);
  const sumXY = scores.reduce((sum, score, index) => sum + score * index, 0);
  const sumX2 = (n * (n - 1) * (2 * n - 1)) / 6; // Sum of squares of indices

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  return slope;
}

function calculateConsistency(scores) {
  if (scores.length < 2) return 0;

  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const stdDev = Math.sqrt(variance);

  // Consistency score: higher is more consistent (lower standard deviation)
  return Math.max(0, 100 - stdDev * 10);
}

function assessImprovementPotential(scores) {
  const currentScore = scores[scores.length - 1];
  const maxPossible = 100;
  const improvementRoom = maxPossible - currentScore;

  return {
    current_level: currentScore,
    improvement_room: improvementRoom,
    potential_rating:
      improvementRoom > 30 ? "high" : improvementRoom > 15 ? "medium" : "low",
  };
}

// Additional AI analysis functions (stubs for compilation)
async function generateAIRecommendations(performanceData) {
  return {
    technical_recommendations: ["Improve technique", "Focus on consistency"],
    training_recommendations: [
      "Increase training frequency",
      "Add strength training",
    ],
    recovery_recommendations: [
      "Ensure adequate rest",
      "Consider massage therapy",
    ],
  };
}

function identifyPriorityImprovementAreas(performanceData) {
  return ["technique_refinement", "endurance_building", "mental_preparation"];
}

function generateNextSteps(performanceData) {
  return [
    "Schedule technique assessment session",
    "Implement recommended training adjustments",
    "Set short-term performance goals",
  ];
}

async function createPersonalizedTrainingPlan(
  athlete,
  performanceHistory,
  milestones,
) {
  return {
    plan_id: `plan_${athlete.id}_${Date.now()}`,
    duration_weeks: 12,
    focus_areas: ["technique", "conditioning", "mental_preparation"],
    weekly_sessions: 4,
    session_types: ["technique", "conditioning", "scrimmage", "recovery"],
    milestones: milestones.map((m) => m.title),
    expected_outcomes: "15-20% performance improvement",
  };
}

async function generateRealTimeFeedback(latestScan) {
  return {
    overall_assessment: "Good technique with room for improvement",
    specific_feedback: [
      "Maintain consistent form throughout movement",
      "Focus on follow-through execution",
      "Improve balance during transition phases",
    ],
    immediate_corrections: [
      "Adjust stance width by 2-3 inches",
      "Keep core engaged throughout movement",
      "Ensure full range of motion",
    ],
    confidence_level: 0.85,
  };
}

function generateTrainingSession(sessionData) {
  return {
    session_id: `session_${Date.now()}`,
    session_type: sessionData.session_type,
    estimated_duration: sessionData.duration,
    exercises: generateExerciseList(
      sessionData.focus_areas,
      sessionData.difficulty_level,
    ),
    target_metrics: {
      intensity_target: sessionData.difficulty_level,
      focus_areas: sessionData.focus_areas,
      expected_improvement: "5-10% in targeted areas",
    },
  };
}

function generateExerciseList(focusAreas, difficulty) {
  const exercises = [];
  focusAreas.forEach((area) => {
    exercises.push({
      exercise_name: `${area} focused drill`,
      duration: "15 minutes",
      intensity: difficulty,
      description: `Targeted exercise for ${area} improvement`,
    });
  });
  return exercises;
}

function generateSportSpecificTechniqueAnalysis(sportType, scanData) {
  return {
    sport: sportType,
    technique_score: Math.round(Math.random() * 30 + 70), // 70-100
    key_observations: [
      `Good ${sportType} fundamentals`,
      "Room for improvement in precision",
    ],
    specific_metrics: getSportSpecificMetrics(sportType),
  };
}

function getSportSpecificMetrics(sportType) {
  const metrics = {
    wrestling: { takedown_efficiency: 78, defensive_stability: 85 },
    tennis: { serve_power: 82, shot_accuracy: 76 },
    american_football: { consistency_rating: 79, technique_score: 83 },
  };
  return metrics[sportType] || { overall_technique: 80 };
}

function identifyTechniqueImprovements(scanData, sportType) {
  return [
    `Improve ${sportType} specific positioning`,
    "Enhance movement efficiency",
    "Focus on consistency in execution",
  ];
}

function generateMilestoneInsights(milestones) {
  return {
    average_completion_time: "6.5 weeks",
    success_factors: ["Consistent training", "Proper technique focus"],
    common_challenges: ["Maintaining motivation", "Technique plateaus"],
  };
}

async function performAdvancedAnalysis(
  athleteId,
  performanceData,
  analysisType,
) {
  return {
    analysis_type: analysisType,
    confidence_level: 0.87,
    improvement_recommendations: [
      "Focus on specific skill development",
      "Increase training consistency",
      "Consider technique refinement",
    ],
    performance_insights: {
      strengths: ["Good fundamentals", "Consistent effort"],
      areas_for_improvement: ["Power generation", "Precision"],
      overall_assessment: "Positive trajectory with optimization opportunities",
    },
  };
}

async function createIntelligentFeedback(
  athleteId,
  motionData,
  sessionContext,
) {
  return {
    feedback_summary: "Good session with targeted improvements identified",
    actionable_points: [
      "Adjust stance for better balance",
      "Focus on follow-through consistency",
      "Maintain core engagement",
    ],
    technique_score: 82,
    improvement_areas: ["balance", "consistency", "power_transfer"],
    next_session_focus: "Build on today's progress with specific drills",
  };
}

async function adaptTrainingPlan(athleteId, planUpdates, performanceFeedback) {
  return {
    version: "2.1",
    adaptation_reason:
      "Performance feedback indicates need for increased focus on technique",
    updated_focus_areas: planUpdates.focus_areas || [
      "technique",
      "conditioning",
    ],
    adjusted_intensity: "moderate_increase",
    timeline_adjustments: "Extended technique phase by 2 weeks",
  };
}
