/**
 * PhysiobioFIN Security Utilities
 *
 * Implements:
 * - CSRF Token Generation & Validation
 * - XSS Sanitization
 * - SQL Injection Prevention Validation
 * - Input Validation & Rate Limiting
 */

import crypto from "crypto";

// ============================================================================
// CSRF PROTECTION
// ============================================================================

/**
 * Generate a cryptographically secure CSRF token
 * @returns {string} CSRF token
 */
export function generateCSRFToken() {
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Validate CSRF token from request
 * @param {Request} request - Next.js request object
 * @param {string} expectedToken - Expected CSRF token (from session/cookie)
 * @returns {boolean} Whether token is valid
 */
export function validateCSRFToken(request, expectedToken) {
  const headerToken = request.headers.get("x-csrf-token");
  const bodyToken = request.body?.csrfToken;

  const providedToken = headerToken || bodyToken;

  if (!providedToken || !expectedToken) {
    return false;
  }

  // Timing-safe comparison to prevent timing attacks
  return crypto.timingSafeEqual(
    Buffer.from(providedToken),
    Buffer.from(expectedToken),
  );
}

// ============================================================================
// XSS SANITIZATION
// ============================================================================

/**
 * HTML entity encoding map
 */
const htmlEntityMap = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#x27;",
  "/": "&#x2F;",
};

/**
 * Escape HTML to prevent XSS
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
export function escapeHtml(str) {
  if (typeof str !== "string") return str;
  return str.replace(/[&<>"'/]/g, (char) => htmlEntityMap[char]);
}

/**
 * Sanitize user input to prevent XSS attacks
 * @param {any} input - Input to sanitize
 * @param {Object} options - Sanitization options
 * @returns {any} Sanitized input
 */
export function sanitizeInput(input, options = {}) {
  const {
    allowHtml = false,
    maxLength = 10000,
    stripScripts = true,
    stripEvents = true,
  } = options;

  if (input === null || input === undefined) return input;

  // Handle arrays
  if (Array.isArray(input)) {
    return input.map((item) => sanitizeInput(item, options));
  }

  // Handle objects
  if (typeof input === "object") {
    const sanitized = {};
    for (const [key, value] of Object.entries(input)) {
      sanitized[escapeHtml(key)] = sanitizeInput(value, options);
    }
    return sanitized;
  }

  // Handle strings
  if (typeof input === "string") {
    let sanitized = input;

    // Length limit
    if (sanitized.length > maxLength) {
      sanitized = sanitized.substring(0, maxLength);
    }

    // Strip script tags
    if (stripScripts) {
      sanitized = sanitized.replace(
        /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
        "",
      );
    }

    // Strip event handlers
    if (stripEvents) {
      sanitized = sanitized.replace(/on\w+\s*=\s*["'][^"']*["']/gi, "");
      sanitized = sanitized.replace(/on\w+\s*=\s*[^\s>]*/gi, "");
    }

    // Strip javascript: URLs
    sanitized = sanitized.replace(/javascript:/gi, "");

    // Strip data: URLs (can contain encoded scripts)
    sanitized = sanitized.replace(/data:text\/html/gi, "");

    // Escape HTML if not allowed
    if (!allowHtml) {
      sanitized = escapeHtml(sanitized);
    }

    return sanitized;
  }

  return input;
}

/**
 * Sanitize JSON object recursively
 * @param {Object} obj - Object to sanitize
 * @returns {Object} Sanitized object
 */
export function sanitizeJSON(obj) {
  return sanitizeInput(obj, {
    allowHtml: false,
    stripScripts: true,
    stripEvents: true,
  });
}

// ============================================================================
// SQL INJECTION PREVENTION
// ============================================================================

/**
 * Validate SQL parameter to prevent injection
 * Note: This is a secondary defense. Primary defense is parameterized queries.
 * @param {any} param - Parameter to validate
 * @returns {boolean} Whether parameter is safe
 */
export function isValidSQLParam(param) {
  if (param === null || param === undefined) return true;

  const str = String(param);

  // Check for common SQL injection patterns
  const sqlInjectionPatterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)/gi,
    /(--|\*|;|'|"|`|\/\*|\*\/)/g,
    /(UNION|OR|AND)\s+\d+\s*=\s*\d+/gi,
    /xp_cmdshell/gi,
    /script/gi,
  ];

  for (const pattern of sqlInjectionPatterns) {
    if (pattern.test(str)) {
      return false;
    }
  }

  return true;
}

/**
 * Validate all SQL parameters in an object
 * @param {Object} params - Parameters to validate
 * @returns {Object} Validation result
 */
export function validateSQLParams(params) {
  const errors = [];

  for (const [key, value] of Object.entries(params)) {
    if (!isValidSQLParam(value)) {
      errors.push(`Parameter "${key}" contains potentially malicious content`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// ============================================================================
// INPUT VALIDATION
// ============================================================================

/**
 * Email validation
 * @param {string} email - Email to validate
 * @returns {boolean} Whether email is valid
 */
export function isValidEmail(email) {
  if (!email || typeof email !== "string") return false;

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
}

/**
 * URL validation
 * @param {string} url - URL to validate
 * @returns {boolean} Whether URL is valid
 */
export function isValidURL(url) {
  if (!url || typeof url !== "string") return false;

  try {
    const parsed = new URL(url);
    return ["http:", "https:"].includes(parsed.protocol);
  } catch {
    return false;
  }
}

/**
 * Numeric validation
 * @param {any} value - Value to validate
 * @param {Object} options - Validation options
 * @returns {boolean} Whether value is valid
 */
export function isValidNumber(value, options = {}) {
  const { min, max, integer = false } = options;

  const num = Number(value);

  if (isNaN(num) || !isFinite(num)) return false;
  if (integer && !Number.isInteger(num)) return false;
  if (min !== undefined && num < min) return false;
  if (max !== undefined && num > max) return false;

  return true;
}

/**
 * String length validation
 * @param {string} str - String to validate
 * @param {Object} options - Validation options
 * @returns {boolean} Whether string is valid
 */
export function isValidStringLength(str, options = {}) {
  if (typeof str !== "string") return false;

  const { min = 0, max = Infinity } = options;

  return str.length >= min && str.length <= max;
}

/**
 * Alphanumeric validation
 * @param {string} str - String to validate
 * @param {Object} options - Validation options
 * @returns {boolean} Whether string is alphanumeric
 */
export function isAlphanumeric(str, options = {}) {
  if (typeof str !== "string") return false;

  const {
    allowSpaces = false,
    allowDashes = false,
    allowUnderscores = false,
  } = options;

  let pattern = "^[a-zA-Z0-9";
  if (allowSpaces) pattern += " ";
  if (allowDashes) pattern += "-";
  if (allowUnderscores) pattern += "_";
  pattern += "]+$";

  const regex = new RegExp(pattern);
  return regex.test(str);
}

// ============================================================================
// RATE LIMITING (In-Memory)
// ============================================================================

const rateLimitStore = new Map();

/**
 * Simple in-memory rate limiter
 * @param {string} identifier - Unique identifier (e.g., IP address, user ID)
 * @param {Object} options - Rate limit options
 * @returns {Object} Rate limit result
 */
export function checkRateLimit(identifier, options = {}) {
  const {
    maxRequests = 100,
    windowMs = 60000, // 1 minute
  } = options;

  const now = Date.now();
  const key = `${identifier}:${Math.floor(now / windowMs)}`;

  // Clean old entries
  const cutoff = now - windowMs * 2;
  for (const [k, v] of rateLimitStore.entries()) {
    if (v.timestamp < cutoff) {
      rateLimitStore.delete(k);
    }
  }

  // Check current window
  const current = rateLimitStore.get(key) || { count: 0, timestamp: now };

  if (current.count >= maxRequests) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: new Date(Math.floor(now / windowMs + 1) * windowMs),
    };
  }

  current.count++;
  current.timestamp = now;
  rateLimitStore.set(key, current);

  return {
    allowed: true,
    remaining: maxRequests - current.count,
    resetAt: new Date(Math.floor(now / windowMs + 1) * windowMs),
  };
}

// ============================================================================
// REQUEST VALIDATION MIDDLEWARE
// ============================================================================

/**
 * Validate and sanitize request body
 * @param {Request} request - Next.js request
 * @param {Object} schema - Validation schema
 * @returns {Promise<Object>} Validated and sanitized body
 */
export async function validateRequestBody(request, schema = {}) {
  let body;

  try {
    body = await request.json();
  } catch {
    throw new Error("Invalid JSON in request body");
  }

  // Sanitize input
  body = sanitizeJSON(body);

  // Validate against schema
  const errors = [];

  for (const [field, rules] of Object.entries(schema)) {
    const value = body[field];

    // Required check
    if (
      rules.required &&
      (value === undefined || value === null || value === "")
    ) {
      errors.push(`Field "${field}" is required`);
      continue;
    }

    // Skip validation if field is optional and not provided
    if (!rules.required && (value === undefined || value === null)) {
      continue;
    }

    // Type validation
    if (rules.type === "email" && !isValidEmail(value)) {
      errors.push(`Field "${field}" must be a valid email`);
    }

    if (rules.type === "url" && !isValidURL(value)) {
      errors.push(`Field "${field}" must be a valid URL`);
    }

    if (rules.type === "number" && !isValidNumber(value, rules)) {
      errors.push(`Field "${field}" must be a valid number`);
    }

    if (rules.type === "string" && typeof value !== "string") {
      errors.push(`Field "${field}" must be a string`);
    }

    // Length validation
    if (
      rules.minLength &&
      !isValidStringLength(value, { min: rules.minLength })
    ) {
      errors.push(
        `Field "${field}" must be at least ${rules.minLength} characters`,
      );
    }

    if (
      rules.maxLength &&
      !isValidStringLength(value, { max: rules.maxLength })
    ) {
      errors.push(
        `Field "${field}" must be at most ${rules.maxLength} characters`,
      );
    }

    // Pattern validation
    if (rules.pattern && !new RegExp(rules.pattern).test(value)) {
      errors.push(`Field "${field}" has invalid format`);
    }

    // Custom validation
    if (rules.validate && !rules.validate(value)) {
      errors.push(`Field "${field}" failed custom validation`);
    }
  }

  if (errors.length > 0) {
    throw new Error(`Validation failed: ${errors.join(", ")}`);
  }

  return body;
}

// ============================================================================
// SECURITY HEADERS HELPER
// ============================================================================

/**
 * Get security headers for API responses
 * @returns {Object} Headers object
 */
export function getSecurityHeaders() {
  return {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  };
}

/**
 * Create secure Response with security headers
 * @param {any} data - Response data
 * @param {Object} options - Response options
 * @returns {Response} Secure response
 */
export function createSecureResponse(data, options = {}) {
  const { status = 200, headers = {} } = options;

  return Response.json(data, {
    status,
    headers: {
      ...getSecurityHeaders(),
      ...headers,
    },
  });
}

// ============================================================================
// PASSWORD SECURITY
// ============================================================================

/**
 * Validate password strength
 * @param {string} password - Password to validate
 * @returns {Object} Validation result
 */
export function validatePasswordStrength(password) {
  const errors = [];

  if (!password || typeof password !== "string") {
    return { valid: false, errors: ["Password is required"] };
  }

  if (password.length < 8) {
    errors.push("Password must be at least 8 characters");
  }

  if (password.length > 128) {
    errors.push("Password must be at most 128 characters");
  }

  if (!/[a-z]/.test(password)) {
    errors.push("Password must contain at least one lowercase letter");
  }

  if (!/[A-Z]/.test(password)) {
    errors.push("Password must contain at least one uppercase letter");
  }

  if (!/[0-9]/.test(password)) {
    errors.push("Password must contain at least one number");
  }

  if (!/[^a-zA-Z0-9]/.test(password)) {
    errors.push("Password must contain at least one special character");
  }

  // Check for common weak passwords
  const commonPasswords = ["password", "12345678", "qwerty", "abc123"];
  if (commonPasswords.includes(password.toLowerCase())) {
    errors.push("Password is too common");
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// ============================================================================
// EXPORTS
// ============================================================================

export default {
  // CSRF
  generateCSRFToken,
  validateCSRFToken,

  // XSS
  escapeHtml,
  sanitizeInput,
  sanitizeJSON,

  // SQL Injection
  isValidSQLParam,
  validateSQLParams,

  // Input Validation
  isValidEmail,
  isValidURL,
  isValidNumber,
  isValidStringLength,
  isAlphanumeric,

  // Rate Limiting
  checkRateLimit,

  // Request Validation
  validateRequestBody,

  // Security Headers
  getSecurityHeaders,
  createSecureResponse,

  // Password
  validatePasswordStrength,
};
