import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { milestone_id, amount, contribution_type = "direct" } = body;

    if (!milestone_id || !amount || amount <= 0) {
      return Response.json({ error: "Invalid request data" }, { status: 400 });
    }

    const [contributorProfile] = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!contributorProfile) {
      return Response.json(
        { error: "Contributor profile not found" },
        { status: 404 },
      );
    }

    // Get or create contribution pool for milestone
    let [pool] = await sql`
      SELECT * FROM contribution_pools WHERE milestone_id = ${milestone_id}
    `;

    if (!pool) {
      [pool] = await sql`
        INSERT INTO contribution_pools (milestone_id)
        VALUES (${milestone_id})
        RETURNING *
      `;
    }

    if (pool.pool_status !== "active") {
      return Response.json(
        { error: "Contribution pool is not active" },
        { status: 400 },
      );
    }

    const [contribution, updatedPool] = await sql.transaction([
      sql`
        INSERT INTO contributions (
          pool_id, contributor_id, amount, contribution_type
        )
        VALUES (
          ${pool.id}, ${contributorProfile.id}, ${amount}, ${contribution_type}
        )
        RETURNING *
      `,
      sql`
        UPDATE contribution_pools
        SET total_amount = total_amount + ${amount},
            contributor_count = contributor_count + 1
        WHERE id = ${pool.id}
        RETURNING *
      `,
    ]);

    return Response.json({
      success: true,
      contribution: contribution[0],
      pool: updatedPool[0],
    });
  } catch (error) {
    console.error("Create contribution error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
