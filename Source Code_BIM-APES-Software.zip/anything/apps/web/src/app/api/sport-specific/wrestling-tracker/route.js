import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Sport-Specific Module
 * Wrestling / Goalwrestling Performance Tracker
 *
 * Analyzes:
 * - Takedown efficiency
 * - Escape rate
 * - Stamina retention
 * - Match control time
 * - Point differential
 * - Technical execution
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athleteId,
      sessionId,
      matchData = {},
      biometricData = {},
      videoAnalysis = {},
      opponentProfile = {},
    } = body;

    if (!athleteId) {
      return Response.json(
        { error: "Athlete ID is required" },
        { status: 400 },
      );
    }

    // --- CORE WRESTLING METRICS ---
    const coreMetrics = calculateCoreWrestlingMetrics(matchData);

    // --- TECHNICAL EXECUTION ANALYSIS ---
    const technicalAnalysis = analyzeTechnicalExecution(
      matchData,
      videoAnalysis,
    );

    // --- STAMINA & ENDURANCE ---
    const staminaAnalysis = analyzeStamina(matchData, biometricData);

    // --- MATCH CONTROL ANALYSIS ---
    const controlAnalysis = analyzeMatchControl(matchData);

    // --- POINT EFFICIENCY ---
    const pointEfficiency = analyzePointEfficiency(matchData);

    // --- DEFENSIVE METRICS ---
    const defensiveMetrics = analyzeDefensivePerformance(matchData);

    // --- OPPONENT-RELATIVE PERFORMANCE ---
    const relativePerformance = analyzeRelativePerformance(
      matchData,
      opponentProfile,
    );

    // --- BIM SCORE CALCULATION ---
    const bimScore = calculateWrestlingBIMScore({
      coreMetrics,
      technicalAnalysis,
      staminaAnalysis,
      controlAnalysis,
      pointEfficiency,
      defensiveMetrics,
    });

    // --- NIL VALUATION IMPACT ---
    const nilImpact = calculateNILImpact(bimScore, matchData, opponentProfile);

    // --- COACHING INSIGHTS ---
    const coachingInsights = generateCoachingInsights({
      coreMetrics,
      technicalAnalysis,
      staminaAnalysis,
      defensiveMetrics,
      relativePerformance,
    });

    // --- IMPROVEMENT ROADMAP ---
    const improvementRoadmap = generateImprovementRoadmap({
      coreMetrics,
      technicalAnalysis,
      defensiveMetrics,
      bimScore,
    });

    return Response.json({
      success: true,
      athlete: {
        id: athleteId,
        sessionId,
      },
      performance: {
        core: coreMetrics,
        technical: technicalAnalysis,
        stamina: staminaAnalysis,
        control: controlAnalysis,
        pointEfficiency,
        defensive: defensiveMetrics,
        relativePerformance,
      },
      bim: {
        overallScore: bimScore.overall,
        breakdown: bimScore.breakdown,
        percentile: bimScore.percentile,
        tier: bimScore.tier,
      },
      nil: nilImpact,
      insights: {
        coaching: coachingInsights,
        improvement: improvementRoadmap,
      },
      metadata: {
        analyzedAt: new Date().toISOString(),
        sport: "wrestling",
        sessionType: matchData.sessionType || "match",
      },
    });
  } catch (error) {
    console.error("Wrestling tracker error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- CORE METRICS CALCULATION ---

function calculateCoreWrestlingMetrics(matchData) {
  const {
    takedownAttempts = 0,
    takedownsCompleted = 0,
    escapeAttempts = 0,
    escapesCompleted = 0,
    reversals = 0,
    nearFallPoints = 0,
    totalPoints = 0,
    opponentPoints = 0,
    matchDuration = 360, // 6 minutes in seconds
  } = matchData;

  const takedownEfficiency =
    takedownAttempts > 0 ? (takedownsCompleted / takedownAttempts) * 100 : 0;

  const escapeRate =
    escapeAttempts > 0 ? (escapesCompleted / escapeAttempts) * 100 : 0;

  const pointDifferential = totalPoints - opponentPoints;

  const pointsPerMinute =
    matchDuration > 0 ? totalPoints / (matchDuration / 60) : 0;

  const offensiveEfficiency =
    (takedownsCompleted * 2 + nearFallPoints + reversals * 2) /
    (matchDuration / 60);

  return {
    takedownEfficiency: Math.round(takedownEfficiency * 10) / 10,
    escapeRate: Math.round(escapeRate * 10) / 10,
    takedownsCompleted,
    takedownAttempts,
    escapesCompleted,
    escapeAttempts,
    reversals,
    nearFallPoints,
    totalPoints,
    opponentPoints,
    pointDifferential,
    pointsPerMinute: Math.round(pointsPerMinute * 10) / 10,
    offensiveEfficiency: Math.round(offensiveEfficiency * 10) / 10,
  };
}

// --- TECHNICAL EXECUTION ANALYSIS ---

function analyzeTechnicalExecution(matchData, videoAnalysis) {
  const {
    singleLegAttempts = 0,
    singleLegSuccess = 0,
    doubleLegAttempts = 0,
    doubleLegSuccess = 0,
    highCrankAttempts = 0,
    highCrankSuccess = 0,
    shotSetup = 0,
    shotTiming = 0,
    shotPenetration = 0,
    finishingAbility = 0,
  } = videoAnalysis;

  const singleLegEfficiency =
    singleLegAttempts > 0 ? (singleLegSuccess / singleLegAttempts) * 100 : 0;

  const doubleLegEfficiency =
    doubleLegAttempts > 0 ? (doubleLegSuccess / doubleLegAttempts) * 100 : 0;

  const highCrankEfficiency =
    highCrankAttempts > 0 ? (highCrankSuccess / highCrankAttempts) * 100 : 0;

  // Technical quality score (0-100)
  const technicalQuality =
    shotSetup * 0.2 +
    shotTiming * 0.25 +
    shotPenetration * 0.25 +
    finishingAbility * 0.3;

  return {
    singleLegEfficiency: Math.round(singleLegEfficiency * 10) / 10,
    doubleLegEfficiency: Math.round(doubleLegEfficiency * 10) / 10,
    highCrankEfficiency: Math.round(highCrankEfficiency * 10) / 10,
    technicalQuality: Math.round(technicalQuality * 10) / 10,
    shotSetup: Math.round(shotSetup * 10) / 10,
    shotTiming: Math.round(shotTiming * 10) / 10,
    shotPenetration: Math.round(shotPenetration * 10) / 10,
    finishingAbility: Math.round(finishingAbility * 10) / 10,
  };
}

// --- STAMINA ANALYSIS ---

function analyzeStamina(matchData, biometricData) {
  const {
    period1Intensity = 80,
    period2Intensity = 75,
    period3Intensity = 70,
    avgHeartRate = 160,
    peakHeartRate = 185,
    recoveryRate = 0.8, // 0-1 scale
  } = biometricData;

  const intensityRetention = period3Intensity / period1Intensity;
  const staminaScore = (intensityRetention * 0.6 + recoveryRate * 0.4) * 100;

  const cardiacEfficiency =
    avgHeartRate > 0 ? (1 - Math.abs(avgHeartRate - 160) / 160) * 100 : 0;

  return {
    period1Intensity,
    period2Intensity,
    period3Intensity,
    intensityRetention: Math.round(intensityRetention * 100) / 100,
    staminaScore: Math.round(staminaScore * 10) / 10,
    avgHeartRate,
    peakHeartRate,
    recoveryRate: Math.round(recoveryRate * 100),
    cardiacEfficiency: Math.round(cardiacEfficiency * 10) / 10,
  };
}

// --- MATCH CONTROL ANALYSIS ---

function analyzeMatchControl(matchData) {
  const {
    topPositionTime = 0, // seconds
    bottomPositionTime = 0,
    neutralTime = 0,
    matchDuration = 360,
  } = matchData;

  const topControlPercentage =
    matchDuration > 0 ? (topPositionTime / matchDuration) * 100 : 0;

  const bottomControlPercentage =
    matchDuration > 0 ? (bottomPositionTime / matchDuration) * 100 : 0;

  const neutralPercentage =
    matchDuration > 0 ? (neutralTime / matchDuration) * 100 : 0;

  const dominanceScore = topControlPercentage * 1.5 + neutralPercentage * 0.5;

  return {
    topPositionTime,
    bottomPositionTime,
    neutralTime,
    topControlPercentage: Math.round(topControlPercentage * 10) / 10,
    bottomControlPercentage: Math.round(bottomControlPercentage * 10) / 10,
    neutralPercentage: Math.round(neutralPercentage * 10) / 10,
    dominanceScore: Math.round(dominanceScore * 10) / 10,
  };
}

// --- POINT EFFICIENCY ---

function analyzePointEfficiency(matchData) {
  const {
    takedownsCompleted = 0,
    escapePoints = 0,
    reversalPoints = 0,
    nearFallPoints = 0,
    penaltyPoints = 0,
    totalPoints = 0,
    matchDuration = 360,
  } = matchData;

  const takedownPoints = takedownsCompleted * 2;
  const actionPoints = takedownPoints + reversalPoints + nearFallPoints;
  const passivePoints = escapePoints + penaltyPoints;

  const actionPointRatio =
    totalPoints > 0 ? (actionPoints / totalPoints) * 100 : 0;

  const scoringDiversity =
    ([
      takedownPoints > 0 ? 1 : 0,
      escapePoints > 0 ? 1 : 0,
      reversalPoints > 0 ? 1 : 0,
      nearFallPoints > 0 ? 1 : 0,
    ].reduce((a, b) => a + b, 0) /
      4) *
    100;

  return {
    takedownPoints,
    escapePoints,
    reversalPoints,
    nearFallPoints,
    penaltyPoints,
    actionPoints,
    passivePoints,
    actionPointRatio: Math.round(actionPointRatio * 10) / 10,
    scoringDiversity: Math.round(scoringDiversity * 10) / 10,
  };
}

// --- DEFENSIVE METRICS ---

function analyzeDefensivePerformance(matchData) {
  const {
    opponentTakedownAttempts = 0,
    opponentTakedownsAllowed = 0,
    scrambleDefenseSuccess = 0,
    scrambleDefenseAttempts = 0,
    counterAttacks = 0,
  } = matchData;

  const takedownDefense =
    opponentTakedownAttempts > 0
      ? ((opponentTakedownAttempts - opponentTakedownsAllowed) /
          opponentTakedownAttempts) *
        100
      : 0;

  const scrambleDefenseRate =
    scrambleDefenseAttempts > 0
      ? (scrambleDefenseSuccess / scrambleDefenseAttempts) * 100
      : 0;

  const defensiveAggressiveness = counterAttacks;

  return {
    takedownDefense: Math.round(takedownDefense * 10) / 10,
    scrambleDefenseRate: Math.round(scrambleDefenseRate * 10) / 10,
    opponentTakedownsAllowed,
    counterAttacks,
    defensiveAggressiveness,
  };
}

// --- RELATIVE PERFORMANCE ---

function analyzeRelativePerformance(matchData, opponentProfile) {
  const {
    opponentRanking = 50,
    opponentWinRate = 0.5,
    opponentAvgPoints = 8,
  } = opponentProfile;

  const {
    totalPoints = 0,
    opponentPoints = 0,
    matchOutcome = "win", // win, loss, draw
  } = matchData;

  const opponentQuality = (opponentRanking / 100) * 0.5 + opponentWinRate * 0.5;
  const performanceVsExpected =
    matchOutcome === "win"
      ? 1.2 + opponentQuality * 0.3
      : matchOutcome === "loss"
        ? 0.8 - opponentQuality * 0.3
        : 1.0;

  return {
    opponentRanking,
    opponentWinRate: Math.round(opponentWinRate * 100),
    opponentQuality: Math.round(opponentQuality * 100),
    performanceVsExpected: Math.round(performanceVsExpected * 100) / 100,
    matchOutcome,
  };
}

// --- BIM SCORE CALCULATION ---

function calculateWrestlingBIMScore(metrics) {
  const {
    coreMetrics,
    technicalAnalysis,
    staminaAnalysis,
    controlAnalysis,
    pointEfficiency,
    defensiveMetrics,
  } = metrics;

  // Weight distribution
  const weights = {
    takedownEfficiency: 0.15,
    escapeRate: 0.1,
    technicalQuality: 0.2,
    staminaScore: 0.15,
    dominanceScore: 0.15,
    actionPointRatio: 0.1,
    takedownDefense: 0.15,
  };

  const overall =
    coreMetrics.takedownEfficiency * weights.takedownEfficiency +
    coreMetrics.escapeRate * weights.escapeRate +
    technicalAnalysis.technicalQuality * weights.technicalQuality +
    staminaAnalysis.staminaScore * weights.staminaScore +
    controlAnalysis.dominanceScore * weights.dominanceScore +
    pointEfficiency.actionPointRatio * weights.actionPointRatio +
    defensiveMetrics.takedownDefense * weights.takedownDefense;

  const percentile = calculatePercentile(overall);
  const tier = assignTier(overall);

  return {
    overall: Math.round(overall * 10) / 10,
    breakdown: {
      offense: Math.round(coreMetrics.takedownEfficiency * 10) / 10,
      defense: Math.round(defensiveMetrics.takedownDefense * 10) / 10,
      technical: Math.round(technicalAnalysis.technicalQuality * 10) / 10,
      stamina: Math.round(staminaAnalysis.staminaScore * 10) / 10,
      control: Math.round(controlAnalysis.dominanceScore * 10) / 10,
    },
    percentile,
    tier,
  };
}

function calculatePercentile(score) {
  // Simplified percentile calculation
  if (score >= 90) return 99;
  if (score >= 80) return 90;
  if (score >= 70) return 75;
  if (score >= 60) return 50;
  if (score >= 50) return 25;
  return 10;
}

function assignTier(score) {
  if (score >= 90) return "elite";
  if (score >= 80) return "tier_1";
  if (score >= 70) return "tier_2";
  if (score >= 60) return "tier_3";
  return "developing";
}

// --- NIL IMPACT ---

function calculateNILImpact(bimScore, matchData, opponentProfile) {
  const baseValue = 50000; // Base NIL value
  const scoreMultiplier = bimScore.overall / 70;
  const outcomeMultiplier =
    matchData.matchOutcome === "win"
      ? 1.2
      : matchData.matchOutcome === "loss"
        ? 0.9
        : 1.0;
  const opponentMultiplier = 1 + (opponentProfile.opponentQuality || 0.5);

  const currentNILValue =
    baseValue * scoreMultiplier * outcomeMultiplier * opponentMultiplier;
  const nilChange = currentNILValue - baseValue;

  return {
    currentNILValue: Math.round(currentNILValue),
    baseNILValue: baseValue,
    nilChange: Math.round(nilChange),
    nilChangePercent: Math.round((nilChange / baseValue) * 100 * 10) / 10,
    marketability: bimScore.tier,
  };
}

// --- COACHING INSIGHTS ---

function generateCoachingInsights(metrics) {
  const insights = [];

  const { coreMetrics, technicalAnalysis, staminaAnalysis, defensiveMetrics } =
    metrics;

  if (coreMetrics.takedownEfficiency < 60) {
    insights.push({
      area: "Offense",
      severity: "high",
      observation: "Takedown efficiency below target",
      recommendation: "Focus on shot setup and penetration drills",
    });
  }

  if (technicalAnalysis.finishingAbility < 70) {
    insights.push({
      area: "Technical",
      severity: "medium",
      observation: "Finishing ability needs improvement",
      recommendation: "Practice scramble situations and finishing sequences",
    });
  }

  if (staminaAnalysis.intensityRetention < 0.85) {
    insights.push({
      area: "Conditioning",
      severity: "high",
      observation: "Significant intensity drop in third period",
      recommendation: "Increase conditioning work and live wrestling volume",
    });
  }

  if (defensiveMetrics.takedownDefense < 70) {
    insights.push({
      area: "Defense",
      severity: "medium",
      observation: "Takedown defense vulnerable",
      recommendation: "Work on sprawl technique and hand fighting",
    });
  }

  return insights;
}

// --- IMPROVEMENT ROADMAP ---

function generateImprovementRoadmap(metrics) {
  const { coreMetrics, technicalAnalysis, defensiveMetrics, bimScore } =
    metrics;

  const priorities = [];

  // Identify top 3 improvement areas
  const areas = [
    {
      name: "Takedown Offense",
      score: coreMetrics.takedownEfficiency,
      target: 75,
    },
    {
      name: "Technical Execution",
      score: technicalAnalysis.technicalQuality,
      target: 80,
    },
    {
      name: "Takedown Defense",
      score: defensiveMetrics.takedownDefense,
      target: 75,
    },
    { name: "Escape Rate", score: coreMetrics.escapeRate, target: 80 },
  ];

  areas.sort((a, b) => a.score - a.target - (b.score - b.target));

  areas.slice(0, 3).forEach((area) => {
    priorities.push({
      area: area.name,
      current: Math.round(area.score * 10) / 10,
      target: area.target,
      gap: Math.round((area.target - area.score) * 10) / 10,
      estimatedTimeline: Math.ceil((area.target - area.score) / 5) + " weeks",
    });
  });

  return {
    currentTier: bimScore.tier,
    targetTier: getNextTier(bimScore.tier),
    priorities,
  };
}

function getNextTier(currentTier) {
  const tiers = ["developing", "tier_3", "tier_2", "tier_1", "elite"];
  const index = tiers.indexOf(currentTier);
  return index < tiers.length - 1 ? tiers[index + 1] : "elite";
}
