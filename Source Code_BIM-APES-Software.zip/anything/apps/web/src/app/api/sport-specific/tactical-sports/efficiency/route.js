import sql from "@/app/api/utils/sql";

/**
 * Tactical Sports Efficiency Module
 *
 * For: Rugby, Soccer, Basketball
 *
 * Tracks tactical decision-making and efficiency:
 * - Possession efficiency
 * - Decision quality under pressure
 * - Spatial awareness
 * - Team coordination
 * - Transition speed
 * - Defensive positioning
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athleteId,
      sport = "soccer",
      matchId,
      matchData = {},
      position = "",
    } = body;

    // --- SCALAR INPUT DETECTION (from dashboard form) ---
    const isScalarInput =
      typeof matchData.possessions === "number" ||
      typeof matchData.totalPasses === "number";
    if (isScalarInput) {
      const {
        possessions = 0,
        productivePossessions = 0,
        totalPasses = 0,
        successfulPasses = 0,
        tackles = 0,
        successfulTackles = 0,
        shots = 0,
        assists = 0,
        turnovers = 0,
        distanceCovered = 0,
        sprintDistance = 0,
      } = matchData;

      const possessionEff =
        possessions > 0 ? (productivePossessions / possessions) * 100 : 0;
      const passingAcc =
        totalPasses > 0 ? (successfulPasses / totalPasses) * 100 : 0;
      const tackleSucc = tackles > 0 ? (successfulTackles / tackles) * 100 : 0;
      const sprintRatio =
        distanceCovered > 0 ? (sprintDistance / distanceCovered) * 100 : 0;
      const turnoverPenalty = Math.min(30, turnovers * 3);

      const weights =
        sport === "rugby"
          ? {
              possession: 0.2,
              passing: 0.2,
              defensive: 0.25,
              spatial: 0.15,
              decision: 0.2,
            }
          : sport === "basketball"
            ? {
                possession: 0.25,
                passing: 0.25,
                defensive: 0.2,
                spatial: 0.1,
                decision: 0.2,
              }
            : {
                possession: 0.25,
                passing: 0.25,
                defensive: 0.2,
                spatial: 0.2,
                decision: 0.1,
              };

      const decisionQuality = Math.max(
        0,
        Math.min(100, 80 - turnoverPenalty + assists * 5),
      );
      const spatialScore = Math.min(
        100,
        sprintRatio * 2.5 + distanceCovered / 150,
      );
      const transitionScore = Math.min(
        100,
        assists * 8 + shots * 4 + sprintRatio * 1.5,
      );
      const coordinationScore = Math.min(
        100,
        passingAcc * 0.6 + possessionEff * 0.4,
      );

      const efficiency = {
        possession: parseFloat(possessionEff.toFixed(2)),
        passing: parseFloat(passingAcc.toFixed(2)),
        defensive: parseFloat(tackleSucc.toFixed(2)),
        spatial: parseFloat(Math.min(100, spatialScore).toFixed(2)),
        decisionMaking: parseFloat(Math.min(100, decisionQuality).toFixed(2)),
        transition: parseFloat(transitionScore.toFixed(2)),
        coordination: parseFloat(coordinationScore.toFixed(2)),
      };

      const tacticalScore = parseFloat(
        Math.min(
          100,
          Math.max(
            0,
            possessionEff * weights.possession +
              passingAcc * weights.passing +
              tackleSucc * weights.defensive +
              spatialScore * weights.spatial +
              decisionQuality * weights.decision,
          ),
        ).toFixed(2),
      );

      const sportMult =
        sport === "basketball" ? 1.05 : sport === "rugby" ? 1.1 : 1.0;
      const bimScore = parseFloat(
        Math.min(100, tacticalScore * sportMult).toFixed(2),
      );
      const tier =
        bimScore >= 85
          ? "elite"
          : bimScore >= 70
            ? "advanced"
            : bimScore >= 55
              ? "competitive"
              : bimScore >= 40
                ? "developing"
                : "emerging";

      const insights = [];
      if (passingAcc >= 80)
        insights.push({
          type: "strength",
          area: "Passing",
          message: `Excellent ${passingAcc.toFixed(1)}% passing accuracy.`,
          recommendation:
            "Distribute ball quickly under pressure to exploit spacing.",
        });
      else if (passingAcc < 65 && totalPasses > 0)
        insights.push({
          type: "weakness",
          area: "Passing",
          message: `${passingAcc.toFixed(1)}% passing accuracy is below target.`,
          recommendation: "Prioritize short passes to build possession rhythm.",
        });
      if (possessionEff >= 70)
        insights.push({
          type: "strength",
          area: "Possession",
          message: `${possessionEff.toFixed(1)}% productive possession rate is elite.`,
          recommendation: "Maintain tempo — opponent is on the back foot.",
        });
      else if (possessionEff < 40 && possessions > 0)
        insights.push({
          type: "weakness",
          area: "Possession",
          message: `Only ${possessionEff.toFixed(1)}% of possessions productive.`,
          recommendation: "Improve final-third decision making.",
        });
      if (tackleSucc >= 75)
        insights.push({
          type: "strength",
          area: "Defense",
          message: `${tackleSucc.toFixed(1)}% tackle success rate is dominant.`,
          recommendation: "Press higher — defense can afford to be aggressive.",
        });
      else if (tackleSucc < 55 && tackles > 0)
        insights.push({
          type: "weakness",
          area: "Defense",
          message: `${tackleSucc.toFixed(1)}% tackle success is below standard.`,
          recommendation:
            "Focus on body position and timing in defensive drills.",
        });
      if (turnovers > 5)
        insights.push({
          type: "warning",
          area: "Ball Security",
          message: `${turnovers} turnovers are damaging tactical effectiveness.`,
          recommendation:
            "Protect ball in pressure situations — simplify decision-making.",
        });

      try {
        await sql`INSERT INTO asset_simulations (athlete_id, asset_value, roi_projection, risk_score, simulation_data, valuation_factors)
          VALUES (${athleteId}, ${bimScore * 1200}, ${tacticalScore / 100}, 0.15, ${JSON.stringify({ sport, bimScore, tier, sessionType: "match" })}, ${JSON.stringify({ matchData, sport, position })})`;
      } catch (dbErr) {
        console.error("DB insert error (tactical):", dbErr.message);
      }

      return Response.json({
        success: true,
        athleteId,
        sport,
        position,
        matchId,
        efficiency,
        tacticalScore,
        bimScore,
        tier,
        insights,
        passingBreakdown: {
          total: totalPasses,
          successful: successfulPasses,
          accuracy: passingAcc,
        },
        defensiveBreakdown: { tackles, successfulTackles },
        physical: { distanceCovered, sprintDistance },
        recommendations: insights
          .filter((i) => i.type !== "strength")
          .map((i) => i.recommendation),
      });
    }

    // --- ARRAY-BASED INPUT (existing logic) ---
    const {
      possessions = [],
      passes = [],
      tackles = [],
      shots = [],
      assists = [],
      turnovers = [],
      defensiveActions = [],
      offensiveActions = [],
      transitions = [],
      touchesInDangerZone = 0,
      distanceCovered = 0,
      sprintDistance = 0,
      matchDuration = 90,
      heatmapData = [],
    } = matchData;

    // --- POSSESSION EFFICIENCY ---
    const totalPossessions = possessions.length;
    const productivePossessions = possessions.filter(
      (p) =>
        p.outcome === "goal" || p.outcome === "shot" || p.outcome === "assist",
    ).length;
    const possessionEfficiency =
      totalPossessions > 0
        ? (productivePossessions / totalPossessions) * 100
        : 0;

    // --- PASSING METRICS ---
    const totalPasses = passes.length;
    const successfulPasses = passes.filter((p) => p.successful).length;
    const passAccuracy =
      totalPasses > 0 ? (successfulPasses / totalPasses) * 100 : 0;

    const forwardPasses = passes.filter(
      (p) => p.direction === "forward",
    ).length;
    const progressivePasses = passes.filter((p) => p.progressive).length;
    const keyPasses = passes.filter((p) => p.leadToShot).length;

    // --- DECISION QUALITY ---
    const decisionsUnderPressure = [...passes, ...shots, ...assists].filter(
      (action) => action.underPressure,
    );
    const goodDecisionsUnderPressure = decisionsUnderPressure.filter(
      (action) => action.successful || action.quality === "good",
    );
    const decisionQuality =
      decisionsUnderPressure.length > 0
        ? (goodDecisionsUnderPressure.length / decisionsUnderPressure.length) *
          100
        : 0;

    // --- DEFENSIVE METRICS ---
    const totalTackles = tackles.length;
    const successfulTackles = tackles.filter((t) => t.successful).length;
    const tackleSuccessRate =
      totalTackles > 0 ? (successfulTackles / totalTackles) * 100 : 0;

    const interceptions = defensiveActions.filter(
      (d) => d.type === "interception",
    ).length;
    const blocks = defensiveActions.filter((d) => d.type === "block").length;
    const clearances = defensiveActions.filter(
      (d) => d.type === "clearance",
    ).length;

    // --- SPATIAL AWARENESS ---
    const spatialScore = calculateSpatialAwareness({
      heatmapData,
      position,
      sport,
      touchesInDangerZone,
      totalPossessions,
    });

    // --- TRANSITION EFFICIENCY ---
    const transitionScore = calculateTransitionEfficiency({
      transitions,
      sprintDistance,
      distanceCovered,
    });

    // --- TEAM COORDINATION ---
    const coordinationScore = calculateTeamCoordination({
      assists,
      keyPasses,
      successfulPasses,
      offensiveActions,
    });

    // --- PHYSICAL PERFORMANCE ---
    const workRate = (distanceCovered / matchDuration) * 100;
    const intensityRatio = sprintDistance / distanceCovered;

    // --- SPORT-SPECIFIC ADJUSTMENTS ---
    let sportSpecificMetrics = {};

    if (sport === "basketball") {
      sportSpecificMetrics = {
        screenAssists: offensiveActions.filter((a) => a.type === "screen")
          .length,
        cutQuality: offensiveActions.filter(
          (a) => a.type === "cut" && a.quality === "good",
        ).length,
        defensiveSwitches: defensiveActions.filter((d) => d.type === "switch")
          .length,
      };
    } else if (sport === "rugby") {
      sportSpecificMetrics = {
        ruckEfficiency: offensiveActions.filter(
          (a) => a.type === "ruck" && a.successful,
        ).length,
        linebreaks: offensiveActions.filter((a) => a.type === "linebreak")
          .length,
        tacklesMissed: tackles.filter((t) => !t.successful).length,
      };
    } else if (sport === "soccer") {
      sportSpecificMetrics = {
        dribbleSuccess: offensiveActions.filter(
          (a) => a.type === "dribble" && a.successful,
        ).length,
        crossAccuracy:
          (passes.filter((p) => p.type === "cross" && p.successful).length /
            Math.max(1, passes.filter((p) => p.type === "cross").length)) *
          100,
        aerialDuelsWon: defensiveActions.filter(
          (d) => d.type === "aerial" && d.successful,
        ).length,
      };
    }

    // --- OVERALL TACTICAL EFFICIENCY SCORE ---
    const tacticalScore = calculateTacticalScore({
      possessionEfficiency,
      passAccuracy,
      decisionQuality,
      tackleSuccessRate,
      spatialScore,
      transitionScore,
      coordinationScore,
    });

    // --- BIM CONVERSION ---
    const bimScore = convertToBIM({
      tacticalScore,
      workRate,
      intensityRatio,
      sport,
      position,
    });

    // --- TACTICAL INSIGHTS ---
    const insights = generateTacticalInsights({
      possessionEfficiency,
      passAccuracy,
      decisionQuality,
      spatialScore,
      coordinationScore,
      sport,
    });

    return Response.json({
      success: true,
      athleteId,
      sport,
      position,
      matchId,
      efficiency: {
        possession: Math.round(possessionEfficiency * 100) / 100,
        passing: Math.round(passAccuracy * 100) / 100,
        decisionMaking: Math.round(decisionQuality * 100) / 100,
        defensive: Math.round(tackleSuccessRate * 100) / 100,
        spatial: Math.round(spatialScore * 100) / 100,
        transition: Math.round(transitionScore * 100) / 100,
        coordination: Math.round(coordinationScore * 100) / 100,
      },
      passingBreakdown: {
        total: totalPasses,
        successful: successfulPasses,
        accuracy: Math.round(passAccuracy * 100) / 100,
        forward: forwardPasses,
        progressive: progressivePasses,
        key: keyPasses,
      },
      defensiveBreakdown: {
        tackles: totalTackles,
        successfulTackles,
        interceptions,
        blocks,
        clearances,
      },
      physical: {
        distanceCovered: Math.round(distanceCovered * 100) / 100,
        sprintDistance: Math.round(sprintDistance * 100) / 100,
        workRate: Math.round(workRate * 100) / 100,
        intensityRatio: Math.round(intensityRatio * 100) / 100,
      },
      sportSpecificMetrics,
      tacticalScore: Math.round(tacticalScore * 100) / 100,
      bimScore: Math.round(bimScore * 100) / 100,
      insights,
      recommendations: generateTacticalRecommendations(insights, sport),
    });
  } catch (error) {
    console.error("Tactical sports efficiency error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- SPATIAL AWARENESS ---
function calculateSpatialAwareness({
  heatmapData,
  position,
  sport,
  touchesInDangerZone,
  totalPossessions,
}) {
  let score = 50; // Base score

  // Danger zone touches (high-value areas)
  if (totalPossessions > 0) {
    const dangerZoneRatio = touchesInDangerZone / totalPossessions;
    score += dangerZoneRatio * 30;
  }

  // Position-specific adjustments
  if (sport === "soccer") {
    if (position.includes("forward") && touchesInDangerZone > 5) score += 15;
    if (position.includes("midfielder") && heatmapData.centerCoverage > 60)
      score += 10;
  }

  return Math.min(100, Math.max(0, score));
}

// --- TRANSITION EFFICIENCY ---
function calculateTransitionEfficiency({
  transitions,
  sprintDistance,
  distanceCovered,
}) {
  if (!transitions || transitions.length === 0) return 50;

  const successfulTransitions = transitions.filter((t) => t.successful).length;
  const transitionSuccessRate =
    (successfulTransitions / transitions.length) * 100;

  // Sprint involvement in transitions
  const avgTransitionSprints =
    transitions.reduce((sum, t) => sum + (t.sprintsInvolved || 0), 0) /
    transitions.length;
  const sprintBonus = Math.min(20, avgTransitionSprints * 5);

  return Math.min(100, transitionSuccessRate + sprintBonus);
}

// --- TEAM COORDINATION ---
function calculateTeamCoordination({
  assists,
  keyPasses,
  successfulPasses,
  offensiveActions,
}) {
  let score = 0;

  // Assist contribution
  score += assists.length * 10;

  // Key pass contribution
  score += keyPasses.length * 5;

  // Successful combination play
  const combinationPlays = offensiveActions.filter(
    (a) => a.type === "combination",
  ).length;
  score += combinationPlays * 7;

  // Pass network integration
  if (successfulPasses > 20) score += 15;
  else if (successfulPasses > 10) score += 10;

  return Math.min(100, score);
}

// --- TACTICAL SCORE ---
function calculateTacticalScore(metrics) {
  const {
    possessionEfficiency,
    passAccuracy,
    decisionQuality,
    tackleSuccessRate,
    spatialScore,
    transitionScore,
    coordinationScore,
  } = metrics;

  let score = 0;

  score += (possessionEfficiency / 100) * 20;
  score += (passAccuracy / 100) * 15;
  score += (decisionQuality / 100) * 20;
  score += (tackleSuccessRate / 100) * 10;
  score += (spatialScore / 100) * 15;
  score += (transitionScore / 100) * 10;
  score += (coordinationScore / 100) * 10;

  return Math.min(100, score);
}

// --- BIM CONVERSION ---
function convertToBIM({
  tacticalScore,
  workRate,
  intensityRatio,
  sport,
  position,
}) {
  let bim = tacticalScore;

  // Work rate multiplier
  if (workRate > 120) bim *= 1.15;
  else if (workRate > 100) bim *= 1.1;

  // Intensity multiplier
  if (intensityRatio > 0.2) bim *= 1.1;

  // Sport-specific adjustments
  if (sport === "basketball") bim *= 1.05; // Fast-paced
  if (sport === "rugby") bim *= 1.08; // High-intensity

  return Math.min(100, bim);
}

// --- TACTICAL INSIGHTS ---
function generateTacticalInsights(metrics) {
  const insights = [];
  const {
    possessionEfficiency,
    passAccuracy,
    decisionQuality,
    spatialScore,
    coordinationScore,
    sport,
  } = metrics;

  if (possessionEfficiency < 30) {
    insights.push({
      area: "Possession",
      severity: "high",
      message:
        "Low possession efficiency - focus on decision-making in final third",
    });
  }

  if (passAccuracy < 70) {
    insights.push({
      area: "Passing",
      severity: "medium",
      message: "Below-average passing accuracy - improve technique and vision",
    });
  }

  if (decisionQuality < 60) {
    insights.push({
      area: "Decision Making",
      severity: "high",
      message: "Poor decisions under pressure - practice game scenarios",
    });
  }

  if (spatialScore < 50) {
    insights.push({
      area: "Positioning",
      severity: "medium",
      message: "Limited involvement in key areas - improve spatial awareness",
    });
  }

  if (coordinationScore < 40) {
    insights.push({
      area: "Team Play",
      severity: "medium",
      message: "Low team coordination - work on combination play",
    });
  }

  return insights;
}

// --- RECOMMENDATIONS ---
function generateTacticalRecommendations(insights, sport) {
  const recommendations = [];

  insights.forEach((insight) => {
    if (insight.area === "Possession") {
      recommendations.push("Practice decision-making drills in tight spaces");
      recommendations.push("Film study: recognize scoring opportunities");
    }
    if (insight.area === "Decision Making") {
      recommendations.push("Small-sided games with defensive pressure");
      recommendations.push("Cognitive training exercises");
    }
    if (insight.area === "Positioning") {
      if (sport === "soccer")
        recommendations.push("Zone-specific movement drills");
      if (sport === "basketball")
        recommendations.push("Off-ball movement patterns");
      if (sport === "rugby")
        recommendations.push("Support line running drills");
    }
  });

  return [...new Set(recommendations)];
}
