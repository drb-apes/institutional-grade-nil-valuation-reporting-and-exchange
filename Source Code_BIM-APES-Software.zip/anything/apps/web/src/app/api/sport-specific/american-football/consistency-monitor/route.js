import sql from "@/app/api/utils/sql";

/**
 * American Football Session Consistency Monitoring
 *
 * Tracks consistency across practices, training sessions, and games:
 * - Session-to-session performance variance
 * - Position-specific metrics consistency
 * - Snap-to-snap reliability
 * - Endurance throughout game
 * - Week-over-week improvement
 * - Injury resilience tracking
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athleteId,
      position, // QB, RB, WR, TE, OL, DL, LB, DB, K, P
      sessions = [], // Array of session data
      timeframe = "weekly", // daily, weekly, monthly, season
    } = body;

    if (!sessions || sessions.length === 0) {
      return Response.json(
        {
          error: "At least one session is required for consistency analysis",
        },
        { status: 400 },
      );
    }

    // --- POSITION-SPECIFIC METRICS EXTRACTION ---
    const positionMetrics = extractPositionMetrics(position, sessions);

    // --- SESSION CONSISTENCY SCORES ---
    const consistencyScores = calculateSessionConsistency(positionMetrics);

    // --- VARIANCE ANALYSIS ---
    const varianceAnalysis = calculateVariance(positionMetrics);

    // --- RELIABILITY SCORE ---
    const reliabilityScore = calculateReliability({
      consistency: consistencyScores,
      variance: varianceAnalysis,
      sessions,
    });

    // --- ENDURANCE TRACKING ---
    const enduranceMetrics = analyzeEndurance(sessions);

    // --- WEEK-OVER-WEEK TRENDS ---
    const trendAnalysis = analyzeTrends(sessions, timeframe);

    // --- INJURY RESILIENCE ---
    const injuryResilience = calculateInjuryResilience(sessions);

    // --- SNAP-TO-SNAP CONSISTENCY (for game sessions) ---
    const snapConsistency = analyzeSnapConsistency(sessions);

    // --- OVERALL CONSISTENCY RATING ---
    const overallConsistency = calculateOverallConsistency({
      reliabilityScore,
      varianceAnalysis,
      enduranceMetrics,
      snapConsistency,
    });

    // --- BIM INTEGRATION ---
    const bimScore = convertToBIM({
      overallConsistency,
      position,
      sessionCount: sessions.length,
      performanceLevel: calculateAveragePerformance(sessions),
    });

    // --- INSIGHTS & FLAGS ---
    const insights = generateConsistencyInsights({
      consistencyScores,
      varianceAnalysis,
      trendAnalysis,
      injuryResilience,
      position,
    });

    // Persist simulation to DB
    try {
      await sql`INSERT INTO asset_simulations (athlete_id, asset_value, roi_projection, risk_score, simulation_data, valuation_factors)
        VALUES (
          ${athleteId || 1},
          ${bimScore * 1300},
          ${overallConsistency / 100},
          ${1 - reliabilityScore / 100},
          ${JSON.stringify({ sport: "american_football", bimScore, tier: bimScore >= 85 ? "elite" : bimScore >= 70 ? "advanced" : bimScore >= 55 ? "competitive" : "developing", sessionType: "consistency_analysis", position })},
          ${JSON.stringify({ position, timeframe, sessionCount: sessions.length })}
        )`;
    } catch (dbErr) {
      console.error("DB insert error (football):", dbErr.message);
    }

    return Response.json({
      success: true,
      athleteId,
      position,
      timeframe,
      sessionCount: sessions.length,
      consistency: {
        overall: Math.round(overallConsistency * 100) / 100,
        reliability: Math.round(reliabilityScore * 100) / 100,
        snapToSnap: Math.round(snapConsistency * 100) / 100,
      },
      variance: {
        coefficient:
          Math.round(varianceAnalysis.coefficientOfVariation * 100) / 100,
        standardDeviation:
          Math.round(varianceAnalysis.standardDeviation * 100) / 100,
        range: varianceAnalysis.range,
      },
      endurance: {
        averageStamina: Math.round(enduranceMetrics.avgStamina * 100) / 100,
        fatigueRate: Math.round(enduranceMetrics.fatigueRate * 100) / 100,
        fourthQuarterPerformance:
          Math.round(enduranceMetrics.fourthQuarterPct * 100) / 100,
      },
      trends: {
        direction: trendAnalysis.direction,
        slope: Math.round(trendAnalysis.slope * 100) / 100,
        momentum: trendAnalysis.momentum,
      },
      injuryResilience: Math.round(injuryResilience * 100) / 100,
      positionMetrics,
      bimScore: Math.round(bimScore * 100) / 100,
      insights,
      recommendations: generateRecommendations(insights, position),
    });
  } catch (error) {
    console.error("American Football consistency monitoring error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- POSITION-SPECIFIC METRIC EXTRACTION ---
function extractPositionMetrics(position, sessions) {
  const metrics = [];

  sessions.forEach((session) => {
    const { sessionType, stats = {}, performance = {} } = session;

    let positionScore = 0;

    // Position-specific performance calculation
    if (position === "QB") {
      const {
        completions = 0,
        attempts = 0,
        touchdowns = 0,
        interceptions = 0,
        yards = 0,
      } = stats;
      const completionPct = attempts > 0 ? (completions / attempts) * 100 : 0;
      const tdIntRatio =
        interceptions > 0 ? touchdowns / interceptions : touchdowns;
      positionScore = completionPct * 0.4 + tdIntRatio * 15 + yards / 100;
    } else if (position === "RB" || position === "WR" || position === "TE") {
      const {
        rushingYards = 0,
        receivingYards = 0,
        touchdowns = 0,
        fumbles = 0,
      } = stats;
      positionScore =
        rushingYards / 20 +
        receivingYards / 20 +
        touchdowns * 10 -
        fumbles * 15;
    } else if (position === "OL") {
      const { pancakeBlocks = 0, sacksAllowed = 0, penalties = 0 } = stats;
      positionScore = pancakeBlocks * 8 - sacksAllowed * 12 - penalties * 5;
    } else if (position === "DL" || position === "LB") {
      const {
        tackles = 0,
        sacks = 0,
        qbHits = 0,
        tfl = 0,
        forcedFumbles = 0,
      } = stats;
      positionScore =
        tackles * 2 + sacks * 10 + qbHits * 5 + tfl * 4 + forcedFumbles * 8;
    } else if (position === "DB") {
      const {
        tackles = 0,
        passesDefended = 0,
        interceptions = 0,
        forcedFumbles = 0,
      } = stats;
      positionScore =
        tackles * 2 +
        passesDefended * 5 +
        interceptions * 12 +
        forcedFumbles * 8;
    } else if (position === "K" || position === "P") {
      const { fieldGoalPct = 0, extraPointPct = 0, avgPuntYards = 0 } = stats;
      positionScore =
        fieldGoalPct * 0.7 + extraPointPct * 0.3 + avgPuntYards / 2;
    }

    metrics.push({
      sessionId: session.sessionId || `session_${metrics.length + 1}`,
      sessionType,
      date: session.date,
      score: Math.max(0, positionScore),
      rawStats: stats,
      performance: performance.overall || 0,
    });
  });

  return metrics;
}

// --- SESSION CONSISTENCY ---
function calculateSessionConsistency(metrics) {
  if (metrics.length < 2) return 100;

  const scores = metrics.map((m) => m.score);
  const avg = scores.reduce((a, b) => a + b, 0) / scores.length;

  // Calculate how many scores are within 15% of average
  const threshold = avg * 0.15;
  const consistentScores = scores.filter(
    (s) => Math.abs(s - avg) <= threshold,
  ).length;

  return (consistentScores / scores.length) * 100;
}

// --- VARIANCE ANALYSIS ---
function calculateVariance(metrics) {
  if (metrics.length < 2) {
    return {
      coefficientOfVariation: 0,
      standardDeviation: 0,
      range: { min: 0, max: 0 },
    };
  }

  const scores = metrics.map((m) => m.score);
  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;

  const variance =
    scores.reduce((sum, score) => {
      return sum + Math.pow(score - mean, 2);
    }, 0) / scores.length;

  const stdDev = Math.sqrt(variance);
  const coefficientOfVariation = mean > 0 ? (stdDev / mean) * 100 : 0;

  return {
    coefficientOfVariation,
    standardDeviation: stdDev,
    range: {
      min: Math.min(...scores),
      max: Math.max(...scores),
    },
    mean,
  };
}

// --- RELIABILITY SCORE ---
function calculateReliability({ consistency, variance, sessions }) {
  let score = consistency.overall || 0;

  // Penalize high variance
  if (variance.coefficientOfVariation > 30) score -= 15;
  else if (variance.coefficientOfVariation > 20) score -= 8;

  // Bonus for session volume
  if (sessions.length >= 16)
    score += 10; // Full season+
  else if (sessions.length >= 8) score += 5;

  // Injury-free bonus
  const injuryFreeSessions = sessions.filter(
    (s) => !s.injured && !s.limitedParticipation,
  ).length;
  const healthRate = (injuryFreeSessions / sessions.length) * 100;
  if (healthRate >= 95) score += 10;
  else if (healthRate >= 85) score += 5;

  return Math.min(100, Math.max(0, score));
}

// --- ENDURANCE ANALYSIS ---
function analyzeEndurance(sessions) {
  const gameSessions = sessions.filter((s) => s.sessionType === "game");

  if (gameSessions.length === 0) {
    return {
      avgStamina: 100,
      fatigueRate: 0,
      fourthQuarterPct: 100,
    };
  }

  let totalStamina = 0;
  let totalFatigue = 0;
  let fourthQuarterPerformance = 0;

  gameSessions.forEach((game) => {
    const { quarters = [] } = game;

    if (quarters.length > 0) {
      const avgEnergy =
        quarters.reduce((sum, q) => sum + (q.energyLevel || 100), 0) /
        quarters.length;
      totalStamina += avgEnergy;

      // Fatigue rate: energy drop from Q1 to Q4
      if (quarters.length >= 4) {
        const fatigue =
          (quarters[0].energyLevel || 100) - (quarters[3].energyLevel || 100);
        totalFatigue += Math.max(0, fatigue);

        // Fourth quarter performance relative to first quarter
        const q4Performance = quarters[3].performance || 100;
        const q1Performance = quarters[0].performance || 100;
        fourthQuarterPerformance +=
          q1Performance > 0 ? (q4Performance / q1Performance) * 100 : 100;
      }
    }
  });

  return {
    avgStamina:
      gameSessions.length > 0 ? totalStamina / gameSessions.length : 100,
    fatigueRate:
      gameSessions.length > 0 ? totalFatigue / gameSessions.length : 0,
    fourthQuarterPct:
      gameSessions.length > 0
        ? fourthQuarterPerformance / gameSessions.length
        : 100,
  };
}

// --- TREND ANALYSIS ---
function analyzeTrends(sessions, timeframe) {
  if (sessions.length < 3) {
    return {
      direction: "insufficient_data",
      slope: 0,
      momentum: "neutral",
    };
  }

  // Sort by date
  const sortedSessions = [...sessions].sort(
    (a, b) => new Date(a.date) - new Date(b.date),
  );

  // Calculate linear trend
  const scores = sortedSessions.map((s, idx) => ({
    x: idx,
    y: s.performance?.overall || 0,
  }));
  const n = scores.length;
  const sumX = scores.reduce((sum, point) => sum + point.x, 0);
  const sumY = scores.reduce((sum, point) => sum + point.y, 0);
  const sumXY = scores.reduce((sum, point) => sum + point.x * point.y, 0);
  const sumX2 = scores.reduce((sum, point) => sum + point.x * point.x, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);

  // Recent momentum (last 3 sessions)
  const recentSessions = sortedSessions.slice(-3);
  const recentAvg =
    recentSessions.reduce((sum, s) => sum + (s.performance?.overall || 0), 0) /
    3;
  const overallAvg =
    sortedSessions.reduce((sum, s) => sum + (s.performance?.overall || 0), 0) /
    n;

  let momentum = "neutral";
  if (recentAvg > overallAvg * 1.1) momentum = "accelerating";
  else if (recentAvg < overallAvg * 0.9) momentum = "declining";

  let direction = "stable";
  if (slope > 0.5) direction = "improving";
  else if (slope < -0.5) direction = "declining";

  return {
    direction,
    slope,
    momentum,
  };
}

// --- INJURY RESILIENCE ---
function calculateInjuryResilience(sessions) {
  const injuredSessions = sessions.filter(
    (s) => s.injured || s.limitedParticipation,
  );

  if (injuredSessions.length === 0) return 100;

  // Recovery rate (how quickly performance returns after injury)
  let recoveryScore = 0;
  let recoveryCount = 0;

  sessions.forEach((session, idx) => {
    if (session.injured && idx + 2 < sessions.length) {
      const performanceBefore = sessions[idx - 1]?.performance?.overall || 100;
      const performanceAfter = sessions[idx + 2]?.performance?.overall || 0;
      const recoveryRate =
        performanceBefore > 0
          ? (performanceAfter / performanceBefore) * 100
          : 0;
      recoveryScore += recoveryRate;
      recoveryCount++;
    }
  });

  const avgRecovery = recoveryCount > 0 ? recoveryScore / recoveryCount : 100;
  const injuryFreePct =
    ((sessions.length - injuredSessions.length) / sessions.length) * 100;

  return avgRecovery * 0.4 + injuryFreePct * 0.6;
}

// --- SNAP-TO-SNAP CONSISTENCY ---
function analyzeSnapConsistency(sessions) {
  const gameSessions = sessions.filter((s) => s.sessionType === "game");

  if (gameSessions.length === 0) return 100;

  let totalConsistency = 0;

  gameSessions.forEach((game) => {
    const { snaps = [] } = game;

    if (snaps.length > 1) {
      const snapPerformances = snaps.map((s) => s.performance || 0);
      const mean =
        snapPerformances.reduce((a, b) => a + b, 0) / snapPerformances.length;
      const variance =
        snapPerformances.reduce(
          (sum, perf) => sum + Math.pow(perf - mean, 2),
          0,
        ) / snapPerformances.length;
      const stdDev = Math.sqrt(variance);
      const cv = mean > 0 ? (stdDev / mean) * 100 : 0;

      // Lower CV = higher consistency
      const consistencyScore = Math.max(0, 100 - cv);
      totalConsistency += consistencyScore;
    }
  });

  return gameSessions.length > 0 ? totalConsistency / gameSessions.length : 100;
}

// --- OVERALL CONSISTENCY ---
function calculateOverallConsistency({
  reliabilityScore,
  varianceAnalysis,
  enduranceMetrics,
  snapConsistency,
}) {
  let score = 0;

  score += reliabilityScore * 0.35;
  score +=
    (100 - Math.min(100, varianceAnalysis.coefficientOfVariation)) * 0.25;
  score += enduranceMetrics.avgStamina * 0.2;
  score += snapConsistency * 0.2;

  return Math.min(100, Math.max(0, score));
}

// --- BIM CONVERSION ---
function convertToBIM({
  overallConsistency,
  position,
  sessionCount,
  performanceLevel,
}) {
  let bim = overallConsistency;

  // Consistency premium
  if (overallConsistency >= 85) bim *= 1.15;
  else if (overallConsistency >= 75) bim *= 1.08;

  // Position multipliers (positions requiring high consistency)
  const highConsistencyPositions = ["QB", "K", "P", "OL"];
  if (highConsistencyPositions.includes(position)) bim *= 1.1;

  // Session volume bonus
  if (sessionCount >= 16) bim *= 1.05;

  // Performance level adjustment
  if (performanceLevel >= 80) bim *= 1.1;
  else if (performanceLevel < 60) bim *= 0.9;

  return Math.min(100, bim);
}

// --- AVERAGE PERFORMANCE ---
function calculateAveragePerformance(sessions) {
  const performances = sessions
    .map((s) => s.performance?.overall || 0)
    .filter((p) => p > 0);
  return performances.length > 0
    ? performances.reduce((a, b) => a + b, 0) / performances.length
    : 0;
}

// --- INSIGHTS ---
function generateConsistencyInsights({
  consistencyScores,
  varianceAnalysis,
  trendAnalysis,
  injuryResilience,
  position,
}) {
  const insights = [];

  if (consistencyScores < 70) {
    insights.push({
      area: "Session Consistency",
      severity: "high",
      message:
        "High session-to-session variance detected - focus on routine and fundamentals",
    });
  }

  if (varianceAnalysis.coefficientOfVariation > 25) {
    insights.push({
      area: "Performance Stability",
      severity: "medium",
      message: "Unstable performance patterns - work on mental preparation",
    });
  }

  if (trendAnalysis.direction === "declining") {
    insights.push({
      area: "Performance Trend",
      severity: "high",
      message:
        "Declining performance trend - review training program and recovery",
    });
  }

  if (injuryResilience < 70) {
    insights.push({
      area: "Injury Resilience",
      severity: "high",
      message:
        "Poor injury resilience - enhance recovery protocols and conditioning",
    });
  }

  return insights;
}

// --- RECOMMENDATIONS ---
function generateRecommendations(insights, position) {
  const recommendations = [];

  insights.forEach((insight) => {
    if (insight.area === "Session Consistency") {
      recommendations.push("Establish consistent pre-session routine");
      recommendations.push("Film review to identify execution gaps");
    }
    if (insight.area === "Performance Stability") {
      recommendations.push("Mental skills training with sports psychologist");
      recommendations.push("Meditation and visualization exercises");
    }
    if (insight.area === "Injury Resilience") {
      recommendations.push("Increase flexibility and mobility work");
      recommendations.push(
        "Optimize recovery protocols (sleep, nutrition, therapy)",
      );
    }
  });

  // Position-specific recommendations
  if (position === "QB") {
    recommendations.push("Footwork consistency drills");
    recommendations.push("Decision-making simulator work");
  } else if (position === "RB" || position === "WR") {
    recommendations.push("Route running precision drills");
    recommendations.push("Ball security emphasis in practice");
  } else if (position === "OL") {
    recommendations.push("Hand placement repetition");
    recommendations.push("Set consistency from multiple stances");
  }

  return [...new Set(recommendations)];
}
