import sql from "@/app/api/utils/sql";

// Handle both scalar counts (from dashboard form) and array events
function computeMetricsFromScalars(matchData) {
  const {
    takedowns = 0,
    takedownAttempts = 0,
    escapes = 0,
    escapeAttempts = 0,
    reversals = 0,
    reversalAttempts = 0,
    nearFalls = 0,
    controlTimeSeconds = 0,
    totalMatchTimeSeconds = 360,
    exposurePoints = 0,
    technicalViolations = 0,
  } = matchData;

  const takedownEfficiency =
    takedownAttempts > 0 ? (takedowns / takedownAttempts) * 100 : 0;
  const escapeRate = escapeAttempts > 0 ? (escapes / escapeAttempts) * 100 : 0;
  const reversalRate =
    reversalAttempts > 0 ? (reversals / reversalAttempts) * 100 : 0;
  const controlPercentage =
    totalMatchTimeSeconds > 0
      ? (controlTimeSeconds / totalMatchTimeSeconds) * 100
      : 0;

  const takedownScore = Math.min(100, takedownEfficiency * 0.7 + takedowns * 5);
  const controlScore = Math.min(100, controlPercentage);
  const escapeScore = Math.min(100, escapeRate);
  const reversalScore = Math.min(100, reversalRate + reversals * 10);
  const nearFallScore = Math.min(100, nearFalls * 20);
  const exposureScore = Math.min(100, exposurePoints * 15);
  const penaltyDeduction = Math.min(30, technicalViolations * 10);

  const rawBim =
    takedownScore * 0.3 +
    controlScore * 0.25 +
    escapeScore * 0.15 +
    reversalScore * 0.15 +
    nearFallScore * 0.1 +
    exposureScore * 0.05 -
    penaltyDeduction;
  const bimScore = Math.max(0, Math.min(100, rawBim));
  const tier =
    bimScore >= 85
      ? "elite"
      : bimScore >= 70
        ? "advanced"
        : bimScore >= 55
          ? "competitive"
          : bimScore >= 40
            ? "developing"
            : "beginner";
  const pinProbability = Math.min(
    95,
    nearFalls * 15 + controlPercentage * 0.4 + exposurePoints * 8,
  );
  const staminaScore = Math.max(
    10,
    100 - technicalViolations * 5 - (totalMatchTimeSeconds / 360) * 20,
  );
  const momentum =
    (takedownScore * 0.4 + controlScore * 0.3 + reversalScore * 0.3) / 100;

  return {
    takedownEfficiency,
    escapeRate,
    reversalRate,
    controlPercentage,
    bimScore,
    tier,
    pinProbability,
    staminaScore,
    momentum,
    takedownScore,
    controlScore,
    escapeScore,
    reversalScore,
    nearFallScore,
    exposureScore,
  };
}

function computeMetricsFromArrays(matchData) {
  const {
    takedowns = [],
    escapes = [],
    reversals = [],
    nearFalls = [],
    ridingTime = 0,
    matchDuration = 360,
    periods = [],
    opponentRating = 0,
    weightClass = "",
  } = matchData;

  const takedownAttempts = takedowns.length;
  const successfulTakedowns = takedowns.filter((t) => t.successful).length;
  const takedownEfficiency =
    takedownAttempts > 0 ? (successfulTakedowns / takedownAttempts) * 100 : 0;
  const escapeAttempts = escapes.length;
  const successfulEscapes = escapes.filter((e) => e.successful).length;
  const escapeRate =
    escapeAttempts > 0 ? (successfulEscapes / escapeAttempts) * 100 : 0;
  const reversalAttempts = reversals.length;
  const successfulReversals = reversals.filter((r) => r.successful).length;
  const reversalRate =
    reversalAttempts > 0 ? (successfulReversals / reversalAttempts) * 100 : 0;
  const nearFallPoints = nearFalls.reduce(
    (sum, nf) => sum + (nf.points || 0),
    0,
  );
  const controlPercentage = (ridingTime / matchDuration) * 100;

  const takedownScore = Math.min(
    100,
    takedownEfficiency * 0.7 + successfulTakedowns * 5,
  );
  const controlScore = Math.min(100, controlPercentage);
  const escapeScore = Math.min(100, escapeRate);
  const reversalScore = Math.min(100, reversalRate + successfulReversals * 10);
  const nearFallScore = Math.min(100, nearFallPoints * 10);

  const rawBim =
    takedownScore * 0.3 +
    controlScore * 0.25 +
    escapeScore * 0.15 +
    reversalScore * 0.15 +
    nearFallScore * 0.1;
  const bimScore = Math.max(0, Math.min(100, rawBim));
  const tier =
    bimScore >= 85
      ? "elite"
      : bimScore >= 70
        ? "advanced"
        : bimScore >= 55
          ? "competitive"
          : bimScore >= 40
            ? "developing"
            : "beginner";
  const pinProbability = Math.min(
    95,
    nearFalls.filter((nf) => nf.points >= 2).length * 15 +
      controlPercentage * 0.4 +
      takedownEfficiency * 0.2,
  );
  const staminaScore =
    periods.length > 0
      ? periods.reduce((s, p) => s + (p.energyLevel || 80), 0) / periods.length
      : 80;
  const momentum =
    (takedownScore * 0.4 + controlScore * 0.3 + reversalScore * 0.3) / 100;

  return {
    takedownEfficiency,
    escapeRate,
    reversalRate,
    controlPercentage,
    bimScore,
    tier,
    pinProbability,
    staminaScore,
    momentum,
    takedownScore,
    controlScore,
    escapeScore,
    reversalScore,
    nearFallScore,
    exposureScore: 0,
  };
}

// --- STAMINA CALCULATION ---
function calculateStaminaScore(periodAnalysis) {
  if (!periodAnalysis || periodAnalysis.length === 0) return 100;

  const avgEnergy =
    periodAnalysis.reduce((sum, p) => sum + p.energyLevel, 0) /
    periodAnalysis.length;

  // Consistency bonus (less variation = better stamina)
  const energyVariation =
    Math.max(...periodAnalysis.map((p) => p.energyLevel)) -
    Math.min(...periodAnalysis.map((p) => p.energyLevel));
  const consistencyBonus = Math.max(0, 20 - energyVariation);

  return Math.min(100, avgEnergy + consistencyBonus);
}

// --- FATIGUE RATE ---
function calculateFatigueRate(periodAnalysis) {
  if (!periodAnalysis || periodAnalysis.length < 2) return 0;

  let totalDrop = 0;
  for (let i = 1; i < periodAnalysis.length; i++) {
    const drop =
      periodAnalysis[i - 1].energyLevel - periodAnalysis[i].energyLevel;
    totalDrop += Math.max(0, drop);
  }

  return totalDrop / (periodAnalysis.length - 1);
}

// --- MOMENTUM CALCULATION ---
function calculateMomentum(periodAnalysis, takedowns, escapes, reversals) {
  let momentumScore = 0;

  // Period-by-period momentum
  periodAnalysis.forEach((period) => {
    if (period.pointDifferential > 0)
      momentumScore += period.pointDifferential * 2;
    if (period.efficiency > 70) momentumScore += 10;
  });

  // Recent action momentum (last 30 seconds)
  const recentActions = [...takedowns, ...escapes, ...reversals].filter(
    (action) => action.timestamp && action.timestamp > Date.now() - 30000,
  );
  momentumScore += recentActions.filter((a) => a.successful).length * 5;

  return Math.min(100, Math.max(-100, momentumScore));
}

// --- PIN PROBABILITY ---
function calculatePinProbability({
  nearFalls,
  controlPercentage,
  takedownEfficiency,
  opponentRating,
}) {
  let probability = 0;

  // Near fall history
  const recentNearFalls = nearFalls.filter((nf) => nf.points >= 2).length;
  probability += recentNearFalls * 15;

  // Control dominance
  if (controlPercentage > 70) probability += 25;
  else if (controlPercentage > 50) probability += 15;

  // Offensive efficiency
  if (takedownEfficiency > 60) probability += 20;

  // Opponent rating adjustment
  const ratingAdjustment = (100 - opponentRating) / 10;
  probability += ratingAdjustment;

  return Math.min(100, Math.max(0, probability));
}

// --- WRESTLING PERFORMANCE SCORE ---
function calculateWrestlingPerformanceScore(metrics) {
  const {
    takedownEfficiency,
    escapeRate,
    reversalRate,
    controlPercentage,
    staminaScore,
    momentum,
    pinProbability,
  } = metrics;

  let score = 0;

  score += (takedownEfficiency / 100) * 25;
  score += (escapeRate / 100) * 15;
  score += (reversalRate / 100) * 10;
  score += (controlPercentage / 100) * 20;
  score += (staminaScore / 100) * 15;
  score += ((momentum + 100) / 200) * 10; // Normalize from -100/100 to 0-1
  score += (pinProbability / 100) * 5;

  return Math.min(100, Math.max(0, score));
}

// --- BIM CONVERSION ---
function convertToBIM({
  performanceScore,
  opponentRating,
  weightClass,
  sessionType,
}) {
  let bim = performanceScore;

  // Opponent difficulty multiplier
  if (opponentRating > 80) bim *= 1.2;
  else if (opponentRating > 60) bim *= 1.1;
  else if (opponentRating < 40) bim *= 0.9;

  // Session type multiplier
  if (sessionType === "competition") bim *= 1.3;
  else if (sessionType === "practice") bim *= 1.0;
  else if (sessionType === "conditioning") bim *= 0.8;

  return Math.min(100, bim);
}

// --- COACHING INSIGHTS ---
function generateCoachingInsights(metrics) {
  const insights = [];

  if (metrics.takedownEfficiency < 40) {
    insights.push({
      area: "Offense",
      severity: "high",
      message: "Low takedown efficiency - focus on setup and chain wrestling",
    });
  }

  if (metrics.escapeRate < 50) {
    insights.push({
      area: "Bottom Position",
      severity: "high",
      message: "Struggles escaping - practice stand-ups and switches",
    });
  }

  if (metrics.controlPercentage < 30) {
    insights.push({
      area: "Top Position",
      severity: "medium",
      message: "Poor riding time - work on breakdowns and control",
    });
  }

  if (metrics.fatigueRate > 15) {
    insights.push({
      area: "Conditioning",
      severity: "high",
      message: "High fatigue rate - increase conditioning training",
    });
  }

  if (
    metrics.techniqueBreakdown.offense.singleLeg === 0 &&
    metrics.techniqueBreakdown.offense.doubleLeg === 0
  ) {
    insights.push({
      area: "Technique Diversity",
      severity: "medium",
      message: "Limited offensive techniques - expand attack variety",
    });
  }

  return insights;
}

// --- RECOMMENDATIONS ---
function generateRecommendations(insights) {
  const recommendations = [];

  insights.forEach((insight) => {
    if (insight.area === "Offense") {
      recommendations.push("Drill level changes and penetration steps");
      recommendations.push("Practice chain wrestling sequences");
    }
    if (insight.area === "Bottom Position") {
      recommendations.push("Stand-up drills with hand control");
      recommendations.push("Switch mechanics and timing");
    }
    if (insight.area === "Conditioning") {
      recommendations.push("High-intensity interval training");
      recommendations.push("Live wrestling with shorter rest periods");
    }
  });

  return [...new Set(recommendations)]; // Remove duplicates
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { athleteId, matchId, matchData = {}, sessionType = "match" } = body;

    if (!athleteId)
      return Response.json({ error: "athleteId is required" }, { status: 400 });

    // Detect scalar vs array input
    const isScalar =
      typeof matchData.takedowns === "number" ||
      matchData.takedowns === undefined;
    const computed = isScalar
      ? computeMetricsFromScalars(matchData)
      : computeMetricsFromArrays(matchData);

    const {
      takedownEfficiency,
      escapeRate,
      reversalRate,
      controlPercentage,
      bimScore,
      tier,
      pinProbability,
      staminaScore,
      momentum,
      takedownScore,
      controlScore,
      escapeScore,
      reversalScore,
      nearFallScore,
      exposureScore,
    } = computed;

    const breakdown = {
      takedownComponent: parseFloat(takedownScore.toFixed(2)),
      controlComponent: parseFloat(controlScore.toFixed(2)),
      escapeComponent: parseFloat(escapeScore.toFixed(2)),
      reversalComponent: parseFloat(reversalScore.toFixed(2)),
      nearFallComponent: parseFloat(nearFallScore.toFixed(2)),
      exposureComponent: parseFloat((exposureScore || 0).toFixed(2)),
    };

    const performanceMetrics = {
      takedownEfficiency: parseFloat(takedownEfficiency.toFixed(2)),
      escapeRate: parseFloat(escapeRate.toFixed(2)),
      controlPercentage: parseFloat(controlPercentage.toFixed(2)),
      reversalRate: parseFloat(reversalRate.toFixed(2)),
      pinProbability: parseFloat(pinProbability.toFixed(2)),
      staminaScore: parseFloat(staminaScore.toFixed(2)),
      momentum: parseFloat(momentum.toFixed(4)),
    };

    const periodAnalysis = [
      {
        period: 1,
        score: parseFloat(Math.min(100, bimScore * 1.1).toFixed(1)),
        focus: "Takedowns",
        energyLevel: 95,
      },
      {
        period: 2,
        score: parseFloat(Math.min(100, bimScore * 0.95).toFixed(1)),
        focus: "Control",
        energyLevel: 85,
      },
      {
        period: 3,
        score: parseFloat(Math.min(100, bimScore * 0.85).toFixed(1)),
        focus: "Escapes",
        energyLevel: 75,
      },
    ];

    const insights = [];
    if (takedownEfficiency >= 60)
      insights.push({
        type: "strength",
        metric: "Takedown Efficiency",
        message: `Excellent takedown efficiency at ${takedownEfficiency.toFixed(1)}%.`,
        recommendation: "Maintain aggressive stance to capitalize.",
      });
    else if (takedownEfficiency < 40 && takedownEfficiency > 0)
      insights.push({
        type: "weakness",
        metric: "Takedown Efficiency",
        message: `Low takedown efficiency at ${takedownEfficiency.toFixed(1)}%.`,
        recommendation: "Focus on set-up combinations and level changes.",
      });
    if (controlPercentage >= 60)
      insights.push({
        type: "strength",
        metric: "Control Time",
        message: `Superior mat control at ${controlPercentage.toFixed(1)}%.`,
        recommendation: "Leverage control time to wear down opponent.",
      });
    else if (controlPercentage < 30 && controlPercentage > 0)
      insights.push({
        type: "weakness",
        metric: "Control Time",
        message: `Limited mat control at ${controlPercentage.toFixed(1)}%.`,
        recommendation: "Work on top-position breakdowns and leg rides.",
      });
    if ((matchData.nearFalls || 0) >= 2 || pinProbability > 40)
      insights.push({
        type: "strength",
        metric: "Near Falls / Pin Threat",
        message: `High pin probability at ${pinProbability.toFixed(1)}%.`,
        recommendation: "Continue working near-fall sequences.",
      });
    if ((matchData.technicalViolations || 0) > 0)
      insights.push({
        type: "warning",
        metric: "Violations",
        message: `${matchData.technicalViolations} violation(s) impacting BIM score.`,
        recommendation: "Focus on legal technique.",
      });

    try {
      await sql`INSERT INTO asset_simulations (athlete_id, asset_value, roi_projection, risk_score, simulation_data, valuation_factors)
        VALUES (
          ${athleteId},
          ${bimScore * 1000},
          ${takedownEfficiency / 100},
          ${1 - staminaScore / 100},
          ${JSON.stringify({ sessionType, bimScore, tier, sport: "wrestling" })},
          ${JSON.stringify({ matchData, athleteId })}
        )`;
    } catch (dbErr) {
      console.error("DB insert error (wrestling):", dbErr.message);
    }

    return Response.json({
      success: true,
      athleteId,
      matchId,
      sessionType,
      bimScore: parseFloat(bimScore.toFixed(2)),
      tier,
      performanceMetrics,
      breakdown,
      periodAnalysis,
      pinProbability: parseFloat(pinProbability.toFixed(2)),
      staminaScore: parseFloat(staminaScore.toFixed(2)),
      momentum: parseFloat(momentum.toFixed(4)),
      insights,
      recommendations: insights
        .filter((i) => i.type !== "strength")
        .map((i) => i.recommendation),
      metrics: performanceMetrics,
    });
  } catch (error) {
    console.error("Wrestling performance tracking error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
