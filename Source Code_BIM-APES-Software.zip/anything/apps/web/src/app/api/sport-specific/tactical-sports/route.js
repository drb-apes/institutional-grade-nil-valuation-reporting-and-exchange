import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Sport-Specific Module
 * Rugby / Soccer / Basketball Tactical Efficiency Analyzer
 *
 * Analyzes:
 * - Tactical efficiency score
 * - Territory/court control
 * - Possession quality
 * - Defensive pressure index
 * - Transition speed
 * - Decision-making quality
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athleteId,
      sessionId,
      sport, // rugby, soccer, basketball
      gameData = {},
      trackingData = {},
      tacticalData = {},
      biometricData = {},
    } = body;

    if (!athleteId || !sport) {
      return Response.json(
        {
          error: "Athlete ID and sport type are required",
        },
        { status: 400 },
      );
    }

    // --- TERRITORIAL CONTROL ---
    const territorialControl = analyzeTerritorialControl(
      sport,
      trackingData,
      gameData,
    );

    // --- POSSESSION QUALITY ---
    const possessionQuality = analyzePossessionQuality(
      sport,
      gameData,
      tacticalData,
    );

    // --- DEFENSIVE METRICS ---
    const defensiveMetrics = analyzeDefensivePressure(
      sport,
      gameData,
      trackingData,
    );

    // --- TRANSITION ANALYSIS ---
    const transitionMetrics = analyzeTransitions(sport, gameData, trackingData);

    // --- DECISION MAKING ---
    const decisionMaking = analyzeDecisionMaking(sport, gameData, tacticalData);

    // --- PHYSICAL METRICS ---
    const physicalMetrics = analyzePhysicalOutput(
      sport,
      trackingData,
      biometricData,
    );

    // --- TACTICAL EFFICIENCY SCORE ---
    const tacticalScore = calculateTacticalEfficiencyScore({
      sport,
      territorialControl,
      possessionQuality,
      defensiveMetrics,
      transitionMetrics,
      decisionMaking,
      physicalMetrics,
    });

    // --- BIM INTEGRATION ---
    const bimScore = calculateTacticalBIMScore(tacticalScore, sport);

    // --- NIL IMPACT ---
    const nilImpact = calculateNILImpact(bimScore, gameData, sport);

    // --- TACTICAL INSIGHTS ---
    const insights = generateTacticalInsights({
      sport,
      territorialControl,
      possessionQuality,
      defensiveMetrics,
      transitionMetrics,
      decisionMaking,
    });

    // --- DEVELOPMENT PLAN ---
    const developmentPlan = generateDevelopmentPlan({
      sport,
      tacticalScore,
      bimScore,
    });

    return Response.json({
      success: true,
      athlete: {
        id: athleteId,
        sessionId,
        sport,
      },
      performance: {
        territorialControl,
        possessionQuality,
        defensiveMetrics,
        transitionMetrics,
        decisionMaking,
        physicalMetrics,
      },
      tactical: {
        overallScore: tacticalScore.overall,
        breakdown: tacticalScore.breakdown,
        tier: tacticalScore.tier,
      },
      bim: {
        overallScore: bimScore.overall,
        percentile: bimScore.percentile,
        tier: bimScore.tier,
      },
      nil: nilImpact,
      insights,
      developmentPlan,
      metadata: {
        analyzedAt: new Date().toISOString(),
        sport,
        sessionType: gameData.sessionType || "match",
      },
    });
  } catch (error) {
    console.error("Tactical sports error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- TERRITORIAL CONTROL ---

function analyzeTerritorialControl(sport, trackingData, gameData) {
  const {
    positionHeatmap = {},
    attackingThirdTime = 0,
    middleThirdTime = 0,
    defensiveThirdTime = 0,
    totalGameTime = 5400, // 90 minutes for soccer/rugby, 48 min for basketball
  } = trackingData;

  let attackingPercentage = 0;
  let middlePercentage = 0;
  let defensivePercentage = 0;

  if (sport === "basketball") {
    // Basketball uses half-court metrics
    const offensiveHalfTime = attackingThirdTime;
    const defensiveHalfTime = defensiveThirdTime;
    attackingPercentage =
      totalGameTime > 0 ? (offensiveHalfTime / totalGameTime) * 100 : 0;
    defensivePercentage =
      totalGameTime > 0 ? (defensiveHalfTime / totalGameTime) * 100 : 0;
  } else {
    // Rugby/Soccer use thirds
    attackingPercentage =
      totalGameTime > 0 ? (attackingThirdTime / totalGameTime) * 100 : 0;
    middlePercentage =
      totalGameTime > 0 ? (middleThirdTime / totalGameTime) * 100 : 0;
    defensivePercentage =
      totalGameTime > 0 ? (defensiveThirdTime / totalGameTime) * 100 : 0;
  }

  const territoryScore = attackingPercentage * 1.5 + middlePercentage * 0.5;

  return {
    attackingPercentage: Math.round(attackingPercentage * 10) / 10,
    middlePercentage: Math.round(middlePercentage * 10) / 10,
    defensivePercentage: Math.round(defensivePercentage * 10) / 10,
    territoryScore: Math.round(territoryScore * 10) / 10,
    dominance:
      territoryScore > 60 ? "high" : territoryScore > 40 ? "balanced" : "low",
  };
}

// --- POSSESSION QUALITY ---

function analyzePossessionQuality(sport, gameData, tacticalData) {
  const {
    totalPossessions = 0,
    successfulPossessions = 0,
    turnovers = 0,
    assists = 0,
    keyPasses = 0,
    passCompletionRate = 0,
    progressivePasses = 0,
    creativeActions = 0,
  } = gameData;

  const possessionEfficiency =
    totalPossessions > 0 ? (successfulPossessions / totalPossessions) * 100 : 0;

  const turnoverRate =
    totalPossessions > 0 ? (turnovers / totalPossessions) * 100 : 0;

  const creativityScore = assists * 3 + keyPasses * 2 + creativeActions;

  const possessionQualityScore =
    possessionEfficiency * 0.4 +
    (100 - turnoverRate) * 0.3 +
    passCompletionRate * 0.2 +
    Math.min(creativityScore, 100) * 0.1;

  return {
    possessionEfficiency: Math.round(possessionEfficiency * 10) / 10,
    turnoverRate: Math.round(turnoverRate * 10) / 10,
    passCompletionRate: Math.round(passCompletionRate * 10) / 10,
    assists,
    keyPasses,
    progressivePasses,
    creativeActions,
    creativityScore: Math.round(creativityScore * 10) / 10,
    possessionQualityScore: Math.round(possessionQualityScore * 10) / 10,
  };
}

// --- DEFENSIVE PRESSURE ---

function analyzeDefensivePressure(sport, gameData, trackingData) {
  const {
    tackles = 0,
    tackleSuccess = 0,
    interceptions = 0,
    blocks = 0,
    pressures = 0,
    recoveries = 0,
    defensiveActions = 0,
  } = gameData;

  const tackleSuccessRate = tackles > 0 ? (tackleSuccess / tackles) * 100 : 0;

  const defensiveIntensity =
    tackles + interceptions + blocks + pressures + recoveries;

  const pressureIndex =
    tackleSuccessRate * 0.3 +
    interceptions * 0.25 +
    blocks * 0.2 +
    pressures * 0.15 +
    recoveries * 0.1;

  return {
    tackles,
    tackleSuccessRate: Math.round(tackleSuccessRate * 10) / 10,
    interceptions,
    blocks,
    pressures,
    recoveries,
    defensiveIntensity,
    pressureIndex: Math.round(pressureIndex * 10) / 10,
    defensiveImpact:
      pressureIndex > 70 ? "high" : pressureIndex > 40 ? "medium" : "low",
  };
}

// --- TRANSITIONS ---

function analyzeTransitions(sport, gameData, trackingData) {
  const {
    counterAttacks = 0,
    counterAttackSuccess = 0,
    fastBreaks = 0,
    fastBreakSuccess = 0,
    transitionSpeed = 0, // seconds
    defensiveTransitions = 0,
    attackingTransitions = 0,
  } = gameData;

  const counterEfficiency =
    counterAttacks > 0 ? (counterAttackSuccess / counterAttacks) * 100 : 0;

  const fastBreakEfficiency =
    fastBreaks > 0 ? (fastBreakSuccess / fastBreaks) * 100 : 0;

  const transitionQuality =
    counterEfficiency * 0.4 +
    fastBreakEfficiency * 0.4 +
    (10 - Math.min(transitionSpeed, 10)) * 10 * 0.2; // Lower time = better

  return {
    counterAttacks,
    counterEfficiency: Math.round(counterEfficiency * 10) / 10,
    fastBreaks,
    fastBreakEfficiency: Math.round(fastBreakEfficiency * 10) / 10,
    transitionSpeed: Math.round(transitionSpeed * 10) / 10,
    transitionQuality: Math.round(transitionQuality * 10) / 10,
    explosiveness:
      transitionQuality > 70
        ? "high"
        : transitionQuality > 50
          ? "medium"
          : "developing",
  };
}

// --- DECISION MAKING ---

function analyzeDecisionMaking(sport, gameData, tacticalData) {
  const {
    goodDecisions = 0,
    poorDecisions = 0,
    riskTaking = 0,
    conservativePlay = 0,
    situationalAwareness = 0, // 0-100 score
    adaptability = 0, // 0-100 score
  } = tacticalData;

  const totalDecisions = goodDecisions + poorDecisions;
  const decisionAccuracy =
    totalDecisions > 0 ? (goodDecisions / totalDecisions) * 100 : 0;

  const riskBalance =
    riskTaking > 0 && conservativePlay > 0
      ? (Math.min(riskTaking, conservativePlay) /
          Math.max(riskTaking, conservativePlay)) *
        100
      : 50;

  const decisionMakingScore =
    decisionAccuracy * 0.4 +
    situationalAwareness * 0.3 +
    adaptability * 0.2 +
    riskBalance * 0.1;

  return {
    decisionAccuracy: Math.round(decisionAccuracy * 10) / 10,
    situationalAwareness: Math.round(situationalAwareness * 10) / 10,
    adaptability: Math.round(adaptability * 10) / 10,
    riskBalance: Math.round(riskBalance * 10) / 10,
    decisionMakingScore: Math.round(decisionMakingScore * 10) / 10,
    intelligence:
      decisionMakingScore > 80
        ? "elite"
        : decisionMakingScore > 65
          ? "high"
          : "developing",
  };
}

// --- PHYSICAL OUTPUT ---

function analyzePhysicalOutput(sport, trackingData, biometricData) {
  const {
    totalDistance = 0, // meters
    sprintDistance = 0,
    highIntensityRuns = 0,
    accelerations = 0,
    decelerations = 0,
    avgSpeed = 0, // km/h
    topSpeed = 0,
  } = trackingData;

  const { avgHeartRate = 0, peakHeartRate = 0, workRate = 0 } = biometricData;

  const physicalOutput =
    totalDistance / 100 +
    sprintDistance / 10 +
    highIntensityRuns * 2 +
    accelerations * 0.5 +
    decelerations * 0.5;

  const athleticism = topSpeed * 2 + avgSpeed * 1.5;

  return {
    totalDistance,
    sprintDistance,
    highIntensityRuns,
    accelerations,
    decelerations,
    avgSpeed: Math.round(avgSpeed * 10) / 10,
    topSpeed: Math.round(topSpeed * 10) / 10,
    physicalOutput: Math.round(physicalOutput * 10) / 10,
    athleticism: Math.round(athleticism * 10) / 10,
    workRate: Math.round(workRate * 10) / 10,
  };
}

// --- TACTICAL EFFICIENCY SCORE ---

function calculateTacticalEfficiencyScore(data) {
  const {
    sport,
    territorialControl,
    possessionQuality,
    defensiveMetrics,
    transitionMetrics,
    decisionMaking,
    physicalMetrics,
  } = data;

  // Sport-specific weighting
  let weights = {};
  if (sport === "basketball") {
    weights = {
      territorial: 0.1,
      possession: 0.25,
      defensive: 0.2,
      transition: 0.25,
      decision: 0.15,
      physical: 0.05,
    };
  } else if (sport === "rugby") {
    weights = {
      territorial: 0.2,
      possession: 0.15,
      defensive: 0.25,
      transition: 0.15,
      decision: 0.15,
      physical: 0.1,
    };
  } else {
    // soccer
    weights = {
      territorial: 0.15,
      possession: 0.25,
      defensive: 0.2,
      transition: 0.15,
      decision: 0.15,
      physical: 0.1,
    };
  }

  const overall =
    territorialControl.territoryScore * weights.territorial +
    possessionQuality.possessionQualityScore * weights.possession +
    defensiveMetrics.pressureIndex * weights.defensive +
    transitionMetrics.transitionQuality * weights.transition +
    decisionMaking.decisionMakingScore * weights.decision +
    Math.min(physicalMetrics.physicalOutput, 100) * weights.physical;

  const tier =
    overall >= 85
      ? "elite"
      : overall >= 75
        ? "tier_1"
        : overall >= 65
          ? "tier_2"
          : overall >= 55
            ? "tier_3"
            : "developing";

  return {
    overall: Math.round(overall * 10) / 10,
    breakdown: {
      territorial: Math.round(territorialControl.territoryScore * 10) / 10,
      possession:
        Math.round(possessionQuality.possessionQualityScore * 10) / 10,
      defensive: Math.round(defensiveMetrics.pressureIndex * 10) / 10,
      transition: Math.round(transitionMetrics.transitionQuality * 10) / 10,
      decision: Math.round(decisionMaking.decisionMakingScore * 10) / 10,
      physical:
        Math.round(Math.min(physicalMetrics.physicalOutput, 100) * 10) / 10,
    },
    tier,
    weights,
  };
}

// --- BIM SCORE ---

function calculateTacticalBIMScore(tacticalScore, sport) {
  const overall = tacticalScore.overall;

  const percentile =
    overall >= 90
      ? 99
      : overall >= 80
        ? 90
        : overall >= 70
          ? 75
          : overall >= 60
            ? 50
            : overall >= 50
              ? 25
              : 10;

  return {
    overall: Math.round(overall * 10) / 10,
    percentile,
    tier: tacticalScore.tier,
    sport,
  };
}

// --- NIL IMPACT ---

function calculateNILImpact(bimScore, gameData, sport) {
  const baseValue = 50000;
  const scoreMultiplier = bimScore.overall / 70;
  const sportMultiplier =
    sport === "basketball" ? 1.3 : sport === "soccer" ? 1.2 : 1.0;
  const outcomeMultiplier = gameData.won ? 1.15 : 0.95;

  const currentNILValue =
    baseValue * scoreMultiplier * sportMultiplier * outcomeMultiplier;
  const nilChange = currentNILValue - baseValue;

  return {
    currentNILValue: Math.round(currentNILValue),
    baseNILValue: baseValue,
    nilChange: Math.round(nilChange),
    nilChangePercent: Math.round((nilChange / baseValue) * 100 * 10) / 10,
    marketability: bimScore.tier,
  };
}

// --- INSIGHTS ---

function generateTacticalInsights(data) {
  const insights = [];

  if (data.possessionQuality.turnoverRate > 20) {
    insights.push({
      category: "Possession",
      severity: "high",
      finding: "High turnover rate impacting possession quality",
      recommendation:
        "Focus on ball security and decision-making under pressure",
    });
  }

  if (data.defensiveMetrics.tackleSuccessRate < 70) {
    insights.push({
      category: "Defense",
      severity: "medium",
      finding: "Tackle success rate below optimal",
      recommendation: "Work on timing and positioning in defensive situations",
    });
  }

  if (data.transitionMetrics.transitionQuality < 60) {
    insights.push({
      category: "Transitions",
      severity: "medium",
      finding: "Transition efficiency needs improvement",
      recommendation: "Practice quick decision-making in transition scenarios",
    });
  }

  if (data.decisionMaking.decisionAccuracy < 75) {
    insights.push({
      category: "Tactical IQ",
      severity: "high",
      finding: "Decision-making accuracy below target",
      recommendation: "Study game situations and improve pattern recognition",
    });
  }

  return insights;
}

// --- DEVELOPMENT PLAN ---

function generateDevelopmentPlan(data) {
  const { sport, tacticalScore, bimScore } = data;

  const priorities = [];

  Object.entries(tacticalScore.breakdown).forEach(([area, score]) => {
    if (score < 70) {
      priorities.push({
        area: area.charAt(0).toUpperCase() + area.slice(1),
        current: score,
        target: 75,
        gap: 75 - score,
        focus: "high",
      });
    }
  });

  priorities.sort((a, b) => b.gap - a.gap);

  return {
    currentTier: bimScore.tier,
    targetTier: getNextTier(bimScore.tier),
    priorities: priorities.slice(0, 3),
    sport,
  };
}

function getNextTier(currentTier) {
  const tiers = ["developing", "tier_3", "tier_2", "tier_1", "elite"];
  const index = tiers.indexOf(currentTier);
  return index < tiers.length - 1 ? tiers[index + 1] : "elite";
}
