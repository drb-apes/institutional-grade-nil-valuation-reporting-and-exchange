import sql from "@/app/api/utils/sql";

/**
 * Racket Sports Spike Analysis
 *
 * For: Tennis, Pickleball
 *
 * Analyzes performance spikes and momentum shifts:
 * - Serve quality and consistency
 * - Return effectiveness
 * - Rally dominance
 * - Pressure point performance
 * - Momentum shift detection
 * - Shot placement accuracy
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const { athleteId, sport = "tennis", matchId, matchData = {} } = body;

    // --- SCALAR INPUT DETECTION ---
    const isScalarInput =
      typeof matchData.firstServePercentage === "number" ||
      typeof matchData.acesCount === "number";
    if (isScalarInput) {
      const {
        firstServePercentage = 65,
        firstServePointsWon = 70,
        secondServePointsWon = 50,
        acesCount = 0,
        doubleFaults = 0,
        winnersCount = 0,
        unforcedErrors = 0,
        breakPointsConverted = 0,
        breakPointsTotal = 0,
        totalPoints = 0,
        pointsWon = 0,
      } = matchData;

      const winPercentage =
        totalPoints > 0 ? (pointsWon / totalPoints) * 100 : 0;
      const breakPointConversion =
        breakPointsTotal > 0
          ? (breakPointsConverted / breakPointsTotal) * 100
          : 0;
      const winnerToErrorRatio =
        unforcedErrors > 0 ? winnersCount / unforcedErrors : winnersCount;
      const acePenalty = doubleFaults * 3;

      const isFastPaced = ["pickleball", "badminton", "table_tennis"].includes(
        sport,
      );
      const serveWeight = sport === "tennis" ? 0.3 : 0.2;
      const aggressionWeight = isFastPaced ? 0.3 : 0.2;
      const pressureWeight = 0.25;
      const consistencyWeight =
        1 - serveWeight - aggressionWeight - pressureWeight;

      const serveScore = Math.min(
        100,
        Math.max(
          0,
          firstServePercentage * 0.5 +
            firstServePointsWon * 0.3 +
            secondServePointsWon * 0.2 -
            acePenalty,
        ),
      );
      const aggressionScore = Math.min(
        100,
        winnersCount * 2 + winnerToErrorRatio * 10,
      );
      const pressureScore = Math.min(
        100,
        Math.max(0, breakPointConversion + winPercentage * 0.4),
      );
      const consistencyScore = Math.min(
        100,
        Math.max(0, 100 - unforcedErrors * 2 + acesCount * 3),
      );

      const spikeScore = parseFloat(
        Math.min(
          100,
          Math.max(
            0,
            serveScore * serveWeight +
              aggressionScore * aggressionWeight +
              pressureScore * pressureWeight +
              consistencyScore * consistencyWeight,
          ),
        ).toFixed(2),
      );
      const performanceScore = spikeScore;
      const bimScore = parseFloat(Math.min(100, spikeScore * 1.08).toFixed(2));
      const tier =
        bimScore >= 85
          ? "elite"
          : bimScore >= 70
            ? "advanced"
            : bimScore >= 55
              ? "competitive"
              : bimScore >= 40
                ? "developing"
                : "emerging";

      const momentumPeaks = [];
      if (firstServePointsWon >= 75)
        momentumPeaks.push({
          phase: "Service Games",
          intensity: "HIGH",
          label: "Dominant service hold",
        });
      if (breakPointConversion >= 50)
        momentumPeaks.push({
          phase: "Break Points",
          intensity: "HIGH",
          label: "Clinical break point conversion",
        });
      if (winnersCount > unforcedErrors * 1.5)
        momentumPeaks.push({
          phase: "Rally Play",
          intensity: "MEDIUM",
          label: "Aggressive baseline play",
        });

      const insights = [];
      if (firstServePercentage >= 65)
        insights.push({
          type: "strength",
          area: "Serve",
          message: `First serve in at ${firstServePercentage.toFixed(
            1,
          )}% — solid foundation.`,
          recommendation: "Vary placement to keep opponents guessing.",
        });
      else
        insights.push({
          type: "weakness",
          area: "Serve",
          message: `First serve at ${firstServePercentage.toFixed(
            1,
          )}% is below target (65%).`,
          recommendation: "Focus on consistent ball toss and shoulder turn.",
        });
      if (breakPointsTotal > 0) {
        if (breakPointConversion >= 50)
          insights.push({
            type: "strength",
            area: "Pressure",
            message: `${breakPointConversion.toFixed(
              1,
            )}% break point conversion is excellent.`,
            recommendation: "Maintain aggression on opponent's serve.",
          });
        else
          insights.push({
            type: "weakness",
            area: "Pressure",
            message: `Converting only ${breakPointConversion.toFixed(
              1,
            )}% of break points.`,
            recommendation: "Attack the net more on break point opportunities.",
          });
      }
      if (winnerToErrorRatio >= 1.5)
        insights.push({
          type: "strength",
          area: "Aggression",
          message: `Winner-to-error ratio of ${winnerToErrorRatio.toFixed(
            2,
          )} shows disciplined aggression.`,
          recommendation:
            "Keep attacking — the ratio supports this game style.",
        });
      else if (unforcedErrors > winnersCount)
        insights.push({
          type: "weakness",
          area: "Consistency",
          message: `${unforcedErrors} unforced errors vs ${winnersCount} winners — too many giveaways.`,
          recommendation: "Build points with depth before going for winners.",
        });

      try {
        await sql`INSERT INTO asset_simulations (athlete_id, asset_value, roi_projection, risk_score, simulation_data, valuation_factors)
          VALUES (${athleteId}, ${bimScore * 1100}, ${spikeScore / 100}, 0.12, ${JSON.stringify({ sport, bimScore: bimScore, tier, sessionType: "match", spikeScore })}, ${JSON.stringify({ matchData, sport })})`;
      } catch (dbErr) {
        console.error("DB insert error (racket):", dbErr.message);
      }

      return Response.json({
        success: true,
        athleteId,
        sport,
        matchId,
        tier,
        serve: {
          firstServePercentage,
          aces: acesCount,
          doubleFaults,
          firstServePointsWon,
          secondServePointsWon,
          score: parseFloat(serveScore.toFixed(2)),
        },
        return: { accuracy: 0, pointsWon: 0 },
        rally: { avgLength: 0, winRate: 0, longRallyWinRate: 0 },
        efficiency: {
          winners: winnersCount,
          unforcedErrors,
          winnerErrorRatio: parseFloat(winnerToErrorRatio.toFixed(2)),
          score: parseFloat(aggressionScore.toFixed(2)),
        },
        pressure: {
          breakPointConversion: parseFloat(breakPointConversion.toFixed(2)),
          gamePointConversion: 0,
          score: parseFloat(pressureScore.toFixed(2)),
        },
        consistency: { score: parseFloat(consistencyScore.toFixed(2)) },
        momentum: { shifts: [], peakPeriods: momentumPeaks },
        spikeScore,
        consistencyScore: parseFloat(consistencyScore.toFixed(2)),
        performanceScore,
        bimScore,
        insights,
        recommendations: insights
          .filter((i) => i.type !== "strength")
          .map((i) => i.recommendation),
      });
    }

    // --- ARRAY-BASED INPUT (existing logic) ---
    const {
      serves = [],
      returns = [],
      rallies = [],
      winners = [],
      unforcedErrors = [],
      forcedErrors = [],
      breakPoints = [],
      gamePoints = [],
      sets = [],
      shotData = [],
      courtCoverage = {},
    } = matchData;

    // --- SERVE METRICS ---
    const totalServes = serves.length;
    const firstServesIn = serves.filter((s) => s.number === 1 && s.in).length;
    const firstServePercentage =
      totalServes > 0 ? (firstServesIn / totalServes) * 100 : 0;

    const acesCount = serves.filter((s) => s.ace).length;
    const doubleFaults = serves.filter((s) => s.doubleFault).length;
    const firstServePointsWon = serves.filter(
      (s) => s.number === 1 && s.pointWon,
    ).length;
    const secondServePointsWon = serves.filter(
      (s) => s.number === 2 && s.pointWon,
    ).length;

    // --- RETURN METRICS ---
    const totalReturns = returns.length;
    const returnsIn = returns.filter((r) => r.in).length;
    const returnAccuracy =
      totalReturns > 0 ? (returnsIn / totalReturns) * 100 : 0;
    const returnPointsWon = returns.filter((r) => r.pointWon).length;

    // --- RALLY ANALYSIS ---
    const avgRallyLength =
      rallies.length > 0
        ? rallies.reduce((sum, r) => sum + r.shotCount, 0) / rallies.length
        : 0;
    const ralliesWon = rallies.filter((r) => r.won).length;
    const rallyWinRate =
      rallies.length > 0 ? (ralliesWon / rallies.length) * 100 : 0;

    // Long rally performance (7+ shots)
    const longRallies = rallies.filter((r) => r.shotCount >= 7);
    const longRalliesWon = longRallies.filter((r) => r.won).length;
    const longRallyWinRate =
      longRallies.length > 0 ? (longRalliesWon / longRallies.length) * 100 : 0;

    // --- WINNER/ERROR RATIO ---
    const totalWinners = winners.length;
    const totalUnforcedErrors = unforcedErrors.length;
    const winnerErrorRatio =
      totalUnforcedErrors > 0
        ? totalWinners / totalUnforcedErrors
        : totalWinners;

    // --- PRESSURE POINT PERFORMANCE ---
    const breakPointsPlayed = breakPoints.length;
    const breakPointsWon = breakPoints.filter((bp) => bp.won).length;
    const breakPointConversion =
      breakPointsPlayed > 0 ? (breakPointsWon / breakPointsPlayed) * 100 : 0;

    const gamePointsPlayed = gamePoints.length;
    const gamePointsWon = gamePoints.filter((gp) => gp.won).length;
    const gamePointConversion =
      gamePointsPlayed > 0 ? (gamePointsWon / gamePointsPlayed) * 100 : 0;

    // --- MOMENTUM ANALYSIS ---
    const momentumShifts = detectMomentumShifts(sets, rallies);
    const peakPerformancePeriods = identifyPerformanceSpikes(sets);

    // --- SHOT PLACEMENT ---
    const shotPlacement = analyzeShotPlacement(shotData, sport);

    // --- COURT COVERAGE ---
    const coverageScore = calculateCoverageScore(courtCoverage, sport);

    // --- SPIKE SCORE (Key Metric) ---
    const spikeScore = calculateSpikeScore({
      acesCount,
      totalWinners,
      breakPointConversion,
      momentumShifts,
      peakPerformancePeriods,
    });

    // --- CONSISTENCY SCORE ---
    const consistencyScore = calculateConsistencyScore({
      firstServePercentage,
      unforcedErrors: totalUnforcedErrors,
      ralliesPlayed: rallies.length,
      sets,
    });

    // --- OVERALL PERFORMANCE SCORE ---
    const performanceScore = calculateRacketPerformanceScore({
      firstServePercentage,
      firstServePointsWon,
      returnAccuracy,
      rallyWinRate,
      winnerErrorRatio,
      breakPointConversion,
      spikeScore,
      consistencyScore,
    });

    // --- BIM CONVERSION ---
    const bimScore = convertToBIM({
      performanceScore,
      sport,
      opponentLevel: matchData.opponentRating || 0,
    });

    // --- INSIGHTS ---
    const insights = generateRacketInsights({
      firstServePercentage,
      breakPointConversion,
      winnerErrorRatio,
      spikeScore,
      consistencyScore,
      sport,
    });

    return Response.json({
      success: true,
      athleteId,
      sport,
      matchId,
      serve: {
        firstServePercentage: Math.round(firstServePercentage * 100) / 100,
        aces: acesCount,
        doubleFaults,
        firstServePointsWon,
        secondServePointsWon,
      },
      return: {
        accuracy: Math.round(returnAccuracy * 100) / 100,
        pointsWon: returnPointsWon,
      },
      rally: {
        avgLength: Math.round(avgRallyLength * 100) / 100,
        winRate: Math.round(rallyWinRate * 100) / 100,
        longRallyWinRate: Math.round(longRallyWinRate * 100) / 100,
      },
      efficiency: {
        winners: totalWinners,
        unforcedErrors: totalUnforcedErrors,
        winnerErrorRatio: Math.round(winnerErrorRatio * 100) / 100,
      },
      pressure: {
        breakPointConversion: Math.round(breakPointConversion * 100) / 100,
        gamePointConversion: Math.round(gamePointConversion * 100) / 100,
      },
      momentum: {
        shifts: momentumShifts,
        peakPeriods: peakPerformancePeriods,
      },
      shotPlacement,
      courtCoverage: coverageScore,
      spikeScore: Math.round(spikeScore * 100) / 100,
      consistencyScore: Math.round(consistencyScore * 100) / 100,
      performanceScore: Math.round(performanceScore * 100) / 100,
      bimScore: Math.round(bimScore * 100) / 100,
      insights,
      recommendations: generateRacketRecommendations(insights, sport),
    });
  } catch (error) {
    console.error("Racket sports analysis error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- MOMENTUM SHIFT DETECTION ---
function detectMomentumShifts(sets, rallies) {
  const shifts = [];

  sets.forEach((set, setIdx) => {
    const { games = [] } = set;
    let consecutiveGamesWon = 0;
    let consecutiveGamesLost = 0;

    games.forEach((game, gameIdx) => {
      if (game.won) {
        consecutiveGamesWon++;
        consecutiveGamesLost = 0;

        if (consecutiveGamesWon >= 3) {
          shifts.push({
            type: "positive",
            set: setIdx + 1,
            game: gameIdx + 1,
            strength: "strong",
          });
        }
      } else {
        consecutiveGamesLost++;
        consecutiveGamesWon = 0;

        if (consecutiveGamesLost >= 3) {
          shifts.push({
            type: "negative",
            set: setIdx + 1,
            game: gameIdx + 1,
            strength: "strong",
          });
        }
      }
    });
  });

  return shifts;
}

// --- PERFORMANCE SPIKE DETECTION ---
function identifyPerformanceSpikes(sets) {
  const spikes = [];

  sets.forEach((set, setIdx) => {
    const { games = [] } = set;

    // Look for dominant stretches
    for (let i = 0; i < games.length - 2; i++) {
      const window = games.slice(i, i + 3);
      const gamesWon = window.filter((g) => g.won).length;
      const avgWinners =
        window.reduce((sum, g) => sum + (g.winners || 0), 0) / 3;

      if (gamesWon >= 3 && avgWinners >= 3) {
        spikes.push({
          set: setIdx + 1,
          startGame: i + 1,
          endGame: i + 3,
          intensity: "high",
          avgWinners: Math.round(avgWinners * 10) / 10,
        });
      }
    }
  });

  return spikes;
}

// --- SHOT PLACEMENT ANALYSIS ---
function analyzeShotPlacement(shotData, sport) {
  if (!shotData || shotData.length === 0) {
    return {
      forehand: { accuracy: 0, winners: 0 },
      backhand: { accuracy: 0, winners: 0 },
      volleys: { accuracy: 0, winners: 0 },
    };
  }

  const forehandShots = shotData.filter((s) => s.type === "forehand");
  const backhandShots = shotData.filter((s) => s.type === "backhand");
  const volleys = shotData.filter((s) => s.type === "volley");

  return {
    forehand: {
      accuracy: calculateShotAccuracy(forehandShots),
      winners: forehandShots.filter((s) => s.winner).length,
    },
    backhand: {
      accuracy: calculateShotAccuracy(backhandShots),
      winners: backhandShots.filter((s) => s.winner).length,
    },
    volleys: {
      accuracy: calculateShotAccuracy(volleys),
      winners: volleys.filter((s) => s.winner).length,
    },
  };
}

function calculateShotAccuracy(shots) {
  if (shots.length === 0) return 0;
  const successful = shots.filter((s) => s.in).length;
  return Math.round((successful / shots.length) * 100 * 100) / 100;
}

// --- COURT COVERAGE ---
function calculateCoverageScore(courtCoverage, sport) {
  const { frontCourt = 0, midCourt = 0, backCourt = 0 } = courtCoverage;

  if (sport === "pickleball") {
    // Pickleball favors front court positioning
    return frontCourt * 0.5 + midCourt * 0.3 + backCourt * 0.2;
  } else {
    // Tennis is more balanced
    return frontCourt * 0.3 + midCourt * 0.3 + backCourt * 0.4;
  }
}

// --- SPIKE SCORE ---
function calculateSpikeScore({
  acesCount,
  totalWinners,
  breakPointConversion,
  momentumShifts,
  peakPerformancePeriods,
}) {
  let score = 0;

  score += acesCount * 5;
  score += totalWinners * 2;
  score += breakPointConversion * 0.3;
  score += momentumShifts.filter((s) => s.type === "positive").length * 8;
  score += peakPerformancePeriods.length * 10;

  return Math.min(100, score);
}

// --- CONSISTENCY SCORE ---
function calculateConsistencyScore({
  firstServePercentage,
  unforcedErrors,
  ralliesPlayed,
  sets,
}) {
  let score = 100;

  // First serve penalty
  if (firstServePercentage < 60) score -= 20;
  else if (firstServePercentage < 70) score -= 10;

  // Unforced error penalty
  const errorRate = ralliesPlayed > 0 ? unforcedErrors / ralliesPlayed : 0;
  score -= errorRate * 40;

  // Set consistency
  if (sets.length >= 2) {
    const setPerformanceVariation = calculateSetVariation(sets);
    score -= setPerformanceVariation * 15;
  }

  return Math.max(0, Math.min(100, score));
}

function calculateSetVariation(sets) {
  const gamesWonPerSet = sets.map((s) => s.gamesWon || 0);
  const avg = gamesWonPerSet.reduce((a, b) => a + b, 0) / gamesWonPerSet.length;
  const variance =
    gamesWonPerSet.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) /
    gamesWonPerSet.length;
  return Math.sqrt(variance) / 6; // Normalize to 0-1
}

// --- RACKET PERFORMANCE SCORE ---
function calculateRacketPerformanceScore(metrics) {
  let score = 0;

  score += (metrics.firstServePercentage / 100) * 15;
  score += (metrics.firstServePointsWon / 20) * 10; // Assume max 20
  score += (metrics.returnAccuracy / 100) * 10;
  score += (metrics.rallyWinRate / 100) * 15;
  score += Math.min(metrics.winnerErrorRatio / 2, 1) * 15;
  score += (metrics.breakPointConversion / 100) * 15;
  score += (metrics.spikeScore / 100) * 10;
  score += (metrics.consistencyScore / 100) * 10;

  return Math.min(100, score);
}

// --- BIM CONVERSION ---
function convertToBIM({ performanceScore, sport, opponentLevel }) {
  let bim = performanceScore;

  // Opponent adjustment
  if (opponentLevel > 80) bim *= 1.2;
  else if (opponentLevel > 60) bim *= 1.1;

  // Sport-specific
  if (sport === "tennis") bim *= 1.05;

  return Math.min(100, bim);
}

// --- INSIGHTS ---
function generateRacketInsights(metrics) {
  const insights = [];
  const {
    firstServePercentage,
    breakPointConversion,
    winnerErrorRatio,
    spikeScore,
    consistencyScore,
    sport,
  } = metrics;

  if (firstServePercentage < 60) {
    insights.push({
      area: "Serve",
      severity: "high",
      message: "Low first serve percentage - practice serve consistency",
    });
  }

  if (breakPointConversion < 40) {
    insights.push({
      area: "Pressure Points",
      severity: "high",
      message: "Struggles on break points - mental toughness training needed",
    });
  }

  if (winnerErrorRatio < 0.5) {
    insights.push({
      area: "Shot Selection",
      severity: "medium",
      message: "Too many unforced errors - improve decision-making",
    });
  }

  if (spikeScore < 30) {
    insights.push({
      area: "Peak Performance",
      severity: "medium",
      message: "Limited performance spikes - develop momentum strategies",
    });
  }

  if (consistencyScore < 60) {
    insights.push({
      area: "Consistency",
      severity: "high",
      message: "Inconsistent performance - focus on fundamentals",
    });
  }

  return insights;
}

// --- RECOMMENDATIONS ---
function generateRacketRecommendations(insights, sport) {
  const recommendations = [];

  insights.forEach((insight) => {
    if (insight.area === "Serve") {
      recommendations.push("Serve technique drills with video analysis");
      recommendations.push("Target practice: hit specific zones");
    }
    if (insight.area === "Pressure Points") {
      recommendations.push("Simulate high-pressure scenarios in practice");
      recommendations.push("Mental resilience training");
    }
    if (insight.area === "Shot Selection") {
      recommendations.push("Decision-making drills");
      recommendations.push("Pattern play practice");
    }
  });

  if (sport === "pickleball") {
    recommendations.push("Kitchen line positioning drills");
    recommendations.push("Dink rally practice");
  }

  return [...new Set(recommendations)];
}
