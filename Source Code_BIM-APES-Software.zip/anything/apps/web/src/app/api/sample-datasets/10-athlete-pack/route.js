import sql from "@/app/api/utils/sql";

export async function GET() {
  // Sample Dataset Pack — 10 Athletes (7-day sessions each)
  // Data Contract: session_id, athlete_id, timestamp, index_type, value, OHLCV, coach_flags, referral_id, notes

  const sampleDataset = {
    athletes: [
      // Combat Sports Cluster
      {
        athlete_id: 1,
        name: "Marcus Rodriguez",
        sport: "mma",
        tier: "Elite",
        coalition_status: "Summit",
      },
      {
        athlete_id: 2,
        name: "Sarah Chen",
        sport: "boxing",
        tier: "Summit",
        coalition_status: "Championship",
      },
      {
        athlete_id: 3,
        name: "David Thompson",
        sport: "wrestling",
        tier: "Development",
        coalition_status: "Elite",
      },
      {
        athlete_id: 4,
        name: "Ivan Petrov",
        sport: "goalwrestling",
        tier: "Elite",
        coalition_status: "Summit",
      },
      // Racket Sports Cluster
      {
        athlete_id: 5,
        name: "Maria Santos",
        sport: "tennis",
        tier: "Elite",
        coalition_status: "Summit",
      },
      {
        athlete_id: 6,
        name: "Alex Johnson",
        sport: "pickleball",
        tier: "Development",
        coalition_status: "Elite",
      },
      // Team Sports Cluster
      {
        athlete_id: 7,
        name: "James Wilson",
        sport: "american_football",
        tier: "Summit",
        coalition_status: "Championship",
      },
      {
        athlete_id: 8,
        name: "Elena Petrov",
        sport: "soccer",
        tier: "Elite",
        coalition_status: "Summit",
      },
      {
        athlete_id: 9,
        name: "Connor O'Brien",
        sport: "rugby",
        tier: "Development",
        coalition_status: "Elite",
      },
      {
        athlete_id: 10,
        name: "Yuki Tanaka",
        sport: "basketball",
        tier: "Summit",
        coalition_status: "Championship",
      },
      // Individual Sports Cluster
      {
        athlete_id: 11,
        name: "Sofia Martinez",
        sport: "track_field",
        tier: "Elite",
        coalition_status: "Summit",
      },
      {
        athlete_id: 12,
        name: "Ryan Kim",
        sport: "swimming",
        tier: "Summit",
        coalition_status: "Championship",
      },
      // Emerging Sports Cluster
      {
        athlete_id: 13,
        name: "Luna Chen",
        sport: "esports",
        tier: "Elite",
        coalition_status: "Summit",
      },
      {
        athlete_id: 14,
        name: "Miguel Torres",
        sport: "tactical_sports",
        tier: "Development",
        coalition_status: "Elite",
      },
      {
        athlete_id: 15,
        name: "Zara Ahmed",
        sport: "combat_sports",
        tier: "Summit",
        coalition_status: "Championship",
      },
    ],
    dataset_sessions: generateSevenDayDataset(),
  };

  return Response.json({
    success: true,
    dataset_info: {
      total_athletes: 15,
      session_days: 7,
      date_range: "2025-02-24 to 2025-03-02",
      total_data_points: 315, // 15 athletes × 7 days × 3 indices
      indices_tracked: ["BVI", "Tactical", "Recovery"],
      sports_covered: [
        "MMA",
        "Boxing",
        "Wrestling",
        "Goal Wrestling",
        "Tennis",
        "Pickleball",
        "American Football",
        "Soccer",
        "Rugby",
        "Basketball",
        "Track & Field",
        "Swimming",
        "Esports",
        "Tactical Sports",
        "Combat Sports",
      ],
    },
    sample_dataset: sampleDataset,
  });
}

function generateSevenDayDataset() {
  const sessions = [];
  const dates = [
    "2025-02-24",
    "2025-02-25",
    "2025-02-26",
    "2025-02-27",
    "2025-02-28",
    "2025-03-01",
    "2025-03-02",
  ];

  // Athletes data with sport-specific baselines
  const athletes = [
    // Combat Sports Cluster
    {
      id: 1,
      sport: "mma",
      baseline_bvi: 84,
      baseline_tactical: 78,
      baseline_recovery: 72,
    },
    {
      id: 2,
      sport: "boxing",
      baseline_bvi: 89,
      baseline_tactical: 85,
      baseline_recovery: 81,
    },
    {
      id: 3,
      sport: "wrestling",
      baseline_bvi: 76,
      baseline_tactical: 73,
      baseline_recovery: 79,
    },
    {
      id: 4,
      sport: "goalwrestling",
      baseline_bvi: 72,
      baseline_tactical: 68,
      baseline_recovery: 75,
    },

    // Racket Sports Cluster
    {
      id: 5,
      sport: "tennis",
      baseline_bvi: 82,
      baseline_tactical: 80,
      baseline_recovery: 75,
    },
    {
      id: 6,
      sport: "pickleball",
      baseline_bvi: 68,
      baseline_tactical: 72,
      baseline_recovery: 70,
    },

    // Team Sports Cluster
    {
      id: 7,
      sport: "american_football",
      baseline_bvi: 87,
      baseline_tactical: 84,
      baseline_recovery: 78,
    },
    {
      id: 8,
      sport: "soccer",
      baseline_bvi: 79,
      baseline_tactical: 82,
      baseline_recovery: 77,
    },
    {
      id: 9,
      sport: "rugby",
      baseline_bvi: 75,
      baseline_tactical: 71,
      baseline_recovery: 74,
    },
    {
      id: 10,
      sport: "basketball",
      baseline_bvi: 85,
      baseline_tactical: 88,
      baseline_recovery: 80,
    },

    // Individual Sports Cluster
    {
      id: 11,
      sport: "track_field",
      baseline_bvi: 80,
      baseline_tactical: 76,
      baseline_recovery: 82,
    },
    {
      id: 12,
      sport: "swimming",
      baseline_bvi: 86,
      baseline_tactical: 83,
      baseline_recovery: 85,
    },

    // Emerging Sports Cluster
    {
      id: 13,
      sport: "esports",
      baseline_bvi: 78,
      baseline_tactical: 85,
      baseline_recovery: 65,
    },
    {
      id: 14,
      sport: "tactical_sports",
      baseline_bvi: 83,
      baseline_tactical: 87,
      baseline_recovery: 79,
    },
    {
      id: 15,
      sport: "combat_sports",
      baseline_bvi: 81,
      baseline_tactical: 77,
      baseline_recovery: 73,
    },
  ];

  let sessionId = 1;

  athletes.forEach((athlete) => {
    dates.forEach((date, dayIndex) => {
      // Generate BVI Index Session
      const bviValue = generateTrendingValue(
        athlete.baseline_bvi,
        dayIndex,
        "bvi",
      );
      sessions.push({
        session_id: sessionId++,
        athlete_id: athlete.id,
        timestamp: `${date}T08:00:00Z`,
        index_type: "BVI",
        value: bviValue,
        open: null,
        high: null,
        low: null,
        close: null,
        volume: null,
        coach_flags: generateCoachFlags(bviValue, "bvi"),
        referral_id: athlete.id < 6 ? `REF_${athlete.id}${dayIndex + 1}` : null,
        notes: generateNotes(athlete.sport, "bvi", bviValue, dayIndex),
      });

      // Generate Tactical Index Session
      const tacticalBase = generateTrendingValue(
        athlete.baseline_tactical,
        dayIndex,
        "tactical",
      );
      const tacticalOHLCV = generateOHLCV(tacticalBase);
      sessions.push({
        session_id: sessionId++,
        athlete_id: athlete.id,
        timestamp: `${date}T14:00:00Z`,
        index_type: "Tactical",
        value: null,
        open: tacticalOHLCV.open,
        high: tacticalOHLCV.high,
        low: tacticalOHLCV.low,
        close: tacticalOHLCV.close,
        volume: tacticalOHLCV.volume,
        coach_flags: generateCoachFlags(tacticalOHLCV.close, "tactical"),
        referral_id: athlete.id < 6 ? `REF_${athlete.id}${dayIndex + 1}` : null,
        notes: generateNotes(
          athlete.sport,
          "tactical",
          tacticalOHLCV.close,
          dayIndex,
        ),
      });

      // Generate Recovery Index Session
      const recoveryValue = generateTrendingValue(
        athlete.baseline_recovery,
        dayIndex,
        "recovery",
      );
      sessions.push({
        session_id: sessionId++,
        athlete_id: athlete.id,
        timestamp: `${date}T20:00:00Z`,
        index_type: "Recovery",
        value: recoveryValue,
        open: null,
        high: null,
        low: null,
        close: null,
        volume: null,
        coach_flags: generateCoachFlags(recoveryValue, "recovery"),
        referral_id: athlete.id < 6 ? `REF_${athlete.id}${dayIndex + 1}` : null,
        notes: generateNotes(
          athlete.sport,
          "recovery",
          recoveryValue,
          dayIndex,
        ),
      });
    });
  });

  return sessions;
}

function generateTrendingValue(baseline, dayIndex, indexType) {
  // Create realistic trending patterns
  const trends = {
    bvi: [0, 2, -1, 3, 1, -2, 4], // Upward trend with volatility
    tactical: [1, -1, 2, 0, 3, -1, 2], // Mixed performance
    recovery: [-2, -1, 1, 0, -3, 2, 3], // Recovery pattern
  };

  const trend = trends[indexType][dayIndex] || 0;
  const randomVariation = (Math.random() - 0.5) * 4; // ±2 point variation

  return Math.round(baseline + trend + randomVariation);
}

function generateOHLCV(baseClose) {
  const volatility = Math.random() * 6 + 2; // 2-8 point range
  const high = Math.round(baseClose + volatility);
  const low = Math.round(baseClose - volatility);
  const open = Math.round(low + Math.random() * (high - low));
  const volume = Math.round(Math.random() * 1000 + 500); // 500-1500 volume

  return { open, high, low, close: baseClose, volume };
}

function generateCoachFlags(value, indexType) {
  const flags = [];

  if (indexType === "bvi") {
    if (value >= 85) flags.push("elite_performance");
    if (value <= 65) flags.push("development_needed");
  } else if (indexType === "tactical") {
    if (value >= 80) flags.push("tactical_mastery");
    if (value <= 60) flags.push("tactical_review");
  } else if (indexType === "recovery") {
    if (value <= 50) flags.push("recovery_protocol");
    if (value >= 85) flags.push("optimal_readiness");
  }

  // Random additional flags
  if (Math.random() < 0.3) flags.push("monitor_closely");
  if (Math.random() < 0.2) flags.push("breakthrough_session");

  return flags;
}

function generateNotes(sport, indexType, value, dayIndex) {
  const noteTemplates = {
    mma: {
      bvi: [
        "Striking accuracy showing improvement",
        "Ground control time increasing",
        "Takedown defense needs work",
        "Overall fight IQ development on track",
      ],
      tactical: [
        "Pressure response excellent",
        "Position transitions smooth",
        "Gameplan execution improving",
        "Adaptability showing growth",
      ],
      recovery: [
        "Cortisol levels normalizing",
        "Sleep quality metrics good",
        "HRV showing positive trends",
        "Post-training recovery optimal",
      ],
    },
    boxing: {
      bvi: [
        "Punch efficiency trending up",
        "Ring control establishing well",
        "Defensive positioning solid",
        "Power output consistent",
      ],
      tactical: [
        "Ring generalship improving",
        "Distance management excellent",
        "Counter-punching opportunities seized",
        "Effective aggression balanced",
      ],
      recovery: [
        "Hand conditioning optimal",
        "Shoulder health maintaining",
        "Fatigue markers within range",
        "Post-bout recovery protocols effective",
      ],
    },
    wrestling: {
      bvi: [
        "Takedown efficiency improving",
        "Defensive holds strengthening",
        "Endurance building steady",
        "Technical precision advancing",
      ],
      tactical: [
        "Match strategy execution solid",
        "Position control excellent",
        "Submission defense improving",
        "Counter-wrestling developing",
      ],
      recovery: [
        "Joint stress manageable",
        "Muscle recovery on track",
        "Weight management optimal",
        "Training load balanced",
      ],
    },
    goalwrestling: {
      bvi: [
        "Goal protection rate high",
        "Positioning accuracy good",
        "Reaction time improving",
        "Coverage efficiency strong",
      ],
      tactical: [
        "Defensive reads excellent",
        "Communication clear",
        "Zone coverage effective",
        "Breakaway defense solid",
      ],
      recovery: [
        "Reflexes sharp post-session",
        "Mental fatigue low",
        "Physical readiness high",
        "Coordination maintaining",
      ],
    },
    tennis: {
      bvi: [
        "Spike power increasing",
        "Accuracy placement improving",
        "Consistency index rising",
        "Court coverage expanding",
      ],
      tactical: [
        "Shot selection optimal",
        "Point construction good",
        "Net play advancing",
        "Serve strategy effective",
      ],
      recovery: [
        "Shoulder rotation excellent",
        "Leg fatigue minimal",
        "Focus maintenance strong",
        "Hydration levels good",
      ],
    },
    pickleball: {
      bvi: [
        "Dink precision improving",
        "Volley control advancing",
        "Power shots balanced",
        "Court positioning good",
      ],
      tactical: [
        "Kitchen play excellent",
        "Third shot strategy solid",
        "Partner coordination strong",
        "Game tempo control good",
      ],
      recovery: [
        "Quick recovery between points",
        "Movement efficiency high",
        "Mental alertness sharp",
        "Energy levels sustained",
      ],
    },
    american_football: {
      bvi: [
        "Session consistency high",
        "Training frequency optimal",
        "Performance stability good",
        "Skill progression steady",
      ],
      tactical: [
        "Position reads excellent",
        "Play execution clean",
        "Route running precise",
        "Blocking technique solid",
      ],
      recovery: [
        "Impact absorption good",
        "Mobility maintenance strong",
        "Strength levels stable",
        "Conditioning on track",
      ],
    },
    soccer: {
      bvi: [
        "Field vision expanding",
        "Touch quality improving",
        "Sprint speed increasing",
        "Endurance building",
      ],
      tactical: [
        "Passing accuracy excellent",
        "Positioning awareness strong",
        "Defensive pressure good",
        "Offensive runs creative",
      ],
      recovery: [
        "Leg muscle recovery fast",
        "Cardiovascular rebound quick",
        "Mental sharpness maintained",
        "Hydration protocols effective",
      ],
    },
    rugby: {
      bvi: [
        "Contact efficiency improving",
        "Scrum power increasing",
        "Lineout accuracy good",
        "Ruck technique advancing",
      ],
      tactical: [
        "Phase play execution solid",
        "Breakdown work effective",
        "Kicking game accurate",
        "Defensive line discipline",
      ],
      recovery: [
        "Impact tolerance high",
        "Joint flexibility maintained",
        "Strength recovery rapid",
        "Bruising minimal",
      ],
    },
    basketball: {
      bvi: [
        "Court awareness sharp",
        "Shot accuracy improving",
        "Defensive stance solid",
        "Passing vision expanding",
      ],
      tactical: [
        "Pick and roll execution",
        "Fast break timing good",
        "Half court sets clean",
        "Defensive rotations smart",
      ],
      recovery: [
        "Jump recovery excellent",
        "Lateral movement fluid",
        "Shooting touch consistent",
        "Energy reserves good",
      ],
    },
    track_field: {
      bvi: [
        "Speed endurance building",
        "Form efficiency improving",
        "Power output increasing",
        "Technique refinement good",
      ],
      tactical: [
        "Race strategy solid",
        "Pacing discipline strong",
        "Lane positioning good",
        "Finish technique clean",
      ],
      recovery: [
        "Lactate clearance fast",
        "Muscle elasticity good",
        "VO2 recovery rapid",
        "Neural fatigue low",
      ],
    },
    swimming: {
      bvi: [
        "Stroke efficiency advancing",
        "Breathing rhythm optimal",
        "Turn technique clean",
        "Underwater distance good",
      ],
      tactical: [
        "Pace distribution smart",
        "Lane strategy effective",
        "Stroke rate controlled",
        "Finish timing precise",
      ],
      recovery: [
        "Shoulder flexibility excellent",
        "Core stability strong",
        "Lung capacity expanding",
        "Water feel maintained",
      ],
    },
    esports: {
      bvi: [
        "Reaction precision sharp",
        "Decision speed improving",
        "Accuracy metrics high",
        "Multitasking efficiency good",
      ],
      tactical: [
        "Map awareness excellent",
        "Team coordination strong",
        "Strategy execution clean",
        "Adaptation speed fast",
      ],
      recovery: [
        "Eye strain minimal",
        "Mental fatigue low",
        "Focus maintenance strong",
        "Hand-eye coordination sharp",
      ],
    },
    tactical_sports: {
      bvi: [
        "Team coordination excellent",
        "Strategic execution clean",
        "Communication clear",
        "Positional discipline strong",
      ],
      tactical: [
        "Formation flexibility good",
        "Counter-attack timing perfect",
        "Defensive shape maintained",
        "Transition play smooth",
      ],
      recovery: [
        "Mental processing fast",
        "Physical readiness high",
        "Team chemistry strong",
        "Leadership presence good",
      ],
    },
    combat_sports: {
      bvi: [
        "Mixed technique improving",
        "Combat awareness sharp",
        "Physical conditioning good",
        "Technique integration advancing",
      ],
      tactical: [
        "Combat strategy flexible",
        "Range management excellent",
        "Timing precision good",
        "Counter-attack readiness high",
      ],
      recovery: [
        "Multiple system recovery",
        "Injury prevention effective",
        "Adaptation rate fast",
        "Performance consistency good",
      ],
    },
  };

  const sportNotes = noteTemplates[sport] || noteTemplates.mma;
  const indexNotes = sportNotes[indexType];
  const baseNote = indexNotes[dayIndex % indexNotes.length];

  // Add performance context
  if (value >= 85) return `${baseNote} - Exceptional session`;
  if (value <= 60) return `${baseNote} - Focus area identified`;
  return baseNote;
}
