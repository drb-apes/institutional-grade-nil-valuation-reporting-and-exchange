import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { sessions } = body;

    if (!sessions || !Array.isArray(sessions)) {
      return Response.json(
        {
          error: "Sessions array required for dataset ingestion",
        },
        { status: 400 },
      );
    }

    // Batch insert sessions into video_analytics table
    // Using video_analytics as it has flexible metadata structure
    const insertedSessions = [];

    for (const session of sessions) {
      const {
        session_id,
        athlete_id,
        timestamp,
        index_type,
        value,
        open,
        high,
        low,
        close,
        volume,
        coach_flags,
        referral_id,
        notes,
      } = session;

      // Store session data with flexible metadata structure
      const insertedSession = await sql`
        INSERT INTO video_analytics (
          viewer_id,
          viewer_role,
          watch_duration_seconds,
          completion_percentage,
          interaction_data,
          viewed_at
        ) VALUES (
          ${athlete_id},
          ${index_type},
          ${session_id},
          ${value || close || 0},
          ${JSON.stringify({
            session_id,
            athlete_id,
            index_type,
            value,
            ohlcv: { open, high, low, close, volume },
            coach_flags: coach_flags || [],
            referral_id,
            notes,
            original_timestamp: timestamp,
          })},
          ${new Date(timestamp)}
        ) RETURNING *
      `;

      insertedSessions.push(insertedSession[0]);
    }

    return Response.json({
      success: true,
      ingestion_results: {
        total_sessions_processed: sessions.length,
        successful_inserts: insertedSessions.length,
        failed_inserts: sessions.length - insertedSessions.length,
        ingestion_timestamp: new Date().toISOString(),
      },
      sample_data_preview: insertedSessions.slice(0, 3).map((session) => ({
        id: session.id,
        athlete_id: session.viewer_id,
        index_type: session.viewer_role,
        session_id: session.watch_duration_seconds,
        value_or_close: session.completion_percentage,
        ingested_at: session.viewed_at,
      })),
    });
  } catch (error) {
    console.error("Dataset ingestion error:", error);
    return Response.json(
      {
        error: "Failed to ingest dataset",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// Helper endpoint to retrieve ingested sessions
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athlete_id");
    const indexType = searchParams.get("index_type");
    const limit = parseInt(searchParams.get("limit")) || 50;

    let query = sql`
      SELECT 
        id,
        viewer_id as athlete_id,
        viewer_role as index_type,
        watch_duration_seconds as session_id,
        completion_percentage as value_or_close,
        interaction_data,
        viewed_at as timestamp
      FROM video_analytics
      WHERE 1=1
    `;

    // Add filters if provided
    if (athleteId) {
      query = sql`${query} AND viewer_id = ${parseInt(athleteId)}`;
    }

    if (indexType) {
      query = sql`${query} AND viewer_role = ${indexType}`;
    }

    query = sql`${query} ORDER BY viewed_at DESC LIMIT ${limit}`;

    const sessions = await query;

    // Transform back to original format
    const transformedSessions = sessions.map((session) => {
      const metadata = session.interaction_data || {};
      return {
        session_id: session.session_id,
        athlete_id: session.athlete_id,
        timestamp: session.timestamp,
        index_type: session.index_type,
        value: metadata.value,
        open: metadata.ohlcv?.open,
        high: metadata.ohlcv?.high,
        low: metadata.ohlcv?.low,
        close: metadata.ohlcv?.close,
        volume: metadata.ohlcv?.volume,
        coach_flags: metadata.coach_flags || [],
        referral_id: metadata.referral_id,
        notes: metadata.notes,
      };
    });

    return Response.json({
      success: true,
      sessions: transformedSessions,
      query_info: {
        total_results: sessions.length,
        filters_applied: {
          athlete_id: athleteId,
          index_type: indexType,
          limit: limit,
        },
      },
    });
  } catch (error) {
    console.error("Session retrieval error:", error);
    return Response.json(
      {
        error: "Failed to retrieve sessions",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
