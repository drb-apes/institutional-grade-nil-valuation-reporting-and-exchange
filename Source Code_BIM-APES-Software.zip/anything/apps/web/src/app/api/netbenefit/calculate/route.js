import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      participantId,
      economicBenefit,
      transactionCost,
      marginCost,
      complianceCost,
      instrument = "ProductA",
      calculationMethod = "standard",
      biometricFactors,
      timeHorizon = "1Y",
    } = body;

    // Validate required fields
    if (economicBenefit === undefined || transactionCost === undefined) {
      return Response.json(
        {
          error: "Missing required fields: economicBenefit, transactionCost",
        },
        { status: 400 },
      );
    }

    // Validate participant if provided
    let participantData = null;
    if (participantId) {
      const participant = await sql`
        SELECT * FROM institutional_partners 
        WHERE api_credentials->>'participant_id' = ${participantId}
        AND integration_status = 'active'
      `;

      if (participant.length === 0) {
        return Response.json(
          { error: "Invalid or inactive participant" },
          { status: 403 },
        );
      }
      participantData = participant[0];
    }

    // Calculate base net benefit
    const totalCost =
      (transactionCost || 0) + (marginCost || 0) + (complianceCost || 0);
    const baseNetBenefit = economicBenefit - totalCost;

    // Enhanced calculation with biometric factors
    const enhancedCalculation = await calculateEnhancedNetBenefit({
      baseNetBenefit,
      economicBenefit,
      transactionCost,
      marginCost,
      complianceCost,
      instrument,
      biometricFactors,
      timeHorizon,
      participantData,
    });

    // Determine decision recommendation
    const decisionMatrix = getDecisionMatrix(
      enhancedCalculation.adjustedNetBenefit,
      enhancedCalculation.riskAdjustment,
    );

    // Log calculation for audit trail
    if (participantId) {
      await logNetBenefitCalculation({
        participantId,
        userId: session.user.id,
        calculation: enhancedCalculation,
        decision: decisionMatrix,
      });
    }

    return Response.json({
      success: true,
      calculation_id: `NBC_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      net_benefit_analysis: {
        base_calculation: {
          economic_benefit: economicBenefit,
          transaction_cost: transactionCost || 0,
          margin_cost: marginCost || 0,
          compliance_cost: complianceCost || 0,
          total_cost: totalCost,
          base_net_benefit: Math.round(baseNetBenefit * 100) / 100,
        },
        enhanced_calculation: enhancedCalculation,
        decision_matrix: decisionMatrix,
        risk_assessment: {
          overall_risk_score: enhancedCalculation.riskScore,
          volatility_adjustment: enhancedCalculation.volatilityAdjustment,
          liquidity_premium: enhancedCalculation.liquidityPremium,
          biometric_stability: enhancedCalculation.biometricStability,
        },
      },
      metadata: {
        calculation_method: calculationMethod,
        instrument: instrument,
        time_horizon: timeHorizon,
        participant_id: participantId,
        calculation_timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Net benefit calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate net benefit",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function calculateEnhancedNetBenefit({
  baseNetBenefit,
  economicBenefit,
  transactionCost,
  marginCost,
  complianceCost,
  instrument,
  biometricFactors,
  timeHorizon,
  participantData,
}) {
  // Instrument-specific adjustments
  const instrumentAdjustments = {
    ProductA: { risk_multiplier: 1.0, liquidity_factor: 0.95 },
    ProductB: { risk_multiplier: 1.2, liquidity_factor: 1.1 },
    BVI_Future: { risk_multiplier: 1.1, liquidity_factor: 1.05 },
    Tactical_Swap: { risk_multiplier: 0.9, liquidity_factor: 0.9 },
    Recovery_Note: { risk_multiplier: 1.3, liquidity_factor: 1.2 },
  };

  const adjustment =
    instrumentAdjustments[instrument] || instrumentAdjustments.ProductA;

  // Time horizon adjustments
  const timeAdjustments = {
    "1M": 0.95,
    "3M": 1.0,
    "6M": 1.05,
    "1Y": 1.1,
    "2Y": 1.2,
  };

  const timeMultiplier = timeAdjustments[timeHorizon] || 1.0;

  // Biometric factor integration
  const biometricAdjustment = await calculateBiometricAdjustment(
    biometricFactors,
    participantData,
  );

  // Market volatility factor
  const volatilityAdjustment = await getMarketVolatilityAdjustment(instrument);

  // Liquidity premium calculation
  const liquidityPremium = calculateLiquidityPremium(
    instrument,
    economicBenefit,
  );

  // Risk score calculation
  const riskScore = calculateOverallRiskScore({
    instrument,
    economicBenefit,
    transactionCost,
    marginCost,
    complianceCost,
    biometricFactors,
    participantData,
  });

  // Risk-adjusted calculation
  const riskAdjustment = Math.max(0.7, 1 - riskScore / 200); // Cap risk adjustment

  // Final adjusted net benefit
  const adjustedNetBenefit =
    baseNetBenefit *
      adjustment.risk_multiplier *
      timeMultiplier *
      riskAdjustment *
      biometricAdjustment.multiplier -
    liquidityPremium;

  return {
    adjustedNetBenefit: Math.round(adjustedNetBenefit * 100) / 100,
    baseNetBenefit: Math.round(baseNetBenefit * 100) / 100,
    adjustments: {
      instrument_risk_multiplier: adjustment.risk_multiplier,
      time_horizon_multiplier: timeMultiplier,
      risk_adjustment_factor: Math.round(riskAdjustment * 1000) / 1000,
      biometric_multiplier: biometricAdjustment.multiplier,
      liquidity_premium: Math.round(liquidityPremium * 100) / 100,
    },
    riskScore: riskScore,
    volatilityAdjustment: volatilityAdjustment,
    liquidityPremium: liquidityPremium,
    biometricStability: biometricAdjustment.stability_score,
    breakdown: {
      economic_benefit_adjusted:
        Math.round(
          economicBenefit *
            timeMultiplier *
            biometricAdjustment.multiplier *
            100,
        ) / 100,
      total_cost_adjusted:
        Math.round(
          (transactionCost + marginCost + complianceCost + liquidityPremium) *
            adjustment.risk_multiplier *
            100,
        ) / 100,
      net_improvement:
        Math.round((adjustedNetBenefit - baseNetBenefit) * 100) / 100,
    },
  };
}

async function calculateBiometricAdjustment(biometricFactors, participantData) {
  if (!biometricFactors || !participantData) {
    return { multiplier: 1.0, stability_score: 0.5 };
  }

  // Get recent biometric signals if available
  const recentSignals = await sql`
    SELECT scan_data FROM motion_scans 
    WHERE created_at >= NOW() - INTERVAL '24 hours'
    ORDER BY created_at DESC 
    LIMIT 10
  `;

  let bviAverage = 75;
  let tacticalAverage = 70;
  let recoveryAverage = 65;
  let stabilityScore = 0.5;

  if (recentSignals.length > 0) {
    const bviValues = [];
    const tacticalValues = [];
    const recoveryValues = [];

    recentSignals.forEach((signal) => {
      const data = signal.scan_data;
      if (data?.bvi_score?.overall_score)
        bviValues.push(data.bvi_score.overall_score);
      if (data?.tactical_efficiency?.overall_efficiency)
        tacticalValues.push(data.tactical_efficiency.overall_efficiency);
      if (data?.recovery_index?.overall_recovery)
        recoveryValues.push(data.recovery_index.overall_recovery);
    });

    if (bviValues.length > 0) {
      bviAverage = bviValues.reduce((a, b) => a + b, 0) / bviValues.length;
      const bviStdDev = Math.sqrt(
        bviValues.reduce((sq, n) => sq + Math.pow(n - bviAverage, 2), 0) /
          bviValues.length,
      );
      stabilityScore = Math.max(0, 1 - bviStdDev / bviAverage);
    }

    if (tacticalValues.length > 0) {
      tacticalAverage =
        tacticalValues.reduce((a, b) => a + b, 0) / tacticalValues.length;
    }

    if (recoveryValues.length > 0) {
      recoveryAverage =
        recoveryValues.reduce((a, b) => a + b, 0) / recoveryValues.length;
    }
  }

  // Calculate biometric multiplier
  const compositeScore =
    bviAverage * 0.4 + tacticalAverage * 0.35 + recoveryAverage * 0.25;
  const normalizedScore = Math.max(0, Math.min(100, compositeScore));

  // Convert to multiplier (0.8 to 1.2 range)
  const multiplier = 0.8 + (normalizedScore / 100) * 0.4;

  // Apply stability bonus/penalty
  const stabilityAdjustment = (stabilityScore - 0.5) * 0.1;
  const finalMultiplier = Math.max(
    0.7,
    Math.min(1.3, multiplier + stabilityAdjustment),
  );

  return {
    multiplier: Math.round(finalMultiplier * 1000) / 1000,
    stability_score: Math.round(stabilityScore * 1000) / 1000,
    composite_biometric_score: Math.round(normalizedScore * 100) / 100,
    component_averages: {
      bvi: Math.round(bviAverage * 100) / 100,
      tactical: Math.round(tacticalAverage * 100) / 100,
      recovery: Math.round(recoveryAverage * 100) / 100,
    },
  };
}

async function getMarketVolatilityAdjustment(instrument) {
  // Simulate market volatility based on recent trading activity
  const recentTrades = await sql`
    SELECT amount FROM treasury_transactions 
    WHERE transaction_type = 'trade_execution'
    AND created_at >= NOW() - INTERVAL '1 hour'
    ORDER BY created_at DESC 
    LIMIT 20
  `;

  if (recentTrades.length === 0) {
    return 0.02; // Default 2% volatility
  }

  const amounts = recentTrades.map((trade) => parseFloat(trade.amount));
  const mean = amounts.reduce((a, b) => a + b, 0) / amounts.length;
  const variance =
    amounts.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / amounts.length;
  const stdDev = Math.sqrt(variance);

  const volatility = mean > 0 ? Math.min(0.1, stdDev / mean) : 0.02;

  // Instrument-specific volatility multipliers
  const instrumentVolatilityMultipliers = {
    ProductA: 1.0,
    ProductB: 1.3,
    BVI_Future: 1.2,
    Tactical_Swap: 0.8,
    Recovery_Note: 1.5,
  };

  const multiplier = instrumentVolatilityMultipliers[instrument] || 1.0;
  return Math.round(volatility * multiplier * 10000) / 10000;
}

function calculateLiquidityPremium(instrument, economicBenefit) {
  // Liquidity premium as percentage of economic benefit
  const liquidityPremiums = {
    ProductA: 0.005, // 0.5%
    ProductB: 0.008, // 0.8%
    BVI_Future: 0.006, // 0.6%
    Tactical_Swap: 0.003, // 0.3%
    Recovery_Note: 0.012, // 1.2%
  };

  const premium = liquidityPremiums[instrument] || 0.005;
  return Math.round(economicBenefit * premium * 100) / 100;
}

function calculateOverallRiskScore({
  instrument,
  economicBenefit,
  transactionCost,
  marginCost,
  complianceCost,
  biometricFactors,
  participantData,
}) {
  let riskScore = 0;

  // Instrument risk
  const instrumentRisk = {
    ProductA: 20,
    ProductB: 35,
    BVI_Future: 30,
    Tactical_Swap: 15,
    Recovery_Note: 45,
  };
  riskScore += instrumentRisk[instrument] || 25;

  // Size-based risk
  if (economicBenefit > 1000000) riskScore += 25;
  else if (economicBenefit > 100000) riskScore += 15;
  else if (economicBenefit > 10000) riskScore += 5;

  // Cost ratio risk
  const totalCost = transactionCost + marginCost + complianceCost;
  const costRatio = totalCost / economicBenefit;
  if (costRatio > 0.5) riskScore += 30;
  else if (costRatio > 0.3) riskScore += 20;
  else if (costRatio > 0.1) riskScore += 10;

  // Participant tier adjustment
  if (participantData) {
    const complianceTier = participantData.api_credentials.compliance_tier;
    if (complianceTier === "MiFIDII") riskScore -= 10;
    else if (complianceTier === "DoddFrank") riskScore -= 5;

    const entityType = participantData.api_credentials.entity_type;
    if (entityType === "retail") riskScore += 15;
    else if (entityType === "scout") riskScore += 10;
  }

  return Math.max(0, Math.min(100, riskScore));
}

function getDecisionMatrix(netBenefit, riskAdjustment) {
  // Decision thresholds
  const strongPositive = 100;
  const weakPositive = 20;
  const breakeven = 0;
  const weakNegative = -20;

  // Risk-adjusted thresholds
  const riskAdjustedThresholds = {
    strong_positive: strongPositive * riskAdjustment,
    weak_positive: weakPositive * riskAdjustment,
    breakeven: breakeven,
    weak_negative: weakNegative * riskAdjustment,
  };

  let decision = "proceed with caution";
  let confidence = "medium";
  let reasoning = "Net benefit analysis indicates moderate viability";

  if (netBenefit >= riskAdjustedThresholds.strong_positive) {
    decision = "strongly recommended";
    confidence = "high";
    reasoning = "Strong positive net benefit with acceptable risk profile";
  } else if (netBenefit >= riskAdjustedThresholds.weak_positive) {
    decision = "recommended";
    confidence = "medium-high";
    reasoning = "Positive net benefit justifies execution";
  } else if (netBenefit >= riskAdjustedThresholds.breakeven) {
    decision = "review viability";
    confidence = "medium";
    reasoning = "Near breakeven - consider timing and market conditions";
  } else if (netBenefit >= riskAdjustedThresholds.weak_negative) {
    decision = "not recommended";
    confidence = "medium-high";
    reasoning = "Negative net benefit - seek alternatives";
  } else {
    decision = "strongly not recommended";
    confidence = "high";
    reasoning = "Significant negative net benefit - avoid execution";
  }

  return {
    decision: decision,
    confidence_level: confidence,
    reasoning: reasoning,
    net_benefit: Math.round(netBenefit * 100) / 100,
    risk_adjusted_thresholds: Object.keys(riskAdjustedThresholds).reduce(
      (acc, key) => {
        acc[key] = Math.round(riskAdjustedThresholds[key] * 100) / 100;
        return acc;
      },
      {},
    ),
    recommendation_score:
      Math.round(Math.max(-100, Math.min(100, netBenefit / 10)) * 100) / 100,
  };
}

async function logNetBenefitCalculation({
  participantId,
  userId,
  calculation,
  decision,
}) {
  try {
    await sql`
      INSERT INTO treasury_transactions (
        transaction_type,
        amount,
        balance_after,
        reference_id,
        reference_type,
        description,
        authorized_by
      ) VALUES (
        'calculation_log',
        ${calculation.adjustedNetBenefit},
        0,
        ${participantId},
        'net_benefit_calc',
        ${`Net benefit calculation: ${decision.decision} (${decision.confidence_level} confidence)`},
        ${userId}
      )
    `;
  } catch (error) {
    console.warn("Failed to log net benefit calculation:", error);
  }
}
