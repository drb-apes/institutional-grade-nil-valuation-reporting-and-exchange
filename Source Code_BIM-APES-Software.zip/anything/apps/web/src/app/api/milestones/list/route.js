import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athlete_id");
    const status = searchParams.get("status");

    let query = `
      SELECT 
        m.*,
        up.user_id,
        au.name as athlete_name,
        au.email as athlete_email,
        cp.total_amount,
        cp.contributor_count,
        cp.pool_status
      FROM milestones m
      JOIN user_profiles up ON m.athlete_id = up.id
      JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN contribution_pools cp ON m.id = cp.milestone_id
      WHERE 1=1
    `;

    const params = [];
    let paramIndex = 1;

    if (athleteId) {
      query += ` AND m.athlete_id = $${paramIndex}`;
      params.push(parseInt(athleteId));
      paramIndex++;
    }

    if (status) {
      query += ` AND m.milestone_status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    // If user is authenticated, they can see all milestones
    // If not authenticated, they can only see active milestones
    if (!session?.user?.id) {
      query += ` AND m.milestone_status = $${paramIndex}`;
      params.push("active");
    }

    query += ` ORDER BY m.created_at DESC`;

    const milestones = await sql(query, params);

    // Parse JSON fields
    const processedMilestones = milestones.map((milestone) => ({
      ...milestone,
      target_metrics: JSON.parse(milestone.target_metrics || "{}"),
      current_progress: JSON.parse(milestone.current_progress || "{}"),
    }));

    return Response.json({
      success: true,
      milestones: processedMilestones,
    });
  } catch (error) {
    console.error("Error fetching milestones:", error);
    return Response.json(
      {
        error: "Failed to fetch milestones",
      },
      { status: 500 },
    );
  }
}
