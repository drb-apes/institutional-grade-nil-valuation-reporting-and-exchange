import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { title, description, target_metrics, reward_pool, target_date } =
      body;

    // Validate required fields
    if (!title || !target_metrics) {
      return Response.json(
        {
          error: "Title and target metrics are required",
        },
        { status: 400 },
      );
    }

    // Get user profile to verify they're an athlete
    const userProfiles = await sql`
      SELECT id, user_type FROM user_profiles 
      WHERE user_id = ${session.user.id}
    `;

    if (userProfiles.length === 0) {
      return Response.json(
        {
          error: "User profile not found",
        },
        { status: 404 },
      );
    }

    const userProfile = userProfiles[0];
    if (userProfile.user_type !== "athlete") {
      return Response.json(
        {
          error: "Only athletes can create milestones",
        },
        { status: 403 },
      );
    }

    // Create the milestone
    const milestones = await sql`
      INSERT INTO milestones (
        athlete_id, 
        title, 
        description, 
        target_metrics, 
        reward_pool, 
        target_date
      ) VALUES (
        ${userProfile.id},
        ${title},
        ${description || ""},
        ${JSON.stringify(target_metrics)},
        ${reward_pool || 0},
        ${target_date || null}
      )
      RETURNING *
    `;

    const milestone = milestones[0];

    // Create associated contribution pool
    await sql`
      INSERT INTO contribution_pools (milestone_id)
      VALUES (${milestone.id})
    `;

    return Response.json({
      success: true,
      milestone: {
        ...milestone,
        target_metrics: JSON.parse(milestone.target_metrics),
        current_progress: JSON.parse(milestone.current_progress || "{}"),
      },
    });
  } catch (error) {
    console.error("Error creating milestone:", error);
    return Response.json(
      {
        error: "Failed to create milestone",
      },
      { status: 500 },
    );
  }
}
