import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      sponsor_id,
      athlete_id,
      campaign_name,
      biometric_threshold,
      engagement_target,
      conversion_target,
      budget_allocated,
      start_date,
      end_date,
    } = body;

    // Create ROI tracking campaign
    const campaign = await sql`
      INSERT INTO sponsor_contracts (
        sponsor_id,
        athlete_id,
        contract_type,
        exposure_amount,
        predictable_spend,
        yield_target,
        contract_status,
        started_at,
        expires_at,
        performance_metrics
      ) VALUES (
        ${sponsor_id},
        ${athlete_id},
        'biometric_index',
        ${budget_allocated},
        ${budget_allocated},
        ${JSON.stringify({
          campaign_name,
          biometric_threshold,
          engagement_target,
          conversion_target,
        })},
        'active',
        ${start_date},
        ${end_date},
        ${JSON.stringify({
          brand_lift: 0,
          engagement_quality: 0,
          conversion_rate: 0,
          sales_attribution: 0,
          biometric_peak_exposures: 0,
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      campaign: campaign[0],
    });
  } catch (error) {
    console.error("ROI tracking creation error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sponsor_id = searchParams.get("sponsor_id");
    const status = searchParams.get("status") || "active";

    let query;
    if (sponsor_id) {
      query = sql`
        SELECT 
          sc.*,
          up_athlete.user_id as athlete_user_id,
          au_athlete.name as athlete_name,
          up_sponsor.user_id as sponsor_user_id,
          au_sponsor.name as sponsor_name
        FROM sponsor_contracts sc
        LEFT JOIN user_profiles up_athlete ON sc.athlete_id = up_athlete.id
        LEFT JOIN auth_users au_athlete ON up_athlete.user_id = au_athlete.id
        LEFT JOIN user_profiles up_sponsor ON sc.sponsor_id = up_sponsor.id
        LEFT JOIN auth_users au_sponsor ON up_sponsor.user_id = au_sponsor.id
        WHERE sc.sponsor_id = ${parseInt(sponsor_id)}
          AND sc.contract_status = ${status}
        ORDER BY sc.started_at DESC
      `;
    } else {
      query = sql`
        SELECT 
          sc.*,
          up_athlete.user_id as athlete_user_id,
          au_athlete.name as athlete_name,
          up_sponsor.user_id as sponsor_user_id,
          au_sponsor.name as sponsor_name
        FROM sponsor_contracts sc
        LEFT JOIN user_profiles up_athlete ON sc.athlete_id = up_athlete.id
        LEFT JOIN auth_users au_athlete ON up_athlete.user_id = au_athlete.id
        LEFT JOIN user_profiles up_sponsor ON sc.sponsor_id = up_sponsor.id
        LEFT JOIN auth_users au_sponsor ON up_sponsor.user_id = au_sponsor.id
        WHERE sc.contract_status = ${status}
        ORDER BY sc.started_at DESC
        LIMIT 50
      `;
    }

    const campaigns = await query;

    return Response.json({
      success: true,
      campaigns,
    });
  } catch (error) {
    console.error("ROI tracking fetch error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const {
      contract_id,
      brand_lift,
      engagement_quality,
      conversion_rate,
      sales_attribution,
      biometric_peak_exposures,
    } = body;

    // Update performance metrics
    const updated = await sql`
      UPDATE sponsor_contracts
      SET 
        performance_metrics = ${JSON.stringify({
          brand_lift,
          engagement_quality,
          conversion_rate,
          sales_attribution,
          biometric_peak_exposures,
        })},
        brand_lift_score = ${brand_lift},
        engagement_lift_score = ${engagement_quality}
      WHERE id = ${contract_id}
      RETURNING *
    `;

    return Response.json({
      success: true,
      campaign: updated[0],
    });
  } catch (error) {
    console.error("ROI update error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
