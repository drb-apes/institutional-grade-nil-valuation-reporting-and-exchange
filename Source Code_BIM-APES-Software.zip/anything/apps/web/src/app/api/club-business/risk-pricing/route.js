import sql from "@/app/api/utils/sql";

// Risk pricing engine
function calculateRiskScore(riskFactors) {
  const {
    injury_history = 0,
    performance_volatility = 0,
    market_sentiment = 1,
    regulatory_exposure = 0,
    contract_complexity = 0,
    age = 20,
    sport_risk_level = "medium",
  } = riskFactors;

  // Sport-specific risk multipliers
  const sportRiskMultipliers = {
    low: 0.8, // Swimming, Track & Field
    medium: 1.0, // Soccer, Basketball
    high: 1.3, // American Football, Rugby
    extreme: 1.6, // Boxing, MMA, Wrestling
  };

  const sportMultiplier = sportRiskMultipliers[sport_risk_level] || 1.0;

  // Age risk curve (optimal age: 22-28)
  const ageRisk = age < 18 ? 0.4 : age > 32 ? 0.3 : 0;

  // Calculate composite risk score (0-100)
  const baseRisk =
    (injury_history * 0.3 +
      performance_volatility * 0.25 +
      (1 - market_sentiment) * 0.2 +
      regulatory_exposure * 0.15 +
      contract_complexity * 0.1) *
    100;

  const adjustedRisk = Math.min(
    100,
    Math.max(0, baseRisk * sportMultiplier + ageRisk * 10),
  );

  return {
    risk_score: adjustedRisk,
    risk_category:
      adjustedRisk < 20
        ? "low"
        : adjustedRisk < 40
          ? "moderate"
          : adjustedRisk < 60
            ? "high"
            : "extreme",
    sport_multiplier: sportMultiplier,
    age_adjustment: ageRisk,
  };
}

function calculateDynamicPricing(baseValue, riskScore, marketConditions) {
  const {
    market_volatility = 0.1,
    liquidity_premium = 0,
    demand_factor = 1.0,
  } = marketConditions;

  // Risk-adjusted discount rate
  const riskDiscount = (riskScore.risk_score / 100) * 0.4; // Up to 40% discount for high risk

  // Market adjustment
  const marketAdjustment = market_volatility * 0.15 + liquidity_premium;

  // Dynamic price calculation
  const adjustedValue =
    baseValue * (1 - riskDiscount) * demand_factor * (1 + marketAdjustment);

  return {
    base_value: baseValue,
    adjusted_value: parseFloat(adjustedValue.toFixed(2)),
    risk_discount: parseFloat((riskDiscount * 100).toFixed(2)),
    market_adjustment: parseFloat((marketAdjustment * 100).toFixed(2)),
    pricing_confidence: calculatePricingConfidence(
      riskScore.risk_score,
      market_volatility,
    ),
  };
}

function calculatePricingConfidence(riskScore, marketVolatility) {
  const riskConfidence = 100 - riskScore;
  const marketConfidence = (1 - marketVolatility) * 100;
  return parseFloat(((riskConfidence + marketConfidence) / 2).toFixed(2));
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      base_valuation,
      risk_factors,
      market_conditions,
      contract_duration_months = 12,
    } = body;

    // Calculate risk score
    const riskAssessment = calculateRiskScore(risk_factors);

    // Calculate dynamic pricing
    const pricingModel = calculateDynamicPricing(
      base_valuation,
      riskAssessment,
      market_conditions,
    );

    // Generate risk mitigation strategies
    const mitigationStrategies = generateMitigationStrategies(
      riskAssessment,
      risk_factors,
    );

    // Calculate insurance premium
    const insurancePremium = calculateInsurancePremium(
      pricingModel.adjusted_value,
      riskAssessment.risk_score,
      contract_duration_months,
    );

    // Store risk assessment
    const assessment = await sql`
      INSERT INTO hedging_positions (
        sponsor_id,
        athlete_id,
        hedge_type,
        ht_token_amount,
        hedge_trigger,
        hedge_status,
        created_at,
        expires_at
      ) VALUES (
        1,
        ${athlete_id},
        'stability',
        ${insurancePremium},
        ${JSON.stringify({
          risk_assessment: riskAssessment,
          pricing_model: pricingModel,
          mitigation_strategies: mitigationStrategies,
          market_conditions,
          contract_duration_months,
        })},
        'active',
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP + INTERVAL '${contract_duration_months} months'
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      risk_assessment: riskAssessment,
      pricing_model: pricingModel,
      insurance_premium: insurancePremium,
      mitigation_strategies: mitigationStrategies,
      assessment_id: assessment[0].id,
    });
  } catch (error) {
    console.error("Risk pricing calculation error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");

    let query;
    if (athlete_id) {
      query = sql`
        SELECT 
          hp.*,
          up.user_id as athlete_user_id,
          au.name as athlete_name
        FROM hedging_positions hp
        LEFT JOIN user_profiles up ON hp.athlete_id = up.id
        LEFT JOIN auth_users au ON up.user_id = au.id
        WHERE hp.athlete_id = ${parseInt(athlete_id)}
          AND hp.hedge_type = 'stability'
        ORDER BY hp.created_at DESC
      `;
    } else {
      query = sql`
        SELECT 
          hp.*,
          up.user_id as athlete_user_id,
          au.name as athlete_name
        FROM hedging_positions hp
        LEFT JOIN user_profiles up ON hp.athlete_id = up.id
        LEFT JOIN auth_users au ON up.user_id = au.id
        WHERE hp.hedge_type = 'stability'
        ORDER BY hp.created_at DESC
        LIMIT 50
      `;
    }

    const assessments = await query;

    return Response.json({
      success: true,
      assessments,
    });
  } catch (error) {
    console.error("Risk assessment fetch error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function generateMitigationStrategies(riskAssessment, riskFactors) {
  const strategies = [];

  // Injury risk mitigation
  if (riskFactors.injury_history > 0.5) {
    strategies.push({
      risk_type: "injury",
      severity: "high",
      strategy: "Enhanced recovery protocol and biometric monitoring",
      cost_impact: "Medium",
      effectiveness: "75%",
    });
  }

  // Performance volatility mitigation
  if (riskFactors.performance_volatility > 0.4) {
    strategies.push({
      risk_type: "performance",
      severity: "medium",
      strategy: "Skill development program and mental coaching",
      cost_impact: "Low",
      effectiveness: "65%",
    });
  }

  // Market sentiment mitigation
  if (riskFactors.market_sentiment < 0.6) {
    strategies.push({
      risk_type: "market",
      severity: "medium",
      strategy: "Enhanced media exposure and fan engagement campaigns",
      cost_impact: "Medium",
      effectiveness: "70%",
    });
  }

  // Regulatory exposure mitigation
  if (riskFactors.regulatory_exposure > 0.3) {
    strategies.push({
      risk_type: "regulatory",
      severity: "high",
      strategy: "Legal compliance audit and NIL advisory services",
      cost_impact: "High",
      effectiveness: "85%",
    });
  }

  return strategies;
}

function calculateInsurancePremium(contractValue, riskScore, durationMonths) {
  // Base premium: 2-8% of contract value based on risk
  const basePremiumRate = 0.02 + (riskScore / 100) * 0.06;

  // Duration adjustment (longer = slight discount)
  const durationDiscount = durationMonths > 12 ? 0.9 : 1.0;

  const premium = contractValue * basePremiumRate * durationDiscount;

  return {
    monthly_premium: parseFloat((premium / durationMonths).toFixed(2)),
    total_premium: parseFloat(premium.toFixed(2)),
    premium_rate: parseFloat((basePremiumRate * 100).toFixed(2)),
    coverage_amount: contractValue,
  };
}
