import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      alert_type,
      severity,
      athlete_id,
      trigger_data,
      recommendation,
      compliance_status,
      auto_execute,
    } = body;

    // Create AI alert
    const alert = await sql`
      INSERT INTO sandbox_alerts (
        alert_id,
        alert_type,
        severity,
        message,
        context,
        status,
        triggered_at
      ) VALUES (
        ${`AI-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`},
        ${alert_type},
        ${severity},
        ${recommendation},
        ${JSON.stringify({
          athlete_id,
          trigger_data,
          compliance_status,
          auto_execute,
          timestamp: new Date().toISOString(),
        })},
        'open',
        NOW()
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      alert: alert[0],
    });
  } catch (error) {
    console.error("AI alert creation error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const severity = searchParams.get("severity");
    const status = searchParams.get("status") || "open";
    const limit = parseInt(searchParams.get("limit") || "50");

    let query;
    if (severity) {
      query = sql`
        SELECT *
        FROM sandbox_alerts
        WHERE status = ${status}
          AND severity = ${severity}
        ORDER BY triggered_at DESC
        LIMIT ${limit}
      `;
    } else {
      query = sql`
        SELECT *
        FROM sandbox_alerts
        WHERE status = ${status}
        ORDER BY triggered_at DESC
        LIMIT ${limit}
      `;
    }

    const alerts = await query;

    // Simulate AI-generated alerts for demo
    const aiAlerts = generateAIAlerts();

    return Response.json({
      success: true,
      alerts: [...alerts, ...aiAlerts],
    });
  } catch (error) {
    console.error("AI alerts fetch error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { alert_id, action, notes } = body;

    const updated = await sql`
      UPDATE sandbox_alerts
      SET 
        status = ${action === "acknowledge" ? "acknowledged" : action === "resolve" ? "resolved" : "dismissed"},
        resolved_at = ${action === "resolve" ? new Date() : null},
        context = context || ${JSON.stringify({ action_notes: notes })}::jsonb
      WHERE alert_id = ${alert_id}
      RETURNING *
    `;

    return Response.json({
      success: true,
      alert: updated[0],
    });
  } catch (error) {
    console.error("AI alert update error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function generateAIAlerts() {
  return [
    {
      id: Date.now() + 1,
      alert_id: `AI-INJURY-${Date.now()}`,
      alert_type: "injury_risk",
      severity: "high",
      message:
        "⚠️ HIGH INJURY RISK: Striker #10 showing 23% elevated hamstring strain indicators in last 3 training sessions",
      context: {
        athlete_id: 101,
        athlete_name: "Marcus Johnson",
        trigger_data: {
          hrv_drop: -18,
          muscle_fatigue: 0.87,
          movement_asymmetry: 0.34,
          recent_load: "145% of baseline",
        },
        recommendation:
          "SELL: Reduce exposure by 40% - Consider hedging position",
        compliance_status: "approved",
        confidence: 0.89,
      },
      status: "open",
      triggered_at: new Date(Date.now() - 300000).toISOString(),
    },
    {
      id: Date.now() + 2,
      alert_id: `AI-PERF-${Date.now()}`,
      alert_type: "performance_spike",
      severity: "medium",
      message:
        "📈 PERFORMANCE SPIKE: Midfielder #7 exceeding expected output by 34% - BIM Index up 12pts",
      context: {
        athlete_id: 102,
        athlete_name: "Sarah Chen",
        trigger_data: {
          sprint_velocity: "+8.3%",
          tactical_positioning: 0.92,
          pass_completion: "89% (avg: 76%)",
          biometric_consistency: 0.94,
        },
        recommendation:
          "BUY: Increase allocation by 25% - Strong upside potential",
        compliance_status: "approved",
        confidence: 0.91,
      },
      status: "open",
      triggered_at: new Date(Date.now() - 600000).toISOString(),
    },
    {
      id: Date.now() + 3,
      alert_id: `AI-MARKET-${Date.now()}`,
      alert_type: "market_anomaly",
      severity: "critical",
      message:
        "🔴 MARKET ANOMALY: Unusual trading volume on Defender #5 index - 340% above baseline",
      context: {
        athlete_id: 103,
        athlete_name: "David Martinez",
        trigger_data: {
          volume_spike: 3.4,
          price_volatility: 0.67,
          insider_activity: "detected",
          news_sentiment: -0.45,
        },
        recommendation:
          "HOLD: Investigate before action - Possible insider information",
        compliance_status: "flagged_for_review",
        confidence: 0.76,
      },
      status: "open",
      triggered_at: new Date(Date.now() - 900000).toISOString(),
    },
    {
      id: Date.now() + 4,
      alert_id: `AI-WEATHER-${Date.now()}`,
      alert_type: "external_factor",
      severity: "low",
      message:
        "🌧️ WEATHER IMPACT: Heavy rain forecast for Saturday match - Adjust tactical indices",
      context: {
        trigger_data: {
          weather_condition: "heavy_rain",
          temperature: "8°C",
          wind_speed: "35 km/h",
          pitch_condition: "waterlogged",
        },
        recommendation:
          "ADJUST: Reduce allocation to speed-dependent indices by 15%",
        compliance_status: "approved",
        confidence: 0.82,
      },
      status: "open",
      triggered_at: new Date(Date.now() - 1200000).toISOString(),
    },
    {
      id: Date.now() + 5,
      alert_id: `AI-OPPONENT-${Date.now()}`,
      alert_type: "tactical_intelligence",
      severity: "medium",
      message:
        "🎯 TACTICAL EDGE: Opponent weak against high-press tactics - +28% success rate projected",
      context: {
        trigger_data: {
          opponent: "City Rivals FC",
          weakness: "high_press_vulnerability",
          historical_success_rate: 0.72,
          recommended_formation: "4-3-3 aggressive",
        },
        recommendation:
          "BUY: Increase allocation to pressing midfielders by 20%",
        compliance_status: "approved",
        confidence: 0.88,
      },
      status: "open",
      triggered_at: new Date(Date.now() - 1800000).toISOString(),
    },
  ];
}
