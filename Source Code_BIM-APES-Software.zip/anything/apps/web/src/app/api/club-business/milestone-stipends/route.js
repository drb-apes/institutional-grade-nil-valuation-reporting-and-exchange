import sql from "@/app/api/utils/sql";

// Milestone stipend amounts (in GBP)
const STIPEND_AMOUNTS = {
  mint: 5000,
  consent: 3000,
  license: 15000,
  roi: 25000,
  nil_report: 5000,
  contract: 10000,
  renew: 8000,
};

// Lifecycle stages
const LIFECYCLE_STAGES = [
  "mint",
  "consent",
  "license",
  "roi",
  "nil_report",
  "contract",
  "renew",
];

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      milestone_type,
      overlay_id,
      performance_data,
      verification_status = "pending",
    } = body;

    const stipend_amount = STIPEND_AMOUNTS[milestone_type] || 0;

    // Record milestone achievement
    const milestone = await sql`
      INSERT INTO milestones (
        athlete_id,
        title,
        description,
        target_metrics,
        milestone_status,
        reward_pool,
        current_progress
      ) VALUES (
        ${athlete_id},
        ${`Milestone: ${milestone_type.toUpperCase()}`},
        ${`Lifecycle milestone: ${milestone_type} completed`},
        ${JSON.stringify({
          milestone_type,
          overlay_id,
          stipend_amount,
          verification_status,
        })},
        ${verification_status === "verified" ? "completed" : "active"},
        ${stipend_amount},
        ${JSON.stringify({
          milestone_type,
          performance_data,
          timestamp: new Date().toISOString(),
        })}
      )
      RETURNING *
    `;

    // If verified, create reward distribution
    if (verification_status === "verified") {
      await sql`
        INSERT INTO rewards (
          recipient_id,
          milestone_id,
          amount,
          reward_type,
          distribution_status,
          metadata
        ) VALUES (
          ${athlete_id},
          ${milestone[0].id},
          ${stipend_amount},
          'milestone_completion',
          'pending',
          ${JSON.stringify({
            milestone_type,
            overlay_id,
            lifecycle_stage: milestone_type,
          })}
        )
      `;
    }

    return Response.json({
      success: true,
      milestone: milestone[0],
      stipend_amount,
      verification_required: verification_status !== "verified",
    });
  } catch (error) {
    console.error("Milestone stipend creation error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");
    const milestone_type = searchParams.get("milestone_type");

    let query;
    const conditions = [];
    const values = [];

    if (athlete_id) {
      conditions.push(`m.athlete_id = $${conditions.length + 1}`);
      values.push(parseInt(athlete_id));
    }

    if (milestone_type) {
      conditions.push(
        `m.target_metrics->>'milestone_type' = $${conditions.length + 1}`,
      );
      values.push(milestone_type);
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    const queryText = `
      SELECT 
        m.*,
        up.user_id as athlete_user_id,
        au.name as athlete_name,
        r.amount as paid_amount,
        r.distribution_status,
        r.distributed_at
      FROM milestones m
      LEFT JOIN user_profiles up ON m.athlete_id = up.id
      LEFT JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN rewards r ON m.id = r.milestone_id
      ${whereClause}
      ORDER BY m.created_at DESC
      LIMIT 100
    `;

    const milestones = await sql(queryText, values);

    // Calculate lifecycle progress
    const lifecycleProgress = LIFECYCLE_STAGES.map((stage) => {
      const stageData = milestones.filter(
        (m) => m.target_metrics?.milestone_type === stage,
      );
      return {
        stage,
        completed: stageData.filter((m) => m.milestone_status === "completed")
          .length,
        pending: stageData.filter((m) => m.milestone_status === "active")
          .length,
        total_stipends: stageData.reduce(
          (sum, m) => sum + (parseFloat(m.reward_pool) || 0),
          0,
        ),
      };
    });

    return Response.json({
      success: true,
      milestones,
      lifecycle_progress: lifecycleProgress,
      total_earned: milestones.reduce((sum, m) => {
        return (
          sum +
          (m.milestone_status === "completed"
            ? parseFloat(m.reward_pool || 0)
            : 0)
        );
      }, 0),
    });
  } catch (error) {
    console.error("Milestone stipend fetch error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { milestone_id, verification_status, verifier_notes } = body;

    // Update milestone verification
    const updated = await sql`
      UPDATE milestones
      SET 
        milestone_status = ${verification_status === "verified" ? "completed" : "failed"},
        completed_at = ${verification_status === "verified" ? new Date().toISOString() : null},
        current_progress = jsonb_set(
          current_progress,
          '{verification_notes}',
          ${JSON.stringify(verifier_notes || "")}
        )
      WHERE id = ${milestone_id}
      RETURNING *
    `;

    if (verification_status === "verified") {
      // Update reward distribution status
      await sql`
        UPDATE rewards
        SET distribution_status = 'completed',
            distributed_at = CURRENT_TIMESTAMP
        WHERE milestone_id = ${milestone_id}
      `;
    }

    return Response.json({
      success: true,
      milestone: updated[0],
    });
  } catch (error) {
    console.error("Milestone verification error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
