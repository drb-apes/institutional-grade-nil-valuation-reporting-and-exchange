import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      scenario_type,
      contract_value,
      event_costs,
      sponsorship_revenue,
      timeframe_months,
    } = body;

    // AI Financial Simulation
    const simulation = {
      scenario_type,
      timeframe_months,
      projections: {
        revenue: generateRevenueProjection(
          sponsorship_revenue,
          timeframe_months,
        ),
        costs: generateCostProjection(
          contract_value,
          event_costs,
          timeframe_months,
        ),
        cash_flow: [],
        roi: 0,
        risk_sensitivity: calculateRiskSensitivity(),
      },
    };

    // Calculate monthly cash flow
    for (let month = 1; month <= timeframe_months; month++) {
      const monthlyRevenue = simulation.projections.revenue[month - 1];
      const monthlyCosts = simulation.projections.costs[month - 1];
      const netCashFlow = monthlyRevenue - monthlyCosts;

      simulation.projections.cash_flow.push({
        month,
        revenue: monthlyRevenue,
        costs: monthlyCosts,
        net: netCashFlow,
        cumulative: simulation.projections.cash_flow[month - 2]?.cumulative
          ? simulation.projections.cash_flow[month - 2].cumulative + netCashFlow
          : netCashFlow,
      });
    }

    // Calculate ROI
    const totalRevenue = simulation.projections.revenue.reduce(
      (a, b) => a + b,
      0,
    );
    const totalCosts = simulation.projections.costs.reduce((a, b) => a + b, 0);
    simulation.projections.roi = (
      ((totalRevenue - totalCosts) / totalCosts) *
      100
    ).toFixed(2);

    // AI Recommendations
    simulation.recommendations = generateFinancialRecommendations(
      simulation.projections.roi,
      simulation.projections.risk_sensitivity,
    );

    return Response.json({
      success: true,
      simulation,
    });
  } catch (error) {
    console.error("Financial analytics error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const analysis_type = searchParams.get("type") || "overview";

    // Fetch financial data
    const contracts = await sql`
      SELECT 
        SUM(exposure_amount) as total_contracts,
        AVG(brand_lift_score) as avg_brand_lift,
        COUNT(*) as active_count
      FROM sponsor_contracts
      WHERE contract_status = 'active'
    `;

    const milestones = await sql`
      SELECT 
        SUM(reward_pool) as total_rewards,
        COUNT(*) as milestone_count
      FROM milestones
      WHERE milestone_status = 'active'
    `;

    const analytics = {
      overview: {
        total_contract_value: parseFloat(contracts[0]?.total_contracts || 0),
        active_contracts: parseInt(contracts[0]?.active_count || 0),
        avg_brand_lift: parseFloat(contracts[0]?.avg_brand_lift || 0),
        total_milestone_pool: parseFloat(milestones[0]?.total_rewards || 0),
        active_milestones: parseInt(milestones[0]?.milestone_count || 0),
      },
      roai_calculation: calculateROAI(contracts[0], milestones[0]),
      budget_health: assessBudgetHealth(),
      investment_priorities: generateInvestmentPriorities(),
    };

    return Response.json({
      success: true,
      analytics,
    });
  } catch (error) {
    console.error("Financial analytics fetch error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function generateRevenueProjection(baseRevenue, months) {
  const revenue = [];
  for (let i = 0; i < months; i++) {
    // Simulate growth with seasonality
    const seasonalFactor = 1 + Math.sin((i / 12) * Math.PI * 2) * 0.2;
    const growthFactor = 1 + i * 0.02;
    revenue.push(baseRevenue * seasonalFactor * growthFactor);
  }
  return revenue;
}

function generateCostProjection(contractValue, eventCosts, months) {
  const costs = [];
  for (let i = 0; i < months; i++) {
    // Distribute costs with some variability
    const baseCost = (contractValue + eventCosts) / months;
    const variability = baseCost * (Math.random() * 0.2 - 0.1);
    costs.push(baseCost + variability);
  }
  return costs;
}

function calculateRiskSensitivity() {
  return {
    market_downturn: { impact: -0.25, probability: 0.15 },
    injury_spike: { impact: -0.35, probability: 0.2 },
    performance_decline: { impact: -0.2, probability: 0.18 },
    regulatory_change: { impact: -0.15, probability: 0.1 },
    positive_upside: { impact: 0.4, probability: 0.25 },
  };
}

function generateFinancialRecommendations(roi, riskSensitivity) {
  const recommendations = [];

  if (roi > 20) {
    recommendations.push({
      priority: "high",
      action: "Increase investment allocation by 15-20%",
      reason: "Strong ROI performance above target threshold",
    });
  } else if (roi < 5) {
    recommendations.push({
      priority: "critical",
      action: "Review and optimize cost structure",
      reason: "ROI below minimum acceptable threshold",
    });
  }

  if (riskSensitivity.injury_spike.probability > 0.15) {
    recommendations.push({
      priority: "medium",
      action: "Allocate 5-8% of budget to injury insurance",
      reason: "Elevated injury risk detected",
    });
  }

  recommendations.push({
    priority: "low",
    action: "Diversify revenue streams across 3+ athlete indices",
    reason: "Portfolio optimization for risk mitigation",
  });

  return recommendations;
}

function calculateROAI(contracts, milestones) {
  const investment = parseFloat(contracts?.total_contracts || 100000);
  const returns =
    investment * (1 + parseFloat(contracts?.avg_brand_lift || 10) / 100);
  const roi = (((returns - investment) / investment) * 100).toFixed(2);

  return {
    total_investment: investment,
    projected_returns: returns,
    roi_percentage: roi,
    payback_period_months: investment / (returns / 12),
  };
}

function assessBudgetHealth() {
  return {
    status: "healthy",
    burn_rate: 0.15,
    runway_months: 18,
    reserves_ratio: 0.25,
    recommendations: [
      "Maintain current spending levels",
      "Consider 10% reserve buffer increase",
    ],
  };
}

function generateInvestmentPriorities() {
  return [
    { category: "Player Development", allocation: 0.35, roi_potential: 0.42 },
    {
      category: "Marketing & Sponsorship",
      allocation: 0.25,
      roi_potential: 0.38,
    },
    { category: "Infrastructure", allocation: 0.2, roi_potential: 0.28 },
    {
      category: "Technology & Analytics",
      allocation: 0.15,
      roi_potential: 0.55,
    },
    { category: "Risk Management", allocation: 0.05, roi_potential: 0.2 },
  ];
}
