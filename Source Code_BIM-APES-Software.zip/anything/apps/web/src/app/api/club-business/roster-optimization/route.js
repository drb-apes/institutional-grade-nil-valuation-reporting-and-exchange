import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      match_date,
      opponent,
      formation,
      tactical_priority,
      injury_threshold,
      fitness_threshold,
    } = body;

    // Fetch available athletes
    const athletes = await sql`
      SELECT 
        up.id,
        au.name,
        ms.ai_score as fitness_score,
        ms.scan_data
      FROM user_profiles up
      LEFT JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN LATERAL (
        SELECT * FROM motion_scans 
        WHERE athlete_id = up.id 
        ORDER BY created_at DESC 
        LIMIT 1
      ) ms ON true
      WHERE up.user_type = 'athlete'
      LIMIT 30
    `;

    // AI Roster Optimization
    const optimizedRoster = athletes.map((athlete) => {
      const scanData = athlete.scan_data || {};
      const fitnessScore = athlete.fitness_score || Math.random() * 100;

      // Simulate availability and tactical fit
      const availability =
        fitnessScore > (injury_threshold || 70) ? "available" : "injured";
      const tacticalFit = calculateTacticalFit(formation, tactical_priority);
      const riskScore = calculateRiskScore(fitnessScore, scanData);

      return {
        athlete_id: athlete.id,
        athlete_name: athlete.name,
        fitness_score: fitnessScore.toFixed(1),
        availability,
        tactical_fit: tacticalFit,
        risk_score: riskScore,
        position_recommendation: getPositionRecommendation(
          tacticalFit,
          fitnessScore,
        ),
        minutes_limit: availability === "available" ? 90 : 0,
        ai_confidence: (Math.random() * 0.3 + 0.7).toFixed(2),
      };
    });

    // Sort by tactical fit and fitness
    const sortedRoster = optimizedRoster.sort(
      (a, b) =>
        b.tactical_fit * b.fitness_score - a.tactical_fit * a.fitness_score,
    );

    const startingXI = sortedRoster
      .filter((a) => a.availability === "available")
      .slice(0, 11);
    const bench = sortedRoster
      .filter((a) => a.availability === "available")
      .slice(11, 18);
    const unavailable = sortedRoster.filter(
      (a) => a.availability === "injured",
    );

    return Response.json({
      success: true,
      optimization: {
        match_date,
        opponent,
        formation,
        starting_xi: startingXI,
        bench,
        unavailable,
        tactical_summary: {
          total_fitness_score:
            startingXI.reduce(
              (sum, a) => sum + parseFloat(a.fitness_score),
              0,
            ) / 11,
          avg_tactical_fit:
            startingXI.reduce((sum, a) => sum + a.tactical_fit, 0) / 11,
          injury_risk: startingXI.filter((a) => a.risk_score > 0.6).length,
          ai_confidence: 0.87,
        },
      },
    });
  } catch (error) {
    console.error("Roster optimization error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateTacticalFit(formation, priority) {
  // Simulate tactical fit based on formation and priority
  const baseScore = Math.random() * 0.5 + 0.5;
  const formationBonus = formation === "4-3-3" ? 0.15 : 0.1;
  const priorityBonus = priority === "attacking" ? 0.1 : 0.05;

  return Math.min(baseScore + formationBonus + priorityBonus, 1.0);
}

function calculateRiskScore(fitnessScore, scanData) {
  // Higher risk for lower fitness
  const fitnessRisk = (100 - fitnessScore) / 100;
  const scanRisk = scanData.injury_indicators ? 0.3 : 0;

  return Math.min(fitnessRisk + scanRisk, 1.0);
}

function getPositionRecommendation(tacticalFit, fitnessScore) {
  if (tacticalFit > 0.8 && fitnessScore > 85) return "Starter";
  if (tacticalFit > 0.6 && fitnessScore > 70) return "Rotation";
  if (fitnessScore > 60) return "Bench";
  return "Rest";
}
