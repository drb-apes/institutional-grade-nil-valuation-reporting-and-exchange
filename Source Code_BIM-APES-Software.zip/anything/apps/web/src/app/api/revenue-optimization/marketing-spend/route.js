import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Revenue Optimization Engine
 * Marketing Spend Optimization
 *
 * Optimizes marketing budget allocation across:
 * - Channels (social, search, display, email, etc.)
 * - Campaigns
 * - Audiences
 * - Timing
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      totalBudget,
      channels = [], // [{ name, historicalROI, cost, reach, ... }]
      campaigns = [], // [{ name, budget, performance, ... }]
      objectives = {}, // { awareness: 0.3, conversion: 0.5, retention: 0.2 }
      constraints = {}, // { minChannelBudget, maxChannelBudget, ... }
      optimizationGoal = "maximize_roi", // maximize_roi, maximize_reach, balanced
    } = body;

    if (!totalBudget || totalBudget <= 0) {
      return Response.json(
        { error: "Total budget is required and must be > 0" },
        { status: 400 },
      );
    }

    if (!channels || channels.length === 0) {
      return Response.json(
        { error: "At least one marketing channel is required" },
        { status: 400 },
      );
    }

    // --- CHANNEL SCORING ---
    const scoredChannels = scoreChannels(
      channels,
      objectives,
      optimizationGoal,
    );

    // --- BUDGET ALLOCATION ---
    const allocation = allocateBudget({
      totalBudget,
      channels: scoredChannels,
      constraints,
      optimizationGoal,
    });

    // --- CAMPAIGN PRIORITIZATION ---
    const campaignPriorities = prioritizeCampaigns(campaigns, allocation);

    // --- ROI PROJECTIONS ---
    const projections = projectROI(allocation, scoredChannels);

    // --- OPTIMIZATION RECOMMENDATIONS ---
    const recommendations = generateRecommendations({
      allocation,
      scoredChannels,
      objectives,
      projections,
    });

    // --- TIMING OPTIMIZATION ---
    const timingStrategy = optimizeTiming(allocation, channels);

    // --- AUDIENCE SEGMENTATION ---
    const audienceStrategy = optimizeAudiences(allocation, channels);

    return Response.json({
      success: true,
      allocation,
      projections,
      insights: {
        expectedROI: projections.totalROI,
        expectedRevenue: projections.totalRevenue,
        breakEvenPoint: projections.breakEvenDays,
        efficiency: projections.efficiency,
      },
      recommendations,
      strategies: {
        timing: timingStrategy,
        audience: audienceStrategy,
        campaigns: campaignPriorities,
      },
      metadata: {
        totalBudget,
        channelsAnalyzed: channels.length,
        campaignsAnalyzed: campaigns.length,
        optimizationGoal,
        generatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Marketing optimization error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- SCORING FUNCTIONS ---

function scoreChannels(channels, objectives, goal) {
  return channels.map((channel) => {
    // Base scores
    const roiScore = normalizeScore(channel.historicalROI || 1, 0, 5);
    const reachScore = normalizeScore(
      channel.estimatedReach || 1000,
      0,
      100000,
    );
    const engagementScore = normalizeScore(
      channel.engagementRate || 0.02,
      0,
      0.1,
    );
    const conversionScore = normalizeScore(
      channel.conversionRate || 0.01,
      0,
      0.05,
    );
    const costEfficiency = normalizeScore(
      1 / (channel.costPerLead || 10),
      0,
      0.2,
    );

    // Objective alignment
    const objectiveScore = calculateObjectiveAlignment(channel, objectives);

    // Composite score based on goal
    let compositeScore;
    if (goal === "maximize_roi") {
      compositeScore =
        roiScore * 0.4 +
        costEfficiency * 0.3 +
        conversionScore * 0.2 +
        objectiveScore * 0.1;
    } else if (goal === "maximize_reach") {
      compositeScore =
        reachScore * 0.5 + engagementScore * 0.3 + objectiveScore * 0.2;
    } else {
      // balanced
      compositeScore =
        roiScore * 0.25 +
        reachScore * 0.2 +
        engagementScore * 0.2 +
        conversionScore * 0.2 +
        objectiveScore * 0.15;
    }

    return {
      ...channel,
      scores: {
        roi: roiScore,
        reach: reachScore,
        engagement: engagementScore,
        conversion: conversionScore,
        costEfficiency,
        objective: objectiveScore,
        composite: compositeScore,
      },
    };
  });
}

function calculateObjectiveAlignment(channel, objectives) {
  const { awareness = 0.33, conversion = 0.33, retention = 0.33 } = objectives;

  // Channels have different strengths for different objectives
  const channelStrengths = {
    social: { awareness: 0.8, conversion: 0.4, retention: 0.6 },
    search: { awareness: 0.5, conversion: 0.9, retention: 0.3 },
    display: { awareness: 0.9, conversion: 0.3, retention: 0.4 },
    email: { awareness: 0.3, conversion: 0.6, retention: 0.9 },
    content: { awareness: 0.7, conversion: 0.7, retention: 0.7 },
  };

  const channelType = (channel.type || "content").toLowerCase();
  const strengths = channelStrengths[channelType] || channelStrengths.content;

  const alignmentScore =
    strengths.awareness * awareness +
    strengths.conversion * conversion +
    strengths.retention * retention;

  return alignmentScore;
}

function normalizeScore(value, min, max) {
  if (max === min) return 0.5;
  return Math.min(1, Math.max(0, (value - min) / (max - min)));
}

// --- ALLOCATION FUNCTIONS ---

function allocateBudget({
  totalBudget,
  channels,
  constraints,
  optimizationGoal,
}) {
  const {
    minChannelBudget = totalBudget * 0.05, // Minimum 5% per channel
    maxChannelBudget = totalBudget * 0.5, // Maximum 50% per channel
    minChannels = 2, // Diversification requirement
  } = constraints;

  // Sort channels by composite score
  const sortedChannels = [...channels].sort(
    (a, b) => b.scores.composite - a.scores.composite,
  );

  // Calculate proportional allocation based on scores
  const totalScore = sortedChannels.reduce(
    (sum, c) => sum + c.scores.composite,
    0,
  );

  const allocations = sortedChannels.map((channel) => {
    // Proportional allocation
    const rawAllocation = (channel.scores.composite / totalScore) * totalBudget;

    // Apply constraints
    const constrainedAllocation = Math.max(
      minChannelBudget,
      Math.min(maxChannelBudget, rawAllocation),
    );

    return {
      channel: channel.name,
      channelType: channel.type,
      budget: Math.round(constrainedAllocation * 100) / 100,
      percentage:
        Math.round((constrainedAllocation / totalBudget) * 100 * 10) / 10,
      scores: channel.scores,
      expectedROI: channel.historicalROI || 1.5,
      expectedRevenue:
        Math.round(
          constrainedAllocation * (channel.historicalROI || 1.5) * 100,
        ) / 100,
      estimatedLeads: Math.round(
        constrainedAllocation / (channel.costPerLead || 10),
      ),
    };
  });

  // Rebalance if constraints cause over/under allocation
  const totalAllocated = allocations.reduce((sum, a) => sum + a.budget, 0);
  if (Math.abs(totalAllocated - totalBudget) > 0.01) {
    const adjustmentFactor = totalBudget / totalAllocated;
    allocations.forEach((a) => {
      a.budget = Math.round(a.budget * adjustmentFactor * 100) / 100;
      a.percentage = Math.round((a.budget / totalBudget) * 100 * 10) / 10;
      a.expectedRevenue = Math.round(a.budget * a.expectedROI * 100) / 100;
    });
  }

  return allocations;
}

// --- CAMPAIGN PRIORITIZATION ---

function prioritizeCampaigns(campaigns, allocation) {
  if (!campaigns || campaigns.length === 0) return [];

  return campaigns
    .map((campaign) => {
      const channelAllocation = allocation.find(
        (a) => a.channelType === campaign.channel,
      );
      const channelBudget = channelAllocation ? channelAllocation.budget : 0;

      const performanceScore =
        (campaign.clickRate || 0.02) * (campaign.conversionRate || 0.01) * 1000;
      const efficiencyScore = channelBudget / (campaign.cost || 1);
      const urgencyScore = campaign.deadline
        ? Math.max(
            0,
            1 -
              (new Date(campaign.deadline) - Date.now()) /
                (30 * 24 * 60 * 60 * 1000),
          )
        : 0.5;

      const priorityScore =
        performanceScore * 0.4 + efficiencyScore * 0.3 + urgencyScore * 0.3;

      return {
        ...campaign,
        priorityScore,
        priority:
          priorityScore > 0.7 ? "high" : priorityScore > 0.4 ? "medium" : "low",
        recommendedBudget:
          Math.round(channelBudget * (priorityScore / 10) * 100) / 100,
      };
    })
    .sort((a, b) => b.priorityScore - a.priorityScore);
}

// --- PROJECTION FUNCTIONS ---

function projectROI(allocation, scoredChannels) {
  const totalBudget = allocation.reduce((sum, a) => sum + a.budget, 0);
  const totalRevenue = allocation.reduce(
    (sum, a) => sum + a.expectedRevenue,
    0,
  );
  const totalROI = totalRevenue / totalBudget;

  const weightedEfficiency = allocation.reduce((sum, a) => {
    const channel = scoredChannels.find((c) => c.name === a.channel);
    return sum + (channel?.scores.composite || 0.5) * (a.budget / totalBudget);
  }, 0);

  return {
    totalBudget,
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    totalROI: Math.round(totalROI * 100) / 100,
    efficiency: Math.round(weightedEfficiency * 100),
    breakEvenDays: Math.round(30 / (totalROI > 1 ? totalROI : 1)),
    projectedLeads: allocation.reduce((sum, a) => sum + a.estimatedLeads, 0),
  };
}

// --- RECOMMENDATIONS ---

function generateRecommendations({
  allocation,
  scoredChannels,
  objectives,
  projections,
}) {
  const recommendations = [];

  // High ROI channel recommendations
  const highROIChannels = allocation.filter((a) => a.expectedROI > 3);
  if (highROIChannels.length > 0) {
    recommendations.push({
      type: "increase",
      priority: "high",
      message: `High ROI channels detected: ${highROIChannels.map((c) => c.channel).join(", ")}`,
      action: `Consider increasing budget allocation to these channels by 10-20%`,
    });
  }

  // Low performing channel recommendations
  const lowROIChannels = allocation.filter((a) => a.expectedROI < 1.2);
  if (lowROIChannels.length > 0) {
    recommendations.push({
      type: "decrease",
      priority: "medium",
      message: `Underperforming channels: ${lowROIChannels.map((c) => c.channel).join(", ")}`,
      action: `Optimize or reduce spend on these channels`,
    });
  }

  // Diversification check
  const topChannelPercentage = Math.max(...allocation.map((a) => a.percentage));
  if (topChannelPercentage > 60) {
    recommendations.push({
      type: "diversify",
      priority: "medium",
      message: "Portfolio is concentrated in one channel",
      action: "Diversify spend across multiple channels to reduce risk",
    });
  }

  // ROI threshold check
  if (projections.totalROI < 1.5) {
    recommendations.push({
      type: "optimize",
      priority: "high",
      message: "Overall ROI below target threshold",
      action:
        "Review channel performance and reallocate to higher-performing channels",
    });
  }

  return recommendations;
}

// --- TIMING OPTIMIZATION ---

function optimizeTiming(allocation, channels) {
  return allocation.map((a) => {
    const channel = channels.find((c) => c.name === a.channel);
    const bestDays = channel?.peakDays || ["Monday", "Tuesday", "Wednesday"];
    const bestHours = channel?.peakHours || [9, 10, 11, 14, 15];

    return {
      channel: a.channel,
      recommendedDays: bestDays,
      recommendedHours: bestHours,
      seasonality: channel?.seasonality || "consistent",
    };
  });
}

// --- AUDIENCE OPTIMIZATION ---

function optimizeAudiences(allocation, channels) {
  return allocation.map((a) => {
    const channel = channels.find((c) => c.name === a.channel);

    return {
      channel: a.channel,
      primaryAudience: channel?.primaryAudience || "general",
      segmentRecommendations: channel?.topSegments || [
        "demo_25-34",
        "interest_sports",
      ],
      targetingStrategy: a.expectedROI > 2 ? "broad" : "narrow",
    };
  });
}
