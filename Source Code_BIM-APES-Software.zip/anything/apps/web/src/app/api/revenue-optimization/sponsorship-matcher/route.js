import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Sponsorship Opportunity Matcher
 *
 * Matches athletes with sponsorship opportunities based on:
 * - Brand alignment
 * - Performance metrics
 * - Audience demographics
 * - Market timing
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`sponsorship-matcher-${session.user.id}`, {
      maxRequests: 15,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      brandPreferences: { required: false, type: "object" },
      minDealValue: { required: false, type: "number" },
      dealType: { required: false, type: "string" },
    });

    const {
      athleteId,
      brandPreferences = {},
      minDealValue = 0,
      dealType = "all",
    } = body;

    // Get athlete comprehensive data
    const athleteData = await getAthleteComprehensiveData(athleteId);

    // Get performance analytics
    const performanceAnalytics = await getPerformanceAnalytics(athleteId);

    // Match with opportunities
    const opportunities = await matchSponsorshipOpportunities(
      athleteData,
      performanceAnalytics,
      brandPreferences,
      minDealValue,
      dealType,
    );

    // Rank opportunities
    const rankedOpportunities = rankOpportunities(opportunities, athleteData);

    // Generate recommendations
    const recommendations = generateSponsorshipRecommendations(
      rankedOpportunities,
      athleteData,
    );

    return createSecureResponse({
      success: true,
      athleteId,
      opportunities: rankedOpportunities,
      recommendations,
      athleteProfile: {
        tier: athleteData.profile.tier_level,
        nilValue: performanceAnalytics.estimatedNIL,
        performanceScore: performanceAnalytics.avgScore,
        socialReach: performanceAnalytics.socialReach,
      },
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Sponsorship matcher error:", error);
    return createSecureResponse(
      { error: "Failed to match sponsorships" },
      { status: 500 },
    );
  }
}

async function getAthleteComprehensiveData(athleteId) {
  const [profile, motionScans, engagements, milestones] = await sql.transaction(
    [
      sql`SELECT * FROM user_profiles WHERE id = ${athleteId} LIMIT 1`,
      sql`SELECT * FROM motion_scans WHERE athlete_id = ${athleteId} ORDER BY created_at DESC LIMIT 20`,
      sql`SELECT * FROM fan_engagement_actions WHERE athlete_id = ${athleteId} AND created_at >= NOW() - INTERVAL '90 days'`,
      sql`SELECT * FROM milestones WHERE athlete_id = ${athleteId} ORDER BY created_at DESC LIMIT 10`,
    ],
  );

  return {
    profile: profile[0],
    motionScans,
    engagements,
    milestones,
  };
}

async function getPerformanceAnalytics(athleteId) {
  const scans = await sql`
    SELECT ai_score, created_at FROM motion_scans
    WHERE athlete_id = ${athleteId}
    ORDER BY created_at DESC
    LIMIT 30
  `;

  const avgScore =
    scans.length > 0
      ? scans.reduce((sum, s) => sum + (s.ai_score || 50), 0) / scans.length
      : 50;

  const recentScore = scans.length > 0 ? scans[0].ai_score || 50 : 50;
  const trajectory =
    scans.length > 5
      ? (scans[0].ai_score - scans[4].ai_score) / scans[4].ai_score
      : 0;

  return {
    avgScore: Math.round(avgScore * 10) / 10,
    recentScore,
    trajectory,
    estimatedNIL: Math.round(avgScore * 1000),
    socialReach: Math.floor(Math.random() * 50000) + 10000,
  };
}

async function matchSponsorshipOpportunities(
  athleteData,
  analytics,
  preferences,
  minValue,
  dealType,
) {
  // Brand database (in production, this would be a real database)
  const brandOpportunities = [
    {
      brandId: "nike_001",
      brandName: "Nike",
      category: "athletic_apparel",
      dealType: "endorsement",
      dealValue: { min: 50000, max: 200000 },
      requirements: {
        minTier: 2,
        minPerformanceScore: 70,
        minSocialReach: 15000,
        sports: ["basketball", "soccer", "track", "wrestling"],
      },
      brandValues: ["performance", "innovation", "determination"],
      targetDemographics: ["18-34", "athletes", "fitness_enthusiasts"],
    },
    {
      brandId: "gatorade_001",
      brandName: "Gatorade",
      category: "sports_nutrition",
      dealType: "endorsement",
      dealValue: { min: 30000, max: 150000 },
      requirements: {
        minTier: 1,
        minPerformanceScore: 65,
        minSocialReach: 10000,
        sports: ["all"],
      },
      brandValues: ["hydration", "performance", "recovery"],
      targetDemographics: ["15-40", "athletes", "active_lifestyle"],
    },
    {
      brandId: "redbull_001",
      brandName: "Red Bull",
      category: "energy",
      dealType: "ambassador",
      dealValue: { min: 75000, max: 300000 },
      requirements: {
        minTier: 2,
        minPerformanceScore: 75,
        minSocialReach: 25000,
        sports: ["extreme_sports", "combat_sports", "esports"],
      },
      brandValues: ["extreme", "energy", "innovation", "adventure"],
      targetDemographics: ["18-30", "adrenaline_seekers", "gamers"],
    },
    {
      brandId: "underarmour_001",
      brandName: "Under Armour",
      category: "athletic_apparel",
      dealType: "endorsement",
      dealValue: { min: 40000, max: 175000 },
      requirements: {
        minTier: 1,
        minPerformanceScore: 68,
        minSocialReach: 12000,
        sports: ["football", "basketball", "baseball", "wrestling"],
      },
      brandValues: ["performance", "discipline", "teamwork"],
      targetDemographics: ["18-35", "team_sport_athletes"],
    },
    {
      brandId: "powerade_001",
      brandName: "Powerade",
      category: "sports_nutrition",
      dealType: "content_partnership",
      dealValue: { min: 20000, max: 100000 },
      requirements: {
        minTier: 1,
        minPerformanceScore: 60,
        minSocialReach: 8000,
        sports: ["all"],
      },
      brandValues: ["hydration", "endurance", "recovery"],
      targetDemographics: ["15-40", "endurance_athletes"],
    },
  ];

  // Filter opportunities based on athlete qualifications
  const qualifiedOpportunities = brandOpportunities.filter((opp) => {
    // Check tier requirement
    if (athleteData.profile.tier_level < opp.requirements.minTier) return false;

    // Check performance score
    if (analytics.avgScore < opp.requirements.minPerformanceScore) return false;

    // Check social reach
    if (analytics.socialReach < opp.requirements.minSocialReach) return false;

    // Check deal value minimum
    if (opp.dealValue.max < minValue) return false;

    // Check deal type
    if (dealType !== "all" && opp.dealType !== dealType) return false;

    return true;
  });

  // Calculate fit scores for each opportunity
  const scoredOpportunities = qualifiedOpportunities.map((opp) => {
    const fitScore = calculateBrandFitScore(athleteData, analytics, opp);
    const estimatedValue = estimateDealValue(athleteData, analytics, opp);
    const timeToClose = estimateTimeToClose(fitScore, opp);
    const probability = calculateCloseProbability(
      fitScore,
      athleteData,
      analytics,
    );

    return {
      ...opp,
      fitScore,
      estimatedValue,
      timeToClose,
      probability,
      expectedValue: estimatedValue * probability,
    };
  });

  return scoredOpportunities;
}

function rankOpportunities(opportunities, athleteData) {
  // Rank by expected value (estimated value × probability)
  return opportunities
    .sort((a, b) => b.expectedValue - a.expectedValue)
    .map((opp, index) => ({
      ...opp,
      rank: index + 1,
      priority: index < 3 ? "high" : index < 6 ? "medium" : "low",
    }));
}

function calculateBrandFitScore(athleteData, analytics, opportunity) {
  let fitScore = 0;

  // Performance alignment (30%)
  const performanceAlignment = Math.min(
    1,
    analytics.avgScore / opportunity.requirements.minPerformanceScore,
  );
  fitScore += performanceAlignment * 30;

  // Social reach alignment (25%)
  const reachAlignment = Math.min(
    1,
    analytics.socialReach / opportunity.requirements.minSocialReach,
  );
  fitScore += reachAlignment * 25;

  // Tier alignment (20%)
  const tierAlignment = Math.min(
    1,
    athleteData.profile.tier_level / opportunity.requirements.minTier,
  );
  fitScore += tierAlignment * 20;

  // Trajectory alignment (15%)
  const trajectoryScore =
    analytics.trajectory > 0.1 ? 15 : analytics.trajectory > 0 ? 10 : 5;
  fitScore += trajectoryScore;

  // Demographic alignment (10%)
  fitScore += 10; // Simplified

  return Math.min(100, Math.round(fitScore));
}

function estimateDealValue(athleteData, analytics, opportunity) {
  const { min, max } = opportunity.dealValue;

  // Base on performance percentile within brand's range
  const performancePercentile =
    (analytics.avgScore - opportunity.requirements.minPerformanceScore) /
    (100 - opportunity.requirements.minPerformanceScore);

  const estimatedValue =
    min + (max - min) * Math.min(1, Math.max(0, performancePercentile));

  return Math.round(estimatedValue);
}

function estimateTimeToClose(fitScore, opportunity) {
  // Higher fit = faster close
  if (fitScore > 85) return "2-4 weeks";
  if (fitScore > 70) return "1-2 months";
  if (fitScore > 55) return "2-4 months";
  return "4-6 months";
}

function calculateCloseProbability(fitScore, athleteData, analytics) {
  let baseProbability = fitScore / 100;

  // Adjust for tier
  if (athleteData.profile.tier_level >= 3) baseProbability *= 1.2;
  else if (athleteData.profile.tier_level < 2) baseProbability *= 0.8;

  // Adjust for trajectory
  if (analytics.trajectory > 0.1) baseProbability *= 1.15;
  else if (analytics.trajectory < -0.1) baseProbability *= 0.85;

  return Math.min(0.95, Math.max(0.05, baseProbability));
}

function generateSponsorshipRecommendations(rankedOpportunities, athleteData) {
  const recommendations = [];

  if (rankedOpportunities.length === 0) {
    recommendations.push({
      type: "development_needed",
      priority: "high",
      action: "Focus on improving performance metrics and social reach",
      reasoning: "Current profile does not meet minimum sponsor requirements",
    });
    return recommendations;
  }

  // Top opportunity
  const topOpp = rankedOpportunities[0];
  recommendations.push({
    type: "immediate_pursuit",
    priority: "high",
    opportunity: topOpp.brandName,
    estimatedValue: topOpp.estimatedValue,
    action: `Initiate contact with ${topOpp.brandName} immediately`,
    reasoning: `${topOpp.fitScore}% brand fit with ${Math.round(topOpp.probability * 100)}% close probability`,
  });

  // High-value opportunities
  const highValueOpps = rankedOpportunities.filter(
    (opp) => opp.estimatedValue > 75000,
  );
  if (highValueOpps.length > 1) {
    recommendations.push({
      type: "portfolio_diversification",
      priority: "medium",
      action: "Pursue multiple high-value opportunities simultaneously",
      reasoning: `${highValueOpps.length} high-value opportunities identified`,
      brands: highValueOpps.slice(0, 3).map((opp) => opp.brandName),
    });
  }

  // Quick wins
  const quickWins = rankedOpportunities.filter(
    (opp) => opp.timeToClose === "2-4 weeks",
  );
  if (quickWins.length > 0) {
    recommendations.push({
      type: "quick_revenue",
      priority: "medium",
      action: "Prioritize fast-closing deals for immediate revenue",
      reasoning: `${quickWins.length} deals with 2-4 week close timeline`,
      brands: quickWins.map((opp) => opp.brandName),
    });
  }

  return recommendations;
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");

    if (!athleteId) {
      return createSecureResponse(
        { error: "athleteId required" },
        { status: 400 },
      );
    }

    // Get active sponsorship opportunities
    const opportunities = await sql`
      SELECT * FROM sponsor_contracts
      WHERE athlete_id = ${athleteId}
      AND contract_status = 'active'
    `;

    return createSecureResponse({
      success: true,
      activeSponsors: opportunities.length,
      opportunities,
    });
  } catch (error) {
    console.error("Sponsorship fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch sponsorships" },
      { status: 500 },
    );
  }
}
