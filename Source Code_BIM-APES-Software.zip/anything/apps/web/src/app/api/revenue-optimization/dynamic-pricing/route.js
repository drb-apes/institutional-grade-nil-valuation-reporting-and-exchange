import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Revenue Optimization Engine
 * Dynamic Pricing Algorithm
 *
 * Calculates optimal pricing based on:
 * - Real-time demand signals
 * - Performance metrics
 * - Market conditions
 * - Competitor pricing
 * - Inventory availability
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      entityType = "concert", // concert, game, event, merchandise
      entityId,
      basePrice,
      currentDemand = 0.5, // 0-1 scale
      performanceScore = 0.5, // 0-1 scale
      inventoryRemaining = 1, // 0-1 scale (1 = full inventory)
      competitorPricing = [],
      timeToEvent = 30, // days
      seasonality = "normal", // peak, normal, off-peak
      weatherConditions = "good", // good, moderate, poor
      socialSentiment = 0.5, // 0-1 scale
    } = body;

    if (!basePrice) {
      return Response.json(
        { error: "Base price is required" },
        { status: 400 },
      );
    }

    // --- DEMAND MULTIPLIER ---
    const demandMultiplier = calculateDemandMultiplier(currentDemand);

    // --- PERFORMANCE MULTIPLIER ---
    const performanceMultiplier =
      calculatePerformanceMultiplier(performanceScore);

    // --- SCARCITY MULTIPLIER ---
    const scarcityMultiplier = calculateScarcityMultiplier(inventoryRemaining);

    // --- TIME-TO-EVENT MULTIPLIER ---
    const timeMultiplier = calculateTimeMultiplier(timeToEvent);

    // --- SEASONALITY MULTIPLIER ---
    const seasonalityMultiplier = calculateSeasonalityMultiplier(seasonality);

    // --- WEATHER MULTIPLIER ---
    const weatherMultiplier = calculateWeatherMultiplier(weatherConditions);

    // --- SOCIAL SENTIMENT MULTIPLIER ---
    const sentimentMultiplier = calculateSentimentMultiplier(socialSentiment);

    // --- COMPETITOR PRICING ADJUSTMENT ---
    const competitorAdjustment = calculateCompetitorAdjustment(
      basePrice,
      competitorPricing,
    );

    // --- CALCULATE OPTIMAL PRICE ---
    const rawOptimalPrice =
      basePrice *
      demandMultiplier *
      performanceMultiplier *
      scarcityMultiplier *
      timeMultiplier *
      seasonalityMultiplier *
      weatherMultiplier *
      sentimentMultiplier;

    const optimalPrice = applyCompetitorAdjustment(
      rawOptimalPrice,
      competitorAdjustment,
    );

    // --- PRICE CEILING & FLOOR ---
    const priceCeiling = basePrice * 3; // Max 3x base price
    const priceFloor = basePrice * 0.5; // Min 50% of base price
    const finalPrice = Math.max(
      priceFloor,
      Math.min(priceCeiling, optimalPrice),
    );

    // --- CALCULATE ELASTICITY ---
    const priceElasticity = calculatePriceElasticity(
      currentDemand,
      inventoryRemaining,
    );

    // --- REVENUE PROJECTION ---
    const expectedSalesVolume = estimateSalesVolume(
      currentDemand,
      inventoryRemaining,
      priceElasticity,
      (finalPrice - basePrice) / basePrice,
    );

    const projectedRevenue = finalPrice * expectedSalesVolume;

    // --- CONFIDENCE SCORE ---
    const confidenceScore = calculateConfidenceScore({
      demandSignalStrength: currentDemand,
      dataQuality: competitorPricing.length > 0 ? 0.8 : 0.5,
      marketVolatility: Math.abs(finalPrice - basePrice) / basePrice,
    });

    // --- RECOMMENDATIONS ---
    const recommendations = generatePricingRecommendations({
      basePrice,
      finalPrice,
      currentDemand,
      inventoryRemaining,
      timeToEvent,
    });

    return Response.json({
      success: true,
      pricing: {
        basePrice,
        optimalPrice: Math.round(finalPrice * 100) / 100,
        priceChange: Math.round((finalPrice - basePrice) * 100) / 100,
        priceChangePercent:
          Math.round(((finalPrice - basePrice) / basePrice) * 100 * 10) / 10,
      },
      multipliers: {
        demand: Math.round(demandMultiplier * 100) / 100,
        performance: Math.round(performanceMultiplier * 100) / 100,
        scarcity: Math.round(scarcityMultiplier * 100) / 100,
        time: Math.round(timeMultiplier * 100) / 100,
        seasonality: Math.round(seasonalityMultiplier * 100) / 100,
        weather: Math.round(weatherMultiplier * 100) / 100,
        sentiment: Math.round(sentimentMultiplier * 100) / 100,
      },
      projections: {
        expectedSalesVolume: Math.round(expectedSalesVolume),
        projectedRevenue: Math.round(projectedRevenue * 100) / 100,
        priceElasticity: Math.round(priceElasticity * 100) / 100,
      },
      analysis: {
        confidenceScore: Math.round(confidenceScore * 100),
        competitorPosition: competitorAdjustment.position,
        recommendations,
      },
    });
  } catch (error) {
    console.error("Dynamic pricing error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- CALCULATION FUNCTIONS ---

function calculateDemandMultiplier(demand) {
  // Exponential scaling: high demand → significant price increase
  return 0.7 + demand * 0.6;
}

function calculatePerformanceMultiplier(score) {
  // Strong performance → premium pricing
  return 0.9 + score * 0.3;
}

function calculateScarcityMultiplier(inventory) {
  // Low inventory → higher prices
  return 1 + (1 - inventory) * 0.5;
}

function calculateTimeMultiplier(daysToEvent) {
  if (daysToEvent <= 3) return 1.3; // Last-minute premium
  if (daysToEvent <= 7) return 1.15; // Week-out boost
  if (daysToEvent <= 14) return 1.0; // Two weeks - normal
  if (daysToEvent <= 30) return 0.95; // Month out - slight discount
  return 0.85; // Early bird discount
}

function calculateSeasonalityMultiplier(season) {
  const multipliers = {
    peak: 1.2,
    normal: 1.0,
    "off-peak": 0.85,
  };
  return multipliers[season] || 1.0;
}

function calculateWeatherMultiplier(weather) {
  const multipliers = {
    good: 1.0,
    moderate: 0.95,
    poor: 0.85,
  };
  return multipliers[weather] || 1.0;
}

function calculateSentimentMultiplier(sentiment) {
  // Social buzz drives pricing
  return 0.9 + sentiment * 0.2;
}

function calculateCompetitorAdjustment(basePrice, competitors) {
  if (!competitors || competitors.length === 0) {
    return { adjustment: 1.0, position: "unknown" };
  }

  const avgCompetitorPrice =
    competitors.reduce((sum, c) => sum + c.price, 0) / competitors.length;
  const priceRatio = basePrice / avgCompetitorPrice;

  let position = "competitive";
  let adjustment = 1.0;

  if (priceRatio < 0.9) {
    position = "underpriced";
    adjustment = 1.1; // Room to increase
  } else if (priceRatio > 1.1) {
    position = "premium";
    adjustment = 0.95; // Consider reducing
  }

  return { adjustment, position };
}

function applyCompetitorAdjustment(price, { adjustment }) {
  return price * adjustment;
}

function calculatePriceElasticity(demand, inventory) {
  // High demand + low inventory = inelastic (can raise prices)
  // Low demand + high inventory = elastic (price sensitive)
  const elasticity = -1.5 + demand * 0.5 - inventory * 0.3;
  return Math.max(-3, Math.min(-0.5, elasticity));
}

function estimateSalesVolume(
  demand,
  inventory,
  elasticity,
  priceChangePercent,
) {
  const baseVolume = 1000; // Assume 1000 unit base
  const demandFactor = demand * inventory;
  const priceImpact = 1 + elasticity * priceChangePercent;
  return baseVolume * demandFactor * priceImpact;
}

function calculateConfidenceScore({
  demandSignalStrength,
  dataQuality,
  marketVolatility,
}) {
  const demandWeight = demandSignalStrength * 0.4;
  const qualityWeight = dataQuality * 0.3;
  const stabilityWeight = (1 - Math.min(1, marketVolatility)) * 0.3;
  return demandWeight + qualityWeight + stabilityWeight;
}

function generatePricingRecommendations({
  basePrice,
  finalPrice,
  currentDemand,
  inventoryRemaining,
  timeToEvent,
}) {
  const recommendations = [];

  const priceChange = (finalPrice - basePrice) / basePrice;

  if (priceChange > 0.2) {
    recommendations.push({
      type: "increase",
      message: "Strong demand signals support significant price increase",
      action: "Implement dynamic pricing immediately",
    });
  } else if (priceChange < -0.1) {
    recommendations.push({
      type: "decrease",
      message: "Consider promotional pricing to stimulate demand",
      action: "Launch targeted marketing campaign",
    });
  }

  if (inventoryRemaining < 0.3 && currentDemand > 0.6) {
    recommendations.push({
      type: "scarcity",
      message: "Low inventory + high demand = premium pricing opportunity",
      action: "Maximize revenue with scarcity messaging",
    });
  }

  if (inventoryRemaining > 0.7 && timeToEvent < 7) {
    recommendations.push({
      type: "urgency",
      message: "High inventory close to event date",
      action: "Deploy flash sale or last-minute promotion",
    });
  }

  if (currentDemand > 0.8) {
    recommendations.push({
      type: "upsell",
      message: "Extremely high demand detected",
      action: "Introduce premium tiers or VIP packages",
    });
  }

  return recommendations;
}
