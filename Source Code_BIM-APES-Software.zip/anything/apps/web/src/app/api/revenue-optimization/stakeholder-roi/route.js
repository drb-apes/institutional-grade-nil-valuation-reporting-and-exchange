import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Revenue Optimization Engine
 * Stakeholder ROI Analytics
 *
 * Analyzes ROI across multiple stakeholder types:
 * - Athletes / Talent
 * - Sponsors / Brands
 * - Teams / Organizations
 * - Fans / Consumers
 * - Investors / Partners
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      stakeholderType, // athlete, sponsor, team, fan, investor
      stakeholderId,
      investment, // Total invested amount
      revenue, // Total revenue generated
      timePeriod = 30, // Days
      metrics = {}, // Additional metrics
      campaigns = [], // Associated campaigns
      compareAgainst = [], // Benchmark stakeholders
    } = body;

    if (!stakeholderType) {
      return Response.json(
        { error: "Stakeholder type is required" },
        { status: 400 },
      );
    }

    // --- CALCULATE CORE ROI METRICS ---
    const coreMetrics = calculateCoreROI({
      investment,
      revenue,
      timePeriod,
      metrics,
    });

    // --- STAKEHOLDER-SPECIFIC METRICS ---
    const specificMetrics = calculateStakeholderMetrics({
      stakeholderType,
      investment,
      revenue,
      metrics,
      campaigns,
    });

    // --- TIME-BASED ANALYSIS ---
    const timeAnalysis = analyzeTimeBasedROI({
      investment,
      revenue,
      timePeriod,
    });

    // --- COMPARATIVE ANALYSIS ---
    const comparativeAnalysis = compareROI({
      stakeholder: { type: stakeholderType, roi: coreMetrics.roi },
      benchmarks: compareAgainst,
    });

    // --- OPTIMIZATION OPPORTUNITIES ---
    const opportunities = identifyOptimizationOpportunities({
      stakeholderType,
      coreMetrics,
      specificMetrics,
      comparativeAnalysis,
    });

    // --- RISK ASSESSMENT ---
    const riskAssessment = assessROIRisk({
      stakeholderType,
      coreMetrics,
      timePeriod,
      metrics,
    });

    // --- RECOMMENDATIONS ---
    const recommendations = generateROIRecommendations({
      stakeholderType,
      coreMetrics,
      specificMetrics,
      opportunities,
      riskAssessment,
    });

    return Response.json({
      success: true,
      stakeholder: {
        type: stakeholderType,
        id: stakeholderId,
        timePeriod,
      },
      roi: {
        core: coreMetrics,
        specific: specificMetrics,
        timeAnalysis,
      },
      benchmarking: comparativeAnalysis,
      optimization: {
        opportunities,
        recommendations,
      },
      risk: riskAssessment,
      metadata: {
        calculatedAt: new Date().toISOString(),
        currency: "USD",
      },
    });
  } catch (error) {
    console.error("Stakeholder ROI error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- CORE ROI CALCULATIONS ---

function calculateCoreROI({ investment, revenue, timePeriod, metrics }) {
  const netProfit = (revenue || 0) - (investment || 0);
  const roi = investment > 0 ? (netProfit / investment) * 100 : 0;
  const roiMultiple = investment > 0 ? revenue / investment : 0;

  const annualizedROI = timePeriod > 0 ? (roi * 365) / timePeriod : roi;
  const dailyROI = timePeriod > 0 ? roi / timePeriod : 0;

  const paybackPeriod =
    revenue > 0 && timePeriod > 0 ? investment / (revenue / timePeriod) : null;

  const profitMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;

  return {
    investment: Math.round((investment || 0) * 100) / 100,
    revenue: Math.round((revenue || 0) * 100) / 100,
    netProfit: Math.round(netProfit * 100) / 100,
    roi: Math.round(roi * 10) / 10,
    roiMultiple: Math.round(roiMultiple * 100) / 100,
    annualizedROI: Math.round(annualizedROI * 10) / 10,
    dailyROI: Math.round(dailyROI * 100) / 100,
    paybackPeriod: paybackPeriod ? Math.round(paybackPeriod * 10) / 10 : null,
    profitMargin: Math.round(profitMargin * 10) / 10,
  };
}

// --- STAKEHOLDER-SPECIFIC METRICS ---

function calculateStakeholderMetrics({
  stakeholderType,
  investment,
  revenue,
  metrics,
  campaigns,
}) {
  switch (stakeholderType.toLowerCase()) {
    case "athlete":
    case "talent":
      return calculateAthleteROI(investment, revenue, metrics);

    case "sponsor":
    case "brand":
      return calculateSponsorROI(investment, revenue, metrics, campaigns);

    case "team":
    case "organization":
      return calculateTeamROI(investment, revenue, metrics);

    case "fan":
    case "consumer":
      return calculateFanROI(investment, revenue, metrics);

    case "investor":
    case "partner":
      return calculateInvestorROI(investment, revenue, metrics);

    default:
      return {};
  }
}

function calculateAthleteROI(investment, revenue, metrics) {
  const nilValue = metrics.nilValue || 0;
  const performanceScore = metrics.performanceScore || 0;
  const mediaImpressions = metrics.mediaImpressions || 0;
  const fanEngagement = metrics.fanEngagement || 0;

  return {
    nilGrowth:
      nilValue > investment ? ((nilValue - investment) / investment) * 100 : 0,
    performanceROI: performanceScore * 10,
    mediaValue: (mediaImpressions / 1000) * 0.05, // $0.05 per 1K impressions
    engagementValue: fanEngagement * 2, // $2 per engaged fan
    careerTrajectory:
      performanceScore > 80
        ? "rising"
        : performanceScore > 60
          ? "stable"
          : "developing",
  };
}

function calculateSponsorROI(investment, revenue, metrics, campaigns) {
  const brandLift = metrics.brandLift || 0;
  const impressions = metrics.impressions || 0;
  const engagementRate = metrics.engagementRate || 0.02;
  const conversions = metrics.conversions || 0;

  const cpm = investment > 0 ? (investment / impressions) * 1000 : 0;
  const cpa = conversions > 0 ? investment / conversions : 0;
  const engagementValue = impressions * engagementRate * 0.1; // $0.10 per engagement

  return {
    brandLiftPercentage: Math.round(brandLift * 10) / 10,
    cpm: Math.round(cpm * 100) / 100,
    cpa: Math.round(cpa * 100) / 100,
    totalImpressions: impressions,
    engagementValue: Math.round(engagementValue * 100) / 100,
    activeCampaigns: campaigns.length,
    avgCampaignROI:
      campaigns.length > 0
        ? campaigns.reduce((sum, c) => sum + (c.roi || 0), 0) / campaigns.length
        : 0,
  };
}

function calculateTeamROI(investment, revenue, metrics) {
  const playerValueIncrease = metrics.playerValueIncrease || 0;
  const fanbaseGrowth = metrics.fanbaseGrowth || 0;
  const merchandiseRevenue = metrics.merchandiseRevenue || 0;
  const ticketRevenue = metrics.ticketRevenue || 0;

  const totalRevenue = revenue + merchandiseRevenue + ticketRevenue;
  const rosterValue = playerValueIncrease;

  return {
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    rosterValueGrowth: Math.round(rosterValue * 100) / 100,
    fanbaseGrowthPercentage: Math.round(fanbaseGrowth * 10) / 10,
    merchandiseContribution:
      merchandiseRevenue > 0 ? (merchandiseRevenue / totalRevenue) * 100 : 0,
    ticketContribution:
      ticketRevenue > 0 ? (ticketRevenue / totalRevenue) * 100 : 0,
    revenuePerFan: fanbaseGrowth > 0 ? totalRevenue / fanbaseGrowth : 0,
  };
}

function calculateFanROI(investment, revenue, metrics) {
  const contentConsumed = metrics.contentConsumed || 0;
  const socialShares = metrics.socialShares || 0;
  const referrals = metrics.referrals || 0;
  const lifetimeValue = metrics.lifetimeValue || 0;

  const engagementScore =
    contentConsumed * 0.3 + socialShares * 0.5 + referrals * 2;
  const viralCoefficient = referrals > 0 ? referrals / investment : 0;

  return {
    engagementScore: Math.round(engagementScore * 100) / 100,
    socialAmplification: socialShares,
    referralValue: referrals * 50, // $50 per referral
    lifetimeValue: Math.round(lifetimeValue * 100) / 100,
    viralCoefficient: Math.round(viralCoefficient * 100) / 100,
    customerAcquisitionCost: investment,
  };
}

function calculateInvestorROI(investment, revenue, metrics) {
  const portfolioValue = metrics.portfolioValue || 0;
  const distributions = metrics.distributions || 0;
  const unrealizedGains = metrics.unrealizedGains || 0;

  const totalValue = portfolioValue + distributions + unrealizedGains;
  const moic = investment > 0 ? totalValue / investment : 0; // Multiple on Invested Capital
  const irr = calculateIRR(investment, totalValue, metrics.timePeriod || 365);

  return {
    moic: Math.round(moic * 100) / 100,
    irr: Math.round(irr * 10) / 10,
    portfolioValue: Math.round(portfolioValue * 100) / 100,
    distributions: Math.round(distributions * 100) / 100,
    unrealizedGains: Math.round(unrealizedGains * 100) / 100,
    totalValue: Math.round(totalValue * 100) / 100,
  };
}

// --- TIME-BASED ANALYSIS ---

function analyzeTimeBasedROI({ investment, revenue, timePeriod }) {
  const dailyRevenue = timePeriod > 0 ? revenue / timePeriod : 0;
  const weeklyRevenue = dailyRevenue * 7;
  const monthlyRevenue = dailyRevenue * 30;
  const quarterlyRevenue = dailyRevenue * 90;
  const annualRevenue = dailyRevenue * 365;

  const dailyROI =
    investment > 0
      ? ((dailyRevenue - investment / timePeriod) / (investment / timePeriod)) *
        100
      : 0;

  return {
    daily: {
      revenue: Math.round(dailyRevenue * 100) / 100,
      roi: Math.round(dailyROI * 10) / 10,
    },
    weekly: {
      revenue: Math.round(weeklyRevenue * 100) / 100,
    },
    monthly: {
      revenue: Math.round(monthlyRevenue * 100) / 100,
    },
    quarterly: {
      revenue: Math.round(quarterlyRevenue * 100) / 100,
    },
    annual: {
      revenue: Math.round(annualRevenue * 100) / 100,
      projected: true,
    },
  };
}

// --- COMPARATIVE ANALYSIS ---

function compareROI({ stakeholder, benchmarks }) {
  if (!benchmarks || benchmarks.length === 0) {
    return {
      position: "unknown",
      percentile: null,
      comparison: [],
    };
  }

  const allROIs = [stakeholder.roi, ...benchmarks.map((b) => b.roi)].sort(
    (a, b) => b - a,
  );
  const position = allROIs.indexOf(stakeholder.roi) + 1;
  const percentile = ((allROIs.length - position + 1) / allROIs.length) * 100;

  const avgBenchmarkROI =
    benchmarks.reduce((sum, b) => sum + b.roi, 0) / benchmarks.length;
  const performance =
    stakeholder.roi > avgBenchmarkROI
      ? "above"
      : stakeholder.roi < avgBenchmarkROI
        ? "below"
        : "average";

  return {
    position,
    totalBenchmarks: benchmarks.length,
    percentile: Math.round(percentile * 10) / 10,
    performance,
    avgBenchmarkROI: Math.round(avgBenchmarkROI * 10) / 10,
    delta: Math.round((stakeholder.roi - avgBenchmarkROI) * 10) / 10,
    topPerformer: allROIs[0],
    bottomPerformer: allROIs[allROIs.length - 1],
  };
}

// --- OPTIMIZATION OPPORTUNITIES ---

function identifyOptimizationOpportunities({
  stakeholderType,
  coreMetrics,
  specificMetrics,
  comparativeAnalysis,
}) {
  const opportunities = [];

  if (coreMetrics.roi < 50) {
    opportunities.push({
      area: "Overall ROI",
      currentValue: coreMetrics.roi,
      targetValue: 100,
      uplift: 100 - coreMetrics.roi,
      priority: "high",
      actions: [
        "Review cost structure",
        "Optimize pricing strategy",
        "Improve conversion rates",
      ],
    });
  }

  if (coreMetrics.paybackPeriod > 180) {
    opportunities.push({
      area: "Payback Period",
      currentValue: coreMetrics.paybackPeriod,
      targetValue: 90,
      uplift: Math.round(
        ((coreMetrics.paybackPeriod - 90) / coreMetrics.paybackPeriod) * 100,
      ),
      priority: "medium",
      actions: [
        "Accelerate revenue recognition",
        "Reduce upfront costs",
        "Implement early-stage monetization",
      ],
    });
  }

  if (comparativeAnalysis.percentile && comparativeAnalysis.percentile < 50) {
    opportunities.push({
      area: "Competitive Position",
      currentValue: comparativeAnalysis.percentile,
      targetValue: 75,
      uplift: 75 - comparativeAnalysis.percentile,
      priority: "high",
      actions: [
        "Benchmark against top performers",
        "Adopt best practices",
        "Invest in high-ROI channels",
      ],
    });
  }

  return opportunities;
}

// --- RISK ASSESSMENT ---

function assessROIRisk({ stakeholderType, coreMetrics, timePeriod, metrics }) {
  const risks = [];

  if (coreMetrics.roi < 0) {
    risks.push({
      factor: "Negative ROI",
      severity: "critical",
      impact: "Immediate action required to stem losses",
    });
  }

  if (timePeriod < 30) {
    risks.push({
      factor: "Short Time Period",
      severity: "low",
      impact: "Metrics may not be fully representative",
    });
  }

  if (!metrics || Object.keys(metrics).length < 3) {
    risks.push({
      factor: "Limited Data",
      severity: "medium",
      impact: "Analysis based on incomplete information",
    });
  }

  const overallRisk = risks.some((r) => r.severity === "critical")
    ? "high"
    : risks.some((r) => r.severity === "high")
      ? "medium"
      : "low";

  return {
    overallRisk,
    factors: risks,
    confidence:
      timePeriod >= 30 && Object.keys(metrics).length >= 3 ? "high" : "medium",
  };
}

// --- RECOMMENDATIONS ---

function generateROIRecommendations({
  stakeholderType,
  coreMetrics,
  specificMetrics,
  opportunities,
  riskAssessment,
}) {
  const recommendations = [];

  if (coreMetrics.roi > 100) {
    recommendations.push({
      type: "scale",
      message: "Strong ROI indicates opportunity to scale investment",
      action: "Increase budget allocation to maximize returns",
    });
  } else if (coreMetrics.roi > 50) {
    recommendations.push({
      type: "optimize",
      message: "Moderate ROI - focus on efficiency improvements",
      action: "Identify and eliminate low-performing activities",
    });
  } else {
    recommendations.push({
      type: "restructure",
      message: "ROI below target - significant changes needed",
      action: "Conduct comprehensive review and consider strategy pivot",
    });
  }

  if (opportunities.length > 0) {
    recommendations.push({
      type: "opportunity",
      message: `${opportunities.length} optimization opportunities identified`,
      action: "Prioritize highest-impact improvements",
    });
  }

  if (riskAssessment.overallRisk === "high") {
    recommendations.push({
      type: "risk_mitigation",
      message: "High risk factors detected",
      action: "Implement risk mitigation strategies immediately",
    });
  }

  return recommendations;
}

// --- HELPER FUNCTIONS ---

function calculateIRR(investment, totalValue, days) {
  // Simplified IRR calculation
  const periods = days / 365;
  if (periods === 0 || investment === 0) return 0;

  const rate = Math.pow(totalValue / investment, 1 / periods) - 1;
  return rate * 100;
}
