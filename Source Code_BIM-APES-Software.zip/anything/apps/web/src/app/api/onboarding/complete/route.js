import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      selectedRole,
      biometricData,
      qaasDecision,
      socialSync,
      deviceInfo,
    } = await request.json();

    // Validate required fields
    if (!selectedRole || !biometricData) {
      return Response.json(
        { error: "Missing required onboarding data" },
        { status: 400 },
      );
    }

    // Create or update user profile
    const existingProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    let profileId;
    if (existingProfile.length > 0) {
      // Update existing profile
      await sql`
        UPDATE user_profiles 
        SET user_type = ${selectedRole}, 
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ${session.user.id}
      `;
      profileId = existingProfile[0].id;
    } else {
      // Create new profile
      const newProfile = await sql`
        INSERT INTO user_profiles (user_id, user_type, tier_level, reputation_score)
        VALUES (${session.user.id}, ${selectedRole}, 1, 0)
        RETURNING id
      `;
      profileId = newProfile[0].id;
    }

    // Create digital wallet
    const existingWallet = await sql`
      SELECT * FROM digital_wallets WHERE user_id = ${profileId}
    `;

    if (existingWallet.length === 0) {
      await sql`
        INSERT INTO digital_wallets (user_id, wallet_type, balance, available_balance)
        VALUES (${profileId}, ${selectedRole}, 0, 0)
      `;
    }

    // Create initial motion scan with biometric calibration data
    if (selectedRole === "athlete") {
      const motionScanData = {
        biometric_calibration: biometricData,
        qaas_decision: qaasDecision,
        social_sync: socialSync,
        onboarding_completion: true,
        device_info: deviceInfo,
        timestamp: new Date().toISOString(),
      };

      // Calculate initial AI score based on biometric data
      const aiScore = calculateInitialScore(biometricData, qaasDecision);

      await sql`
        INSERT INTO motion_scans (
          athlete_id, 
          scan_data, 
          ai_score, 
          verification_status, 
          motion_type,
          metadata
        )
        VALUES (
          ${profileId},
          ${JSON.stringify(motionScanData)},
          ${aiScore},
          'verified',
          'onboarding_calibration',
          ${JSON.stringify({ source: "mobile_onboarding", version: "1.0" })}
        )
      `;
    }

    // Log onboarding completion for analytics
    await sql`
      INSERT INTO treasury_transactions (
        transaction_type,
        amount,
        balance_after,
        description,
        reference_type
      )
      VALUES (
        'onboarding_bonus',
        50.00,
        50.00,
        ${`Onboarding bonus for ${selectedRole}: ${session.user.name || session.user.email}`},
        'user_onboarding'
      )
    `;

    // Generate initial NIL score and insights
    const nilScore = calculateNILScore(
      biometricData,
      qaasDecision,
      selectedRole,
    );
    const insights = generateOnboardingInsights(
      biometricData,
      qaasDecision,
      selectedRole,
    );

    return Response.json({
      success: true,
      message: "Onboarding completed successfully",
      data: {
        profileId,
        userType: selectedRole,
        nilScore,
        insights,
        walletCreated: existingWallet.length === 0,
        bonusAwarded: 50.0,
      },
    });
  } catch (error) {
    console.error("Onboarding completion error:", error);
    return Response.json(
      {
        error: "Failed to complete onboarding",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateInitialScore(biometricData, qaasDecision) {
  const { fatigue, stress, cohesion } = biometricData;

  // Base score calculation
  let score = 50; // Starting baseline

  // Biometric adjustments
  score += (5 - fatigue) * 5; // Lower fatigue = higher score
  score += (5 - stress) * 3; // Lower stress = higher score
  score += cohesion * 8; // Higher cohesion = higher score

  // QaaS decision bonus
  const qaasBonus = {
    strategic: 10,
    adaptive: 15,
    aggressive: 5,
  };
  score += qaasBonus[qaasDecision] || 0;

  return Math.min(100, Math.max(0, score));
}

function calculateNILScore(biometricData, qaasDecision, role) {
  const baseScore = calculateInitialScore(biometricData, qaasDecision);

  // Role-specific multipliers
  const roleMultipliers = {
    athlete: 1.2,
    coach: 1.0,
    scout: 0.9,
    agent: 1.1,
  };

  const nilScore = Math.round(baseScore * (roleMultipliers[role] || 1.0));
  return Math.min(100, Math.max(30, nilScore));
}

function generateOnboardingInsights(biometricData, qaasDecision, role) {
  const insights = [];
  const { fatigue, stress, cohesion } = biometricData;

  // Biometric insights
  if (fatigue >= 4) {
    insights.push({
      type: "recommendation",
      message:
        "Consider implementing a recovery protocol to optimize performance",
      category: "recovery",
    });
  }

  if (stress >= 4) {
    insights.push({
      type: "alert",
      message:
        "High stress levels detected - mental wellness support recommended",
      category: "wellness",
    });
  }

  if (cohesion <= 2) {
    insights.push({
      type: "opportunity",
      message: "Team building activities could enhance group dynamics",
      category: "team_cohesion",
    });
  }

  // Decision-making insights
  const decisionInsights = {
    strategic:
      "Strong methodical approach - excellent for consistent performance",
    adaptive: "High adaptability scores - valuable in dynamic situations",
    aggressive: "High-risk tolerance - potential for breakthrough moments",
  };

  if (decisionInsights[qaasDecision]) {
    insights.push({
      type: "strength",
      message: decisionInsights[qaasDecision],
      category: "decision_making",
    });
  }

  // Role-specific insights
  const roleInsights = {
    athlete: "Focus on biometric optimization and performance consistency",
    coach: "Leverage analytics for strategic team development",
    scout: "Utilize pattern recognition for talent identification",
    agent: "Balance performance metrics with marketability factors",
  };

  insights.push({
    type: "guidance",
    message:
      roleInsights[role] ||
      "Continue developing your skills in the NIL ecosystem",
    category: "role_development",
  });

  return insights;
}
