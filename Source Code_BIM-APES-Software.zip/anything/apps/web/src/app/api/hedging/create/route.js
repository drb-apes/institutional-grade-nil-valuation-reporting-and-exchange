import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      athlete_id,
      hedge_type,
      ht_token_amount,
      hedge_trigger,
      duration_days = 90,
    } = body;

    if (!athlete_id || !hedge_type || !ht_token_amount || !hedge_trigger) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [sponsorProfile] = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!sponsorProfile) {
      return Response.json(
        { error: "Sponsor profile not found" },
        { status: 404 },
      );
    }

    const expires_at = new Date();
    expires_at.setDate(expires_at.getDate() + duration_days);

    const [hedgePosition] = await sql`
      INSERT INTO hedging_positions (
        sponsor_id, athlete_id, hedge_type, ht_token_amount,
        hedge_trigger, expires_at
      )
      VALUES (
        ${sponsorProfile.id}, ${athlete_id}, ${hedge_type}, ${ht_token_amount},
        ${JSON.stringify(hedge_trigger)}, ${expires_at.toISOString()}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      hedge_position: hedgePosition,
    });
  } catch (error) {
    console.error("Create hedge error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
