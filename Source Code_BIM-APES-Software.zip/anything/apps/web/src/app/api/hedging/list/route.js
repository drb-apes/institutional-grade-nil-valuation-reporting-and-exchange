import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const [sponsorProfile] = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!sponsorProfile) {
      return Response.json(
        { error: "Sponsor profile not found" },
        { status: 404 },
      );
    }

    const hedges = await sql`
      SELECT 
        hp.*,
        up.wallet_address as athlete_wallet,
        au.name as athlete_name
      FROM hedging_positions hp
      JOIN user_profiles up ON up.id = hp.athlete_id
      LEFT JOIN auth_users au ON au.id = up.user_id
      WHERE hp.sponsor_id = ${sponsorProfile.id}
      ORDER BY hp.created_at DESC
    `;

    return Response.json({ hedges });
  } catch (error) {
    console.error("List hedges error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
