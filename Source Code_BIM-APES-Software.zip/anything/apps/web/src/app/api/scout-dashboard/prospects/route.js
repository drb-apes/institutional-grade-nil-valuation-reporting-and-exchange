import sql from "@/app/api/utils/sql";
import { SPORT_PROFILES } from "@/app/api/context/sport-profiles/route";
import { ORG_PROFILES } from "@/app/api/context/org-profiles/route";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sport = searchParams.get("sport") || "wrestling";
  const org = searchParams.get("org") || "ncaa_d1";
  const tier = searchParams.get("tier") || "all";
  const sort = searchParams.get("sort") || "ppi_desc";
  const search = searchParams.get("search") || "";

  try {
    // Fetch all athlete profiles
    const athletes = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.tier_level,
        au.name,
        au.email
      FROM user_profiles up
      INNER JOIN auth_users au ON up.user_id = au.id
      WHERE up.user_type = 'athlete'
      ORDER BY up.tier_level DESC
      LIMIT 100
    `;

    // For each athlete, compute analytics
    const prospects = await Promise.all(
      athletes.map(async (athlete) => {
        // Fetch recent motion scans
        const scans = await sql`
          SELECT * FROM motion_scans
          WHERE athlete_id = ${athlete.id}
          ORDER BY created_at DESC
          LIMIT 15
        `;

        if (scans.length === 0) {
          return null; // Skip athletes with no data
        }

        // Extract PPIs
        const historicalPPIs = scans.map((scan) => ({
          ppi: scan.ai_score || 0,
          timestamp: scan.created_at,
        }));

        // Calculate velocity
        let velocity = 0;
        if (historicalPPIs.length >= 2) {
          const recent = historicalPPIs.slice(0, 5);
          const oldestPPI = recent[recent.length - 1].ppi;
          const newestPPI = recent[0].ppi;
          velocity = newestPPI - oldestPPI;
        }

        // Calculate consistency
        const ppis = historicalPPIs.map((h) => h.ppi);
        const mean = ppis.reduce((sum, v) => sum + v, 0) / ppis.length;
        const variance =
          ppis.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / ppis.length;
        const consistency = Math.max(0, 100 - variance);

        // Breakout probability
        const breakout_probability = Math.min(
          100,
          Math.max(0, velocity * 10 + consistency * 0.3),
        );

        // Determine tier
        const currentPPI = historicalPPIs[0].ppi;
        const sportProfile = SPORT_PROFILES[sport];
        let tierName = "amateur";
        if (sportProfile) {
          for (const [tier, bounds] of Object.entries(
            sportProfile.tierBoundaries,
          )) {
            if (currentPPI >= bounds.ppi_min && currentPPI <= bounds.ppi_max) {
              tierName = tier;
              break;
            }
          }
        }

        // Get org details
        const orgProfile = ORG_PROFILES[org];

        return {
          id: athlete.id,
          name: athlete.name || `Athlete ${athlete.id}`,
          age: Math.floor(Math.random() * 10) + 18, // Mock age data
          position: scans[0].metadata?.position || null,
          ppi: currentPPI,
          tier: tierName,
          velocity,
          consistency,
          breakout_probability: Math.round(breakout_probability),
          org_name: orgProfile?.name || org,
          sport_name: sportProfile?.name || sport,
        };
      }),
    );

    // Filter out null values
    let filteredProspects = prospects.filter((p) => p !== null);

    // Apply tier filter
    if (tier !== "all") {
      filteredProspects = filteredProspects.filter((p) => p.tier === tier);
    }

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filteredProspects = filteredProspects.filter(
        (p) =>
          p.name.toLowerCase().includes(searchLower) ||
          p.position?.toLowerCase().includes(searchLower),
      );
    }

    // Apply sorting
    switch (sort) {
      case "ppi_desc":
        filteredProspects.sort((a, b) => b.ppi - a.ppi);
        break;
      case "ppi_asc":
        filteredProspects.sort((a, b) => a.ppi - b.ppi);
        break;
      case "velocity_desc":
        filteredProspects.sort((a, b) => b.velocity - a.velocity);
        break;
      case "breakout_desc":
        filteredProspects.sort(
          (a, b) => b.breakout_probability - a.breakout_probability,
        );
        break;
      case "recent":
        // Already sorted by creation time
        break;
      default:
        filteredProspects.sort((a, b) => b.ppi - a.ppi);
    }

    return Response.json({
      sport,
      org,
      tier,
      sort,
      prospects: filteredProspects,
      count: filteredProspects.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error fetching prospects:", error);
    return Response.json(
      { error: "Failed to fetch prospects", details: error.message },
      { status: 500 },
    );
  }
}
