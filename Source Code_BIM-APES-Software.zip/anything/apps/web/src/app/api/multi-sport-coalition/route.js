import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const action = url.searchParams.get("action");

    if (action === "coalition_overview") {
      return await getCoalitionOverview();
    } else if (action === "sport_performance") {
      const sport = url.searchParams.get("sport");
      return await getSportPerformanceData(sport);
    } else if (action === "cross_sport_analytics") {
      return await getCrossSportAnalytics();
    }

    // Default: Get all coalition data
    const coalitionData = await getFullCoalitionData();
    return Response.json({
      success: true,
      coalition_data: coalitionData,
    });
  } catch (error) {
    console.error("Multi-sport coalition error:", error);
    return Response.json(
      { error: "Failed to retrieve coalition data" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { action, coalition_data } = await request.json();

    if (action === "create_cross_sport_milestone") {
      return await createCrossSportMilestone(coalition_data);
    } else if (action === "analyze_sport_efficiency") {
      return await analyzeSportEfficiency(coalition_data);
    } else if (action === "generate_coalition_insights") {
      return await generateCoalitionInsights();
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Coalition action error:", error);
    return Response.json(
      { error: "Failed to process coalition action" },
      { status: 500 },
    );
  }
}

async function getCoalitionOverview() {
  const [
    sportDistribution,
    totalAthletes,
    activeMilestones,
    crossSportMetrics,
  ] = await sql.transaction([
    sql`
      SELECT 
        COALESCE(JSON_EXTRACT_PATH_TEXT(simulation_data, 'sport_type'), 'general') as sport,
        COUNT(*) as athlete_count,
        AVG(CAST(JSON_EXTRACT_PATH_TEXT(simulation_data, 'overall_score') AS NUMERIC)) as avg_performance
      FROM asset_simulations
      GROUP BY COALESCE(JSON_EXTRACT_PATH_TEXT(simulation_data, 'sport_type'), 'general')
      ORDER BY athlete_count DESC
    `,
    sql`
      SELECT COUNT(DISTINCT athlete_id) as total_athletes
      FROM asset_simulations
    `,
    sql`
      SELECT 
        COUNT(*) as active_milestones,
        AVG(reward_pool) as avg_reward_pool
      FROM milestones
      WHERE milestone_status = 'active'
    `,
    sql`
      SELECT 
        AVG(CASE WHEN JSON_EXTRACT_PATH_TEXT(simulation_data, 'scale_type') = 'professional' THEN 1.0 ELSE 0.0 END) as professional_ratio,
        MAX(CAST(JSON_EXTRACT_PATH_TEXT(simulation_data, 'overall_score') AS NUMERIC)) as peak_performance,
        COUNT(*) as total_simulations
      FROM asset_simulations
    `,
  ]);

  return Response.json({
    success: true,
    overview: {
      sport_distribution: sportDistribution,
      total_athletes: totalAthletes[0]?.total_athletes || 0,
      active_milestones: activeMilestones[0]?.active_milestones || 0,
      avg_reward_pool: activeMilestones[0]?.avg_reward_pool || 0,
      cross_sport_metrics: crossSportMetrics[0],
      coalition_health: calculateCoalitionHealth(
        sportDistribution,
        crossSportMetrics[0],
      ),
    },
  });
}

async function getSportPerformanceData(sport) {
  if (!sport) {
    return Response.json(
      { error: "Sport parameter required" },
      { status: 400 },
    );
  }

  const sportSpecificData = await sql`
    SELECT 
      a.athlete_id,
      a.simulation_data,
      a.valuation_factors,
      u.tier_level,
      m.title as latest_milestone,
      m.target_metrics
    FROM asset_simulations a
    JOIN user_profiles u ON a.athlete_id = u.id
    LEFT JOIN milestones m ON a.athlete_id = m.athlete_id AND m.milestone_status = 'active'
    WHERE COALESCE(JSON_EXTRACT_PATH_TEXT(a.simulation_data, 'sport_type'), 'general') = ${sport}
    ORDER BY CAST(JSON_EXTRACT_PATH_TEXT(a.simulation_data, 'overall_score') AS NUMERIC) DESC
    LIMIT 50
  `;

  const sportAnalytics = generateSportSpecificAnalytics(
    sport,
    sportSpecificData,
  );

  return Response.json({
    success: true,
    sport: sport,
    athletes: sportSpecificData,
    analytics: sportAnalytics,
    performance_insights: generateSportPerformanceInsights(
      sport,
      sportSpecificData,
    ),
  });
}

async function getCrossSportAnalytics() {
  const crossSportData = await sql`
    SELECT 
      COALESCE(JSON_EXTRACT_PATH_TEXT(simulation_data, 'sport_type'), 'general') as sport,
      JSON_EXTRACT_PATH_TEXT(simulation_data, 'tactical_efficiency') as tactical_efficiency,
      JSON_EXTRACT_PATH_TEXT(simulation_data, 'recovery_index') as recovery_index,
      JSON_EXTRACT_PATH_TEXT(simulation_data, 'spike_score') as spike_score,
      JSON_EXTRACT_PATH_TEXT(simulation_data, 'session_consistency') as session_consistency,
      JSON_EXTRACT_PATH_TEXT(simulation_data, 'bvi') as bvi,
      u.tier_level
    FROM asset_simulations a
    JOIN user_profiles u ON a.athlete_id = u.id
  `;

  const crossSportInsights = analyzeCrossSportPerformance(crossSportData);

  return Response.json({
    success: true,
    cross_sport_analytics: crossSportInsights,
    sport_correlations: calculateSportCorrelations(crossSportData),
    transfer_potential: assessSkillTransferPotential(crossSportData),
  });
}

async function createCrossSportMilestone(coalitionData) {
  const { title, sports_involved, target_metrics, reward_structure } =
    coalitionData;

  const milestone = await sql`
    INSERT INTO milestones (
      athlete_id,
      title,
      description,
      target_metrics,
      reward_pool
    ) VALUES (
      ${coalitionData.primary_athlete_id},
      ${title},
      ${`Cross-sport milestone involving: ${sports_involved.join(", ")}`},
      ${JSON.stringify(target_metrics)},
      ${reward_structure.total_pool}
    )
    RETURNING *
  `;

  return Response.json({
    success: true,
    milestone: milestone[0],
    coalition_impact: assessCoalitionImpact(sports_involved, target_metrics),
  });
}

async function analyzeSportEfficiency(coalitionData) {
  const { sport, analysis_type } = coalitionData;
  let efficiencyMetrics = {};

  switch (sport) {
    case "wrestling":
    case "goalwrestling":
      efficiencyMetrics = analyzeWrestlingEfficiency(coalitionData);
      break;
    case "rugby":
    case "soccer":
    case "basketball":
      efficiencyMetrics = analyzeTacticalSportsEfficiency(coalitionData);
      break;
    case "tennis":
    case "pickleball":
      efficiencyMetrics = analyzeRacketSportsEfficiency(coalitionData);
      break;
    case "american_football":
      efficiencyMetrics = analyzeAmericanFootballEfficiency(coalitionData);
      break;
    default:
      efficiencyMetrics = analyzeGeneralSportEfficiency(coalitionData);
  }

  return Response.json({
    success: true,
    sport: sport,
    efficiency_analysis: efficiencyMetrics,
    improvement_recommendations: generateSportSpecificRecommendations(
      sport,
      efficiencyMetrics,
    ),
  });
}

// Sport-specific analysis functions
function analyzeWrestlingEfficiency(data) {
  return {
    performance_tracking: {
      takedown_efficiency: calculateMetricEfficiency("takedown_rate", data),
      defensive_stability: calculateMetricEfficiency("defensive_holds", data),
      endurance_score: calculateMetricEfficiency("match_endurance", data),
      technical_precision: calculateMetricEfficiency("technical_points", data),
    },
    goal_wrestling_metrics: {
      goal_defense_rate: calculateMetricEfficiency("goal_saves", data),
      positioning_accuracy: calculateMetricEfficiency(
        "position_effectiveness",
        data,
      ),
      reaction_time: calculateMetricEfficiency("reaction_speed", data),
    },
    improvement_areas: identifyWrestlingImprovementAreas(data),
  };
}

function analyzeTacticalSportsEfficiency(data) {
  return {
    tactical_efficiency: {
      team_coordination: calculateMetricEfficiency("team_plays", data),
      spatial_awareness: calculateMetricEfficiency("field_coverage", data),
      decision_making: calculateMetricEfficiency("tactical_decisions", data),
      execution_rate: calculateMetricEfficiency("successful_plays", data),
    },
    sport_specific: {
      rugby: data.sport === "rugby" ? analyzeRugbySpecifics(data) : null,
      soccer: data.sport === "soccer" ? analyzeSoccerSpecifics(data) : null,
      basketball:
        data.sport === "basketball" ? analyzeBasketballSpecifics(data) : null,
    },
    improvement_areas: identifyTacticalImprovementAreas(data),
  };
}

function analyzeRacketSportsEfficiency(data) {
  return {
    spike_score_analysis: {
      power_generation: calculateMetricEfficiency("spike_power", data),
      accuracy_rating: calculateMetricEfficiency("spike_accuracy", data),
      consistency_index: calculateMetricEfficiency("spike_consistency", data),
      tactical_placement: calculateMetricEfficiency("shot_placement", data),
    },
    sport_specific: {
      tennis: data.sport === "tennis" ? analyzeTennisSpecifics(data) : null,
      pickleball:
        data.sport === "pickleball" ? analyzePickleballSpecifics(data) : null,
    },
    improvement_areas: identifyRacketSportsImprovementAreas(data),
  };
}

function analyzeAmericanFootballEfficiency(data) {
  return {
    session_consistency: {
      training_regularity: calculateMetricEfficiency(
        "training_frequency",
        data,
      ),
      performance_stability: calculateMetricEfficiency(
        "consistent_performance",
        data,
      ),
      skill_development: calculateMetricEfficiency("skill_progression", data),
      game_readiness: calculateMetricEfficiency("game_performance", data),
    },
    position_specific: analyzePositionSpecificMetrics(data),
    improvement_areas: identifyFootballImprovementAreas(data),
  };
}

function analyzeGeneralSportEfficiency(data) {
  return {
    general_metrics: {
      overall_performance: calculateMetricEfficiency("overall_score", data),
      consistency: calculateMetricEfficiency("consistency", data),
      improvement_rate: calculateMetricEfficiency("improvement", data),
      competitiveness: calculateMetricEfficiency("competitive_edge", data),
    },
    improvement_areas: [
      "general_fitness",
      "skill_development",
      "mental_preparation",
    ],
  };
}

// Helper functions
function calculateMetricEfficiency(metric, data) {
  const baseEfficiency = 0.75 + Math.random() * 0.2;
  return {
    score: Math.round(baseEfficiency * 100),
    trend: Math.random() > 0.5 ? "improving" : "stable",
    benchmark: Math.round((baseEfficiency - 0.1) * 100),
  };
}

function generateSportSpecificAnalytics(sport, data) {
  const analytics = {
    performance_distribution: calculatePerformanceDistribution(data),
    tier_analysis: analyzeTierDistribution(data),
    milestone_success_rate: calculateMilestoneSuccessRate(data),
    sport_specific_insights: getSportInsights(sport),
  };

  return analytics;
}

function getSportInsights(sport) {
  const insights = {
    wrestling: {
      technique_focus: "grappling_efficiency",
      key_metrics: ["takedown_rate", "defensive_holds", "endurance_score"],
      training_recommendations: [
        "strength_conditioning",
        "technique_drilling",
        "match_simulation",
      ],
    },
    tennis: {
      technique_focus: "spike_optimization",
      key_metrics: ["spike_power", "accuracy_rating", "consistency_index"],
      training_recommendations: [
        "power_training",
        "precision_drills",
        "match_play",
      ],
    },
    american_football: {
      technique_focus: "session_consistency",
      key_metrics: [
        "training_frequency",
        "performance_stability",
        "game_readiness",
      ],
      training_recommendations: [
        "consistent_training",
        "position_drills",
        "game_simulation",
      ],
    },
  };

  return (
    insights[sport] || {
      technique_focus: "general_performance",
      key_metrics: ["overall_score", "consistency", "improvement_rate"],
      training_recommendations: [
        "skill_development",
        "fitness_training",
        "mental_preparation",
      ],
    }
  );
}

function generateSportPerformanceInsights(sport, data) {
  return {
    top_performers: data.slice(0, 5).map((athlete) => ({
      athlete_id: athlete.athlete_id,
      score: JSON.parse(athlete.simulation_data)?.overall_score || 0,
      tier: athlete.tier_level,
    })),
    performance_trends: {
      average_score:
        data.reduce((sum, athlete) => {
          const score = JSON.parse(athlete.simulation_data)?.overall_score || 0;
          return sum + score;
        }, 0) / data.length,
      improvement_potential: calculateImprovementPotential(data),
    },
    sport_specific_notes: getSportSpecificNotes(sport),
  };
}

function calculateCoalitionHealth(sportDistribution, crossSportMetrics) {
  const diversityScore = sportDistribution.length * 10;
  const professionalRatio = (crossSportMetrics?.professional_ratio || 0) * 100;
  const totalSimulations = crossSportMetrics?.total_simulations || 0;

  const healthScore = Math.min(
    100,
    diversityScore + professionalRatio + totalSimulations / 10,
  );

  return {
    overall_score: Math.round(healthScore),
    diversity_score: diversityScore,
    professional_penetration: Math.round(professionalRatio),
    activity_level:
      totalSimulations > 100
        ? "high"
        : totalSimulations > 50
          ? "medium"
          : "low",
    health_status:
      healthScore > 80
        ? "excellent"
        : healthScore > 60
          ? "good"
          : "needs_improvement",
  };
}

function analyzeCrossSportPerformance(data) {
  const sportGroups = data.reduce((acc, row) => {
    const sport = row.sport;
    if (!acc[sport]) acc[sport] = [];
    acc[sport].push(row);
    return acc;
  }, {});

  const insights = {};
  Object.keys(sportGroups).forEach((sport) => {
    insights[sport] = {
      avg_tactical_efficiency: calculateAverage(
        sportGroups[sport],
        "tactical_efficiency",
      ),
      avg_recovery_index: calculateAverage(
        sportGroups[sport],
        "recovery_index",
      ),
      avg_spike_score: calculateAverage(sportGroups[sport], "spike_score"),
      avg_consistency: calculateAverage(
        sportGroups[sport],
        "session_consistency",
      ),
      tier_distribution: calculateTierDistribution(sportGroups[sport]),
    };
  });

  return insights;
}

function calculateAverage(data, field) {
  const values = data
    .map((row) => parseFloat(row[field]) || 0)
    .filter((v) => v > 0);
  return values.length > 0
    ? values.reduce((a, b) => a + b, 0) / values.length
    : 0;
}

function calculateTierDistribution(data) {
  const tiers = data.reduce((acc, row) => {
    const tier = row.tier_level || 1;
    acc[tier] = (acc[tier] || 0) + 1;
    return acc;
  }, {});
  return tiers;
}

// Stub functions for compilation
async function generateCoalitionInsights() {
  return Response.json({ insights: "Coalition insights generated" });
}

function calculateSportCorrelations(data) {
  return { correlations: "Sport correlation analysis" };
}

function assessSkillTransferPotential(data) {
  return { transfer_potential: "Skill transfer assessment" };
}

function assessCoalitionImpact(sports, metrics) {
  return { impact: "Coalition impact assessed" };
}

function generateSportSpecificRecommendations(sport, metrics) {
  return [`Improve ${sport} specific skills`, "Focus on technique development"];
}

function identifyWrestlingImprovementAreas(data) {
  return ["takedown_technique", "defensive_positioning", "conditioning"];
}

function analyzeRugbySpecifics(data) {
  return { scrum_efficiency: 85, lineout_success: 78 };
}

function analyzeSoccerSpecifics(data) {
  return { passing_accuracy: 82, goal_conversion: 23 };
}

function analyzeBasketballSpecifics(data) {
  return { field_goal_percentage: 45, defensive_rating: 95 };
}

function identifyTacticalImprovementAreas(data) {
  return ["tactical_awareness", "decision_making", "team_coordination"];
}

function analyzeTennisSpecifics(data) {
  return { serve_accuracy: 68, return_efficiency: 72 };
}

function analyzePickleballSpecifics(data) {
  return { dink_precision: 75, volley_control: 80 };
}

function identifyRacketSportsImprovementAreas(data) {
  return ["power_generation", "shot_placement", "court_positioning"];
}

function analyzePositionSpecificMetrics(data) {
  return { position_analysis: "Position-specific metrics analyzed" };
}

function identifyFootballImprovementAreas(data) {
  return ["consistency", "game_preparation", "skill_execution"];
}

function calculatePerformanceDistribution(data) {
  return { distribution: "Performance distribution calculated" };
}

function analyzeTierDistribution(data) {
  return calculateTierDistribution(data);
}

function calculateMilestoneSuccessRate(data) {
  return { success_rate: 0.78 };
}

function calculateImprovementPotential(data) {
  return 0.85;
}

function getSportSpecificNotes(sport) {
  return `${sport} specific performance notes`;
}

async function getFullCoalitionData() {
  const overview = await getCoalitionOverview();
  return {
    overview: overview,
    recent_activity: [],
    performance_trends: [],
  };
}
