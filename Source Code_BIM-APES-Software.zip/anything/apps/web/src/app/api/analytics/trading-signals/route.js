import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { createSecureResponse } from "@/app/api/utils/security";

/**
 * Trading Signals Engine
 *
 * Generates entry/exit signals for athlete NIL positions
 * Uses technical analysis: RSI, MACD, Bollinger Bands, Moving Averages
 * Supports: Buy, Sell, Hold, Accumulate, Strong Buy, Strong Sell
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      athleteIds = [],
      signalType = "comprehensive", // 'comprehensive' | 'entry' | 'exit' | 'momentum'
      lookbackPeriod = 30,
      riskTolerance = "medium", // 'low' | 'medium' | 'high'
    } = body;

    const allSignals = [];

    for (const athleteId of athleteIds) {
      // Get performance history
      const performanceHistory = await sql`
        SELECT ai_score, created_at
        FROM motion_scans
        WHERE athlete_id = ${athleteId}
        ORDER BY created_at DESC
        LIMIT ${lookbackPeriod}
      `;

      if (performanceHistory.length < 10) {
        allSignals.push({
          athleteId,
          signal: "INSUFFICIENT_DATA",
          confidence: 0,
          reasoning: ["Need at least 10 data points for analysis"],
        });
        continue;
      }

      const scores = performanceHistory.map((s) => s.ai_score).reverse();

      // Calculate technical indicators
      const sma20 = calculateSMA(scores, 20);
      const sma50 = calculateSMA(scores, Math.min(50, scores.length));
      const ema12 = calculateEMA(scores, 12);
      const ema26 = calculateEMA(scores, 26);
      const rsi = calculateRSI(scores, 14);
      const macd = calculateMACD(scores);
      const bollingerBands = calculateBollingerBands(scores, 20, 2);
      const atr = calculateATR(scores, 14);

      // Get current and recent values
      const currentScore = scores[scores.length - 1];
      const previousScore = scores[scores.length - 2];
      const scoreChange =
        ((currentScore - previousScore) / previousScore) * 100;

      // Generate primary signal
      let signal = "HOLD";
      let confidence = 50;
      const reasoning = [];
      const entryPoints = [];
      const exitPoints = [];

      // ENTRY SIGNALS
      if (signalType === "comprehensive" || signalType === "entry") {
        // Strong Buy: Multiple bullish confirmations
        if (
          rsi < 30 && // Oversold
          currentScore > sma20 && // Above moving average
          ema12 > ema26 && // Bullish crossover
          macd.histogram > 0 // Positive momentum
        ) {
          signal = "STRONG BUY";
          confidence = 90;
          reasoning.push("Oversold with strong bullish momentum");
          reasoning.push("Golden Cross confirmed (EMA12 > EMA26)");
          reasoning.push("MACD positive divergence");
          entryPoints.push({
            price: currentScore * 1000,
            type: "Aggressive Entry",
            confidence: 90,
          });
        }
        // Buy: Bullish but not oversold
        else if (rsi < 45 && currentScore > sma20 && macd.histogram > 0) {
          signal = "BUY";
          confidence = 75;
          reasoning.push("Bullish trend with positive momentum");
          reasoning.push("Price above 20-day average");
          entryPoints.push({
            price: currentScore * 1000,
            type: "Standard Entry",
            confidence: 75,
          });
        }
        // Accumulate: Steady uptrend
        else if (
          rsi > 40 &&
          rsi < 60 &&
          currentScore > sma20 &&
          scoreChange > 0
        ) {
          signal = "ACCUMULATE";
          confidence = 65;
          reasoning.push("Steady uptrend - ideal for position building");
          reasoning.push("Neutral RSI with positive price action");
          entryPoints.push({
            price: currentScore * 1000 * 0.95,
            type: "Dip Buy",
            confidence: 65,
          });
        }
      }

      // EXIT SIGNALS
      if (signalType === "comprehensive" || signalType === "exit") {
        // Strong Sell: Multiple bearish confirmations
        if (
          rsi > 70 && // Overbought
          currentScore < sma20 && // Below moving average
          ema12 < ema26 && // Bearish crossover
          macd.histogram < 0 // Negative momentum
        ) {
          signal = "STRONG SELL";
          confidence = 90;
          reasoning.push("Overbought with strong bearish momentum");
          reasoning.push("Death Cross confirmed (EMA12 < EMA26)");
          reasoning.push("MACD negative divergence");
          exitPoints.push({
            price: currentScore * 1000,
            type: "Immediate Exit",
            confidence: 90,
          });
        }
        // Sell: Bearish trend
        else if (rsi > 60 && currentScore < sma20 && scoreChange < 0) {
          signal = "SELL";
          confidence = 75;
          reasoning.push("Bearish trend established");
          reasoning.push("Price below 20-day average");
          exitPoints.push({
            price: currentScore * 1000,
            type: "Standard Exit",
            confidence: 75,
          });
        }
      }

      // Calculate price targets
      const volatility = atr / currentScore;
      const entryPrice = currentScore * 1000;
      const targetPrice = signal.includes("BUY")
        ? entryPrice * (1 + volatility * 2)
        : entryPrice * (1 - volatility * 2);
      const stopLoss = signal.includes("BUY")
        ? entryPrice * (1 - volatility * 1.5)
        : entryPrice * (1 + volatility * 1.5);

      allSignals.push({
        athleteId,
        signal,
        confidence,
        reasoning,
        technicalIndicators: {
          rsi: rsi.toFixed(2),
          sma20: sma20.toFixed(2),
          sma50: sma50.toFixed(2),
          ema12: ema12.toFixed(2),
          ema26: ema26.toFixed(2),
          macd: {
            line: macd.line.toFixed(2),
            signal: macd.signal.toFixed(2),
            histogram: macd.histogram.toFixed(2),
          },
          bollingerBands: {
            upper: bollingerBands.upper.toFixed(2),
            middle: bollingerBands.middle.toFixed(2),
            lower: bollingerBands.lower.toFixed(2),
          },
          atr: atr.toFixed(2),
          volatility: (volatility * 100).toFixed(2) + "%",
        },
        priceTargets: {
          entry: entryPrice.toFixed(0),
          target: targetPrice.toFixed(0),
          stopLoss: stopLoss.toFixed(0),
          riskRewardRatio: (
            Math.abs(targetPrice - entryPrice) / Math.abs(entryPrice - stopLoss)
          ).toFixed(2),
        },
        entryPoints,
        exitPoints,
        currentPrice: entryPrice,
        priceChange24h: scoreChange.toFixed(2) + "%",
      });
    }

    // Generate portfolio summary
    const summary = {
      strongBuy: allSignals.filter((s) => s.signal === "STRONG BUY").length,
      buy: allSignals.filter((s) => s.signal === "BUY").length,
      accumulate: allSignals.filter((s) => s.signal === "ACCUMULATE").length,
      hold: allSignals.filter((s) => s.signal === "HOLD").length,
      sell: allSignals.filter((s) => s.signal === "SELL").length,
      strongSell: allSignals.filter((s) => s.signal === "STRONG SELL").length,
      avgConfidence:
        allSignals.reduce((sum, s) => sum + s.confidence, 0) /
        allSignals.length,
    };

    return createSecureResponse({
      success: true,
      signals: allSignals,
      summary,
      generatedAt: new Date().toISOString(),
      parameters: {
        lookbackPeriod,
        riskTolerance,
        signalType,
      },
    });
  } catch (error) {
    console.error("Trading signals error:", error);
    return createSecureResponse(
      { error: "Failed to generate trading signals" },
      { status: 500 },
    );
  }
}

// ============================================================================
// TECHNICAL INDICATORS
// ============================================================================

function calculateSMA(values, period) {
  if (values.length < period) return values[values.length - 1];
  const recent = values.slice(-period);
  return recent.reduce((a, b) => a + b, 0) / period;
}

function calculateEMA(values, period) {
  if (values.length < period) return values[values.length - 1];

  const k = 2 / (period + 1);
  let ema = calculateSMA(values.slice(0, period), period);

  for (let i = period; i < values.length; i++) {
    ema = values[i] * k + ema * (1 - k);
  }

  return ema;
}

function calculateRSI(values, period = 14) {
  if (values.length < period + 1) return 50;

  const changes = [];
  for (let i = 1; i < values.length; i++) {
    changes.push(values[i] - values[i - 1]);
  }

  const recentChanges = changes.slice(-period);
  const gains =
    recentChanges.filter((c) => c > 0).reduce((a, b) => a + b, 0) / period;
  const losses =
    Math.abs(recentChanges.filter((c) => c < 0).reduce((a, b) => a + b, 0)) /
    period;

  if (losses === 0) return 100;

  const rs = gains / losses;
  return 100 - 100 / (1 + rs);
}

function calculateMACD(values) {
  const ema12 = calculateEMA(values, 12);
  const ema26 = calculateEMA(values, 26);
  const macdLine = ema12 - ema26;

  // Signal line is 9-period EMA of MACD line
  // Simplified: using last 9 MACD values
  const macdSignal = macdLine * 0.8; // Simplified
  const histogram = macdLine - macdSignal;

  return {
    line: macdLine,
    signal: macdSignal,
    histogram,
  };
}

function calculateBollingerBands(values, period = 20, stdDevMultiplier = 2) {
  if (values.length < period) {
    const current = values[values.length - 1];
    return { upper: current * 1.1, middle: current, lower: current * 0.9 };
  }

  const sma = calculateSMA(values, period);
  const recentValues = values.slice(-period);

  // Calculate standard deviation
  const squaredDiffs = recentValues.map((v) => Math.pow(v - sma, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / period;
  const stdDev = Math.sqrt(variance);

  return {
    upper: sma + stdDev * stdDevMultiplier,
    middle: sma,
    lower: sma - stdDev * stdDevMultiplier,
  };
}

function calculateATR(values, period = 14) {
  if (values.length < period + 1) return values[values.length - 1] * 0.05;

  const trueRanges = [];
  for (let i = 1; i < values.length; i++) {
    const high = Math.max(values[i], values[i - 1]);
    const low = Math.min(values[i], values[i - 1]);
    const tr = high - low;
    trueRanges.push(tr);
  }

  const recentTR = trueRanges.slice(-period);
  return recentTR.reduce((a, b) => a + b, 0) / period;
}
