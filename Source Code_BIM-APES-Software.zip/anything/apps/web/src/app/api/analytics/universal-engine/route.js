import sql from "@/app/api/utils/sql";
import { SPORT_PROFILES } from "@/app/api/context/sport-profiles/route";
import { ORG_PROFILES } from "@/app/api/context/org-profiles/route";

// Universal Analytics Engine - Computes PPI/TPI/LPI for any sport, any org
class UniversalAnalyticsEngine {
  constructor(sportProfile, orgProfile) {
    this.sportProfile = sportProfile;
    this.orgProfile = orgProfile;
  }

  // Calculate Player Performance Index (PPI)
  calculatePPI(rawMetrics) {
    const { featureMap, derivedMetrics, scoringSchema } = this.sportProfile;
    const scores = {};

    // Step 1: Compute derived metrics from raw features
    for (const [metricName, config] of Object.entries(derivedMetrics)) {
      const features = featureMap[metricName] || [];
      const rawValues = features.map((f) => rawMetrics[f] || 0);

      // Simplified metric computation (in production, this would use the formula)
      scores[metricName] =
        this._computeMetric(rawValues, config.formula) * config.weight;
    }

    // Step 2: Apply sport-specific weighting
    const ppi = Object.keys(scoringSchema.ppi_weights).reduce(
      (total, metric) => {
        const weight = scoringSchema.ppi_weights[metric];
        const score = scores[metric] || 0;
        return total + score * weight;
      },
      0,
    );

    // Step 3: Apply org-specific tier boundaries
    const tier = this._classifyTier(ppi);

    return {
      ppi: Math.round(ppi * 100) / 100,
      tier,
      breakdown: scores,
      timestamp: new Date().toISOString(),
    };
  }

  // Calculate Team Performance Index (TPI)
  calculateTPI(athletePPIs, teamMetadata = {}) {
    const { scoringSchema } = this.sportProfile;
    const aggregationType = scoringSchema.tpi_aggregation;

    let tpi = 0;

    switch (aggregationType) {
      case "weighted_average":
        tpi =
          athletePPIs.reduce((sum, p) => sum + p.ppi, 0) / athletePPIs.length;
        break;

      case "synergy_adjusted":
        // Basketball-style: factor in team chemistry
        const avgPPI =
          athletePPIs.reduce((sum, p) => sum + p.ppi, 0) / athletePPIs.length;
        const chemistryBonus = teamMetadata.chemistry || 1.0;
        const balanceBonus = this._calculateRosterBalance(athletePPIs);
        tpi = avgPPI * chemistryBonus * balanceBonus;
        break;

      case "doubles_synergy":
        // Tennis/Pickleball doubles: synergy between two players
        if (athletePPIs.length === 2) {
          const [p1, p2] = athletePPIs;
          const synergyFactor = teamMetadata.synergy || 1.0;
          tpi = ((p1.ppi + p2.ppi) / 2) * synergyFactor;
        }
        break;

      case "position_group_weighted":
        // Football: weight by position importance
        const positionWeights = teamMetadata.positionWeights || {};
        tpi =
          athletePPIs.reduce((sum, p) => {
            const weight = positionWeights[p.position] || 1.0;
            return sum + p.ppi * weight;
          }, 0) / athletePPIs.length;
        break;

      case "forward_back_balanced":
        // Rugby: balance forwards and backs
        const forwards = athletePPIs.filter(
          (p) => p.positionGroup === "forward",
        );
        const backs = athletePPIs.filter((p) => p.positionGroup === "back");
        const forwardAvg =
          forwards.reduce((sum, p) => sum + p.ppi, 0) / (forwards.length || 1);
        const backAvg =
          backs.reduce((sum, p) => sum + p.ppi, 0) / (backs.length || 1);
        tpi = (forwardAvg + backAvg) / 2;
        break;

      case "tactical_cohesion_weighted":
        // Soccer: tactical cohesion matters
        const avgTeamPPI =
          athletePPIs.reduce((sum, p) => sum + p.ppi, 0) / athletePPIs.length;
        const cohesionFactor = teamMetadata.tacticalCohesion || 1.0;
        tpi = avgTeamPPI * cohesionFactor;
        break;

      case "relay_team_synergy":
        // Track & Field relays: handoff quality matters
        const individualAvg =
          athletePPIs.reduce((sum, p) => sum + p.ppi, 0) / athletePPIs.length;
        const handoffQuality = teamMetadata.handoffQuality || 1.0;
        tpi = individualAvg * handoffQuality;
        break;

      case "role_balanced_weighted":
        // Esports: balance roles (carry, support, etc.)
        const roleWeights = teamMetadata.roleWeights || {};
        tpi =
          athletePPIs.reduce((sum, p) => {
            const weight = roleWeights[p.role] || 1.0;
            return sum + p.ppi * weight;
          }, 0) / athletePPIs.length;
        break;

      case "constructor_team_weighted":
        // Motorsport: team strategy and car quality matter
        const driverAvg =
          athletePPIs.reduce((sum, p) => sum + p.ppi, 0) / athletePPIs.length;
        const carQuality = teamMetadata.carQuality || 1.0;
        const strategyFactor = teamMetadata.strategyFactor || 1.0;
        tpi = driverAvg * carQuality * strategyFactor;
        break;

      default:
        tpi =
          athletePPIs.reduce((sum, p) => sum + p.ppi, 0) / athletePPIs.length;
    }

    return {
      tpi: Math.round(tpi * 100) / 100,
      aggregationType,
      athleteCount: athletePPIs.length,
      timestamp: new Date().toISOString(),
    };
  }

  // Calculate League/Federation Performance Index (LPI)
  calculateLPI(teamTPIs, leagueMetadata = {}) {
    const { scoringSchema } = this.sportProfile;
    const aggregationType = scoringSchema.lpi_aggregation;

    let lpi = 0;

    switch (aggregationType) {
      case "percentile_ranking":
        // Wrestling, combat sports: rank by percentile
        const sorted = [...teamTPIs].sort((a, b) => b.tpi - a.tpi);
        const median = sorted[Math.floor(sorted.length / 2)]?.tpi || 0;
        lpi = median;
        break;

      case "competitive_balance":
        // Basketball: competitive balance across league
        const avgTPI =
          teamTPIs.reduce((sum, t) => sum + t.tpi, 0) / teamTPIs.length;
        const variance = this._calculateVariance(teamTPIs.map((t) => t.tpi));
        const balanceFactor = 1 / (1 + variance / 100); // Lower variance = better balance
        lpi = avgTPI * balanceFactor;
        break;

      case "elo_adjusted":
        // Tennis, esports: ELO-based ranking
        const eloScores = teamTPIs.map((t) => t.elo || t.tpi);
        lpi = eloScores.reduce((sum, e) => sum + e, 0) / eloScores.length;
        break;

      case "tournament_adjusted":
        // Pickleball, competitive circuits
        const tournamentWeights = leagueMetadata.tournamentWeights || {};
        lpi =
          teamTPIs.reduce((sum, t) => {
            const weight = tournamentWeights[t.tournamentId] || 1.0;
            return sum + t.tpi * weight;
          }, 0) / teamTPIs.length;
        break;

      case "conference_adjusted":
        // American Football: adjust for conference strength
        const conferenceFactors = leagueMetadata.conferenceStrength || {};
        lpi =
          teamTPIs.reduce((sum, t) => {
            const factor = conferenceFactors[t.conference] || 1.0;
            return sum + t.tpi * factor;
          }, 0) / teamTPIs.length;
        break;

      case "union_adjusted":
        // Rugby: adjust for union/competition level
        const unionFactors = leagueMetadata.unionStrength || {};
        lpi =
          teamTPIs.reduce((sum, t) => {
            const factor = unionFactors[t.union] || 1.0;
            return sum + t.tpi * factor;
          }, 0) / teamTPIs.length;
        break;

      case "league_coefficient_adjusted":
        // Soccer: UEFA coefficient-style
        const coefficients = leagueMetadata.leagueCoefficients || {};
        lpi =
          teamTPIs.reduce((sum, t) => {
            const coef = coefficients[t.leagueId] || 1.0;
            return sum + t.tpi * coef;
          }, 0) / teamTPIs.length;
        break;

      case "world_ranking_adjusted":
        // Track & Field: world ranking points
        const worldRankings = teamTPIs.map((t) => t.worldRanking || 100);
        lpi =
          worldRankings.reduce((sum, r) => sum + (100 - r), 0) /
          worldRankings.length;
        break;

      case "championship_points_adjusted":
        // Motorsport: championship points system
        const championshipPoints = teamTPIs.map((t) => t.points || 0);
        const totalPoints = championshipPoints.reduce((sum, p) => sum + p, 0);
        lpi = totalPoints / teamTPIs.length;
        break;

      default:
        lpi = teamTPIs.reduce((sum, t) => sum + t.tpi, 0) / teamTPIs.length;
    }

    return {
      lpi: Math.round(lpi * 100) / 100,
      aggregationType,
      teamCount: teamTPIs.length,
      timestamp: new Date().toISOString(),
    };
  }

  // Velocity of improvement
  calculateVelocity(historicalPPIs) {
    if (historicalPPIs.length < 2) return 0;

    const recent = historicalPPIs.slice(-5); // Last 5 data points
    const trend = this._linearRegression(
      recent.map((p, i) => ({ x: i, y: p.ppi })),
    );
    return Math.round(trend.slope * 100) / 100;
  }

  // Consistency metric
  calculateConsistency(historicalPPIs) {
    if (historicalPPIs.length < 2) return 100;

    const values = historicalPPIs.map((p) => p.ppi);
    const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
    const variance = this._calculateVariance(values);
    const cv = variance / mean; // Coefficient of variation

    // Lower CV = higher consistency
    return Math.max(0, Math.min(100, 100 - cv * 100));
  }

  // Learning curve / adaptation rate
  calculateLearningRate(historicalPPIs) {
    if (historicalPPIs.length < 3) return 0;

    const improvements = [];
    for (let i = 1; i < historicalPPIs.length; i++) {
      const delta = historicalPPIs[i].ppi - historicalPPIs[i - 1].ppi;
      improvements.push(delta);
    }

    const avgImprovement =
      improvements.reduce((sum, i) => sum + i, 0) / improvements.length;
    return Math.round(avgImprovement * 100) / 100;
  }

  // 30/60/90-day forecasting
  forecastPPI(historicalPPIs, daysAhead = 30) {
    if (historicalPPIs.length < 3) return null;

    const recent = historicalPPIs.slice(-10);
    const trend = this._linearRegression(
      recent.map((p, i) => ({ x: i, y: p.ppi })),
    );

    const forecastValue =
      trend.intercept + trend.slope * (recent.length + daysAhead);
    const variance = this._calculateVariance(recent.map((p) => p.ppi));
    const confidenceBand = variance * 0.5;

    return {
      forecast: Math.max(
        0,
        Math.min(100, Math.round(forecastValue * 100) / 100),
      ),
      confidenceLow: Math.max(
        0,
        Math.round((forecastValue - confidenceBand) * 100) / 100,
      ),
      confidenceHigh: Math.min(
        100,
        Math.round((forecastValue + confidenceBand) * 100) / 100,
      ),
      daysAhead,
    };
  }

  // Injury risk / stress band
  calculateInjuryRisk(rawMetrics, historicalPPIs) {
    const loadMetric = rawMetrics.load || rawMetrics.loadFatigue || 0;
    const recoveryMetric =
      rawMetrics.recovery || rawMetrics.recoveryVelocity || 100;
    const consistency = this.calculateConsistency(historicalPPIs);

    // High load + low recovery + low consistency = high risk
    const loadRisk = Math.min(100, loadMetric);
    const recoveryRisk = Math.max(0, 100 - recoveryMetric);
    const consistencyRisk = Math.max(0, 100 - consistency);

    const overallRisk =
      loadRisk * 0.4 + recoveryRisk * 0.4 + consistencyRisk * 0.2;

    return {
      riskScore: Math.round(overallRisk),
      riskLevel:
        overallRisk > 70 ? "high" : overallRisk > 40 ? "medium" : "low",
      factors: {
        load: loadRisk,
        recovery: recoveryRisk,
        consistency: consistencyRisk,
      },
    };
  }

  // Breakout probability
  calculateBreakoutProbability(historicalPPIs) {
    if (historicalPPIs.length < 5) return 0;

    const velocity = this.calculateVelocity(historicalPPIs);
    const consistency = this.calculateConsistency(historicalPPIs);
    const learningRate = this.calculateLearningRate(historicalPPIs);

    // High velocity + high consistency + positive learning rate = high breakout probability
    const velocityFactor = Math.max(0, velocity * 10); // Scale to 0-100
    const consistencyFactor = consistency;
    const learningFactor = Math.max(0, learningRate * 10);

    const breakoutProb =
      velocityFactor * 0.4 + consistencyFactor * 0.3 + learningFactor * 0.3;

    return Math.min(100, Math.round(breakoutProb));
  }

  // Helper: Classify tier based on PPI
  _classifyTier(ppi) {
    const { tierBoundaries } = this.sportProfile;
    for (const [tierName, bounds] of Object.entries(tierBoundaries)) {
      if (ppi >= bounds.ppi_min && ppi <= bounds.ppi_max) {
        return tierName;
      }
    }
    return "amateur";
  }

  // Helper: Compute a derived metric from raw values
  _computeMetric(rawValues, formula) {
    if (rawValues.length === 0) return 0;

    // Simplified computation: average of normalized values
    const avg = rawValues.reduce((sum, v) => sum + v, 0) / rawValues.length;
    return Math.max(0, Math.min(100, avg));
  }

  // Helper: Calculate roster balance
  _calculateRosterBalance(athletePPIs) {
    const values = athletePPIs.map((p) => p.ppi);
    const variance = this._calculateVariance(values);
    return 1 + 1 / (1 + variance); // Lower variance = better balance
  }

  // Helper: Calculate variance
  _calculateVariance(values) {
    const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
    const squaredDiffs = values.map((v) => Math.pow(v - mean, 2));
    return squaredDiffs.reduce((sum, d) => sum + d, 0) / values.length;
  }

  // Helper: Linear regression
  _linearRegression(points) {
    const n = points.length;
    const sumX = points.reduce((sum, p) => sum + p.x, 0);
    const sumY = points.reduce((sum, p) => sum + p.y, 0);
    const sumXY = points.reduce((sum, p) => sum + p.x * p.y, 0);
    const sumXX = points.reduce((sum, p) => sum + p.x * p.x, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    return { slope, intercept };
  }
}

// POST: Run universal analytics
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      sport_id,
      org_id,
      athlete_id,
      raw_metrics,
      analysis_type,
      team_metadata,
      league_metadata,
    } = body;

    if (!sport_id || !org_id) {
      return Response.json(
        { error: "Missing sport_id or org_id" },
        { status: 400 },
      );
    }

    const sportProfile = SPORT_PROFILES[sport_id];
    const orgProfile = ORG_PROFILES[org_id];

    if (!sportProfile) {
      return Response.json({ error: "Invalid sport profile" }, { status: 404 });
    }

    if (!orgProfile) {
      return Response.json(
        { error: "Invalid organization profile" },
        { status: 404 },
      );
    }

    const engine = new UniversalAnalyticsEngine(sportProfile, orgProfile);

    let result = {};

    switch (analysis_type) {
      case "ppi":
        if (!raw_metrics) {
          return Response.json(
            { error: "Missing raw_metrics for PPI calculation" },
            { status: 400 },
          );
        }
        result = engine.calculatePPI(raw_metrics);
        break;

      case "tpi":
        if (!body.athlete_ppis) {
          return Response.json(
            { error: "Missing athlete_ppis for TPI calculation" },
            { status: 400 },
          );
        }
        result = engine.calculateTPI(body.athlete_ppis, team_metadata);
        break;

      case "lpi":
        if (!body.team_tpis) {
          return Response.json(
            { error: "Missing team_tpis for LPI calculation" },
            { status: 400 },
          );
        }
        result = engine.calculateLPI(body.team_tpis, league_metadata);
        break;

      case "velocity":
        if (!body.historical_ppis) {
          return Response.json(
            { error: "Missing historical_ppis for velocity calculation" },
            { status: 400 },
          );
        }
        result = { velocity: engine.calculateVelocity(body.historical_ppis) };
        break;

      case "consistency":
        if (!body.historical_ppis) {
          return Response.json(
            { error: "Missing historical_ppis for consistency calculation" },
            { status: 400 },
          );
        }
        result = {
          consistency: engine.calculateConsistency(body.historical_ppis),
        };
        break;

      case "learning_rate":
        if (!body.historical_ppis) {
          return Response.json(
            { error: "Missing historical_ppis for learning rate calculation" },
            { status: 400 },
          );
        }
        result = {
          learningRate: engine.calculateLearningRate(body.historical_ppis),
        };
        break;

      case "forecast":
        if (!body.historical_ppis) {
          return Response.json(
            { error: "Missing historical_ppis for forecast" },
            { status: 400 },
          );
        }
        const daysAhead = body.days_ahead || 30;
        result = engine.forecastPPI(body.historical_ppis, daysAhead);
        break;

      case "injury_risk":
        if (!raw_metrics || !body.historical_ppis) {
          return Response.json(
            { error: "Missing raw_metrics or historical_ppis for injury risk" },
            { status: 400 },
          );
        }
        result = engine.calculateInjuryRisk(raw_metrics, body.historical_ppis);
        break;

      case "breakout_probability":
        if (!body.historical_ppis) {
          return Response.json(
            { error: "Missing historical_ppis for breakout probability" },
            { status: 400 },
          );
        }
        result = {
          breakoutProbability: engine.calculateBreakoutProbability(
            body.historical_ppis,
          ),
        };
        break;

      case "full_analysis":
        if (!raw_metrics || !body.historical_ppis) {
          return Response.json(
            {
              error: "Missing raw_metrics or historical_ppis for full analysis",
            },
            { status: 400 },
          );
        }

        const ppi = engine.calculatePPI(raw_metrics);
        const velocity = engine.calculateVelocity(body.historical_ppis);
        const consistency = engine.calculateConsistency(body.historical_ppis);
        const learningRate = engine.calculateLearningRate(body.historical_ppis);
        const forecast30 = engine.forecastPPI(body.historical_ppis, 30);
        const forecast60 = engine.forecastPPI(body.historical_ppis, 60);
        const forecast90 = engine.forecastPPI(body.historical_ppis, 90);
        const injuryRisk = engine.calculateInjuryRisk(
          raw_metrics,
          body.historical_ppis,
        );
        const breakoutProb = engine.calculateBreakoutProbability(
          body.historical_ppis,
        );

        result = {
          ppi,
          velocity,
          consistency,
          learningRate,
          forecasts: { forecast30, forecast60, forecast90 },
          injuryRisk,
          breakoutProbability: breakoutProb,
        };
        break;

      default:
        return Response.json(
          { error: "Unknown analysis_type" },
          { status: 400 },
        );
    }

    return Response.json({
      sport_id,
      sport_name: sportProfile.name,
      org_id,
      org_name: orgProfile.name,
      analysis_type,
      result,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Universal analytics error:", error);
    return Response.json(
      { error: "Analytics computation failed", details: error.message },
      { status: 500 },
    );
  }
}

// GET: Fetch analytics for an athlete
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const athleteId = searchParams.get("athlete_id");
  const sportId = searchParams.get("sport_id");
  const orgId = searchParams.get("org_id");

  if (!athleteId || !sportId || !orgId) {
    return Response.json(
      { error: "Missing required parameters" },
      { status: 400 },
    );
  }

  try {
    // Fetch historical motion scans for this athlete
    const scans = await sql`
      SELECT * FROM motion_scans
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 30
    `;

    if (scans.length === 0) {
      return Response.json(
        { error: "No motion scans found for athlete" },
        { status: 404 },
      );
    }

    const sportProfile = SPORT_PROFILES[sportId];
    const orgProfile = ORG_PROFILES[orgId];

    if (!sportProfile || !orgProfile) {
      return Response.json(
        { error: "Invalid sport or org profile" },
        { status: 404 },
      );
    }

    const engine = new UniversalAnalyticsEngine(sportProfile, orgProfile);

    // Extract historical PPIs from scans
    const historicalPPIs = scans.map((scan) => ({
      ppi: scan.ai_score || 0,
      timestamp: scan.created_at,
    }));

    // Get latest scan metrics
    const latestScan = scans[0];
    const rawMetrics = latestScan.scan_data || {};

    // Run full analysis
    const ppi = engine.calculatePPI(rawMetrics);
    const velocity = engine.calculateVelocity(historicalPPIs);
    const consistency = engine.calculateConsistency(historicalPPIs);
    const learningRate = engine.calculateLearningRate(historicalPPIs);
    const forecast30 = engine.forecastPPI(historicalPPIs, 30);
    const forecast60 = engine.forecastPPI(historicalPPIs, 60);
    const forecast90 = engine.forecastPPI(historicalPPIs, 90);
    const injuryRisk = engine.calculateInjuryRisk(rawMetrics, historicalPPIs);
    const breakoutProb = engine.calculateBreakoutProbability(historicalPPIs);

    return Response.json({
      athlete_id: athleteId,
      sport_id: sportId,
      sport_name: sportProfile.name,
      org_id: orgId,
      org_name: orgProfile.name,
      analytics: {
        ppi,
        velocity,
        consistency,
        learningRate,
        forecasts: { forecast30, forecast60, forecast90 },
        injuryRisk,
        breakoutProbability: breakoutProb,
      },
      dataPoints: scans.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error fetching athlete analytics:", error);
    return Response.json(
      { error: "Failed to fetch athlete analytics" },
      { status: 500 },
    );
  }
}
