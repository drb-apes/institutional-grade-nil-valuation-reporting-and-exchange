import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// **🏛️ INSTITUTIONAL DASHBOARD API**
// Real-time heatmap overlays, training load adjustments, injury risk scoring

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const athleteId = url.searchParams.get("athlete_id");
    const dashboardType = url.searchParams.get("type") || "overview";
    const timeRange = url.searchParams.get("range") || "7"; // days

    // Verify user has institutional access
    const userProfile = await sql`
      SELECT * FROM user_profiles 
      WHERE user_id = ${session.user.id}
      AND user_type IN ('institutional', 'dao_member')
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "Institutional access required" },
        { status: 403 },
      );
    }

    let dashboardData = {};

    switch (dashboardType) {
      case "heatmap_overlays":
        dashboardData = await generateHeatmapOverlays(athleteId, timeRange);
        break;

      case "training_load":
        dashboardData = await generateTrainingLoadRecommendations(
          athleteId,
          timeRange,
        );
        break;

      case "injury_risk":
        dashboardData = await generateInjuryRiskScoring(athleteId, timeRange);
        break;

      case "highlight_reels":
        dashboardData = await generateHighlightReelData(athleteId, timeRange);
        break;

      default:
        dashboardData = await generateInstitutionalOverview(
          athleteId,
          timeRange,
        );
    }

    return Response.json({
      success: true,
      dashboard_type: dashboardType,
      time_range_days: parseInt(timeRange),
      athlete_id: athleteId,
      institutional_data: dashboardData,
      access_level: "institutional_grade",
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Institutional dashboard error:", error);
    return Response.json(
      { error: "Failed to generate institutional dashboard" },
      { status: 500 },
    );
  }
}

// **REAL-TIME HEATMAP OVERLAYS**
async function generateHeatmapOverlays(athleteId, timeRange) {
  try {
    // Get recent asset simulations with enhanced heatmap data
    const heatmapData = await sql`
      SELECT 
        s.id,
        s.simulation_data,
        s.valuation_factors,
        s.created_at,
        u.tier_level,
        u.reputation_score
      FROM asset_simulations s
      JOIN user_profiles u ON s.athlete_id = u.id
      WHERE (${athleteId} IS NULL OR s.athlete_id = ${athleteId})
      AND s.created_at >= NOW() - INTERVAL '${timeRange} days'
      AND s.valuation_factors->>'heatmap_type' = 'enhanced_10x10_grid'
      ORDER BY s.created_at DESC
      LIMIT 50
    `;

    const overlayData = heatmapData.map((sim) => {
      const factors = sim.valuation_factors;
      const perfData = sim.simulation_data;

      return {
        simulation_id: sim.id,
        timestamp: sim.created_at,
        tier_level: sim.tier_level,
        overlay_type: "stress_zone_mapping",
        grid_precision: "10x10_institutional",
        stress_zones: factors.coaching_insights?.stress_zones || [],
        injury_risk_score: perfData.injury_risk_score || 0,
        real_time_alerts: generateRealTimeAlerts(factors, perfData),
        highlight_potential: calculateHighlightPotential(
          perfData,
          sim.tier_level,
        ),
        overlay_svg: generateOverlaySVG(factors.coaching_insights),
      };
    });

    return {
      total_overlays: overlayData.length,
      recent_scans: overlayData.slice(0, 10),
      aggregate_stress_trends: calculateStressTrends(overlayData),
      real_time_monitoring: {
        active_alerts: overlayData.filter((d) => d.real_time_alerts.length > 0)
          .length,
        high_risk_zones: countHighRiskZones(overlayData),
        tier_distribution: calculateTierDistribution(overlayData),
      },
    };
  } catch (error) {
    console.error("Heatmap overlay generation error:", error);
    return { error: "Overlay generation failed" };
  }
}

// **TRAINING LOAD ADJUSTMENT RECOMMENDATIONS**
async function generateTrainingLoadRecommendations(athleteId, timeRange) {
  try {
    // Analyze recent motion scans and stress patterns
    const scanData = await sql`
      SELECT 
        ms.scan_data,
        ms.ai_score,
        ms.motion_type,
        ms.created_at,
        up.tier_level,
        asim.simulation_data
      FROM motion_scans ms
      JOIN user_profiles up ON ms.athlete_id = up.id
      LEFT JOIN asset_simulations asim ON asim.motion_scan_id = ms.id
      WHERE (${athleteId} IS NULL OR ms.athlete_id = ${athleteId})
      AND ms.created_at >= NOW() - INTERVAL '${timeRange} days'
      ORDER BY ms.created_at DESC
      LIMIT 100
    `;

    const loadRecommendations = scanData.map((scan) => {
      const stressData = scan.scan_data.stress_zones || [];
      const recoveryIndex = scan.simulation_data?.recovery_index || 50;
      const overallScore = scan.simulation_data?.overall_score || 0;

      return {
        scan_id: scan.id,
        motion_type: scan.motion_type,
        timestamp: scan.created_at,
        current_load_assessment: assessCurrentLoad(stressData, recoveryIndex),
        recommended_adjustments: generateLoadAdjustments(
          stressData,
          recoveryIndex,
          scan.tier_level,
        ),
        recovery_priority: calculateRecoveryPriority(stressData),
        training_modifications: generateTrainingMods(
          scan.motion_type,
          stressData,
        ),
        next_session_timing: recommendNextSession(recoveryIndex, stressData),
      };
    });

    return {
      total_assessments: loadRecommendations.length,
      current_recommendations: loadRecommendations.slice(0, 5),
      load_trend_analysis: analyzeLoadTrends(loadRecommendations),
      institutional_protocols: {
        high_stress_protocol: getHighStressProtocol(),
        recovery_optimization: getRecoveryOptimization(),
        tier_specific_guidelines: getTierGuidelines(),
      },
    };
  } catch (error) {
    console.error("Training load recommendation error:", error);
    return { error: "Load recommendation generation failed" };
  }
}

// **INJURY RISK SCORING**
async function generateInjuryRiskScoring(athleteId, timeRange) {
  try {
    // Get enhanced heatmap data with injury risk calculations
    const riskData = await sql`
      SELECT 
        s.simulation_data,
        s.valuation_factors,
        s.created_at,
        u.tier_level,
        u.total_contributions,
        ms.motion_type
      FROM asset_simulations s
      JOIN user_profiles u ON s.athlete_id = u.id
      LEFT JOIN motion_scans ms ON s.motion_scan_id = ms.id
      WHERE (${athleteId} IS NULL OR s.athlete_id = ${athleteId})
      AND s.created_at >= NOW() - INTERVAL '${timeRange} days'
      AND s.valuation_factors ? 'enhanced_features'
      ORDER BY s.created_at DESC
      LIMIT 200
    `;

    const riskAssessments = riskData.map((data) => {
      const perfIndex = data.simulation_data;
      const factors = data.valuation_factors;

      return {
        assessment_id: `risk_${data.created_at.getTime()}`,
        timestamp: data.created_at,
        motion_type: data.motion_type,
        overall_injury_risk: calculateOverallInjuryRisk(perfIndex, factors),
        zone_specific_risks: calculateZoneRisks(factors.coaching_insights),
        predictive_model: runPredictiveModel(perfIndex, data.tier_level),
        institutional_alerts: generateInstitutionalAlerts(perfIndex, factors),
        prevention_protocols: getPreventionProtocols(perfIndex, factors),
      };
    });

    return {
      total_risk_assessments: riskAssessments.length,
      current_risk_profile: riskAssessments.slice(0, 10),
      predictive_analytics: {
        day_7_forecast: generate7DayForecast(riskAssessments),
        day_30_projection: generate30DayProjection(riskAssessments),
        seasonal_patterns: analyzeSeasonalPatterns(riskAssessments),
      },
      institutional_insights: {
        high_risk_athletes: identifyHighRiskAthletes(riskAssessments),
        intervention_recommendations:
          getInterventionRecommendations(riskAssessments),
        protocol_effectiveness: assessProtocolEffectiveness(riskAssessments),
      },
    };
  } catch (error) {
    console.error("Injury risk scoring error:", error);
    return { error: "Risk scoring generation failed" };
  }
}

// **HIGHLIGHT REEL DATA GENERATION**
async function generateHighlightReelData(athleteId, timeRange) {
  try {
    // Get performance data suitable for highlight reels
    const highlightData = await sql`
      SELECT 
        s.simulation_data,
        s.valuation_factors,
        s.created_at,
        u.tier_level,
        ms.motion_type,
        ms.ai_score
      FROM asset_simulations s
      JOIN user_profiles u ON s.athlete_id = u.id
      LEFT JOIN motion_scans ms ON s.motion_scan_id = ms.id
      WHERE (${athleteId} IS NULL OR s.athlete_id = ${athleteId})
      AND s.created_at >= NOW() - INTERVAL '${timeRange} days'
      AND s.simulation_data->>'overall_score' > '70'
      ORDER BY (s.simulation_data->>'overall_score')::numeric DESC
      LIMIT 50
    `;

    const highlightMoments = highlightData.map((data) => {
      const perfIndex = data.simulation_data;
      const factors = data.valuation_factors;

      return {
        moment_id: `highlight_${data.created_at.getTime()}`,
        timestamp: data.created_at,
        motion_type: data.motion_type,
        performance_score: perfIndex.overall_score,
        tier_level: data.tier_level,
        ai_score: data.ai_score,
        highlight_value: calculateHighlightValue(perfIndex, data.tier_level),
        overlay_effects: generateOverlayEffects(perfIndex, factors),
        stress_visualization: factors.coaching_insights?.stress_zones || [],
        cinematic_potential: assessCinematicPotential(
          perfIndex,
          data.motion_type,
        ),
        institutional_tags: generateInstitutionalTags(perfIndex, factors),
      };
    });

    return {
      total_highlight_moments: highlightMoments.length,
      top_moments: highlightMoments.slice(0, 10),
      cinematic_categories: categorizeCinematicMoments(highlightMoments),
      overlay_library: {
        stress_heatmaps: generateStressOverlays(highlightMoments),
        performance_metrics: generateMetricOverlays(highlightMoments),
        tier_badges: generateTierOverlays(highlightMoments),
      },
    };
  } catch (error) {
    console.error("Highlight reel generation error:", error);
    return { error: "Highlight reel generation failed" };
  }
}

// **INSTITUTIONAL OVERVIEW**
async function generateInstitutionalOverview(athleteId, timeRange) {
  try {
    const [heatmaps, trainingLoad, injuryRisk, highlights] = await Promise.all([
      generateHeatmapOverlays(athleteId, timeRange),
      generateTrainingLoadRecommendations(athleteId, timeRange),
      generateInjuryRiskScoring(athleteId, timeRange),
      generateHighlightReelData(athleteId, timeRange),
    ]);

    return {
      summary_metrics: {
        total_scans_analyzed: heatmaps.total_overlays,
        active_risk_alerts:
          injuryRisk.institutional_insights?.high_risk_athletes?.length || 0,
        highlight_moments_captured: highlights.total_highlight_moments,
        training_adjustments_recommended:
          trainingLoad.current_recommendations?.length || 0,
      },
      real_time_monitoring: heatmaps.real_time_monitoring,
      institutional_alerts: combineInstitutionalAlerts(
        heatmaps,
        trainingLoad,
        injuryRisk,
      ),
      performance_insights: combinePerformanceInsights(
        highlights,
        trainingLoad,
      ),
      system_status: {
        enhanced_heatmap_active: true,
        ml_predictions_online: true,
        institutional_grade: true,
        last_updated: new Date().toISOString(),
      },
    };
  } catch (error) {
    console.error("Institutional overview error:", error);
    return { error: "Overview generation failed" };
  }
}

// **UTILITY FUNCTIONS**

function generateRealTimeAlerts(factors, perfData) {
  const alerts = [];

  if (perfData.injury_risk_score > 75) {
    alerts.push({
      type: "critical_injury_risk",
      message:
        "Critical injury risk detected - immediate intervention recommended",
      priority: "high",
    });
  }

  if (perfData.recovery_index < 30) {
    alerts.push({
      type: "recovery_deficiency",
      message:
        "Recovery index critically low - training load reduction required",
      priority: "medium",
    });
  }

  return alerts;
}

function calculateHighlightPotential(perfData, tierLevel) {
  const baseScore = perfData.overall_score || 0;
  const tierMultiplier = tierLevel >= 3 ? 1.2 : 1.0;
  const tacticalBonus = perfData.tactical_efficiency > 80 ? 10 : 0;

  return Math.min(100, baseScore * tierMultiplier + tacticalBonus);
}

function generateOverlaySVG(coachingInsights) {
  if (!coachingInsights || !coachingInsights.stress_zones) {
    return null;
  }

  // Generate SVG overlay for stress zones
  let svg = '<svg viewBox="0 0 300 400" xmlns="http://www.w3.org/2000/svg">';

  coachingInsights.stress_zones.forEach((zone) => {
    const color = zone.stress_level >= 0.6 ? "#ff0000" : "#ffaa00";
    svg += `<circle cx="150" cy="200" r="20" fill="${color}" opacity="0.6"/>`;
  });

  svg += "</svg>";
  return svg;
}

function calculateStressTrends(overlayData) {
  if (overlayData.length === 0) return {};

  const avgStress =
    overlayData.reduce((sum, d) => {
      return sum + (d.injury_risk_score || 0);
    }, 0) / overlayData.length;

  return {
    average_stress_level: avgStress,
    trend_direction: avgStress > 50 ? "increasing" : "stable",
    high_stress_frequency: overlayData.filter((d) => d.injury_risk_score > 70)
      .length,
  };
}

function countHighRiskZones(overlayData) {
  return overlayData.reduce((count, data) => {
    return (
      count +
      (data.stress_zones?.filter((z) => z.stress_level >= 0.6)?.length || 0)
    );
  }, 0);
}

function calculateTierDistribution(overlayData) {
  const distribution = {};
  overlayData.forEach((data) => {
    const tier = data.tier_level || 1;
    distribution[tier] = (distribution[tier] || 0) + 1;
  });
  return distribution;
}

function assessCurrentLoad(stressData, recoveryIndex) {
  const stressLevel = stressData.reduce(
    (max, zone) => Math.max(max, zone.stress_level || 0),
    0,
  );

  if (stressLevel > 0.6 && recoveryIndex < 40) {
    return "overload_critical";
  } else if (stressLevel > 0.4 || recoveryIndex < 60) {
    return "moderate_stress";
  } else {
    return "optimal_range";
  }
}

function generateLoadAdjustments(stressData, recoveryIndex, tierLevel) {
  const adjustments = [];

  if (recoveryIndex < 40) {
    adjustments.push({
      type: "reduce_intensity",
      recommendation: "Reduce training intensity by 30-40%",
      duration: "48-72 hours",
    });
  }

  const highStressZones = stressData.filter((z) => z.stress_level >= 0.6);
  if (highStressZones.length > 2) {
    adjustments.push({
      type: "targeted_recovery",
      recommendation: "Focus on targeted recovery for high-stress zones",
      zones: highStressZones.map((z) => z.zone_name),
    });
  }

  return adjustments;
}

function calculateRecoveryPriority(stressData) {
  const maxStress = Math.max(...stressData.map((z) => z.stress_level || 0));
  const stressZoneCount = stressData.filter(
    (z) => z.stress_level >= 0.6,
  ).length;

  if (maxStress > 0.65 || stressZoneCount > 3) {
    return "immediate";
  } else if (maxStress > 0.5 || stressZoneCount > 1) {
    return "within_24h";
  } else {
    return "standard";
  }
}

function generateTrainingMods(motionType, stressData) {
  const mods = [];

  switch (motionType) {
    case "sprint":
      if (
        stressData.some((z) => z.zone_name === "ankles" && z.stress_level > 0.6)
      ) {
        mods.push("Reduce sprint volume, focus on ankle mobility");
      }
      break;
    case "jump":
      if (
        stressData.some((z) => z.zone_name === "knees" && z.stress_level > 0.6)
      ) {
        mods.push("Limit plyometric exercises, emphasize knee stability");
      }
      break;
    default:
      mods.push("Monitor high-stress zones closely during training");
  }

  return mods;
}

function recommendNextSession(recoveryIndex, stressData) {
  const maxStress = Math.max(...stressData.map((z) => z.stress_level || 0));

  if (recoveryIndex < 30 || maxStress > 0.65) {
    return "48-72 hours (recovery focus)";
  } else if (recoveryIndex < 50 || maxStress > 0.5) {
    return "24-36 hours (light activity)";
  } else {
    return "12-24 hours (normal progression)";
  }
}

function analyzeLoadTrends(recommendations) {
  const trends = {
    increasing_load: recommendations.filter(
      (r) => r.current_load_assessment === "overload_critical",
    ).length,
    stable_load: recommendations.filter(
      (r) => r.current_load_assessment === "optimal_range",
    ).length,
    recovery_needed: recommendations.filter(
      (r) => r.recovery_priority === "immediate",
    ).length,
  };

  return trends;
}

function getHighStressProtocol() {
  return {
    immediate_actions: [
      "Reduce training intensity by 40%",
      "Implement targeted recovery protocols",
      "Monitor stress zones every 12 hours",
    ],
    recovery_timeline: "48-72 hours minimum",
    clearance_criteria: "Stress zones below 0.4, recovery index above 60%",
  };
}

function getRecoveryOptimization() {
  return {
    active_recovery: ["Light movement, mobility work"],
    passive_recovery: ["Sleep optimization, nutrition support"],
    targeted_therapy: ["Zone-specific treatment based on heatmap"],
  };
}

function getTierGuidelines() {
  return {
    tier_1_2: "Conservative load management, emphasis on technique",
    tier_3_4: "Moderate intensity allowed, monitor closely",
    tier_5_plus: "High-performance protocols, real-time monitoring",
  };
}

function calculateOverallInjuryRisk(perfIndex, factors) {
  const stressScore =
    factors.coaching_insights?.stress_zones?.reduce(
      (max, z) => Math.max(max, z.stress_level || 0),
      0,
    ) || 0;
  const recoveryFactor = (perfIndex.recovery_index || 50) / 100;
  const baseRisk = stressScore * 100;
  const recoveryAdjustment = (1 - recoveryFactor) * 30;

  return Math.min(100, baseRisk + recoveryAdjustment);
}

function calculateZoneRisks(coachingInsights) {
  if (!coachingInsights?.stress_zones) return [];

  return coachingInsights.stress_zones.map((zone) => ({
    zone_name: zone.zone_name,
    risk_level: zone.stress_level * 100,
    risk_category:
      zone.stress_level >= 0.6
        ? "high"
        : zone.stress_level >= 0.4
          ? "moderate"
          : "low",
  }));
}

function runPredictiveModel(perfIndex, tierLevel) {
  // Simple predictive model based on current metrics
  const trendFactor = tierLevel >= 3 ? 1.1 : 0.9;
  const predicted7Day = (perfIndex.overall_score || 0) * trendFactor;
  const predicted30Day = predicted7Day * 0.95; // Slight decline over time

  return {
    next_7_days: Math.min(100, predicted7Day),
    next_30_days: Math.min(100, predicted30Day),
    confidence_level: 0.75,
    model_type: "linear_progression",
  };
}

function generateInstitutionalAlerts(perfIndex, factors) {
  const alerts = [];

  if (perfIndex.overall_score > 90) {
    alerts.push({
      type: "exceptional_performance",
      message: "Exceptional performance detected - highlight reel candidate",
      action: "capture_for_showcase",
    });
  }

  if (factors.coaching_insights?.elite_validation?.validated) {
    alerts.push({
      type: "elite_validation",
      message: "Elite badge validation confirmed",
      action: "tier_advancement_review",
    });
  }

  return alerts;
}

function getPreventionProtocols(perfIndex, factors) {
  return {
    immediate: ["Monitor stress zones", "Adjust training load"],
    short_term: ["Implement recovery protocols", "Schedule follow-up scan"],
    long_term: ["Biomechanical assessment", "Training program review"],
  };
}

function generate7DayForecast(assessments) {
  if (assessments.length === 0) return null;

  const avgRisk =
    assessments.reduce((sum, a) => sum + a.overall_injury_risk, 0) /
    assessments.length;

  return {
    projected_risk: Math.min(100, avgRisk * 1.05),
    confidence: 0.8,
    trend: avgRisk > 60 ? "increasing" : "stable",
  };
}

function generate30DayProjection(assessments) {
  if (assessments.length === 0) return null;

  const avgRisk =
    assessments.reduce((sum, a) => sum + a.overall_injury_risk, 0) /
    assessments.length;

  return {
    projected_risk: Math.min(100, avgRisk * 1.1),
    confidence: 0.65,
    trend: "gradual_increase",
  };
}

function analyzeSeasonalPatterns(assessments) {
  // Simple seasonal analysis
  return {
    pattern_detected: false,
    season_factor: 1.0,
    recommendations: ["Continue monitoring"],
  };
}

function identifyHighRiskAthletes(assessments) {
  return assessments
    .filter((a) => a.overall_injury_risk > 70)
    .map((a) => ({
      assessment_id: a.assessment_id,
      risk_score: a.overall_injury_risk,
      priority: a.overall_injury_risk > 85 ? "critical" : "high",
    }));
}

function getInterventionRecommendations(assessments) {
  const highRiskCount = assessments.filter(
    (a) => a.overall_injury_risk > 70,
  ).length;

  if (highRiskCount > 5) {
    return ["System-wide load reduction", "Enhanced monitoring protocol"];
  } else if (highRiskCount > 2) {
    return ["Targeted interventions", "Individual risk management"];
  } else {
    return ["Continue current protocols", "Maintain monitoring"];
  }
}

function assessProtocolEffectiveness(assessments) {
  return {
    protocol_adherence: 0.85,
    effectiveness_score: 0.78,
    improvement_areas: ["Recovery optimization", "Load management"],
  };
}

function calculateHighlightValue(perfIndex, tierLevel) {
  const baseValue = perfIndex.overall_score || 0;
  const tierBonus = tierLevel * 5;
  const specialBonus = perfIndex.spike_score > 80 ? 15 : 0;

  return Math.min(100, baseValue + tierBonus + specialBonus);
}

function generateOverlayEffects(perfIndex, factors) {
  return {
    stress_heatmap: true,
    performance_metrics: true,
    tier_badge: factors.tier_badge ? true : false,
    elite_validation:
      factors.coaching_insights?.elite_validation?.validated || false,
  };
}

function assessCinematicPotential(perfIndex, motionType) {
  let potential = perfIndex.overall_score || 0;

  // Motion type multipliers
  const multipliers = {
    sprint: 1.2,
    jump: 1.3,
    throw: 1.1,
    grapple: 1.0,
  };

  potential *= multipliers[motionType] || 1.0;

  return Math.min(100, potential);
}

function generateInstitutionalTags(perfIndex, factors) {
  const tags = [];

  if (perfIndex.overall_score > 85) tags.push("exceptional_performance");
  if (factors.coaching_insights?.elite_validation?.validated)
    tags.push("elite_validated");
  if (perfIndex.spike_score > 80) tags.push("spike_performance");
  if (perfIndex.tactical_efficiency > 75) tags.push("tactical_excellence");

  return tags;
}

function categorizeCinematicMoments(moments) {
  return {
    exceptional_performance: moments.filter((m) => m.performance_score > 90),
    elite_validated: moments.filter((m) =>
      m.institutional_tags.includes("elite_validated"),
    ),
    high_intensity: moments.filter((m) =>
      m.stress_visualization.some((z) => z.stress_level > 0.6),
    ),
    tier_showcase: moments.filter((m) => m.tier_level >= 3),
  };
}

function generateStressOverlays(moments) {
  return moments.map((m) => ({
    moment_id: m.moment_id,
    overlay_type: "stress_heatmap",
    zones: m.stress_visualization,
    intensity: Math.max(
      ...m.stress_visualization.map((z) => z.stress_level || 0),
    ),
  }));
}

function generateMetricOverlays(moments) {
  return moments.map((m) => ({
    moment_id: m.moment_id,
    overlay_type: "performance_metrics",
    score: m.performance_score,
    tier: m.tier_level,
    ai_score: m.ai_score,
  }));
}

function generateTierOverlays(moments) {
  return moments.map((m) => ({
    moment_id: m.moment_id,
    overlay_type: "tier_badge",
    tier_level: m.tier_level,
    badge_style: m.tier_level >= 3 ? "professional" : "amateur",
  }));
}

function combineInstitutionalAlerts(heatmaps, trainingLoad, injuryRisk) {
  const alerts = [];

  // Combine alerts from different systems
  if (heatmaps.real_time_monitoring?.active_alerts > 5) {
    alerts.push({
      type: "system_wide",
      message: "Multiple athletes showing high stress patterns",
      priority: "high",
    });
  }

  if (injuryRisk.institutional_insights?.high_risk_athletes?.length > 3) {
    alerts.push({
      type: "injury_prevention",
      message: "Multiple high-risk injury assessments detected",
      priority: "critical",
    });
  }

  return alerts;
}

function combinePerformanceInsights(highlights, trainingLoad) {
  return {
    highlight_performance_correlation: highlights.total_highlight_moments > 10,
    training_load_optimization: trainingLoad.load_trend_analysis,
    institutional_recommendations: [
      "Continue enhanced monitoring",
      "Optimize training protocols",
      "Maintain injury prevention focus",
    ],
  };
}
