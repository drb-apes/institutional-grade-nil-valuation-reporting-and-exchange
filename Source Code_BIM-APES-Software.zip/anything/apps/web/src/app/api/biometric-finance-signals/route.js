export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const signalType = searchParams.get("type") || "all";
  const sport = searchParams.get("sport") || "wrestling";
  const timeframe = searchParams.get("timeframe") || "24h";

  try {
    // Simulate real-time biometric finance signal data
    const timestamp = new Date().toISOString();

    // Sport-specific multipliers
    const sportMultipliers = {
      wrestling: { base: 2.1, volatility: 0.3 },
      "team-sports": { base: 1.8, volatility: 0.25 },
      "racket-sports": { base: 1.6, volatility: 0.2 },
      football: { base: 2.5, volatility: 0.35 },
    };

    const multiplier = sportMultipliers[sport] || sportMultipliers["wrestling"];

    // Generate real-time composite indices
    const compositeIndices = {
      bif_performance: {
        value: 847.3 + (Math.random() - 0.5) * 20,
        change: (Math.random() - 0.5) * 30,
        volatility: Math.random() * 0.4 + 0.1,
        components: {
          biometric_consistency: Math.random() * 20 + 80,
          performance_trajectory: Math.random() * 25 + 75,
          risk_adjusted_returns: Math.random() * 30 + 70,
        },
      },
      coalition_sentiment: {
        value: 692.1 + (Math.random() - 0.5) * 15,
        change: (Math.random() - 0.5) * 20,
        volatility: Math.random() * 0.3 + 0.1,
        components: {
          fan_engagement: Math.random() * 25 + 70,
          coach_confidence: Math.random() * 20 + 75,
          institutional_interest: Math.random() * 30 + 65,
        },
      },
      risk_adjusted_roi: {
        value: 543.8 + (Math.random() - 0.5) * 25,
        change: (Math.random() - 0.5) * 40,
        volatility: Math.random() * 0.5 + 0.15,
        components: {
          injury_probability: Math.random() * 30 + 20,
          performance_volatility: Math.random() * 35 + 15,
          market_stability: Math.random() * 25 + 70,
        },
      },
      nil_opportunity: {
        value: 728.6 + (Math.random() - 0.5) * 18,
        change: (Math.random() - 0.5) * 15,
        volatility: Math.random() * 0.25 + 0.1,
        components: {
          brand_affinity: Math.random() * 30 + 65,
          market_timing: Math.random() * 25 + 70,
          regulatory_clarity: Math.random() * 20 + 75,
        },
      },
    };

    // Generate core signals with sport-specific adjustments
    const coreSignals = {
      biomechanical: {
        power_output_efficiency: Math.random() * 10 + 90,
        movement_consistency: Math.random() * 15 + 80,
        fatigue_resistance: Math.random() * 20 + 70,
        injury_risk_score: Math.random() * 30 + 15,
      },
      financial: {
        market_value_velocity: (Math.random() * 500 + 1000) * multiplier.base,
        liquidity_depth: Math.random() * 15 + 80,
        volatility_coefficient: Math.random() * 0.3 + 0.1,
        correlation_factor: Math.random() * 0.3 + 0.7,
      },
      coalition: {
        voting_power_index: Math.random() * 25 + 60,
        consensus_alignment: Math.random() * 20 + 75,
        stakeholder_confidence: Math.random() * 15 + 85,
        governance_participation: Math.random() * 25 + 65,
      },
    };

    const response = {
      timestamp,
      sport,
      timeframe,
      sport_multiplier: multiplier.base,
      data: {},
    };

    // Return specific signal type or all
    if (signalType === "composite" || signalType === "all") {
      response.data.composite_indices = compositeIndices;
    }
    if (signalType === "core" || signalType === "all") {
      response.data.core_signals = coreSignals;
    }

    return Response.json(response);
  } catch (error) {
    console.error("Error generating biometric finance signals:", error);
    return Response.json(
      { error: "Failed to generate signal data" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { signal_type, threshold_value, alert_condition, sport } = body;

    // Simulate setting up signal alerts
    const alertConfig = {
      id: Math.random().toString(36).substr(2, 9),
      signal_type,
      threshold_value,
      alert_condition, // 'above', 'below', 'change'
      sport,
      created_at: new Date().toISOString(),
      status: "active",
    };

    return Response.json({
      success: true,
      alert_config: alertConfig,
      message: `Alert configured for ${signal_type} signals`,
    });
  } catch (error) {
    console.error("Error configuring signal alert:", error);
    return Response.json(
      { error: "Failed to configure alert" },
      { status: 500 },
    );
  }
}
