import sql from "@/app/api/utils/sql";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Universal Broadcast Feed API
 *
 * Multi-network compatible broadcast feed
 * Supports: ESPN, TNT, NBC, Fox Sports, CBS, Amazon Prime Video, Apple TV+
 *
 * Format: Standardized JSON with network-specific adapters
 */

export async function POST(request) {
  try {
    // Verify broadcast API key (universal)
    const apiKey = request.headers.get("x-broadcast-api-key");
    const network = request.headers.get("x-broadcast-network"); // 'espn' | 'tnt' | 'nbc' | etc.

    if (!apiKey || !isValidBroadcastKey(apiKey)) {
      return createSecureResponse(
        { error: "Invalid API key" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`broadcast-${network}-${apiKey}`, {
      maxRequests: 150,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      eventId: { required: true, type: "string" },
      sport: { required: true, type: "string" },
      athletes: { required: true, type: "object" },
      feedType: { required: false, type: "string" },
      outputFormat: { required: false, type: "string" },
    });

    const {
      eventId,
      sport,
      athletes,
      feedType = "real_time",
      outputFormat = "standard",
    } = body;

    const athleteIds = athletes.map((a) => a.athleteId);

    // Fetch comprehensive athlete data
    const athleteData = await fetchAthleteData(athleteIds, eventId, sport);

    // Build universal feed
    const universalFeed = {
      metadata: {
        eventId,
        sport,
        network,
        feedType,
        generatedAt: new Date().toISOString(),
        dataVersion: "3.0",
      },
      athletes: athleteData,
      eventMetrics: calculateEventMetrics(athleteData, sport),
      broadcastAssets: generateBroadcastAssets(athleteData, sport, network),
    };

    // Apply network-specific formatting
    const networkFeed = applyNetworkFormat(
      universalFeed,
      network,
      outputFormat,
    );

    return createSecureResponse({
      success: true,
      feed: networkFeed,
      latency: 0,
    });
  } catch (error) {
    console.error("Universal broadcast feed error:", error);
    return createSecureResponse(
      { error: "Failed to generate broadcast feed" },
      { status: 500 },
    );
  }
}

// Fetch athlete data
async function fetchAthleteData(athleteIds, eventId, sport) {
  const now = Date.now();
  const thirtySecondsAgo = now - 30000;

  const biometrics = await sql`
    SELECT 
      wd.owner_id as athlete_id,
      wds.stream_type,
      wds.processed_data,
      wds.timestamp,
      wds.data_quality_score
    FROM wearable_data_streams wds
    JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
    WHERE wd.owner_id = ANY(${athleteIds})
      AND wds.session_id = ${eventId}
      AND wds.timestamp > to_timestamp(${thirtySecondsAgo / 1000})
    ORDER BY wds.timestamp DESC
  `;

  const profiles = await sql`
    SELECT 
      up.id,
      au.name,
      up.tier_level,
      up.reputation_score
    FROM user_profiles up
    JOIN auth_users au ON up.user_id = au.id
    WHERE up.id = ANY(${athleteIds})
  `;

  return profiles.map((profile) => {
    const athleteStreams = biometrics.filter(
      (b) => b.athlete_id === profile.id,
    );

    return {
      athleteId: profile.id,
      name: profile.name,
      tier: getTierName(profile.tier_level),
      biometric: extractBiometricData(athleteStreams),
      performance: extractPerformanceData(athleteStreams, sport),
      capsule: generateCapsuleForBroadcast(athleteStreams, sport),
      nil: {
        currentValue: calculateInstantNIL(athleteStreams),
        tier: getTierName(profile.tier_level),
      },
    };
  });
}

// Extract biometric data
function extractBiometricData(streams) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");

  return {
    heartRate: hrStream?.processed_data?.bpm || null,
    zone: hrStream?.processed_data?.zone || null,
    hrv: hrStream?.processed_data?.hrv || null,
  };
}

// Extract performance data
function extractPerformanceData(streams, sport) {
  const gpsStream = streams.find((s) => s.stream_type === "gps");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");

  return {
    speed: gpsStream?.processed_data?.speed || null,
    acceleration: accelStream?.processed_data?.magnitude || null,
    distance: gpsStream?.processed_data?.distance || null,
  };
}

// Generate capsule for broadcast
function generateCapsuleForBroadcast(streams, sport) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");

  const bpm = hrStream?.processed_data?.bpm || 0;
  const zone = hrStream?.processed_data?.zone || "recovery";
  const magnitude = accelStream?.processed_data?.magnitude || 0;

  let glowColor = "#F2F2F2";
  let fatigueColor = "#3CFF7A";

  if (zone === "anaerobic") {
    glowColor = "#FFCC33";
    fatigueColor = "#FF3C3C";
  }

  return {
    glow: glowColor,
    fatigue: fatigueColor,
    intensity: zone,
    status: bpm > 180 ? "critical" : bpm > 160 ? "high" : "normal",
  };
}

// Calculate instant NIL
function calculateInstantNIL(streams) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const zone = hrStream?.processed_data?.zone || "recovery";

  const baseNIL = 100000;
  let multiplier = 1.0;

  if (zone === "anaerobic") multiplier = 1.15;
  else if (zone === "vo2max") multiplier = 1.1;

  return Math.round(baseNIL * multiplier);
}

// Calculate event metrics
function calculateEventMetrics(athletes, sport) {
  const avgHR = athletes
    .map((a) => a.biometric?.heartRate || 0)
    .filter((hr) => hr > 0)
    .reduce((sum, hr, _, arr) => sum + hr / (arr.length || 1), 0);

  return {
    averageHeartRate: Math.round(avgHR),
    totalAthletes: athletes.length,
    highIntensityCount: athletes.filter((a) => a.capsule?.status === "critical")
      .length,
  };
}

// Generate broadcast assets
function generateBroadcastAssets(athletes, sport, network) {
  const assets = [];

  // Highlight reel suggestions
  const highPerformers = athletes.filter(
    (a) => a.capsule?.intensity === "anaerobic",
  );
  if (highPerformers.length > 0) {
    assets.push({
      type: "highlight_suggestion",
      athletes: highPerformers.map((a) => a.athleteId),
      reason: "High-intensity performance moment",
    });
  }

  // NIL surge alerts
  const nilSurge = athletes.filter((a) => a.nil?.currentValue > 110000);
  if (nilSurge.length > 0) {
    assets.push({
      type: "nil_alert",
      athletes: nilSurge.map((a) => a.athleteId),
      reason: "NIL value surge detected",
    });
  }

  return assets;
}

// Apply network-specific format
function applyNetworkFormat(universalFeed, network, outputFormat) {
  // Network-specific adaptations
  const formatters = {
    espn: formatForESPN,
    tnt: formatForTNT,
    nbc: formatForNBC,
  };

  const formatter = formatters[network?.toLowerCase()] || ((feed) => feed);
  return formatter(universalFeed, outputFormat);
}

function formatForESPN(feed, format) {
  // ESPN prefers compact JSON with specific field names
  return {
    event_id: feed.metadata.eventId,
    sport: feed.metadata.sport,
    players: feed.athletes.map((a) => ({
      id: a.athleteId,
      name: a.name,
      hr: a.biometric.heartRate,
      zone: a.biometric.zone,
      nil_value: a.nil.currentValue,
      status: a.capsule.status,
    })),
    event_stats: feed.eventMetrics,
  };
}

function formatForTNT(feed, format) {
  // TNT prefers full capsule SVG data
  return {
    eventId: feed.metadata.eventId,
    athletes: feed.athletes.map((a) => ({
      id: a.athleteId,
      name: a.name,
      capsule: a.capsule,
      performance: a.performance,
    })),
  };
}

function formatForNBC(feed, format) {
  // NBC prefers narrative-focused data
  return {
    eventId: feed.metadata.eventId,
    athletes: feed.athletes.map((a) => ({
      id: a.athleteId,
      name: a.name,
      tier: a.tier,
      performance: a.performance,
      nil: a.nil,
    })),
    broadcastAssets: feed.broadcastAssets,
  };
}

// Validate broadcast API key
function isValidBroadcastKey(key) {
  const validKeys = [
    process.env.ESPN_BROADCAST_API_KEY,
    process.env.TNT_BROADCAST_API_KEY,
    process.env.NBC_BROADCAST_API_KEY,
    process.env.UNIVERSAL_BROADCAST_API_KEY,
  ];

  return validKeys.filter((k) => k).includes(key);
}

function getTierName(level) {
  const tiers = [
    "Emerging",
    "Foundational",
    "Developing",
    "High Performer",
    "Elite",
  ];
  return tiers[level - 1] || "Unknown";
}
