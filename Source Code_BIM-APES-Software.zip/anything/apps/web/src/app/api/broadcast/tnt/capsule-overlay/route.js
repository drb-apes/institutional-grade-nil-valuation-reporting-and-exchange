import sql from "@/app/api/utils/sql";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * TNT Broadcast BiomechFlow Capsule Overlay API
 *
 * Provides pre-rendered capsule visualization data for TNT broadcast graphics
 * Supports: SVG paths, animation keyframes, color palettes
 *
 * Integration: TNT Broadcast Graphics Engine
 * Format: SVG + JSON animation data
 */

export async function POST(request) {
  try {
    // Verify broadcast API key
    const apiKey = request.headers.get("x-broadcast-api-key");
    if (!apiKey || apiKey !== process.env.TNT_BROADCAST_API_KEY) {
      return createSecureResponse(
        { error: "Invalid API key" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`tnt-capsule-${apiKey}`, {
      maxRequests: 100,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      eventId: { required: true, type: "string" },
      renderFormat: { required: false, type: "string" },
      size: { required: false, type: "number" },
      animationDuration: { required: false, type: "number" },
    });

    const {
      athleteId,
      eventId,
      renderFormat = "svg",
      size = 200,
      animationDuration = 300,
    } = body;

    // Fetch latest athlete data
    const now = Date.now();
    const tenSecondsAgo = now - 10000;

    const athleteStreams = await sql`
      SELECT 
        wds.stream_type,
        wds.processed_data,
        wds.timestamp
      FROM wearable_data_streams wds
      JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
      WHERE wd.owner_id = ${athleteId}
        AND wds.session_id = ${eventId}
        AND wds.timestamp > to_timestamp(${tenSecondsAgo / 1000})
      ORDER BY wds.timestamp DESC
      LIMIT 20
    `;

    if (athleteStreams.length === 0) {
      return createSecureResponse(
        { error: "No recent data for athlete" },
        { status: 404 },
      );
    }

    // Generate capsule state
    const capsule = generateDetailedCapsule(athleteStreams);

    // Render capsule based on format
    let renderedCapsule;
    if (renderFormat === "svg") {
      renderedCapsule = renderCapsuleSVG(capsule, size);
    } else if (renderFormat === "json") {
      renderedCapsule = capsule;
    } else {
      return createSecureResponse(
        { error: "Invalid render format" },
        { status: 400 },
      );
    }

    // Generate animation keyframes
    const animationKeyframes = generateCapsuleAnimation(
      capsule,
      animationDuration,
    );

    return createSecureResponse({
      success: true,
      athleteId,
      eventId,
      capsule: renderedCapsule,
      animationKeyframes,
      format: renderFormat,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("TNT capsule overlay error:", error);
    return createSecureResponse(
      { error: "Failed to generate capsule overlay" },
      { status: 500 },
    );
  }
}

// Generate detailed capsule
function generateDetailedCapsule(streams) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");
  const forceStream = streams.find((s) => s.stream_type === "force");

  const bpm = hrStream?.processed_data?.bpm || 0;
  const zone = hrStream?.processed_data?.zone || "recovery";
  const magnitude = accelStream?.processed_data?.magnitude || 0;
  const force = forceStream?.processed_data?.newton || 0;

  // Glow ring
  let glowColor = "#F2F2F2";
  let glowBloom = 100;
  let glowPulse = 0.5;

  if (zone === "anaerobic") {
    glowColor = "#FFCC33";
    glowBloom = 200;
    glowPulse = 1.5;
  } else if (zone === "vo2max") {
    glowColor = "#FFCC33";
    glowBloom = 150;
    glowPulse = 1.0;
  }

  // Stress arc
  const stress = magnitude * 2 + force / 100;
  let stressThickness = 2;
  let stressColor = "#4DA6FF";

  if (stress > 20) {
    stressThickness = 10;
    stressColor = "#002B66";
  } else if (stress > 10) {
    stressThickness = 6;
    stressColor = "#1E5FA8";
  }

  // Fatigue arc
  let fatigueColor = "#3CFF7A";
  let fatigueGradient = ["#3CFF7A", "#3CFF7A"];

  if (bpm > 180) {
    fatigueColor = "#FF3C3C";
    fatigueGradient = ["#FFD93C", "#FF3C3C"];
  } else if (bpm > 160) {
    fatigueColor = "#FFD93C";
    fatigueGradient = ["#3CFF7A", "#FFD93C"];
  }

  // Recovery line
  const hrDelta =
    (hrStream?.processed_data?.bpm || 0) -
    (hrStream?.processed_data?.prevBpm || hrStream?.processed_data?.bpm || 0);
  let recoverySlope = 0;
  if (hrDelta < -5) recoverySlope = -30;
  else if (hrDelta > 5) recoverySlope = 30;

  // Bars
  let subHeight = 10;
  if (zone === "anaerobic" && bpm > 185) subHeight = 60;

  let injuryHeight = 10;
  let injuryColor = "#33FFF3";
  if (magnitude > 10 || force > 2000) {
    injuryHeight = 60;
    injuryColor = "#D90000";
  } else if (magnitude > 5 || force > 1000) {
    injuryHeight = 40;
    injuryColor = "#FF8C33";
  }

  return {
    glowRing: { color: glowColor, bloom: glowBloom, pulse: glowPulse },
    stressArc: { thickness: stressThickness, color: stressColor, stress },
    fatigueArc: { color: fatigueColor, gradient: fatigueGradient, zone },
    recoveryLine: {
      slope: recoverySlope,
      animation: recoverySlope !== 0 ? "sweep" : "static",
    },
    leftBar: { height: subHeight, color: "#3B82F6" },
    rightBar: { height: injuryHeight, color: injuryColor },
    metadata: {
      bpm,
      zone,
      magnitude,
      force,
    },
  };
}

// Render capsule as SVG
function renderCapsuleSVG(capsule, size) {
  const radius = size / 2;
  const center = size / 2;

  const svg = `
<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
  <!-- Glow Ring -->
  <circle 
    cx="${center}" 
    cy="${center}" 
    r="${radius * 0.9}" 
    fill="none" 
    stroke="${capsule.glowRing.color}" 
    stroke-width="4" 
    opacity="${capsule.glowRing.bloom / 200}"
    filter="url(#glow)"
  >
    <animate attributeName="opacity" values="${capsule.glowRing.bloom / 200};${capsule.glowRing.bloom / 100};${capsule.glowRing.bloom / 200}" dur="${1 / capsule.glowRing.pulse}s" repeatCount="indefinite" />
  </circle>
  
  <!-- Top Arc (Stress) -->
  <path 
    d="M ${center - radius * 0.7} ${center} A ${radius * 0.7} ${radius * 0.7} 0 0 1 ${center + radius * 0.7} ${center}"
    fill="none"
    stroke="${capsule.stressArc.color}"
    stroke-width="${capsule.stressArc.thickness}"
  />
  
  <!-- Bottom Arc (Fatigue) -->
  <path 
    d="M ${center - radius * 0.7} ${center} A ${radius * 0.7} ${radius * 0.7} 0 0 0 ${center + radius * 0.7} ${center}"
    fill="none"
    stroke="${capsule.fatigueArc.color}"
    stroke-width="4"
  />
  
  <!-- Recovery Line -->
  <line 
    x1="${center - 20}" 
    y1="${center}" 
    x2="${center + 20}" 
    y2="${center - Math.tan((capsule.recoveryLine.slope * Math.PI) / 180) * 20}" 
    stroke="#FFFFFF" 
    stroke-width="2"
  />
  
  <!-- Left Bar (Sub Probability) -->
  <rect 
    x="${center - radius - 10}" 
    y="${center - capsule.leftBar.height / 2}" 
    width="4" 
    height="${capsule.leftBar.height}" 
    fill="${capsule.leftBar.color}"
  />
  
  <!-- Right Bar (Injury Risk) -->
  <rect 
    x="${center + radius + 6}" 
    y="${center - capsule.rightBar.height / 2}" 
    width="4" 
    height="${capsule.rightBar.height}" 
    fill="${capsule.rightBar.color}"
  />
  
  <!-- Glow Filter -->
  <defs>
    <filter id="glow">
      <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>
</svg>
  `.trim();

  return svg;
}

// Generate animation keyframes
function generateCapsuleAnimation(capsule, duration) {
  return {
    glowRing: {
      property: "opacity",
      keyframes: [
        { time: 0, value: capsule.glowRing.bloom / 200 },
        { time: duration / 2, value: capsule.glowRing.bloom / 100 },
        { time: duration, value: capsule.glowRing.bloom / 200 },
      ],
      loop: true,
    },
    recoveryLine: {
      property: "transform",
      keyframes:
        capsule.recoveryLine.animation === "sweep"
          ? [
              { time: 0, value: "rotate(0deg)" },
              {
                time: duration,
                value: `rotate(${capsule.recoveryLine.slope}deg)`,
              },
            ]
          : [],
      loop: false,
    },
    fatigueArc:
      capsule.fatigueArc.zone === "anaerobic"
        ? {
            property: "stroke",
            keyframes: [
              { time: 0, value: capsule.fatigueArc.gradient[0] },
              { time: duration / 2, value: capsule.fatigueArc.gradient[1] },
              { time: duration, value: capsule.fatigueArc.gradient[0] },
            ],
            loop: true,
          }
        : null,
  };
}
