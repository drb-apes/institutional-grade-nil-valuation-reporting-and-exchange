import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * NBC Broadcast Athlete Story Feed API
 *
 * Provides narrative-focused athlete data for human-interest storytelling
 * Includes: Performance journey, milestone progress, community impact, adversity overcome
 *
 * Integration: NBC Olympics Coverage, NBC Sports Sunday Night Football
 */

export async function POST(request) {
  try {
    // Verify broadcast API key
    const apiKey = request.headers.get("x-broadcast-api-key");
    if (!apiKey || apiKey !== process.env.NBC_BROADCAST_API_KEY) {
      return createSecureResponse(
        { error: "Invalid API key" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`nbc-story-${apiKey}`, {
      maxRequests: 60,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      storyType: { required: false, type: "string" },
      includePerformanceJourney: { required: false, type: "boolean" },
      includeMilestones: { required: false, type: "boolean" },
      includeNILGrowth: { required: false, type: "boolean" },
    });

    const {
      athleteId,
      storyType = "full_profile",
      includePerformanceJourney = true,
      includeMilestones = true,
      includeNILGrowth = true,
    } = body;

    // Fetch athlete profile
    const athleteProfile = await sql`
      SELECT 
        up.*,
        au.name,
        au.email
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId}
      LIMIT 1
    `;

    if (athleteProfile.length === 0) {
      return createSecureResponse(
        { error: "Athlete not found" },
        { status: 404 },
      );
    }

    const athlete = athleteProfile[0];

    // Build story feed
    const storyFeed = {
      athleteId,
      name: athlete.name,
      userType: athlete.user_type,
      tierLevel: athlete.tier_level,
      reputationScore: athlete.reputation_score,
      overview: generateAthleteOverview(athlete),
    };

    // Performance journey
    if (includePerformanceJourney) {
      storyFeed.performanceJourney =
        await generatePerformanceJourney(athleteId);
    }

    // Milestones
    if (includeMilestones) {
      storyFeed.milestones = await getMilestones(athleteId);
    }

    // NIL growth story
    if (includeNILGrowth) {
      storyFeed.nilGrowth = await getNILGrowthStory(athleteId);
    }

    // Human-interest angles
    storyFeed.narrativeAngles = await generateNarrativeAngles(
      athleteId,
      athlete,
    );

    // Quote-worthy stats
    storyFeed.standoutStats = await generateStandoutStats(athleteId);

    // Suggested graphics
    storyFeed.broadcastGraphics = generateStoryGraphics(storyFeed);

    return createSecureResponse({
      success: true,
      storyFeed,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("NBC story feed error:", error);
    return createSecureResponse(
      { error: "Failed to generate athlete story feed" },
      { status: 500 },
    );
  }
}

// Generate athlete overview
function generateAthleteOverview(athlete) {
  return {
    name: athlete.name,
    tier: getTierName(athlete.tier_level),
    reputation: athlete.reputation_score,
    totalContributions: athlete.total_contributions,
    totalEarnings: athlete.total_earnings,
    careerStage: determineCareerStage(athlete),
  };
}

// Generate performance journey
async function generatePerformanceJourney(athleteId) {
  // Fetch motion scans over time
  const scans = await sql`
    SELECT 
      ai_score,
      motion_type,
      created_at
    FROM motion_scans
    WHERE athlete_id = ${athleteId}
      AND verification_status = 'verified'
    ORDER BY created_at ASC
    LIMIT 50
  `;

  if (scans.length === 0) {
    return { dataPoints: [], trend: "insufficient_data" };
  }

  // Calculate trend
  const scores = scans.map((s) => s.ai_score);
  const avgScore =
    scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const recentAvg =
    scores.slice(-10).reduce((sum, score) => sum + score, 0) /
    Math.min(10, scores.length);
  const trend =
    recentAvg > avgScore
      ? "improving"
      : recentAvg < avgScore
        ? "declining"
        : "stable";

  return {
    dataPoints: scans.map((s) => ({
      date: s.created_at,
      score: s.ai_score,
      motionType: s.motion_type,
    })),
    averageScore: avgScore.toFixed(2),
    recentScore: recentAvg.toFixed(2),
    trend,
    improvement: (((recentAvg - avgScore) / avgScore) * 100).toFixed(1),
  };
}

// Get milestones
async function getMilestones(athleteId) {
  const milestones = await sql`
    SELECT 
      title,
      description,
      target_metrics,
      current_progress,
      milestone_status,
      target_date,
      created_at,
      completed_at
    FROM milestones
    WHERE athlete_id = ${athleteId}
    ORDER BY created_at DESC
    LIMIT 10
  `;

  return {
    total: milestones.length,
    completed: milestones.filter((m) => m.milestone_status === "completed")
      .length,
    active: milestones.filter((m) => m.milestone_status === "active").length,
    milestones: milestones.map((m) => ({
      title: m.title,
      description: m.description,
      status: m.milestone_status,
      progress: calculateProgress(m.current_progress, m.target_metrics),
      completedAt: m.completed_at,
    })),
  };
}

// Get NIL growth story
async function getNILGrowthStory(athleteId) {
  // Fetch NIL account
  const nilAccount = await sql`
    SELECT * FROM nil_valuation_accounts
    WHERE athlete_id = ${athleteId}
    LIMIT 1
  `;

  if (nilAccount.length === 0) {
    return { narrative: "No NIL data available", growth: 0 };
  }

  const account = nilAccount[0];

  // Fetch historical valuations
  const history = await sql`
    SELECT * FROM player_index_history
    WHERE athlete_id = ${athleteId}
    ORDER BY recorded_at ASC
  `;

  const initialValue = history[0]?.valuation || account.current_valuation;
  const currentValue = account.current_valuation;
  const growth =
    initialValue > 0 ? ((currentValue - initialValue) / initialValue) * 100 : 0;

  return {
    initialValue,
    currentValue,
    growth: growth.toFixed(1),
    playerIndex: account.player_index,
    narrative: generateNILNarrative(growth, initialValue, currentValue),
    dataPoints: history.length,
  };
}

// Generate narrative angles
async function generateNarrativeAngles(athleteId, athlete) {
  // Check for referral data (adversity/community impact)
  const referral = await sql`
    SELECT 
      standout_traits,
      adversity_overcome,
      community_impact
    FROM athlete_referrals
    WHERE athlete_profile_id = ${athleteId}
    LIMIT 1
  `;

  const angles = [];

  if (athlete.tier_level >= 4) {
    angles.push({
      angle: "underdog_story",
      headline: "From Emerging Talent to Elite Performer",
      narrative: "Watch how data-driven training transformed this athlete",
    });
  }

  if (referral.length > 0 && referral[0].adversity_overcome) {
    angles.push({
      angle: "adversity",
      headline: "Overcoming the Odds",
      narrative: referral[0].adversity_overcome,
    });
  }

  if (referral.length > 0 && referral[0].community_impact) {
    angles.push({
      angle: "community_impact",
      headline: "Making a Difference",
      narrative: referral[0].community_impact,
    });
  }

  if (athlete.total_earnings > athlete.total_contributions) {
    angles.push({
      angle: "financial_success",
      headline: "NIL Success Story",
      narrative: `Earned $${athlete.total_earnings.toLocaleString()} through performance-based NIL`,
    });
  }

  return angles;
}

// Generate standout stats
async function generateStandoutStats(athleteId) {
  const stats = [];

  // Motion scan stats
  const topScans = await sql`
    SELECT ai_score, motion_type
    FROM motion_scans
    WHERE athlete_id = ${athleteId}
      AND verification_status = 'verified'
    ORDER BY ai_score DESC
    LIMIT 5
  `;

  if (topScans.length > 0) {
    stats.push({
      category: "Performance",
      stat: `${topScans[0].ai_score.toFixed(1)} AI Score`,
      context: `Best ${topScans[0].motion_type} performance`,
      isRecord: topScans[0].ai_score > 90,
    });
  }

  // Milestone completion rate
  const milestoneData = await sql`
    SELECT milestone_status, COUNT(*) as count
    FROM milestones
    WHERE athlete_id = ${athleteId}
    GROUP BY milestone_status
  `;

  const completed =
    milestoneData.find((m) => m.milestone_status === "completed")?.count || 0;
  const total = milestoneData.reduce((sum, m) => sum + parseInt(m.count), 0);

  if (total > 0) {
    const completionRate = (completed / total) * 100;
    stats.push({
      category: "Consistency",
      stat: `${completionRate.toFixed(0)}% Milestone Completion`,
      context: `${completed} of ${total} milestones achieved`,
      isRecord: completionRate > 80,
    });
  }

  return stats;
}

// Generate story graphics
function generateStoryGraphics(storyFeed) {
  const graphics = [];

  // NIL growth graphic
  if (storyFeed.nilGrowth && parseFloat(storyFeed.nilGrowth.growth) > 50) {
    graphics.push({
      type: "NIL_GROWTH_CHART",
      title: `${storyFeed.nilGrowth.growth}% NIL Growth`,
      data: storyFeed.nilGrowth,
    });
  }

  // Performance journey graphic
  if (
    storyFeed.performanceJourney &&
    storyFeed.performanceJourney.trend === "improving"
  ) {
    graphics.push({
      type: "PERFORMANCE_TRAJECTORY",
      title: `${storyFeed.performanceJourney.improvement}% Improvement`,
      data: storyFeed.performanceJourney,
    });
  }

  // Milestone progress
  if (storyFeed.milestones && storyFeed.milestones.completed > 0) {
    graphics.push({
      type: "MILESTONE_PROGRESS",
      title: `${storyFeed.milestones.completed} Milestones Achieved`,
      data: storyFeed.milestones,
    });
  }

  return graphics;
}

// Utility functions
function getTierName(level) {
  const tiers = [
    "Emerging",
    "Foundational",
    "Developing",
    "High Performer",
    "Elite",
  ];
  return tiers[level - 1] || "Unknown";
}

function determineCareerStage(athlete) {
  if (athlete.tier_level >= 4) return "peak";
  if (athlete.tier_level >= 2) return "developing";
  return "early_career";
}

function calculateProgress(current, target) {
  if (!current || !target) return 0;
  // Simplified progress calculation
  return 50; // Placeholder
}

function generateNILNarrative(growth, initial, current) {
  if (growth > 100) {
    return `Remarkable NIL growth: from $${initial.toLocaleString()} to $${current.toLocaleString()} — more than doubling in value through consistent performance.`;
  } else if (growth > 50) {
    return `Strong NIL trajectory: ${growth}% growth demonstrates market confidence and performance consistency.`;
  } else if (growth > 0) {
    return `Steady NIL growth of ${growth}%, reflecting reliable performance and fan engagement.`;
  } else {
    return `NIL value holding steady at $${current.toLocaleString()}, awaiting next performance catalyst.`;
  }
}
