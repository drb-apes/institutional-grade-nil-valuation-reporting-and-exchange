import sql from "@/app/api/utils/sql";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * ESPN Broadcast Real-Time Feed API
 *
 * Provides real-time athlete performance data, capsule states, and NIL valuations
 * for live broadcast graphics overlays
 *
 * Integration: ESPN Broadcast Graphics System
 * Rate Limit: 200 req/min (high throughput for live broadcasts)
 */

export async function POST(request) {
  try {
    // Verify broadcast API key
    const apiKey = request.headers.get("x-broadcast-api-key");
    if (!apiKey || apiKey !== process.env.ESPN_BROADCAST_API_KEY) {
      return createSecureResponse(
        { error: "Invalid API key" },
        { status: 401 },
      );
    }

    // High throughput rate limiting for live broadcasts
    const rateLimit = checkRateLimit(`espn-feed-${apiKey}`, {
      maxRequests: 200,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      eventId: { required: true, type: "string" },
      sport: { required: true, type: "string" },
      athletes: { required: true, type: "object" },
      dataTypes: { required: false, type: "object" },
      includeNIL: { required: false, type: "boolean" },
      includeCapsules: { required: false, type: "boolean" },
      includePlaybook: { required: false, type: "boolean" },
    });

    const {
      eventId,
      sport,
      athletes,
      dataTypes = ["performance", "biometric", "nil"],
      includeNIL = true,
      includeCapsules = true,
      includePlaybook = false,
    } = body;

    const athleteIds = athletes.map((a) => a.athleteId);

    // Fetch latest biometric data (last 30 seconds)
    const now = Date.now();
    const thirtySecondsAgo = now - 30000;

    const latestBiometrics = await sql`
      SELECT 
        wd.owner_id as athlete_id,
        wds.stream_type,
        wds.processed_data,
        wds.timestamp,
        wds.data_quality_score
      FROM wearable_data_streams wds
      JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
      WHERE wd.owner_id = ANY(${athleteIds})
        AND wds.timestamp > to_timestamp(${thirtySecondsAgo / 1000})
      ORDER BY wds.timestamp DESC
    `;

    // Build broadcast feed
    const broadcastFeed = {
      eventId,
      sport,
      timestamp: new Date().toISOString(),
      athletes: [],
    };

    // Process each athlete
    for (const athlete of athletes) {
      const athleteStreams = latestBiometrics.filter(
        (b) => b.athlete_id === athlete.athleteId,
      );

      const athleteData = {
        athleteId: athlete.athleteId,
        name: athlete.name,
        position: athlete.position,
        jerseyNumber: athlete.jerseyNumber,
      };

      // Performance metrics
      if (dataTypes.includes("performance")) {
        athleteData.performance = extractPerformanceMetrics(
          athleteStreams,
          sport,
        );
      }

      // Biometric data
      if (dataTypes.includes("biometric")) {
        athleteData.biometric = extractBiometricMetrics(athleteStreams);
      }

      // NIL valuation
      if (includeNIL && dataTypes.includes("nil")) {
        athleteData.nil = await calculateLiveNIL(
          athlete.athleteId,
          athleteStreams,
          sport,
        );
      }

      // BiomechFlow capsule
      if (includeCapsules) {
        athleteData.capsule = generateBroadcastCapsule(athleteStreams, sport);
      }

      // Playbook data (tactical positioning)
      if (includePlaybook) {
        athleteData.tactical = await getTacticalPosition(
          athlete.athleteId,
          eventId,
        );
      }

      broadcastFeed.athletes.push(athleteData);
    }

    // Add event-level metrics
    broadcastFeed.eventMetrics = calculateEventMetrics(
      broadcastFeed.athletes,
      sport,
    );

    // Add broadcast graphics suggestions
    broadcastFeed.graphicsSuggestions = generateGraphicsSuggestions(
      broadcastFeed,
      sport,
    );

    return createSecureResponse({
      success: true,
      feed: broadcastFeed,
      latency: Date.now() - now,
      dataQuality: calculateFeedQuality(latestBiometrics),
    });
  } catch (error) {
    console.error("ESPN feed error:", error);
    return createSecureResponse(
      { error: "Failed to generate broadcast feed" },
      { status: 500 },
    );
  }
}

// GET: Real-time streaming endpoint
export async function GET(request) {
  try {
    const apiKey = request.headers.get("x-broadcast-api-key");
    if (!apiKey || apiKey !== process.env.ESPN_BROADCAST_API_KEY) {
      return createSecureResponse(
        { error: "Invalid API key" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const eventId = searchParams.get("eventId");
    const athleteId = searchParams.get("athleteId");

    if (!eventId) {
      return createSecureResponse(
        { error: "eventId required" },
        { status: 400 },
      );
    }

    // Fetch latest snapshot
    const latestData = await sql`
      SELECT 
        wd.owner_id as athlete_id,
        wds.stream_type,
        wds.processed_data,
        wds.timestamp
      FROM wearable_data_streams wds
      JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
      WHERE wds.session_id = ${eventId}
      ORDER BY wds.timestamp DESC
      LIMIT 100
    `;

    return createSecureResponse({
      success: true,
      eventId,
      snapshot: latestData,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("ESPN feed GET error:", error);
    return createSecureResponse(
      { error: "Failed to fetch broadcast snapshot" },
      { status: 500 },
    );
  }
}

// Extract performance metrics
function extractPerformanceMetrics(streams, sport) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");
  const gpsStream = streams.find((s) => s.stream_type === "gps");
  const forceStream = streams.find((s) => s.stream_type === "force");

  return {
    heartRate: hrStream?.processed_data?.bpm || null,
    hrZone: hrStream?.processed_data?.zone || null,
    speed: gpsStream?.processed_data?.speed || null,
    acceleration: accelStream?.processed_data?.magnitude || null,
    impact: accelStream?.processed_data?.impact || null,
    force: forceStream?.processed_data?.newton || null,
    distance: gpsStream?.processed_data?.distance || null,
    activityType:
      streams.find((s) => s.stream_type === "motion")?.processed_data
        ?.activityType || null,
  };
}

// Extract biometric metrics
function extractBiometricMetrics(streams) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");

  return {
    bpm: hrStream?.processed_data?.bpm || null,
    hrv: hrStream?.processed_data?.hrv || null,
    zone: hrStream?.processed_data?.zone || null,
    vo2max: hrStream?.processed_data?.vo2max || null,
    recovery: hrStream?.processed_data?.recovery || null,
  };
}

// Calculate live NIL
async function calculateLiveNIL(athleteId, streams, sport) {
  // Get athlete baseline NIL
  const athleteProfile = await sql`
    SELECT * FROM user_profiles
    WHERE id = ${athleteId}
    LIMIT 1
  `;

  if (athleteProfile.length === 0) {
    return { baseValue: 0, currentValue: 0, change: 0 };
  }

  const baseNIL = 100000; // Placeholder base NIL

  // Calculate performance multiplier
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");

  let multiplier = 1.0;

  // High-intensity performance boosts NIL
  if (hrStream?.processed_data?.zone === "anaerobic") {
    multiplier += 0.15;
  } else if (hrStream?.processed_data?.zone === "vo2max") {
    multiplier += 0.1;
  }

  // High acceleration events boost NIL
  const magnitude = accelStream?.processed_data?.magnitude || 0;
  if (magnitude > 10) {
    multiplier += 0.2;
  } else if (magnitude > 5) {
    multiplier += 0.1;
  }

  const currentNIL = baseNIL * multiplier;

  return {
    baseValue: baseNIL,
    currentValue: Math.round(currentNIL),
    change: ((currentNIL - baseNIL) / baseNIL) * 100,
    multiplier,
  };
}

// Generate broadcast capsule
function generateBroadcastCapsule(streams, sport) {
  const hrStream = streams.find((s) => s.stream_type === "heart_rate");
  const accelStream = streams.find((s) => s.stream_type === "acceleration");
  const forceStream = streams.find((s) => s.stream_type === "force");

  // Simplified capsule for broadcast overlay
  const bpm = hrStream?.processed_data?.bpm || 0;
  const zone = hrStream?.processed_data?.zone || "recovery";
  const magnitude = accelStream?.processed_data?.magnitude || 0;
  const force = forceStream?.processed_data?.newton || 0;

  // Glow ring
  let glowColor = "#F2F2F2";
  let glowBloom = 100;
  if (zone === "anaerobic") {
    glowColor = "#FFCC33";
    glowBloom = 200;
  } else if (zone === "vo2max") {
    glowColor = "#FFCC33";
    glowBloom = 150;
  }

  // Fatigue color
  let fatigueColor = "#3CFF7A"; // Green
  if (bpm > 180) {
    fatigueColor = "#FF3C3C"; // Red
  } else if (bpm > 160) {
    fatigueColor = "#FFD93C"; // Yellow
  }

  // Injury risk
  let injuryRiskHeight = 10;
  let injuryRiskColor = "#33FFF3";
  if (magnitude > 10 || force > 2000) {
    injuryRiskHeight = 60;
    injuryRiskColor = "#D90000";
  } else if (magnitude > 5 || force > 1000) {
    injuryRiskHeight = 40;
    injuryRiskColor = "#FF8C33";
  }

  return {
    glowRing: { color: glowColor, bloom: glowBloom },
    fatigueArc: { color: fatigueColor, zone },
    injuryRisk: { height: injuryRiskHeight, color: injuryRiskColor },
    timestamp: hrStream?.timestamp || new Date(),
  };
}

// Get tactical position
async function getTacticalPosition(athleteId, eventId) {
  // In production, fetch from spatial intelligence engine
  return {
    x: 0,
    y: 0,
    formation: "N/A",
    role: "N/A",
  };
}

// Calculate event-level metrics
function calculateEventMetrics(athletes, sport) {
  const avgHR = athletes
    .map((a) => a.biometric?.bpm || 0)
    .filter((bpm) => bpm > 0)
    .reduce((sum, bpm, _, arr) => sum + bpm / arr.length, 0);

  const highIntensityCount = athletes.filter(
    (a) => a.biometric?.zone === "anaerobic" || a.biometric?.zone === "vo2max",
  ).length;

  return {
    averageHeartRate: Math.round(avgHR),
    highIntensityAthletes: highIntensityCount,
    totalAthletes: athletes.length,
    gameIntensity: highIntensityCount / athletes.length,
  };
}

// Generate graphics suggestions
function generateGraphicsSuggestions(feed, sport) {
  const suggestions = [];

  // Check for NIL momentum spikes
  const nilSpikes = feed.athletes.filter((a) => a.nil?.change > 10);
  if (nilSpikes.length > 0) {
    suggestions.push({
      type: "nil_spike",
      priority: "high",
      athletes: nilSpikes.map((a) => a.athleteId),
      graphic: "NIL_VALUE_OVERLAY",
      message: `${nilSpikes[0].name}'s NIL value up ${nilSpikes[0].nil.change.toFixed(1)}%`,
    });
  }

  // Check for high injury risk
  const injuryRisk = feed.athletes.filter(
    (a) => a.capsule?.injuryRisk?.height > 50,
  );
  if (injuryRisk.length > 0) {
    suggestions.push({
      type: "injury_alert",
      priority: "critical",
      athletes: injuryRisk.map((a) => a.athleteId),
      graphic: "INJURY_RISK_INDICATOR",
      message: `High injury risk detected: ${injuryRisk[0].name}`,
    });
  }

  // Check for high-intensity moments
  const highIntensity = feed.athletes.filter(
    (a) => a.biometric?.zone === "anaerobic",
  );
  if (highIntensity.length > 3) {
    suggestions.push({
      type: "intensity_surge",
      priority: "medium",
      athletes: highIntensity.map((a) => a.athleteId),
      graphic: "INTENSITY_HEATMAP",
      message: "High-intensity surge detected across multiple athletes",
    });
  }

  return suggestions;
}

// Calculate feed quality
function calculateFeedQuality(streams) {
  if (streams.length === 0) return 0;

  const avgQuality =
    streams.reduce((sum, s) => sum + (s.data_quality_score || 0), 0) /
    streams.length;
  return Math.round(avgQuality * 100);
}
