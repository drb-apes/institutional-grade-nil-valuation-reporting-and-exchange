import sql from "@/app/api/utils/sql";

// Organization Profile Registry - Define all supported organization types
export const ORG_PROFILES = {
  youth_academy: {
    id: "youth_academy",
    name: "Youth Academy",
    tier: "grassroots",
    ageRange: { min: 8, max: 14 },
    nilRules: {
      allowSwaps: false,
      allowDirectPayments: false,
      allowStipends: true,
      maxStipendPerMonth: 0, // Educational support only
      requireParentalConsent: true,
      requireEducationalTrust: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: 12 },
      competitionFrequency: { max: 2, period: "month" },
      mandatoryEducation: true,
      healthScreeningRequired: true,
    },
    visibilityRules: {
      coach: ["performance_metrics", "health_data", "attendance"],
      parent: [
        "performance_metrics",
        "health_data",
        "attendance",
        "education_progress",
      ],
      agent: [],
      sponsor: [],
      fan: [],
    },
    marketPermissions: {
      canHoldSwaps: false,
      canFundPools: false,
      canEarnStipends: true,
      canTrade: false,
    },
  },

  high_school: {
    id: "high_school",
    name: "High School",
    tier: "prep",
    ageRange: { min: 14, max: 18 },
    nilRules: {
      allowSwaps: false,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: 500,
      requireParentalConsent: true,
      requireEducationalTrust: false,
      stateLawCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: 20 },
      competitionFrequency: { max: 3, period: "month" },
      mandatoryEducation: true,
      academicEligibilityRequired: true,
      healthScreeningRequired: true,
    },
    visibilityRules: {
      coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "academic_progress",
      ],
      parent: [
        "performance_metrics",
        "health_data",
        "attendance",
        "academic_progress",
        "nil_earnings",
      ],
      agent: ["performance_metrics"],
      sponsor: ["performance_metrics", "engagement_data"],
      scout: ["performance_metrics", "competition_data"],
      fan: ["basic_stats"],
    },
    marketPermissions: {
      canHoldSwaps: false,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: false,
    },
  },

  junior_college: {
    id: "junior_college",
    name: "Junior College",
    tier: "development",
    ageRange: { min: 18, max: 22 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: 2000,
      requireParentalConsent: false,
      njcaaCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: 30 },
      competitionFrequency: { max: 4, period: "month" },
      mandatoryEducation: true,
      academicEligibilityRequired: true,
      healthScreeningRequired: true,
    },
    visibilityRules: {
      coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "academic_progress",
        "nil_activity",
      ],
      athletic_director: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "compliance_data",
      ],
      agent: ["performance_metrics", "nil_valuation"],
      sponsor: ["performance_metrics", "engagement_data", "nil_opportunities"],
      scout: ["performance_metrics", "competition_data", "projection_data"],
      fan: ["basic_stats", "highlights"],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: 10000 },
    },
  },

  ncaa_d1: {
    id: "ncaa_d1",
    name: "NCAA Division I",
    tier: "collegiate_elite",
    ageRange: { min: 18, max: 23 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: null, // No cap, market-driven
      requireParentalConsent: false,
      ncaaCompliance: true,
      stateNilLawCompliance: true,
      schoolPolicyCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: 40 },
      competitionFrequency: { max: 6, period: "month" },
      mandatoryEducation: true,
      academicEligibilityRequired: true,
      healthScreeningRequired: true,
      substanceTestingRequired: true,
    },
    visibilityRules: {
      coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "academic_progress",
        "nil_activity",
        "recruiting_data",
      ],
      athletic_director: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "compliance_data",
        "financial_impact",
      ],
      compliance_officer: [
        "nil_activity",
        "compliance_data",
        "agent_relationships",
      ],
      agent: ["performance_metrics", "nil_valuation", "market_data"],
      sponsor: [
        "performance_metrics",
        "engagement_data",
        "nil_opportunities",
        "brand_fit",
      ],
      scout: [
        "performance_metrics",
        "competition_data",
        "projection_data",
        "draft_potential",
      ],
      fan: ["basic_stats", "highlights", "public_nil_deals"],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: 50000 },
    },
  },

  ncaa_d2: {
    id: "ncaa_d2",
    name: "NCAA Division II",
    tier: "collegiate_competitive",
    ageRange: { min: 18, max: 23 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: 5000,
      requireParentalConsent: false,
      ncaaCompliance: true,
      stateNilLawCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: 35 },
      competitionFrequency: { max: 5, period: "month" },
      mandatoryEducation: true,
      academicEligibilityRequired: true,
      healthScreeningRequired: true,
    },
    visibilityRules: {
      coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "academic_progress",
        "nil_activity",
      ],
      athletic_director: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "compliance_data",
      ],
      agent: ["performance_metrics", "nil_valuation"],
      sponsor: ["performance_metrics", "engagement_data", "nil_opportunities"],
      scout: ["performance_metrics", "competition_data"],
      fan: ["basic_stats", "highlights"],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: 25000 },
    },
  },

  semi_pro: {
    id: "semi_pro",
    name: "Semi-Professional",
    tier: "transition",
    ageRange: { min: 18, max: 35 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: null,
      requireParentalConsent: false,
      contractCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: 50 },
      competitionFrequency: { max: 8, period: "month" },
      mandatoryEducation: false,
      healthScreeningRequired: true,
      substanceTestingRequired: true,
    },
    visibilityRules: {
      coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "nil_activity",
        "contract_data",
      ],
      team_manager: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "financial_data",
      ],
      agent: [
        "performance_metrics",
        "nil_valuation",
        "market_data",
        "contract_opportunities",
      ],
      sponsor: [
        "performance_metrics",
        "engagement_data",
        "nil_opportunities",
        "brand_fit",
      ],
      scout: [
        "performance_metrics",
        "competition_data",
        "projection_data",
        "pro_potential",
      ],
      fan: ["basic_stats", "highlights", "public_deals"],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: 100000 },
    },
  },

  professional: {
    id: "professional",
    name: "Professional",
    tier: "elite",
    ageRange: { min: 18, max: 45 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: null,
      requireParentalConsent: false,
      leagueCompliance: true,
      unionCompliance: true,
      cbaCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: null }, // No limit
      competitionFrequency: { max: null }, // League-defined
      mandatoryEducation: false,
      healthScreeningRequired: true,
      substanceTestingRequired: true,
      injuryReportingRequired: true,
    },
    visibilityRules: {
      coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "nil_activity",
        "contract_data",
        "tactical_data",
      ],
      team_manager: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "financial_data",
        "contract_data",
      ],
      gm: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "financial_data",
        "contract_data",
        "trade_value",
      ],
      agent: [
        "performance_metrics",
        "nil_valuation",
        "market_data",
        "contract_opportunities",
        "endorsement_deals",
      ],
      sponsor: [
        "performance_metrics",
        "engagement_data",
        "nil_opportunities",
        "brand_fit",
        "media_value",
      ],
      scout: [
        "performance_metrics",
        "competition_data",
        "projection_data",
        "trade_analysis",
      ],
      fan: ["basic_stats", "highlights", "public_deals", "media_appearances"],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: null }, // Institutional-grade limits
    },
  },

  national_federation: {
    id: "national_federation",
    name: "National Federation",
    tier: "governing_body",
    ageRange: { min: 16, max: 40 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: null,
      requireParentalConsent: false,
      olympicCompliance: true,
      ifCompliance: true, // International Federation
      wadaCompliance: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: null },
      competitionFrequency: { max: null },
      mandatoryEducation: false,
      healthScreeningRequired: true,
      substanceTestingRequired: true,
      dualNationalityRules: true,
    },
    visibilityRules: {
      national_coach: [
        "performance_metrics",
        "health_data",
        "attendance",
        "nil_activity",
        "international_results",
      ],
      federation_director: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "financial_data",
        "funding_allocation",
      ],
      national_selector: [
        "performance_metrics",
        "competition_data",
        "ranking_data",
      ],
      agent: [
        "performance_metrics",
        "nil_valuation",
        "market_data",
        "sponsorship_opportunities",
      ],
      sponsor: [
        "performance_metrics",
        "engagement_data",
        "nil_opportunities",
        "brand_fit",
        "media_value",
      ],
      fan: [
        "basic_stats",
        "highlights",
        "international_rankings",
        "medal_count",
      ],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: null },
    },
  },

  multi_sport_coalition: {
    id: "multi_sport_coalition",
    name: "Multi-Sport Coalition",
    tier: "coalition",
    ageRange: { min: 14, max: 45 },
    nilRules: {
      allowSwaps: true,
      allowDirectPayments: true,
      allowStipends: true,
      maxStipendPerMonth: null,
      requireParentalConsent: false,
      coalitionGovernance: true,
      crossSportAgreements: true,
    },
    policyConstraints: {
      trainingHoursPerWeek: { max: null },
      competitionFrequency: { max: null },
      mandatoryEducation: false,
      healthScreeningRequired: true,
      substanceTestingRequired: true,
      multiSportEligibility: true,
    },
    visibilityRules: {
      coalition_director: [
        "performance_metrics",
        "health_data",
        "nil_activity",
        "financial_data",
        "cross_sport_insights",
      ],
      sport_coordinator: ["performance_metrics", "health_data", "nil_activity"],
      agent: [
        "performance_metrics",
        "nil_valuation",
        "market_data",
        "cross_sport_opportunities",
      ],
      sponsor: [
        "performance_metrics",
        "engagement_data",
        "nil_opportunities",
        "brand_fit",
        "multi_sport_reach",
      ],
      fan: ["basic_stats", "highlights", "coalition_rankings"],
    },
    marketPermissions: {
      canHoldSwaps: true,
      canFundPools: true,
      canEarnStipends: true,
      canTrade: true,
      tradingLimits: { maxPositionSize: null },
      crossSportTrading: true,
    },
  },
};

// GET: Retrieve organization profiles
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const orgId = searchParams.get("org_id");
  const tier = searchParams.get("tier");

  try {
    if (orgId) {
      const profile = ORG_PROFILES[orgId];
      if (!profile) {
        return Response.json(
          { error: "Organization profile not found" },
          { status: 404 },
        );
      }
      return Response.json({ profile });
    }

    if (tier) {
      const profiles = Object.values(ORG_PROFILES).filter(
        (p) => p.tier === tier,
      );
      return Response.json({ profiles });
    }

    // Return all profiles
    return Response.json({ profiles: Object.values(ORG_PROFILES) });
  } catch (error) {
    console.error("Error fetching organization profiles:", error);
    return Response.json(
      { error: "Failed to fetch organization profiles" },
      { status: 500 },
    );
  }
}

// POST: Validate organization context for a specific action
export async function POST(request) {
  try {
    const body = await request.json();
    const { org_id, action, athlete_age, user_role } = body;

    if (!org_id || !action) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const orgProfile = ORG_PROFILES[org_id];
    if (!orgProfile) {
      return Response.json(
        { error: "Invalid organization profile" },
        { status: 404 },
      );
    }

    // Age validation
    if (athlete_age) {
      if (
        athlete_age < orgProfile.ageRange.min ||
        athlete_age > orgProfile.ageRange.max
      ) {
        return Response.json({
          allowed: false,
          reason: `Athlete age ${athlete_age} is outside allowed range (${orgProfile.ageRange.min}-${orgProfile.ageRange.max})`,
        });
      }
    }

    // Action-specific validation
    const validationResult = {
      allowed: false,
      reason: "",
      constraints: {},
    };

    switch (action) {
      case "create_swap":
        validationResult.allowed =
          orgProfile.nilRules.allowSwaps &&
          orgProfile.marketPermissions.canHoldSwaps;
        validationResult.reason = validationResult.allowed
          ? "Swap creation allowed"
          : "Swaps not permitted for this organization";
        break;

      case "direct_payment":
        validationResult.allowed = orgProfile.nilRules.allowDirectPayments;
        validationResult.reason = validationResult.allowed
          ? "Direct payments allowed"
          : "Direct payments not permitted";
        break;

      case "fund_pool":
        validationResult.allowed = orgProfile.marketPermissions.canFundPools;
        validationResult.reason = validationResult.allowed
          ? "Pool funding allowed"
          : "Pool funding not permitted";
        break;

      case "trade":
        validationResult.allowed = orgProfile.marketPermissions.canTrade;
        validationResult.constraints =
          orgProfile.marketPermissions.tradingLimits || {};
        validationResult.reason = validationResult.allowed
          ? "Trading allowed"
          : "Trading not permitted";
        break;

      case "view_data":
        if (user_role && orgProfile.visibilityRules[user_role]) {
          validationResult.allowed = true;
          validationResult.constraints = {
            allowedDataTypes: orgProfile.visibilityRules[user_role],
          };
          validationResult.reason = "Data access granted based on role";
        } else {
          validationResult.allowed = false;
          validationResult.reason = "No data access permissions for this role";
        }
        break;

      default:
        return Response.json({ error: "Unknown action type" }, { status: 400 });
    }

    return Response.json({
      org_id,
      org_name: orgProfile.name,
      org_tier: orgProfile.tier,
      validation: validationResult,
    });
  } catch (error) {
    console.error("Error validating organization context:", error);
    return Response.json(
      { error: "Failed to validate organization context" },
      { status: 500 },
    );
  }
}
