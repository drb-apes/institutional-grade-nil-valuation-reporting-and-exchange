import sql from "@/app/api/utils/sql";

// Sport Profile Registry - Define all supported sports
export const SPORT_PROFILES = {
  wrestling: {
    id: "wrestling",
    name: "Wrestling / Goalwrestling",
    category: "combat_sports",
    featureMap: {
      explosiveness: ["takedown_speed", "escape_velocity", "reaction_time"],
      consistency: ["control_time_variance", "technique_repeatability"],
      loadFatigue: ["match_intensity", "recovery_rate"],
      decisionQuality: ["position_selection", "counter_timing"],
      recoveryVelocity: ["rest_period_effectiveness", "next_session_readiness"],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "avg(takedown_speed, escape_velocity) * reaction_time_factor",
        weight: 0.3,
      },
      consistency: {
        formula: "1 - std_dev(control_time) / mean(control_time)",
        weight: 0.25,
      },
      loadFatigue: {
        formula: "match_intensity * (1 / recovery_rate)",
        weight: 0.2,
      },
      decisionQuality: {
        formula: "position_selection_accuracy * counter_timing_score",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "next_session_readiness / rest_period_hours",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.25,
        loadFatigue: 0.2,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "weighted_average", // team performance = weighted avg of roster PPI
      lpi_aggregation: "percentile_ranking", // league index = percentile across all athletes
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 45 },
      development: { ppi_min: 45, ppi_max: 65 },
      pro: { ppi_min: 65, ppi_max: 85 },
      elite: { ppi_min: 85, ppi_max: 100 },
    },
  },

  basketball: {
    id: "basketball",
    name: "Basketball",
    category: "tactical_sports",
    featureMap: {
      explosiveness: ["vertical_jump", "sprint_speed", "acceleration"],
      consistency: [
        "shooting_variance",
        "spacing_adherence",
        "effort_consistency",
      ],
      loadFatigue: ["minutes_played", "contact_load", "recovery_quality"],
      decisionQuality: [
        "assist_to_turnover",
        "shot_selection",
        "defensive_positioning",
      ],
      recoveryVelocity: [
        "hr_recovery_rate",
        "sleep_quality",
        "next_game_readiness",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula:
          "avg(vertical_jump_percentile, sprint_speed_percentile, acceleration_index)",
        weight: 0.25,
      },
      consistency: {
        formula: "shooting_consistency * spacing_score * effort_index",
        weight: 0.3,
      },
      loadFatigue: {
        formula: "minutes_played * contact_load * (1 / recovery_quality)",
        weight: 0.2,
      },
      decisionQuality: {
        formula: "assist_to_turnover * shot_selection_score * defensive_iq",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "hr_recovery_rate * sleep_quality * next_game_readiness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.25,
        consistency: 0.3,
        loadFatigue: 0.2,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "synergy_adjusted", // team chemistry + roster balance adjustments
      lpi_aggregation: "competitive_balance",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 40 },
      development: { ppi_min: 40, ppi_max: 60 },
      pro: { ppi_min: 60, ppi_max: 80 },
      elite: { ppi_min: 80, ppi_max: 100 },
    },
  },

  tennis: {
    id: "tennis",
    name: "Tennis",
    category: "racket_sports",
    featureMap: {
      explosiveness: ["serve_speed", "first_step_quickness", "shot_power"],
      consistency: ["unforced_error_rate", "shot_placement_variance", "rhythm"],
      loadFatigue: ["match_length_impact", "surface_adaptation", "stamina"],
      decisionQuality: [
        "point_construction",
        "shot_selection",
        "pressure_performance",
      ],
      recoveryVelocity: ["between_point_recovery", "between_match_recovery"],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "serve_speed_index * first_step_score * shot_power_rating",
        weight: 0.3,
      },
      consistency: {
        formula:
          "(1 - unforced_error_rate) * shot_placement_consistency * rhythm_score",
        weight: 0.3,
      },
      loadFatigue: {
        formula:
          "stamina_index * (1 / match_length_fatigue) * surface_adaptation",
        weight: 0.15,
      },
      decisionQuality: {
        formula: "point_construction_iq * shot_selection * pressure_index",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "between_point_hr_recovery * between_match_readiness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.3,
        loadFatigue: 0.15,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "doubles_synergy", // for doubles teams
      lpi_aggregation: "elo_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 40 },
      development: { ppi_min: 40, ppi_max: 60 },
      pro: { ppi_min: 60, ppi_max: 80 },
      elite: { ppi_min: 80, ppi_max: 100 },
    },
  },

  pickleball: {
    id: "pickleball",
    name: "Pickleball",
    category: "racket_sports",
    featureMap: {
      explosiveness: ["spike_speed", "dink_power", "lateral_quickness"],
      consistency: ["shot_error_rate", "placement_accuracy", "rally_endurance"],
      loadFatigue: ["game_volume", "recovery_between_games"],
      decisionQuality: [
        "third_shot_selection",
        "kitchen_positioning",
        "pressure_handling",
      ],
      recoveryVelocity: ["hr_normalization", "session_to_session_readiness"],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "spike_speed * dink_power * lateral_quickness_score",
        weight: 0.3,
      },
      consistency: {
        formula: "(1 - shot_error_rate) * placement_accuracy * rally_endurance",
        weight: 0.3,
      },
      loadFatigue: {
        formula: "game_volume * (1 / recovery_quality)",
        weight: 0.15,
      },
      decisionQuality: {
        formula: "third_shot_iq * kitchen_positioning_score * pressure_index",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "hr_normalization * session_readiness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.3,
        loadFatigue: 0.15,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "doubles_synergy",
      lpi_aggregation: "tournament_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 35 },
      development: { ppi_min: 35, ppi_max: 55 },
      pro: { ppi_min: 55, ppi_max: 75 },
      elite: { ppi_min: 75, ppi_max: 100 },
    },
  },

  american_football: {
    id: "american_football",
    name: "American Football",
    category: "tactical_sports",
    featureMap: {
      explosiveness: ["forty_yard_dash", "vertical_jump", "burst_velocity"],
      consistency: [
        "route_precision",
        "blocking_technique_repeatability",
        "effort_variance",
      ],
      loadFatigue: ["contact_volume", "snap_count", "recovery_efficiency"],
      decisionQuality: ["pre_snap_reads", "route_adjustments", "tackle_angles"],
      recoveryVelocity: [
        "concussion_protocol_clearance",
        "injury_recovery_rate",
        "practice_participation",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "forty_time_inverse * vertical_jump * burst_velocity_index",
        weight: 0.3,
      },
      consistency: {
        formula:
          "route_precision * technique_repeatability * (1 - effort_variance)",
        weight: 0.25,
      },
      loadFatigue: {
        formula: "contact_volume * snap_count * (1 / recovery_efficiency)",
        weight: 0.2,
      },
      decisionQuality: {
        formula: "pre_snap_iq * route_adjustment_score * tackle_efficiency",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula:
          "protocol_clearance_speed * injury_recovery_index * practice_participation",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.25,
        loadFatigue: 0.2,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "position_group_weighted",
      lpi_aggregation: "conference_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 45 },
      development: { ppi_min: 45, ppi_max: 65 },
      pro: { ppi_min: 65, ppi_max: 85 },
      elite: { ppi_min: 85, ppi_max: 100 },
    },
  },

  rugby: {
    id: "rugby",
    name: "Rugby",
    category: "tactical_sports",
    featureMap: {
      explosiveness: ["sprint_speed", "tackle_power", "ruck_speed"],
      consistency: [
        "passing_accuracy",
        "tackle_success_rate",
        "positional_discipline",
      ],
      loadFatigue: ["minutes_played", "contact_events", "recovery_quality"],
      decisionQuality: ["kick_selection", "support_running", "defensive_reads"],
      recoveryVelocity: [
        "hr_recovery",
        "soreness_index",
        "next_match_readiness",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "sprint_speed * tackle_power * ruck_speed_index",
        weight: 0.3,
      },
      consistency: {
        formula:
          "passing_accuracy * tackle_success_rate * positional_discipline",
        weight: 0.25,
      },
      loadFatigue: {
        formula: "minutes_played * contact_events * (1 / recovery_quality)",
        weight: 0.2,
      },
      decisionQuality: {
        formula: "kick_selection_iq * support_running_score * defensive_reads",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "hr_recovery * (1 / soreness_index) * next_match_readiness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.25,
        loadFatigue: 0.2,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "forward_back_balanced",
      lpi_aggregation: "union_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 40 },
      development: { ppi_min: 40, ppi_max: 60 },
      pro: { ppi_min: 60, ppi_max: 80 },
      elite: { ppi_min: 80, ppi_max: 100 },
    },
  },

  soccer: {
    id: "soccer",
    name: "Soccer / Football",
    category: "tactical_sports",
    featureMap: {
      explosiveness: ["sprint_speed", "acceleration", "jump_height"],
      consistency: [
        "passing_accuracy",
        "first_touch_quality",
        "positioning_discipline",
      ],
      loadFatigue: [
        "distance_covered",
        "high_intensity_runs",
        "recovery_quality",
      ],
      decisionQuality: [
        "pass_selection",
        "pressing_triggers",
        "shot_selection",
      ],
      recoveryVelocity: [
        "hr_recovery_rate",
        "muscle_soreness",
        "next_session_readiness",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "sprint_speed * acceleration * jump_height_index",
        weight: 0.25,
      },
      consistency: {
        formula:
          "passing_accuracy * first_touch_score * positioning_discipline",
        weight: 0.3,
      },
      loadFatigue: {
        formula:
          "distance_covered * high_intensity_runs * (1 / recovery_quality)",
        weight: 0.2,
      },
      decisionQuality: {
        formula: "pass_selection_iq * pressing_trigger_score * shot_selection",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "hr_recovery * (1 / muscle_soreness) * next_session_readiness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.25,
        consistency: 0.3,
        loadFatigue: 0.2,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "tactical_cohesion_weighted",
      lpi_aggregation: "league_coefficient_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 40 },
      development: { ppi_min: 40, ppi_max: 60 },
      pro: { ppi_min: 60, ppi_max: 80 },
      elite: { ppi_min: 80, ppi_max: 100 },
    },
  },

  track_field: {
    id: "track_field",
    name: "Track & Field",
    category: "individual_performance",
    featureMap: {
      explosiveness: [
        "block_start_power",
        "acceleration_curve",
        "max_velocity",
      ],
      consistency: [
        "split_variance",
        "technique_repeatability",
        "race_execution",
      ],
      loadFatigue: ["training_volume", "race_frequency", "recovery_metrics"],
      decisionQuality: [
        "pacing_strategy",
        "lane_positioning",
        "competition_awareness",
      ],
      recoveryVelocity: [
        "lactate_clearance",
        "muscle_recovery",
        "next_workout_readiness",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "block_start_power * acceleration_curve * max_velocity_index",
        weight: 0.35,
      },
      consistency: {
        formula:
          "(1 - split_variance) * technique_repeatability * race_execution",
        weight: 0.3,
      },
      loadFatigue: {
        formula: "training_volume * race_frequency * (1 / recovery_metrics)",
        weight: 0.15,
      },
      decisionQuality: {
        formula:
          "pacing_strategy_score * lane_positioning * competition_awareness",
        weight: 0.1,
      },
      recoveryVelocity: {
        formula: "lactate_clearance * muscle_recovery * next_workout_readiness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.35,
        consistency: 0.3,
        loadFatigue: 0.15,
        decisionQuality: 0.1,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "relay_team_synergy",
      lpi_aggregation: "world_ranking_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 50 },
      development: { ppi_min: 50, ppi_max: 70 },
      pro: { ppi_min: 70, ppi_max: 88 },
      elite: { ppi_min: 88, ppi_max: 100 },
    },
  },

  esports: {
    id: "esports",
    name: "Esports",
    category: "digital_performance",
    featureMap: {
      explosiveness: [
        "reaction_time",
        "click_speed",
        "ability_execution_speed",
      ],
      consistency: [
        "accuracy_variance",
        "decision_repeatability",
        "tilt_resistance",
      ],
      loadFatigue: ["session_duration", "game_volume", "mental_fatigue"],
      decisionQuality: [
        "map_awareness",
        "resource_management",
        "teamplay_coordination",
      ],
      recoveryVelocity: [
        "focus_restoration",
        "sleep_quality",
        "next_session_sharpness",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula: "(1 / reaction_time) * click_speed * ability_execution_speed",
        weight: 0.3,
      },
      consistency: {
        formula:
          "(1 - accuracy_variance) * decision_repeatability * tilt_resistance",
        weight: 0.3,
      },
      loadFatigue: {
        formula: "session_duration * game_volume * mental_fatigue_index",
        weight: 0.15,
      },
      decisionQuality: {
        formula: "map_awareness * resource_management * teamplay_coordination",
        weight: 0.15,
      },
      recoveryVelocity: {
        formula: "focus_restoration * sleep_quality * next_session_sharpness",
        weight: 0.1,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.3,
        loadFatigue: 0.15,
        decisionQuality: 0.15,
        recoveryVelocity: 0.1,
      },
      tpi_aggregation: "role_balanced_weighted",
      lpi_aggregation: "elo_tournament_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 40 },
      development: { ppi_min: 40, ppi_max: 60 },
      pro: { ppi_min: 60, ppi_max: 80 },
      elite: { ppi_min: 80, ppi_max: 100 },
    },
  },

  motorsport: {
    id: "motorsport",
    name: "Motorsport",
    category: "high_performance_technical",
    featureMap: {
      explosiveness: [
        "reaction_time",
        "micro_movement_precision",
        "throttle_modulation",
      ],
      consistency: [
        "lap_time_variance",
        "braking_point_repeatability",
        "line_adherence",
      ],
      loadFatigue: [
        "g_load_tolerance",
        "session_length",
        "heat_stress_management",
      ],
      decisionQuality: [
        "overtaking_judgment",
        "tire_management",
        "fuel_strategy",
      ],
      recoveryVelocity: [
        "neck_strength_recovery",
        "focus_restoration",
        "next_session_readiness",
      ],
    },
    derivedMetrics: {
      explosiveness: {
        formula:
          "(1 / reaction_time) * micro_movement_precision * throttle_modulation",
        weight: 0.3,
      },
      consistency: {
        formula:
          "(1 - lap_time_variance) * braking_point_repeatability * line_adherence",
        weight: 0.35,
      },
      loadFatigue: {
        formula: "g_load_tolerance * session_length * heat_stress_management",
        weight: 0.15,
      },
      decisionQuality: {
        formula: "overtaking_judgment * tire_management * fuel_strategy",
        weight: 0.12,
      },
      recoveryVelocity: {
        formula:
          "neck_strength_recovery * focus_restoration * next_session_readiness",
        weight: 0.08,
      },
    },
    scoringSchema: {
      ppi_weights: {
        explosiveness: 0.3,
        consistency: 0.35,
        loadFatigue: 0.15,
        decisionQuality: 0.12,
        recoveryVelocity: 0.08,
      },
      tpi_aggregation: "constructor_team_weighted",
      lpi_aggregation: "championship_points_adjusted",
    },
    tierBoundaries: {
      amateur: { ppi_min: 0, ppi_max: 45 },
      development: { ppi_min: 45, ppi_max: 68 },
      pro: { ppi_min: 68, ppi_max: 88 },
      elite: { ppi_min: 88, ppi_max: 100 },
    },
  },
};

// GET: Retrieve sport profiles
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sportId = searchParams.get("sport_id");
  const category = searchParams.get("category");

  try {
    if (sportId) {
      const profile = SPORT_PROFILES[sportId];
      if (!profile) {
        return Response.json(
          { error: "Sport profile not found" },
          { status: 404 },
        );
      }
      return Response.json({ profile });
    }

    if (category) {
      const profiles = Object.values(SPORT_PROFILES).filter(
        (p) => p.category === category,
      );
      return Response.json({ profiles });
    }

    // Return all profiles
    return Response.json({ profiles: Object.values(SPORT_PROFILES) });
  } catch (error) {
    console.error("Error fetching sport profiles:", error);
    return Response.json(
      { error: "Failed to fetch sport profiles" },
      { status: 500 },
    );
  }
}

// POST: Create or update custom sport profile (future extensibility)
export async function POST(request) {
  try {
    const body = await request.json();
    const { sport_id, profile_data } = body;

    // In the future, this could store custom sport profiles in the database
    // For now, we'll just validate and return the profile

    if (!sport_id || !profile_data) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Validate profile structure
    const requiredFields = [
      "name",
      "category",
      "featureMap",
      "derivedMetrics",
      "scoringSchema",
      "tierBoundaries",
    ];
    for (const field of requiredFields) {
      if (!profile_data[field]) {
        return Response.json(
          { error: `Missing required field: ${field}` },
          { status: 400 },
        );
      }
    }

    return Response.json({
      message: "Sport profile validated successfully",
      sport_id,
      profile: profile_data,
    });
  } catch (error) {
    console.error("Error creating sport profile:", error);
    return Response.json(
      { error: "Failed to create sport profile" },
      { status: 500 },
    );
  }
}
