import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      athlete_name,
      athlete_id,
      organization,
      contact_email,
      contact_name,
      data_types_requested,
      use_case,
      notes,
      urgency_level,
    } = await request.json();

    if (
      !athlete_name ||
      !organization ||
      !contact_email ||
      !data_types_requested
    ) {
      return Response.json(
        {
          error:
            "Missing required fields: athlete_name, organization, contact_email, data_types_requested",
        },
        { status: 400 },
      );
    }

    // Validate data types
    const validDataTypes = [
      "motion_scan_summary",
      "bvi_score",
      "tactical_index",
      "recovery_index",
      "heatmap_overlay",
      "scout_notes",
      "qr_flyer",
      "contributor_credit_log",
    ];

    const requestedTypes = Array.isArray(data_types_requested)
      ? data_types_requested
      : [data_types_requested];
    const invalidTypes = requestedTypes.filter(
      (type) => !validDataTypes.includes(type),
    );

    if (invalidTypes.length > 0) {
      return Response.json(
        { error: `Invalid data types requested: ${invalidTypes.join(", ")}` },
        { status: 400 },
      );
    }

    // Calculate pricing based on requested data types and athlete tier
    let basePrice = 0;
    let athleteProfile = null;

    if (athlete_id) {
      const profiles = await sql`
        SELECT * FROM user_profiles 
        WHERE id = ${athlete_id} AND user_type = 'athlete'
      `;
      athleteProfile = profiles[0] || null;
    }

    // Pricing logic
    const pricingTiers = {
      motion_scan_summary: { base: 25, elite_multiplier: 1.5 },
      bvi_score: { base: 35, elite_multiplier: 2.0 },
      tactical_index: { base: 35, elite_multiplier: 2.0 },
      recovery_index: { base: 30, elite_multiplier: 1.8 },
      heatmap_overlay: { base: 50, elite_multiplier: 2.5 },
      scout_notes: { base: 20, elite_multiplier: 1.3 },
      qr_flyer: { base: 15, elite_multiplier: 1.2 },
      contributor_credit_log: { base: 40, elite_multiplier: 2.2 },
    };

    const isEliteAthlete = athleteProfile?.tier_level >= 3;

    for (const type of requestedTypes) {
      const pricing = pricingTiers[type];
      const price = isEliteAthlete
        ? pricing.base * pricing.elite_multiplier
        : pricing.base;
      basePrice += price;
    }

    // Apply bulk discount for multiple data types
    if (requestedTypes.length >= 5) {
      basePrice *= 0.85; // 15% discount
    } else if (requestedTypes.length >= 3) {
      basePrice *= 0.9; // 10% discount
    }

    // Generate request ID
    const requestId = `VAL_${Date.now()}_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    // Store valuation request
    const valuationRequest = await sql`
      INSERT INTO athlete_referrals (
        rep_name,
        rep_title,
        rep_organization,
        rep_email,
        rep_type,
        athlete_name,
        athlete_age,
        athlete_sport,
        athlete_level,
        standout_traits,
        milestone_potential,
        training_schedule,
        preferred_milestones,
        athlete_profile_id,
        referral_status
      ) VALUES (
        ${contact_name || "Data Request"},
        ${"Valuation Request"},
        ${organization},
        ${contact_email},
        ${"validator_dao"},
        ${athlete_name},
        ${99}, -- Placeholder for valuation requests
        ${"data_request"},
        ${"professional"},
        ${`Valuation Request - Types: ${requestedTypes.join(", ")}`},
        ${use_case || "Data Analysis"},
        ${"On-demand"},
        ${JSON.stringify({
          request_id: requestId,
          data_types: requestedTypes,
          pricing: {
            base_price: Math.round(basePrice),
            is_elite: isEliteAthlete,
            discount_applied: requestedTypes.length >= 3,
          },
          urgency: urgency_level || "standard",
          notes: notes || "",
        })},
        ${athlete_id || null},
        ${"pending_review"}
      )
      RETURNING *
    `;

    // Log the request for tracking
    // Get or create user profile to get correct athlete_id
    let userProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      // Create profile if it doesn't exist
      userProfile = await sql`
        INSERT INTO user_profiles (user_id, user_type, tier_level)
        VALUES (${session.user.id}, 'fan', 1)
        RETURNING id
      `;
    }

    const requestorAthleteId = userProfile[0].id;

    await sql`
      INSERT INTO motion_scans (
        athlete_id,
        scan_data,
        ai_score,
        motion_type,
        metadata,
        verification_status
      ) VALUES (
        ${requestorAthleteId},
        ${JSON.stringify({
          request_type: "valuation_data_request",
          athlete_target: athlete_name,
          organization: organization,
          data_types: requestedTypes,
        })},
        ${1.0},
        ${"valuation_request"},
        ${JSON.stringify({
          request_id: requestId,
          contact_email: contact_email,
          use_case: use_case,
          pricing_quote: Math.round(basePrice),
          created_by: session.user.id,
        })},
        ${"pending"}
      )
    `;

    // Generate email notification content
    const emailContent = {
      to: "dashawn@bimanalytics.com",
      subject: `Valuation Access Request - ${athlete_name} (${requestId})`,
      body: `
📊 BIM Valuation Access Request

Request ID: ${requestId}
Submitted: ${new Date().toISOString()}

=== CONTACT INFORMATION ===
Organization: ${organization}
Contact Name: ${contact_name || "Not provided"}
Contact Email: ${contact_email}

=== ATHLETE INFORMATION ===
Athlete Name: ${athlete_name}
Athlete ID: ${athlete_id || "Not provided"}
Elite Status: ${isEliteAthlete ? "Yes (Tier " + athleteProfile?.tier_level + ")" : "Standard"}

=== DATA REQUEST ===
Use Case: ${use_case || "Not specified"}
Urgency: ${urgency_level || "Standard"}
Data Types Requested:
${requestedTypes.map((type) => `- ${type.replace(/_/g, " ").toUpperCase()}`).join("\n")}

=== PRICING QUOTE ===
Base Price: $${Math.round(basePrice)}
Elite Multiplier: ${isEliteAthlete ? "Applied" : "Not applicable"}
Bulk Discount: ${requestedTypes.length >= 3 ? "Applied" : "Not applicable"}

=== ADDITIONAL NOTES ===
${notes || "None provided"}

=== NEXT STEPS ===
1. Verify athlete consent for data release
2. Confirm pricing and delivery format
3. Process payment and deliver valuation packet

This request is pending review and athlete approval.
      `,
    };

    return Response.json({
      success: true,
      request_id: requestId,
      pricing_quote: Math.round(basePrice),
      data_types_included: requestedTypes,
      athlete_tier: athleteProfile?.tier_level || 1,
      is_elite_pricing: isEliteAthlete,
      bulk_discount_applied: requestedTypes.length >= 3,
      estimated_delivery:
        urgency_level === "urgent" ? "24-48 hours" : "3-5 business days",
      status: "pending_review",
      next_steps: [
        "Athlete consent verification",
        "Pricing confirmation",
        "Payment processing",
        "Data package delivery",
      ],
      email_notification: emailContent,
      message: `Valuation request ${requestId} submitted successfully. You will receive confirmation within 24 hours.`,
    });
  } catch (error) {
    console.error("Valuation request error:", error);
    return Response.json(
      { error: "Failed to submit valuation request" },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const requestId = url.searchParams.get("request_id");
    const organization = url.searchParams.get("organization");

    let query = sql`
      SELECT 
        ar.*,
        up.tier_level,
        up.user_type
      FROM athlete_referrals ar
      LEFT JOIN user_profiles up ON ar.athlete_profile_id = up.id
      WHERE ar.rep_type = 'validator_dao'
      AND ar.athlete_sport = 'data_request'
    `;

    if (requestId) {
      const requests = await sql`
        ${query}
        AND ar.preferred_milestones->>'request_id' = ${requestId}
      `;

      if (requests.length === 0) {
        return Response.json({ error: "Request not found" }, { status: 404 });
      }

      return Response.json({
        success: true,
        request: requests[0],
      });
    }

    if (organization) {
      const requests = await sql`
        ${query}
        AND ar.rep_organization = ${organization}
        ORDER BY ar.created_at DESC
        LIMIT 10
      `;

      return Response.json({
        success: true,
        requests: requests,
      });
    }

    // Return recent requests for authenticated user's organization
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json({
        success: true,
        requests: [],
      });
    }

    const allRequests = await sql`
      ${query}
      ORDER BY ar.created_at DESC
      LIMIT 20
    `;

    return Response.json({
      success: true,
      requests: allRequests,
    });
  } catch (error) {
    console.error("Valuation request retrieval error:", error);
    return Response.json(
      { error: "Failed to retrieve valuation requests" },
      { status: 500 },
    );
  }
}
