import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Position Management Strategy Execution Engine
 *
 * Executes exit strategies for NIL-backed performance positions
 * Supports 10 methods: Adaptive trailing, AI weighted, milestone-based, etc.
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Rate limiting
    const rateLimit = checkRateLimit(`position-strategy-${session.user.id}`, {
      maxRequests: 30,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      positionId: { required: true, type: "string" },
      strategyMethod: { required: true, type: "string" },
      athleteId: { required: true, type: "number" },
      currentMetrics: { required: true, type: "object" },
      positionDetails: { required: false, type: "object" },
      strategyParams: { required: false, type: "object" },
    });

    const {
      positionId,
      strategyMethod,
      athleteId,
      currentMetrics,
      positionDetails = {},
      strategyParams = {},
    } = body;

    // Validate strategy method
    const validStrategies = [
      "adaptive_trailing_stop",
      "pattern_only_exit",
      "hybrid_ai_weighted",
      "volatility_event_driven",
      "operator_override",
      "milestone_partial_exit",
      "randomized_exit",
      "max_risk_all_in",
      "biometric_inverse_martingale",
      "distributed_multi_manager",
    ];

    if (!validStrategies.includes(strategyMethod)) {
      return createSecureResponse(
        { error: "Invalid strategy method" },
        { status: 400 },
      );
    }

    // Execute strategy
    const strategyResult = await executeStrategy(
      strategyMethod,
      positionId,
      athleteId,
      currentMetrics,
      positionDetails,
      strategyParams,
    );

    // Log strategy execution
    await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        user_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${positionId},
        'strategy_engine',
        ${session.user.id},
        'strategy_execution',
        ${JSON.stringify({
          strategy_method: strategyMethod,
          athlete_id: athleteId,
          decision: strategyResult.decision,
          exit_percentage: strategyResult.exitPercentage,
          reasoning: strategyResult.reasoning,
          metrics_snapshot: currentMetrics,
        })},
        NOW(),
        NOW()
      )
    `;

    return createSecureResponse({
      success: true,
      positionId,
      strategy: strategyMethod,
      decision: strategyResult.decision,
      exitPercentage: strategyResult.exitPercentage,
      reasoning: strategyResult.reasoning,
      signalStrength: strategyResult.signalStrength,
      riskLevel: strategyResult.riskLevel,
      recommendations: strategyResult.recommendations,
      metadata: strategyResult.metadata,
    });
  } catch (error) {
    console.error("Strategy execution error:", error);
    return createSecureResponse(
      { error: "Failed to execute strategy" },
      { status: 500 },
    );
  }
}

// GET: Retrieve strategy execution history
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const positionId = searchParams.get("positionId");
    const strategyMethod = searchParams.get("strategyMethod");
    const limit = parseInt(searchParams.get("limit") || "50");

    let query = sql`
      SELECT * FROM mesh_sync_data
      WHERE sync_type = 'strategy_execution'
        AND user_id = ${session.user.id}
    `;

    if (positionId) {
      query = sql`${query} AND mesh_id = ${positionId}`;
    }

    if (strategyMethod) {
      query = sql`${query} AND sync_data->>'strategy_method' = ${strategyMethod}`;
    }

    query = sql`${query} ORDER BY sync_timestamp DESC LIMIT ${limit}`;

    const executionHistory = await query;

    // Calculate strategy performance
    const performanceStats = calculateStrategyPerformance(executionHistory);

    return createSecureResponse({
      success: true,
      executionHistory,
      performanceStats,
    });
  } catch (error) {
    console.error("Strategy history fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch strategy history" },
      { status: 500 },
    );
  }
}

// Strategy execution logic
async function executeStrategy(
  strategyMethod,
  positionId,
  athleteId,
  currentMetrics,
  positionDetails,
  strategyParams,
) {
  switch (strategyMethod) {
    case "adaptive_trailing_stop":
      return executeAdaptiveTrailingStop(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "pattern_only_exit":
      return executePatternOnlyExit(currentMetrics, positionDetails);

    case "hybrid_ai_weighted":
      return executeHybridAIWeighted(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "volatility_event_driven":
      return executeVolatilityEventDriven(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "operator_override":
      return executeOperatorOverride(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "milestone_partial_exit":
      return executeMilestonePartialExit(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "randomized_exit":
      return executeRandomizedExit(currentMetrics, positionDetails);

    case "max_risk_all_in":
      return executeMaxRiskAllIn(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "biometric_inverse_martingale":
      return executeBiometricInverseMartingale(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    case "distributed_multi_manager":
      return executeDistributedMultiManager(
        currentMetrics,
        positionDetails,
        strategyParams,
      );

    default:
      throw new Error("Unknown strategy method");
  }
}

// Method 1: Adaptive Trailing Stop
function executeAdaptiveTrailingStop(metrics, position, params) {
  const {
    heartRate = 0,
    fatigueIndex = 0,
    recoveryScore = 100,
    performanceVolatility = 0,
  } = metrics;

  const { entryPrice = 100, currentPrice = 100, peakPrice = 100 } = position;

  // Calculate biometric drawdown signal
  const biometricDrawdown = calculateBiometricDrawdown(
    heartRate,
    fatigueIndex,
    recoveryScore,
  );

  // Dynamic trailing threshold (tightens as drawdown increases)
  const baseTrailPercent = params.baseTrailPercent || 5;
  const adaptiveTrailPercent = baseTrailPercent * (1 + biometricDrawdown * 0.5);

  // Price-based trailing stop
  const trailDistance = ((peakPrice - currentPrice) / peakPrice) * 100;

  const shouldExit =
    trailDistance >= adaptiveTrailPercent || biometricDrawdown > 0.7;

  return {
    decision: shouldExit ? "exit" : "hold",
    exitPercentage: shouldExit ? 100 : 0,
    reasoning: shouldExit
      ? `Biometric drawdown at ${(biometricDrawdown * 100).toFixed(1)}%, trailing stop triggered at ${adaptiveTrailPercent.toFixed(1)}%`
      : `Position healthy, trailing at ${trailDistance.toFixed(1)}% (threshold: ${adaptiveTrailPercent.toFixed(1)}%)`,
    signalStrength: biometricDrawdown,
    riskLevel:
      biometricDrawdown > 0.5
        ? "high"
        : biometricDrawdown > 0.3
          ? "medium"
          : "low",
    recommendations: [
      shouldExit
        ? "Exit immediately to lock gains"
        : "Monitor fatigue signals closely",
      `Current drawdown: ${(biometricDrawdown * 100).toFixed(1)}%`,
    ],
    metadata: {
      biometricDrawdown,
      adaptiveTrailPercent,
      trailDistance,
      peakPrice,
      currentPrice,
    },
  };
}

// Method 2: Pattern-Only Exit
function executePatternOnlyExit(metrics, position) {
  const { currentPrice = 100, priceHistory = [] } = position;

  // Simple candlestick pattern detection
  const patterns = detectCandlestickPatterns(priceHistory);

  const bearishPatterns = [
    "evening_star",
    "bearish_engulfing",
    "shooting_star",
  ];
  const hasBearishSignal = patterns.some((p) => bearishPatterns.includes(p));

  return {
    decision: hasBearishSignal ? "exit" : "hold",
    exitPercentage: hasBearishSignal ? 100 : 0,
    reasoning: hasBearishSignal
      ? `Bearish pattern detected: ${patterns.join(", ")}`
      : "No bearish exit signals in price action",
    signalStrength: hasBearishSignal ? 0.8 : 0.2,
    riskLevel: hasBearishSignal ? "high" : "low",
    recommendations: [
      hasBearishSignal
        ? "Technical reversal pattern detected"
        : "Price pattern neutral",
    ],
    metadata: {
      patterns,
      currentPrice,
    },
  };
}

// Method 3: Hybrid AI Weighted
function executeHybridAIWeighted(metrics, position, params) {
  const {
    heartRate = 0,
    fatigueIndex = 0,
    recoveryScore = 100,
    performanceVolatility = 0,
  } = metrics;

  const { priceHistory = [], currentPrice = 100 } = position;

  // AI-learned weights (in production, these would come from ML model)
  const weights = params.aiWeights || {
    biometric: 0.4,
    price: 0.3,
    volatility: 0.2,
    context: 0.1,
  };

  // Calculate individual signals
  const biometricSignal = calculateBiometricDrawdown(
    heartRate,
    fatigueIndex,
    recoveryScore,
  );
  const priceSignal = calculatePriceSignal(priceHistory, currentPrice);
  const volatilitySignal =
    performanceVolatility > 50 ? 0.8 : performanceVolatility / 100;
  const contextSignal = 0.5; // Placeholder for session context

  // Weighted blend
  const compositeSignal =
    biometricSignal * weights.biometric +
    priceSignal * weights.price +
    volatilitySignal * weights.volatility +
    contextSignal * weights.context;

  const exitThreshold = params.exitThreshold || 0.6;
  const shouldExit = compositeSignal >= exitThreshold;

  return {
    decision: shouldExit ? "exit" : "hold",
    exitPercentage: shouldExit ? 100 : 0,
    reasoning: `Composite AI signal: ${(compositeSignal * 100).toFixed(1)}% (threshold: ${(exitThreshold * 100).toFixed(1)}%)`,
    signalStrength: compositeSignal,
    riskLevel:
      compositeSignal > 0.7 ? "high" : compositeSignal > 0.4 ? "medium" : "low",
    recommendations: [
      `Biometric contribution: ${(biometricSignal * weights.biometric * 100).toFixed(1)}%`,
      `Price contribution: ${(priceSignal * weights.price * 100).toFixed(1)}%`,
      shouldExit ? "AI recommends exit" : "AI recommends hold",
    ],
    metadata: {
      compositeSignal,
      weights,
      signals: {
        biometricSignal,
        priceSignal,
        volatilitySignal,
        contextSignal,
      },
    },
  };
}

// Method 4: Volatility Event-Driven
function executeVolatilityEventDriven(metrics, position, params) {
  const { performanceVolatility = 0, heartRateVolatility = 0 } = metrics;

  const volatilityThreshold = params.volatilityThreshold || 60;
  const isVolatilitySpike =
    performanceVolatility > volatilityThreshold || heartRateVolatility > 30;

  return {
    decision: isVolatilitySpike ? "exit" : "hold",
    exitPercentage: isVolatilitySpike ? 100 : 0,
    reasoning: isVolatilitySpike
      ? `Volatility spike detected: Performance ${performanceVolatility.toFixed(1)}%, HR ${heartRateVolatility.toFixed(1)}%`
      : "Volatility within acceptable range",
    signalStrength: Math.max(
      performanceVolatility / 100,
      heartRateVolatility / 50,
    ),
    riskLevel: isVolatilitySpike ? "high" : "low",
    recommendations: [
      isVolatilitySpike ? "Exit to avoid whipsaw" : "Volatility stable",
    ],
    metadata: {
      performanceVolatility,
      heartRateVolatility,
      volatilityThreshold,
    },
  };
}

// Method 5: Operator Override
function executeOperatorOverride(metrics, position, params) {
  const { operatorDecision = "ai", operatorReasoning = "" } = params;

  if (operatorDecision === "ai") {
    // Defer to AI recommendation
    return executeHybridAIWeighted(metrics, position, params);
  }

  const shouldExit = operatorDecision === "exit";

  return {
    decision: operatorDecision,
    exitPercentage: shouldExit ? params.exitPercentage || 100 : 0,
    reasoning: `Operator override: ${operatorReasoning || operatorDecision}`,
    signalStrength: 1.0,
    riskLevel: "operator_discretion",
    recommendations: ["Operator has taken manual control", operatorReasoning],
    metadata: {
      operatorDecision,
      operatorReasoning,
    },
  };
}

// Method 6: Milestone-Based Partial Exit
function executeMilestonePartialExit(metrics, position, params) {
  const {
    heartRate = 0,
    fatigueIndex = 0,
    recoveryScore = 100,
    distanceCovered = 0,
    forcePeaks = [],
  } = metrics;

  const milestones = params.milestones || [
    { trigger: "force_threshold", value: 500, exitPercent: 25 },
    { trigger: "distance_threshold", value: 5000, exitPercent: 25 },
    { trigger: "recovery_drop", value: 60, exitPercent: 25 },
    { trigger: "fatigue_spike", value: 70, exitPercent: 25 },
  ];

  const exitedMilestones = position.exitedMilestones || [];
  let totalExitPercentage = 0;
  const triggeredMilestones = [];

  milestones.forEach((milestone, idx) => {
    if (exitedMilestones.includes(idx)) return;

    let triggered = false;

    if (
      milestone.trigger === "force_threshold" &&
      Math.max(...forcePeaks, 0) >= milestone.value
    ) {
      triggered = true;
    } else if (
      milestone.trigger === "distance_threshold" &&
      distanceCovered >= milestone.value
    ) {
      triggered = true;
    } else if (
      milestone.trigger === "recovery_drop" &&
      recoveryScore <= milestone.value
    ) {
      triggered = true;
    } else if (
      milestone.trigger === "fatigue_spike" &&
      fatigueIndex >= milestone.value
    ) {
      triggered = true;
    }

    if (triggered) {
      totalExitPercentage += milestone.exitPercent;
      triggeredMilestones.push(milestone);
    }
  });

  return {
    decision: totalExitPercentage > 0 ? "partial_exit" : "hold",
    exitPercentage: totalExitPercentage,
    reasoning:
      totalExitPercentage > 0
        ? `Milestones triggered: ${triggeredMilestones.map((m) => m.trigger).join(", ")}`
        : "No milestones reached",
    signalStrength: totalExitPercentage / 100,
    riskLevel: totalExitPercentage > 50 ? "medium" : "low",
    recommendations: [
      `Exiting ${totalExitPercentage}% of position`,
      `Remaining milestones: ${milestones.length - triggeredMilestones.length}`,
    ],
    metadata: {
      triggeredMilestones,
      totalExitPercentage,
      remainingPosition: 100 - totalExitPercentage,
    },
  };
}

// Method 7: Randomized Exit (Baseline)
function executeRandomizedExit(metrics, position) {
  const randomSignal = Math.random();
  const shouldExit = randomSignal > 0.7;

  return {
    decision: shouldExit ? "exit" : "hold",
    exitPercentage: shouldExit ? 100 : 0,
    reasoning: `Random baseline: ${(randomSignal * 100).toFixed(1)}%`,
    signalStrength: randomSignal,
    riskLevel: "baseline",
    recommendations: ["⚠️ This is a baseline method - not for production use"],
    metadata: {
      randomSignal,
    },
  };
}

// Method 8: Max Risk/All-In (Long Shot)
function executeMaxRiskAllIn(metrics, position, params) {
  const { fatigueIndex = 0, heartRate = 0 } = metrics;

  const maxFatigueThreshold = params.maxFatigueThreshold || 95;
  const maxHRThreshold = params.maxHRThreshold || 210;

  const atExtremeLimit =
    fatigueIndex >= maxFatigueThreshold || heartRate >= maxHRThreshold;

  return {
    decision: atExtremeLimit ? "exit" : "hold",
    exitPercentage: atExtremeLimit ? 100 : 0,
    reasoning: atExtremeLimit
      ? `⚠️ EXTREME LIMITS REACHED - Fatigue: ${fatigueIndex}, HR: ${heartRate}`
      : "Waiting for extreme limits (high risk strategy)",
    signalStrength: atExtremeLimit ? 1.0 : 0,
    riskLevel: "extreme",
    recommendations: [
      "⚠️ WARNING: This strategy exposes to catastrophic drawdowns",
      "⚠️ NOT RECOMMENDED for real trading",
      atExtremeLimit
        ? "EXIT IMMEDIATELY"
        : "Holding despite intermediate signals",
    ],
    metadata: {
      fatigueIndex,
      heartRate,
      maxFatigueThreshold,
      maxHRThreshold,
    },
  };
}

// Method 9: Biometric Inverse Martingale (Long Shot)
function executeBiometricInverseMartingale(metrics, position, params) {
  const { fatigueIndex = 0, recoveryScore = 100 } = metrics;
  const { consecutivePositiveSignals = 0 } = position;

  const isPositiveSignal = fatigueIndex < 30 && recoveryScore > 80;
  const isNegativeSignal = fatigueIndex > 60 || recoveryScore < 50;

  let decision = "hold";
  let reasoning = "";

  if (isNegativeSignal) {
    decision = "exit";
    reasoning = "⚠️ First negative signal - Inverse Martingale exit triggered";
  } else if (isPositiveSignal) {
    reasoning = `Positive signal - would increase risk (consecutive: ${consecutivePositiveSignals})`;
  }

  return {
    decision,
    exitPercentage: decision === "exit" ? 100 : 0,
    reasoning,
    signalStrength: isNegativeSignal ? 1.0 : 0,
    riskLevel: "extreme",
    recommendations: [
      "⚠️ WARNING: Inverse Martingale is statistically dangerous",
      "⚠️ Rapid risk compounding can lead to outsized losses",
      "⚠️ NOT RECOMMENDED for real trading",
    ],
    metadata: {
      isPositiveSignal,
      isNegativeSignal,
      consecutivePositiveSignals,
    },
  };
}

// Method 10: Distributed Multi-Manager
function executeDistributedMultiManager(metrics, position, params) {
  // Run multiple strategies in parallel
  const strategies = [
    executeAdaptiveTrailingStop(metrics, position, params),
    executeHybridAIWeighted(metrics, position, params),
    executeMilestonePartialExit(metrics, position, params),
  ];

  // Aggregate decisions (majority vote)
  const exitVotes = strategies.filter(
    (s) => s.decision === "exit" || s.decision === "partial_exit",
  ).length;
  const avgExitPercentage =
    strategies.reduce((sum, s) => sum + s.exitPercentage, 0) /
    strategies.length;

  const shouldExit = exitVotes >= 2;

  return {
    decision: shouldExit ? "exit" : "hold",
    exitPercentage: shouldExit ? avgExitPercentage : 0,
    reasoning: `Multi-manager consensus: ${exitVotes}/3 strategies recommend exit`,
    signalStrength: exitVotes / 3,
    riskLevel: exitVotes >= 2 ? "medium" : "low",
    recommendations: strategies.map(
      (s, idx) => `Strategy ${idx + 1}: ${s.reasoning}`,
    ),
    metadata: {
      exitVotes,
      avgExitPercentage,
      individualResults: strategies,
    },
  };
}

// Utility functions
function calculateBiometricDrawdown(heartRate, fatigueIndex, recoveryScore) {
  // Normalize metrics to 0-1 scale (higher = more drawdown)
  const hrDrawdown = Math.max(0, Math.min(1, (heartRate - 100) / 100));
  const fatigueDrawdown = fatigueIndex / 100;
  const recoveryDrawdown = (100 - recoveryScore) / 100;

  return hrDrawdown * 0.3 + fatigueDrawdown * 0.4 + recoveryDrawdown * 0.3;
}

function calculatePriceSignal(priceHistory, currentPrice) {
  if (priceHistory.length < 3) return 0;

  const recentPrices = priceHistory.slice(-10);
  const priceChange = (currentPrice - recentPrices[0]) / recentPrices[0];

  // Negative price change = bearish signal
  return priceChange < -0.05 ? 0.8 : priceChange < 0 ? 0.5 : 0.2;
}

function detectCandlestickPatterns(priceHistory) {
  if (priceHistory.length < 3) return [];

  const patterns = [];
  const recent = priceHistory.slice(-3);

  // Simple pattern detection
  if (recent[2] < recent[1] && recent[1] < recent[0]) {
    patterns.push("bearish_trend");
  }

  if (recent[2] < recent[0] && recent[1] > recent[0] && recent[1] > recent[2]) {
    patterns.push("shooting_star");
  }

  return patterns;
}

function calculateStrategyPerformance(executionHistory) {
  if (executionHistory.length === 0) {
    return {
      totalExecutions: 0,
      exitRate: 0,
      avgSignalStrength: 0,
    };
  }

  const exits = executionHistory.filter(
    (e) => e.sync_data?.decision === "exit",
  ).length;
  const avgSignalStrength =
    executionHistory.reduce(
      (sum, e) => sum + (e.sync_data?.signal_strength || 0),
      0,
    ) / executionHistory.length;

  return {
    totalExecutions: executionHistory.length,
    exitRate: (exits / executionHistory.length) * 100,
    avgSignalStrength,
  };
}
