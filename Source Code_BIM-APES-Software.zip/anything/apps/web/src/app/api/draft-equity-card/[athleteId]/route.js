import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { athleteId } = params;

    // Get athlete profile with related data
    const athleteProfile = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.user_type,
        up.tier_level,
        up.total_contributions,
        up.total_earnings,
        up.reputation_score,
        au.name as athlete_name,
        au.email
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId} AND up.user_type = 'athlete'
    `;

    if (athleteProfile.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteProfile[0];

    // Get latest asset simulation for valuation data
    const latestSimulation = await sql`
      SELECT 
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors,
        created_at
      FROM asset_simulations
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 1
    `;

    // Get latest motion scan for biometric data
    const latestMotionScan = await sql`
      SELECT 
        scan_data,
        ai_score,
        motion_type,
        verification_status,
        created_at
      FROM motion_scans
      WHERE athlete_id = ${athleteId} AND verification_status = 'verified'
      ORDER BY created_at DESC
      LIMIT 1
    `;

    // Get active milestones for performance context
    const activeMilestones = await sql`
      SELECT 
        title,
        target_metrics,
        current_progress,
        milestone_status,
        reward_pool
      FROM milestones
      WHERE athlete_id = ${athleteId} AND milestone_status = 'active'
      ORDER BY created_at DESC
      LIMIT 3
    `;

    // Get contributor credits from referrals (if athlete was referred)
    const contributorCredits = await sql`
      SELECT 
        rep_name,
        rep_title,
        rep_type,
        rep_organization,
        created_at
      FROM athlete_referrals
      WHERE athlete_profile_id = ${athleteId} AND referral_status = 'approved'
      ORDER BY created_at DESC
    `;

    // Extract sport from latest motion scan or simulation data
    const sport =
      latestMotionScan[0]?.motion_type ||
      latestSimulation[0]?.valuation_factors?.sport_type ||
      "general";

    // Generate sport-specific biometric milestones
    const generateSportSpecificMetrics = (sport, scanData, simData) => {
      const baseMetrics =
        scanData?.simulation_data || simData?.simulation_data || {};

      switch (sport.toLowerCase()) {
        case "wrestling":
          return {
            weight_cut_score: `${Math.round((baseMetrics.recovery_index || 0.75) * 100)}/100`,
            takedown_speed: `${((baseMetrics.tactical_efficiency || 0.7) * 2.5).toFixed(1)}s`,
            endurance_index: `${Math.round((baseMetrics.session_consistency || 0.7) * 100)}/100`,
          };
        case "american_football":
          return {
            forty_yard_dash: `${(4.8 - (baseMetrics.spike_score || 0.7) * 0.8).toFixed(2)}s`,
            bench_press: `${Math.round(225 + (baseMetrics.bvi || 0.7) * 100)} lbs`,
            vertical_leap: `${Math.round(28 + (baseMetrics.spike_score || 0.7) * 12)}"`,
          };
        case "tennis":
        case "pickleball":
          return {
            serve_speed: `${Math.round(90 + (baseMetrics.spike_score || 0.7) * 40)} mph`,
            court_coverage: `${Math.round((baseMetrics.tactical_efficiency || 0.7) * 100)}/100`,
            spike_score: `${Math.round((baseMetrics.spike_score || 0.7) * 100)}/100`,
          };
        case "basketball":
          return {
            vertical_leap: `${Math.round(24 + (baseMetrics.spike_score || 0.7) * 16)}"`,
            court_vision: `${Math.round((baseMetrics.tactical_efficiency || 0.7) * 100)}/100`,
            tactical_efficiency: `${Math.round((baseMetrics.tactical_efficiency || 0.7) * 100)}/100`,
          };
        default:
          return {
            overall_score: `${Math.round((baseMetrics.overall_score || 0.75) * 100)}/100`,
            performance_index: `${Math.round((baseMetrics.bvi || 0.7) * 100)}/100`,
            consistency: `${Math.round((baseMetrics.session_consistency || 0.7) * 100)}/100`,
          };
      }
    };

    // Generate mock draft data based on tier and performance
    const generateDraftProjection = (tierLevel, assetValue, sport) => {
      const tierMultipliers = {
        1: { round: 7, pick: 220, contract: 750000, bonus: 10000 },
        2: { round: 5, pick: 150, contract: 950000, bonus: 25000 },
        3: { round: 3, pick: 85, contract: 2500000, bonus: 100000 },
        4: { round: 2, pick: 45, contract: 8500000, bonus: 500000 },
        5: { round: 1, pick: 15, contract: 25000000, bonus: 2000000 },
      };

      const base =
        tierMultipliers[Math.min(tierLevel, 5)] || tierMultipliers[1];
      const performanceBoost = (assetValue || 75) / 100;

      return {
        draft_round: base.round,
        draft_pick: Math.max(1, Math.round(base.pick * (2 - performanceBoost))),
        contract_value: `$${(base.contract * performanceBoost).toLocaleString()} over 4 years`,
        signing_bonus: `$${(base.bonus * performanceBoost).toLocaleString()}`,
        team_name: getRandomTeam(sport),
      };
    };

    const getRandomTeam = (sport) => {
      const teams = {
        american_football: [
          "Chiefs",
          "Cowboys",
          "Patriots",
          "Packers",
          "Steelers",
        ],
        basketball: ["Lakers", "Warriors", "Celtics", "Heat", "Spurs"],
        baseball: ["Yankees", "Dodgers", "Red Sox", "Giants", "Cardinals"],
        hockey: ["Penguins", "Bruins", "Rangers", "Blackhawks", "Kings"],
        default: [
          "Team Alpha",
          "Team Beta",
          "Team Gamma",
          "Team Delta",
          "Team Omega",
        ],
      };

      const teamList = teams[sport.toLowerCase()] || teams.default;
      return teamList[Math.floor(Math.random() * teamList.length)];
    };

    const getPosition = (sport) => {
      const positions = {
        wrestling: [
          "Heavyweight",
          "Light Heavyweight",
          "Middleweight",
          "Welterweight",
        ],
        american_football: [
          "QB",
          "RB",
          "WR",
          "TE",
          "OL",
          "DE",
          "LB",
          "CB",
          "S",
        ],
        basketball: ["PG", "SG", "SF", "PF", "C"],
        tennis: ["Singles", "Doubles"],
        pickleball: ["Singles", "Doubles"],
        default: ["Athlete"],
      };

      const positionList = positions[sport.toLowerCase()] || positions.default;
      return positionList[Math.floor(Math.random() * positionList.length)];
    };

    // Calculate team fit score based on performance consistency
    const calculateTeamFitScore = (simData, tierLevel) => {
      const consistency = simData?.session_consistency || 0.7;
      const tacticalEfficiency = simData?.tactical_efficiency || 0.7;
      const baseScore = (consistency + tacticalEfficiency) / 2;
      const tierBonus = tierLevel * 5;
      return Math.min(100, Math.round(baseScore * 85 + tierBonus));
    };

    // Prepare card data
    const simulationData = latestSimulation[0]?.simulation_data || {};
    const draftProjection = generateDraftProjection(
      athlete.tier_level,
      latestSimulation[0]?.asset_value,
      sport,
    );

    const cardData = {
      coalition_id: `COA-${athlete.id.toString().padStart(6, "0")}`,
      athlete_name: athlete.athlete_name,
      sport: sport,
      position: getPosition(sport),
      draft_round: draftProjection.draft_round,
      draft_pick: draftProjection.draft_pick,
      team_name: draftProjection.team_name,
      contract_value: draftProjection.contract_value,
      signing_bonus: draftProjection.signing_bonus,
      team_fit_score: calculateTeamFitScore(simulationData, athlete.tier_level),
      coalition_valuation: `$${(latestSimulation[0]?.asset_value * 10000 || 750000).toLocaleString()}`,
      biometric_index: Math.round(simulationData.overall_score || 75),
      biometric_milestones: generateSportSpecificMetrics(
        sport,
        latestMotionScan[0]?.scan_data,
        simulationData,
      ),
      contributor_credit: contributorCredits.map((credit) => ({
        name: credit.rep_name,
        role: credit.rep_title,
        impact_percentage: Math.round(25 + Math.random() * 50), // Simulated impact percentage
      })),
      draft_class: `${new Date().getFullYear()} Coalition Draft`,
      coalition_role:
        athlete.tier_level >= 3 ? "Elite Prospect" : "Rising Talent",
      summit_status: athlete.tier_level >= 3 ? "active" : "pending",
      privacy_status: "gated", // Default privacy setting
      last_updated: new Date().toISOString(),
    };

    return Response.json(cardData);
  } catch (error) {
    console.error("Draft Equity Card generation error:", error);
    return Response.json(
      {
        error: "Failed to generate Draft Equity Card",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

export async function PATCH(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { athleteId } = params;
    const { privacy_status } = await request.json();

    // Verify user owns this athlete profile or has admin access
    const athleteProfile = await sql`
      SELECT user_id FROM user_profiles WHERE id = ${athleteId}
    `;

    if (athleteProfile.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    if (athleteProfile[0].user_id !== session.user.id) {
      return Response.json(
        { error: "Not authorized to update this profile" },
        { status: 403 },
      );
    }

    // For now, we'll store privacy status in the user_profiles table
    // In a full implementation, you might have a separate table for card settings
    await sql`
      UPDATE user_profiles 
      SET updated_at = CURRENT_TIMESTAMP
      WHERE id = ${athleteId}
    `;

    return Response.json({
      success: true,
      privacy_status,
      message: "Privacy settings updated",
    });
  } catch (error) {
    console.error("Privacy update error:", error);
    return Response.json(
      {
        error: "Failed to update privacy settings",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
