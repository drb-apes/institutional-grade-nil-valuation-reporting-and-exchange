import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { athleteId } = params;

    // Get card data (reuse the logic from the main route)
    const cardResponse = await fetch(
      `${process.env.NEXTAUTH_URL}/api/draft-equity-card/${athleteId}`,
      {
        headers: {
          Cookie: request.headers.get("Cookie") || "",
        },
      },
    );

    if (!cardResponse.ok) {
      return Response.json(
        { error: "Failed to fetch card data" },
        { status: 500 },
      );
    }

    const cardData = await cardResponse.json();

    // Generate PDF content (simple HTML that can be converted to PDF)
    const pdfContent = generatePDFContent(cardData);

    // For now, return HTML content
    // In a production app, you'd use a library like Puppeteer or jsPDF
    return new Response(pdfContent, {
      headers: {
        "Content-Type": "text/html",
        "Content-Disposition": `attachment; filename="${cardData.athlete_name.replace(" ", "_")}_Draft_Equity_Card.html"`,
      },
    });
  } catch (error) {
    console.error("PDF generation error:", error);
    return Response.json(
      {
        error: "Failed to generate PDF",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function generatePDFContent(cardData) {
  const sport = cardData.sport.toUpperCase();

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>${cardData.athlete_name} - Draft Equity Card</title>
      <style>
        body {
          font-family: 'Arial', sans-serif;
          margin: 0;
          padding: 20px;
          background: linear-gradient(135deg, #1e293b, #334155);
          color: white;
          min-height: 100vh;
        }
        .card {
          max-width: 600px;
          margin: 0 auto;
          background: linear-gradient(135deg, #1e293b, #0f172a);
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
        }
        .header {
          background: linear-gradient(90deg, #7c3aed, #2563eb);
          padding: 24px;
          text-align: center;
        }
        .header h1 {
          margin: 0;
          font-size: 24px;
          font-weight: bold;
        }
        .coalition-id {
          font-size: 12px;
          opacity: 0.8;
          margin-top: 8px;
        }
        .section {
          padding: 20px;
          border-bottom: 1px solid #334155;
        }
        .section:last-child {
          border-bottom: none;
        }
        .section-title {
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 12px;
          color: #a855f7;
          display: flex;
          align-items: center;
        }
        .athlete-name {
          font-size: 28px;
          font-weight: bold;
          margin-bottom: 16px;
          text-align: center;
        }
        .grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }
        .metric-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        .metric-label {
          opacity: 0.7;
        }
        .metric-value {
          font-weight: bold;
        }
        .accent {
          color: #a855f7;
        }
        .status-badge {
          display: inline-block;
          padding: 4px 12px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: bold;
        }
        .status-active {
          background: #10b981;
          color: white;
        }
        .status-pending {
          background: #f59e0b;
          color: black;
        }
        .biometric-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 6px;
        }
        .contributor-list {
          display: grid;
          grid-template-columns: 1fr;
          gap: 4px;
        }
        .footer {
          text-align: center;
          font-size: 12px;
          opacity: 0.6;
          padding: 16px;
        }
      </style>
    </head>
    <body>
      <div class="card">
        <!-- Header -->
        <div class="header">
          <h1>🏆 DRAFT EQUITY CARD</h1>
          <div class="coalition-id">Coalition ID: ${cardData.coalition_id}</div>
        </div>

        <!-- Athlete Info -->
        <div class="section">
          <div class="athlete-name">${cardData.athlete_name}</div>
          <div class="grid">
            <div><span class="metric-label">Sport:</span> ${sport}</div>
            <div><span class="metric-label">Position:</span> ${cardData.position}</div>
            <div><span class="metric-label">Draft Pick:</span> Round ${cardData.draft_round}, Pick ${cardData.draft_pick}</div>
            <div><span class="metric-label">Team:</span> ${cardData.team_name}</div>
          </div>
        </div>

        <!-- Valuation Summary -->
        <div class="section">
          <div class="section-title">⭐ Valuation Summary</div>
          <div class="metric-row">
            <span class="metric-label">Contract Value:</span>
            <span class="metric-value">${cardData.contract_value}</span>
          </div>
          <div class="metric-row">
            <span class="metric-label">Signing Bonus:</span>
            <span class="metric-value">${cardData.signing_bonus}</span>
          </div>
          <div class="metric-row">
            <span class="metric-label">Team Fit Score:</span>
            <span class="metric-value accent">${cardData.team_fit_score}/100</span>
          </div>
          <div class="metric-row">
            <span class="metric-label">Coalition Valuation:</span>
            <span class="metric-value accent">${cardData.coalition_valuation}</span>
          </div>
        </div>

        <!-- Biometric Index -->
        <div class="section">
          <div class="section-title">🛡️ Biometric Index: <span class="accent">${cardData.biometric_index}</span></div>
          <div class="biometric-grid">
            ${Object.entries(cardData.biometric_milestones)
              .map(
                ([key, value]) => `
              <div class="metric-row">
                <span class="metric-label">${key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}:</span>
                <span class="metric-value">${value}</span>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>

        <!-- Contributor Credit -->
        ${
          cardData.contributor_credit.length > 0
            ? `
        <div class="section">
          <div class="section-title">👥 Contributor Credit</div>
          <div class="contributor-list">
            ${cardData.contributor_credit
              .map(
                (contributor) => `
              <div class="metric-row">
                <span>${contributor.role}: ${contributor.name}</span>
                <span class="accent">(${contributor.impact_percentage}%)</span>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
        `
            : ""
        }

        <!-- Summit Badge -->
        <div class="section">
          <div class="metric-row">
            <div>
              <div class="section-title">Summit Badge</div>
              <div style="font-size: 14px; opacity: 0.7;">${cardData.draft_class} • ${cardData.coalition_role}</div>
            </div>
            <div>
              <span class="status-badge ${cardData.summit_status === "active" ? "status-active" : "status-pending"}">
                ${cardData.summit_status.toUpperCase()}
              </span>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div class="footer">
          Privacy: Gated • Coalition Verified • Generated ${new Date().toLocaleDateString()}
        </div>
      </div>
    </body>
    </html>
  `;
}
