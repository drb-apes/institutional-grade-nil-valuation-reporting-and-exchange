import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

const SPORT_TIER_BRANDING = {
  elite_basketball: {
    name: "Elite Basketball",
    colors: { primary: "#B8860B", secondary: "#1D2B3D", accent: "#FFD700" },
    icon: "🏀",
  },
  elite_gridiron: {
    name: "Elite Gridiron",
    colors: { primary: "#059669", secondary: "#1D2B3D", accent: "#10B981" },
    icon: "🏈",
  },
  combat_performance: {
    name: "Combat Performance",
    colors: { primary: "#DC2626", secondary: "#1F2937", accent: "#EF4444" },
    icon: "🥊",
  },
  collegiate_advancement: {
    name: "Collegiate Advancement",
    colors: { primary: "#7C3AED", secondary: "#1E40AF", accent: "#8B5CF6" },
    icon: "🎓",
  },
  federation_performance: {
    name: "Federation Performance",
    colors: { primary: "#F59E0B", secondary: "#9333EA", accent: "#FB923C" },
    icon: "🏅",
  },
};

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      card_data,
      simulation_data,
      athlete_name,
      format = "pdf",
      privacy_mode = "gated",
    } = await request.json();

    // Validate required data
    if (!card_data || !simulation_data || !athlete_name) {
      return Response.json(
        { error: "Missing required card data" },
        { status: 400 },
      );
    }

    // Generate unique card ID and store in database
    const cardId = `BIM-${simulation_data.sport_tier.toUpperCase()}-${Date.now().toString().slice(-6)}`;

    const cardRecord = {
      card_id: cardId,
      athlete_name,
      sport_tier: simulation_data.sport_tier,
      card_data: JSON.stringify(card_data),
      simulation_data: JSON.stringify(simulation_data),
      privacy_mode,
      created_by: session.user.id,
      created_at: new Date().toISOString(),
    };

    // Store card in database
    await sql`
      INSERT INTO draft_equity_cards (
        card_id,
        athlete_name,
        sport_tier,
        card_data,
        simulation_data,
        privacy_mode,
        created_by,
        created_at
      ) VALUES (
        ${cardRecord.card_id},
        ${cardRecord.athlete_name},
        ${cardRecord.sport_tier},
        ${cardRecord.card_data},
        ${cardRecord.simulation_data},
        ${cardRecord.privacy_mode},
        ${cardRecord.created_by},
        ${cardRecord.created_at}
      )
    `;

    if (format === "pdf") {
      // Generate PDF
      const pdfContent = await generatePDF(
        card_data,
        simulation_data,
        athlete_name,
      );

      return new Response(pdfContent, {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `attachment; filename="${athlete_name.replace(/\s+/g, "_")}_Draft_Equity_Card.pdf"`,
        },
      });
    } else if (format === "json") {
      // Return JSON export
      const exportData = {
        card_id: cardId,
        athlete_name,
        sport_tier: simulation_data.sport_tier,
        card_data,
        simulation_data,
        export_timestamp: new Date().toISOString(),
        coalition_verified: true,
      };

      return new Response(JSON.stringify(exportData, null, 2), {
        headers: {
          "Content-Type": "application/json",
          "Content-Disposition": `attachment; filename="${athlete_name.replace(/\s+/g, "_")}_Draft_Equity_Data.json"`,
        },
      });
    } else {
      return Response.json({
        success: true,
        card_id: cardId,
        message: "Card generated and stored successfully",
      });
    }
  } catch (error) {
    console.error("Card generation error:", error);
    return Response.json(
      { error: "Card generation failed", details: error.message },
      { status: 500 },
    );
  }
}

async function generatePDF(cardData, simulationData, athleteName) {
  // Create HTML template for PDF generation
  const sportTier = simulationData.sport_tier;
  const branding = SPORT_TIER_BRANDING[sportTier];

  const htmlTemplate = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>${athleteName} - Draft Equity Valuation Card</title>
      <style>
        body {
          font-family: 'Arial', sans-serif;
          margin: 0;
          padding: 20px;
          background: #ffffff;
          color: #333;
        }
        
        .card-container {
          max-width: 800px;
          margin: 0 auto;
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.1);
          overflow: hidden;
        }
        
        .header {
          background: linear-gradient(135deg, ${branding.colors.primary}, ${branding.colors.accent});
          color: white;
          padding: 30px;
          text-align: center;
        }
        
        .header h1 {
          margin: 0;
          font-size: 32px;
          font-weight: bold;
        }
        
        .header .sport-tier {
          font-size: 18px;
          opacity: 0.9;
          margin-top: 8px;
        }
        
        .header .card-id {
          background: rgba(255,255,255,0.2);
          display: inline-block;
          padding: 8px 16px;
          border-radius: 8px;
          margin-top: 16px;
          font-weight: bold;
        }
        
        .section {
          padding: 24px 30px;
          border-bottom: 1px solid #e5e7eb;
        }
        
        .section h2 {
          color: ${branding.colors.primary};
          font-size: 20px;
          margin: 0 0 16px 0;
          display: flex;
          align-items: center;
        }
        
        .section h2::before {
          content: "${branding.icon}";
          margin-right: 8px;
          font-size: 24px;
        }
        
        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
          margin-bottom: 16px;
        }
        
        .metric-card {
          background: #f9fafb;
          padding: 16px;
          border-radius: 8px;
          border-left: 4px solid ${branding.colors.primary};
        }
        
        .metric-label {
          font-size: 12px;
          color: #6b7280;
          margin-bottom: 4px;
          text-transform: uppercase;
          font-weight: bold;
        }
        
        .metric-value {
          font-size: 18px;
          font-weight: bold;
          color: #1f2937;
        }
        
        .coalition-value {
          background: linear-gradient(135deg, ${branding.colors.primary}, ${branding.colors.accent});
          color: white;
          border: none;
        }
        
        .coalition-value .metric-label {
          color: rgba(255,255,255,0.8);
        }
        
        .coalition-value .metric-value {
          color: white;
          font-size: 24px;
        }
        
        .insights-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }
        
        .insight-column h3 {
          font-size: 14px;
          font-weight: bold;
          margin: 0 0 12px 0;
          text-transform: uppercase;
        }
        
        .insight-column ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        
        .insight-column li {
          font-size: 12px;
          margin-bottom: 6px;
          padding-left: 16px;
          position: relative;
        }
        
        .insight-column li::before {
          position: absolute;
          left: 0;
          top: 0;
        }
        
        .strengths li::before { content: "✓"; color: #10b981; }
        .improvements li::before { content: "⚡"; color: #f59e0b; }
        .recommendations li::before { content: "💡"; color: #3b82f6; }
        
        .strengths h3 { color: #10b981; }
        .improvements h3 { color: #f59e0b; }
        .recommendations h3 { color: #3b82f6; }
        
        .contributor-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 16px;
        }
        
        .contributor-table th,
        .contributor-table td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #e5e7eb;
        }
        
        .contributor-table th {
          background: #f9fafb;
          font-weight: bold;
          color: #374151;
          font-size: 12px;
          text-transform: uppercase;
        }
        
        .contributor-table td {
          font-size: 14px;
        }
        
        .consent-verified::before {
          content: "✓";
          color: #10b981;
          font-weight: bold;
        }
        
        .consent-pending::before {
          content: "⏳";
          color: #f59e0b;
        }
        
        .footer {
          background: #f9fafb;
          padding: 20px 30px;
          text-align: center;
          color: #6b7280;
          font-size: 12px;
        }
        
        .footer .timestamp {
          margin-bottom: 8px;
        }
        
        .footer .verification {
          color: ${branding.colors.primary};
          font-weight: bold;
        }
        
        @media print {
          body { margin: 0; padding: 0; }
          .card-container { box-shadow: none; }
        }
      </style>
    </head>
    <body>
      <div class="card-container">
        <!-- Header -->
        <div class="header">
          <h1>${athleteName}</h1>
          <div class="sport-tier">${branding.name}</div>
          <div class="card-id">Coalition ID: ${cardData.header.valuation_id}</div>
        </div>
        
        <!-- Valuation Summary -->
        <div class="section">
          <h2>Valuation Summary</h2>
          <div class="metrics-grid">
            <div class="metric-card">
              <div class="metric-label">Selection Tier</div>
              <div class="metric-value">${cardData.valuation_summary.selection_tier}</div>
            </div>
            <div class="metric-card">
              <div class="metric-label">Team Fit Score</div>
              <div class="metric-value">${cardData.valuation_summary.team_fit_score}</div>
            </div>
            <div class="metric-card">
              <div class="metric-label">Biometric Index</div>
              <div class="metric-value">${cardData.valuation_summary.biometric_boost}</div>
            </div>
            <div class="metric-card">
              <div class="metric-label">Projected Contract</div>
              <div class="metric-value">${cardData.valuation_summary.projected_contract}</div>
            </div>
            <div class="metric-card coalition-value">
              <div class="metric-label">Coalition Asset Value</div>
              <div class="metric-value">${cardData.valuation_summary.coalition_asset_value}</div>
            </div>
            <div class="metric-card">
              <div class="metric-label">Pick Tier Grade</div>
              <div class="metric-value">${cardData.simulation_metadata.pick_tier?.replace("_", " ") || "N/A"}</div>
            </div>
          </div>
        </div>
        
        <!-- Performance Insights -->
        <div class="section">
          <h2>Performance Insights</h2>
          <div class="insights-grid">
            <div class="insight-column strengths">
              <h3>Strengths</h3>
              <ul>
                ${getStrengthsHTML(simulationData)}
              </ul>
            </div>
            <div class="insight-column improvements">
              <h3>Growth Areas</h3>
              <ul>
                ${getImprovementAreasHTML(simulationData)}
              </ul>
            </div>
            <div class="insight-column recommendations">
              <h3>AI Recommendations</h3>
              <ul>
                ${getRecommendationsHTML(simulationData)}
              </ul>
            </div>
          </div>
        </div>
        
        <!-- Contributor Credits -->
        ${
          cardData.contributor_credits?.length > 0
            ? `
        <div class="section">
          <h2>Contributor Credit Ledger</h2>
          <table class="contributor-table">
            <thead>
              <tr>
                <th>Role</th>
                <th>Contributor Name</th>
                <th>Impact %</th>
                <th>Consent</th>
              </tr>
            </thead>
            <tbody>
              ${cardData.contributor_credits
                .map(
                  (contributor) => `
                <tr>
                  <td>${contributor.role}</td>
                  <td>${contributor.consent_verified ? contributor.name : "[Private]"}</td>
                  <td><strong>${contributor.impact_percentage}%</strong></td>
                  <td>
                    <span class="${contributor.consent_verified ? "consent-verified" : "consent-pending"}">
                      ${contributor.consent_verified ? "Verified" : "Pending"}
                    </span>
                  </td>
                </tr>
              `,
                )
                .join("")}
            </tbody>
          </table>
        </div>
        `
            : ""
        }
        
        <!-- Footer -->
        <div class="footer">
          <div class="timestamp">Generated: ${cardData.header.simulation_date}</div>
          <div class="verification">Coalition Verified • Summit Grade Analysis</div>
        </div>
      </div>
    </body>
    </html>
  `;

  // In a real implementation, you would use a PDF generation library like Puppeteer
  // For now, return the HTML as a mock PDF
  return Buffer.from(htmlTemplate, "utf-8");
}

function getStrengthsHTML(simulationData) {
  const biometrics = simulationData.biometric_milestones || {};
  const strengths = [];

  switch (simulationData.sport_tier) {
    case "elite_basketball":
      if (biometrics.vertical_leap > 35)
        strengths.push("Elite vertical athleticism");
      if (biometrics.wingspan > 84)
        strengths.push("Superior wingspan advantage");
      if (biometrics.shooting_form > 80)
        strengths.push("Advanced shooting mechanics");
      break;
    case "elite_gridiron":
      if (biometrics.forty_yard < 4.5) strengths.push("Elite speed profile");
      if (biometrics.bench_press > 20)
        strengths.push("Superior strength metrics");
      if (biometrics.wonderlic > 25) strengths.push("High football IQ");
      break;
  }

  if (strengths.length === 0) {
    strengths.push(
      "Consistent baseline performance",
      "Strong work ethic indicators",
    );
  }

  return strengths.map((strength) => `<li>${strength}</li>`).join("");
}

function getImprovementAreasHTML(simulationData) {
  const areas = [];
  const teamFitScore = simulationData.team_fit_score;

  if (teamFitScore < 70) areas.push("Team system integration");
  if (teamFitScore < 60) areas.push("Positional versatility");

  if (areas.length === 0) {
    areas.push("Continue current development trajectory");
  }

  return areas.map((area) => `<li>${area}</li>`).join("");
}

function getRecommendationsHTML(simulationData) {
  const recommendations = [];

  if (simulationData.draft_pick_number <= 10) {
    recommendations.push("Focus on immediate impact preparation");
    recommendations.push("Develop leadership presence for high expectations");
  } else {
    recommendations.push("Maximize development runway");
    recommendations.push("Build specialized role competency");
  }

  if (simulationData.team_fit_score > 80) {
    recommendations.push("Leverage excellent organizational fit");
  } else {
    recommendations.push("Focus on adaptability and system learning");
  }

  return recommendations.map((rec) => `<li>${rec}</li>`).join("");
}

// GET endpoint to retrieve existing cards
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const cardId = searchParams.get("card_id");
    const athleteName = searchParams.get("athlete_name");
    const sportTier = searchParams.get("sport_tier");
    const limit = parseInt(searchParams.get("limit")) || 10;

    let cards;

    if (cardId) {
      cards = await sql`
        SELECT * FROM draft_equity_cards
        WHERE card_id = ${cardId}
        LIMIT 1
      `;
    } else {
      let whereClause = "WHERE 1=1";
      const params = [limit];
      let paramCount = 1;

      if (athleteName) {
        whereClause += ` AND athlete_name ILIKE $${++paramCount}`;
        params.push(`%${athleteName}%`);
      }

      if (sportTier) {
        whereClause += ` AND sport_tier = $${++paramCount}`;
        params.push(sportTier);
      }

      cards = await sql`
        SELECT 
          card_id,
          athlete_name,
          sport_tier,
          privacy_mode,
          created_at,
          created_by
        FROM draft_equity_cards
        ${sql.raw(whereClause)}
        ORDER BY created_at DESC
        LIMIT $1
      `.apply(null, params);
    }

    return Response.json({
      cards: cards.map((card) => ({
        card_id: card.card_id,
        athlete_name: card.athlete_name,
        sport_tier: card.sport_tier,
        privacy_mode: card.privacy_mode,
        created_at: card.created_at,
        card_data: cardId ? JSON.parse(card.card_data) : undefined,
        simulation_data: cardId ? JSON.parse(card.simulation_data) : undefined,
      })),
    });
  } catch (error) {
    console.error("Card retrieval error:", error);
    return Response.json(
      { error: "Failed to retrieve cards", details: error.message },
      { status: 500 },
    );
  }
}
