import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * TALENT BRAND OPPORTUNITIES API
 *
 * Returns potential brand collaboration opportunities for talent
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Mock opportunities (replace with real matching algorithm)
    const opportunities = [
      {
        id: 1,
        brandName: "Red Bull",
        description:
          "High-energy performance campaign featuring extreme athletes",
        estimatedValue: 150000,
        duration: "18 months",
        matchScore: 95,
        status: "pending_review",
      },
      {
        id: 2,
        brandName: "Beats by Dre",
        description:
          "Music and performance collaboration with social media activation",
        estimatedValue: 200000,
        duration: "2 years",
        matchScore: 88,
        status: "pending_review",
      },
      {
        id: 3,
        brandName: "Muscle Milk",
        description: "Recovery and nutrition endorsement with training content",
        estimatedValue: 80000,
        duration: "1 year",
        matchScore: 92,
        status: "pending_review",
      },
    ];

    return Response.json(opportunities);
  } catch (error) {
    console.error("Brand opportunities error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
