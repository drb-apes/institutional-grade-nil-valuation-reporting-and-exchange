import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * TALENT CONTRACTS API
 *
 * Returns all contracts (active, pending, completed) for talent
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Mock contract data (replace with real database query)
    const contracts = [
      {
        id: 1,
        brandName: "Nike Performance",
        type: "Performance Endorsement",
        status: "active",
        value: 250000,
        duration: "2 years",
        earned: 125000,
        completion: 50,
        startDate: "2024-01-01",
        endDate: "2026-01-01",
      },
      {
        id: 2,
        brandName: "Gatorade",
        type: "Social Media Campaign",
        status: "active",
        value: 75000,
        duration: "1 year",
        earned: 60000,
        completion: 80,
        startDate: "2024-06-01",
        endDate: "2025-06-01",
      },
      {
        id: 3,
        brandName: "Under Armour",
        type: "Milestone Contract",
        status: "pending",
        value: 500000,
        duration: "3 years",
        earned: 0,
        completion: 0,
        startDate: "2025-01-01",
        endDate: "2028-01-01",
      },
    ];

    return Response.json(contracts);
  } catch (error) {
    console.error("Contracts error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
