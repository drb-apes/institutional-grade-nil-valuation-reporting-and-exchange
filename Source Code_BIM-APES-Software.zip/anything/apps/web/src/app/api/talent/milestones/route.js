import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * TALENT MILESTONES API
 *
 * Returns all milestones (active, completed, failed) for talent
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Fetch milestones from database
    const milestonesData = await sql`
      SELECT 
        m.id,
        m.title,
        m.description,
        m.target_metrics,
        m.current_progress,
        m.milestone_status as status,
        m.reward_pool as reward,
        m.target_date,
        m.created_at
      FROM milestones m
      INNER JOIN user_profiles up ON m.athlete_id = up.id
      WHERE up.user_id = ${userId}
      ORDER BY m.created_at DESC
    `;

    const milestones = milestonesData.map((m) => ({
      id: m.id,
      title: m.title,
      description: m.description,
      status: m.status,
      reward: `$${m.reward?.toLocaleString() || 0}`,
      progress: calculateProgress(m.current_progress, m.target_metrics),
      targetDate: m.target_date,
    }));

    return Response.json(milestones);
  } catch (error) {
    console.error("Milestones error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function calculateProgress(current, target) {
  if (!current || !target) return 0;

  try {
    const currentObj =
      typeof current === "string" ? JSON.parse(current) : current;
    const targetObj = typeof target === "string" ? JSON.parse(target) : target;

    const keys = Object.keys(targetObj);
    if (keys.length === 0) return 0;

    let totalProgress = 0;
    keys.forEach((key) => {
      const currentVal = currentObj[key] || 0;
      const targetVal = targetObj[key] || 1;
      totalProgress += (currentVal / targetVal) * 100;
    });

    return Math.min(100, Math.round(totalProgress / keys.length));
  } catch (e) {
    return 0;
  }
}
