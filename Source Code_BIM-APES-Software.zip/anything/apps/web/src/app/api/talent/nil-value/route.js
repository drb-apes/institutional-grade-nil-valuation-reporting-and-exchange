import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * TALENT NIL VALUE API
 *
 * Returns current NIL valuation and historical data
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Fetch NIL value data
    const nilData = await sql`
      SELECT 
        current_value,
        thirty_day_avg,
        peak_value,
        market_rank
      FROM user_profiles
      WHERE user_id = ${userId}
      LIMIT 1
    `;

    return Response.json({
      success: true,
      currentValue: nilData[0]?.current_value || 125000,
      thirtyDayAvg: nilData[0]?.thirty_day_avg || 118000,
      peakValue: nilData[0]?.peak_value || 145000,
      marketRank: nilData[0]?.market_rank || 247,
      trend: "up",
      changePercent: 12.3,
    });
  } catch (error) {
    console.error("NIL value error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
