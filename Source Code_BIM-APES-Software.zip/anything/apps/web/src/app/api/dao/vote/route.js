import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { proposal_id, vote_choice, vote_reason } = body;

    if (!proposal_id || !vote_choice) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [voterProfile] = await sql`
      SELECT id, tier_level, reputation_score FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!voterProfile) {
      return Response.json(
        { error: "Voter profile not found" },
        { status: 404 },
      );
    }

    // Calculate voting power based on tier and reputation
    const voting_power =
      (voterProfile.tier_level || 1) * 10 +
      (voterProfile.reputation_score || 0);

    // Check if proposal exists and is active
    const [proposal] = await sql`
      SELECT * FROM dao_proposals WHERE id = ${proposal_id} AND proposal_status = 'active'
    `;

    if (!proposal) {
      return Response.json(
        { error: "Proposal not found or not active" },
        { status: 404 },
      );
    }

    const [vote, updatedProposal] = await sql.transaction([
      // Create vote
      sql`
        INSERT INTO dao_votes (
          proposal_id, voter_id, vote_choice, voting_power, vote_reason
        )
        VALUES (
          ${proposal_id}, ${voterProfile.id}, ${vote_choice}, ${voting_power},
          ${vote_reason || null}
        )
        RETURNING *
      `,
      // Update proposal vote counts
      vote_choice === "for"
        ? sql`
        UPDATE dao_proposals
        SET votes_for = votes_for + ${voting_power}
        WHERE id = ${proposal_id}
        RETURNING *
      `
        : vote_choice === "against"
          ? sql`
        UPDATE dao_proposals
        SET votes_against = votes_against + ${voting_power}
        WHERE id = ${proposal_id}
        RETURNING *
      `
          : sql`SELECT * FROM dao_proposals WHERE id = ${proposal_id}`,
    ]);

    return Response.json({
      success: true,
      vote: vote[0],
      proposal: updatedProposal[0],
    });
  } catch (error) {
    console.error("Vote error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
