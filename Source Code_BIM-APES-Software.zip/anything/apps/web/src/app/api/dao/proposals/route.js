import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      title,
      description,
      proposal_type,
      voting_power_required = 100,
      execution_data,
      duration_days = 7,
    } = body;

    if (!title || !description || !proposal_type) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [proposerProfile] = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!proposerProfile) {
      return Response.json(
        { error: "Proposer profile not found" },
        { status: 404 },
      );
    }

    const expires_at = new Date();
    expires_at.setDate(expires_at.getDate() + duration_days);

    const [proposal] = await sql`
      INSERT INTO dao_proposals (
        proposer_id, title, description, proposal_type,
        voting_power_required, execution_data, expires_at
      )
      VALUES (
        ${proposerProfile.id}, ${title}, ${description}, ${proposal_type},
        ${voting_power_required}, ${JSON.stringify(execution_data || {})},
        ${expires_at.toISOString()}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      proposal,
    });
  } catch (error) {
    console.error("Create proposal error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");

  try {
    let proposals;

    if (status) {
      proposals = await sql`
        SELECT 
          dp.*,
          au.name as proposer_name
        FROM dao_proposals dp
        LEFT JOIN user_profiles up ON up.id = dp.proposer_id
        LEFT JOIN auth_users au ON au.id = up.user_id
        WHERE dp.proposal_status = ${status}
        ORDER BY dp.created_at DESC
      `;
    } else {
      proposals = await sql`
        SELECT 
          dp.*,
          au.name as proposer_name
        FROM dao_proposals dp
        LEFT JOIN user_profiles up ON up.id = dp.proposer_id
        LEFT JOIN auth_users au ON au.id = up.user_id
        ORDER BY dp.created_at DESC
        LIMIT 50
      `;
    }

    return Response.json({ proposals });
  } catch (error) {
    console.error("Get proposals error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
