import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Music NIL Live Concert Performance Engine
 *
 * Applies PhysiobioFIN sports performance logic to live music concerts:
 * - Concert Performance Units (CPUs): Songs, Verses, Hooks, Transitions
 * - Real-time NIL valuation during shows
 * - Performance volatility tracking
 * - Hedging, arbitrage, and scalping for concerts
 * - Sponsor activation opportunities
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Rate limiting
    const rateLimit = checkRateLimit(`concert-${session.user.id}`, {
      maxRequests: 15,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      artistId: { required: true, type: "number" },
      concertData: { required: true, type: "object" },
      venueCapacity: { required: false, type: "number" },
      ticketRevenue: { required: false, type: "number" },
    });

    const {
      artistId,
      concertData,
      venueCapacity = 0,
      ticketRevenue = 0,
    } = body;

    // Calculate Concert Performance Metrics
    const performanceMetrics = calculateConcertMetrics(concertData);
    const nilValuation = calculateRealTimeNIL(performanceMetrics, concertData);
    const volatilityAnalysis = analyzeConcertVolatility(concertData);
    const scalableingOpportunities = detectScalpingMoments(concertData);
    const sponsorROI = calculateSponsorROI(
      performanceMetrics,
      venueCapacity,
      ticketRevenue,
    );

    // Store in motion_scans table (concerts treated as performance events)
    const scanResult = await sql`
      INSERT INTO motion_scans (
        athlete_id,
        scan_data,
        ai_score,
        verification_status,
        motion_type,
        metadata,
        created_at
      ) VALUES (
        ${artistId},
        ${JSON.stringify(concertData)},
        ${performanceMetrics.artistPerformanceScore},
        'verified',
        'concert_performance',
        ${JSON.stringify({
          performance_metrics: performanceMetrics,
          nil_valuation: nilValuation,
          volatility: volatilityAnalysis,
          scalping_opportunities: scalableingOpportunities,
          sponsor_roi: sponsorROI,
          sport: "music_live_concert",
        })},
        NOW()
      )
      RETURNING *
    `;

    return createSecureResponse({
      success: true,
      scanId: scanResult[0].id,
      artistPerformanceScore: performanceMetrics.artistPerformanceScore,
      performanceMetrics,
      nilValuation,
      volatilityAnalysis,
      scalableingOpportunities,
      sponsorROI,
      tier: determineArtistTier(performanceMetrics.artistPerformanceScore),
      insights: generateConcertInsights(performanceMetrics, volatilityAnalysis),
    });
  } catch (error) {
    console.error("Concert performance tracking error:", error);
    return createSecureResponse(
      { error: "Failed to process concert performance data" },
      { status: 500 },
    );
  }
}

/**
 * CONCERT PERFORMANCE UNITS (CPUs)
 * Song = Possession/Drive
 * Verse = Play/Attempt
 * Hook/Chorus = Scoring Attempt
 * Dance Sequence = Shift/Sequence
 * Crowd Interaction = Momentum Swing
 */
function calculateConcertMetrics(concertData) {
  const {
    songs = [],
    setList = [],
    crowdEngagement = [],
    vocalQuality = [],
    danceSequences = [],
    technicalIssues = [],
    socialSpikes = [],
    streamingSpikes = [],
  } = concertData;

  // Song Performance Analysis
  const totalSongs = songs.length;
  const cleanSongs = songs.filter((s) => s.vocalClean && !s.errors).length;
  const songAccuracy = totalSongs > 0 ? (cleanSongs / totalSongs) * 100 : 0;

  // Verse Delivery Metrics
  const allVerses = songs.flatMap((s) => s.verses || []);
  const totalVerses = allVerses.length;
  const cleanVerses = allVerses.filter(
    (v) => v.clarity >= 80 && v.timing >= 80,
  ).length;
  const verseAccuracy = totalVerses > 0 ? (cleanVerses / totalVerses) * 100 : 0;
  const wordsPerMinute =
    totalVerses > 0
      ? allVerses.reduce((sum, v) => sum + (v.wpm || 0), 0) / totalVerses
      : 0;

  // Hook/Chorus Execution
  const allHooks = songs.flatMap((s) => s.hooks || []);
  const hookPitchAccuracy =
    allHooks.length > 0
      ? allHooks.reduce((sum, h) => sum + (h.pitchAccuracy || 0), 0) /
        allHooks.length
      : 0;
  const hookPowerOutput =
    allHooks.length > 0
      ? allHooks.reduce((sum, h) => sum + (h.powerOutput || 0), 0) /
        allHooks.length
      : 0;
  const crowdParticipation =
    allHooks.length > 0
      ? allHooks.reduce((sum, h) => sum + (h.crowdSing || 0), 0) /
        allHooks.length
      : 0;

  // High-Intensity Moments
  const highIntensityMoments = [...songs, ...danceSequences].filter(
    (item) => item.intensity >= 80,
  );
  const vocalStamina =
    vocalQuality.length > 0
      ? vocalQuality.reduce((sum, v) => sum + (v.stamina || 100), 0) /
        vocalQuality.length
      : 100;

  // Crowd Engagement (Momentum Swings)
  const avgCrowdEngagement =
    crowdEngagement.length > 0
      ? crowdEngagement.reduce((sum, e) => sum + e.level, 0) /
        crowdEngagement.length
      : 0;
  const engagementSpikes = crowdEngagement.filter((e) => e.level >= 90).length;

  // Technical Quality
  const technicalIssueCount = technicalIssues.length;
  const technicalPenalty = Math.min(technicalIssueCount * 5, 30);

  // Overall Artist Performance Score (APS)
  const aps = calculateAPS({
    songAccuracy,
    verseAccuracy,
    hookPitchAccuracy,
    hookPowerOutput,
    crowdParticipation,
    vocalStamina,
    avgCrowdEngagement,
    engagementSpikes,
    technicalPenalty,
  });

  return {
    artistPerformanceScore: aps,
    songMetrics: {
      totalSongs,
      songAccuracy,
      averageSongDuration:
        totalSongs > 0
          ? songs.reduce((sum, s) => sum + (s.duration || 0), 0) / totalSongs
          : 0,
    },
    verseMetrics: {
      totalVerses,
      verseAccuracy,
      wordsPerMinute,
      clarity:
        allVerses.length > 0
          ? allVerses.reduce((sum, v) => sum + (v.clarity || 0), 0) /
            allVerses.length
          : 0,
    },
    hookMetrics: {
      pitchAccuracy: hookPitchAccuracy,
      powerOutput: hookPowerOutput,
      crowdParticipation,
    },
    performanceIntensity: {
      highIntensityMoments: highIntensityMoments.length,
      vocalStamina,
      energyRetention: vocalStamina,
    },
    crowdMetrics: {
      averageEngagement: avgCrowdEngagement,
      engagementSpikes,
      responseVolume: avgCrowdEngagement,
    },
    technicalQuality: {
      issueCount: technicalIssueCount,
      flowDisruptions: technicalIssueCount,
      penalty: technicalPenalty,
    },
  };
}

function calculateAPS(metrics) {
  const {
    songAccuracy,
    verseAccuracy,
    hookPitchAccuracy,
    hookPowerOutput,
    crowdParticipation,
    vocalStamina,
    avgCrowdEngagement,
    engagementSpikes,
    technicalPenalty,
  } = metrics;

  let aps = 0;

  // Weighted scoring
  aps += (songAccuracy / 100) * 15;
  aps += (verseAccuracy / 100) * 15;
  aps += (hookPitchAccuracy / 100) * 20;
  aps += (hookPowerOutput / 100) * 10;
  aps += (crowdParticipation / 100) * 15;
  aps += (vocalStamina / 100) * 10;
  aps += (avgCrowdEngagement / 100) * 10;
  aps += Math.min(engagementSpikes * 0.5, 5); // Cap at 5 points

  // Technical penalty
  aps -= technicalPenalty;

  return Math.max(0, Math.min(100, aps));
}

/**
 * REAL-TIME NIL VALUATION DURING CONCERT
 * NIL increases with: hook lands clean, crowd surge, viral moment
 * NIL decreases with: sloppy verse, fatigue, technical issues
 */
function calculateRealTimeNIL(performanceMetrics, concertData) {
  const { songs = [], socialSpikes = [], streamingSpikes = [] } = concertData;

  let baseNIL = 50000; // Base NIL value
  let dynamicMultiplier = 1.0;

  // Performance-based adjustments
  if (performanceMetrics.artistPerformanceScore >= 90) {
    dynamicMultiplier *= 1.5;
  } else if (performanceMetrics.artistPerformanceScore >= 80) {
    dynamicMultiplier *= 1.3;
  } else if (performanceMetrics.artistPerformanceScore < 60) {
    dynamicMultiplier *= 0.7;
  }

  // Hook quality impact
  if (performanceMetrics.hookMetrics.pitchAccuracy >= 90) {
    baseNIL *= 1.2;
  }

  // Crowd engagement impact
  if (performanceMetrics.crowdMetrics.averageEngagement >= 85) {
    baseNIL *= 1.25;
  }

  // Social/streaming spike multiplier
  const totalSocialSpikes = socialSpikes.length + streamingSpikes.length;
  if (totalSocialSpikes > 0) {
    baseNIL *= 1 + totalSocialSpikes * 0.05; // 5% per spike
  }

  // Technical issues penalty
  const technicalPenalty =
    performanceMetrics.technicalQuality.issueCount * 0.05;
  dynamicMultiplier *= 1 - technicalPenalty;

  const finalNIL = baseNIL * dynamicMultiplier;

  return {
    baseValue: baseNIL,
    dynamicMultiplier: Math.round(dynamicMultiplier * 100) / 100,
    currentValue: Math.round(finalNIL),
    changeFromBase: Math.round(((finalNIL - baseNIL) / baseNIL) * 100),
    factors: {
      performanceScore: performanceMetrics.artistPerformanceScore,
      hookQuality: performanceMetrics.hookMetrics.pitchAccuracy,
      crowdEngagement: performanceMetrics.crowdMetrics.averageEngagement,
      socialSpikes: totalSocialSpikes,
      technicalIssues: performanceMetrics.technicalQuality.issueCount,
    },
  };
}

/**
 * CONCERT VOLATILITY ANALYSIS
 * Tracks song-to-song, verse-to-verse performance changes
 */
function analyzeConcertVolatility(concertData) {
  const { songs = [], crowdEngagement = [] } = concertData;

  if (songs.length < 2) {
    return { volatilityIndex: 0, consistency: 100 };
  }

  // Calculate song-to-song variance
  const songScores = songs.map(
    (s) => (s.vocalClean ? 100 : 0) + (s.errors ? -20 : 0),
  );
  const mean = songScores.reduce((a, b) => a + b, 0) / songScores.length;
  const variance =
    songScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    songScores.length;
  const stdDev = Math.sqrt(variance);

  const volatilityIndex = (stdDev / mean) * 100;
  const consistency = Math.max(0, 100 - volatilityIndex);

  // Momentum shifts
  const momentumShifts = detectMomentumShifts(crowdEngagement);

  return {
    volatilityIndex: Math.round(volatilityIndex * 100) / 100,
    consistency: Math.round(consistency * 100) / 100,
    standardDeviation: Math.round(stdDev * 100) / 100,
    momentumShifts,
  };
}

function detectMomentumShifts(crowdEngagement) {
  const shifts = [];

  for (let i = 1; i < crowdEngagement.length; i++) {
    const change = crowdEngagement[i].level - crowdEngagement[i - 1].level;
    if (Math.abs(change) >= 20) {
      shifts.push({
        timestamp: crowdEngagement[i].timestamp,
        direction: change > 0 ? "surge" : "drop",
        magnitude: Math.abs(change),
      });
    }
  }

  return shifts;
}

/**
 * SCALPING OPPORTUNITIES (Momentum Trading)
 * Detects short-term performance bursts for trading
 */
function detectScalpingMoments(concertData) {
  const { songs = [], crowdEngagement = [], socialSpikes = [] } = concertData;

  const opportunities = [];

  // Verse-to-verse improvement signals
  songs.forEach((song, idx) => {
    if (song.verses && song.verses.length >= 2) {
      for (let i = 1; i < song.verses.length; i++) {
        const improvement = song.verses[i].clarity - song.verses[i - 1].clarity;
        if (improvement >= 15) {
          opportunities.push({
            type: "verse_improvement",
            song: idx + 1,
            magnitude: improvement,
            signal: "buy",
          });
        }
      }
    }
  });

  // Crowd response spikes
  crowdEngagement.forEach((engagement, idx) => {
    if (engagement.level >= 90) {
      opportunities.push({
        type: "crowd_surge",
        timestamp: engagement.timestamp,
        magnitude: engagement.level,
        signal: "buy",
      });
    }
  });

  // Social/viral moments
  socialSpikes.forEach((spike) => {
    opportunities.push({
      type: "viral_moment",
      platform: spike.platform,
      magnitude: spike.growthRate,
      signal: "buy",
    });
  });

  return opportunities;
}

/**
 * SPONSOR ROI CALCULATION
 * Measures brand exposure and engagement value
 */
function calculateSponsorROI(performanceMetrics, venueCapacity, ticketRevenue) {
  const exposureValue =
    venueCapacity * performanceMetrics.crowdMetrics.averageEngagement;
  const engagementQuality = performanceMetrics.artistPerformanceScore;

  // Estimated brand value
  const cpm = 25; // Cost per thousand impressions (standard rate)
  const brandImpressions =
    venueCapacity + performanceMetrics.crowdMetrics.engagementSpikes * 1000;
  const brandValue = (brandImpressions / 1000) * cpm;

  // ROI multiplier based on performance
  let roiMultiplier = 1.0;
  if (engagementQuality >= 90) roiMultiplier = 1.5;
  else if (engagementQuality >= 80) roiMultiplier = 1.3;
  else if (engagementQuality < 60) roiMultiplier = 0.8;

  return {
    brandValue: Math.round(brandValue * roiMultiplier),
    exposureValue: Math.round(exposureValue),
    roiMultiplier: Math.round(roiMultiplier * 100) / 100,
    estimatedReach: brandImpressions,
    engagementQuality,
  };
}

function determineArtistTier(aps) {
  if (aps >= 90) return "platinum";
  if (aps >= 80) return "gold";
  if (aps >= 70) return "silver";
  if (aps >= 60) return "bronze";
  return "emerging";
}

function generateConcertInsights(performanceMetrics, volatilityAnalysis) {
  const insights = [];

  if (performanceMetrics.hookMetrics.pitchAccuracy >= 90) {
    insights.push({
      type: "strength",
      area: "Hook Execution",
      message: "Elite vocal precision on hooks - major NIL value driver",
      recommendation: "Feature hook-heavy setlist for high-value shows",
    });
  }

  if (performanceMetrics.crowdMetrics.averageEngagement >= 85) {
    insights.push({
      type: "strength",
      area: "Crowd Control",
      message: "Exceptional audience engagement",
      recommendation:
        "Maximize crowd interaction moments for sponsor activations",
    });
  }

  if (performanceMetrics.verseMetrics.verseAccuracy < 70) {
    insights.push({
      type: "improvement",
      area: "Verse Delivery",
      message: "Inconsistent verse clarity affecting overall score",
      recommendation: "Focus on breath control and timing in rehearsal",
    });
  }

  if (performanceMetrics.performanceIntensity.vocalStamina < 70) {
    insights.push({
      type: "weakness",
      area: "Stamina",
      message: "Vocal fatigue detected in later songs",
      recommendation: "Optimize setlist pacing and hydration strategy",
    });
  }

  if (volatilityAnalysis.volatilityIndex > 30) {
    insights.push({
      type: "concern",
      area: "Consistency",
      message: "High performance variance across songs",
      recommendation: "Standardize pre-song preparation routine",
    });
  }

  return insights;
}

// GET: Retrieve concert performance history
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const artistId = searchParams.get("artistId");

    if (!artistId) {
      return createSecureResponse(
        { error: "artistId required" },
        { status: 400 },
      );
    }

    // Fetch recent concert performances
    const concerts = await sql`
      SELECT * FROM motion_scans
      WHERE athlete_id = ${artistId}
        AND motion_type = 'concert_performance'
      ORDER BY created_at DESC
      LIMIT 20
    `;

    // Calculate tour trends
    const tourTrend = calculateTourTrend(concerts);

    return createSecureResponse({
      success: true,
      concerts,
      tourTrend,
      averageAPS:
        concerts.length > 0
          ? concerts.reduce((sum, c) => sum + c.ai_score, 0) / concerts.length
          : 0,
    });
  } catch (error) {
    console.error("Concert performance fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch concert performance data" },
      { status: 500 },
    );
  }
}

function calculateTourTrend(concerts) {
  if (concerts.length < 2) return { trend: "insufficient_data" };

  const recent3 = concerts.slice(0, 3);
  const previous3 = concerts.slice(3, 6);

  if (previous3.length === 0) return { trend: "insufficient_data" };

  const recentAvg =
    recent3.reduce((sum, c) => sum + c.ai_score, 0) / recent3.length;
  const previousAvg =
    previous3.reduce((sum, c) => sum + c.ai_score, 0) / previous3.length;

  const change = ((recentAvg - previousAvg) / previousAvg) * 100;

  return {
    trend: change > 5 ? "improving" : change < -5 ? "declining" : "stable",
    changePercentage: Math.round(change * 100) / 100,
    recentAverage: Math.round(recentAvg * 100) / 100,
    previousAverage: Math.round(previousAvg * 100) / 100,
  };
}
