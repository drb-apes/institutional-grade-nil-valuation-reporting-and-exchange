import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Get featured music artists with top performance
export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const genre = url.searchParams.get("genre");
    const limit = parseInt(url.searchParams.get("limit")) || 10;

    let query;
    if (genre) {
      query = sql`
        SELECT 
          up.id,
          au.name as artist_name,
          ms.metadata->>'genre' as genre,
          ms.metadata->'concertScores'->>'overallCPS' as cps,
          ms.metadata->'consistencyMetrics'->>'concertToConcertConsistency' as consistency,
          ms.metadata->'nilImpact'->'tourProjection'->>'hundredShowTour' as tour_value,
          ms.created_at as last_concert
        FROM user_profiles up
        JOIN auth_users au ON up.user_id = au.id
        JOIN motion_scans ms ON ms.athlete_id = up.id
        WHERE ms.motion_type LIKE ${`%${genre}%concert%`}
        ORDER BY ms.created_at DESC
        LIMIT ${limit}
      `;
    } else {
      query = sql`
        SELECT 
          up.id,
          au.name as artist_name,
          ms.metadata->>'genre' as genre,
          ms.metadata->'concertScores'->>'overallCPS' as cps,
          ms.metadata->'consistencyMetrics'->>'concertToConcertConsistency' as consistency,
          ms.metadata->'nilImpact'->'tourProjection'->>'hundredShowTour' as tour_value,
          ms.created_at as last_concert
        FROM user_profiles up
        JOIN auth_users au ON up.user_id = au.id
        JOIN motion_scans ms ON ms.athlete_id = up.id
        WHERE ms.motion_type LIKE '%concert%'
        ORDER BY ms.created_at DESC
        LIMIT ${limit}
      `;
    }

    const artists = await query;

    return Response.json({
      success: true,
      artists: artists.map((a) => ({
        id: a.id,
        name: a.artist_name,
        genre: a.genre,
        cps: parseFloat(a.cps) || 0,
        consistency: parseFloat(a.consistency) || 0,
        tourValue: parseInt(a.tour_value) || 0,
        lastConcert: a.last_concert,
      })),
    });
  } catch (error) {
    console.error("Featured artists error:", error);
    return Response.json(
      { error: "Failed to fetch featured artists" },
      { status: 500 },
    );
  }
}
