import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Music NIL Portfolio Management
export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    // Get user's music artist portfolio
    const artists = await sql`
      SELECT 
        up.id,
        up.user_id,
        au.name as artist_name,
        au.email,
        up.tier_level,
        up.reputation_score,
        COUNT(ms.id) as total_concerts,
        AVG((ms.metadata->>'concertScores')::jsonb->>'overallCPS') as avg_cps
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN motion_scans ms ON ms.athlete_id = up.id AND ms.motion_type LIKE '%concert%'
      WHERE up.user_type = 'athlete'
      GROUP BY up.id, au.name, au.email
      ORDER BY avg_cps DESC NULLS LAST
      LIMIT 50
    `;

    // Calculate portfolio summary
    const totalArtists = artists.length;
    const avgNILValue =
      artists.reduce(
        (sum, a) => sum + (parseFloat(a.avg_cps) || 0.75) * 150000,
        0,
      ) / Math.max(totalArtists, 1);
    const totalTourRevenue = artists.reduce((sum, a) => {
      const cps = parseFloat(a.avg_cps) || 0.75;
      const performanceScore = cps * 1.3; // Genre multiplier average
      const perShowRevenue = 50000 * (1 + performanceScore * 2);
      return sum + perShowRevenue * 100; // 100-show tour
    }, 0);

    const topPerformer = artists.length > 0 ? artists[0].artist_name : "N/A";

    return Response.json({
      success: true,
      summary: {
        totalArtists,
        totalTourRevenue: Math.round(totalTourRevenue),
        avgNILValue: Math.round(avgNILValue),
        topPerformer,
      },
      artists: artists.map((a) => ({
        id: a.id,
        name: a.artist_name,
        email: a.email,
        tierLevel: a.tier_level,
        reputationScore: a.reputation_score,
        totalConcerts: parseInt(a.total_concerts) || 0,
        avgCPS: parseFloat(a.avg_cps) || 0,
        nilValue: Math.round((parseFloat(a.avg_cps) || 0.75) * 150000),
      })),
    });
  } catch (error) {
    console.error("Music portfolio error:", error);
    return Response.json(
      { error: "Failed to fetch music portfolio" },
      { status: 500 },
    );
  }
}

// POST: Add artist to portfolio
export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { artistId, genre, initialData } = await req.json();

    if (!artistId) {
      return Response.json({ error: "Artist ID required" }, { status: 400 });
    }

    // Update or create artist profile
    const [artist] = await sql`
      INSERT INTO user_profiles (user_id, user_type, tier_level)
      VALUES (${artistId}, 'athlete', 1)
      ON CONFLICT (user_id) DO UPDATE
      SET user_type = 'athlete'
      RETURNING *
    `;

    return Response.json({
      success: true,
      artist,
      message: "Artist added to portfolio",
    });
  } catch (error) {
    console.error("Add artist error:", error);
    return Response.json({ error: "Failed to add artist" }, { status: 500 });
  }
}
