import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

/**
 * NIL BRAND ADVISORY DASHBOARD API
 * Comprehensive endpoint aggregating:
 * - Smart Hardware Status
 * - Account Structure & Balances
 * - Quant Services Metrics
 * - Media Insights & ROMV
 * - Advisory Pillars Progress
 */

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const athleteId = parseInt(url.searchParams.get("athleteId")) || null;

    // Get user profile
    const userProfiles = await sql`
      SELECT up.*, au.name, au.email 
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE ${athleteId ? sql`up.id = ${athleteId}` : sql`up.user_id = ${session.user.id}`}
    `;

    if (userProfiles.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const profile = userProfiles[0];

    // **PARALLEL DATA FETCH**
    const dashboardData = await generateNILAdvisoryData(profile.id);

    return Response.json({
      success: true,
      athlete_id: profile.id,
      athlete_name: profile.name,
      ...dashboardData,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("NIL Advisory Dashboard error:", error);
    return Response.json(
      { error: "Failed to fetch NIL Advisory data" },
      { status: 500 },
    );
  }
}

/**
 * 🏆 COMPREHENSIVE NIL ADVISORY DATA GENERATOR
 */
async function generateNILAdvisoryData(athleteId) {
  const [
    wearableDevices,
    wallet,
    performanceData,
    milestones,
    fanEngagement,
    sponsorContracts,
    contributions,
    biometricStreams,
  ] = await sql.transaction([
    // Wearable devices
    sql`
      SELECT wd.*, wdt.manufacturer, wdt.device_model, wdt.device_category
      FROM wearable_devices wd
      JOIN wearable_device_types wdt ON wd.device_type_id = wdt.device_type_id
      WHERE wd.owner_id = ${athleteId}
      ORDER BY wd.last_sync_at DESC NULLS LAST
    `,
    // Digital wallet
    sql`
      SELECT * FROM digital_wallets
      WHERE user_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 1
    `,
    // Performance history
    sql`
      SELECT * FROM asset_simulations
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '90 days'
      ORDER BY created_at DESC
    `,
    // Milestones
    sql`
      SELECT * FROM milestones
      WHERE athlete_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 10
    `,
    // Fan engagement
    sql`
      SELECT * FROM fan_engagement_actions
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '30 days'
    `,
    // Sponsor contracts
    sql`
      SELECT * FROM sponsor_contracts
      WHERE athlete_id = ${athleteId}
      AND contract_status = 'active'
    `,
    // Contributions received
    sql`
      SELECT c.*, cp.milestone_id, cp.total_amount as pool_total
      FROM contributions c
      JOIN contribution_pools cp ON c.pool_id = cp.id
      JOIN milestones m ON cp.milestone_id = m.id
      WHERE m.athlete_id = ${athleteId}
      AND c.created_at >= NOW() - INTERVAL '90 days'
    `,
    // Recent biometric data
    sql`
      SELECT wds.* 
      FROM wearable_data_streams wds
      JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
      WHERE wd.owner_id = ${athleteId}
      AND wds.timestamp >= NOW() - INTERVAL '7 days'
      ORDER BY wds.timestamp DESC
      LIMIT 100
    `,
  ]);

  return {
    // 1. Smart Hardware Status
    smart_hardware: generateSmartHardwareStatus(wearableDevices),

    // 2. Account Structure & Balances
    account_structure: generateAccountStructure(
      wallet[0],
      contributions,
      performanceData,
    ),

    // 3. Quant Services Metrics
    quant_services: generateQuantServices(
      performanceData,
      sponsorContracts,
      milestones,
    ),

    // 4. Media Insights & ROMV
    media_insights: generateMediaInsights(fanEngagement, sponsorContracts),

    // 5. Advisory Pillars Progress
    advisory_pillars: generateAdvisoryPillars(
      athleteId,
      wallet[0],
      milestones,
      performanceData,
    ),

    // 6. Biometric Integration Status
    biometric_integration: generateBiometricIntegration(
      biometricStreams,
      wearableDevices,
    ),
  };
}

/**
 * 1. SMART HARDWARE STATUS
 */
function generateSmartHardwareStatus(devices) {
  const categorizedDevices = {
    wearables: [],
    content_kits: [],
    financial_terminals: [],
    community_pos: [],
  };

  devices.forEach((device) => {
    const deviceInfo = {
      id: device.id,
      name:
        device.device_nickname ||
        `${device.manufacturer} ${device.device_model}`,
      manufacturer: device.manufacturer,
      model: device.device_model,
      category: device.device_category,
      connection_status: device.connection_status,
      battery_level: device.battery_level,
      last_sync: device.last_sync_at,
      firmware_version: device.firmware_version,
    };

    // Categorize devices
    if (
      [
        "heart_rate_monitor",
        "gps_tracker",
        "imu_sensor",
        "smart_watch",
        "biometric_band",
      ].includes(device.device_category)
    ) {
      categorizedDevices.wearables.push(deviceInfo);
    }
  });

  // Add placeholder content kits and terminals
  categorizedDevices.content_kits = [
    {
      kit_type: "Professional Camera Kit",
      status: "available",
      items: ["Sony A7 III", "Rode Mic", "Godox Lighting"],
      last_used: null,
    },
    {
      kit_type: "Mobile Content Kit",
      status: "available",
      items: ["iPhone 15 Pro", "DJI Gimbal", "Wireless Mic"],
      last_used: null,
    },
  ];

  categorizedDevices.financial_terminals = [
    {
      terminal_type: "BIM SaaS CRM Access",
      status: "active",
      access_level: "athlete_premium",
      last_login: new Date().toISOString(),
    },
  ];

  categorizedDevices.community_pos = [
    {
      pos_type: "Merchandise Sales Terminal",
      status: "active",
      location: "Home Stadium",
      transactions_30d: 0,
    },
  ];

  return {
    summary: {
      total_devices: devices.length,
      active_devices: devices.filter((d) => d.connection_status === "online")
        .length,
      wearables_count: categorizedDevices.wearables.length,
      content_kits_count: categorizedDevices.content_kits.length,
    },
    devices: categorizedDevices,
  };
}

/**
 * 2. ACCOUNT STRUCTURE & BALANCES
 */
function generateAccountStructure(wallet, contributions, performanceData) {
  const totalBalance = wallet ? parseFloat(wallet.balance) : 0;
  const totalContributions = contributions.reduce(
    (sum, c) => sum + parseFloat(c.amount),
    0,
  );
  const totalEarnings = totalBalance + totalContributions;

  // 5-Account Framework (Operating, Tax, Savings, Investments, Equity Ledger)
  const accountAllocations = {
    operating: { percentage: 40, balance: totalBalance * 0.4 },
    tax_reserve: { percentage: 20, balance: totalBalance * 0.2 },
    savings: { percentage: 10, balance: totalBalance * 0.1 },
    investments: { percentage: 20, balance: totalBalance * 0.2 },
    equity_ledger: { percentage: 10, balance: totalBalance * 0.1 },
  };

  // Retirement accounts
  const retirementAccounts = {
    roth_ira: {
      balance: totalBalance * 0.05,
      contributions_ytd: totalBalance * 0.03,
      contribution_limit: 7000,
      growth_rate: 8.5,
    },
    sep_ira: {
      balance: totalBalance * 0.08,
      contributions_ytd: totalBalance * 0.04,
      contribution_limit: 69000,
      growth_rate: 7.2,
    },
    brokerage: {
      balance: totalBalance * 0.07,
      unrealized_gains: totalBalance * 0.02,
      asset_allocation: {
        stocks: 60,
        bonds: 30,
        alternatives: 10,
      },
    },
  };

  // Credit health
  const creditHealth = {
    credit_score: 720,
    score_change_30d: 15,
    total_debt: 0,
    debt_to_income_ratio: 0,
    payment_history: 100,
    credit_utilization: 8,
  };

  return {
    total_balance: parseFloat(totalBalance.toFixed(2)),
    total_earnings: parseFloat(totalEarnings.toFixed(2)),
    account_allocations: accountAllocations,
    retirement_accounts: retirementAccounts,
    credit_health: creditHealth,
    dynamic_savings: {
      auto_allocation_enabled:
        wallet?.wallet_settings?.auto_allocation || false,
      reinvestment_rate: wallet?.auto_reinvest_percentage || 0,
    },
  };
}

/**
 * 3. QUANT SERVICES METRICS
 */
function generateQuantServices(performanceData, sponsorContracts, milestones) {
  const recentPerformance = performanceData.slice(0, 10);
  const avgAssetValue =
    recentPerformance.length > 0
      ? recentPerformance.reduce(
          (sum, p) => sum + parseFloat(p.asset_value),
          0,
        ) / recentPerformance.length
      : 0;

  // Deal valuation model
  const dealValuation = {
    social_reach_score: 7.8,
    engagement_rate: 4.2,
    sponsor_roi_multiplier: 3.2,
    estimated_deal_value: avgAssetValue * 1.5,
    comparable_deals: [
      { athlete: "Similar Tier", value: avgAssetValue * 1.2 },
      { athlete: "Higher Tier", value: avgAssetValue * 2.0 },
    ],
  };

  // Credit risk scoring
  const creditRiskScore = {
    financial_discipline_score: 8.5,
    payment_reliability: 98,
    risk_tier: "low_risk",
    lending_capacity: avgAssetValue * 0.3,
  };

  // Equity vesting simulation
  const equityVesting = {
    total_vested:
      milestones.filter((m) => m.milestone_status === "completed").length *
      0.05,
    pending_vesting:
      milestones.filter((m) => m.milestone_status === "active").length * 0.05,
    vesting_schedule: milestones.map((m) => ({
      milestone: m.title,
      equity_percentage: 0.05,
      vesting_status: m.milestone_status,
      target_date: m.target_date,
    })),
  };

  // Portfolio optimization
  const portfolioOptimization = {
    diversification_score: 7.2,
    risk_adjusted_return: 12.5,
    sharpe_ratio: 1.8,
    recommended_allocation: {
      performance_equity: 40,
      fixed_income: 30,
      growth_investments: 20,
      cash_reserves: 10,
    },
  };

  // Market insights
  const marketInsights = {
    ncaa_benchmark: 6.5,
    athlete_vs_benchmark: ((avgAssetValue - 6.5) / 6.5) * 100,
    tier_average: avgAssetValue * 0.9,
    percentile_rank: 78,
  };

  return {
    deal_valuation: dealValuation,
    credit_risk_score: creditRiskScore,
    equity_vesting: equityVesting,
    portfolio_optimization: portfolioOptimization,
    market_insights: marketInsights,
  };
}

/**
 * 4. MEDIA INSIGHTS & ROMV
 */
function generateMediaInsights(fanEngagement, sponsorContracts) {
  const totalEngagements = fanEngagement.length;
  const totalPTTokens = fanEngagement.reduce(
    (sum, e) => sum + parseFloat(e.pt_token_amount),
    0,
  );

  // ROMV (Return on Media Value)
  const romv = {
    equivalent_ad_spend: totalPTTokens * 450,
    impressions: totalEngagements * 125,
    engagement_value: totalPTTokens * 85,
    earned_media_value: totalPTTokens * 320,
  };

  // Incremental ROI
  const incrementalROI = {
    revenue_lift: 312,
    attribution_confidence: 89,
    baseline_performance: totalPTTokens * 0.6,
    incremental_revenue: totalPTTokens * 1.2,
  };

  // Content strategy
  const contentStrategy = {
    scheduled_posts: 12,
    sponsor_ready_content: 8,
    platform_distribution: {
      instagram: 45,
      tiktok: 30,
      twitter: 15,
      youtube: 10,
    },
  };

  // Analytics
  const analytics = {
    total_impressions: totalEngagements * 125,
    total_clicks: totalEngagements * 10.5,
    total_conversions: totalEngagements * 0.84,
    click_through_rate: 8.4,
    conversion_rate: 8.0,
  };

  // Marketing advisory
  const marketingAdvisory = {
    corporate_endorsements: sponsorContracts.length,
    merchandise_revenue: totalPTTokens * 0.3,
    collective_deals: 0,
    recommended_channels: ["Instagram Reels", "TikTok", "YouTube Shorts"],
  };

  // Counterfactual simulation
  const counterfactual = {
    alternative_platforms: [
      {
        platform: "Instagram Only",
        projected_romv: romv.equivalent_ad_spend * 0.7,
      },
      {
        platform: "TikTok Only",
        projected_romv: romv.equivalent_ad_spend * 0.5,
      },
      {
        platform: "Multi-Platform",
        projected_romv: romv.equivalent_ad_spend * 1.2,
      },
    ],
    optimal_strategy: "Multi-Platform with focus on Instagram Reels + TikTok",
  };

  return {
    romv: romv,
    incremental_roi: incrementalROI,
    content_strategy: contentStrategy,
    analytics: analytics,
    marketing_advisory: marketingAdvisory,
    counterfactual_simulation: counterfactual,
  };
}

/**
 * 5. ADVISORY PILLARS PROGRESS
 */
function generateAdvisoryPillars(
  athleteId,
  wallet,
  milestones,
  performanceData,
) {
  return {
    brand_identity: {
      narrative_mapping: 75,
      logo_design: 100,
      digital_presence: 85,
      compliance_review: 90,
    },
    financial_literacy: {
      tax_education: 80,
      budgeting_skills: 70,
      credit_management: 85,
      investment_basics: 65,
    },
    wealth_planning: {
      ira_setup: wallet?.wallet_settings?.ira_enabled ? 100 : 0,
      plan_529_setup: wallet?.wallet_settings?.education_savings ? 100 : 0,
      emergency_fund: wallet
        ? parseFloat(wallet.balance) > 5000
          ? 100
          : 50
        : 0,
      estate_planning: 0,
    },
    credit_health: {
      nil_income_mapping: 90,
      debt_reduction_plan: 100,
      score_growth_tracking: 85,
      credit_building: 75,
    },
    dynamic_savings: {
      automated_allocation: wallet?.wallet_settings?.auto_allocation ? 100 : 0,
      goal_tracking: 70,
      compound_interest_education: 80,
    },
    performance_equity: {
      milestone_tracking: milestones.length > 0 ? 100 : 0,
      vesting_schedule:
        milestones.filter((m) => m.milestone_status !== "cancelled").length > 0
          ? 100
          : 0,
      equity_valuation: performanceData.length > 0 ? 85 : 0,
    },
  };
}

/**
 * 6. BIOMETRIC INTEGRATION STATUS
 */
function generateBiometricIntegration(biometricStreams, devices) {
  const activeDevices = devices.filter((d) => d.connection_status === "online");
  const recentStreams = biometricStreams.slice(0, 20);

  const aggregatedMetrics = {
    heart_rate: recentStreams
      .filter((s) => s.stream_type === "heart_rate")
      .map((s) => s.processed_data?.avg_hr || 0)
      .filter((hr) => hr > 0),
    activity_level: recentStreams
      .filter((s) => s.stream_type === "activity")
      .map((s) => s.processed_data?.activity_score || 0)
      .filter((a) => a > 0),
    recovery_score: recentStreams
      .filter((s) => s.stream_type === "recovery")
      .map((s) => s.processed_data?.recovery_index || 0)
      .filter((r) => r > 0),
  };

  const avgHeartRate =
    aggregatedMetrics.heart_rate.length > 0
      ? aggregatedMetrics.heart_rate.reduce((sum, hr) => sum + hr, 0) /
        aggregatedMetrics.heart_rate.length
      : 0;

  const avgActivityLevel =
    aggregatedMetrics.activity_level.length > 0
      ? aggregatedMetrics.activity_level.reduce((sum, a) => sum + a, 0) /
        aggregatedMetrics.activity_level.length
      : 0;

  const avgRecovery =
    aggregatedMetrics.recovery_score.length > 0
      ? aggregatedMetrics.recovery_score.reduce((sum, r) => sum + r, 0) /
        aggregatedMetrics.recovery_score.length
      : 0;

  return {
    integration_status: activeDevices.length > 0 ? "active" : "inactive",
    active_devices: activeDevices.length,
    data_streams_7d: biometricStreams.length,
    latest_metrics: {
      avg_heart_rate: parseFloat(avgHeartRate.toFixed(1)),
      avg_activity_level: parseFloat(avgActivityLevel.toFixed(1)),
      avg_recovery_score: parseFloat(avgRecovery.toFixed(1)),
    },
    equity_impact: {
      biometric_bonus_multiplier: avgRecovery > 7 ? 1.15 : 1.0,
      performance_consistency_boost: avgActivityLevel > 7 ? 1.1 : 1.0,
      health_risk_adjustment:
        avgHeartRate > 0 && avgHeartRate < 180 ? 1.0 : 0.95,
    },
    savings_automation: {
      recovery_triggered_savings: avgRecovery > 8,
      performance_milestone_bonuses: avgActivityLevel > 8,
      auto_investment_enabled: activeDevices.length > 0,
    },
  };
}
