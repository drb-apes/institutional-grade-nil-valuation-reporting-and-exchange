import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

/**
 * BIOMETRIC INTEGRATION FOR NIL ADVISORY
 * Real-time wearable data streaming into:
 * - Performance Equity Multipliers
 * - Dynamic Savings Triggers
 * - Health-Based Risk Adjustments
 * - Recovery-Triggered Bonuses
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { device_uuid, stream_type, raw_data, timestamp, session_id } = body;

    // Validate required fields
    if (!device_uuid || !stream_type || !raw_data || !timestamp) {
      return Response.json(
        {
          error:
            "Missing required fields: device_uuid, stream_type, raw_data, timestamp",
        },
        { status: 400 },
      );
    }

    // Get device and owner info
    const devices = await sql`
      SELECT wd.*, up.id as athlete_id
      FROM wearable_devices wd
      JOIN user_profiles up ON wd.owner_id = up.id
      WHERE wd.device_uuid = ${device_uuid}
    `;

    if (devices.length === 0) {
      return Response.json({ error: "Device not found" }, { status: 404 });
    }

    const device = devices[0];
    const athleteId = device.athlete_id;

    // **PROCESS RAW BIOMETRIC DATA**
    const processedData = await processBiometricData(stream_type, raw_data);

    // **INSERT BIOMETRIC STREAM**
    const insertedStream = await sql`
      INSERT INTO wearable_data_streams (
        device_uuid,
        stream_type,
        raw_data,
        processed_data,
        timestamp,
        session_id,
        data_quality_score
      ) VALUES (
        ${device_uuid},
        ${stream_type},
        ${JSON.stringify(raw_data)},
        ${JSON.stringify(processedData)},
        ${timestamp},
        ${session_id || null},
        ${processedData.quality_score || 0.95}
      )
      RETURNING *
    `;

    // **UPDATE DEVICE SYNC STATUS**
    await sql`
      UPDATE wearable_devices
      SET 
        last_sync_at = NOW(),
        battery_level = ${raw_data.battery_level || device.battery_level},
        connection_status = 'online'
      WHERE device_uuid = ${device_uuid}
    `;

    // **CALCULATE BIOMETRIC IMPACT ON EQUITY & SAVINGS**
    const impact = await calculateBiometricImpact(
      athleteId,
      stream_type,
      processedData,
    );

    // **AUTO-TRIGGER SAVINGS/EQUITY ADJUSTMENTS**
    const adjustments = await applyBiometricAdjustments(athleteId, impact);

    return Response.json({
      success: true,
      stream_id: insertedStream[0].id,
      processed_data: processedData,
      impact: impact,
      adjustments: adjustments,
      message: "Biometric data integrated successfully",
    });
  } catch (error) {
    console.error("Biometric integration error:", error);
    return Response.json(
      { error: "Failed to integrate biometric data" },
      { status: 500 },
    );
  }
}

/**
 * GET BIOMETRIC INTEGRATION STATUS
 */
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const athleteId = parseInt(url.searchParams.get("athleteId")) || null;
    const timeframe = parseInt(url.searchParams.get("timeframe") || "7"); // days

    // Get user profile
    const userProfiles = await sql`
      SELECT up.*, au.name, au.email 
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE ${athleteId ? sql`up.id = ${athleteId}` : sql`up.user_id = ${session.user.id}`}
    `;

    if (userProfiles.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const profile = userProfiles[0];

    // Fetch biometric integration status
    const integrationStatus = await getBiometricIntegrationStatus(
      profile.id,
      timeframe,
    );

    return Response.json({
      success: true,
      athlete_id: profile.id,
      athlete_name: profile.name,
      ...integrationStatus,
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Biometric status error:", error);
    return Response.json(
      { error: "Failed to fetch biometric status" },
      { status: 500 },
    );
  }
}

/**
 * 🧬 PROCESS RAW BIOMETRIC DATA
 */
function processBiometricData(streamType, rawData) {
  const processors = {
    heart_rate: processHeartRateData,
    activity: processActivityData,
    recovery: processRecoveryData,
    sleep: processSleepData,
    hrv: processHRVData,
    gps: processGPSData,
    force_plate: processForcePlateData,
    imu: processIMUData,
  };

  const processor = processors[streamType] || processGenericData;
  return processor(rawData);
}

function processHeartRateData(rawData) {
  const hr_values = rawData.heart_rate_values || [];
  const avg_hr =
    hr_values.length > 0
      ? hr_values.reduce((sum, hr) => sum + hr, 0) / hr_values.length
      : rawData.avg_hr || 0;

  const max_hr = Math.max(...hr_values, rawData.max_hr || 0);
  const min_hr = Math.min(
    ...hr_values.filter((hr) => hr > 0),
    rawData.min_hr || 180,
  );

  const zones = calculateHeartRateZones(avg_hr, max_hr);

  return {
    avg_hr: parseFloat(avg_hr.toFixed(1)),
    max_hr: max_hr,
    min_hr: min_hr,
    hr_zones: zones,
    quality_score: rawData.signal_quality || 0.95,
    cardiovascular_efficiency: calculateCardiovascularEfficiency(
      avg_hr,
      max_hr,
    ),
  };
}

function processActivityData(rawData) {
  const steps = rawData.steps || 0;
  const distance = rawData.distance || 0; // meters
  const calories = rawData.calories || 0;
  const active_minutes = rawData.active_minutes || 0;

  const activity_score = calculateActivityScore(
    steps,
    distance,
    active_minutes,
  );

  return {
    steps: steps,
    distance_meters: distance,
    calories_burned: calories,
    active_minutes: active_minutes,
    activity_score: parseFloat(activity_score.toFixed(2)),
    quality_score: 0.95,
  };
}

function processRecoveryData(rawData) {
  const recovery_index = rawData.recovery_score || rawData.recovery_index || 0;
  const readiness = rawData.readiness || 0;
  const stress_level = rawData.stress_level || 0;

  return {
    recovery_index: parseFloat(recovery_index.toFixed(2)),
    readiness_score: parseFloat(readiness.toFixed(2)),
    stress_level: parseFloat(stress_level.toFixed(2)),
    recovery_recommendation: determineRecoveryRecommendation(
      recovery_index,
      stress_level,
    ),
    quality_score: 0.95,
  };
}

function processSleepData(rawData) {
  const total_sleep = rawData.total_sleep_minutes || 0;
  const deep_sleep = rawData.deep_sleep_minutes || 0;
  const rem_sleep = rawData.rem_sleep_minutes || 0;
  const light_sleep = rawData.light_sleep_minutes || 0;

  const sleep_quality = calculateSleepQuality(
    total_sleep,
    deep_sleep,
    rem_sleep,
  );

  return {
    total_sleep_minutes: total_sleep,
    deep_sleep_minutes: deep_sleep,
    rem_sleep_minutes: rem_sleep,
    light_sleep_minutes: light_sleep,
    sleep_quality_score: parseFloat(sleep_quality.toFixed(2)),
    quality_score: 0.95,
  };
}

function processHRVData(rawData) {
  const hrv_rmssd = rawData.hrv_rmssd || 0; // Root mean square of successive differences
  const hrv_sdnn = rawData.hrv_sdnn || 0; // Standard deviation of NN intervals

  return {
    hrv_rmssd: parseFloat(hrv_rmssd.toFixed(2)),
    hrv_sdnn: parseFloat(hrv_sdnn.toFixed(2)),
    autonomic_balance: calculateAutonomicBalance(hrv_rmssd, hrv_sdnn),
    quality_score: 0.95,
  };
}

function processGPSData(rawData) {
  const latitude = rawData.latitude || 0;
  const longitude = rawData.longitude || 0;
  const speed = rawData.speed || 0; // m/s
  const altitude = rawData.altitude || 0;

  return {
    latitude: latitude,
    longitude: longitude,
    speed_mps: parseFloat(speed.toFixed(2)),
    altitude_meters: parseFloat(altitude.toFixed(2)),
    quality_score: rawData.gps_accuracy || 0.9,
  };
}

function processForcePlateData(rawData) {
  const vertical_force = rawData.vertical_force || 0; // Newtons
  const contact_time = rawData.contact_time || 0; // milliseconds
  const jump_height = rawData.jump_height || 0; // cm

  return {
    vertical_force_n: parseFloat(vertical_force.toFixed(2)),
    contact_time_ms: parseFloat(contact_time.toFixed(2)),
    jump_height_cm: parseFloat(jump_height.toFixed(2)),
    power_output_watts: calculatePowerOutput(vertical_force, contact_time),
    quality_score: 0.95,
  };
}

function processIMUData(rawData) {
  const acceleration = rawData.acceleration || { x: 0, y: 0, z: 0 };
  const gyroscope = rawData.gyroscope || { x: 0, y: 0, z: 0 };
  const magnetometer = rawData.magnetometer || { x: 0, y: 0, z: 0 };

  return {
    acceleration: acceleration,
    gyroscope: gyroscope,
    magnetometer: magnetometer,
    total_acceleration: calculateTotalAcceleration(acceleration),
    quality_score: 0.95,
  };
}

function processGenericData(rawData) {
  return {
    ...rawData,
    quality_score: 0.9,
  };
}

/**
 * 💪 BIOMETRIC UTILITY FUNCTIONS
 */
function calculateHeartRateZones(avgHR, maxHR) {
  const zones = {
    zone_1_recovery: avgHR < maxHR * 0.6,
    zone_2_endurance: avgHR >= maxHR * 0.6 && avgHR < maxHR * 0.7,
    zone_3_tempo: avgHR >= maxHR * 0.7 && avgHR < maxHR * 0.8,
    zone_4_threshold: avgHR >= maxHR * 0.8 && avgHR < maxHR * 0.9,
    zone_5_max: avgHR >= maxHR * 0.9,
  };

  return zones;
}

function calculateCardiovascularEfficiency(avgHR, maxHR) {
  if (maxHR === 0) return 0;

  // Lower average HR relative to max = better efficiency
  const efficiency = (1 - avgHR / maxHR) * 10;
  return Math.max(0, Math.min(10, parseFloat(efficiency.toFixed(2))));
}

function calculateActivityScore(steps, distance, activeMinutes) {
  // Normalized activity score (0-10)
  const stepScore = Math.min(steps / 10000, 1) * 3; // Max 3 points for 10k steps
  const distanceScore = Math.min(distance / 8000, 1) * 3; // Max 3 points for 8km
  const timeScore = Math.min(activeMinutes / 60, 1) * 4; // Max 4 points for 60 min

  return stepScore + distanceScore + timeScore;
}

function determineRecoveryRecommendation(recoveryIndex, stressLevel) {
  if (recoveryIndex >= 8 && stressLevel < 3) {
    return "Excellent recovery - Ready for high-intensity training";
  } else if (recoveryIndex >= 6 && stressLevel < 5) {
    return "Good recovery - Moderate intensity training recommended";
  } else if (recoveryIndex >= 4) {
    return "Moderate recovery - Light training or active recovery";
  } else {
    return "Low recovery - Rest day recommended";
  }
}

function calculateSleepQuality(total, deep, rem) {
  if (total === 0) return 0;

  const deepPercentage = (deep / total) * 100;
  const remPercentage = (rem / total) * 100;

  // Optimal: 13-23% deep sleep, 20-25% REM sleep
  const deepScore = Math.min(deepPercentage / 23, 1) * 5;
  const remScore = Math.min(remPercentage / 25, 1) * 5;

  return Math.min(10, deepScore + remScore);
}

function calculateAutonomicBalance(rmssd, sdnn) {
  // Higher HRV = better autonomic balance
  const rmssdScore = Math.min(rmssd / 50, 1) * 5; // Max at 50ms
  const sdnnScore = Math.min(sdnn / 100, 1) * 5; // Max at 100ms

  return parseFloat((rmssdScore + sdnnScore).toFixed(2));
}

function calculatePowerOutput(force, contactTime) {
  if (contactTime === 0) return 0;

  const timeSeconds = contactTime / 1000;
  const work = force * 0.3; // Assume 30cm vertical displacement
  const power = work / timeSeconds;

  return parseFloat(power.toFixed(2));
}

function calculateTotalAcceleration(acceleration) {
  const { x, y, z } = acceleration;
  return parseFloat(Math.sqrt(x * x + y * y + z * z).toFixed(3));
}

/**
 * 📊 CALCULATE BIOMETRIC IMPACT ON EQUITY & SAVINGS
 */
async function calculateBiometricImpact(athleteId, streamType, processedData) {
  // Fetch recent biometric history
  const recentStreams = await sql`
    SELECT wds.* 
    FROM wearable_data_streams wds
    JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
    WHERE wd.owner_id = ${athleteId}
    AND wds.stream_type = ${streamType}
    AND wds.timestamp >= NOW() - INTERVAL '7 days'
    ORDER BY wds.timestamp DESC
    LIMIT 50
  `;

  const impact = {
    equity_multiplier: 1.0,
    savings_trigger: false,
    health_risk_adjustment: 1.0,
    performance_bonus_eligible: false,
    recommendations: [],
  };

  // Calculate impact based on stream type
  if (streamType === "recovery" && processedData.recovery_index) {
    const recoveryIndex = processedData.recovery_index;

    if (recoveryIndex >= 8) {
      impact.equity_multiplier = 1.15; // 15% bonus for excellent recovery
      impact.savings_trigger = true;
      impact.performance_bonus_eligible = true;
      impact.recommendations.push({
        type: "equity_boost",
        message: `Excellent recovery (${recoveryIndex}/10) triggered 15% equity multiplier`,
      });
    } else if (recoveryIndex >= 6) {
      impact.equity_multiplier = 1.08; // 8% bonus for good recovery
      impact.recommendations.push({
        type: "equity_boost",
        message: `Good recovery (${recoveryIndex}/10) triggered 8% equity multiplier`,
      });
    } else if (recoveryIndex < 4) {
      impact.health_risk_adjustment = 0.95; // 5% risk adjustment for poor recovery
      impact.recommendations.push({
        type: "risk_warning",
        message: `Low recovery (${recoveryIndex}/10) - consider rest day`,
      });
    }
  }

  if (streamType === "activity" && processedData.activity_score) {
    const activityScore = processedData.activity_score;

    if (activityScore >= 8) {
      impact.performance_bonus_eligible = true;
      impact.savings_trigger = true;
      impact.recommendations.push({
        type: "performance_milestone",
        message: `High activity score (${activityScore.toFixed(1)}/10) triggered performance bonus`,
      });
    }
  }

  if (streamType === "heart_rate" && processedData.avg_hr) {
    const avgHR = processedData.avg_hr;
    const cardioEfficiency = processedData.cardiovascular_efficiency || 0;

    if (cardioEfficiency >= 7) {
      impact.equity_multiplier = Math.max(impact.equity_multiplier, 1.1);
      impact.recommendations.push({
        type: "cardiovascular_health",
        message: `Excellent cardiovascular efficiency (${cardioEfficiency.toFixed(1)}/10)`,
      });
    }

    // Health risk adjustment for unusual HR
    if (avgHR > 0 && (avgHR > 180 || avgHR < 40)) {
      impact.health_risk_adjustment = 0.95;
      impact.recommendations.push({
        type: "health_alert",
        message: `Unusual heart rate detected (${avgHR.toFixed(0)} bpm) - consider medical consultation`,
      });
    }
  }

  if (streamType === "sleep" && processedData.sleep_quality_score) {
    const sleepQuality = processedData.sleep_quality_score;

    if (sleepQuality >= 8) {
      impact.equity_multiplier = Math.max(impact.equity_multiplier, 1.12);
      impact.recommendations.push({
        type: "sleep_quality",
        message: `Excellent sleep quality (${sleepQuality.toFixed(1)}/10) supports performance`,
      });
    } else if (sleepQuality < 5) {
      impact.health_risk_adjustment = 0.92;
      impact.recommendations.push({
        type: "sleep_warning",
        message: `Poor sleep quality (${sleepQuality.toFixed(1)}/10) may impact performance`,
      });
    }
  }

  return impact;
}

/**
 * 💰 APPLY BIOMETRIC ADJUSTMENTS TO EQUITY & SAVINGS
 */
async function applyBiometricAdjustments(athleteId, impact) {
  const adjustments = {
    equity_adjusted: false,
    savings_deposited: false,
    wallet_updated: false,
    adjustments_applied: [],
  };

  // Get athlete wallet
  const wallets = await sql`
    SELECT * FROM digital_wallets
    WHERE user_id = ${athleteId}
    ORDER BY created_at DESC
    LIMIT 1
  `;

  if (wallets.length === 0) {
    return adjustments;
  }

  const wallet = wallets[0];

  // Apply equity multiplier to recent performance data
  if (impact.equity_multiplier > 1.0) {
    // Update most recent asset simulation with equity multiplier
    await sql`
      UPDATE asset_simulations
      SET 
        asset_value = asset_value * ${impact.equity_multiplier},
        valuation_factors = jsonb_set(
          COALESCE(valuation_factors, '{}'::jsonb),
          '{biometric_multiplier}',
          to_jsonb(${impact.equity_multiplier})
        )
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '24 hours'
    `;

    adjustments.equity_adjusted = true;
    adjustments.adjustments_applied.push({
      type: "equity_multiplier",
      value: impact.equity_multiplier,
      description: `Applied ${((impact.equity_multiplier - 1) * 100).toFixed(1)}% equity bonus`,
    });
  }

  // Trigger automatic savings deposit
  if (impact.savings_trigger && impact.performance_bonus_eligible) {
    const bonusAmount = parseFloat(wallet.balance) * 0.02; // 2% bonus

    await sql`
      UPDATE digital_wallets
      SET 
        balance = balance + ${bonusAmount},
        available_balance = available_balance + ${bonusAmount}
      WHERE id = ${wallet.id}
    `;

    adjustments.savings_deposited = true;
    adjustments.wallet_updated = true;
    adjustments.adjustments_applied.push({
      type: "performance_bonus",
      value: bonusAmount,
      description: `Deposited $${bonusAmount.toFixed(2)} performance bonus`,
    });
  }

  // Apply health risk adjustment
  if (impact.health_risk_adjustment < 1.0) {
    adjustments.adjustments_applied.push({
      type: "risk_adjustment",
      value: impact.health_risk_adjustment,
      description: `Applied ${((1 - impact.health_risk_adjustment) * 100).toFixed(1)}% risk adjustment`,
    });
  }

  return adjustments;
}

/**
 * 📈 GET BIOMETRIC INTEGRATION STATUS
 */
async function getBiometricIntegrationStatus(athleteId, timeframeDays) {
  const [devices, recentStreams, wallet, recentPerformance] =
    await sql.transaction([
      // Wearable devices
      sql`
      SELECT wd.*, wdt.manufacturer, wdt.device_model
      FROM wearable_devices wd
      JOIN wearable_device_types wdt ON wd.device_type_id = wdt.device_type_id
      WHERE wd.owner_id = ${athleteId}
    `,
      // Recent biometric streams
      sql`
      SELECT wds.* 
      FROM wearable_data_streams wds
      JOIN wearable_devices wd ON wds.device_uuid = wd.device_uuid
      WHERE wd.owner_id = ${athleteId}
      AND wds.timestamp >= NOW() - INTERVAL '${timeframeDays} days'
      ORDER BY wds.timestamp DESC
    `,
      // Wallet
      sql`
      SELECT * FROM digital_wallets
      WHERE user_id = ${athleteId}
      ORDER BY created_at DESC
      LIMIT 1
    `,
      // Recent performance with biometric multipliers
      sql`
      SELECT * FROM asset_simulations
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '${timeframeDays} days'
      AND valuation_factors @> '{"biometric_multiplier": 1}'::jsonb
      ORDER BY created_at DESC
    `,
    ]);

  const activeDevices = devices.filter((d) => d.connection_status === "online");

  // Aggregate biometric metrics
  const aggregatedMetrics = aggregateBiometricMetrics(recentStreams);

  // Calculate total biometric impact
  const totalImpact = calculateTotalBiometricImpact(
    recentPerformance,
    aggregatedMetrics,
  );

  return {
    integration_status: activeDevices.length > 0 ? "active" : "inactive",
    active_devices: activeDevices.length,
    total_devices: devices.length,
    data_streams_count: recentStreams.length,
    timeframe_days: timeframeDays,
    aggregated_metrics: aggregatedMetrics,
    total_impact: totalImpact,
    devices_detail: devices.map((d) => ({
      id: d.id,
      name: `${d.manufacturer} ${d.device_model}`,
      status: d.connection_status,
      battery: d.battery_level,
      last_sync: d.last_sync_at,
    })),
  };
}

function aggregateBiometricMetrics(streams) {
  const metrics = {
    heart_rate: [],
    activity: [],
    recovery: [],
    sleep: [],
    hrv: [],
  };

  streams.forEach((stream) => {
    const processed = stream.processed_data || {};

    if (stream.stream_type === "heart_rate" && processed.avg_hr) {
      metrics.heart_rate.push(processed.avg_hr);
    }
    if (stream.stream_type === "activity" && processed.activity_score) {
      metrics.activity.push(processed.activity_score);
    }
    if (stream.stream_type === "recovery" && processed.recovery_index) {
      metrics.recovery.push(processed.recovery_index);
    }
    if (stream.stream_type === "sleep" && processed.sleep_quality_score) {
      metrics.sleep.push(processed.sleep_quality_score);
    }
    if (stream.stream_type === "hrv" && processed.hrv_rmssd) {
      metrics.hrv.push(processed.hrv_rmssd);
    }
  });

  const avgHeartRate =
    metrics.heart_rate.length > 0
      ? metrics.heart_rate.reduce((sum, hr) => sum + hr, 0) /
        metrics.heart_rate.length
      : 0;

  const avgActivity =
    metrics.activity.length > 0
      ? metrics.activity.reduce((sum, a) => sum + a, 0) /
        metrics.activity.length
      : 0;

  const avgRecovery =
    metrics.recovery.length > 0
      ? metrics.recovery.reduce((sum, r) => sum + r, 0) /
        metrics.recovery.length
      : 0;

  const avgSleep =
    metrics.sleep.length > 0
      ? metrics.sleep.reduce((sum, s) => sum + s, 0) / metrics.sleep.length
      : 0;

  const avgHRV =
    metrics.hrv.length > 0
      ? metrics.hrv.reduce((sum, h) => sum + h, 0) / metrics.hrv.length
      : 0;

  return {
    avg_heart_rate: parseFloat(avgHeartRate.toFixed(1)),
    avg_activity_score: parseFloat(avgActivity.toFixed(2)),
    avg_recovery_index: parseFloat(avgRecovery.toFixed(2)),
    avg_sleep_quality: parseFloat(avgSleep.toFixed(2)),
    avg_hrv_rmssd: parseFloat(avgHRV.toFixed(2)),
    data_points: {
      heart_rate: metrics.heart_rate.length,
      activity: metrics.activity.length,
      recovery: metrics.recovery.length,
      sleep: metrics.sleep.length,
      hrv: metrics.hrv.length,
    },
  };
}

function calculateTotalBiometricImpact(performanceRecords, metrics) {
  const biometricBonuses = performanceRecords.filter(
    (p) =>
      p.valuation_factors?.biometric_multiplier &&
      p.valuation_factors.biometric_multiplier > 1.0,
  );

  const totalEquityBonus = biometricBonuses.reduce((sum, p) => {
    const multiplier = p.valuation_factors.biometric_multiplier;
    const baseValue = parseFloat(p.asset_value) / multiplier;
    const bonus = parseFloat(p.asset_value) - baseValue;
    return sum + bonus;
  }, 0);

  const equityMultiplier =
    metrics.avg_recovery_index >= 8
      ? 1.15
      : metrics.avg_recovery_index >= 6
        ? 1.08
        : 1.0;

  const savingsTrigger =
    metrics.avg_recovery_index >= 8 || metrics.avg_activity_score >= 8;

  return {
    total_equity_bonus: parseFloat(totalEquityBonus.toFixed(2)),
    bonus_transactions_count: biometricBonuses.length,
    current_equity_multiplier: equityMultiplier,
    savings_auto_trigger_active: savingsTrigger,
    health_risk_adjustment: metrics.avg_recovery_index < 4 ? 0.95 : 1.0,
  };
}
