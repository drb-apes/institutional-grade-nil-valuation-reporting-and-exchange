import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      participantId,
      tradeType,
      instrument,
      notionalValue,
      executionMode,
      transparencyPhase,
      athleteId,
      biometricTriggers,
      riskLimits,
    } = body;

    // Validate required fields
    if (
      !participantId ||
      !tradeType ||
      !instrument ||
      !notionalValue ||
      !executionMode
    ) {
      return Response.json(
        {
          error:
            "Missing required fields: participantId, tradeType, instrument, notionalValue, executionMode",
        },
        { status: 400 },
      );
    }

    // Validate participant and trading permissions
    const participant = await sql`
      SELECT * FROM institutional_partners 
      WHERE api_credentials->>'participant_id' = ${participantId}
      AND integration_status = 'active'
    `;

    if (participant.length === 0) {
      return Response.json(
        { error: "Invalid or inactive participant" },
        { status: 403 },
      );
    }

    const participantData = participant[0];
    const entityType = participantData.api_credentials.entity_type;
    const complianceTier = participantData.api_credentials.compliance_tier;

    // Check trading permissions
    if (!participantData.service_offerings.trade_execution) {
      return Response.json(
        { error: "Trading not enabled for this participant" },
        { status: 403 },
      );
    }

    // Validate enum values
    const validTradeTypes = ["small", "block"];
    const validInstruments = [
      "ProductA",
      "ProductB",
      "BVI_Future",
      "Tactical_Swap",
      "Recovery_Note",
    ];
    const validExecutionModes = ["swap", "future", "spot", "forward"];
    const validTransparencyPhases = ["I", "II", "III"];

    if (!validTradeTypes.includes(tradeType)) {
      return Response.json(
        { error: "Invalid tradeType. Must be 'small' or 'block'" },
        { status: 400 },
      );
    }

    if (!validInstruments.includes(instrument)) {
      return Response.json({ error: "Invalid instrument" }, { status: 400 });
    }

    if (!validExecutionModes.includes(executionMode)) {
      return Response.json({ error: "Invalid executionMode" }, { status: 400 });
    }

    const effectiveTransparencyPhase =
      transparencyPhase || getTransparencyPhaseFromCompliance(complianceTier);

    if (!validTransparencyPhases.includes(effectiveTransparencyPhase)) {
      return Response.json(
        { error: "Invalid transparencyPhase" },
        { status: 400 },
      );
    }

    // Get participant wallet for trade execution
    const wallet = await sql`
      SELECT * FROM digital_wallets 
      WHERE user_id = ${session.user.id} 
      AND wallet_settings->>'participant_id' = ${participantId}
    `;

    if (wallet.length === 0) {
      return Response.json(
        { error: "No wallet found for participant" },
        { status: 400 },
      );
    }

    // Risk and compliance checks
    const riskAssessment = await performRiskAssessment(
      participantId,
      tradeType,
      notionalValue,
      entityType,
      complianceTier,
      wallet[0],
    );

    if (!riskAssessment.approved) {
      return Response.json(
        {
          error: "Trade rejected by risk assessment",
          reason: riskAssessment.reason,
          risk_metrics: riskAssessment.metrics,
        },
        { status: 400 },
      );
    }

    // Calculate execution costs based on transparency phase and instrument
    const executionCosts = calculateExecutionCosts(
      tradeType,
      instrument,
      notionalValue,
      executionMode,
      effectiveTransparencyPhase,
    );

    // Get biometric signals for trade validation
    const biometricValidation = athleteId
      ? await validateBiometricTriggers(athleteId, biometricTriggers || {})
      : { valid: true, signals: {} };

    if (!biometricValidation.valid) {
      return Response.json(
        {
          error: "Biometric validation failed",
          reason: biometricValidation.reason,
          required_signals: biometricValidation.missing_signals,
        },
        { status: 400 },
      );
    }

    // Execute the trade
    const tradeResult = await executeTrade({
      participantId,
      walletId: wallet[0].id,
      tradeType,
      instrument,
      notionalValue,
      executionMode,
      transparencyPhase: effectiveTransparencyPhase,
      executionCosts,
      biometricSignals: biometricValidation.signals,
      riskMetrics: riskAssessment.metrics,
    });

    // Log trade in treasury transactions
    const treasuryTransaction = await sql`
      INSERT INTO treasury_transactions (
        transaction_type,
        amount,
        balance_after,
        reference_id,
        reference_type,
        description,
        authorized_by
      ) VALUES (
        'trade_execution',
        ${executionCosts.total_cost},
        ${wallet[0].balance - executionCosts.total_cost},
        ${tradeResult.trade_id},
        'biometric_trade',
        ${`${tradeType} ${instrument} trade via ${executionMode} - Transparency Phase ${effectiveTransparencyPhase}`},
        ${session.user.id}
      ) RETURNING *
    `;

    // Update wallet balance
    await sql`
      UPDATE digital_wallets 
      SET balance = balance - ${executionCosts.total_cost},
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ${wallet[0].id}
    `;

    // Create trade confirmation with coalition-coded metadata
    return Response.json({
      success: true,
      trade_confirmation: {
        trade_id: tradeResult.trade_id,
        participantId: participantId,
        instrument: instrument,
        tradeType: tradeType,
        notionalValue: notionalValue,
        executionMode: executionMode,
        transparencyPhase: effectiveTransparencyPhase,
        execution_timestamp: new Date().toISOString(),
        status: "executed",
      },
      execution_details: {
        total_cost: executionCosts.total_cost,
        breakdown: executionCosts.breakdown,
        market_conditions: tradeResult.market_conditions,
        slippage: tradeResult.slippage,
        fill_quality: tradeResult.fill_quality,
      },
      biometric_integration: {
        athlete_id: athleteId || null,
        signals_validated: Object.keys(biometricValidation.signals),
        bvi_at_execution: biometricValidation.signals.bvi || null,
        tactical_efficiency:
          biometricValidation.signals.tactical_efficiency || null,
      },
      compliance: {
        compliance_tier: complianceTier,
        transparency_phase: effectiveTransparencyPhase,
        regulatory_flags: tradeResult.regulatory_flags,
        audit_trail_id: tradeResult.audit_trail_id,
      },
      risk_management: {
        risk_score: riskAssessment.metrics.risk_score,
        position_impact: riskAssessment.metrics.position_impact,
        concentration_check: riskAssessment.metrics.concentration_check,
        var_impact: riskAssessment.metrics.var_impact,
      },
      treasury_transaction_id: treasuryTransaction[0].id,
    });
  } catch (error) {
    console.error("Trade execution error:", error);
    return Response.json(
      {
        error: "Failed to execute trade",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function performRiskAssessment(
  participantId,
  tradeType,
  notionalValue,
  entityType,
  complianceTier,
  wallet,
) {
  const walletSettings = wallet.wallet_settings;
  const riskLimits = walletSettings.risk_limits || {};

  // Check position size limits
  if (notionalValue > (riskLimits.max_position_size || 1000000)) {
    return {
      approved: false,
      reason: "Exceeds maximum position size",
      metrics: { exceeded_limit: "position_size" },
    };
  }

  // Check available balance
  if (notionalValue > wallet.available_balance) {
    return {
      approved: false,
      reason: "Insufficient available balance",
      metrics: {
        required: notionalValue,
        available: wallet.available_balance,
        shortfall: notionalValue - wallet.available_balance,
      },
    };
  }

  // Get recent trading activity for concentration check
  const recentTrades = await sql`
    SELECT SUM(amount) as daily_volume
    FROM treasury_transactions
    WHERE transaction_type = 'trade_execution'
    AND created_at >= CURRENT_DATE
    AND reference_type = 'biometric_trade'
  `;

  const dailyVolume = recentTrades[0]?.daily_volume || 0;
  const maxDailyVolume = riskLimits.max_daily_volume || 10000000;

  if (dailyVolume + notionalValue > maxDailyVolume) {
    return {
      approved: false,
      reason: "Exceeds daily volume limit",
      metrics: {
        daily_used: dailyVolume,
        daily_limit: maxDailyVolume,
        trade_size: notionalValue,
      },
    };
  }

  // Calculate risk score based on trade characteristics
  const riskScore = calculateTradeRiskScore(
    tradeType,
    notionalValue,
    entityType,
    complianceTier,
  );

  // Concentration check (simplified)
  const concentrationRisk = (notionalValue / wallet.balance) * 100;
  const maxConcentration = (riskLimits.concentration_limit || 0.15) * 100;

  if (concentrationRisk > maxConcentration) {
    return {
      approved: false,
      reason: "Exceeds concentration limit",
      metrics: {
        concentration_percentage: concentrationRisk,
        max_allowed: maxConcentration,
      },
    };
  }

  // VaR impact estimation
  const varImpact = notionalValue * (riskLimits.var_limit || 0.05);

  return {
    approved: true,
    reason: "All risk checks passed",
    metrics: {
      risk_score: riskScore,
      position_impact: (notionalValue / wallet.balance) * 100,
      concentration_check: concentrationRisk,
      var_impact: varImpact,
      daily_volume_used: dailyVolume,
      daily_volume_remaining: maxDailyVolume - dailyVolume,
    },
  };
}

function calculateExecutionCosts(
  tradeType,
  instrument,
  notionalValue,
  executionMode,
  transparencyPhase,
) {
  // Base execution cost rates
  const baseCosts = {
    small: 0.001, // 0.1%
    block: 0.0008, // 0.08%
  };

  // Instrument-specific multipliers
  const instrumentMultipliers = {
    ProductA: 1.0,
    ProductB: 1.2,
    BVI_Future: 1.1,
    Tactical_Swap: 0.9,
    Recovery_Note: 1.3,
  };

  // Execution mode costs
  const executionModeCosts = {
    swap: 0.0005,
    future: 0.0003,
    spot: 0.0002,
    forward: 0.0004,
  };

  // Transparency phase adjustments
  const transparencyAdjustments = {
    I: 1.0, // Phase I - standard costs
    II: 1.15, // Phase II - increased transparency requirements
    III: 1.25, // Phase III - full transparency, highest costs
  };

  const baseExecutionCost = notionalValue * baseCosts[tradeType];
  const instrumentAdjustment =
    baseExecutionCost * (instrumentMultipliers[instrument] - 1);
  const executionModeAdjustment =
    notionalValue * executionModeCosts[executionMode];
  const transparencyAdjustment =
    (baseExecutionCost + instrumentAdjustment) *
    (transparencyAdjustments[transparencyPhase] - 1);

  // Additional regulatory costs for Phase II and III
  const regulatoryCost = ["II", "III"].includes(transparencyPhase)
    ? notionalValue * 0.0001 * (transparencyPhase === "III" ? 2 : 1)
    : 0;

  const totalCost =
    baseExecutionCost +
    instrumentAdjustment +
    executionModeAdjustment +
    transparencyAdjustment +
    regulatoryCost;

  return {
    total_cost: Math.round(totalCost * 100) / 100,
    breakdown: {
      base_execution: Math.round(baseExecutionCost * 100) / 100,
      instrument_adjustment: Math.round(instrumentAdjustment * 100) / 100,
      execution_mode: Math.round(executionModeAdjustment * 100) / 100,
      transparency_premium: Math.round(transparencyAdjustment * 100) / 100,
      regulatory_cost: Math.round(regulatoryCost * 100) / 100,
    },
    cost_percentage: Math.round((totalCost / notionalValue) * 10000) / 100, // basis points
  };
}

async function validateBiometricTriggers(athleteId, biometricTriggers) {
  // Get latest biometric signals for athlete
  const latestScan = await sql`
    SELECT * FROM motion_scans 
    WHERE athlete_id = ${athleteId}
    ORDER BY created_at DESC 
    LIMIT 1
  `;

  if (latestScan.length === 0) {
    return {
      valid: false,
      reason: "No biometric data available for athlete",
      missing_signals: ["bvi", "tactical_efficiency", "recovery_index"],
    };
  }

  const scanData = latestScan[0].scan_data;
  const bviScore = scanData?.bvi_score?.overall_score || 0;
  const tacticalEfficiency =
    scanData?.tactical_efficiency?.overall_efficiency || 0;
  const recoveryIndex = scanData?.recovery_index?.overall_recovery || 0;

  // Default trigger thresholds if not specified
  const triggers = {
    min_bvi: biometricTriggers.min_bvi || 60,
    min_tactical: biometricTriggers.min_tactical || 60,
    min_recovery: biometricTriggers.min_recovery || 50,
    ...biometricTriggers,
  };

  // Validate against triggers
  const validationResults = {
    bvi_valid: bviScore >= triggers.min_bvi,
    tactical_valid: tacticalEfficiency >= triggers.min_tactical,
    recovery_valid: recoveryIndex >= triggers.min_recovery,
  };

  const allValid = Object.values(validationResults).every((v) => v === true);

  if (!allValid) {
    const failedChecks = Object.keys(validationResults).filter(
      (key) => !validationResults[key],
    );
    return {
      valid: false,
      reason: "Biometric thresholds not met",
      missing_signals: failedChecks,
      current_values: { bviScore, tacticalEfficiency, recoveryIndex },
      required_values: triggers,
    };
  }

  return {
    valid: true,
    signals: {
      bvi: bviScore,
      tactical_efficiency: tacticalEfficiency,
      recovery_index: recoveryIndex,
      scan_timestamp: latestScan[0].created_at,
    },
  };
}

async function executeTrade(tradeParams) {
  const {
    participantId,
    walletId,
    tradeType,
    instrument,
    notionalValue,
    executionMode,
    transparencyPhase,
    executionCosts,
    biometricSignals,
    riskMetrics,
  } = tradeParams;

  // Generate trade ID
  const tradeId = `BIM_${participantId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  // Simulate market conditions and execution
  const marketConditions = {
    bid_ask_spread: Math.random() * 0.002 + 0.001, // 0.1% - 0.3%
    market_impact:
      tradeType === "block" ? Math.random() * 0.005 : Math.random() * 0.001,
    liquidity_score: Math.random() * 0.4 + 0.6, // 0.6 - 1.0
    volatility: Math.random() * 0.02 + 0.005, // 0.5% - 2.5%
  };

  // Calculate slippage based on trade size and market conditions
  const baseSlippage =
    marketConditions.market_impact * (1 + marketConditions.volatility);
  const transparencySlippage =
    transparencyPhase === "III" ? baseSlippage * 0.2 : 0; // Additional slippage for transparency
  const totalSlippage = baseSlippage + transparencySlippage;

  // Determine fill quality
  const fillQuality =
    marketConditions.liquidity_score > 0.8
      ? "excellent"
      : marketConditions.liquidity_score > 0.6
        ? "good"
        : "fair";

  // Regulatory flags based on transparency phase and trade characteristics
  const regulatoryFlags = [];
  if (transparencyPhase === "III") {
    regulatoryFlags.push("full_transparency_required");
  }
  if (tradeType === "block" && notionalValue > 1000000) {
    regulatoryFlags.push("large_trader_reporting");
  }
  if (instrument.includes("BVI")) {
    regulatoryFlags.push("biometric_instrument_disclosure");
  }

  // Create audit trail ID for compliance
  const auditTrailId = `AUDIT_${tradeId}_${transparencyPhase}`;

  return {
    trade_id: tradeId,
    execution_timestamp: new Date().toISOString(),
    market_conditions: marketConditions,
    slippage: Math.round(totalSlippage * 10000) / 10000, // basis points
    fill_quality: fillQuality,
    regulatory_flags: regulatoryFlags,
    audit_trail_id: auditTrailId,
  };
}

function calculateTradeRiskScore(
  tradeType,
  notionalValue,
  entityType,
  complianceTier,
) {
  let riskScore = 0;

  // Base risk by trade type
  riskScore += tradeType === "block" ? 30 : 15;

  // Size-based risk
  if (notionalValue > 5000000) riskScore += 25;
  else if (notionalValue > 1000000) riskScore += 15;
  else if (notionalValue > 100000) riskScore += 5;

  // Entity type adjustment
  if (entityType === "retail") riskScore += 10;
  else if (entityType === "scout") riskScore += 5;

  // Compliance tier adjustment (higher tier = lower operational risk)
  if (complianceTier === "MiFIDII") riskScore -= 5;
  else if (complianceTier === "DoddFrank") riskScore -= 3;

  return Math.max(0, Math.min(100, riskScore));
}

function getTransparencyPhaseFromCompliance(complianceTier) {
  const phaseMap = {
    LSOC: "I",
    DoddFrank: "II",
    MiFIDII: "III",
  };
  return phaseMap[complianceTier] || "I";
}
