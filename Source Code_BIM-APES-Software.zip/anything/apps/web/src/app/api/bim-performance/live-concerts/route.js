import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Live Concert Performance Units (CPUs)
// Songs = Possessions | Verses = Plays | Choruses = Scoring Attempts
// High-Intensity Moments = Sprints | Crowd Engagement = Momentum Swings
export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      artistId,
      concertData,
      performanceUnits, // CPUs
      genre, // 'hip_hop', 'pop', 'rock', 'edm', 'country', 'r&b'
    } = await req.json();

    if (!artistId || !performanceUnits || !genre) {
      return Response.json(
        {
          error: "Artist ID, performance units, and genre required",
        },
        { status: 400 },
      );
    }

    // Concert Performance Unit Schema
    const concertSchema = {
      songs: [
        "vocal_stability",
        "breath_control",
        "timing_accuracy",
        "energy_retention",
        "crowd_engagement",
      ],
      verses: ["words_per_minute", "clarity", "flow_consistency", "error_rate"],
      choruses: ["pitch_accuracy", "power_output", "audience_participation"],
      high_intensity: [
        "peak_vocal_power",
        "movement_coordination",
        "stamina_cost",
      ],
      crowd_interaction: [
        "response_volume",
        "participation_rate",
        "engagement_spike",
      ],
      transitions: ["set_flow", "energy_management", "technical_transitions"],
    };

    // Calculate Concert Performance Score (CPS)
    const concertScores = calculateConcertPerformance(
      performanceUnits,
      genre,
      concertSchema,
    );

    // Calculate Concert BIM Metrics
    const bimMetrics = calculateConcertBIM(performanceUnits, genre);

    // Calculate Concert-to-Concert Consistency
    const consistencyMetrics = await calculateConcertConsistency(
      artistId,
      genre,
    );

    // Store performance scan
    const [scan] = await sql`
      INSERT INTO motion_scans (
        athlete_id,
        scan_data,
        ai_score,
        verification_status,
        motion_type,
        metadata
      ) VALUES (
        ${parseInt(artistId)},
        ${JSON.stringify(performanceUnits)},
        ${concertScores.overallCPS},
        'verified',
        ${`${genre}_concert`},
        ${JSON.stringify({
          genre,
          concertData,
          concertScores,
          bimMetrics,
          consistencyMetrics,
          timestamp: new Date().toISOString(),
        })}
      )
      RETURNING *
    `;

    // Calculate NIL impact for artist
    const nilImpact = calculateConcertNILImpact(
      concertScores,
      bimMetrics,
      genre,
    );

    return Response.json({
      success: true,
      scan,
      concertScores,
      bimMetrics,
      consistencyMetrics,
      nilImpact,
      insights: generateConcertInsights(
        concertScores,
        consistencyMetrics,
        genre,
      ),
    });
  } catch (error) {
    console.error("Concert performance error:", error);
    return Response.json(
      { error: "Failed to process concert performance" },
      { status: 500 },
    );
  }
}

// Calculate Concert Performance Score
function calculateConcertPerformance(units, genre, schema) {
  const scores = {
    songPerformance: 0,
    verseExecution: 0,
    chorusImpact: 0,
    highIntensityMoments: 0,
    crowdEngagement: 0,
    setTransitions: 0,
    overallCPS: 0,
  };

  // Song Performance (like Drive Completion in Football)
  if (units.songs) {
    const songMetrics = schema.songs.map((metric) => units.songs[metric] || 0);
    scores.songPerformance =
      songMetrics.reduce((a, b) => a + b, 0) / songMetrics.length;
  }

  // Verse Execution (like Play Execution)
  if (units.verses) {
    const verseMetrics = schema.verses.map(
      (metric) => units.verses[metric] || 0,
    );
    scores.verseExecution =
      verseMetrics.reduce((a, b) => a + b, 0) / verseMetrics.length;
  }

  // Chorus Impact (like Scoring Attempts)
  if (units.choruses) {
    const chorusMetrics = schema.choruses.map(
      (metric) => units.choruses[metric] || 0,
    );
    scores.chorusImpact =
      chorusMetrics.reduce((a, b) => a + b, 0) / chorusMetrics.length;
  }

  // High-Intensity Moments (like Sprint Bursts)
  if (units.high_intensity) {
    const hiMetrics = schema.high_intensity.map(
      (metric) => units.high_intensity[metric] || 0,
    );
    scores.highIntensityMoments =
      hiMetrics.reduce((a, b) => a + b, 0) / hiMetrics.length;
  }

  // Crowd Engagement (like Momentum Swings)
  if (units.crowd_interaction) {
    const crowdMetrics = schema.crowd_interaction.map(
      (metric) => units.crowd_interaction[metric] || 0,
    );
    scores.crowdEngagement =
      crowdMetrics.reduce((a, b) => a + b, 0) / crowdMetrics.length;
  }

  // Set Transitions (like Phase Transitions)
  if (units.transitions) {
    const transMetrics = schema.transitions.map(
      (metric) => units.transitions[metric] || 0,
    );
    scores.setTransitions =
      transMetrics.reduce((a, b) => a + b, 0) / transMetrics.length;
  }

  // Calculate overall CPS (weighted by genre)
  const weights = getGenreWeights(genre);
  scores.overallCPS =
    scores.songPerformance * weights.songPerformance +
    scores.verseExecution * weights.verseExecution +
    scores.chorusImpact * weights.chorusImpact +
    scores.highIntensityMoments * weights.highIntensityMoments +
    scores.crowdEngagement * weights.crowdEngagement +
    scores.setTransitions * weights.setTransitions;

  return scores;
}

// Genre-specific weights (different genres value different performance elements)
function getGenreWeights(genre) {
  const weights = {
    hip_hop: {
      songPerformance: 0.15,
      verseExecution: 0.35, // High value on lyrical delivery
      chorusImpact: 0.2,
      highIntensityMoments: 0.15,
      crowdEngagement: 0.1,
      setTransitions: 0.05,
    },
    pop: {
      songPerformance: 0.2,
      verseExecution: 0.15,
      chorusImpact: 0.3, // Pop is chorus-driven
      highIntensityMoments: 0.15,
      crowdEngagement: 0.15,
      setTransitions: 0.05,
    },
    rock: {
      songPerformance: 0.2,
      verseExecution: 0.15,
      chorusImpact: 0.25,
      highIntensityMoments: 0.2, // High energy valued
      crowdEngagement: 0.15,
      setTransitions: 0.05,
    },
    edm: {
      songPerformance: 0.15,
      verseExecution: 0.05,
      chorusImpact: 0.2,
      highIntensityMoments: 0.25, // Drops and energy spikes
      crowdEngagement: 0.25, // Crowd interaction critical
      setTransitions: 0.1,
    },
    country: {
      songPerformance: 0.25,
      verseExecution: 0.2,
      chorusImpact: 0.25,
      highIntensityMoments: 0.1,
      crowdEngagement: 0.15,
      setTransitions: 0.05,
    },
    "r&b": {
      songPerformance: 0.25,
      verseExecution: 0.2,
      chorusImpact: 0.25,
      highIntensityMoments: 0.15, // Vocal runs valued
      crowdEngagement: 0.1,
      setTransitions: 0.05,
    },
  };

  return weights[genre] || weights.pop;
}

// Calculate BIM metrics for concerts
function calculateConcertBIM(units, genre) {
  return {
    vocalStamina: calculateVocalStamina(units, genre),
    emotionalExpression: calculateEmotionalExpression(units, genre),
    technicalProficiency: calculateTechnicalProficiency(units, genre),
    stagePresence: calculateStagePresence(units, genre),
    audienceConnection: calculateAudienceConnection(units, genre),
    setManagement: calculateSetManagement(units, genre),
  };
}

function calculateVocalStamina(units, genre) {
  const breath = units.songs?.breath_control || 0;
  const energy = units.songs?.energy_retention || 0;
  const stamina = units.high_intensity?.stamina_cost || 0;
  return breath * 0.4 + energy * 0.4 + (1 - stamina) * 0.2;
}

function calculateEmotionalExpression(units, genre) {
  const engagement = units.songs?.crowd_engagement || 0;
  const participation = units.choruses?.audience_participation || 0;
  const response = units.crowd_interaction?.response_volume || 0;
  return engagement * 0.35 + participation * 0.35 + response * 0.3;
}

function calculateTechnicalProficiency(units, genre) {
  const pitch = units.choruses?.pitch_accuracy || 0;
  const timing = units.songs?.timing_accuracy || 0;
  const clarity = units.verses?.clarity || 0;
  return pitch * 0.35 + timing * 0.35 + clarity * 0.3;
}

function calculateStagePresence(units, genre) {
  const movement = units.high_intensity?.movement_coordination || 0;
  const crowd = units.crowd_interaction?.engagement_spike || 0;
  const energy = units.songs?.energy_retention || 0;
  return movement * 0.35 + crowd * 0.35 + energy * 0.3;
}

function calculateAudienceConnection(units, genre) {
  const participation = units.crowd_interaction?.participation_rate || 0;
  const response = units.crowd_interaction?.response_volume || 0;
  const engagement = units.songs?.crowd_engagement || 0;
  return participation * 0.4 + response * 0.3 + engagement * 0.3;
}

function calculateSetManagement(units, genre) {
  const flow = units.transitions?.set_flow || 0;
  const energyMgmt = units.transitions?.energy_management || 0;
  const technical = units.transitions?.technical_transitions || 0;
  return flow * 0.4 + energyMgmt * 0.35 + technical * 0.25;
}

// Calculate concert-to-concert consistency
async function calculateConcertConsistency(artistId, genre) {
  const recentConcerts = await sql`
    SELECT metadata FROM motion_scans
    WHERE athlete_id = ${parseInt(artistId)}
    AND motion_type LIKE ${`%${genre}%concert%`}
    ORDER BY created_at DESC
    LIMIT 20
  `;

  if (recentConcerts.length < 3) {
    return {
      concertToConcertConsistency: 0.7,
      averagePerformance: 0.75,
      varianceScore: 0.15,
      trendDirection: "insufficient_data",
    };
  }

  const scores = recentConcerts.map(
    (c) => c.metadata?.concertScores?.overallCPS || 0.7,
  );
  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const consistency = Math.max(0, 1 - variance * 2);

  // Calculate trend (last 5 vs previous 5)
  const recent = scores.slice(0, 5);
  const previous = scores.slice(5, 10);
  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const previousAvg =
    previous.length > 0
      ? previous.reduce((a, b) => a + b, 0) / previous.length
      : recentAvg;

  let trendDirection = "stable";
  if (recentAvg > previousAvg + 0.05) trendDirection = "improving";
  else if (recentAvg < previousAvg - 0.05) trendDirection = "declining";

  return {
    concertToConcertConsistency: consistency,
    averagePerformance: mean,
    varianceScore: variance,
    trendDirection,
    recentPerformances: scores.slice(0, 5),
  };
}

// Calculate NIL impact from concert performance
function calculateConcertNILImpact(concertScores, bimMetrics, genre) {
  // Genre multipliers based on market size
  const genreMultipliers = {
    hip_hop: 1.4,
    pop: 1.5,
    rock: 1.2,
    edm: 1.3,
    country: 1.1,
    "r&b": 1.2,
  };

  const baseMultiplier = genreMultipliers[genre] || 1.0;

  const performanceScore =
    (concertScores.overallCPS * 0.4 +
      bimMetrics.vocalStamina * 0.15 +
      bimMetrics.stagePresence * 0.2 +
      bimMetrics.audienceConnection * 0.15 +
      bimMetrics.technicalProficiency * 0.1) *
    baseMultiplier;

  const nilLiftLow = performanceScore * 110;
  const nilLiftHigh = performanceScore * 160;

  return {
    performanceScore,
    nilLiftRange: {
      low: Math.round(nilLiftLow),
      high: Math.round(nilLiftHigh),
    },
    indexContribution: performanceScore,
    marketability: calculateArtistMarketability(
      concertScores,
      bimMetrics,
      genre,
    ),
    tourProjection: calculateTourProjection(performanceScore, genre),
  };
}

function calculateArtistMarketability(scores, bim, genre) {
  const marketabilityFactors = {
    hip_hop: scores.verseExecution * 1.3, // Lyrical skill drives value
    pop: bim.stagePresence * 1.4, // Stage presence critical
    rock: bim.audienceConnection * 1.3, // Fan loyalty valued
    edm: scores.crowdEngagement * 1.5, // Energy drives value
    country: bim.emotionalExpression * 1.2, // Authenticity valued
    "r&b": bim.vocalStamina * 1.3, // Vocal ability valued
  };
  return marketabilityFactors[genre] || scores.overallCPS;
}

function calculateTourProjection(performanceScore, genre) {
  // Projects potential tour revenue based on performance
  const baseRevenue = 50000; // Per show baseline
  const performanceMultiplier = 1 + performanceScore * 2;
  const genreMultipliers = {
    pop: 1.5,
    hip_hop: 1.4,
    edm: 1.3,
    rock: 1.2,
    "r&b": 1.1,
    country: 1.0,
  };

  const projectedPerShow =
    baseRevenue * performanceMultiplier * (genreMultipliers[genre] || 1.0);

  return {
    perShowRevenue: Math.round(projectedPerShow),
    fiftyShowTour: Math.round(projectedPerShow * 50),
    hundredShowTour: Math.round(projectedPerShow * 100),
  };
}

// Generate concert insights
function generateConcertInsights(scores, consistency, genre) {
  const insights = [];

  if (scores.overallCPS > 0.8) {
    insights.push({
      type: "strength",
      area: "Elite Performance",
      message: `Outstanding concert performance (${(scores.overallCPS * 100).toFixed(1)}%) - Premium NIL value`,
      nilImpact: "very_high",
    });
  }

  if (scores.crowdEngagement > 0.75) {
    insights.push({
      type: "strength",
      area: "Audience Connection",
      message: `Exceptional crowd engagement - High touring potential`,
      nilImpact: "high",
    });
  }

  if (consistency.concertToConcertConsistency > 0.8) {
    insights.push({
      type: "strength",
      area: "Tour Reliability",
      message: `High concert-to-concert consistency - Low risk for sponsors`,
      nilImpact: "high",
    });
  }

  if (scores.highIntensityMoments > 0.75) {
    insights.push({
      type: "strength",
      area: "Peak Moments",
      message: `Strong high-intensity execution - Viral moment potential`,
      nilImpact: "high",
    });
  }

  if (scores.verseExecution < 0.65 && genre === "hip_hop") {
    insights.push({
      type: "improvement",
      area: "Lyrical Delivery",
      message: `Work on verse clarity and flow consistency for ${genre}`,
      nilImpact: "medium",
    });
  }

  if (consistency.trendDirection === "declining") {
    insights.push({
      type: "risk",
      area: "Performance Trend",
      message: `Recent performance decline detected - Monitor closely`,
      nilImpact: "negative",
    });
  }

  return insights;
}

// GET: Retrieve concert performance history
export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const artistId = url.searchParams.get("artistId");
    const genre = url.searchParams.get("genre");

    if (!artistId) {
      return Response.json({ error: "Artist ID required" }, { status: 400 });
    }

    let scans;
    if (genre) {
      scans = await sql`
        SELECT * FROM motion_scans
        WHERE athlete_id = ${parseInt(artistId)}
        AND motion_type LIKE ${`%${genre}%concert%`}
        ORDER BY created_at DESC
        LIMIT 50
      `;
    } else {
      scans = await sql`
        SELECT * FROM motion_scans
        WHERE athlete_id = ${parseInt(artistId)}
        AND motion_type LIKE '%concert%'
        ORDER BY created_at DESC
        LIMIT 50
      `;
    }

    return Response.json({ scans });
  } catch (error) {
    console.error("Get concert performance error:", error);
    return Response.json(
      { error: "Failed to fetch concert data" },
      { status: 500 },
    );
  }
}
