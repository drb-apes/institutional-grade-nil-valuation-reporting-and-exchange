import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";
import {
  calculateBiomechanicalHeatmap,
  calculateEnhancedBiomechanicalHeatmap,
} from "./services/heatmap.js";
import {
  calculateBVI,
  calculateTacticalEfficiency,
  calculateRecoveryIndex,
  calculateSpikeScore,
  calculateSessionConsistency,
  calculatePoseConfidence,
} from "./services/metrics.js";
import {
  scaleMetric,
  calculateOverallScore,
  calculateOverallScore_Normalized,
} from "./services/scoring.js";
import { assessTierMovement, assignTierBadge } from "./services/tier.js";
import {
  generateCoachingInsights,
  generateBVICone,
} from "./services/insights.js";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      motion_scan_data,
      athlete_data = {},
      session_context = {},
    } = await request.json();

    // Validate required data
    if (!motion_scan_data) {
      return Response.json(
        {
          error:
            "Motion scan data required for BIM Performance Index calculation",
        },
        { status: 400 },
      );
    }

    // Ensure motion_scan_data has required structure
    if (!motion_scan_data.biomechanics) {
      motion_scan_data.biomechanics = {};
    }
    if (!motion_scan_data.key_points) {
      motion_scan_data.key_points = [];
    }

    // Get or create user profile - FIX FOR FOREIGN KEY CONSTRAINT
    let userProfile = await sql`
      SELECT id, tier_level, user_type FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      // Create profile if it doesn't exist
      userProfile = await sql`
        INSERT INTO user_profiles (user_id, user_type, tier_level)
        VALUES (${session.user.id}, 'athlete', 1)
        RETURNING id, tier_level, user_type
      `;
    }

    const athlete = userProfile[0];
    const athleteId = athlete.id; // Use user_profiles.id, not auth_users.id

    // Ensure sport type is properly set for sport-specific calculations
    const sportType =
      session_context.sport ||
      motion_scan_data.sport_type ||
      athlete_data.sport ||
      "general";
    motion_scan_data.sport_type = sportType;
    session_context.sport = sportType;

    // **1. NORMALIZED METRIC CALCULATIONS WITH ERROR HANDLING**
    let bvi, tacticalEfficiency, recoveryIndex, spikeScore, sessionConsistency;

    try {
      bvi = calculateBVI(motion_scan_data, athlete_data) || 0.7;
    } catch (error) {
      console.error("BVI calculation error:", error);
      bvi = 0.7;
    }

    try {
      tacticalEfficiency =
        calculateTacticalEfficiency(motion_scan_data, session_context) || 0.7;
    } catch (error) {
      console.error("Tactical efficiency calculation error:", error);
      tacticalEfficiency = 0.7;
    }

    try {
      recoveryIndex =
        (await calculateRecoveryIndex(athleteId, motion_scan_data)) || 0.75; // Use athleteId here
    } catch (error) {
      console.error("Recovery index calculation error:", error);
      recoveryIndex = 0.75;
    }

    try {
      spikeScore = calculateSpikeScore(motion_scan_data) || 0.7;
    } catch (error) {
      console.error("Spike score calculation error:", error);
      spikeScore = 0.7;
    }

    try {
      sessionConsistency =
        (await calculateSessionConsistency(athleteId)) || 0.7; // Use athleteId here
    } catch (error) {
      console.error("Session consistency calculation error:", error);
      sessionConsistency = 0.7;
    }

    const isProfessional =
      athlete.tier_level >= 3 || athlete.user_type === "professional";
    const scale = isProfessional ? 100 : 10;

    const performanceIndex_backend = {
      bvi,
      tactical_efficiency: tacticalEfficiency,
      recovery_index: recoveryIndex,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
      overall_score: calculateOverallScore_Normalized([
        bvi,
        tacticalEfficiency,
        recoveryIndex,
        spikeScore,
        sessionConsistency,
      ]),
      pose_confidence: calculatePoseConfidence(motion_scan_data),
    };

    const performanceIndex_display = {
      bvi: scaleMetric(bvi, scale),
      tactical_efficiency: scaleMetric(tacticalEfficiency, scale),
      recovery_index: scaleMetric(recoveryIndex, scale),
      spike_score: scaleMetric(spikeScore, scale),
      session_consistency: scaleMetric(sessionConsistency, scale),
      overall_score: calculateOverallScore(
        [
          bvi,
          tacticalEfficiency,
          recoveryIndex,
          spikeScore,
          sessionConsistency,
        ],
        scale,
      ),
      scale_type: isProfessional ? "professional" : "pre_college",
      timestamp: new Date().toISOString(),
      pose_confidence: Math.round(
        performanceIndex_backend.pose_confidence * 100,
      ),
      sport_type: sportType,
    };

    // **ENHANCED HEATMAP CALCULATION WITH ERROR HANDLING**
    let biomechanicalHeatmap;
    const hasEnhancedData =
      motion_scan_data.frame_sequence &&
      motion_scan_data.frame_sequence.length > 2 &&
      motion_scan_data.sport_type;

    try {
      if (hasEnhancedData) {
        console.log(
          `Using enhanced 10×10 grid heatmap analysis for ${sportType}`,
        );
        biomechanicalHeatmap = await calculateEnhancedBiomechanicalHeatmap(
          motion_scan_data,
          recoveryIndex,
          tacticalEfficiency,
          athleteId, // Use athleteId here
        );
      } else {
        console.log(`Using standard 8-zone heatmap analysis for ${sportType}`);
        biomechanicalHeatmap = await calculateBiomechanicalHeatmap(
          motion_scan_data,
          recoveryIndex,
          tacticalEfficiency,
          athleteId, // Use athleteId here
        );
      }
    } catch (error) {
      console.error("Biomechanical heatmap calculation error:", error);
      biomechanicalHeatmap = {
        heatmap_type: "error_fallback",
        zones: [],
        enhanced_features: null,
        error: "Heatmap calculation failed",
      };
    }

    const tierAssessment = assessTierMovement(
      performanceIndex_display,
      athlete.tier_level,
    );
    const coachingInsights = generateCoachingInsights(
      performanceIndex_backend,
      performanceIndex_display,
      motion_scan_data,
    );
    const bviCone = generateBVICone(
      performanceIndex_display,
      athlete.tier_level,
    );
    const tierBadgeAssignment = await assignTierBadge(
      athleteId, // Use athleteId here
      performanceIndex_backend,
      performanceIndex_display,
      spikeScore,
      recoveryIndex,
      tacticalEfficiency,
    );
    const ai_score = motion_scan_data.ai_score || 0.85;

    // Store simulation record with error handling
    let simulationRecord;
    try {
      simulationRecord = await sql`
        INSERT INTO asset_simulations (
          athlete_id,
          motion_scan_id,
          asset_value,
          roi_projection,
          risk_score,
          simulation_data,
          valuation_factors
        ) VALUES (
          ${athleteId},
          ${motion_scan_data.scan_id || null},
          ${performanceIndex_display.overall_score},
          ${tierAssessment.roi_projection || 0},
          ${tierAssessment.risk_score || 0.5},
          ${JSON.stringify(performanceIndex_display)},
          ${JSON.stringify({
            coaching_insights: coachingInsights,
            tier_badge: tierBadgeAssignment,
            heatmap_type:
              biomechanicalHeatmap.heatmap_type || "standard_8_zone",
            enhanced_features: biomechanicalHeatmap.enhanced_features || null,
            sport_type: sportType,
          })}
        )
        RETURNING *
      `;
    } catch (error) {
      console.error("Failed to store simulation record:", error);
      simulationRecord = [{ id: null }];
    }

    // Update tier if recommended
    if (tierAssessment.tier_change_recommended) {
      try {
        await sql`
          UPDATE user_profiles 
          SET tier_level = ${tierAssessment.recommended_tier},
              updated_at = CURRENT_TIMESTAMP
          WHERE id = ${athleteId}
        `;
      } catch (error) {
        console.error("Failed to update tier level:", error);
      }
    }

    return Response.json({
      success: true,
      performance_index: performanceIndex_display,
      performance_index_normalized: performanceIndex_backend,
      tier_badge: tierBadgeAssignment,
      tier_assessment: tierAssessment,
      coaching_insights: coachingInsights,
      biomechanical_heatmap: biomechanicalHeatmap,
      bvi_cone: bviCone,
      simulation_id: simulationRecord[0]?.id || null,
      scan_verified: true,
      ai_score: Math.round(ai_score * 100),
      enhanced_analysis: hasEnhancedData,
      sport_type: sportType,
      message: hasEnhancedData
        ? `Enhanced Coalition-grade BIM Performance Index calculated for ${sportType} with 10×10 Grid Biomechanical Heatmap Analysis`
        : `Coalition-grade BIM Performance Index calculated for ${sportType} with Biomechanical Heatmap Analysis`,
    });
  } catch (error) {
    console.error("BIM Performance calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate BIM Performance Index",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
