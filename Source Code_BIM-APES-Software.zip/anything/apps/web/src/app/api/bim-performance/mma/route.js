import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      athleteId,
      strikingData,
      grapplingData,
      conditioningData,
      recoveryMetrics,
    } = body;

    // MMA-specific BVI calculation
    const mmaBVI = calculateMMABVI(
      strikingData,
      grapplingData,
      conditioningData,
      recoveryMetrics,
    );

    // Tactical efficiency for MMA
    const tacticalEfficiency = calculateMMATacticalEfficiency(
      strikingData,
      grapplingData,
    );

    // Recovery index
    const recoveryIndex = calculateMMARecoveryIndex(recoveryMetrics);

    // Store motion scan
    const motionScan = await sql`
      INSERT INTO motion_scans (
        athlete_id, 
        scan_data, 
        ai_score, 
        motion_type, 
        metadata
      ) VALUES (
        ${athleteId},
        ${JSON.stringify({
          sport: "mma",
          bvi_score: mmaBVI,
          tactical_efficiency: tacticalEfficiency,
          recovery_index: recoveryIndex,
          striking_data: strikingData,
          grappling_data: grapplingData,
          conditioning_data: conditioningData,
          analysis_timestamp: new Date().toISOString(),
        })},
        ${mmaBVI.overall_score},
        'mma_performance',
        ${JSON.stringify({
          sport_category: "mixed_martial_arts",
          analysis_version: "v3.0",
          coalition_tier: getCoalitionTier(mmaBVI.overall_score),
        })}
      ) RETURNING *
    `;

    // Generate MMA-specific recommendations
    const recommendations = generateMMARecommendations(
      mmaBVI,
      tacticalEfficiency,
      recoveryIndex,
    );

    return Response.json({
      success: true,
      mma_analysis: {
        sport: "Mixed Martial Arts",
        bvi_score: mmaBVI,
        tactical_efficiency: tacticalEfficiency,
        recovery_index: recoveryIndex,
        coalition_tier: getCoalitionTier(mmaBVI.overall_score),
        recommendations: recommendations,
      },
      motion_scan_id: motionScan[0].id,
    });
  } catch (error) {
    console.error("MMA BIM analysis error:", error);
    return Response.json(
      {
        error: "Failed to process MMA analysis",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateMMABVI(
  strikingData,
  grapplingData,
  conditioningData,
  recoveryMetrics,
) {
  const {
    strikingAccuracy = 65,
    significantStrikes = 0,
    headStrikes = 0,
    bodyStrikes = 0,
    legStrikes = 0,
    knockdowns = 0,
  } = strikingData || {};

  const {
    takedownAttempts = 0,
    successfulTakedowns = 0,
    takedownDefense = 70,
    submissionAttempts = 0,
    groundControlTime = 0,
    reversals = 0,
  } = grapplingData || {};

  const {
    maxHeartRate = 180,
    lactateThreshold = 70,
    vo2Max = 55,
    powerOutput = 75,
    enduranceRating = 70,
  } = conditioningData || {};

  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    sleepQuality = 70,
    hrv = 65,
  } = recoveryMetrics || {};

  // MMA BVI Components (weighted)
  const strikingComponent = Math.min(
    100,
    strikingAccuracy * 0.6 +
      knockdowns * 10 +
      headStrikes * 0.3 +
      bodyStrikes * 0.2 +
      legStrikes * 0.15,
  );

  const grapplingComponent = Math.min(
    100,
    (takedownAttempts > 0
      ? (successfulTakedowns / takedownAttempts) * 100
      : 0) *
      0.4 +
      takedownDefense * 0.3 +
      submissionAttempts * 8 +
      groundControlTime * 0.2 +
      reversals * 5,
  );

  const conditioningComponent = Math.min(
    100,
    enduranceRating * 0.3 +
      powerOutput * 0.25 +
      vo2Max * 1.2 +
      lactateThreshold * 0.15,
  );

  const recoveryComponent = Math.min(
    100,
    100 -
      (cortisolLevels + creatineKinase) / 2 +
      sleepQuality * 0.3 +
      hrv * 0.2,
  );

  // Weighted MMA BVI
  const overallScore = Math.round(
    strikingComponent * 0.35 +
      grapplingComponent * 0.25 +
      conditioningComponent * 0.25 +
      recoveryComponent * 0.15,
  );

  return {
    overall_score: overallScore,
    components: {
      striking: Math.round(strikingComponent),
      grappling: Math.round(grapplingComponent),
      conditioning: Math.round(conditioningComponent),
      recovery: Math.round(recoveryComponent),
    },
    detailed_metrics: {
      striking_accuracy: strikingAccuracy,
      takedown_success_rate:
        takedownAttempts > 0
          ? Math.round((successfulTakedowns / takedownAttempts) * 100)
          : 0,
      ground_control_percentage: groundControlTime,
      submission_threat_level: submissionAttempts * 2,
      cardiovascular_efficiency: Math.round(conditioningComponent),
    },
  };
}

function calculateMMATacticalEfficiency(strikingData, grapplingData) {
  const {
    ringControl = 65,
    pressureResponse = 70,
    adaptability = 75,
    gameplanExecution = 70,
  } = { ...strikingData, ...grapplingData };

  const tacticalScore = Math.round(
    ringControl * 0.25 +
      pressureResponse * 0.3 +
      adaptability * 0.25 +
      gameplanExecution * 0.2,
  );

  return {
    overall_efficiency: tacticalScore,
    components: {
      ring_control: ringControl,
      pressure_response: pressureResponse,
      adaptability: adaptability,
      gameplan_execution: gameplanExecution,
    },
    tactical_grade: getTacticalGrade(tacticalScore),
  };
}

function calculateMMARecoveryIndex(recoveryMetrics) {
  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    sleepQuality = 70,
    hrv = 65,
    inflammationMarkers = 45,
    hydrationStatus = 80,
    mentalReadiness = 75,
  } = recoveryMetrics || {};

  const stressMarkers =
    100 - (cortisolLevels + creatineKinase + inflammationMarkers) / 3;
  const readinessScore =
    (sleepQuality + hrv + hydrationStatus + mentalReadiness) / 4;

  const overallRecovery = Math.round(
    stressMarkers * 0.4 + readinessScore * 0.6,
  );

  return {
    overall_recovery: overallRecovery,
    stress_markers: Math.round(stressMarkers),
    readiness_score: Math.round(readinessScore),
    recovery_grade: getRecoveryGrade(overallRecovery),
    recommendations: generateRecoveryRecommendations(overallRecovery),
  };
}

function generateMMARecommendations(mmaBVI, tacticalEfficiency, recoveryIndex) {
  const recommendations = [];

  // BVI-based recommendations
  if (mmaBVI.overall_score >= 85) {
    recommendations.push({
      type: "elite_development",
      priority: "high",
      message: "Elite MMA prospect - Consider Summit-tier coaching allocation",
    });
  } else if (mmaBVI.overall_score < 60) {
    recommendations.push({
      type: "fundamental_improvement",
      priority: "urgent",
      message:
        "Focus on fundamental technique development across all disciplines",
    });
  }

  // Component-specific recommendations
  if (mmaBVI.components.striking < 70) {
    recommendations.push({
      type: "striking_development",
      priority: "high",
      message:
        "Increase striking training volume - Focus on accuracy and power",
    });
  }

  if (mmaBVI.components.grappling < 65) {
    recommendations.push({
      type: "grappling_focus",
      priority: "medium",
      message: "Enhance takedown defense and submission game",
    });
  }

  // Recovery recommendations
  if (recoveryIndex.overall_recovery < 60) {
    recommendations.push({
      type: "recovery_protocol",
      priority: "urgent",
      message:
        "Implement enhanced recovery protocols - Consider training load reduction",
    });
  }

  return recommendations;
}

function getTacticalGrade(score) {
  if (score >= 90) return "A+";
  if (score >= 85) return "A";
  if (score >= 80) return "A-";
  if (score >= 75) return "B+";
  if (score >= 70) return "B";
  if (score >= 65) return "B-";
  if (score >= 60) return "C";
  return "D";
}

function getRecoveryGrade(score) {
  if (score >= 85) return "Excellent";
  if (score >= 75) return "Very Good";
  if (score >= 65) return "Good";
  if (score >= 55) return "Fair";
  if (score >= 45) return "Poor";
  return "Critical";
}

function getCoalitionTier(bviScore) {
  if (bviScore >= 90) return "Summit Elite";
  if (bviScore >= 80) return "Summit";
  if (bviScore >= 70) return "Elite";
  if (bviScore >= 60) return "Development";
  return "Foundation";
}

function generateRecoveryRecommendations(recoveryScore) {
  if (recoveryScore >= 80) {
    return [
      "Maintain current recovery protocols",
      "Consider training load increase",
    ];
  } else if (recoveryScore >= 60) {
    return ["Monitor stress markers closely", "Optimize sleep and nutrition"];
  } else {
    return [
      "Immediate recovery intervention needed",
      "Reduce training intensity",
      "Medical consultation recommended",
    ];
  }
}
