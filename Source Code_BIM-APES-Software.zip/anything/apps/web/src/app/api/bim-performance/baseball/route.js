import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Hitting performance analysis
function calculateHittingPerformance(baseballData) {
  const battingAverage = baseballData.batting_average || 0.275;
  const onBasePercentage = baseballData.on_base_percentage || 0.35;
  const sluggingPercentage = baseballData.slugging_percentage || 0.425;

  // Advanced hitting metrics
  const exitVelocity = baseballData.exit_velocity || 85; // mph
  const exitVelocityScore = Math.min(exitVelocity / 100, 1.0);

  const launchAngle = baseballData.launch_angle_consistency || 0.7;
  const plateDiscipline = baseballData.plate_discipline_score || 0.65;

  // Situational hitting
  const clutchHitting = baseballData.clutch_hitting_average || battingAverage;
  const clutchScore = clutchHitting / Math.max(battingAverage, 0.2);

  return (
    (battingAverage * 3 +
      onBasePercentage * 2.5 +
      sluggingPercentage * 2 +
      exitVelocityScore * 0.5 +
      launchAngle * 0.5 +
      plateDiscipline * 0.5 +
      Math.min(clutchScore, 1.2) * 0.5) /
    10
  );
}

// Pitching performance analysis
function calculatePitchingPerformance(baseballData) {
  const earnedRunAverage = baseballData.earned_run_average || 4.0;
  const eraScore = Math.max(0, 1 - (earnedRunAverage - 2.0) / 6.0); // 2.0 = excellent

  const strikeoutRate = baseballData.strikeout_rate || 0.2;
  const walkRate = baseballData.walk_rate || 0.1;
  const whip = baseballData.whip || 1.35; // Walks + Hits per Innings Pitched

  // Advanced pitching metrics
  const commandScore = baseballData.command_score || 0.7;
  const velocityConsistency = baseballData.velocity_consistency || 0.75;
  const pitchMix = baseballData.pitch_mix_effectiveness || 0.7;

  // Pressure situations
  const closingAbility = baseballData.closing_ability || 0.65;

  return (
    eraScore * 0.25 +
    strikeoutRate * 2 +
    (1 - walkRate) * 1.5 +
    ((1.5 - Math.min(whip, 1.5)) / 1.5) * 0.5 +
    commandScore * 0.3 +
    velocityConsistency * 0.25 +
    pitchMix * 0.25 +
    closingAbility * 0.2
  );
}

// Fielding performance analysis
function calculateFieldingPerformance(baseballData, position) {
  const fieldingPercentage = baseballData.fielding_percentage || 0.97;
  const rangeScore = baseballData.range_score || 0.75;
  const armStrength = baseballData.arm_strength_score || 0.7;

  // Position-specific adjustments
  let positionWeight = 1.0;
  let positionSpecific = 0.75;

  switch (position) {
    case "catcher":
      const throwingAccuracy = baseballData.throwing_accuracy || 0.7;
      const framingScore = baseballData.framing_score || 0.65;
      const gameManagement = baseballData.game_management || 0.7;
      positionSpecific = (throwingAccuracy + framingScore + gameManagement) / 3;
      break;

    case "infield":
      const doublePlayTurns = baseballData.double_play_turns || 0.8;
      const quickRelease = baseballData.quick_release_score || 0.75;
      positionSpecific = (doublePlayTurns + quickRelease) / 2;
      break;

    case "outfield":
      const jumpScore = baseballData.first_step_score || 0.7;
      const routeEfficiency = baseballData.route_efficiency || 0.75;
      positionSpecific = (jumpScore + routeEfficiency) / 2;
      break;
  }

  return (
    (fieldingPercentage * 2 +
      rangeScore * 1.5 +
      armStrength * 1 +
      positionSpecific * 1.5) /
    6
  );
}

// Base running performance analysis
function calculateBaseRunningPerformance(baseballData) {
  const stolenBaseSuccess = baseballData.stolen_base_percentage || 0.75;
  const baseAdvancement = baseballData.base_advancement_score || 0.7;
  const runningSpeed = baseballData.running_speed_score || 0.7;
  const baseIQ = baseballData.base_running_iq || 0.75;

  return (
    stolenBaseSuccess * 0.3 +
    baseAdvancement * 0.3 +
    runningSpeed * 0.2 +
    baseIQ * 0.2
  );
}

// Baseball tactical efficiency calculation
function calculateBaseballTacticalEfficiency(baseballData, primaryPosition) {
  let hitting = 0.7,
    pitching = 0.7,
    fielding = 0.7,
    baseRunning = 0.7;

  // Calculate performance in available areas
  if (baseballData.at_bats > 0 || baseballData.batting_average !== undefined) {
    hitting = calculateHittingPerformance(baseballData);
  }

  if (
    baseballData.innings_pitched > 0 ||
    baseballData.earned_run_average !== undefined
  ) {
    pitching = calculatePitchingPerformance(baseballData);
  }

  if (primaryPosition && primaryPosition !== "designated_hitter") {
    fielding = calculateFieldingPerformance(baseballData, primaryPosition);
  }

  if (
    baseballData.stolen_base_attempts > 0 ||
    baseballData.stolen_base_percentage !== undefined
  ) {
    baseRunning = calculateBaseRunningPerformance(baseballData);
  }

  // Weight based on position
  let weights = {
    hitting: 0.4,
    pitching: 0.1,
    fielding: 0.3,
    baseRunning: 0.2,
  };

  if (primaryPosition === "pitcher") {
    weights = {
      hitting: 0.15,
      pitching: 0.55,
      fielding: 0.2,
      baseRunning: 0.1,
    };
  } else if (primaryPosition === "catcher") {
    weights = {
      hitting: 0.35,
      pitching: 0.05,
      fielding: 0.45,
      baseRunning: 0.15,
    };
  } else if (primaryPosition === "designated_hitter") {
    weights = { hitting: 0.7, pitching: 0.0, fielding: 0.0, baseRunning: 0.3 };
  }

  return (
    hitting * weights.hitting +
    pitching * weights.pitching +
    fielding * weights.fielding +
    baseRunning * weights.baseRunning
  );
}

// Baseball spike score calculation
function calculateBaseballSpikeScore(baseballData, primaryPosition) {
  let spikePlays = 0;
  const gamesPlayed = baseballData.games_played || 1;

  // Hitting spike plays
  const homeRuns = baseballData.home_runs || 0;
  const gameWinningHits = baseballData.game_winning_hits || 0;
  const walkOffHits = baseballData.walk_off_hits || 0;

  spikePlays += homeRuns * 0.5 + gameWinningHits * 1.0 + walkOffHits * 2.0;

  // Pitching spike plays (if applicable)
  if (primaryPosition === "pitcher") {
    const strikeouts = baseballData.strikeouts || 0;
    const completeGames = baseballData.complete_games || 0;
    const saves = baseballData.saves || 0;
    const shutouts = baseballData.shutouts || 0;

    spikePlays +=
      strikeouts * 0.1 + completeGames * 2.0 + saves * 1.5 + shutouts * 3.0;
  }

  // Fielding spike plays
  const defensivePlays = baseballData.defensive_plays_above_average || 0;
  const assistsAboveAverage = baseballData.assists_above_average || 0;

  spikePlays += defensivePlays * 0.5 + assistsAboveAverage * 0.3;

  // Base running spike plays
  const stolenBases = baseballData.stolen_bases || 0;
  const extraBasesAdvanced = baseballData.extra_bases_advanced || 0;

  spikePlays += stolenBases * 0.2 + extraBasesAdvanced * 0.3;

  return Math.min(spikePlays / gamesPlayed, 1.0);
}

// Baseball session consistency
async function calculateBaseballSessionConsistency(athleteId, primaryPosition) {
  const recentSessions = await sql`
    SELECT simulation_data->'baseball_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '60 days'
    AND valuation_factors->>'sport' = 'baseball'
    ORDER BY created_at DESC
    LIMIT 20
  `;

  if (recentSessions.length < 3) return 0.7;

  const tacticalScores = recentSessions.map(
    (s) => s.metrics?.tactical_efficiency || 0.7,
  );

  const mean =
    tacticalScores.reduce((a, b) => a + b, 0) / tacticalScores.length;
  const variance =
    tacticalScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    tacticalScores.length;

  return Math.max(0, 1 - variance * 1.8);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      baseball_data,
      primary_position,
      sport_variant,
      competition_level,
    } = await request.json();

    if (!baseball_data || !primary_position) {
      return Response.json(
        { error: "Baseball data and primary position required" },
        { status: 400 },
      );
    }

    const validPositions = [
      "pitcher",
      "catcher",
      "first_base",
      "second_base",
      "third_base",
      "shortstop",
      "left_field",
      "center_field",
      "right_field",
      "designated_hitter",
    ];

    if (!validPositions.includes(primary_position)) {
      return Response.json(
        { error: `Position must be one of: ${validPositions.join(", ")}` },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Determine position category for fielding analysis
    let positionCategory = "infield";
    if (
      ["left_field", "center_field", "right_field"].includes(primary_position)
    ) {
      positionCategory = "outfield";
    } else if (primary_position === "catcher") {
      positionCategory = "catcher";
    }

    // Calculate baseball metrics
    const hitting = calculateHittingPerformance(baseball_data);
    const pitching =
      primary_position === "pitcher"
        ? calculatePitchingPerformance(baseball_data)
        : 0.7;
    const fielding =
      primary_position !== "designated_hitter"
        ? calculateFieldingPerformance(baseball_data, positionCategory)
        : 0.7;
    const baseRunning = calculateBaseRunningPerformance(baseball_data);
    const tacticalEfficiency = calculateBaseballTacticalEfficiency(
      baseball_data,
      primary_position,
    );
    const spikeScore = calculateBaseballSpikeScore(
      baseball_data,
      primary_position,
    );
    const sessionConsistency = await calculateBaseballSessionConsistency(
      athlete.id,
      primary_position,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      hitting_performance: hitting,
      pitching_performance: pitching,
      fielding_performance: fielding,
      base_running: baseRunning,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall baseball performance index
    let weights = {
      hitting: 0.35,
      pitching: 0.15,
      fielding: 0.3,
      baseRunning: 0.2,
    };

    if (primary_position === "pitcher") {
      weights = {
        hitting: 0.15,
        pitching: 0.5,
        fielding: 0.2,
        baseRunning: 0.15,
      };
    } else if (primary_position === "designated_hitter") {
      weights = {
        hitting: 0.7,
        pitching: 0.0,
        fielding: 0.0,
        baseRunning: 0.3,
      };
    }

    const overallScore =
      hitting * weights.hitting +
      pitching * weights.pitching +
      fielding * weights.fielding +
      baseRunning * weights.baseRunning;

    // Scale for display based on competition level
    const isCollegiate =
      competition_level === "collegiate" ||
      competition_level === "professional" ||
      athlete.tier_level >= 3;
    const displayScale = isCollegiate ? 100 : 85;

    const displayMetrics = {
      hitting_performance: Math.round(hitting * displayScale),
      pitching_performance:
        primary_position === "pitcher"
          ? Math.round(pitching * displayScale)
          : null,
      fielding_performance:
        primary_position !== "designated_hitter"
          ? Math.round(fielding * displayScale)
          : null,
      base_running: Math.round(baseRunning * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isCollegiate
        ? `collegiate_${sport_variant || "baseball"}`
        : `high_school_${sport_variant || "baseball"}`,
      primary_position: primary_position,
      sport_variant: sport_variant || "baseball",
      timestamp: new Date().toISOString(),
    };

    // Generate baseball-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      baseball_tips: [],
    };

    // Analyze strengths and weaknesses
    if (performanceMetrics.hitting_performance >= 0.8) {
      insights.strengths.push("Exceptional hitting performance");
    } else if (performanceMetrics.hitting_performance <= 0.6) {
      insights.improvements.push("Focus on hitting mechanics and approach");
    }

    if (
      primary_position === "pitcher" &&
      performanceMetrics.pitching_performance >= 0.8
    ) {
      insights.strengths.push("Outstanding pitching performance");
    } else if (
      primary_position === "pitcher" &&
      performanceMetrics.pitching_performance <= 0.6
    ) {
      insights.improvements.push("Work on command and pitch development");
    }

    if (
      primary_position !== "designated_hitter" &&
      performanceMetrics.fielding_performance >= 0.8
    ) {
      insights.strengths.push("Excellent defensive skills");
    } else if (
      primary_position !== "designated_hitter" &&
      performanceMetrics.fielding_performance <= 0.6
    ) {
      insights.improvements.push(
        "Improve fielding fundamentals and positioning",
      );
    }

    // Position-specific tips
    switch (primary_position) {
      case "pitcher":
        if (performanceMetrics.pitching_performance <= 0.6) {
          insights.baseball_tips.push(
            "Focus on strike zone command and pitch sequencing",
          );
        }
        insights.baseball_tips.push(
          "Develop consistent delivery and mental approach",
        );
        break;

      case "catcher":
        if (performanceMetrics.fielding_performance <= 0.6) {
          insights.baseball_tips.push(
            "Work on framing, blocking, and throwing mechanics",
          );
        }
        insights.baseball_tips.push(
          "Study opposing hitters and develop game-calling skills",
        );
        break;

      case "first_base":
      case "second_base":
      case "third_base":
      case "shortstop":
        if (performanceMetrics.fielding_performance <= 0.6) {
          insights.baseball_tips.push(
            "Practice double play turns and quick releases",
          );
        }
        insights.baseball_tips.push(
          "Work on positioning and communication with teammates",
        );
        break;

      case "left_field":
      case "center_field":
      case "right_field":
        if (performanceMetrics.fielding_performance <= 0.6) {
          insights.baseball_tips.push(
            "Focus on first step and route efficiency",
          );
        }
        insights.baseball_tips.push(
          "Practice reading ball off bat and arm strength",
        );
        break;

      case "designated_hitter":
        if (performanceMetrics.hitting_performance <= 0.6) {
          insights.baseball_tips.push(
            "Focus on plate discipline and situational hitting",
          );
        }
        insights.baseball_tips.push(
          "Study pitchers and develop consistent approach",
        );
        break;
    }

    // General improvement areas
    if (performanceMetrics.base_running <= 0.6) {
      insights.improvements.push("Improve base running intelligence and speed");
      insights.baseball_tips.push(
        "Study pitcher tendencies and practice base stealing",
      );
    }

    if (performanceMetrics.session_consistency <= 0.6) {
      insights.improvements.push("Focus on consistent preparation and routine");
      insights.baseball_tips.push(
        "Develop pre-game routines and mental approach",
      );
    }

    // Sport variant specific advice
    if (sport_variant === "softball") {
      insights.baseball_tips.push(
        "Adjust timing for faster pitch speeds and shorter distances",
      );
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.25, 1.0)},
        ${Math.max(0, 1 - sessionConsistency)},
        ${JSON.stringify({
          baseball_metrics: displayMetrics,
          baseball_data: baseball_data,
          sport_context: { primary_position, sport_variant, competition_level },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: sport_variant || "baseball",
          primary_position: primary_position,
          analysis_type: "baseball_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      baseball_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: sport_variant || "baseball",
      primary_position: primary_position,
      message: `${sport_variant || "Baseball"} Performance Index - ${primary_position.replace("_", " ").toUpperCase()}`,
    });
  } catch (error) {
    console.error("Baseball performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate baseball performance metrics" },
      { status: 500 },
    );
  }
}
