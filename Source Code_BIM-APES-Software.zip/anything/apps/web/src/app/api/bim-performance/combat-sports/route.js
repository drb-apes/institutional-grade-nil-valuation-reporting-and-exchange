import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { athleteId, combatType, performanceData, recoveryMetrics } = body;

    // Validate combat sport type
    if (!["mma", "boxing"].includes(combatType?.toLowerCase())) {
      return Response.json(
        { error: "Invalid combat type. Must be 'mma' or 'boxing'" },
        { status: 400 },
      );
    }

    // Calculate BVI Score based on combat sport
    const bviScore =
      combatType.toLowerCase() === "mma"
        ? calculateMMABVI(performanceData, recoveryMetrics)
        : calculateBoxingBVI(performanceData, recoveryMetrics);

    // Calculate tactical efficiency
    const tacticalEfficiency = calculateTacticalEfficiency(
      combatType,
      performanceData,
    );

    // Calculate recovery index
    const recoveryIndex = calculateRecoveryIndex(recoveryMetrics);

    // Store motion scan with combat-specific data
    const motionScan = await sql`
      INSERT INTO motion_scans (
        athlete_id, 
        scan_data, 
        ai_score, 
        motion_type, 
        metadata, 
        verification_status
      ) VALUES (
        ${athleteId},
        ${JSON.stringify({
          combat_type: combatType,
          bvi_score: bviScore,
          tactical_efficiency: tacticalEfficiency,
          recovery_index: recoveryIndex,
          performance_data: performanceData,
          recovery_metrics: recoveryMetrics,
          timestamp: new Date().toISOString(),
        })},
        ${bviScore.overall_score},
        ${`${combatType}_performance`},
        ${JSON.stringify({
          combat_discipline: combatType,
          analysis_version: "v2.1",
          coalition_tier: determineCoalitionTier(bviScore.overall_score),
        })},
        'verified'
      ) RETURNING *
    `;

    // Create asset simulation based on BVI performance
    const assetValue = calculateAssetValue(
      combatType,
      bviScore,
      tacticalEfficiency,
      recoveryIndex,
    );

    const assetSimulation = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        motion_scan_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athleteId},
        ${motionScan[0].id},
        ${assetValue.current_value},
        ${assetValue.roi_projection},
        ${assetValue.risk_score},
        ${JSON.stringify({
          combat_type: combatType,
          bvi_breakdown: bviScore,
          tactical_score: tacticalEfficiency,
          recovery_score: recoveryIndex,
          market_factors: assetValue.market_factors,
        })},
        ${JSON.stringify({
          primary_factors: [
            "bvi_score",
            "tactical_efficiency",
            "recovery_index",
          ],
          combat_multiplier: combatType === "mma" ? 2.8 : 2.3,
          risk_adjustments: assetValue.risk_adjustments,
        })}
      ) RETURNING *
    `;

    // Generate scouting pod recommendations
    const scoutingRecommendations = generateScoutingPodRecommendations(
      combatType,
      bviScore,
      tacticalEfficiency,
      recoveryIndex,
    );

    // Create coach feedback loop triggers
    const coachFeedback = generateCoachFeedbackTriggers(
      athleteId,
      combatType,
      bviScore,
      tacticalEfficiency,
      recoveryIndex,
    );

    return Response.json({
      success: true,
      combat_analysis: {
        combat_type: combatType,
        bvi_score: bviScore,
        tactical_efficiency: tacticalEfficiency,
        recovery_index: recoveryIndex,
        asset_valuation: {
          current_value: assetValue.current_value,
          roi_projection: assetValue.roi_projection,
          risk_score: assetValue.risk_score,
          coalition_tier: determineCoalitionTier(bviScore.overall_score),
        },
        scouting_recommendations: scoutingRecommendations,
        coach_feedback: coachFeedback,
      },
      motion_scan_id: motionScan[0].id,
      asset_simulation_id: assetSimulation[0].id,
    });
  } catch (error) {
    console.error("Combat sports BIM error:", error);
    return Response.json(
      {
        error: "Failed to process combat sports analysis",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// MMA BVI Score Calculation
function calculateMMABVI(performanceData, recoveryMetrics) {
  const {
    strikingAccuracy = 65,
    takedownEfficiency = 70,
    fightIQ = 75,
    significantStrikes = 0,
    takedownAttempts = 0,
    successfulTakedowns = 0,
    controlTime = 0,
    submissionAttempts = 0,
  } = performanceData;

  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    postTrainingRecovery = 60,
    heartRateVariability = 65,
  } = recoveryMetrics;

  // MMA-specific BVI components
  const strikingComponent = Math.min(100, strikingAccuracy * 1.2);
  const grapplingComponent = Math.min(
    100,
    (takedownEfficiency + submissionAttempts * 5) * 0.8,
  );
  const tacticalComponent = Math.min(100, fightIQ * 1.1);
  const recoveryComponent = Math.min(
    100,
    100 - (cortisolLevels + creatineKinase) / 2 + postTrainingRecovery,
  );

  // Weighted MMA BVI calculation
  const overallScore = Math.round(
    strikingComponent * 0.3 +
      grapplingComponent * 0.25 +
      tacticalComponent * 0.25 +
      recoveryComponent * 0.2,
  );

  return {
    overall_score: overallScore,
    components: {
      striking: Math.round(strikingComponent),
      grappling: Math.round(grapplingComponent),
      tactical: Math.round(tacticalComponent),
      recovery: Math.round(recoveryComponent),
    },
    metrics: {
      striking_accuracy: strikingAccuracy,
      takedown_success_rate:
        takedownAttempts > 0
          ? (successfulTakedowns / takedownAttempts) * 100
          : 0,
      control_percentage: controlTime,
      recovery_index: Math.round(recoveryComponent),
    },
  };
}

// Boxing BVI Score Calculation
function calculateBoxingBVI(performanceData, recoveryMetrics) {
  const {
    punchEfficiency = 70,
    ringControl = 65,
    situationalEfficiency = 75,
    cleanPunches = 0,
    totalPunches = 0,
    defensiveEfficiency = 60,
    ringGeneralship = 70,
  } = performanceData;

  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    fatigueMarkers = 45,
    postBoutRecovery = 65,
  } = recoveryMetrics;

  // Boxing-specific BVI components
  const offensiveComponent = Math.min(
    100,
    (punchEfficiency + ringGeneralship) * 0.6,
  );
  const defensiveComponent = Math.min(
    100,
    (defensiveEfficiency + ringControl) * 0.7,
  );
  const tacticalComponent = Math.min(100, situationalEfficiency * 1.1);
  const recoveryComponent = Math.min(
    100,
    100 - (cortisolLevels + fatigueMarkers) / 2 + postBoutRecovery,
  );

  // Weighted Boxing BVI calculation
  const overallScore = Math.round(
    offensiveComponent * 0.35 +
      defensiveComponent * 0.25 +
      tacticalComponent * 0.25 +
      recoveryComponent * 0.15,
  );

  return {
    overall_score: overallScore,
    components: {
      offensive: Math.round(offensiveComponent),
      defensive: Math.round(defensiveComponent),
      tactical: Math.round(tacticalComponent),
      recovery: Math.round(recoveryComponent),
    },
    metrics: {
      punch_accuracy:
        totalPunches > 0 ? (cleanPunches / totalPunches) * 100 : 0,
      ring_control_percentage: ringControl,
      defensive_rating: defensiveEfficiency,
      recovery_load: Math.round(recoveryComponent),
    },
  };
}

// Tactical Efficiency Calculation
function calculateTacticalEfficiency(combatType, performanceData) {
  if (combatType.toLowerCase() === "mma") {
    const {
      fightIQ = 75,
      adaptability = 70,
      pressureResponse = 65,
      positionTransitions = 60,
    } = performanceData;

    return {
      overall_efficiency: Math.round(
        (fightIQ + adaptability + pressureResponse + positionTransitions) / 4,
      ),
      components: {
        fight_iq: fightIQ,
        adaptability: adaptability,
        pressure_response: pressureResponse,
        position_control: positionTransitions,
      },
      tactical_grade: getTacticalGrade(
        (fightIQ + adaptability + pressureResponse + positionTransitions) / 4,
      ),
    };
  } else {
    const {
      effectiveAggression = 70,
      ringGeneralship = 65,
      defensivePositioning = 60,
      punchTiming = 75,
    } = performanceData;

    return {
      overall_efficiency: Math.round(
        (effectiveAggression +
          ringGeneralship +
          defensivePositioning +
          punchTiming) /
          4,
      ),
      components: {
        effective_aggression: effectiveAggression,
        ring_generalship: ringGeneralship,
        defensive_positioning: defensivePositioning,
        punch_timing: punchTiming,
      },
      tactical_grade: getTacticalGrade(
        (effectiveAggression +
          ringGeneralship +
          defensivePositioning +
          punchTiming) /
          4,
      ),
    };
  }
}

// Recovery Index Calculation
function calculateRecoveryIndex(recoveryMetrics) {
  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    sleepQuality = 70,
    hydrationStatus = 80,
    psychologicalState = 65,
    injuryStatus = 90,
  } = recoveryMetrics;

  // Inverse correlation for stress markers
  const stressScore = 100 - (cortisolLevels + creatineKinase) / 2;
  const wellnessScore =
    (sleepQuality + hydrationStatus + psychologicalState + injuryStatus) / 4;

  const overallRecovery = Math.round(stressScore * 0.4 + wellnessScore * 0.6);

  return {
    overall_recovery: overallRecovery,
    stress_markers: {
      cortisol_score: 100 - cortisolLevels,
      ck_score: 100 - creatineKinase,
      combined_stress: Math.round(stressScore),
    },
    wellness_factors: {
      sleep_quality: sleepQuality,
      hydration: hydrationStatus,
      psychological: psychologicalState,
      injury_status: injuryStatus,
    },
    recovery_grade: getRecoveryGrade(overallRecovery),
  };
}

// Asset Value Calculation for Combat Sports
function calculateAssetValue(
  combatType,
  bviScore,
  tacticalEfficiency,
  recoveryIndex,
) {
  const baseMultiplier = combatType === "mma" ? 2.8 : 2.3;
  const tierBase = combatType === "mma" ? 1200 : 1000;

  const compositeScore =
    bviScore.overall_score * 0.4 +
    tacticalEfficiency.overall_efficiency * 0.35 +
    recoveryIndex.overall_recovery * 0.25;

  const currentValue = tierBase + compositeScore * baseMultiplier * 10;
  const volatilityFactor = Math.max(
    0.1,
    1 - recoveryIndex.overall_recovery / 100,
  );
  const riskScore = Math.round(volatilityFactor * 100);

  const marketFactors = {
    combat_popularity: combatType === "mma" ? 0.85 : 0.75,
    performance_consistency: recoveryIndex.overall_recovery / 100,
    tactical_edge: tacticalEfficiency.overall_efficiency / 100,
    injury_risk: Math.max(
      0.1,
      (100 - recoveryIndex.wellness_factors.injury_status) / 100,
    ),
  };

  const roiProjection = Math.min(
    300,
    Math.max(
      -50,
      (compositeScore - 70) * 3 + marketFactors.combat_popularity * 50,
    ),
  );

  return {
    current_value: Math.round(currentValue),
    roi_projection: Math.round(roiProjection * 100) / 100,
    risk_score: riskScore,
    market_factors: marketFactors,
    risk_adjustments: {
      injury_risk_discount: marketFactors.injury_risk * 0.15,
      consistency_bonus: marketFactors.performance_consistency * 0.1,
      tactical_premium: marketFactors.tactical_edge * 0.08,
    },
  };
}

// Scouting Pod Recommendations
function generateScoutingPodRecommendations(
  combatType,
  bviScore,
  tacticalEfficiency,
  recoveryIndex,
) {
  const recommendations = [];

  // BVI-based recommendations
  if (bviScore.overall_score >= 85) {
    recommendations.push({
      type: "elite_prospect",
      priority: "high",
      message: `Elite ${combatType.toUpperCase()} prospect - Summit-tier coalition tracking recommended`,
      action: "immediate_scouting_activation",
    });
  } else if (bviScore.overall_score >= 70) {
    recommendations.push({
      type: "development_track",
      priority: "medium",
      message: `Solid ${combatType.toUpperCase()} fundamentals - Monitor tactical development`,
      action: "quarterly_assessment_cycle",
    });
  }

  // Tactical efficiency recommendations
  if (tacticalEfficiency.overall_efficiency < 60) {
    recommendations.push({
      type: "tactical_development",
      priority: "high",
      message:
        "Tactical efficiency below threshold - Coaching intervention required",
      action: "specialized_coaching_allocation",
    });
  }

  // Recovery protocol recommendations
  if (recoveryIndex.overall_recovery < 50) {
    recommendations.push({
      type: "recovery_protocol",
      priority: "urgent",
      message:
        "Critical recovery deficit - Medical assessment and protocol revision needed",
      action: "medical_intervention_required",
    });
  }

  return recommendations;
}

// Coach Feedback Loop Triggers
function generateCoachFeedbackTriggers(
  athleteId,
  combatType,
  bviScore,
  tacticalEfficiency,
  recoveryIndex,
) {
  const triggers = [];

  // Performance triggers
  if (bviScore.overall_score > 80) {
    triggers.push({
      trigger_type: "performance_milestone",
      threshold_met: "bvi_excellence",
      coaching_action: "advance_training_complexity",
      notification_priority: "medium",
    });
  }

  // Tactical development triggers
  if (tacticalEfficiency.overall_efficiency < 65) {
    triggers.push({
      trigger_type: "skill_deficit",
      threshold_met: "tactical_development_needed",
      coaching_action: "increase_tactical_focus",
      notification_priority: "high",
    });
  }

  // Recovery management triggers
  if (recoveryIndex.overall_recovery < 60) {
    triggers.push({
      trigger_type: "recovery_alert",
      threshold_met: "recovery_protocol_adjustment",
      coaching_action: "modify_training_load",
      notification_priority: "urgent",
    });
  }

  return {
    athlete_id: athleteId,
    combat_type: combatType,
    active_triggers: triggers,
    next_assessment: new Date(
      Date.now() + 7 * 24 * 60 * 60 * 1000,
    ).toISOString(), // 7 days
    coaching_priority: determinePriority(triggers),
  };
}

// Helper functions
function getTacticalGrade(score) {
  if (score >= 90) return "A+";
  if (score >= 80) return "A";
  if (score >= 70) return "B";
  if (score >= 60) return "C";
  return "D";
}

function getRecoveryGrade(score) {
  if (score >= 85) return "Excellent";
  if (score >= 70) return "Good";
  if (score >= 55) return "Fair";
  if (score >= 40) return "Poor";
  return "Critical";
}

function determineCoalitionTier(bviScore) {
  if (bviScore >= 85) return "Summit";
  if (bviScore >= 70) return "Elite";
  if (bviScore >= 55) return "Development";
  return "Foundation";
}

function determinePriority(triggers) {
  const urgentTriggers = triggers.filter(
    (t) => t.notification_priority === "urgent",
  );
  const highTriggers = triggers.filter(
    (t) => t.notification_priority === "high",
  );

  if (urgentTriggers.length > 0) return "urgent";
  if (highTriggers.length > 0) return "high";
  return "medium";
}
