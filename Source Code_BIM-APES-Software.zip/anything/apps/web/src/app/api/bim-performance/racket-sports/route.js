import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Shot quality and placement analysis
function calculateShotQuality(racketData, sport) {
  const shotAccuracy = racketData.shot_accuracy || 0.7;
  const shotPlacement = racketData.shot_placement_score || 0.65;
  const shotVariety = racketData.shot_variety_score || 0.6;

  switch (sport) {
    case "tennis":
      const firstServePercentage = racketData.first_serve_percentage || 0.65;
      const winnerToErrorRatio =
        racketData.winners / Math.max(racketData.unforced_errors || 1, 1);
      const ratioScore = Math.min(winnerToErrorRatio / 2, 1.0);

      return (
        shotAccuracy * 0.3 +
        shotPlacement * 0.25 +
        shotVariety * 0.2 +
        firstServePercentage * 0.15 +
        ratioScore * 0.1
      );

    case "pickleball":
      const thirdShotDropSuccess = racketData.third_shot_drop_success || 0.6;
      const dinkAccuracy = racketData.dink_accuracy || 0.7;
      const volleyControl = racketData.volley_control || 0.65;

      return (
        shotAccuracy * 0.25 +
        shotPlacement * 0.25 +
        thirdShotDropSuccess * 0.2 +
        dinkAccuracy * 0.15 +
        volleyControl * 0.15
      );

    default:
      return shotAccuracy * 0.5 + shotPlacement * 0.3 + shotVariety * 0.2;
  }
}

// Court coverage and movement analysis
function calculateCourtCoverage(racketData, sport) {
  const movementEfficiency = racketData.movement_efficiency || 0.7;
  const courtCoveragePercentage = racketData.court_coverage_percentage || 0.65;

  switch (sport) {
    case "tennis":
      const baselineRecovery = racketData.baseline_recovery_time || 2.5; // seconds
      const recoveryScore = Math.max(0, 1 - (baselineRecovery - 1.5) / 2);
      const netApproach = racketData.net_approach_success || 0.6;

      return (
        movementEfficiency * 0.4 +
        courtCoveragePercentage * 0.3 +
        recoveryScore * 0.2 +
        netApproach * 0.1
      );

    case "pickleball":
      const kitchenLineEfficiency = racketData.kitchen_line_efficiency || 0.75;
      const transitionSuccess = racketData.transition_success || 0.7;

      return (
        movementEfficiency * 0.3 +
        courtCoveragePercentage * 0.3 +
        kitchenLineEfficiency * 0.25 +
        transitionSuccess * 0.15
      );

    default:
      return movementEfficiency * 0.6 + courtCoveragePercentage * 0.4;
  }
}

// Pressure point performance (spike score focus)
function calculatePressurePerformance(racketData, sport) {
  switch (sport) {
    case "tennis":
      const breakPointConversion = racketData.break_point_conversion || 0.4;
      const tiebreakRecord = racketData.tiebreak_win_percentage || 0.5;
      const clutchShotSuccess = racketData.clutch_shot_success || 0.6;
      const serveUnderPressure = racketData.serve_under_pressure || 0.65;

      return (
        breakPointConversion * 0.3 +
        tiebreakRecord * 0.25 +
        clutchShotSuccess * 0.25 +
        serveUnderPressure * 0.2
      );

    case "pickleball":
      const gamePointPerformance = racketData.game_point_performance || 0.6;
      const sideoutEfficiency = racketData.sideout_efficiency || 0.7;
      const clutchDinks = racketData.clutch_dink_success || 0.65;

      return (
        gamePointPerformance * 0.4 +
        sideoutEfficiency * 0.35 +
        clutchDinks * 0.25
      );

    default:
      return racketData.pressure_performance || 0.6;
  }
}

// Match momentum and rally control
function calculateRallyControl(racketData, sport) {
  const rallyWinPercentage = racketData.rally_win_percentage || 0.6;
  const averageRallyLength = racketData.average_rally_length || 6;

  switch (sport) {
    case "tennis":
      const longRallySuccess = racketData.long_rally_success || 0.55; // 9+ shots
      const shortRallyControl = racketData.short_rally_control || 0.7; // 1-4 shots
      const rallyEndingShots = racketData.rally_ending_shot_success || 0.6;

      return (
        rallyWinPercentage * 0.4 +
        longRallySuccess * 0.2 +
        shortRallyControl * 0.25 +
        rallyEndingShots * 0.15
      );

    case "pickleball":
      const kitchenRallyControl = racketData.kitchen_rally_control || 0.65;
      const powerShotTiming = racketData.power_shot_timing || 0.6;
      const rallyInitiation = racketData.rally_initiation_success || 0.7;

      return (
        rallyWinPercentage * 0.35 +
        kitchenRallyControl * 0.3 +
        powerShotTiming * 0.2 +
        rallyInitiation * 0.15
      );

    default:
      return rallyWinPercentage;
  }
}

// Racket sport tactical efficiency
function calculateRacketTacticalEfficiency(racketData, sport) {
  const shotQuality = calculateShotQuality(racketData, sport);
  const courtCoverage = calculateCourtCoverage(racketData, sport);
  const rallyControl = calculateRallyControl(racketData, sport);

  return shotQuality * 0.4 + courtCoverage * 0.3 + rallyControl * 0.3;
}

// Racket sport spike score (clutch performance)
function calculateRacketSpikeScore(racketData, sport) {
  const pressurePerformance = calculatePressurePerformance(racketData, sport);
  const matchWinPercentage = racketData.match_win_percentage || 0.6;

  switch (sport) {
    case "tennis":
      const bagelsAndBreadsticks = racketData.bagel_breadstick_wins || 0; // 6-0, 6-1 sets
      const totalSets = racketData.total_sets_played || 1;
      const dominanceScore = Math.min(
        bagelsAndBreadsticks / (totalSets * 0.1),
        1.0,
      );

      const comebackWins = racketData.comeback_wins || 0; // From 2 sets down or match point
      const totalMatches = racketData.total_matches || 1;
      const clutchScore = Math.min(comebackWins / (totalMatches * 0.2), 1.0);

      return (
        pressurePerformance * 0.4 +
        dominanceScore * 0.3 +
        clutchScore * 0.2 +
        matchWinPercentage * 0.1
      );

    case "pickleball":
      const perfectGames = racketData.perfect_games || 0; // 11-0 games
      const totalGames = racketData.total_games_played || 1;
      const perfectionScore = Math.min(perfectGames / (totalGames * 0.05), 1.0);

      const comebackGames = racketData.comeback_games || 0; // From 6+ points down
      const resilienceScore = Math.min(
        comebackGames / (totalGames * 0.15),
        1.0,
      );

      return (
        pressurePerformance * 0.4 +
        perfectionScore * 0.25 +
        resilienceScore * 0.25 +
        matchWinPercentage * 0.1
      );

    default:
      return pressurePerformance;
  }
}

// Racket sport session consistency
async function calculateRacketSessionConsistency(athleteId, sport) {
  const recentSessions = await sql`
    SELECT simulation_data->'racket_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
    AND valuation_factors->>'sport' = ${sport}
    ORDER BY created_at DESC
    LIMIT 10
  `;

  if (recentSessions.length < 3) return 0.7;

  const spikeScores = recentSessions.map((s) => s.metrics?.spike_score || 0.6);

  const mean = spikeScores.reduce((a, b) => a + b, 0) / spikeScores.length;
  const variance =
    spikeScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    spikeScores.length;

  return Math.max(0, 1 - variance * 2.5);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { racket_data, sport, playing_style, competition_level } =
      await request.json();

    if (!racket_data || !sport) {
      return Response.json(
        { error: "Racket sport data and sport type required" },
        { status: 400 },
      );
    }

    const supportedSports = ["tennis", "pickleball"];
    if (!supportedSports.includes(sport)) {
      return Response.json(
        { error: `Sport must be one of: ${supportedSports.join(", ")}` },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate racket sport metrics
    const shotQuality = calculateShotQuality(racket_data, sport);
    const courtCoverage = calculateCourtCoverage(racket_data, sport);
    const rallyControl = calculateRallyControl(racket_data, sport);
    const pressurePerformance = calculatePressurePerformance(
      racket_data,
      sport,
    );
    const tacticalEfficiency = calculateRacketTacticalEfficiency(
      racket_data,
      sport,
    );
    const spikeScore = calculateRacketSpikeScore(racket_data, sport);
    const sessionConsistency = await calculateRacketSessionConsistency(
      athlete.id,
      sport,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      shot_quality: shotQuality,
      court_coverage: courtCoverage,
      rally_control: rallyControl,
      pressure_performance: pressurePerformance,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall racket sport performance index
    const weights = {
      shot_quality: 0.25,
      court_coverage: 0.2,
      rally_control: 0.2,
      pressure_performance: 0.2,
      tactical_efficiency: 0.15,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => !["session_consistency", "spike_score"].includes(key))
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display based on competition level
    const isProfessional =
      competition_level === "professional" || athlete.tier_level >= 4;
    const displayScale = isProfessional ? 100 : 85;

    const displayMetrics = {
      shot_quality: Math.round(shotQuality * displayScale),
      court_coverage: Math.round(courtCoverage * displayScale),
      rally_control: Math.round(rallyControl * displayScale),
      pressure_performance: Math.round(pressurePerformance * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isProfessional ? `professional_${sport}` : `amateur_${sport}`,
      sport: sport,
      playing_style: playing_style,
      timestamp: new Date().toISOString(),
    };

    // Generate sport-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      sport_specific_tips: [],
    };

    // Analyze strengths and weaknesses
    if (performanceMetrics.shot_quality >= 0.8) {
      insights.strengths.push("Exceptional shot quality and placement");
    } else if (performanceMetrics.shot_quality <= 0.6) {
      insights.improvements.push("Focus on shot accuracy and consistency");
    }

    if (performanceMetrics.pressure_performance >= 0.8) {
      insights.strengths.push("Excellent performance under pressure");
    } else if (performanceMetrics.pressure_performance <= 0.6) {
      insights.improvements.push(
        "Work on mental toughness and clutch performance",
      );
    }

    if (performanceMetrics.court_coverage >= 0.8) {
      insights.strengths.push("Outstanding court movement and coverage");
    } else if (performanceMetrics.court_coverage <= 0.6) {
      insights.improvements.push("Improve footwork and court positioning");
    }

    // Sport-specific tips
    switch (sport) {
      case "tennis":
        if (performanceMetrics.shot_quality <= 0.6) {
          insights.sport_specific_tips.push(
            "Practice crosscourt consistency and depth control",
          );
        }
        if (performanceMetrics.pressure_performance <= 0.6) {
          insights.sport_specific_tips.push(
            "Work on serving under pressure and break point conversion",
          );
        }
        if (performanceMetrics.rally_control <= 0.6) {
          insights.sport_specific_tips.push(
            "Focus on rally construction and point patterns",
          );
        }

        if (playing_style) {
          if (playing_style.includes("aggressive")) {
            insights.sport_specific_tips.push(
              "Balance aggression with consistency, especially on important points",
            );
          } else if (playing_style.includes("defensive")) {
            insights.sport_specific_tips.push(
              "Develop more offensive weapons to finish points",
            );
          } else if (playing_style.includes("all-court")) {
            insights.sport_specific_tips.push(
              "Master transitions between baseline and net play",
            );
          }
        }
        break;

      case "pickleball":
        if (performanceMetrics.shot_quality <= 0.6) {
          insights.sport_specific_tips.push(
            "Practice third shot drops and kitchen line control",
          );
        }
        if (performanceMetrics.pressure_performance <= 0.6) {
          insights.sport_specific_tips.push(
            "Work on side-out consistency and game point execution",
          );
        }
        if (performanceMetrics.court_coverage <= 0.6) {
          insights.sport_specific_tips.push(
            "Focus on kitchen line positioning and transition movements",
          );
        }

        if (playing_style) {
          if (playing_style.includes("power")) {
            insights.sport_specific_tips.push(
              "Develop touch and finesse to complement power game",
            );
          } else if (playing_style.includes("finesse")) {
            insights.sport_specific_tips.push(
              "Add strategic aggression to finish rallies",
            );
          } else if (playing_style.includes("defensive")) {
            insights.sport_specific_tips.push(
              "Work on counterattack opportunities from defensive positions",
            );
          }
        }
        break;
    }

    // General improvement tips
    if (performanceMetrics.session_consistency <= 0.6) {
      insights.improvements.push("Focus on consistent preparation and routine");
      insights.sport_specific_tips.push(
        "Develop pre-point and pre-serve routines for consistency",
      );
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.4, 1.0)}, -- Higher ROI for spike performance
        ${Math.max(0, 1 - sessionConsistency)},
        ${JSON.stringify({
          racket_metrics: displayMetrics,
          racket_data: racket_data,
          sport_context: { sport, playing_style, competition_level },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: sport,
          analysis_type: "racket_sports_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      racket_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: sport,
      playing_style: playing_style,
      message: `${sport.charAt(0).toUpperCase() + sport.slice(1)} Spike Score Analysis - ${playing_style || "All Styles"} Performance`,
    });
  } catch (error) {
    console.error("Racket sports performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate racket sports performance metrics" },
      { status: 500 },
    );
  }
}
