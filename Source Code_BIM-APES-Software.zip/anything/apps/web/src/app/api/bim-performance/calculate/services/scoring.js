// /apps/web/src/app/api/bim-performance/calculate/services/scoring.js

// **SCALING UTILITIES**
export function scaleMetric(normalizedValue, scale) {
  return Math.round(normalizedValue * scale * 100) / 100;
}

export function calculateOverallScore(metrics, scale) {
  const weights = [0.25, 0.25, 0.2, 0.15, 0.15]; // BVI, Tactical, Recovery, Spike, Consistency
  const weightedSum = metrics.reduce(
    (sum, metric, index) => sum + metric * weights[index],
    0,
  );
  return scaleMetric(weightedSum, scale);
}

// **NORMALIZED OVERALL SCORE CALCULATION**
export function calculateOverallScore_Normalized(metrics) {
  const weights = [0.25, 0.25, 0.2, 0.15, 0.15]; // BVI, Tactical, Recovery, Spike, Consistency
  const weightedSum = metrics.reduce(
    (sum, metric, index) => sum + metric * weights[index],
    0,
  );
  return Math.max(0, Math.min(1, weightedSum));
}
