export async function POST(request) {
  try {
    const body = await request.json();
    const { contestantId, performanceData, biometricData, competitionContext } =
      body;

    if (!contestantId || !performanceData) {
      return Response.json(
        { error: "Missing required fields: contestantId, performanceData" },
        { status: 400 },
      );
    }

    // Calculate Pageantry Performance Units
    const performanceUnits =
      calculatePageantryPerformanceUnits(performanceData);

    // Calculate Biometric Scores
    const biometricScores = calculateBiometricScores(biometricData || {});

    // Calculate Core Indices
    const indices = calculatePageantryIndices(
      performanceUnits,
      biometricScores,
    );

    // Calculate Fair-Value NIL
    const nilValuation = calculatePageantryNIL(
      performanceUnits,
      biometricScores,
      indices,
      competitionContext,
    );

    return Response.json({
      success: true,
      contestantId,
      performanceUnits,
      biometricScores,
      indices,
      nilValuation,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Pageantry BIM Performance calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate pageantry performance metrics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculatePageantryPerformanceUnits(data) {
  const {
    stagePresenceSegments = [],
    questionResponses = [],
    posePrecisionMoments = [],
    walkTransitions = [],
    audienceResponseData = [],
  } = data;

  // Stage Presence Units (SPU)
  const stageQuality = stagePresenceSegments.reduce((sum, segment) => {
    const confidence = segment.confidenceScore / 10;
    const poise = segment.poiseScore / 10;
    const charisma = segment.charismaScore / 10;
    return sum + (confidence + poise + charisma) / 3;
  }, 0);
  const spu = stageQuality / Math.max(stagePresenceSegments.length, 1);

  // Question Delivery Units (QDU)
  const questionQuality = questionResponses.reduce((sum, response) => {
    const clarity = response.clarityScore / 10;
    const thoughtfulness = response.thoughtfulnessScore / 10;
    const authenticity = response.authenticityScore / 10;
    return sum + (clarity + thoughtfulness + authenticity) / 3;
  }, 0);
  const qdu = questionQuality / Math.max(questionResponses.length, 1);

  // Pose Composure Units (PCU)
  const poseQuality = posePrecisionMoments.reduce((sum, pose) => {
    const stability = pose.stabilityScore / 100;
    const grace = pose.graceScore / 10;
    const timing = pose.timingScore / 10;
    return sum + (stability + grace + timing) / 3;
  }, 0);
  const pcu = poseQuality / Math.max(posePrecisionMoments.length, 1);

  // Walk Transition Units (WTU)
  const walkQuality = walkTransitions.reduce((sum, transition) => {
    const fluidity = transition.fluidityScore / 10;
    const posture = transition.postureScore / 10;
    const rhythm = transition.rhythmScore / 10;
    return sum + (fluidity + posture + rhythm) / 3;
  }, 0);
  const wtu = walkQuality / Math.max(walkTransitions.length, 1);

  // Audience Response Units (ARU)
  const audienceImpact = audienceResponseData.reduce((sum, response) => {
    const engagement = response.engagementLevel / 100;
    const enthusiasm = response.enthusiasmScore / 10;
    return sum + (engagement + enthusiasm) / 2;
  }, 0);
  const aru = audienceImpact / Math.max(audienceResponseData.length, 1);

  return {
    SPU: Math.min(spu, 1.0),
    QDU: Math.min(qdu, 1.0),
    PCU: Math.min(pcu, 1.0),
    WTU: Math.min(wtu, 1.0),
    ARU: Math.min(aru, 1.0),
    totalUnits:
      stagePresenceSegments.length +
      questionResponses.length +
      posePrecisionMoments.length +
      walkTransitions.length +
      audienceResponseData.length,
  };
}

function calculateBiometricScores(data) {
  const {
    composureStability = 0.94,
    breathControl = 0.91,
    postureConsistency = 0.93,
    voiceClarity = 0.89,
    stressManagement = 0.87,
  } = data;

  return {
    composureStability: Math.min(composureStability, 1.0),
    breathControl: Math.min(breathControl, 1.0),
    postureConsistency: Math.min(postureConsistency, 1.0),
    voiceClarity: Math.min(voiceClarity, 1.0),
    stressManagement: Math.min(stressManagement, 1.0),
    overallBiometric:
      (composureStability +
        breathControl +
        postureConsistency +
        voiceClarity +
        stressManagement) /
      5,
  };
}

function calculatePageantryIndices(performanceUnits, biometricScores) {
  // Stage Presence Index (SPI)
  const spi =
    performanceUnits.SPU * 0.5 +
    performanceUnits.WTU * 0.3 +
    biometricScores.composureStability * 0.2;

  // Communication Strength Index (CSI)
  const csi = performanceUnits.QDU * 0.6 + biometricScores.voiceClarity * 0.4;

  // Queen Excellence Index (QEI)
  const qei =
    performanceUnits.SPU * 0.25 +
    performanceUnits.QDU * 0.25 +
    performanceUnits.PCU * 0.25 +
    performanceUnits.WTU * 0.15 +
    performanceUnits.ARU * 0.1;

  // Audience Resonance Index (ARI)
  const ari = performanceUnits.ARU * 0.6 + performanceUnits.SPU * 0.4;

  return {
    SPI: Math.min(spi, 1.0),
    CSI: Math.min(csi, 1.0),
    QEI: Math.min(qei, 1.0),
    ARI: Math.min(ari, 1.0),
  };
}

function calculatePageantryNIL(
  performanceUnits,
  biometricScores,
  indices,
  competitionContext = {},
) {
  // Base performance score (40%)
  const performanceScore =
    performanceUnits.SPU * 0.3 +
    performanceUnits.QDU * 0.25 +
    performanceUnits.PCU * 0.2 +
    performanceUnits.WTU * 0.15 +
    performanceUnits.ARU * 0.1;

  // Biometric score (25%)
  const biometricScore = biometricScores.overallBiometric;

  // Engagement score (20%) - based on competition level
  const competitionMultiplier = {
    miss_universe: 2.0,
    miss_usa: 1.8,
    miss_teen_usa: 1.5,
    state: 1.2,
    local: 1.0,
  };
  const compMultiplier =
    competitionMultiplier[competitionContext.competitionLevel] || 1.0;
  const engagementScore = indices.ARI * compMultiplier;

  // Brand fit score (15%)
  const brandFitScore = indices.QEI * 0.6 + indices.SPI * 0.4;

  // Calculate FV-NIL
  const fvNIL =
    performanceScore * 0.4 +
    biometricScore * 0.25 +
    Math.min(engagementScore, 1.0) * 0.2 +
    brandFitScore * 0.15;

  // Base NIL value (normalized to $200K max for elite pageant winners)
  const baseNILValue = fvNIL * 200000;

  return {
    fvNIL: Math.min(fvNIL, 1.0),
    estimatedValue: Math.round(baseNILValue),
    performanceComponent: performanceScore,
    biometricComponent: biometricScore,
    engagementComponent: Math.min(engagementScore, 1.0),
    brandFitComponent: brandFitScore,
    tier: determinePageantryTier(fvNIL),
    organization: competitionContext.organization || "Independent",
  };
}

function determinePageantryTier(fvNIL) {
  if (fvNIL >= 0.92) return "Elite Winner";
  if (fvNIL >= 0.85) return "National Finalist";
  if (fvNIL >= 0.75) return "State Winner";
  if (fvNIL >= 0.65) return "Regional Finalist";
  if (fvNIL >= 0.55) return "Local Winner";
  return "Developing Contestant";
}

export async function GET() {
  return Response.json({
    message: "Pageantry BIM Performance Calculation Engine",
    version: "1.0.0",
    performanceUnits: ["SPU", "QDU", "PCU", "WTU", "ARU"],
    indices: ["SPI", "CSI", "QEI", "ARI"],
    method: "POST",
    requiredFields: ["contestantId", "performanceData"],
  });
}
