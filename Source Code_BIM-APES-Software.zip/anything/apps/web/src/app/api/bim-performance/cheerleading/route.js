export async function POST(request) {
  try {
    const body = await request.json();
    const { performerId, performanceData, biometricData, eventContext } = body;

    if (!performerId || !performanceData) {
      return Response.json(
        { error: "Missing required fields: performerId, performanceData" },
        { status: 400 },
      );
    }

    // Calculate Cheerleading/Dance Performance Units
    const performanceUnits = calculateCheerPerformanceUnits(performanceData);

    // Calculate Biometric Scores
    const biometricScores = calculateBiometricScores(biometricData || {});

    // Calculate Core Indices
    const indices = calculateCheerIndices(performanceUnits, biometricScores);

    // Calculate Fair-Value NIL
    const nilValuation = calculateCheerNIL(
      performanceUnits,
      biometricScores,
      indices,
      eventContext,
    );

    return Response.json({
      success: true,
      performerId,
      performanceUnits,
      biometricScores,
      indices,
      nilValuation,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Cheerleading BIM Performance calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate cheerleading performance metrics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateCheerPerformanceUnits(data) {
  const {
    stuntExecutions = [],
    tumblePasses = [],
    formationTransitions = [],
    synchronizationScore = 0,
    crowdImpactScore = 0,
  } = data;

  // Stunt Execution Units (SEU)
  const stuntQuality = stuntExecutions.reduce((sum, stunt) => {
    const cleanExecution = stunt.cleanLanding ? 1.0 : 0.7;
    const difficultyMultiplier = stunt.difficulty / 10;
    return sum + cleanExecution * difficultyMultiplier;
  }, 0);
  const seu = stuntQuality / Math.max(stuntExecutions.length, 1);

  // Tumble Precision Units (TPU)
  const tumbleQuality = tumblePasses.reduce((sum, pass) => {
    const landingPrecision = pass.stickLanding ? 1.0 : 0.8;
    const formScore = pass.formScore / 10;
    return sum + landingPrecision * formScore;
  }, 0);
  const tpu = tumbleQuality / Math.max(tumblePasses.length, 1);

  // Synchronization Units (SU)
  const su = synchronizationScore / 100;

  // Formation Transition Units (FTU)
  const transitionQuality = formationTransitions.reduce((sum, transition) => {
    const speedScore = transition.transitionSpeed / 10;
    const positionAccuracy = transition.positionAccuracy / 100;
    return sum + speedScore * positionAccuracy;
  }, 0);
  const ftu = transitionQuality / Math.max(formationTransitions.length, 1);

  // Crowd Impact Units (CIU)
  const ciu = crowdImpactScore / 100;

  return {
    SEU: Math.min(seu, 1.0),
    TPU: Math.min(tpu, 1.0),
    SU: Math.min(su, 1.0),
    FTU: Math.min(ftu, 1.0),
    CIU: Math.min(ciu, 1.0),
    totalUnits:
      stuntExecutions.length +
      tumblePasses.length +
      formationTransitions.length,
  };
}

function calculateBiometricScores(data) {
  const {
    hrvStability = 0.85,
    breathEfficiency = 0.9,
    motionPrecision = 0.88,
    postureQuality = 0.92,
    fatigueLevel = 0.15,
  } = data;

  return {
    hrvStability: Math.min(hrvStability, 1.0),
    breathEfficiency: Math.min(breathEfficiency, 1.0),
    motionPrecision: Math.min(motionPrecision, 1.0),
    postureQuality: Math.min(postureQuality, 1.0),
    fatigueLevel: Math.min(fatigueLevel, 1.0),
    overallBiometric:
      ((hrvStability + breathEfficiency + motionPrecision + postureQuality) /
        4) *
      (1 - fatigueLevel * 0.2),
  };
}

function calculateCheerIndices(performanceUnits, biometricScores) {
  // Performance Precision Index (PPI)
  const ppi =
    performanceUnits.SEU * 0.3 +
    performanceUnits.TPU * 0.25 +
    performanceUnits.SU * 0.25 +
    performanceUnits.FTU * 0.2;

  // Stunt Risk Index (SRI) - lower is better
  const stuntRiskFactors = [
    1.0 - performanceUnits.SEU,
    1.0 - biometricScores.motionPrecision,
    biometricScores.fatigueLevel,
  ];
  const sri =
    stuntRiskFactors.reduce((a, b) => a + b, 0) / stuntRiskFactors.length;

  // Synchronization Index (SI)
  const si = performanceUnits.SU * 0.6 + performanceUnits.FTU * 0.4;

  // Crowd Momentum Index (CMI)
  const cmi = performanceUnits.CIU * 0.7 + ppi * 0.3;

  return {
    PPI: Math.min(ppi, 1.0),
    SRI: Math.min(sri, 1.0),
    SI: Math.min(si, 1.0),
    CMI: Math.min(cmi, 1.0),
  };
}

function calculateCheerNIL(
  performanceUnits,
  biometricScores,
  indices,
  eventContext = {},
) {
  // Base performance score (40%)
  const performanceScore =
    performanceUnits.SEU * 0.25 +
    performanceUnits.TPU * 0.2 +
    performanceUnits.SU * 0.25 +
    performanceUnits.FTU * 0.15 +
    performanceUnits.CIU * 0.15;

  // Biometric score (25%)
  const biometricScore = biometricScores.overallBiometric;

  // Engagement score (20%) - based on crowd impact and event type
  const eventTypeMultiplier = {
    nationals: 1.5,
    regional: 1.2,
    local: 1.0,
  };
  const eventMultiplier = eventTypeMultiplier[eventContext.eventType] || 1.0;
  const engagementScore = performanceUnits.CIU * eventMultiplier;

  // Brand fit score (15%) - based on consistency and marketability
  const brandFitScore =
    indices.PPI * 0.5 + (1.0 - indices.SRI) * 0.3 + indices.SI * 0.2;

  // Calculate FV-NIL
  const fvNIL =
    performanceScore * 0.4 +
    biometricScore * 0.25 +
    engagementScore * 0.2 +
    brandFitScore * 0.15;

  // Base NIL value (normalized to $150K max for elite performers)
  const baseNILValue = fvNIL * 150000;

  return {
    fvNIL: Math.min(fvNIL, 1.0),
    estimatedValue: Math.round(baseNILValue),
    performanceComponent: performanceScore,
    biometricComponent: biometricScore,
    engagementComponent: engagementScore,
    brandFitComponent: brandFitScore,
    tier: determineCheerTier(fvNIL),
  };
}

function determineCheerTier(fvNIL) {
  if (fvNIL >= 0.9) return "Elite";
  if (fvNIL >= 0.8) return "All-Star";
  if (fvNIL >= 0.7) return "Advanced";
  if (fvNIL >= 0.6) return "Intermediate";
  return "Developing";
}

export async function GET() {
  return Response.json({
    message: "Cheerleading/Dance BIM Performance Calculation Engine",
    version: "1.0.0",
    performanceUnits: ["SEU", "TPU", "SU", "FTU", "CIU"],
    indices: ["PPI", "SRI", "SI", "CMI"],
    method: "POST",
    requiredFields: ["performerId", "performanceData"],
  });
}
