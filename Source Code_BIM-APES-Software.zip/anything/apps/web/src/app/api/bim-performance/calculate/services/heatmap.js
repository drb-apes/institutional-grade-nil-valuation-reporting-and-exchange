// Enhanced 10×10 Grid Biomechanical Heatmap with Advanced Kinematic Analysis
import sql from "@/app/api/utils/sql";

// 10×10 Grid Body Mapping (100 precision zones)
const BODY_GRID_MAPPING = {
  // Head & Neck (Rows 0-1)
  head: { rows: [0, 1], cols: [4, 5, 6, 7] },
  neck: { rows: [1], cols: [4, 5, 6, 7] },

  // Upper Torso (Rows 2-4)
  shoulders: { rows: [2, 3], cols: [2, 3, 8, 9] },
  chest: { rows: [2, 3, 4], cols: [4, 5, 6, 7] },
  upper_back: { rows: [2, 3, 4], cols: [4, 5, 6, 7] },

  // Arms (Rows 2-6)
  upper_arms: { rows: [3, 4, 5], cols: [1, 2, 8, 9] },
  elbows: { rows: [4, 5], cols: [1, 2, 8, 9] },
  forearms: { rows: [5, 6], cols: [0, 1, 8, 9] },
  wrists: { rows: [6], cols: [0, 1, 8, 9] },

  // Core & Lower Torso (Rows 4-6)
  core: { rows: [4, 5, 6], cols: [3, 4, 5, 6, 7] },
  hips: { rows: [6], cols: [3, 4, 5, 6, 7] },

  // Legs (Rows 6-9)
  upper_legs: { rows: [6, 7, 8], cols: [2, 3, 7, 8] },
  knees: { rows: [7, 8], cols: [2, 3, 7, 8] },
  lower_legs: { rows: [8, 9], cols: [2, 3, 7, 8] },
  ankles: { rows: [9], cols: [2, 3, 7, 8] },
};

// Enhanced Kinematic Analysis Functions
function calculateJerk(motion_data, joint_name) {
  if (!motion_data.frame_sequence || motion_data.frame_sequence.length < 3) {
    return 0;
  }

  const frames = motion_data.frame_sequence;
  let total_jerk = 0;
  let jerk_samples = 0;

  // Calculate jerk from acceleration changes
  for (let i = 2; i < frames.length; i++) {
    const current_accel = frames[i].joints?.[joint_name]?.acceleration || 0;
    const prev_accel = frames[i - 1].joints?.[joint_name]?.acceleration || 0;
    const prev_prev_accel =
      frames[i - 2].joints?.[joint_name]?.acceleration || 0;

    // Jerk = rate of change of acceleration
    const jerk_magnitude = Math.abs(
      current_accel - 2 * prev_accel + prev_prev_accel,
    );
    total_jerk += jerk_magnitude;
    jerk_samples++;
  }

  return jerk_samples > 0 ? total_jerk / jerk_samples : 0;
}

function calculateAngleChange(motion_data, joint_name) {
  if (!motion_data.frame_sequence || motion_data.frame_sequence.length < 2) {
    return 0;
  }

  const frames = motion_data.frame_sequence;
  let total_angle_change = 0;
  let angle_samples = 0;

  for (let i = 1; i < frames.length; i++) {
    const current_angle = frames[i].joints?.[joint_name]?.angle || 0;
    const prev_angle = frames[i - 1].joints?.[joint_name]?.angle || 0;

    const angle_delta = Math.abs(current_angle - prev_angle);
    total_angle_change += angle_delta;
    angle_samples++;
  }

  return angle_samples > 0 ? total_angle_change / angle_samples : 0;
}

function smoothVelocity(motion_data, joint_name, window_size = 5) {
  if (
    !motion_data.frame_sequence ||
    motion_data.frame_sequence.length < window_size
  ) {
    return motion_data.biomechanics?.velocity_peak || 0;
  }

  const frames = motion_data.frame_sequence;
  let smoothed_velocities = [];

  for (let i = window_size - 1; i < frames.length; i++) {
    let velocity_sum = 0;
    for (let j = 0; j < window_size; j++) {
      velocity_sum += frames[i - j].joints?.[joint_name]?.velocity || 0;
    }
    smoothed_velocities.push(velocity_sum / window_size);
  }

  return smoothed_velocities.length > 0 ? Math.max(...smoothed_velocities) : 0;
}

// ML-Based Stress Prediction Model
function predictJointStress(kinematic_data, sport_type, recovery_factor) {
  const {
    velocity,
    acceleration,
    jerk,
    angle_change,
    power_output,
    pose_confidence,
  } = kinematic_data;

  // Sport-specific biomechanical coefficients
  const SPORT_COEFFICIENTS = {
    wrestling: {
      velocity_weight: 0.25,
      acceleration_weight: 0.3,
      jerk_weight: 0.2,
      angle_weight: 0.15,
      power_weight: 0.1,
    },
    rugby: {
      velocity_weight: 0.2,
      acceleration_weight: 0.35,
      jerk_weight: 0.25,
      angle_weight: 0.1,
      power_weight: 0.1,
    },
    soccer: {
      velocity_weight: 0.3,
      acceleration_weight: 0.25,
      jerk_weight: 0.15,
      angle_weight: 0.2,
      power_weight: 0.1,
    },
    basketball: {
      velocity_weight: 0.25,
      acceleration_weight: 0.25,
      jerk_weight: 0.2,
      angle_weight: 0.15,
      power_weight: 0.15,
    },
    tennis: {
      velocity_weight: 0.2,
      acceleration_weight: 0.2,
      jerk_weight: 0.3,
      angle_weight: 0.2,
      power_weight: 0.1,
    },
    football: {
      velocity_weight: 0.25,
      acceleration_weight: 0.3,
      jerk_weight: 0.25,
      angle_weight: 0.1,
      power_weight: 0.1,
    },
  };

  const coeffs = SPORT_COEFFICIENTS[sport_type] || SPORT_COEFFICIENTS.soccer;

  // Normalize inputs (0-1 scale)
  const norm_velocity = Math.min(velocity / 10.0, 1.0);
  const norm_acceleration = Math.min(acceleration / 50.0, 1.0);
  const norm_jerk = Math.min(jerk / 100.0, 1.0);
  const norm_angle = Math.min(angle_change / 180.0, 1.0);
  const norm_power = Math.min(power_output / 1000.0, 1.0);

  // ML-weighted stress prediction
  let stress_prediction =
    norm_velocity * coeffs.velocity_weight +
    norm_acceleration * coeffs.acceleration_weight +
    norm_jerk * coeffs.jerk_weight +
    norm_angle * coeffs.angle_weight +
    norm_power * coeffs.power_weight;

  // Apply recovery factor and pose confidence adjustments
  stress_prediction *= 1.0 - recovery_factor * 0.3;
  stress_prediction *= pose_confidence || 0.85;

  // Ensure 0.0-0.7 range
  return Math.min(Math.max(stress_prediction, 0.0), 0.7);
}

// Enhanced 10×10 Grid Heatmap Generator
export async function calculateEnhancedBiomechanicalHeatmap(
  motion_data,
  recovery_index,
  tactical_efficiency,
  athlete_id,
) {
  try {
    // Initialize 10×10 grid (100 zones)
    let heatmap_grid = Array(10)
      .fill()
      .map(() => Array(10).fill(0.0));

    const sport_type = motion_data.sport_type || "soccer";
    const recovery_factor = Math.min(recovery_index / 100.0, 1.0);

    // Enhanced kinematic analysis for each joint
    const joint_analysis = {};
    const primary_joints = [
      "ankle_left",
      "ankle_right",
      "knee_left",
      "knee_right",
      "hip_left",
      "hip_right",
      "shoulder_left",
      "shoulder_right",
      "elbow_left",
      "elbow_right",
      "wrist_left",
      "wrist_right",
    ];

    for (const joint of primary_joints) {
      const velocity = smoothVelocity(motion_data, joint);
      const acceleration = motion_data.biomechanics?.acceleration_max || 0;
      const jerk = calculateJerk(motion_data, joint);
      const angle_change = calculateAngleChange(motion_data, joint);
      const power_output = motion_data.biomechanics?.power_output || 0;
      const pose_confidence = motion_data.pose_confidence || 0.85;

      joint_analysis[joint] = {
        velocity,
        acceleration,
        jerk,
        angle_change,
        power_output,
        pose_confidence,
        stress_score: predictJointStress(
          {
            velocity,
            acceleration,
            jerk,
            angle_change,
            power_output,
            pose_confidence,
          },
          sport_type,
          recovery_factor,
        ),
      };
    }

    // Map joint stress to 10×10 grid zones
    for (const [body_part, grid_mapping] of Object.entries(BODY_GRID_MAPPING)) {
      let region_stress = 0.0;
      let joint_count = 0;

      // Aggregate stress from related joints
      for (const joint of primary_joints) {
        if (
          joint.includes(body_part.split("_")[0]) ||
          (body_part === "core" && joint.includes("hip")) ||
          (body_part === "chest" && joint.includes("shoulder"))
        ) {
          region_stress += joint_analysis[joint]?.stress_score || 0;
          joint_count++;
        }
      }

      const average_stress = joint_count > 0 ? region_stress / joint_count : 0;

      // Fill grid zones for this body part
      for (const row of grid_mapping.rows) {
        for (const col of grid_mapping.cols) {
          if (row < 10 && col < 10) {
            heatmap_grid[row][col] = Math.max(
              heatmap_grid[row][col],
              average_stress,
            );
          }
        }
      }
    }

    // Generate enhanced SVG visualization
    const svg_body = generateEnhancedBodySVG(heatmap_grid, joint_analysis);

    // Calculate stress distribution and injury risk
    const stress_zones = [];
    const high_stress_zones = [];
    let total_stress = 0;

    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        const stress_value = heatmap_grid[row][col];
        total_stress += stress_value;

        if (stress_value > 0.0) {
          stress_zones.push({
            zone_id: `${row}${col}`,
            stress_level: stress_value,
            risk_category:
              stress_value >= 0.6
                ? "high"
                : stress_value >= 0.4
                  ? "moderate"
                  : "low",
          });
        }

        if (stress_value >= 0.6) {
          high_stress_zones.push({
            zone_id: `${row}${col}`,
            stress_level: stress_value,
            injury_risk: calculateInjuryRisk(stress_value, recovery_factor),
          });
        }
      }
    }

    const average_stress = total_stress / 100.0;

    return {
      heatmap_type: "enhanced_10x10_grid",
      grid_data: heatmap_grid,
      svg_visualization: svg_body,
      joint_analysis,
      stress_zones,
      high_stress_zones,
      average_stress,
      injury_risk_score: calculateOverallInjuryRisk(
        high_stress_zones,
        recovery_factor,
      ),
      recovery_adjustment: recovery_factor,
      sport_specific: sport_type,
      total_zones_analyzed: 100,
      precision_level: "institutional_grade",
      enhanced_features: {
        jerk_analysis: true,
        angle_tracking: true,
        ml_stress_prediction: true,
        sport_specific_coefficients: true,
      },
    };
  } catch (error) {
    console.error("Enhanced heatmap calculation error:", error);
    return await calculateBiomechanicalHeatmap(
      motion_data,
      recovery_index,
      tactical_efficiency,
      athlete_id,
    );
  }
}

function generateEnhancedBodySVG(grid_data, joint_analysis) {
  let svg = `<svg viewBox="0 0 300 400" xmlns="http://www.w3.org/2000/svg">`;

  // Generate 10×10 grid overlay on body diagram
  for (let row = 0; row < 10; row++) {
    for (let col = 0; col < 10; col++) {
      const stress = grid_data[row][col];
      const color = getStressColor(stress);
      const x = 30 + col * 24;
      const y = 20 + row * 36;

      if (stress > 0.01) {
        svg += `<rect x="${x}" y="${y}" width="24" height="36" fill="${color}" opacity="0.7" stroke="#333" stroke-width="0.5"/>`;

        // Add stress value text for high zones
        if (stress >= 0.4) {
          svg += `<text x="${x + 12}" y="${y + 20}" text-anchor="middle" font-size="8" fill="white">${(stress * 100).toFixed(0)}</text>`;
        }
      }
    }
  }

  // Add joint markers with enhanced data
  const joint_positions = {
    ankle_left: { x: 90, y: 360 },
    ankle_right: { x: 210, y: 360 },
    knee_left: { x: 90, y: 280 },
    knee_right: { x: 210, y: 280 },
    hip_left: { x: 110, y: 200 },
    hip_right: { x: 190, y: 200 },
    shoulder_left: { x: 80, y: 100 },
    shoulder_right: { x: 220, y: 100 },
  };

  for (const [joint, pos] of Object.entries(joint_positions)) {
    const analysis = joint_analysis[joint];
    if (analysis) {
      const color = getStressColor(analysis.stress_score);
      svg += `<circle cx="${pos.x}" cy="${pos.y}" r="6" fill="${color}" stroke="#000" stroke-width="1"/>`;
      svg += `<text x="${pos.x}" y="${pos.y - 12}" text-anchor="middle" font-size="7" fill="#000">${joint.replace("_", " ")}</text>`;
    }
  }

  svg += `</svg>`;
  return svg;
}

function getStressColor(stress_value) {
  if (stress_value >= 0.6) return "#dc2626"; // High stress - red
  if (stress_value >= 0.4) return "#f59e0b"; // Moderate stress - orange
  if (stress_value >= 0.2) return "#fbbf24"; // Low stress - yellow
  if (stress_value > 0.0) return "#84cc16"; // Minimal stress - green
  return "#f3f4f6"; // No stress - light gray
}

function calculateInjuryRisk(stress_value, recovery_factor) {
  const base_risk = stress_value * 100;
  const recovery_adjustment = (1.0 - recovery_factor) * 20;
  return Math.min(base_risk + recovery_adjustment, 100);
}

function calculateOverallInjuryRisk(high_stress_zones, recovery_factor) {
  if (high_stress_zones.length === 0) return 0;

  const average_zone_risk =
    high_stress_zones.reduce((sum, zone) => sum + zone.injury_risk, 0) /
    high_stress_zones.length;
  const zone_count_factor = Math.min(high_stress_zones.length / 5, 1.0) * 10;

  return Math.min(average_zone_risk + zone_count_factor, 100);
}

// **HEATMAP VISUALIZATION UTILITIES**
function generateHeatmapColors(stressValues) {
  const colorMap = {};

  Object.keys(stressValues).forEach((zone) => {
    const stress = stressValues[zone];
    if (stress >= 0.6) {
      colorMap[zone] = "#FF4444"; // Red - High stress
    } else if (stress >= 0.4) {
      colorMap[zone] = "#FFA500"; // Orange - Medium stress
    } else if (stress >= 0.2) {
      colorMap[zone] = "#FFFF00"; // Yellow - Low-medium stress
    } else {
      colorMap[zone] = "#00FF00"; // Green - Low stress
    }
  });

  return colorMap;
}

function calculateStressDistribution(stressValues) {
  const values = Object.values(stressValues);
  const total = values.length;

  let low = 0,
    medium = 0,
    high = 0,
    critical = 0;

  values.forEach((stress) => {
    if (stress >= 0.65) critical++;
    else if (stress >= 0.6) high++;
    else if (stress >= 0.4) medium++;
    else low++;
  });

  return {
    low: Math.round((low / total) * 100),
    medium: Math.round((medium / total) * 100),
    high: Math.round((high / total) * 100),
    critical: Math.round((critical / total) * 100),
  };
}

// **🔥 BIOMECHANICAL HEATMAP ANALYSIS**
export async function calculateBiomechanicalHeatmap(
  scanData,
  recoveryIndex,
  tacticalEfficiency,
  athleteId,
) {
  try {
    const keyPoints = scanData.key_points || [];
    const biomechanics = scanData.biomechanics || {};
    const motionType = scanData.motion_type || "general";

    // **JOINT ZONE DEFINITIONS**
    const jointZones = {
      ankles: { id: "ANKLE", stress_base: 0.3, stress_modifier: 0.0 },
      knees: { id: "KNEE", stress_base: 0.35, stress_modifier: 0.0 },
      hips: { id: "HIP", stress_base: 0.25, stress_modifier: 0.0 },
      lower_back: { id: "L_BACK", stress_base: 0.4, stress_modifier: 0.0 },
      shoulders: { id: "SHOULDER", stress_base: 0.3, stress_modifier: 0.0 },
      elbows: { id: "ELBOW", stress_base: 0.2, stress_modifier: 0.0 },
      wrists: { id: "WRIST", stress_base: 0.25, stress_modifier: 0.0 },
      neck: { id: "NECK", stress_base: 0.35, stress_modifier: 0.0 },
    };

    // **MOTION-SPECIFIC STRESS CALCULATION**
    switch (motionType) {
      case "sprint":
        jointZones.ankles.stress_modifier =
          (biomechanics.acceleration_max || 0) / 100;
        jointZones.knees.stress_modifier =
          (biomechanics.velocity_peak || 0) / 150;
        jointZones.hips.stress_modifier =
          (biomechanics.power_output || 0) / 2000;
        break;

      case "jump":
        jointZones.knees.stress_modifier =
          (biomechanics.velocity_peak || 0) / 120;
        jointZones.ankles.stress_modifier =
          (biomechanics.acceleration_max || 0) / 80;
        jointZones.lower_back.stress_modifier =
          (biomechanics.power_output || 0) / 1800;
        break;

      case "throw":
      case "swing":
        jointZones.shoulders.stress_modifier =
          (biomechanics.range_of_motion || 0) / 200;
        jointZones.elbows.stress_modifier =
          (biomechanics.velocity_peak || 0) / 100;
        jointZones.wrists.stress_modifier =
          (biomechanics.acceleration_max || 0) / 120;
        jointZones.lower_back.stress_modifier =
          (biomechanics.power_output || 0) / 1500;
        break;

      case "grapple":
      case "takedown":
        jointZones.shoulders.stress_modifier =
          (biomechanics.power_output || 0) / 1600;
        jointZones.lower_back.stress_modifier =
          (biomechanics.stability_score || 50) / 200;
        jointZones.knees.stress_modifier =
          (biomechanics.acceleration_max || 0) / 90;
        break;

      default:
        // General motion stress distribution
        const generalStress = (biomechanics.velocity_peak || 0) / 200;
        Object.keys(jointZones).forEach((zone) => {
          jointZones[zone].stress_modifier = generalStress;
        });
    }

    // **NORMALIZE JOINT STRESS VALUES (0.0-0.7 RANGE)**
    const normalizedStressValues = {};
    const flaggedZones = [];
    const autoScoutNotes = [];

    Object.keys(jointZones).forEach((zoneName) => {
      const zone = jointZones[zoneName];
      let stressValue = zone.stress_base + zone.stress_modifier;

      // **RECOVERY INDEX SYNC** - High recovery reduces stress
      const recoveryFactor = 1 - recoveryIndex * 0.3; // Max 30% reduction
      stressValue *= recoveryFactor;

      // Normalize to 0.0-0.7 range
      const normalizedStress = Math.max(0.0, Math.min(0.7, stressValue));
      normalizedStressValues[zoneName] =
        Math.round(normalizedStress * 1000) / 1000;

      // **FLAG ZONES ≥ 0.6**
      if (normalizedStress >= 0.6) {
        flaggedZones.push({
          zone_id: zone.id,
          zone_name: zoneName,
          stress_value: normalizedStress,
          severity: normalizedStress >= 0.65 ? "critical" : "high",
          recovery_adjusted: true,
        });

        // **AUTO-LOG SCOUT NOTE WITH ZONE ID AND STRESS VALUE**
        autoScoutNotes.push(
          `Zone ${zone.id} flagged: ${normalizedStress.toFixed(3)} stress (${normalizedStress >= 0.65 ? "CRITICAL" : "HIGH"} - monitor for injury prevention)`,
        );
      }
    });

    // **OVERALL STRESS INDEX**
    const stressValues = Object.values(normalizedStressValues);
    const overallStressIndex =
      stressValues.reduce((sum, val) => sum + val, 0) / stressValues.length;

    // **ELITE BADGE VALIDATION**
    let eliteBadgeValidation = {
      validation_status: "not_applicable",
      tactical_requirement_met: false,
      stress_requirement_met: false,
      validated: false,
      validation_reason: "",
    };

    if (tacticalEfficiency >= 0.75) {
      eliteBadgeValidation.tactical_requirement_met = true;

      if (flaggedZones.length > 0) {
        eliteBadgeValidation.validation_status = "stress_validated";
        eliteBadgeValidation.stress_requirement_met = true;
        eliteBadgeValidation.validated = true;
        eliteBadgeValidation.validation_reason = `Tactical efficiency ${Math.round(tacticalEfficiency * 100)}% with high stress zones detected - Elite performance under biomechanical load confirmed`;

        // Add Elite validation to scout notes
        autoScoutNotes.push(
          `ELITE VALIDATION: Tactical efficiency ${Math.round(tacticalEfficiency * 100)}% maintained under stress - ${flaggedZones.length} high-stress zones detected`,
        );
      } else {
        eliteBadgeValidation.validation_status = "tactical_only";
        eliteBadgeValidation.stress_requirement_met = false;
        eliteBadgeValidation.validated = false;
        eliteBadgeValidation.validation_reason = `High tactical efficiency ${Math.round(tacticalEfficiency * 100)}% but no significant stress zones - Elite validation pending stress test`;
      }
    }

    // **RECOVERY DIP CHART SYNC**
    const recoveryDipSync = {
      current_recovery_index: Math.round(recoveryIndex * 100),
      stress_adjusted_recovery: Math.round(
        (recoveryIndex - overallStressIndex * 0.2) * 100,
      ),
      dip_magnitude: Math.round(overallStressIndex * 20), // 0-14 dip scale
      stress_zones_affecting_recovery: flaggedZones.length,
      recovery_recommendation:
        overallStressIndex > 0.5 ? "immediate_rest" : "active_recovery",
    };

    // **LOG SCOUT NOTES TO DATABASE**
    if (autoScoutNotes.length > 0) {
      try {
        // Validate athleteId exists before inserting
        const athleteExists = await sql`
          SELECT id FROM user_profiles WHERE id = ${athleteId}
        `;

        if (athleteExists.length === 0) {
          console.warn(
            `Athlete ID ${athleteId} not found in user_profiles, skipping scout notes logging`,
          );
        } else {
          await sql`
            INSERT INTO motion_scans (
              athlete_id,
              scan_data,
              ai_score,
              motion_type,
              metadata
            ) VALUES (
              ${athleteId},
              ${JSON.stringify({
                biomechanical_analysis: true,
                stress_zones: flaggedZones,
                scout_notes: autoScoutNotes,
              })},
              ${parseFloat(scanData.ai_score) || 0.85},
              ${"biomechanical_heatmap"},
              ${JSON.stringify({
                auto_generated: true,
                analysis_type: "stress_heatmap",
                flagged_zones: flaggedZones.length,
                elite_validation: eliteBadgeValidation.validated,
              })}
            )
          `;
        }
      } catch (dbError) {
        console.warn("Scout notes logging failed:", dbError);
      }
    }

    return {
      joint_stress_values: normalizedStressValues,
      flagged_zones: flaggedZones,
      overall_stress_index: overallStressIndex,
      elite_badge_validation: eliteBadgeValidation,
      recovery_dip_sync: recoveryDipSync,
      auto_scout_notes: autoScoutNotes,
      heatmap_visualization: {
        color_zones: generateHeatmapColors(normalizedStressValues),
        stress_distribution: calculateStressDistribution(
          normalizedStressValues,
        ),
        critical_alerts: flaggedZones.filter(
          (zone) => zone.severity === "critical",
        ).length,
      },
      analysis_metadata: {
        motion_type: motionType,
        zones_analyzed: Object.keys(jointZones).length,
        recovery_factor_applied: Math.round((1 - recoveryIndex) * 100),
        tactical_efficiency: Math.round(tacticalEfficiency * 100),
        timestamp: new Date().toISOString(),
      },
    };
  } catch (error) {
    console.error("Biomechanical heatmap analysis error:", error);
    return {
      joint_stress_values: {},
      flagged_zones: [],
      overall_stress_index: 0.3,
      elite_badge_validation: {
        validated: false,
        validation_reason: "Analysis error",
      },
      recovery_dip_sync: { dip_magnitude: 0 },
      auto_scout_notes: [
        "Heatmap analysis unavailable - using baseline metrics",
      ],
      analysis_metadata: {
        error: "Calculation failed",
        timestamp: new Date().toISOString(),
      },
    };
  }
}
