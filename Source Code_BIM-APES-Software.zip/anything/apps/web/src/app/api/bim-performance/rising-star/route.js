export async function POST(request) {
  try {
    const body = await request.json();
    const { talentId, performanceData, engagementData, platformContext } = body;

    if (!talentId || !performanceData) {
      return Response.json(
        { error: "Missing required fields: talentId, performanceData" },
        { status: 400 },
      );
    }

    // Calculate Rising-Star Performance Units
    const performanceUnits =
      calculateRisingStarPerformanceUnits(performanceData);

    // Calculate Engagement Metrics
    const engagementMetrics = calculateEngagementMetrics(engagementData || {});

    // Calculate Core Indices
    const indices = calculateRisingStarIndices(
      performanceUnits,
      engagementMetrics,
    );

    // Calculate Fair-Value NIL
    const nilValuation = calculateRisingStarNIL(
      performanceUnits,
      engagementMetrics,
      indices,
      platformContext,
    );

    return Response.json({
      success: true,
      talentId,
      performanceUnits,
      engagementMetrics,
      indices,
      nilValuation,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Rising-Star BIM Performance calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate rising-star performance metrics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateRisingStarPerformanceUnits(data) {
  const {
    contentPosts = [],
    brandCollaborations = [],
    onCameraAppearances = [],
    socialGrowthData = {},
    portfolioQualityAssessments = [],
  } = data;

  // Portfolio Versatility Units (PVU)
  const portfolioQuality = contentPosts.reduce((sum, post) => {
    const contentDiversity = post.contentTypeVariety / 10;
    const platformReach = post.platformReach / 10;
    const visualQuality = post.visualQuality / 10;
    return sum + (contentDiversity + platformReach + visualQuality) / 3;
  }, 0);
  const pvu = portfolioQuality / Math.max(contentPosts.length, 1);

  // On-Camera Adaptability Units (OAU)
  const cameraQuality = onCameraAppearances.reduce((sum, appearance) => {
    const adaptability = appearance.adaptabilityScore / 10;
    const naturalness = appearance.naturalnessScore / 10;
    const presence = appearance.presenceScore / 10;
    return sum + (adaptability + naturalness + presence) / 3;
  }, 0);
  const oau = cameraQuality / Math.max(onCameraAppearances.length, 1);

  // Brand Alignment Units (BAU)
  const brandQuality = brandCollaborations.reduce((sum, collab) => {
    const brandFit = collab.brandFitScore / 100;
    const authenticityScore = collab.authenticityScore / 10;
    return sum + (brandFit + authenticityScore) / 2;
  }, 0);
  const bau = brandQuality / Math.max(brandCollaborations.length, 1);

  // Engagement Momentum Units (EMU)
  const growthVelocity = socialGrowthData.followerGrowthRate || 0;
  const interactionRate = socialGrowthData.engagementRate || 0;
  const emu = (growthVelocity + interactionRate) / 2;

  // Social Growth Units (SGU)
  const platformCount = socialGrowthData.activePlatforms || 1;
  const totalReach = socialGrowthData.totalFollowers || 0;
  const sgu = Math.min((platformCount * totalReach) / 100000, 1.0);

  // Content Quality Units (CQU)
  const qualityScore = portfolioQualityAssessments.reduce((sum, assessment) => {
    const production = assessment.productionQuality / 10;
    const creativity = assessment.creativityScore / 10;
    const consistency = assessment.consistencyScore / 10;
    return sum + (production + creativity + consistency) / 3;
  }, 0);
  const cqu = qualityScore / Math.max(portfolioQualityAssessments.length, 1);

  return {
    PVU: Math.min(pvu, 1.0),
    OAU: Math.min(oau, 1.0),
    BAU: Math.min(bau, 1.0),
    EMU: Math.min(emu, 1.0),
    SGU: Math.min(sgu, 1.0),
    CQU: Math.min(cqu, 1.0),
    totalUnits:
      contentPosts.length +
      brandCollaborations.length +
      onCameraAppearances.length +
      portfolioQualityAssessments.length,
  };
}

function calculateEngagementMetrics(data) {
  const {
    followerGrowthRate = 0.05,
    engagementRate = 0.08,
    contentConsistency = 0.85,
    brandReadiness = 0.75,
    marketPenetration = 0.6,
  } = data;

  return {
    followerGrowthRate: Math.min(followerGrowthRate, 1.0),
    engagementRate: Math.min(engagementRate, 1.0),
    contentConsistency: Math.min(contentConsistency, 1.0),
    brandReadiness: Math.min(brandReadiness, 1.0),
    marketPenetration: Math.min(marketPenetration, 1.0),
    overallEngagement:
      (followerGrowthRate +
        engagementRate +
        contentConsistency +
        brandReadiness +
        marketPenetration) /
      5,
  };
}

function calculateRisingStarIndices(performanceUnits, engagementMetrics) {
  // Portfolio Momentum Index (PMI)
  const pmi =
    performanceUnits.PVU * 0.3 +
    performanceUnits.CQU * 0.3 +
    engagementMetrics.contentConsistency * 0.4;

  // Engagement Growth Index (EGI)
  const egi =
    performanceUnits.EMU * 0.4 +
    performanceUnits.SGU * 0.3 +
    engagementMetrics.followerGrowthRate * 0.3;

  // Brand Fit Index (BFI)
  const bfi =
    performanceUnits.BAU * 0.5 +
    performanceUnits.OAU * 0.3 +
    engagementMetrics.brandReadiness * 0.2;

  // Market Penetration Index (MPI)
  const mpi =
    performanceUnits.SGU * 0.4 + engagementMetrics.marketPenetration * 0.6;

  return {
    PMI: Math.min(pmi, 1.0),
    EGI: Math.min(egi, 1.0),
    BFI: Math.min(bfi, 1.0),
    MPI: Math.min(mpi, 1.0),
  };
}

function calculateRisingStarNIL(
  performanceUnits,
  engagementMetrics,
  indices,
  platformContext = {},
) {
  // Base performance score (40%)
  const performanceScore =
    performanceUnits.PVU * 0.2 +
    performanceUnits.OAU * 0.15 +
    performanceUnits.BAU * 0.2 +
    performanceUnits.EMU * 0.2 +
    performanceUnits.SGU * 0.15 +
    performanceUnits.CQU * 0.1;

  // Engagement score (30%)
  const engagementScore = engagementMetrics.overallEngagement;

  // Growth trajectory score (20%)
  const growthScore = indices.PMI * 0.4 + indices.EGI * 0.6;

  // Brand fit score (10%)
  const brandFitScore = indices.BFI;

  // Calculate FV-NIL
  const fvNIL =
    performanceScore * 0.4 +
    engagementScore * 0.3 +
    growthScore * 0.2 +
    brandFitScore * 0.1;

  // Platform multiplier
  const platformMultiplier = {
    tiktok: 1.3,
    instagram: 1.2,
    youtube: 1.4,
    multi_platform: 1.5,
  };
  const platformBonus =
    platformMultiplier[platformContext.primaryPlatform] || 1.0;

  // Base NIL value (normalized to $100K max for rising stars)
  const baseNILValue = fvNIL * 100000 * platformBonus;

  return {
    fvNIL: Math.min(fvNIL, 1.0),
    estimatedValue: Math.round(baseNILValue),
    performanceComponent: performanceScore,
    engagementComponent: engagementScore,
    growthComponent: growthScore,
    brandFitComponent: brandFitScore,
    platformMultiplier: platformBonus,
    tier: determineRisingStarTier(fvNIL),
    category: platformContext.category || "General Influencer",
  };
}

function determineRisingStarTier(fvNIL) {
  if (fvNIL >= 0.9) return "Breakout Star";
  if (fvNIL >= 0.8) return "Rising Talent";
  if (fvNIL >= 0.7) return "Emerging Influencer";
  if (fvNIL >= 0.6) return "Growing Creator";
  if (fvNIL >= 0.5) return "Early Stage";
  return "Developing";
}

export async function GET() {
  return Response.json({
    message: "Rising-Star Talent BIM Performance Calculation Engine",
    version: "1.0.0",
    performanceUnits: ["PVU", "OAU", "BAU", "EMU", "SGU", "CQU"],
    indices: ["PMI", "EGI", "BFI", "MPI"],
    method: "POST",
    requiredFields: ["talentId", "performanceData"],
  });
}
