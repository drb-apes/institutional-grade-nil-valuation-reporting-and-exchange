import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Position-specific performance analysis
function calculatePositionPerformance(footballData, position) {
  switch (position) {
    case "quarterback":
      const completionPercentage = footballData.completion_percentage || 0.65;
      const passerRating = Math.min(
        (footballData.passer_rating || 85) / 158.3,
        1.0,
      );
      const decisionMaking = footballData.decision_making_score || 0.7;
      const pocketPresence = footballData.pocket_presence || 0.65;

      return (
        completionPercentage * 0.3 +
        passerRating * 0.25 +
        decisionMaking * 0.25 +
        pocketPresence * 0.2
      );

    case "running_back":
      const yardsPerCarry = Math.min(
        (footballData.yards_per_carry || 4.0) / 8.0,
        1.0,
      );
      const breakawayAbility = footballData.breakaway_percentage || 0.15;
      const receivingSkills = footballData.receiving_yards_per_game
        ? Math.min(footballData.receiving_yards_per_game / 50, 1.0)
        : 0.3;
      const ballSecurity = footballData.fumble_rate
        ? Math.max(0, 1 - footballData.fumble_rate * 10)
        : 0.85;

      return (
        yardsPerCarry * 0.35 +
        breakawayAbility * 0.25 +
        receivingSkills * 0.2 +
        ballSecurity * 0.2
      );

    case "wide_receiver":
      const catchPercentage = footballData.catch_percentage || 0.7;
      const yardsAfterCatch = Math.min(
        (footballData.yards_after_catch || 5) / 15,
        1.0,
      );
      const routeRunning = footballData.route_running_grade || 0.75;
      const redZoneTargets = footballData.red_zone_efficiency || 0.6;

      return (
        catchPercentage * 0.3 +
        yardsAfterCatch * 0.25 +
        routeRunning * 0.25 +
        redZoneTargets * 0.2
      );

    case "offensive_line":
      const passBlockGrade = footballData.pass_block_grade || 0.7;
      const runBlockGrade = footballData.run_block_grade || 0.7;
      const pressureAllowed = footballData.pressure_allowed_rate
        ? Math.max(0, 1 - footballData.pressure_allowed_rate)
        : 0.75;
      const penaltyRate = footballData.penalty_rate
        ? Math.max(0, 1 - footballData.penalty_rate * 5)
        : 0.8;

      return (
        passBlockGrade * 0.3 +
        runBlockGrade * 0.3 +
        pressureAllowed * 0.25 +
        penaltyRate * 0.15
      );

    case "defensive_line":
      const passRushGrade = footballData.pass_rush_grade || 0.7;
      const runStopGrade = footballData.run_stop_grade || 0.7;
      const pressureRate = footballData.pressure_rate || 0.2;
      const tackleEfficiency = footballData.tackle_efficiency || 0.75;

      return (
        passRushGrade * 0.3 +
        runStopGrade * 0.3 +
        pressureRate * 0.25 +
        tackleEfficiency * 0.15
      );

    case "linebacker":
      const lbCoverageGrade = footballData.coverage_grade || 0.7;
      const runDefenseGrade = footballData.run_defense_grade || 0.7;
      const blitzEffectiveness = footballData.blitz_effectiveness || 0.6;
      const tacklesPerGame = Math.min(
        (footballData.tackles_per_game || 6) / 12,
        1.0,
      );

      return (
        lbCoverageGrade * 0.3 +
        runDefenseGrade * 0.25 +
        blitzEffectiveness * 0.2 +
        tacklesPerGame * 0.25
      );

    case "defensive_back":
      const dbCoverageGrade = footballData.coverage_grade || 0.7;
      const interceptionRate = footballData.interception_rate || 0.02;
      const passBreakups = Math.min(
        (footballData.pass_breakups || 5) / 15,
        1.0,
      );
      const completionAllowed = footballData.completion_percentage_allowed
        ? Math.max(0, 1 - footballData.completion_percentage_allowed)
        : 0.4;

      return (
        dbCoverageGrade * 0.35 +
        interceptionRate * 5 +
        passBreakups * 0.25 +
        completionAllowed * 0.3
      );

    default:
      return footballData.overall_grade || 0.7;
  }
}

// Formation execution and assignment accuracy
function calculateFormationExecution(footballData) {
  const assignmentAccuracy = footballData.assignment_accuracy || 0.85;
  const formationAlignment = footballData.formation_alignment_grade || 0.8;
  const prSnapMovement = footballData.pre_snap_movement_score || 0.75;
  const timingExecution = footballData.timing_execution || 0.7;

  return (
    assignmentAccuracy * 0.3 +
    formationAlignment * 0.25 +
    prSnapMovement * 0.25 +
    timingExecution * 0.2
  );
}

// Situational performance (down and distance, game situation)
function calculateSituationalPerformance(footballData) {
  const thirdDownConversion = footballData.third_down_conversion || 0.4;
  const redZoneEfficiency = footballData.red_zone_efficiency || 0.6;
  const twoMinuteDrillPerformance = footballData.two_minute_performance || 0.65;
  const clutchPerformance = footballData.clutch_performance || 0.6;

  return (
    thirdDownConversion * 0.3 +
    redZoneEfficiency * 0.25 +
    twoMinuteDrillPerformance * 0.25 +
    clutchPerformance * 0.2
  );
}

// Game-to-game consistency analysis
function calculateGameConsistency(footballData) {
  const gameGrades = footballData.game_grades || [];
  if (gameGrades.length < 3) return 0.7;

  const mean = gameGrades.reduce((a, b) => a + b, 0) / gameGrades.length;
  const variance =
    gameGrades.reduce((sum, grade) => sum + Math.pow(grade - mean, 2), 0) /
    gameGrades.length;

  // Lower variance = higher consistency
  return Math.max(0, 1 - variance);
}

// Practice-to-game transfer
function calculatePracticeGameTransfer(footballData) {
  const practiceGrade = footballData.average_practice_grade || 0.75;
  const gameGrade = footballData.average_game_grade || 0.7;
  const transferEfficiency = Math.min(gameGrade / practiceGrade, 1.2); // Allow slight improvement

  const injuryResistance = footballData.injury_resistance || 0.8;
  const conditioningScore = footballData.conditioning_score || 0.75;

  return (
    transferEfficiency * 0.4 + injuryResistance * 0.3 + conditioningScore * 0.3
  );
}

// American Football tactical efficiency
function calculateFootballTacticalEfficiency(footballData, position) {
  const positionPerformance = calculatePositionPerformance(
    footballData,
    position,
  );
  const formationExecution = calculateFormationExecution(footballData);
  const situationalPerformance = calculateSituationalPerformance(footballData);

  return (
    positionPerformance * 0.4 +
    formationExecution * 0.35 +
    situationalPerformance * 0.25
  );
}

// American Football spike score
function calculateFootballSpikeScore(footballData, position) {
  const bigPlays = footballData.big_plays || 0; // 20+ yard gains/stops
  const gameChangingPlays = footballData.game_changing_plays || 0;
  const totalPlays = footballData.total_plays || 1;

  const bigPlayRate = Math.min(bigPlays / (totalPlays * 0.1), 1.0);
  const gameChangingRate = Math.min(
    gameChangingPlays / (totalPlays * 0.05),
    1.0,
  );

  // Position-specific spike plays
  let positionSpike = 0.7;
  switch (position) {
    case "quarterback":
      const touchdownPasses = footballData.touchdown_passes || 0;
      const games = footballData.games_played || 1;
      positionSpike = Math.min(touchdownPasses / (games * 2), 1.0);
      break;
    case "running_back":
      const rushingTouchdowns = footballData.rushing_touchdowns || 0;
      const rbReceivingTouchdowns = footballData.receiving_touchdowns || 0;
      positionSpike = Math.min(
        (rushingTouchdowns + rbReceivingTouchdowns) /
          (footballData.games_played || 1),
        1.0,
      );
      break;
    case "wide_receiver":
      const wrReceivingTouchdowns = footballData.receiving_touchdowns || 0;
      const yards100Plus = footballData.hundred_yard_games || 0;
      positionSpike = Math.min(
        (wrReceivingTouchdowns * 0.7 + yards100Plus * 0.3) /
          (footballData.games_played || 1),
        1.0,
      );
      break;
    case "defensive_line":
    case "linebacker":
    case "defensive_back":
      const sacks = footballData.sacks || 0;
      const interceptions = footballData.interceptions || 0;
      const forcedFumbles = footballData.forced_fumbles || 0;
      positionSpike = Math.min(
        (sacks + interceptions * 2 + forcedFumbles * 1.5) /
          (footballData.games_played || 1),
        1.0,
      );
      break;
  }

  return bigPlayRate * 0.3 + gameChangingRate * 0.4 + positionSpike * 0.3;
}

// American Football session consistency (main focus)
async function calculateFootballSessionConsistency(athleteId, position) {
  const recentSessions = await sql`
    SELECT simulation_data->'football_metrics' as metrics,
           simulation_data->'football_data' as data
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '60 days'
    AND valuation_factors->>'sport' = 'american_football'
    ORDER BY created_at DESC
    LIMIT 16  -- 16 games (full season)
  `;

  if (recentSessions.length < 4) return 0.7;

  // Analyze multiple consistency factors
  const overallScores = recentSessions.map(
    (s) => s.metrics?.overall_score || 70,
  );
  const positionScores = recentSessions.map(
    (s) => s.data?.position_performance || 0.7,
  );
  const formationScores = recentSessions.map(
    (s) => s.data?.formation_execution || 0.75,
  );

  // Calculate variance for each metric
  const calculateConsistency = (scores) => {
    const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
    const variance =
      scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
      scores.length;
    return Math.max(0, 1 - variance / (mean * mean)); // Coefficient of variation approach
  };

  const overallConsistency = calculateConsistency(overallScores);
  const positionConsistency = calculateConsistency(positionScores);
  const formationConsistency = calculateConsistency(formationScores);

  // Weight consistency metrics
  return (
    overallConsistency * 0.4 +
    positionConsistency * 0.35 +
    formationConsistency * 0.25
  );
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { football_data, position, team_level, season_phase } =
      await request.json();

    if (!football_data || !position) {
      return Response.json(
        { error: "Football performance data and position required" },
        { status: 400 },
      );
    }

    const validPositions = [
      "quarterback",
      "running_back",
      "wide_receiver",
      "tight_end",
      "offensive_line",
      "defensive_line",
      "linebacker",
      "defensive_back",
      "kicker",
      "punter",
    ];

    if (!validPositions.includes(position)) {
      return Response.json(
        { error: `Position must be one of: ${validPositions.join(", ")}` },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate American Football metrics
    const positionPerformance = calculatePositionPerformance(
      football_data,
      position,
    );
    const formationExecution = calculateFormationExecution(football_data);
    const situationalPerformance =
      calculateSituationalPerformance(football_data);
    const gameConsistency = calculateGameConsistency(football_data);
    const practiceGameTransfer = calculatePracticeGameTransfer(football_data);
    const tacticalEfficiency = calculateFootballTacticalEfficiency(
      football_data,
      position,
    );
    const spikeScore = calculateFootballSpikeScore(football_data, position);
    const sessionConsistency = await calculateFootballSessionConsistency(
      athlete.id,
      position,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      position_performance: positionPerformance,
      formation_execution: formationExecution,
      situational_performance: situationalPerformance,
      game_consistency: gameConsistency,
      practice_game_transfer: practiceGameTransfer,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall football performance index
    const weights = {
      position_performance: 0.25,
      formation_execution: 0.2,
      situational_performance: 0.2,
      game_consistency: 0.15,
      practice_game_transfer: 0.1,
      tactical_efficiency: 0.1,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => !["session_consistency", "spike_score"].includes(key))
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display based on team level
    const isCollege =
      team_level === "college" ||
      team_level === "professional" ||
      athlete.tier_level >= 3;
    const displayScale = isCollege ? 100 : 85;

    const displayMetrics = {
      position_performance: Math.round(positionPerformance * displayScale),
      formation_execution: Math.round(formationExecution * displayScale),
      situational_performance: Math.round(
        situationalPerformance * displayScale,
      ),
      game_consistency: Math.round(gameConsistency * displayScale),
      practice_game_transfer: Math.round(practiceGameTransfer * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isCollege ? "college_football" : "high_school_football",
      position: position,
      season_phase: season_phase,
      timestamp: new Date().toISOString(),
    };

    // Generate football-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      football_specific_tips: [],
    };

    // Analyze strengths and weaknesses
    if (performanceMetrics.session_consistency >= 0.8) {
      insights.strengths.push("Exceptional game-to-game consistency");
    } else if (performanceMetrics.session_consistency <= 0.6) {
      insights.improvements.push(
        "Focus on consistent preparation and performance",
      );
    }

    if (performanceMetrics.formation_execution >= 0.8) {
      insights.strengths.push("Outstanding assignment execution");
    } else if (performanceMetrics.formation_execution <= 0.6) {
      insights.improvements.push("Work on formation alignment and assignments");
    }

    if (performanceMetrics.situational_performance >= 0.8) {
      insights.strengths.push("Excellent clutch and situational performance");
    } else if (performanceMetrics.situational_performance <= 0.6) {
      insights.improvements.push("Improve performance in pressure situations");
    }

    // Position-specific tips
    switch (position) {
      case "quarterback":
        if (performanceMetrics.position_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Focus on pre-snap reads and pocket awareness",
          );
        }
        if (performanceMetrics.situational_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Practice two-minute drill and red zone efficiency",
          );
        }
        break;

      case "running_back":
        if (performanceMetrics.position_performance <= 0.6) {
          insights.football_specific_tips.push("Work on vision and cut timing");
        }
        if (performanceMetrics.spike_score <= 0.6) {
          insights.football_specific_tips.push(
            "Develop breakaway speed and big play ability",
          );
        }
        break;

      case "wide_receiver":
        if (performanceMetrics.position_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Focus on route precision and catch technique",
          );
        }
        if (performanceMetrics.situational_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Practice contested catches and red zone routes",
          );
        }
        break;

      case "offensive_line":
        if (performanceMetrics.formation_execution <= 0.6) {
          insights.football_specific_tips.push(
            "Work on communication and combo blocks",
          );
        }
        if (performanceMetrics.session_consistency <= 0.6) {
          insights.football_specific_tips.push(
            "Focus on consistent technique and conditioning",
          );
        }
        break;

      case "defensive_line":
        if (performanceMetrics.position_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Develop pass rush moves and run gap discipline",
          );
        }
        break;

      case "linebacker":
        if (performanceMetrics.position_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Work on coverage drops and run fits",
          );
        }
        if (performanceMetrics.formation_execution <= 0.6) {
          insights.football_specific_tips.push(
            "Study defensive calls and communication",
          );
        }
        break;

      case "defensive_back":
        if (performanceMetrics.position_performance <= 0.6) {
          insights.football_specific_tips.push(
            "Focus on coverage technique and ball skills",
          );
        }
        if (performanceMetrics.spike_score <= 0.6) {
          insights.football_specific_tips.push(
            "Work on interception and pass breakup opportunities",
          );
        }
        break;
    }

    // Season phase specific advice
    if (season_phase) {
      switch (season_phase) {
        case "preseason":
          insights.football_specific_tips.push(
            "Focus on fundamentals and building chemistry",
          );
          break;
        case "regular_season":
          insights.football_specific_tips.push(
            "Maintain consistency and manage workload",
          );
          break;
        case "playoffs":
          insights.football_specific_tips.push(
            "Elevate performance and capitalize on opportunities",
          );
          break;
      }
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.1 + sessionConsistency * 0.2, 1.0)}, -- Bonus for consistency
        ${Math.max(0, 1 - sessionConsistency)}, -- Lower risk with higher consistency
        ${JSON.stringify({
          football_metrics: displayMetrics,
          football_data: football_data,
          sport_context: { position, team_level, season_phase },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: "american_football",
          analysis_type: "american_football_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      football_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: "american_football",
      position: position,
      message: `American Football Session Consistency Analysis - ${position.replace("_", " ").toUpperCase()} Performance`,
    });
  } catch (error) {
    console.error("American Football performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate American Football performance metrics" },
      { status: 500 },
    );
  }
}
