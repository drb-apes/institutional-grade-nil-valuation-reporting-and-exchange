// /apps/web/src/app/api/bim-performance/calculate/services/metrics.js
import sql from "@/app/api/utils/sql";
import { calculateBodyVolume, estimateHeight } from "./utils.js";

// **BVI CALCULATION ALGORITHM**
export function calculateBVI(scanData, athleteData = {}) {
  const biomechanics = scanData.biomechanics || {};
  const keyPoints = scanData.key_points || [];
  const sport = scanData.sport_type || athleteData.sport || "general";

  // Extract body composition data from motion analysis
  const bodyVolume = calculateBodyVolume(keyPoints, scanData.frame_count);
  const height = athleteData.height || estimateHeight(keyPoints);

  // Base BVI = Total Body Volume (L) / Height² (m²)
  let bvi = bodyVolume / (height * height);

  // Sport-specific BVI adjustments for specialized metrics
  if (sport === "pole_vault") {
    // Pole vault specific adjustments for approach speed spikes and pole bend intensity
    const approachSpeedSpike =
      biomechanics.approach_speed_spike ||
      (biomechanics.velocity_peak > 8 ? biomechanics.velocity_peak / 10 : 0);
    const poleBendIntensity =
      biomechanics.pole_bend_intensity || biomechanics.power_output / 1000 || 0;
    const landingInstability =
      biomechanics.landing_instability ||
      1 - biomechanics.stability_score / 100 ||
      0.2;

    // Enhance BVI with pole vault specific power metrics
    bvi +=
      approachSpeedSpike * 0.3 +
      poleBendIntensity * 0.2 -
      landingInstability * 0.1;
  }

  // Normalize to 0-1 scale (will be scaled later)
  // Optimal BVI range: 5-15 for most athletes
  return Math.max(0, Math.min(1, (15 - Math.abs(bvi - 10)) / 15));
}

// **TACTICAL EFFICIENCY CALCULATION**
export function calculateTacticalEfficiency(scanData, sessionContext = {}) {
  const biomechanics = scanData.biomechanics || {};
  const motionType = scanData.motion_type;
  const sport = sessionContext.sport || "general";

  // Analyze decision-making quality based on movement patterns
  let efficiency = 0.7; // Base efficiency

  // Sport-specific tactical scoring
  switch (sport) {
    case "boxing":
      // Boxing/MMA: Focus on combo velocity, guard drop
      if (motionType === "punch") {
        efficiency += (biomechanics.velocity_peak / 25) * 0.3; // Punch speed
        efficiency += (biomechanics.stability_score / 100) * 0.2; // Stance stability
      }
      break;

    case "soccer":
      // Soccer/Basketball: Focus on tactical spacing
      if (["kick", "dribble", "sprint"].includes(motionType)) {
        efficiency += (biomechanics.acceleration_max / 35) * 0.25; // Lateral speed
        efficiency += (biomechanics.efficiency_rating / 100) * 0.25; // Reaction time
      }
      break;

    case "wrestling":
      // Wrestling/Rugby: Focus on takedown mechanics
      if (["grapple", "takedown", "throw"].includes(motionType)) {
        efficiency += (biomechanics.power_output / 1500) * 0.2; // Grip torque
        efficiency += (biomechanics.stability_score / 100) * 0.3; // Balance shift
      }
      break;

    case "tennis":
      // Tennis/Pickleball: Focus on serve mechanics
      if (["serve", "swing", "volley"].includes(motionType)) {
        efficiency += (biomechanics.range_of_motion / 180) * 0.25; // Arm angle
        efficiency += (biomechanics.velocity_peak / 30) * 0.25; // Rotation speed
      }
      break;

    case "football":
      // American Football: Focus on route fidelity
      if (["sprint", "cut", "catch"].includes(motionType)) {
        efficiency += (biomechanics.acceleration_max / 40) * 0.3; // Acceleration burst
        efficiency += (biomechanics.efficiency_rating / 100) * 0.2; // Formation logic
      }
      break;

    case "pole_vault":
      // Pole Vault: Focus on vault execution timing
      if (["approach", "plant", "vault", "clearance"].includes(motionType)) {
        // Approach speed efficiency (optimal: 8-10 m/s)
        const approachSpeed =
          biomechanics.approach_speed || biomechanics.velocity_peak || 0;
        const speedEfficiency = Math.max(
          0,
          1 - Math.abs(approachSpeed - 9) / 9,
        );
        efficiency += speedEfficiency * 0.25;

        // Plant timing precision (measured from angular velocity consistency)
        const plantTiming =
          biomechanics.plant_timing_precision ||
          biomechanics.stability_score / 100 ||
          0.7;
        efficiency += plantTiming * 0.25;

        // Bar clearance angle (optimal clearance mechanics)
        const clearanceAngle =
          biomechanics.bar_clearance_angle || biomechanics.range_of_motion || 0;
        const clearanceEfficiency = Math.min(1, clearanceAngle / 85); // Optimal ~85° clearance
        efficiency += clearanceEfficiency * 0.25;

        // Pole release mechanics (clean release timing)
        const releaseScore =
          biomechanics.pole_release_score ||
          biomechanics.efficiency_rating / 100 ||
          0.75;
        efficiency += releaseScore * 0.25;
      }
      break;

    default:
      // General athletics: Standard calculation
      switch (motionType) {
        case "sprint":
          efficiency += (biomechanics.acceleration_max / 40) * 0.3;
          break;
        case "jump":
          efficiency += (biomechanics.velocity_peak / 20) * 0.3;
          break;
        case "throw":
        case "swing":
          efficiency += (biomechanics.range_of_motion / 180) * 0.3;
          break;
        default:
          efficiency += (biomechanics.stability_score / 100) * 0.3;
      }
  }

  return Math.max(0, Math.min(1, efficiency));
}

// **RECOVERY INDEX CALCULATION**
export async function calculateRecoveryIndex(athleteId, scanData) {
  try {
    const sport = scanData.sport_type || "general";
    const biomechanics = scanData.biomechanics || {};

    // Get recent motion scans for trend analysis
    const recentScans = await sql`
      SELECT ai_score, created_at, scan_data
      FROM motion_scans 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '7 days'
      ORDER BY created_at DESC
      LIMIT 10
    `;

    if (recentScans.length < 2) {
      return 0.75; // Default for new athletes
    }

    // Analyze performance consistency as recovery indicator
    const scores = recentScans.map((scan) => scan.ai_score);
    const avgScore =
      scores.reduce((sum, score) => sum + score, 0) / scores.length;
    const variance =
      scores.reduce((sum, score) => sum + Math.pow(score - avgScore, 2), 0) /
      scores.length;

    // Base recovery index from consistency
    let recoveryIndex = Math.max(0.3, 1 - variance / 1000);

    // Sport-specific recovery adjustments
    if (sport === "pole_vault") {
      // Pole vault specific fatigue indicators
      const approachSpeedDecline = biomechanics.approach_speed_decline || 0;
      const delayedPlant = biomechanics.delayed_plant_timing || 0;
      const landingFormDegradation = biomechanics.landing_form_fatigue || 0;

      // Apply fatigue penalties to recovery index
      recoveryIndex -= approachSpeedDecline * 0.2; // Decline in approach speed
      recoveryIndex -= delayedPlant * 0.15; // Delayed plant timing
      recoveryIndex -= landingFormDegradation * 0.1; // Visible fatigue in landing form

      // Check for asymmetry in multiple vaults
      if (recentScans.length >= 3) {
        const recentApproachSpeeds = recentScans
          .map((scan) => {
            try {
              const data = JSON.parse(scan.scan_data);
              return (
                data.biomechanics?.approach_speed ||
                data.biomechanics?.velocity_peak ||
                0
              );
            } catch {
              return 0;
            }
          })
          .filter((speed) => speed > 0);

        if (recentApproachSpeeds.length >= 2) {
          const speedVariance =
            recentApproachSpeeds.reduce((sum, speed, idx, arr) => {
              const mean = arr.reduce((s, v) => s + v, 0) / arr.length;
              return sum + Math.pow(speed - mean, 2);
            }, 0) / recentApproachSpeeds.length;

          // High variance indicates inconsistent approach speeds (fatigue/asymmetry)
          if (speedVariance > 2) {
            recoveryIndex -= 0.1;
          }
        }
      }
    }

    return Math.max(0, Math.min(1, recoveryIndex));
  } catch (error) {
    console.error("Recovery index calculation error:", error);
    return 0.75;
  }
}

// **SPIKE SCORE CALCULATION**
export function calculateSpikeScore(scanData) {
  const biomechanics = scanData.biomechanics || {};

  // Calculate explosive performance metrics
  const peakVelocity = parseFloat(biomechanics.velocity_peak) || 0;
  const maxAcceleration = parseFloat(biomechanics.acceleration_max) || 0;
  const powerRating = Math.sqrt(peakVelocity * maxAcceleration) / 20;

  // Normalize spike score
  return Math.max(0, Math.min(1, powerRating));
}

// **SESSION CONSISTENCY CALCULATION**
export async function calculateSessionConsistency(athleteId) {
  try {
    const recentScans = await sql`
      SELECT ai_score 
      FROM motion_scans 
      WHERE athlete_id = ${athleteId}
      AND created_at >= NOW() - INTERVAL '30 days'
      ORDER BY created_at DESC
      LIMIT 20
    `;

    if (recentScans.length < 3) {
      return 0.7; // Default for athletes with limited history
    }

    const scores = recentScans.map((scan) => scan.ai_score);
    const mean = scores.reduce((sum, score) => sum + score, 0) / scores.length;
    const variance =
      scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
      scores.length;
    const standardDeviation = Math.sqrt(variance);

    // Consistency = 1 - (standardDeviation / mean)
    // Higher consistency = lower relative standard deviation
    const consistency = Math.max(0.2, 1 - standardDeviation / mean);

    return Math.max(0, Math.min(1, consistency));
  } catch (error) {
    console.error("Session consistency calculation error:", error);
    return 0.7;
  }
}

// **POSE CONFIDENCE CALCULATION**
export function calculatePoseConfidence(scanData) {
  const keyPoints = scanData.key_points || [];
  if (keyPoints.length === 0) return 0.85; // Default confidence

  const avgConfidence =
    keyPoints.reduce((sum, point) => sum + point.confidence, 0) /
    keyPoints.length;
  return Math.max(0, Math.min(1, avgConfidence));
}
