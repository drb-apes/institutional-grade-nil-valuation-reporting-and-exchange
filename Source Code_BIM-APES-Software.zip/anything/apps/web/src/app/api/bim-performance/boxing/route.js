import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      athleteId,
      offensiveData,
      defensiveData,
      conditioningData,
      recoveryMetrics,
    } = body;

    // Boxing-specific BVI calculation
    const boxingBVI = calculateBoxingBVI(
      offensiveData,
      defensiveData,
      conditioningData,
      recoveryMetrics,
    );

    // Tactical efficiency for Boxing
    const tacticalEfficiency = calculateBoxingTacticalEfficiency(
      offensiveData,
      defensiveData,
    );

    // Recovery index
    const recoveryIndex = calculateBoxingRecoveryIndex(recoveryMetrics);

    // Store motion scan
    const motionScan = await sql`
      INSERT INTO motion_scans (
        athlete_id, 
        scan_data, 
        ai_score, 
        motion_type, 
        metadata
      ) VALUES (
        ${athleteId},
        ${JSON.stringify({
          sport: "boxing",
          bvi_score: boxingBVI,
          tactical_efficiency: tacticalEfficiency,
          recovery_index: recoveryIndex,
          offensive_data: offensiveData,
          defensive_data: defensiveData,
          conditioning_data: conditioningData,
          analysis_timestamp: new Date().toISOString(),
        })},
        ${boxingBVI.overall_score},
        'boxing_performance',
        ${JSON.stringify({
          sport_category: "boxing",
          analysis_version: "v3.0",
          coalition_tier: getCoalitionTier(boxingBVI.overall_score),
        })}
      ) RETURNING *
    `;

    // Generate Boxing-specific recommendations
    const recommendations = generateBoxingRecommendations(
      boxingBVI,
      tacticalEfficiency,
      recoveryIndex,
    );

    return Response.json({
      success: true,
      boxing_analysis: {
        sport: "Boxing",
        bvi_score: boxingBVI,
        tactical_efficiency: tacticalEfficiency,
        recovery_index: recoveryIndex,
        coalition_tier: getCoalitionTier(boxingBVI.overall_score),
        recommendations: recommendations,
      },
      motion_scan_id: motionScan[0].id,
    });
  } catch (error) {
    console.error("Boxing BIM analysis error:", error);
    return Response.json(
      {
        error: "Failed to process Boxing analysis",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateBoxingBVI(
  offensiveData,
  defensiveData,
  conditioningData,
  recoveryMetrics,
) {
  const {
    jabAccuracy = 75,
    powerPunchPercentage = 65,
    combinationsPerRound = 45,
    cleanPunches = 0,
    totalPunches = 0,
    knockdowns = 0,
    effectiveAggression = 70,
  } = offensiveData || {};

  const {
    slipPercentage = 70,
    blockEfficiency = 80,
    counterPunchRatio = 0.35,
    defensivePositioning = 65,
    ringControl = 70,
  } = defensiveData || {};

  const {
    roundEndurance = 85,
    punchOutputConsistency = 75,
    recoveryBetweenRounds = 80,
    maxHeartRate = 185,
    powerMaintenance = 70,
  } = conditioningData || {};

  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    sleepQuality = 70,
    hrv = 65,
  } = recoveryMetrics || {};

  // Boxing BVI Components (weighted)
  const offensiveComponent = Math.min(
    100,
    jabAccuracy * 0.3 +
      powerPunchPercentage * 0.25 +
      combinationsPerRound * 0.8 +
      knockdowns * 15 +
      effectiveAggression * 0.2 +
      (totalPunches > 0 ? (cleanPunches / totalPunches) * 100 * 0.3 : 0),
  );

  const defensiveComponent = Math.min(
    100,
    slipPercentage * 0.3 +
      blockEfficiency * 0.25 +
      counterPunchRatio * 100 * 0.2 +
      defensivePositioning * 0.15 +
      ringControl * 0.1,
  );

  const conditioningComponent = Math.min(
    100,
    roundEndurance * 0.3 +
      punchOutputConsistency * 0.25 +
      recoveryBetweenRounds * 0.25 +
      powerMaintenance * 0.2,
  );

  const recoveryComponent = Math.min(
    100,
    100 -
      (cortisolLevels + creatineKinase) / 2 +
      sleepQuality * 0.3 +
      hrv * 0.2,
  );

  // Weighted Boxing BVI
  const overallScore = Math.round(
    offensiveComponent * 0.35 +
      defensiveComponent * 0.3 +
      conditioningComponent * 0.25 +
      recoveryComponent * 0.1,
  );

  return {
    overall_score: overallScore,
    components: {
      offensive: Math.round(offensiveComponent),
      defensive: Math.round(defensiveComponent),
      conditioning: Math.round(conditioningComponent),
      recovery: Math.round(recoveryComponent),
    },
    detailed_metrics: {
      punch_accuracy:
        totalPunches > 0 ? Math.round((cleanPunches / totalPunches) * 100) : 0,
      defensive_efficiency: Math.round((slipPercentage + blockEfficiency) / 2),
      ring_generalship: ringControl,
      punch_output_rate: combinationsPerRound,
      power_consistency: powerMaintenance,
    },
  };
}

function calculateBoxingTacticalEfficiency(offensiveData, defensiveData) {
  const {
    ringGeneralship = 70,
    distanceManagement = 75,
    timingPrecision = 80,
    adaptability = 70,
  } = { ...offensiveData, ...defensiveData };

  const tacticalScore = Math.round(
    ringGeneralship * 0.3 +
      distanceManagement * 0.25 +
      timingPrecision * 0.25 +
      adaptability * 0.2,
  );

  return {
    overall_efficiency: tacticalScore,
    components: {
      ring_generalship: ringGeneralship,
      distance_management: distanceManagement,
      timing_precision: timingPrecision,
      adaptability: adaptability,
    },
    tactical_grade: getTacticalGrade(tacticalScore),
    boxing_iq: Math.round((ringGeneralship + adaptability) / 2),
  };
}

function calculateBoxingRecoveryIndex(recoveryMetrics) {
  const {
    cortisolLevels = 50,
    creatineKinase = 40,
    sleepQuality = 70,
    hrv = 65,
    handCondition = 80,
    shoulderHealth = 85,
    hydrationStatus = 80,
    mentalReadiness = 75,
  } = recoveryMetrics || {};

  const stressMarkers = 100 - (cortisolLevels + creatineKinase) / 2;
  const physicalReadiness =
    (handCondition + shoulderHealth + hydrationStatus) / 3;
  const mentalPhysicalBalance = (sleepQuality + hrv + mentalReadiness) / 3;

  const overallRecovery = Math.round(
    stressMarkers * 0.3 + physicalReadiness * 0.4 + mentalPhysicalBalance * 0.3,
  );

  return {
    overall_recovery: overallRecovery,
    stress_markers: Math.round(stressMarkers),
    physical_readiness: Math.round(physicalReadiness),
    mental_readiness: Math.round(mentalPhysicalBalance),
    recovery_grade: getRecoveryGrade(overallRecovery),
    injury_risk_factors: assessBoxingInjuryRisk(recoveryMetrics),
  };
}

function generateBoxingRecommendations(
  boxingBVI,
  tacticalEfficiency,
  recoveryIndex,
) {
  const recommendations = [];

  // BVI-based recommendations
  if (boxingBVI.overall_score >= 85) {
    recommendations.push({
      type: "elite_development",
      priority: "high",
      message:
        "Elite boxing prospect - Consider championship-level training camps",
    });
  } else if (boxingBVI.overall_score < 60) {
    recommendations.push({
      type: "fundamental_improvement",
      priority: "urgent",
      message: "Focus on basic boxing fundamentals and conditioning",
    });
  }

  // Component-specific recommendations
  if (boxingBVI.components.offensive < 70) {
    recommendations.push({
      type: "offensive_development",
      priority: "high",
      message:
        "Increase heavy bag and mitt work - Focus on combination accuracy",
    });
  }

  if (boxingBVI.components.defensive < 70) {
    recommendations.push({
      type: "defensive_focus",
      priority: "high",
      message: "Enhance head movement and defensive positioning drills",
    });
  }

  if (boxingBVI.components.conditioning < 75) {
    recommendations.push({
      type: "conditioning_boost",
      priority: "medium",
      message: "Implement advanced cardiovascular training protocols",
    });
  }

  // Tactical recommendations
  if (tacticalEfficiency.overall_efficiency < 70) {
    recommendations.push({
      type: "tactical_improvement",
      priority: "medium",
      message:
        "Work on ring IQ and strategic thinking with experienced coaches",
    });
  }

  // Recovery recommendations
  if (recoveryIndex.overall_recovery < 60) {
    recommendations.push({
      type: "recovery_protocol",
      priority: "urgent",
      message:
        "Implement comprehensive recovery protocols - Monitor hand/shoulder health",
    });
  }

  return recommendations;
}

function assessBoxingInjuryRisk(recoveryMetrics) {
  const {
    handCondition = 80,
    shoulderHealth = 85,
    headTraumaHistory = 0,
    sparringVolume = 50,
  } = recoveryMetrics;

  const riskFactors = [];

  if (handCondition < 70) {
    riskFactors.push("hand_injury_risk");
  }

  if (shoulderHealth < 75) {
    riskFactors.push("shoulder_instability");
  }

  if (headTraumaHistory > 3) {
    riskFactors.push("head_trauma_accumulation");
  }

  if (sparringVolume > 80) {
    riskFactors.push("overtraining_risk");
  }

  return {
    risk_level:
      riskFactors.length > 2
        ? "high"
        : riskFactors.length > 0
          ? "medium"
          : "low",
    active_risk_factors: riskFactors,
    monitoring_recommendations: generateMonitoringRecommendations(riskFactors),
  };
}

function generateMonitoringRecommendations(riskFactors) {
  const recommendations = [];

  if (riskFactors.includes("hand_injury_risk")) {
    recommendations.push("Daily hand wrap checks and ice therapy");
  }

  if (riskFactors.includes("shoulder_instability")) {
    recommendations.push("Shoulder stability exercises and physiotherapy");
  }

  if (riskFactors.includes("head_trauma_accumulation")) {
    recommendations.push("Neurological screening and reduced sparring volume");
  }

  if (riskFactors.includes("overtraining_risk")) {
    recommendations.push("Training load management and additional rest days");
  }

  return recommendations;
}

function getTacticalGrade(score) {
  if (score >= 90) return "A+";
  if (score >= 85) return "A";
  if (score >= 80) return "A-";
  if (score >= 75) return "B+";
  if (score >= 70) return "B";
  if (score >= 65) return "B-";
  if (score >= 60) return "C";
  return "D";
}

function getRecoveryGrade(score) {
  if (score >= 85) return "Excellent";
  if (score >= 75) return "Very Good";
  if (score >= 65) return "Good";
  if (score >= 55) return "Fair";
  if (score >= 45) return "Poor";
  return "Critical";
}

function getCoalitionTier(bviScore) {
  if (bviScore >= 90) return "Championship Elite";
  if (bviScore >= 80) return "Summit";
  if (bviScore >= 70) return "Elite";
  if (bviScore >= 60) return "Development";
  return "Foundation";
}
