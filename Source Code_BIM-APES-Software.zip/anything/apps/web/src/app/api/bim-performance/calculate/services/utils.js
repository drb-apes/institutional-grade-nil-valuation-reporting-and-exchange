// /apps/web/src/app/api/bim-performance/calculate/services/utils.js

export function calculateBodyVolume(keyPoints, frameCount) {
  // Simplified body volume estimation from key points
  if (!keyPoints || keyPoints.length === 0) return 65; // Default volume in liters

  const avgConfidence =
    keyPoints.reduce((sum, point) => sum + point.confidence, 0) /
    keyPoints.length;
  const volume = 50 + avgConfidence * 30; // Volume range: 50-80L based on pose confidence

  return volume;
}

export function estimateHeight(keyPoints) {
  // Estimate height from key point distribution (simplified)
  if (!keyPoints || keyPoints.length === 0) return 1.75; // Default 1.75m

  const yCoords = keyPoints.map((point) => point.y).filter((y) => y > 0);
  if (yCoords.length === 0) return 1.75;

  const range = Math.max(...yCoords) - Math.min(...yCoords);
  return 1.5 + (range / 720) * 0.5; // Scale range to reasonable height
}

export function calculateCorrelation(x, y) {
  // Simplified correlation coefficient
  return Math.abs(x - y) < 0.2 ? 0.8 : 0.3;
}
