import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Sport-specific valuation engines
const SPORT_ENGINES = {
  elite_basketball: {
    calculateValuation: (params) => {
      const {
        draft_pick_number,
        team_fit_score,
        biometric_milestones,
        tier_config,
      } = params;

      // NBA-specific logic
      const pickTier = getPickTier(draft_pick_number, "basketball");
      const teamFitMultiplier = calculateTeamFitMultiplier(
        team_fit_score,
        params.team_name,
        "basketball",
      );
      const contractValues = getNBAContractValue(draft_pick_number, 120);
      const biometricBoost = calculateBiometricBoost(
        biometric_milestones,
        "basketball",
      );

      const baseValuation = contractValues.total_potential;
      const tierAdjustedValue = baseValuation * pickTier.base_multiplier;
      const teamFitAdjustedValue =
        tierAdjustedValue * teamFitMultiplier.multiplier;
      const finalValuation = teamFitAdjustedValue * (1 + biometricBoost.boost);
      const coalitionValuation =
        finalValuation * tier_config.contractLogic.coalitionPercentage;

      return {
        base_contract_value: baseValuation,
        tier_adjusted_value: tierAdjustedValue,
        team_fit_adjusted_value: teamFitAdjustedValue,
        final_valuation: finalValuation,
        coalition_asset_value: coalitionValuation,
        pick_tier: pickTier.tier,
        team_fit_grade: teamFitMultiplier.fit_tier,
        biometric_index: biometricBoost.index_score,
        contract_years: 4,
      };
    },
  },

  elite_gridiron: {
    calculateValuation: (params) => {
      const {
        draft_pick_number,
        team_fit_score,
        biometric_milestones,
        tier_config,
      } = params;

      // NFL-specific logic
      const pickTier = getPickTier(draft_pick_number, "gridiron");
      const teamFitMultiplier = calculateTeamFitMultiplier(
        team_fit_score,
        params.team_name,
        "gridiron",
      );
      const contractValues = getNFLContractValue(draft_pick_number);
      const biometricBoost = calculateBiometricBoost(
        biometric_milestones,
        "gridiron",
      );

      const baseValuation = contractValues.total_value;
      const tierAdjustedValue = baseValuation * pickTier.base_multiplier;
      const teamFitAdjustedValue =
        tierAdjustedValue * teamFitMultiplier.multiplier;
      const finalValuation = teamFitAdjustedValue * (1 + biometricBoost.boost);
      const coalitionValuation =
        finalValuation * tier_config.contractLogic.coalitionPercentage;

      return {
        base_contract_value: baseValuation,
        tier_adjusted_value: tierAdjustedValue,
        team_fit_adjusted_value: teamFitAdjustedValue,
        final_valuation: finalValuation,
        coalition_asset_value: coalitionValuation,
        pick_tier: pickTier.tier,
        team_fit_grade: teamFitMultiplier.fit_tier,
        biometric_index: biometricBoost.index_score,
        contract_years: 4,
      };
    },
  },

  combat_performance: {
    calculateValuation: (params) => {
      const {
        draft_pick_number,
        team_fit_score,
        biometric_milestones,
        tier_config,
      } = params;

      // Combat sports logic
      const pickTier = getPickTier(draft_pick_number, "combat");
      const teamFitMultiplier = calculateTeamFitMultiplier(
        team_fit_score,
        params.team_name,
        "combat",
      );
      const contractValues = getCombatContractValue(draft_pick_number);
      const biometricBoost = calculateBiometricBoost(
        biometric_milestones,
        "combat",
      );

      const baseValuation = contractValues.total_value;
      const tierAdjustedValue = baseValuation * pickTier.base_multiplier;
      const teamFitAdjustedValue =
        tierAdjustedValue * teamFitMultiplier.multiplier;
      const finalValuation = teamFitAdjustedValue * (1 + biometricBoost.boost);
      const coalitionValuation =
        finalValuation * tier_config.contractLogic.coalitionPercentage;

      return {
        base_contract_value: baseValuation,
        tier_adjusted_value: tierAdjustedValue,
        team_fit_adjusted_value: teamFitAdjustedValue,
        final_valuation: finalValuation,
        coalition_asset_value: coalitionValuation,
        pick_tier: pickTier.tier,
        team_fit_grade: teamFitMultiplier.fit_tier,
        biometric_index: biometricBoost.index_score,
        contract_years: 1,
      };
    },
  },

  collegiate_advancement: {
    calculateValuation: (params) => {
      const {
        draft_pick_number,
        team_fit_score,
        biometric_milestones,
        tier_config,
      } = params;

      // Collegiate logic
      const pickTier = getPickTier(draft_pick_number, "collegiate");
      const teamFitMultiplier = calculateTeamFitMultiplier(
        team_fit_score,
        params.team_name,
        "collegiate",
      );
      const contractValues = getCollegiateValue(draft_pick_number);
      const biometricBoost = calculateBiometricBoost(
        biometric_milestones,
        "collegiate",
      );

      const baseValuation = contractValues.total_value;
      const tierAdjustedValue = baseValuation * pickTier.base_multiplier;
      const teamFitAdjustedValue =
        tierAdjustedValue * teamFitMultiplier.multiplier;
      const finalValuation = teamFitAdjustedValue * (1 + biometricBoost.boost);
      const coalitionValuation =
        finalValuation * tier_config.contractLogic.coalitionPercentage;

      return {
        base_contract_value: baseValuation,
        tier_adjusted_value: tierAdjustedValue,
        team_fit_adjusted_value: teamFitAdjustedValue,
        final_valuation: finalValuation,
        coalition_asset_value: coalitionValuation,
        pick_tier: pickTier.tier,
        team_fit_grade: teamFitMultiplier.fit_tier,
        biometric_index: biometricBoost.index_score,
        contract_years: 4,
      };
    },
  },

  federation_performance: {
    calculateValuation: (params) => {
      const {
        draft_pick_number,
        team_fit_score,
        biometric_milestones,
        tier_config,
      } = params;

      // Federation logic
      const pickTier = getPickTier(draft_pick_number, "federation");
      const teamFitMultiplier = calculateTeamFitMultiplier(
        team_fit_score,
        params.team_name,
        "federation",
      );
      const contractValues = getFederationValue(draft_pick_number);
      const biometricBoost = calculateBiometricBoost(
        biometric_milestones,
        "federation",
      );

      const baseValuation = contractValues.total_value;
      const tierAdjustedValue = baseValuation * pickTier.base_multiplier;
      const teamFitAdjustedValue =
        tierAdjustedValue * teamFitMultiplier.multiplier;
      const finalValuation = teamFitAdjustedValue * (1 + biometricBoost.boost);
      const coalitionValuation =
        finalValuation * tier_config.contractLogic.coalitionPercentage;

      return {
        base_contract_value: baseValuation,
        tier_adjusted_value: tierAdjustedValue,
        team_fit_adjusted_value: teamFitAdjustedValue,
        final_valuation: finalValuation,
        coalition_asset_value: coalitionValuation,
        pick_tier: pickTier.tier,
        team_fit_grade: teamFitMultiplier.fit_tier,
        biometric_index: biometricBoost.index_score,
        contract_years: 2,
      };
    },
  },
};

// Helper functions for each sport
function getPickTier(pickNumber, sport) {
  const tiers = {
    basketball: {
      1: {
        tier: "premier",
        base_multiplier: 1.4,
        description: "Premier lottery pick",
      },
      15: {
        tier: "high",
        base_multiplier: 1.2,
        description: "High first round",
      },
      21: {
        tier: "core",
        base_multiplier: 1.1,
        description: "Core first round",
      },
      31: {
        tier: "development",
        base_multiplier: 0.9,
        description: "Development pick",
      },
    },
    gridiron: {
      1: {
        tier: "round1",
        base_multiplier: 1.5,
        description: "First round premium",
      },
      33: {
        tier: "round2",
        base_multiplier: 1.2,
        description: "Second round value",
      },
      65: {
        tier: "round3",
        base_multiplier: 1.0,
        description: "Mid-round selection",
      },
      105: {
        tier: "later",
        base_multiplier: 0.8,
        description: "Late round depth",
      },
    },
    combat: {
      1: {
        tier: "global",
        base_multiplier: 2.0,
        description: "Global elite tier",
      },
      6: {
        tier: "regional",
        base_multiplier: 1.3,
        description: "Regional contender",
      },
      21: {
        tier: "developmental",
        base_multiplier: 0.9,
        description: "Development level",
      },
    },
    collegiate: {
      1: {
        tier: "full_scholarship",
        base_multiplier: 1.8,
        description: "Full scholarship offer",
      },
      2: {
        tier: "partial_scholarship",
        base_multiplier: 1.2,
        description: "Partial scholarship",
      },
      6: {
        tier: "walk_on",
        base_multiplier: 0.8,
        description: "Walk-on opportunity",
      },
    },
    federation: {
      1: {
        tier: "global_elite",
        base_multiplier: 2.2,
        description: "Global elite level",
      },
      4: {
        tier: "continental",
        base_multiplier: 1.4,
        description: "Continental level",
      },
      16: {
        tier: "national",
        base_multiplier: 1.0,
        description: "National level",
      },
      51: {
        tier: "developmental",
        base_multiplier: 0.7,
        description: "Development pipeline",
      },
    },
  };

  const sportTiers = tiers[sport] || tiers.basketball;
  const tierKeys = Object.keys(sportTiers)
    .map(Number)
    .sort((a, b) => b - a);

  for (const threshold of tierKeys) {
    if (pickNumber >= threshold) {
      return sportTiers[threshold];
    }
  }

  return sportTiers[tierKeys[tierKeys.length - 1]];
}

function calculateTeamFitMultiplier(teamFitScore, teamName, sport) {
  const premiumOrganizations = {
    basketball: ["Lakers", "Warriors", "Celtics", "Knicks", "Bulls"],
    gridiron: ["Patriots", "Cowboys", "Steelers", "Packers", "49ers"],
    combat: ["UFC", "Bellator", "ONE Championship"],
    collegiate: ["Duke", "Kentucky", "North Carolina", "Kansas"],
    federation: ["Team USA", "British Team", "German Federation"],
  };

  const isPremium = premiumOrganizations[sport]?.includes(teamName) || false;

  let multiplier = 1.0;

  if (teamFitScore >= 80) {
    multiplier = isPremium ? 1.2 : 1.1;
  } else if (teamFitScore >= 60) {
    multiplier = isPremium ? 1.1 : 1.0;
  } else if (teamFitScore >= 40) {
    multiplier = isPremium ? 1.0 : 0.9;
  } else {
    multiplier = isPremium ? 0.9 : 0.8;
  }

  return {
    multiplier,
    organization_tier: isPremium ? "premium" : "standard",
    fit_tier:
      teamFitScore >= 80
        ? "excellent"
        : teamFitScore >= 60
          ? "good"
          : teamFitScore >= 40
            ? "fair"
            : "poor",
  };
}

function calculateBiometricBoost(biometrics, sport) {
  if (!biometrics) return { boost: 0, index_score: 50 };

  let scores = [];

  switch (sport) {
    case "basketball":
      scores = [
        Math.min(100, ((biometrics.vertical_leap || 30) / 40) * 100),
        Math.min(100, (((biometrics.wingspan || 80) - 70) / 20) * 100),
        Math.min(100, ((15 - (biometrics.lane_agility || 11)) / 6) * 100),
        Math.min(100, biometrics.shooting_form || 70),
      ];
      break;
    case "gridiron":
      scores = [
        Math.min(100, ((5.5 - (biometrics.forty_yard || 4.6)) / 1.5) * 100),
        Math.min(100, ((biometrics.bench_press || 15) / 30) * 100),
        Math.min(100, ((biometrics.vertical_jump || 30) / 40) * 100),
        Math.min(100, ((biometrics.wonderlic || 20) / 40) * 100),
      ];
      break;
    case "combat":
      scores = [
        Math.min(100, (((biometrics.reach || 70) - 60) / 25) * 100),
        Math.min(100, biometrics.strike_accuracy || 60),
        Math.min(100, biometrics.takedown_defense || 70),
        Math.min(100, biometrics.fight_iq || 70),
      ];
      break;
    case "collegiate":
      scores = [
        Math.min(100, biometrics.combine_score || 70),
        Math.min(100, biometrics.academic_score || 80),
        Math.min(100, biometrics.marketability || 50),
        Math.min(100, biometrics.position_rating || 70),
      ];
      break;
    case "federation":
      scores = [
        Math.min(100, (((biometrics.vo2_max || 55) - 40) / 45) * 100),
        Math.min(100, biometrics.time_trial || 70),
        Math.min(100, biometrics.form_score || 75),
        Math.min(100, biometrics.mental_game || 70),
      ];
      break;
    default:
      scores = [75, 75, 75, 75];
  }

  const indexScore = scores.reduce((a, b) => a + b, 0) / scores.length;
  const boost = (indexScore / 100) * 0.15; // Up to 15% boost

  return {
    boost,
    index_score: Math.round(indexScore * 10) / 10,
    breakdown: scores.map((s) => Math.round(s)),
  };
}

function getNBAContractValue(pickNumber, scalePercentage = 120) {
  const baseValues = {
    1: 11920000,
    2: 10740000,
    3: 9700000,
    4: 8790000,
    5: 8080000,
    6: 7400000,
    7: 6820000,
    8: 6300000,
    9: 5850000,
    10: 5420000,
    11: 5020000,
    12: 4640000,
    13: 4320000,
    14: 4020000,
    15: 3740000,
    16: 3480000,
    17: 3250000,
    18: 3020000,
    19: 2820000,
    20: 2620000,
    21: 2450000,
    22: 2290000,
    23: 2140000,
    24: 2000000,
    25: 1870000,
    26: 1750000,
    27: 1640000,
    28: 1540000,
    29: 1450000,
    30: 1370000,
  };

  let baseValue = baseValues[pickNumber] || 1100000;
  baseValue = baseValue * (scalePercentage / 100);

  return {
    year_1: baseValue,
    year_2: baseValue * 1.22,
    year_3_option: baseValue * 1.45,
    year_4_option: baseValue * 1.68,
    total_guaranteed: baseValue + baseValue * 1.22,
    total_potential: baseValue * (1 + 1.22 + 1.45 + 1.68),
  };
}

function getNFLContractValue(pickNumber) {
  const slotValues = {
    1: 37840000,
    2: 35040000,
    3: 32480000,
    4: 30120000,
    5: 27960000,
    6: 25980000,
    7: 24170000,
    8: 22520000,
    9: 21010000,
    10: 19640000,
    11: 18390000,
    12: 17250000,
    13: 16220000,
    14: 15280000,
    15: 14430000,
    16: 13660000,
    17: 12960000,
    18: 12330000,
    19: 11760000,
    20: 11240000,
    21: 10770000,
    22: 10340000,
    23: 9950000,
    24: 9590000,
    25: 9260000,
    26: 8960000,
    27: 8680000,
    28: 8420000,
    29: 8170000,
    30: 7940000,
    31: 7720000,
    32: 7510000,
  };

  const baseValue =
    slotValues[pickNumber] ||
    Math.max(1000000, 7510000 - (pickNumber - 32) * 100000);

  return {
    total_value: baseValue,
    guaranteed: baseValue * 0.8,
    signing_bonus: baseValue * 0.4,
  };
}

function getCombatContractValue(pickNumber) {
  const purseValues = {
    1: 500000,
    2: 400000,
    3: 350000,
    4: 300000,
    5: 250000,
    6: 200000,
    7: 175000,
    8: 150000,
    9: 125000,
    10: 100000,
  };

  const basePurse =
    purseValues[pickNumber] ||
    Math.max(50000, 100000 - (pickNumber - 10) * 5000);

  return {
    bout_purse: basePurse,
    performance_bonus: basePurse * 0.5,
    media_equity: basePurse * 0.3,
    total_value: basePurse * 1.8,
  };
}

function getCollegiateValue(pickNumber) {
  const scholarshipValues = {
    1: 80000,
    2: 60000,
    3: 45000,
    4: 35000,
    5: 25000,
    6: 15000,
    7: 10000,
    8: 5000,
  };

  const baseScholarship = scholarshipValues[pickNumber] || 2000;
  const nilPotential =
    baseScholarship * (pickNumber <= 3 ? 2.5 : pickNumber <= 10 ? 1.5 : 0.5);

  return {
    scholarship_value: baseScholarship,
    nil_potential: nilPotential,
    total_value: baseScholarship + nilPotential,
  };
}

function getFederationValue(pickNumber) {
  const supportValues = {
    1: 120000,
    2: 100000,
    3: 85000,
    4: 70000,
    5: 60000,
    10: 50000,
    15: 40000,
    25: 30000,
    50: 20000,
  };

  let baseSupport = 10000;
  for (const [threshold, value] of Object.entries(supportValues)) {
    if (pickNumber <= parseInt(threshold)) {
      baseSupport = value;
      break;
    }
  }

  return {
    federation_support: baseSupport,
    medal_bonus: baseSupport * 0.5,
    sponsor_equity: baseSupport * 0.8,
    total_value: baseSupport * 2.3,
  };
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const {
      sport_tier,
      draft_pick_number,
      team_fit_score,
      rookie_scale_percentage = 120,
      guaranteed_years = 2,
      team_options = 2,
      biometric_milestones,
      contributor_ids = [],
      athlete_id,
      team_name,
      tier_config,
    } = await request.json();

    // Validate inputs
    if (!sport_tier || !SPORT_ENGINES[sport_tier]) {
      return Response.json(
        { error: "Invalid sport tier specified" },
        { status: 400 },
      );
    }

    if (
      !draft_pick_number ||
      draft_pick_number < 1 ||
      draft_pick_number > 300
    ) {
      return Response.json(
        { error: "Draft pick number must be between 1-300" },
        { status: 400 },
      );
    }

    if (!team_fit_score || team_fit_score < 0 || team_fit_score > 100) {
      return Response.json(
        { error: "Team fit score must be between 0-100" },
        { status: 400 },
      );
    }

    // Execute sport-specific valuation
    const sportEngine = SPORT_ENGINES[sport_tier];
    const valuationSummary = sportEngine.calculateValuation({
      draft_pick_number,
      team_fit_score,
      biometric_milestones,
      tier_config,
      team_name,
      rookie_scale_percentage,
      guaranteed_years,
      team_options,
    });

    // Process contributor credits
    const contributorCredits = await processContributorCredits(contributor_ids);

    // Create simulation record
    const simulationData = {
      sport_tier,
      draft_pick_number,
      valuation_summary: valuationSummary,
      biometric_analysis: calculateBiometricBoost(
        biometric_milestones,
        sport_tier.split("_")[1] || "basketball",
      ),
      contributor_credits: contributorCredits,
      simulation_parameters: {
        rookie_scale_percentage,
        guaranteed_years,
        team_options,
        team_name,
        tier_config: tier_config?.name || sport_tier,
      },
    };

    // Store simulation if athlete_id provided
    if (athlete_id) {
      await sql`
        INSERT INTO asset_simulations (
          athlete_id,
          asset_value,
          roi_projection,
          risk_score,
          simulation_data,
          valuation_factors
        ) VALUES (
          ${athlete_id},
          ${valuationSummary.coalition_asset_value},
          ${Math.min(30, Math.max(5, (valuationSummary.biometric_index / 100) * 25 + 5))},
          ${Math.max(0.1, Math.min(0.9, 1 - team_fit_score / 100))},
          ${JSON.stringify(simulationData)},
          ${JSON.stringify({
            sport_type: sport_tier,
            draft_pick: draft_pick_number,
            team_fit_score,
            biometric_index: valuationSummary.biometric_index,
          })}
        )
      `;
    }

    return Response.json({
      success: true,
      simulation_id: `${sport_tier.toUpperCase()}-${draft_pick_number}-${Date.now()}`,
      valuation_summary: valuationSummary,
      detailed_analysis: simulationData,
      artifacts: {
        valuation_sheet_url: `/api/draft-equity-card/${athlete_id}/pdf`,
        draft_equity_card_url: `/api/draft-equity-card/${athlete_id}`,
        contributor_ledger: contributorCredits,
        simulator_walkthrough: `BIM Draft Equity Engine v2.0 - ${tier_config?.name || sport_tier}`,
      },
    });
  } catch (error) {
    console.error("Draft Equity Engine error:", error);
    return Response.json(
      {
        error: "Draft valuation simulation failed",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function processContributorCredits(contributorIds) {
  if (!contributorIds.length) return [];

  // In a real implementation, you would fetch contributor data from the database
  // For now, return mock data based on IDs
  return contributorIds.map((id, index) => {
    const roles = [
      "scout_summit",
      "coach_certified",
      "analyst_performance",
      "mentor_community",
    ];
    const roleNames = [
      "Scout (Summit)",
      "Coach (Certified)",
      "Performance Analyst",
      "Community Mentor",
    ];
    const impacts = [25, 20, 15, 10];

    const roleIndex = index % roles.length;

    return {
      id,
      name: `Contributor ${id}`,
      role: roleNames[roleIndex],
      organization: "Coalition Network",
      impact_percentage: impacts[roleIndex],
      consent_status: "verified",
    };
  });
}

// GET endpoint for retrieving simulation history
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athlete_id");
    const sportTier = searchParams.get("sport_tier");
    const limit = parseInt(searchParams.get("limit")) || 10;

    let simulations;

    if (athleteId) {
      simulations = await sql`
        SELECT 
          id,
          asset_value,
          roi_projection,
          risk_score,
          simulation_data,
          created_at
        FROM asset_simulations
        WHERE athlete_id = ${athleteId}
          AND simulation_data->>'sport_tier' IS NOT NULL
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    } else {
      let whereClause = `WHERE simulation_data->>'sport_tier' IS NOT NULL`;
      const params = [limit];

      if (sportTier) {
        whereClause += ` AND simulation_data->>'sport_tier' = $2`;
        params.unshift(sportTier);
      }

      simulations = await sql`
        SELECT 
          id,
          athlete_id,
          asset_value,
          roi_projection,
          simulation_data,
          created_at
        FROM asset_simulations
        ${sql.raw(whereClause)}
        ORDER BY created_at DESC
        LIMIT $${params.length}
      `.apply(null, params);
    }

    return Response.json({
      simulations: simulations.map((sim) => ({
        id: sim.id,
        athlete_id: sim.athlete_id,
        sport_tier: sim.simulation_data?.sport_tier,
        draft_pick: sim.simulation_data?.draft_pick_number,
        final_valuation:
          sim.simulation_data?.valuation_summary?.final_valuation,
        coalition_value: sim.asset_value,
        created_at: sim.created_at,
      })),
    });
  } catch (error) {
    console.error("Simulation history error:", error);
    return Response.json(
      {
        error: "Failed to retrieve simulation history",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
