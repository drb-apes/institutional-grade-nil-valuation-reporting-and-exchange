import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const url = new URL(request.url);
    const athleteId = url.searchParams.get("athlete_id");
    const timeframe = url.searchParams.get("timeframe") || "30"; // days
    const limit = parseInt(url.searchParams.get("limit") || "20");

    // Get user profile
    let userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const profile = userProfile[0];

    // If specific athlete requested and user has permission
    let targetAthleteId = athleteId || profile.id;

    // Check if user can access this athlete's data
    if (athleteId && athleteId !== profile.id.toString()) {
      // Only allow if user is coach, dao member, or institutional
      if (!["dao_member", "institutional"].includes(profile.user_type)) {
        return Response.json({ error: "Access denied" }, { status: 403 });
      }
    }

    // **GET BIM PERFORMANCE INDEX HISTORY**
    const performanceHistory = await sql`
      SELECT 
        s.id,
        s.asset_value as overall_score,
        s.roi_projection,
        s.risk_score,
        s.simulation_data,
        s.valuation_factors,
        s.created_at,
        m.motion_type,
        m.ai_score as motion_ai_score,
        m.verification_status,
        up.user_id,
        au.name as athlete_name,
        au.email as athlete_email
      FROM asset_simulations s
      LEFT JOIN motion_scans m ON s.motion_scan_id = m.id
      JOIN user_profiles up ON s.athlete_id = up.id
      JOIN auth_users au ON up.user_id = au.id
      WHERE s.athlete_id = ${targetAthleteId}
        AND s.created_at >= NOW() - INTERVAL '${timeframe} days'
      ORDER BY s.created_at DESC
      LIMIT ${limit}
    `;

    // **GET CURRENT ATHLETE STATS**
    const athleteStats = await sql`
      SELECT 
        up.*,
        au.name,
        au.email,
        COUNT(DISTINCT m.id) as total_scans,
        COUNT(DISTINCT s.id) as total_simulations,
        AVG(m.ai_score) as avg_motion_score,
        AVG(s.asset_value) as avg_performance_score,
        MAX(s.created_at) as last_analysis
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      LEFT JOIN motion_scans m ON up.id = m.athlete_id
      LEFT JOIN asset_simulations s ON up.id = s.athlete_id
      WHERE up.id = ${targetAthleteId}
      GROUP BY up.id, au.name, au.email
    `;

    if (athleteStats.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteStats[0];

    // **CALCULATE PERFORMANCE TRENDS**
    const trendAnalysis = calculatePerformanceTrends(performanceHistory);

    // **GET TIER PROGRESSION HISTORY**
    const tierHistory = await sql`
      SELECT DISTINCT
        tier_level,
        updated_at
      FROM user_profiles 
      WHERE id = ${targetAthleteId}
      ORDER BY updated_at DESC
      LIMIT 10
    `;

    // **GET RECENT MILESTONES**
    const milestones = await sql`
      SELECT 
        m.*,
        cp.total_amount as pool_amount,
        cp.contributor_count
      FROM milestones m
      LEFT JOIN contribution_pools cp ON m.id = cp.milestone_id
      WHERE m.athlete_id = ${targetAthleteId}
      ORDER BY m.created_at DESC
      LIMIT 5
    `;

    // **CALCULATE CROSS-CORRELATION INSIGHTS**
    const correlationInsights = calculateCrossCorrelations(performanceHistory);

    // **GENERATE COACHING RECOMMENDATIONS**
    const coachingRecommendations = generateCoachingRecommendations(
      performanceHistory,
      athlete,
    );

    return Response.json({
      success: true,
      athlete: {
        id: athlete.id,
        name: athlete.name,
        email: athlete.email,
        user_type: athlete.user_type,
        tier_level: athlete.tier_level,
        reputation_score: athlete.reputation_score,
        total_contributions: athlete.total_contributions,
        total_earnings: athlete.total_earnings,
        stats: {
          total_scans: parseInt(athlete.total_scans) || 0,
          total_simulations: parseInt(athlete.total_simulations) || 0,
          avg_motion_score: parseFloat(athlete.avg_motion_score) || 0,
          avg_performance_score: parseFloat(athlete.avg_performance_score) || 0,
          last_analysis: athlete.last_analysis,
        },
      },
      performance_history: performanceHistory.map((record) => ({
        id: record.id,
        overall_score: record.overall_score,
        roi_projection: record.roi_projection,
        risk_score: record.risk_score,
        performance_index: record.simulation_data,
        coaching_insights: record.valuation_factors,
        motion_type: record.motion_type,
        motion_ai_score: record.motion_ai_score,
        verification_status: record.verification_status,
        created_at: record.created_at,
      })),
      trends: trendAnalysis,
      tier_history: tierHistory,
      milestones: milestones,
      correlation_insights: correlationInsights,
      coaching_recommendations: coachingRecommendations,
      timeframe: `${timeframe} days`,
    });
  } catch (error) {
    console.error("BIM dashboard error:", error);
    return Response.json(
      {
        error: "Failed to fetch BIM performance dashboard",
      },
      { status: 500 },
    );
  }
}

// **PERFORMANCE TREND ANALYSIS**
function calculatePerformanceTrends(history) {
  if (history.length < 2) {
    return {
      overall_trend: "insufficient_data",
      performance_change: 0,
      consistency_trend: "stable",
      recent_performance: null,
    };
  }

  const scores = history.map((h) => parseFloat(h.overall_score));
  const recent = scores.slice(0, Math.min(5, scores.length));
  const older = scores.slice(5);

  const recentAvg =
    recent.reduce((sum, score) => sum + score, 0) / recent.length;
  const olderAvg =
    older.length > 0
      ? older.reduce((sum, score) => sum + score, 0) / older.length
      : recentAvg;

  const performanceChange = ((recentAvg - olderAvg) / olderAvg) * 100;

  // Calculate consistency
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - recentAvg, 2), 0) /
    scores.length;
  const standardDeviation = Math.sqrt(variance);
  const coefficientOfVariation = standardDeviation / recentAvg;

  let consistencyTrend = "stable";
  if (coefficientOfVariation < 0.1) consistencyTrend = "highly_consistent";
  else if (coefficientOfVariation > 0.2) consistencyTrend = "variable";

  let overallTrend = "stable";
  if (performanceChange > 5) overallTrend = "improving";
  else if (performanceChange < -5) overallTrend = "declining";

  return {
    overall_trend: overallTrend,
    performance_change: parseFloat(performanceChange.toFixed(2)),
    consistency_trend: consistencyTrend,
    consistency_score: parseFloat((1 - coefficientOfVariation).toFixed(2)),
    recent_performance: parseFloat(recentAvg.toFixed(2)),
    data_points: scores.length,
  };
}

// **CROSS-CORRELATION ANALYSIS**
function calculateCrossCorrelations(history) {
  if (history.length < 3) {
    return {
      roi_performance_correlation: 0,
      risk_consistency_correlation: 0,
      motion_type_performance: {},
      verification_impact: 0,
    };
  }

  const scores = history.map((h) => parseFloat(h.overall_score));
  const rois = history.map((h) => parseFloat(h.roi_projection));
  const risks = history.map((h) => parseFloat(h.risk_score));

  // Simple correlation calculation
  const roiPerformanceCorr = calculateSimpleCorrelation(rois, scores);
  const riskConsistencyCorr = calculateSimpleCorrelation(risks, scores);

  // Motion type performance analysis
  const motionTypePerformance = {};
  history.forEach((record) => {
    const motionType = record.motion_type;
    if (motionType) {
      if (!motionTypePerformance[motionType]) {
        motionTypePerformance[motionType] = { scores: [], count: 0 };
      }
      motionTypePerformance[motionType].scores.push(
        parseFloat(record.overall_score),
      );
      motionTypePerformance[motionType].count++;
    }
  });

  // Calculate averages for each motion type
  Object.keys(motionTypePerformance).forEach((type) => {
    const typeData = motionTypePerformance[type];
    typeData.average =
      typeData.scores.reduce((sum, score) => sum + score, 0) /
      typeData.scores.length;
  });

  // Verification impact
  const verifiedScores = history
    .filter((h) => h.verification_status === "verified")
    .map((h) => parseFloat(h.overall_score));
  const unverifiedScores = history
    .filter((h) => h.verification_status !== "verified")
    .map((h) => parseFloat(h.overall_score));

  const verifiedAvg =
    verifiedScores.length > 0
      ? verifiedScores.reduce((sum, s) => sum + s, 0) / verifiedScores.length
      : 0;
  const unverifiedAvg =
    unverifiedScores.length > 0
      ? unverifiedScores.reduce((sum, s) => sum + s, 0) /
        unverifiedScores.length
      : 0;

  const verificationImpact = verifiedAvg - unverifiedAvg;

  return {
    roi_performance_correlation: parseFloat(roiPerformanceCorr.toFixed(2)),
    risk_consistency_correlation: parseFloat(riskConsistencyCorr.toFixed(2)),
    motion_type_performance: motionTypePerformance,
    verification_impact: parseFloat(verificationImpact.toFixed(2)),
  };
}

// **COACHING RECOMMENDATIONS ENGINE**
function generateCoachingRecommendations(history, athlete) {
  const recommendations = [];

  if (history.length === 0) {
    return [
      {
        category: "getting_started",
        priority: "high",
        title: "Begin BIM Performance Tracking",
        description:
          "Complete your first motion scan to establish baseline performance metrics.",
        action_items: [
          "Record motion scan",
          "Set performance goals",
          "Review BIM methodology",
        ],
      },
    ];
  }

  const recentScores = history
    .slice(0, 5)
    .map((h) => parseFloat(h.overall_score));
  const avgScore =
    recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

  const scale = history[0].simulation_data?.scale_type || "pre_college";
  const maxScore = scale === "professional" ? 100 : 10;
  const threshold = maxScore * 0.75; // 75% threshold

  // Performance-based recommendations
  if (avgScore < threshold) {
    recommendations.push({
      category: "performance_improvement",
      priority: "high",
      title: "Focus on Core Performance Metrics",
      description: `Current average score (${avgScore.toFixed(1)}/${maxScore}) indicates opportunity for significant improvement.`,
      action_items: [
        "Analyze weakest BIM index components",
        "Implement targeted training protocols",
        "Increase motion scan frequency for better tracking",
      ],
    });
  }

  // Tier progression recommendations
  if (athlete.tier_level < 2 && avgScore >= threshold) {
    recommendations.push({
      category: "tier_advancement",
      priority: "medium",
      title: "Tier Advancement Opportunity",
      description:
        "Performance metrics suggest readiness for higher tier evaluation.",
      action_items: [
        "Complete consistent high-performance scans",
        "Document training improvements",
        "Submit for tier review",
      ],
    });
  }

  // Consistency recommendations
  const scores = history.map((h) => parseFloat(h.overall_score));
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - avgScore, 2), 0) /
    scores.length;
  const cv = Math.sqrt(variance) / avgScore;

  if (cv > 0.2) {
    // High variability
    recommendations.push({
      category: "consistency",
      priority: "medium",
      title: "Improve Performance Consistency",
      description:
        "High performance variability detected. Focus on stable execution.",
      action_items: [
        "Standardize pre-performance routines",
        "Monitor recovery and fatigue levels",
        "Practice in varied conditions",
      ],
    });
  }

  return recommendations;
}

// **UTILITY FUNCTIONS**
function calculateSimpleCorrelation(x, y) {
  if (x.length !== y.length || x.length === 0) return 0;

  const n = x.length;
  const sumX = x.reduce((sum, val) => sum + val, 0);
  const sumY = y.reduce((sum, val) => sum + val, 0);
  const sumXY = x.reduce((sum, val, i) => sum + val * y[i], 0);
  const sumXX = x.reduce((sum, val) => sum + val * val, 0);
  const sumYY = y.reduce((sum, val) => sum + val * val, 0);

  const numerator = n * sumXY - sumX * sumY;
  const denominator = Math.sqrt(
    (n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY),
  );

  return denominator === 0 ? 0 : numerator / denominator;
}
