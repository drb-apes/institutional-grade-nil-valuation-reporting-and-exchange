import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Stroke-specific technique analysis
function calculateStrokeTechnique(swimmingData, stroke) {
  const strokeRate = swimmingData.stroke_rate || 60; // strokes per minute
  const distancePerStroke = swimmingData.distance_per_stroke || 1.8; // meters
  const strokeEfficiency = swimmingData.stroke_efficiency || 0.75;

  switch (stroke) {
    case "freestyle":
      const catchPhase = swimmingData.catch_phase_score || 0.7;
      const bodyRotation = swimmingData.body_rotation_score || 0.75;
      const breathingPattern = swimmingData.breathing_pattern_efficiency || 0.8;

      return (
        catchPhase * 0.3 +
        bodyRotation * 0.25 +
        breathingPattern * 0.2 +
        strokeEfficiency * 0.25
      );

    case "backstroke":
      const armCycle = swimmingData.arm_cycle_coordination || 0.7;
      const bodyPosition = swimmingData.body_position_score || 0.75;
      const startTurn = swimmingData.start_turn_technique || 0.7;

      return (
        armCycle * 0.3 +
        bodyPosition * 0.3 +
        startTurn * 0.2 +
        strokeEfficiency * 0.2
      );

    case "breaststroke":
      const timing = swimmingData.stroke_timing_score || 0.7;
      const kickStrength = swimmingData.kick_strength_score || 0.75;
      const glidePhase = swimmingData.glide_phase_efficiency || 0.7;

      return (
        timing * 0.35 +
        kickStrength * 0.3 +
        glidePhase * 0.2 +
        strokeEfficiency * 0.15
      );

    case "butterfly":
      const undulation = swimmingData.body_undulation_score || 0.65;
      const armCoordination = swimmingData.arm_coordination_score || 0.7;
      const kickTiming = swimmingData.kick_timing_score || 0.7;

      return (
        undulation * 0.3 +
        armCoordination * 0.3 +
        kickTiming * 0.25 +
        strokeEfficiency * 0.15
      );

    default:
      return strokeEfficiency;
  }
}

// Race pace and energy distribution
function calculatePaceStrategy(swimmingData, distance) {
  const personalBest = swimmingData.personal_best_time || 120; // seconds
  const seasonBest = swimmingData.season_best_time || personalBest;

  // Split analysis
  const splits = swimmingData.split_times || [];
  let paceConsistency = 0.7;

  if (splits.length >= 2) {
    const splitVariations = [];
    for (let i = 1; i < splits.length; i++) {
      splitVariations.push(Math.abs(splits[i] - splits[i - 1]) / splits[i - 1]);
    }
    const avgVariation =
      splitVariations.reduce((a, b) => a + b, 0) / splitVariations.length;
    paceConsistency = Math.max(0, 1 - avgVariation * 5);
  }

  // Energy distribution based on distance
  let energyDistribution = 0.75;
  if (distance <= 100) {
    // Sprint events - explosive start and maintain
    const startSplit = swimmingData.first_50_split || personalBest / 2;
    const finishSplit = swimmingData.last_50_split || personalBest / 2;
    energyDistribution = Math.min(startSplit / finishSplit, 1.1); // Slight negative split OK
  } else if (distance <= 400) {
    // Middle distance - controlled aggression
    const firstQuarter = swimmingData.first_quarter_split || personalBest / 4;
    const lastQuarter = swimmingData.last_quarter_split || personalBest / 4;
    energyDistribution =
      1 - Math.abs(firstQuarter - lastQuarter) / firstQuarter;
  } else {
    // Distance events - build strategy
    const firstHalf = swimmingData.first_half_split || personalBest / 2;
    const secondHalf = swimmingData.second_half_split || personalBest / 2;
    energyDistribution = Math.min(firstHalf / secondHalf, 1.05); // Negative split preferred
  }

  return paceConsistency * 0.6 + energyDistribution * 0.4;
}

// Start and turn analysis
function calculateStartTurnPerformance(swimmingData, distance) {
  const reactionTime = swimmingData.reaction_time || 0.7; // seconds
  const reactionScore = Math.max(0, 1 - (reactionTime - 0.5) / 0.5);

  const startDistance = swimmingData.start_distance || 12; // meters underwater
  const startScore = Math.min(startDistance / 15, 1.0);

  // Turn performance (if applicable)
  let turnScore = 1.0; // Default for 50m events
  if (distance > 50) {
    const turnTime = swimmingData.average_turn_time || 1.5;
    const turnEfficiency = swimmingData.turn_efficiency || 0.75;
    turnScore = (turnEfficiency + Math.max(0, 1 - (turnTime - 1.0) / 1.0)) / 2;
  }

  const underwaterKick = swimmingData.underwater_kick_score || 0.75;

  return (
    reactionScore * 0.25 +
    startScore * 0.3 +
    turnScore * 0.25 +
    underwaterKick * 0.2
  );
}

// Training-to-race performance transfer
function calculateTrainingTransfer(swimmingData) {
  const practiceAverageTime = swimmingData.practice_average_time || 125;
  const raceTime = swimmingData.race_time || 120;

  // Training transfer efficiency
  const transferRatio = practiceAverageTime / raceTime;
  const transferScore = Math.min(transferRatio / 1.05, 1.0); // 5% improvement expected

  // Taper effectiveness
  const taperImprovement = swimmingData.taper_improvement_percentage || 0.02;
  const taperScore = Math.min(taperImprovement * 25, 1.0); // 4% = perfect

  // Meet preparation
  const meetPreparation = swimmingData.meet_preparation_score || 0.75;

  return transferScore * 0.4 + taperScore * 0.3 + meetPreparation * 0.3;
}

// Swimming tactical efficiency
function calculateSwimmingTacticalEfficiency(swimmingData, stroke, distance) {
  const strokeTechnique = calculateStrokeTechnique(swimmingData, stroke);
  const paceStrategy = calculatePaceStrategy(swimmingData, distance);
  const startTurnPerformance = calculateStartTurnPerformance(
    swimmingData,
    distance,
  );
  const trainingTransfer = calculateTrainingTransfer(swimmingData);

  return (
    strokeTechnique * 0.35 +
    paceStrategy * 0.25 +
    startTurnPerformance * 0.25 +
    trainingTransfer * 0.15
  );
}

// Swimming spike score
function calculateSwimmingSpikeScore(swimmingData) {
  const personalRecords = swimmingData.personal_records_this_season || 0;
  const meetWins = swimmingData.meet_wins || 0;
  const qualifyingTimes = swimmingData.qualifying_times_achieved || 0;
  const meetsAttended = swimmingData.meets_attended || 1;

  const prRate = personalRecords / meetsAttended;
  const winRate = meetWins / meetsAttended;
  const qualifyingRate = qualifyingTimes / meetsAttended;

  // Clutch performances in finals/championships
  const finalsPerformance = swimmingData.finals_improvement || 0; // % improvement from heats
  const championshipPerformance = swimmingData.championship_performance || 0.7;

  return Math.min(
    prRate * 0.3 +
      winRate * 0.25 +
      qualifyingRate * 0.2 +
      finalsPerformance * 5 +
      championshipPerformance * 0.25,
    1.0,
  );
}

// Swimming session consistency
async function calculateSwimmingSessionConsistency(athleteId, stroke) {
  const recentSessions = await sql`
    SELECT simulation_data->'swimming_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '45 days'
    AND valuation_factors->>'sport' = 'swimming'
    AND valuation_factors->>'stroke' = ${stroke}
    ORDER BY created_at DESC
    LIMIT 15
  `;

  if (recentSessions.length < 3) return 0.7;

  const tacticalScores = recentSessions.map(
    (s) => s.metrics?.tactical_efficiency || 0.7,
  );

  const mean =
    tacticalScores.reduce((a, b) => a + b, 0) / tacticalScores.length;
  const variance =
    tacticalScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    tacticalScores.length;

  return Math.max(0, 1 - variance * 2);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { swimming_data, stroke, distance, competition_level } =
      await request.json();

    if (!swimming_data || !stroke) {
      return Response.json(
        { error: "Swimming data and stroke type required" },
        { status: 400 },
      );
    }

    const validStrokes = [
      "freestyle",
      "backstroke",
      "breaststroke",
      "butterfly",
      "individual_medley",
    ];
    if (!validStrokes.includes(stroke)) {
      return Response.json(
        { error: `Stroke must be one of: ${validStrokes.join(", ")}` },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate swimming metrics
    const strokeTechnique = calculateStrokeTechnique(swimming_data, stroke);
    const paceStrategy = calculatePaceStrategy(swimming_data, distance);
    const startTurnPerformance = calculateStartTurnPerformance(
      swimming_data,
      distance,
    );
    const trainingTransfer = calculateTrainingTransfer(swimming_data);
    const tacticalEfficiency = calculateSwimmingTacticalEfficiency(
      swimming_data,
      stroke,
      distance,
    );
    const spikeScore = calculateSwimmingSpikeScore(swimming_data);
    const sessionConsistency = await calculateSwimmingSessionConsistency(
      athlete.id,
      stroke,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      stroke_technique: strokeTechnique,
      pace_strategy: paceStrategy,
      start_turn_performance: startTurnPerformance,
      training_transfer: trainingTransfer,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall swimming performance index
    const weights = {
      stroke_technique: 0.3,
      pace_strategy: 0.25,
      start_turn_performance: 0.2,
      training_transfer: 0.15,
      tactical_efficiency: 0.1,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => !["session_consistency", "spike_score"].includes(key))
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display based on competition level
    const isCollegiate =
      competition_level === "collegiate" ||
      competition_level === "professional" ||
      athlete.tier_level >= 3;
    const displayScale = isCollegiate ? 100 : 85;

    const displayMetrics = {
      stroke_technique: Math.round(strokeTechnique * displayScale),
      pace_strategy: Math.round(paceStrategy * displayScale),
      start_turn_performance: Math.round(startTurnPerformance * displayScale),
      training_transfer: Math.round(trainingTransfer * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isCollegiate ? "collegiate_swimming" : "high_school_swimming",
      stroke: stroke,
      distance: distance,
      timestamp: new Date().toISOString(),
    };

    // Generate swimming-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      swimming_tips: [],
    };

    // Analyze strengths and weaknesses
    if (performanceMetrics.stroke_technique >= 0.8) {
      insights.strengths.push("Excellent stroke technique and efficiency");
    } else if (performanceMetrics.stroke_technique <= 0.6) {
      insights.improvements.push("Focus on stroke technique refinement");
    }

    if (performanceMetrics.start_turn_performance >= 0.8) {
      insights.strengths.push("Outstanding starts and turns");
    } else if (performanceMetrics.start_turn_performance <= 0.6) {
      insights.improvements.push(
        "Work on start reaction time and turn efficiency",
      );
    }

    if (performanceMetrics.pace_strategy >= 0.8) {
      insights.strengths.push("Excellent race strategy and pacing");
    } else if (performanceMetrics.pace_strategy <= 0.6) {
      insights.improvements.push("Improve race pacing and energy distribution");
    }

    // Stroke-specific tips
    switch (stroke) {
      case "freestyle":
        if (performanceMetrics.stroke_technique <= 0.6) {
          insights.swimming_tips.push(
            "Focus on high elbow catch and body rotation",
          );
        }
        insights.swimming_tips.push("Practice bilateral breathing patterns");
        break;

      case "backstroke":
        if (performanceMetrics.stroke_technique <= 0.6) {
          insights.swimming_tips.push(
            "Work on body position and arm cycle timing",
          );
        }
        insights.swimming_tips.push(
          "Practice backstroke start and turn technique",
        );
        break;

      case "breaststroke":
        if (performanceMetrics.stroke_technique <= 0.6) {
          insights.swimming_tips.push(
            "Focus on timing coordination and kick strength",
          );
        }
        insights.swimming_tips.push("Practice underwater pullout technique");
        break;

      case "butterfly":
        if (performanceMetrics.stroke_technique <= 0.6) {
          insights.swimming_tips.push(
            "Work on body undulation and kick timing",
          );
        }
        insights.swimming_tips.push("Practice 2-beat breathing pattern");
        break;

      case "individual_medley":
        if (performanceMetrics.session_consistency <= 0.6) {
          insights.swimming_tips.push(
            "Balance training across all four strokes",
          );
        }
        insights.swimming_tips.push("Practice stroke transitions and turns");
        break;
    }

    // Distance-specific advice
    if (distance) {
      if (distance <= 100) {
        insights.swimming_tips.push(
          "Focus on explosive start and maximum speed maintenance",
        );
      } else if (distance <= 400) {
        insights.swimming_tips.push(
          "Practice controlled aggression and negative splitting",
        );
      } else {
        insights.swimming_tips.push(
          "Develop pacing strategy and build endurance base",
        );
      }
    }

    // Training transfer advice
    if (performanceMetrics.training_transfer <= 0.6) {
      insights.improvements.push("Improve race simulation in practice");
      insights.swimming_tips.push(
        "Practice competition scenarios and taper protocols",
      );
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.35, 1.0)}, -- Higher ROI for technical precision
        ${Math.max(0, 1 - sessionConsistency)},
        ${JSON.stringify({
          swimming_metrics: displayMetrics,
          swimming_data: swimming_data,
          sport_context: { stroke, distance, competition_level },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: "swimming",
          stroke: stroke,
          analysis_type: "swimming_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      swimming_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: "swimming",
      stroke: stroke,
      distance: distance,
      message: `Swimming Performance Index - ${stroke.toUpperCase()} ${distance ? `${distance}m` : ""}`,
    });
  } catch (error) {
    console.error("Swimming performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate swimming performance metrics" },
      { status: 500 },
    );
  }
}
