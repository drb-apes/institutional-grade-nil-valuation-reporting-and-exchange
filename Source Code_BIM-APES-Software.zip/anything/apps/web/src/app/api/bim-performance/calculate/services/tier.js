// /apps/web/src/app/api/bim-performance/calculate/services/tier.js
import sql from "@/app/api/utils/sql";

// **TIER ASSESSMENT LOGIC**
export function assessTierMovement(performanceIndex, currentTier) {
  const { overall_score, scale_type } = performanceIndex;

  let recommendedTier = currentTier;
  let tierChangeRecommended = false;
  let roiProjection = 5.0; // Base 5% ROI
  let riskScore = 0.3; // Base 30% risk

  // Tier advancement logic
  if (scale_type === "professional") {
    if (overall_score >= 85 && currentTier < 3) {
      recommendedTier = 3; // Elite
      tierChangeRecommended = true;
      roiProjection = 15.0;
      riskScore = 0.15;
    } else if (overall_score >= 70 && currentTier < 2) {
      recommendedTier = 2; // Pro
      tierChangeRecommended = true;
      roiProjection = 10.0;
      riskScore = 0.25;
    }
  } else {
    if (overall_score >= 8.5 && currentTier < 3) {
      recommendedTier = 3;
      tierChangeRecommended = true;
      roiProjection = 12.0;
      riskScore = 0.2;
    } else if (overall_score >= 7.0 && currentTier < 2) {
      recommendedTier = 2;
      tierChangeRecommended = true;
      roiProjection = 8.0;
      riskScore = 0.3;
    }
  }

  return {
    current_tier: currentTier,
    recommended_tier: recommendedTier,
    tier_change_recommended: tierChangeRecommended,
    roi_projection: roiProjection,
    risk_score: riskScore,
    advancement_rationale: tierChangeRecommended
      ? `Performance index of ${overall_score} exceeds tier ${recommendedTier} threshold`
      : "Current tier appropriate based on performance metrics",
  };
}

// **🏷️ TIER BADGE ASSIGNMENT SYSTEM**
export async function assignTierBadge(
  athleteId,
  performanceIndex_backend,
  performanceIndex_display,
  spike_normalized,
  recovery_normalized,
  tactical_normalized,
) {
  try {
    // Get athlete's current tier badge from latest scan
    const currentBadgeQuery = await sql`
        SELECT valuation_factors->>'tier_badge' as tier_badge_data
        FROM asset_simulations 
        WHERE athlete_id = ${athleteId}
        ORDER BY created_at DESC 
        LIMIT 1
      `;

    let currentBadge = null;
    if (currentBadgeQuery.length > 0 && currentBadgeQuery[0].tier_badge_data) {
      try {
        const badgeData = JSON.parse(currentBadgeQuery[0].tier_badge_data);
        currentBadge = badgeData.new_badge;
      } catch (e) {
        // Handle parsing error gracefully
        currentBadge = null;
      }
    }

    // **TIER BADGE LEVELS DEFINITION**
    const tierBadges = {
      starter: {
        name: "Starter",
        description:
          "Entry-level athlete with verified scan and baseline metrics",
        tier_level: 1,
        bvi_range: [40, 59],
        tactical_range: [0.4, 0.59],
        color: "bg-green-500",
        icon: "Shield",
      },
      contributor: {
        name: "Contributor",
        description:
          "Athlete showing tactical bump, consistent recovery, and spike events",
        tier_level: 2,
        bvi_range: [60, 79],
        tactical_range: [0.6, 0.79],
        color: "bg-blue-500",
        icon: "Star",
      },
      elite: {
        name: "Elite",
        description:
          "High-performance athlete with strong BVI cone, tactical overlays, and recovery",
        tier_level: 3,
        bvi_range: [80, 100],
        tactical_range: [0.8, 1.0],
        color: "bg-purple-500",
        icon: "Gauge",
      },
    };

    // **TIER ASSIGNMENT LOGIC**
    const bvi_display = performanceIndex_display.bvi;
    const tactical_backend = tactical_normalized;

    let assignedBadge = "starter"; // Default

    // Elite tier check
    if (bvi_display >= 80 && tactical_backend >= 0.8) {
      assignedBadge = "elite";
    }
    // Contributor tier check
    else if (bvi_display >= 60 && tactical_backend >= 0.6) {
      assignedBadge = "contributor";
    }
    // Starter tier (default)
    else {
      assignedBadge = "starter";
    }

    const newBadge = {
      badge_type: assignedBadge,
      ...tierBadges[assignedBadge],
      assigned_at: new Date().toISOString(),
      metrics_snapshot: {
        bvi_score: bvi_display,
        tactical_efficiency: Math.round(tactical_backend * 100),
        recovery_index: Math.round(recovery_normalized * 100),
        spike_score: Math.round(spike_normalized * 100),
        overall_score: performanceIndex_display.overall_score,
      },
    };

    // **🔁 TIER MOVEMENT LOGIC**
    let tierMovement = {
      movement_occurred: false,
      movement_type: "retained", // retained, upgrade, downgrade
      previous_badge: currentBadge?.badge_type || "none",
      new_badge: assignedBadge,
      movement_reason: "",
      vesting_trigger: false,
    };

    if (currentBadge) {
      const currentTier = currentBadge.tier_level;
      const newTier = newBadge.tier_level;

      if (newTier > currentTier) {
        tierMovement = {
          movement_occurred: true,
          movement_type: "upgrade",
          previous_badge: currentBadge.badge_type,
          new_badge: assignedBadge,
          movement_reason: `Tactical bump (${Math.round(tactical_backend * 100)}%) + performance metrics exceeded ${assignedBadge} threshold`,
          vesting_trigger: true, // Badge upgrade triggers contributor vesting
        };
      } else if (newTier < currentTier) {
        tierMovement = {
          movement_occurred: true,
          movement_type: "downgrade",
          previous_badge: currentBadge.badge_type,
          new_badge: assignedBadge,
          movement_reason: `Recovery dip (${Math.round((1 - recovery_normalized) * 100)}%) + inconsistent metrics dropped below ${currentBadge.badge_type} threshold`,
          vesting_trigger: false,
        };
      } else {
        tierMovement = {
          movement_occurred: false,
          movement_type: "retained",
          previous_badge: currentBadge.badge_type,
          new_badge: assignedBadge,
          movement_reason: `Consistent scan metrics maintained ${assignedBadge} tier status`,
          vesting_trigger: false,
        };
      }
    } else {
      // First-time badge assignment
      tierMovement = {
        movement_occurred: true,
        movement_type: "initial_assignment",
        previous_badge: "none",
        new_badge: assignedBadge,
        movement_reason: `Initial tier badge assignment based on verified scan performance`,
        vesting_trigger: assignedBadge !== "starter", // Only non-starter initial assignments trigger vesting
      };
    }

    // **SPIKE EVENT ANALYSIS**
    const spikeEvents = [];
    if (spike_normalized >= 0.75) {
      spikeEvents.push({
        time: 2.3,
        type: "acceleration_burst",
        intensity: Math.round(spike_normalized * 100),
      });
    }
    if (tactical_backend >= 0.7) {
      spikeEvents.push({
        time: 4.7,
        type: "tactical_highlight",
        intensity: Math.round(tactical_backend * 100),
      });
    }

    return {
      new_badge: newBadge,
      tier_movement: tierMovement,
      spike_events: spikeEvents,
      badge_integration: {
        qr_flyer_ready: true,
        coalition_dashboard_updated: true,
        highlight_reel_sync: spikeEvents.length > 0,
        onboarding_packet_ready:
          tierMovement.movement_type === "initial_assignment",
      },
      assignment_timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Tier badge assignment error:", error);
    // Return fallback starter badge
    return {
      new_badge: {
        badge_type: "starter",
        name: "Starter",
        description:
          "Entry-level athlete with verified scan and baseline metrics",
        tier_level: 1,
        color: "bg-green-500",
        icon: "Shield",
        assigned_at: new Date().toISOString(),
        metrics_snapshot: {
          bvi_score: performanceIndex_display.bvi,
          tactical_efficiency: Math.round(tactical_normalized * 100),
          recovery_index: Math.round(recovery_normalized * 100),
          spike_score: Math.round(spike_normalized * 100),
          overall_score: performanceIndex_display.overall_score,
        },
      },
      tier_movement: {
        movement_occurred: true,
        movement_type: "fallback_assignment",
        previous_badge: "none",
        new_badge: "starter",
        movement_reason: "Fallback assignment due to calculation error",
        vesting_trigger: false,
      },
      spike_events: [],
      badge_integration: {
        qr_flyer_ready: true,
        coalition_dashboard_updated: true,
        highlight_reel_sync: false,
        onboarding_packet_ready: true,
      },
      assignment_timestamp: new Date().toISOString(),
    };
  }
}
