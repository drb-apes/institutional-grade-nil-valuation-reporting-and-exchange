export async function POST(request) {
  try {
    const body = await request.json();
    const { modelId, performanceData, biometricData, sessionContext } = body;

    if (!modelId || !performanceData) {
      return Response.json(
        { error: "Missing required fields: modelId, performanceData" },
        { status: 400 },
      );
    }

    // Calculate Modeling Performance Units
    const performanceUnits = calculateModelingPerformanceUnits(performanceData);

    // Calculate Biometric Scores
    const biometricScores = calculateBiometricScores(biometricData || {});

    // Calculate Core Indices
    const indices = calculateModelingIndices(performanceUnits, biometricScores);

    // Calculate Fair-Value NIL
    const nilValuation = calculateModelingNIL(
      performanceUnits,
      biometricScores,
      indices,
      sessionContext,
    );

    return Response.json({
      success: true,
      modelId,
      performanceUnits,
      biometricScores,
      indices,
      nilValuation,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Modeling BIM Performance calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate modeling performance metrics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateModelingPerformanceUnits(data) {
  const {
    runwayWalks = [],
    poses = [],
    expressionCaptures = [],
    cameraHolds = [],
    brandFitAssessments = [],
  } = data;

  // Runway Gait Units (RGU)
  const gaitQuality = runwayWalks.reduce((sum, walk) => {
    const strideConsistency = walk.strideConsistency / 100;
    const postureScore = walk.postureScore / 10;
    const turnQuality = walk.turnQuality / 10;
    return sum + (strideConsistency + postureScore + turnQuality) / 3;
  }, 0);
  const rgu = gaitQuality / Math.max(runwayWalks.length, 1);

  // Pose Stability Units (PSU)
  const poseQuality = poses.reduce((sum, pose) => {
    const holdStability = pose.holdStability / 100;
    const balanceScore = pose.balanceScore / 10;
    const composure = pose.composure / 10;
    return sum + (holdStability + balanceScore + composure) / 3;
  }, 0);
  const psu = poseQuality / Math.max(poses.length, 1);

  // Expression Fidelity Units (EFU)
  const expressionQuality = expressionCaptures.reduce((sum, expr) => {
    const range = expr.expressionRange / 10;
    const authenticity = expr.authenticity / 10;
    const cameraConnection = expr.cameraConnection / 10;
    return sum + (range + authenticity + cameraConnection) / 3;
  }, 0);
  const efu = expressionQuality / Math.max(expressionCaptures.length, 1);

  // Camera-Hold Units (CHU)
  const holdQuality = cameraHolds.reduce((sum, hold) => {
    const duration = Math.min(hold.durationSeconds / 5, 1.0);
    const stillness = hold.stillnessScore / 100;
    const engagement = hold.engagementScore / 10;
    return sum + (duration + stillness + engagement) / 3;
  }, 0);
  const chu = holdQuality / Math.max(cameraHolds.length, 1);

  // Brand Fit Units (BFU)
  const brandFit = brandFitAssessments.reduce((sum, assessment) => {
    const alignmentScore = assessment.alignmentScore / 100;
    const versatility = assessment.versatility / 10;
    return sum + (alignmentScore + versatility) / 2;
  }, 0);
  const bfu = brandFit / Math.max(brandFitAssessments.length, 1);

  return {
    RGU: Math.min(rgu, 1.0),
    PSU: Math.min(psu, 1.0),
    EFU: Math.min(efu, 1.0),
    CHU: Math.min(chu, 1.0),
    BFU: Math.min(bfu, 1.0),
    totalUnits:
      runwayWalks.length +
      poses.length +
      expressionCaptures.length +
      cameraHolds.length +
      brandFitAssessments.length,
  };
}

function calculateBiometricScores(data) {
  const {
    postureStability = 0.93,
    breathControl = 0.89,
    movementGrace = 0.91,
    composureLevel = 0.94,
    fatigueLevel = 0.12,
  } = data;

  return {
    postureStability: Math.min(postureStability, 1.0),
    breathControl: Math.min(breathControl, 1.0),
    movementGrace: Math.min(movementGrace, 1.0),
    composureLevel: Math.min(composureLevel, 1.0),
    fatigueLevel: Math.min(fatigueLevel, 1.0),
    overallBiometric:
      ((postureStability + breathControl + movementGrace + composureLevel) /
        4) *
      (1 - fatigueLevel * 0.15),
  };
}

function calculateModelingIndices(performanceUnits, biometricScores) {
  // Runway Efficiency Index (REI)
  const rei =
    performanceUnits.RGU * 0.5 +
    performanceUnits.PSU * 0.3 +
    biometricScores.movementGrace * 0.2;

  // Expression Fidelity Index (EFI)
  const efi = performanceUnits.EFU * 0.6 + performanceUnits.CHU * 0.4;

  // Brand Versatility Index (BVI)
  const bvi =
    performanceUnits.BFU * 0.5 +
    performanceUnits.EFU * 0.3 +
    performanceUnits.PSU * 0.2;

  // Camera Presence Index (CPI)
  const cpi =
    performanceUnits.CHU * 0.4 +
    performanceUnits.EFU * 0.35 +
    biometricScores.composureLevel * 0.25;

  return {
    REI: Math.min(rei, 1.0),
    EFI: Math.min(efi, 1.0),
    BVI: Math.min(bvi, 1.0),
    CPI: Math.min(cpi, 1.0),
  };
}

function calculateModelingNIL(
  performanceUnits,
  biometricScores,
  indices,
  sessionContext = {},
) {
  // Base performance score (40%)
  const performanceScore =
    performanceUnits.RGU * 0.25 +
    performanceUnits.PSU * 0.2 +
    performanceUnits.EFU * 0.25 +
    performanceUnits.CHU * 0.2 +
    performanceUnits.BFU * 0.1;

  // Biometric score (25%)
  const biometricScore = biometricScores.overallBiometric;

  // Engagement score (20%) - based on session type and brand alignment
  const sessionTypeMultiplier = {
    paris_fashion_week: 2.0,
    high_fashion: 1.5,
    commercial: 1.2,
    editorial: 1.3,
    catalog: 1.0,
  };
  const sessionMultiplier =
    sessionTypeMultiplier[sessionContext.sessionType] || 1.0;
  const engagementScore = indices.CPI * sessionMultiplier;

  // Brand fit score (15%)
  const brandFitScore = indices.BVI * 0.6 + indices.REI * 0.4;

  // Calculate FV-NIL
  const fvNIL =
    performanceScore * 0.4 +
    biometricScore * 0.25 +
    Math.min(engagementScore, 1.0) * 0.2 +
    brandFitScore * 0.15;

  // Base NIL value (normalized to $400K max for elite models)
  const baseNILValue = fvNIL * 400000;

  return {
    fvNIL: Math.min(fvNIL, 1.0),
    estimatedValue: Math.round(baseNILValue),
    performanceComponent: performanceScore,
    biometricComponent: biometricScore,
    engagementComponent: Math.min(engagementScore, 1.0),
    brandFitComponent: brandFitScore,
    tier: determineModelingTier(fvNIL),
    category: sessionContext.category || "General",
  };
}

function determineModelingTier(fvNIL) {
  if (fvNIL >= 0.92) return "Supermodel";
  if (fvNIL >= 0.85) return "High Fashion";
  if (fvNIL >= 0.75) return "Commercial Elite";
  if (fvNIL >= 0.65) return "Editorial";
  if (fvNIL >= 0.55) return "Catalog";
  return "Developing";
}

export async function GET() {
  return Response.json({
    message: "Super Modeling BIM Performance Calculation Engine",
    version: "1.0.0",
    performanceUnits: ["RGU", "PSU", "EFU", "CHU", "BFU"],
    indices: ["REI", "EFI", "BVI", "CPI"],
    method: "POST",
    requiredFields: ["modelId", "performanceData"],
  });
}
