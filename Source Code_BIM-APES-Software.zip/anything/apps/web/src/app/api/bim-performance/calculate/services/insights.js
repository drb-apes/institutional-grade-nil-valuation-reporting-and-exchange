// /apps/web/src/app/api/bim-performance/calculate/services/insights.js
import { calculateCorrelation } from "./utils.js";

// **COACHING INSIGHTS GENERATION**
export function generateCoachingInsights(
  performanceIndex_backend,
  performanceIndex_display,
  scanData,
) {
  const insights = {
    strengths: [],
    areas_for_improvement: [],
    training_recommendations: [],
    cross_correlation_analysis: {},
    institutional_metrics: {},
  };

  // Use backend normalized values for analysis logic
  const {
    bvi,
    tactical_efficiency,
    recovery_index,
    spike_score,
    session_consistency,
  } = performanceIndex_backend;
  const threshold = 0.75; // 75% threshold for strengths

  // Identify strengths using normalized values
  if (bvi >= threshold)
    insights.strengths.push("Excellent body composition and biometric profile");
  if (tactical_efficiency >= threshold)
    insights.strengths.push("Strong tactical decision-making capabilities");
  if (recovery_index >= threshold)
    insights.strengths.push("Superior recovery and adaptation capacity");
  if (spike_score >= threshold)
    insights.strengths.push("Outstanding explosive power output");
  if (session_consistency >= threshold)
    insights.strengths.push("Highly consistent performance delivery");

  // Identify improvement areas using normalized values
  if (bvi < threshold)
    insights.areas_for_improvement.push("Body composition optimization needed");
  if (tactical_efficiency < threshold)
    insights.areas_for_improvement.push(
      "Tactical awareness and decision-making",
    );
  if (recovery_index < threshold)
    insights.areas_for_improvement.push(
      "Recovery protocols and sleep optimization",
    );
  if (spike_score < threshold)
    insights.areas_for_improvement.push(
      "Explosive power and neuromuscular training",
    );
  if (session_consistency < threshold)
    insights.areas_for_improvement.push(
      "Performance stability and mental resilience",
    );

  // Training recommendations based on motion type
  const motionType = scanData.motion_type;
  const sport = scanData.sport_type || "general";

  // Sport-specific training recommendations
  if (sport === "pole_vault") {
    const biomechanics = scanData.biomechanics || {};

    // Pole vault specific recommendations based on vault execution
    if (["approach", "plant", "vault", "clearance"].includes(motionType)) {
      // Approach speed recommendations
      const approachSpeed =
        biomechanics.approach_speed || biomechanics.velocity_peak || 0;
      if (approachSpeed < 8) {
        insights.training_recommendations.push(
          "Increase approach speed through sprint training and runway mechanics",
        );
      } else if (approachSpeed > 10) {
        insights.training_recommendations.push(
          "Focus on approach speed control and plant preparation timing",
        );
      }

      // Plant timing and pole bend recommendations
      const plantTiming =
        biomechanics.plant_timing_precision ||
        biomechanics.stability_score / 100 ||
        0;
      if (plantTiming < 0.75) {
        insights.training_recommendations.push(
          "Work on plant timing drills and pole transition mechanics",
        );
      }

      // Bar clearance technique
      const clearanceAngle =
        biomechanics.bar_clearance_angle || biomechanics.range_of_motion || 0;
      if (clearanceAngle < 75) {
        insights.training_recommendations.push(
          "Improve bar clearance technique and body positioning over the bar",
        );
      }

      // Landing stability
      const landingStability = biomechanics.stability_score || 0;
      if (landingStability < 80) {
        insights.training_recommendations.push(
          "Focus on landing mechanics and pit technique for safety and consistency",
        );
      }

      // Recovery from fatigue indicators
      if (recovery_index < 0.7) {
        insights.training_recommendations.push(
          "Monitor training load - fatigue detected in approach speed and plant timing",
        );
      }
    }
  } else {
    // Standard motion type recommendations for other sports
    switch (motionType) {
      case "sprint":
        insights.training_recommendations.push(
          "Focus on acceleration mechanics and stride optimization",
        );
        break;
      case "jump":
        insights.training_recommendations.push(
          "Emphasize plyometric training and landing technique",
        );
        break;
      case "throw":
        insights.training_recommendations.push(
          "Develop rotational power and kinetic chain efficiency",
        );
        break;
    }
  }

  // Cross-correlation analysis using normalized values
  insights.cross_correlation_analysis = {
    bvi_tactical_correlation: calculateCorrelation(bvi, tactical_efficiency),
    recovery_consistency_correlation: calculateCorrelation(
      recovery_index,
      session_consistency,
    ),
    power_efficiency_balance:
      tactical_efficiency > 0 ? spike_score / tactical_efficiency : 0,
    overall_development_vector:
      (bvi + tactical_efficiency + recovery_index) / 3,
  };

  // Institutional metrics for coalition dashboard (display scale)
  insights.institutional_metrics = {
    tracking_quality: performanceIndex_display.pose_confidence,
    scan_verification: Math.round(scanData.ai_score || 85),
    power_output: performanceIndex_display.spike_score,
    volatility_index: Math.round((1 - session_consistency) * 100), // Higher volatility = lower consistency
    efficiency_rating: performanceIndex_display.tactical_efficiency,
    recovery_dip: Math.round((1 - recovery_index) * 65), // 0-65 scale for recovery dip
    highlight_intensity: performanceIndex_display.spike_score,
  };

  return insights;
}

// **BVI CONE FORECAST (MONTE CARLO SIMULATION)**
export function generateBVICone(performanceIndex, currentTier) {
  const baseVolatility = 0.15; // 15% base volatility
  const tierMultiplier = [1.2, 1.0, 0.8][currentTier - 1] || 1.0; // Higher tier = lower volatility

  const volatility = baseVolatility * tierMultiplier;
  const currentScore = performanceIndex.overall_score;

  // Monte Carlo simulation for forecast cone
  const simulations = [];
  for (let i = 0; i < 1000; i++) {
    const randomFactor = (Math.random() - 0.5) * 2; // -1 to 1
    const projectedScore = currentScore + randomFactor * volatility;
    simulations.push(Math.max(0, Math.min(10, projectedScore))); // Assuming scale of 10
  }

  simulations.sort((a, b) => a - b);

  return {
    current_value: Math.round(currentScore * 10),
    volatility_index: Math.round(volatility * 100),
    forecast_cone: {
      p10: Math.round(simulations[Math.floor(0.1 * simulations.length)] * 10),
      p25: Math.round(simulations[Math.floor(0.25 * simulations.length)] * 10),
      p50: Math.round(simulations[Math.floor(0.5 * simulations.length)] * 10),
      p75: Math.round(simulations[Math.floor(0.75 * simulations.length)] * 10),
      p90: Math.round(simulations[Math.floor(0.9 * simulations.length)] * 10),
    },
    confidence_interval: "80%",
    forecast_horizon: "30_days",
  };
}
