import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Wrestling-specific metric calculations
function calculateTakedownEfficiency(wrestlingData) {
  const takedownAttempts = wrestlingData.takedown_attempts || 0;
  const successfulTakedowns = wrestlingData.successful_takedowns || 0;

  if (takedownAttempts === 0) return 0.5; // Neutral if no attempts
  return Math.min(successfulTakedowns / takedownAttempts, 1.0);
}

function calculateEscapeRate(wrestlingData) {
  const escapeAttempts = wrestlingData.escape_attempts || 0;
  const successfulEscapes = wrestlingData.successful_escapes || 0;

  if (escapeAttempts === 0) return 0.7; // Default
  return Math.min(successfulEscapes / escapeAttempts, 1.0);
}

function calculateControlTime(wrestlingData) {
  const totalMatchTime = wrestlingData.match_duration || 360; // 6 minutes default
  const controlTime = wrestlingData.control_time || 0;

  return Math.min(controlTime / totalMatchTime, 1.0);
}

function calculatePinThreat(wrestlingData) {
  const nearFalls = wrestlingData.near_falls || 0;
  const backExposures = wrestlingData.back_exposures || 0;
  const pinAttempts = wrestlingData.pin_attempts || 0;

  // Weighted scoring for pin threat level
  return Math.min(
    (nearFalls * 0.5 + backExposures * 0.3 + pinAttempts * 0.2) / 5,
    1.0,
  );
}

function calculateStamina(wrestlingData) {
  const periods = wrestlingData.period_performance || [];
  if (periods.length < 2) return 0.7;

  // Analyze performance degradation across periods
  const firstPeriod = periods[0]?.intensity || 0.8;
  const lastPeriod = periods[periods.length - 1]?.intensity || 0.6;

  return Math.max(0, Math.min(lastPeriod / firstPeriod, 1.0));
}

// Wrestling tactical efficiency calculation
function calculateWrestlingTacticalEfficiency(wrestlingData) {
  const setupSuccess =
    (wrestlingData.successful_setups || 0) /
    Math.max(wrestlingData.setup_attempts || 1, 1);
  const counterSuccess =
    (wrestlingData.successful_counters || 0) /
    Math.max(wrestlingData.counter_attempts || 1, 1);
  const positionTransitions = wrestlingData.position_transition_success || 0.7;

  return setupSuccess * 0.4 + counterSuccess * 0.3 + positionTransitions * 0.3;
}

// Wrestling-specific spike score
function calculateWrestlingSpikeScore(wrestlingData) {
  const techFalls = wrestlingData.technical_falls || 0;
  const pins = wrestlingData.pins || 0;
  const majorDecisions = wrestlingData.major_decisions || 0;
  const totalMatches = wrestlingData.total_matches || 1;

  // Higher points for more dominant victories
  const dominanceScore =
    (pins * 1.0 + techFalls * 0.8 + majorDecisions * 0.6) / totalMatches;

  return Math.min(dominanceScore, 1.0);
}

// Wrestling session consistency
async function calculateWrestlingSessionConsistency(athleteId) {
  const recentMatches = await sql`
    SELECT simulation_data->'wrestling_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
    AND valuation_factors->>'analysis_type' = 'wrestling_performance'
    ORDER BY created_at DESC
    LIMIT 10
  `;

  if (recentMatches.length < 3) return 0.7;

  const takedownEfficiencies = recentMatches.map(
    (m) => m.metrics?.takedown_efficiency || 0.5,
  );

  const mean =
    takedownEfficiencies.reduce((a, b) => a + b, 0) /
    takedownEfficiencies.length;
  const variance =
    takedownEfficiencies.reduce(
      (sum, eff) => sum + Math.pow(eff - mean, 2),
      0,
    ) / takedownEfficiencies.length;

  return Math.max(0, 1 - variance * 3);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { wrestling_data, weight_class, competition_level } =
      await request.json();

    if (!wrestling_data) {
      return Response.json(
        { error: "Wrestling performance data required" },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate wrestling-specific metrics
    const takedownEfficiency = calculateTakedownEfficiency(wrestling_data);
    const escapeRate = calculateEscapeRate(wrestling_data);
    const controlTime = calculateControlTime(wrestling_data);
    const pinThreat = calculatePinThreat(wrestling_data);
    const stamina = calculateStamina(wrestling_data);
    const tacticalEfficiency =
      calculateWrestlingTacticalEfficiency(wrestling_data);
    const spikeScore = calculateWrestlingSpikeScore(wrestling_data);
    const sessionConsistency = await calculateWrestlingSessionConsistency(
      athlete.id,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      takedown_efficiency: takedownEfficiency,
      escape_rate: escapeRate,
      control_time: controlTime,
      pin_threat: pinThreat,
      stamina: stamina,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall wrestling performance index
    const weights = {
      takedown_efficiency: 0.25,
      escape_rate: 0.15,
      control_time: 0.2,
      pin_threat: 0.15,
      stamina: 0.1,
      tactical_efficiency: 0.15,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => key !== "session_consistency" && key !== "spike_score")
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display based on competition level
    const isCollegiate =
      competition_level === "collegiate" || athlete.tier_level >= 3;
    const displayScale = isCollegiate ? 100 : 50;

    const displayMetrics = {
      takedown_efficiency: Math.round(takedownEfficiency * 100), // Always as percentage
      escape_rate: Math.round(escapeRate * 100), // Always as percentage
      control_time: Math.round(controlTime * displayScale),
      pin_threat: Math.round(pinThreat * displayScale),
      stamina: Math.round(stamina * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isCollegiate
        ? "collegiate_wrestling"
        : "high_school_wrestling",
      weight_class: weight_class,
      timestamp: new Date().toISOString(),
    };

    // Generate wrestling-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      wrestling_specific_tips: [],
    };

    // Identify strengths and weaknesses
    if (performanceMetrics.takedown_efficiency >= 0.8) {
      insights.strengths.push("Exceptional takedown execution");
    } else if (performanceMetrics.takedown_efficiency <= 0.5) {
      insights.improvements.push("Focus on takedown technique and timing");
    }

    if (performanceMetrics.control_time >= 0.7) {
      insights.strengths.push("Strong top position control");
    } else if (performanceMetrics.control_time <= 0.4) {
      insights.improvements.push("Work on maintaining control position");
    }

    if (performanceMetrics.escape_rate >= 0.8) {
      insights.strengths.push("Excellent bottom position escapes");
    } else if (performanceMetrics.escape_rate <= 0.5) {
      insights.improvements.push("Practice escape techniques and hip movement");
    }

    if (performanceMetrics.stamina <= 0.6) {
      insights.improvements.push("Improve cardiovascular conditioning");
      insights.wrestling_specific_tips.push(
        "Increase mat time and live wrestling sessions",
      );
    }

    if (performanceMetrics.pin_threat >= 0.7) {
      insights.strengths.push("High pin threat from top position");
    } else if (performanceMetrics.pin_threat <= 0.4) {
      insights.wrestling_specific_tips.push(
        "Work on turning combinations and back exposure",
      );
    }

    // Weight class specific advice
    if (weight_class) {
      if (parseInt(weight_class) <= 125) {
        insights.wrestling_specific_tips.push(
          "Focus on speed and technique over power",
        );
      } else if (parseInt(weight_class) >= 195) {
        insights.wrestling_specific_tips.push(
          "Utilize size advantage and power positions",
        );
      }
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.2, 1.0)},
        ${Math.max(0, 1 - sessionConsistency)},
        ${JSON.stringify({
          wrestling_metrics: displayMetrics,
          wrestling_data: wrestling_data,
          competition_context: { weight_class, competition_level },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: "wrestling",
          analysis_type: "wrestling_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      wrestling_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: "wrestling",
      weight_class: weight_class,
      message: `Wrestling Performance Index calculated for ${weight_class}lbs ${competition_level || "competition"}`,
    });
  } catch (error) {
    console.error("Wrestling performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate wrestling performance metrics" },
      { status: 500 },
    );
  }
}
