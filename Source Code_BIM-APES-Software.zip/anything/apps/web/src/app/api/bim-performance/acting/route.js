import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Acting Performance Units (APUs)
// Scenes = Possessions | Emotional Beats = Plays | Line Delivery = Scoring Attempts
// Stunts = Sprints | Micro-Expressions = Technical Skills | Retakes = Turnovers
export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      actorId,
      projectData,
      performanceUnits, // APUs
      role, // 'lead', 'supporting', 'ensemble', 'stunt', 'voice'
    } = await req.json();

    if (!actorId || !performanceUnits || !role) {
      return Response.json(
        {
          error: "Actor ID, performance units, and role required",
        },
        { status: 400 },
      );
    }

    // Acting Performance Unit Schema
    const actingSchema = {
      scenes: [
        "emotional_depth",
        "consistency",
        "energy_retention",
        "scene_chemistry",
        "blocking_precision",
      ],
      emotional_beats: [
        "authenticity",
        "range",
        "transition_smoothness",
        "intensity_control",
      ],
      line_delivery: [
        "clarity",
        "timing",
        "inflection_accuracy",
        "intention_strength",
      ],
      stunts_physical: [
        "execution_precision",
        "safety_compliance",
        "stamina",
        "coordination",
      ],
      micro_expressions: [
        "facial_fidelity",
        "emotional_truth",
        "subtlety",
        "camera_awareness",
      ],
      continuity: [
        "costume_consistency",
        "prop_handling",
        "movement_matching",
        "emotional_continuity",
      ],
      retakes: [
        "first_take_success_rate",
        "adaptation_speed",
        "fatigue_resistance",
        "director_feedback_incorporation",
      ],
    };

    // Calculate Acting Performance Score (APS)
    const actingScores = calculateActingPerformance(
      performanceUnits,
      role,
      actingSchema,
    );

    // Calculate Acting BIM Metrics
    const bimMetrics = calculateActingBIM(performanceUnits, role);

    // Calculate Take-to-Take Consistency
    const consistencyMetrics = await calculateTakeConsistency(actorId, role);

    // Calculate Digital Double Value (for NIL licensing)
    const digitalDoubleValue = calculateDigitalDoubleValue(
      actingScores,
      bimMetrics,
      role,
    );

    // Store performance scan
    const [scan] = await sql`
      INSERT INTO motion_scans (
        athlete_id,
        scan_data,
        ai_score,
        verification_status,
        motion_type,
        metadata
      ) VALUES (
        ${parseInt(actorId)},
        ${JSON.stringify(performanceUnits)},
        ${actingScores.overallAPS},
        'verified',
        ${`${role}_acting`},
        ${JSON.stringify({
          role,
          projectData,
          actingScores,
          bimMetrics,
          consistencyMetrics,
          digitalDoubleValue,
          timestamp: new Date().toISOString(),
        })}
      )
      RETURNING *
    `;

    // Calculate NIL impact for actor
    const nilImpact = calculateActorNILImpact(
      actingScores,
      bimMetrics,
      digitalDoubleValue,
      role,
    );

    return Response.json({
      success: true,
      scan,
      actingScores,
      bimMetrics,
      consistencyMetrics,
      digitalDoubleValue,
      nilImpact,
      insights: generateActingInsights(actingScores, consistencyMetrics, role),
    });
  } catch (error) {
    console.error("Acting performance error:", error);
    return Response.json(
      { error: "Failed to process acting performance" },
      { status: 500 },
    );
  }
}

// Calculate Acting Performance Score
function calculateActingPerformance(units, role, schema) {
  const scores = {
    sceneExecution: 0,
    emotionalBeats: 0,
    lineDelivery: 0,
    physicalPerformance: 0,
    microExpressions: 0,
    continuityControl: 0,
    retakeEfficiency: 0,
    overallAPS: 0,
  };

  // Scene Execution (like Drive Completion)
  if (units.scenes) {
    const sceneMetrics = schema.scenes.map(
      (metric) => units.scenes[metric] || 0,
    );
    scores.sceneExecution =
      sceneMetrics.reduce((a, b) => a + b, 0) / sceneMetrics.length;
  }

  // Emotional Beats (like Play Execution)
  if (units.emotional_beats) {
    const emotionalMetrics = schema.emotional_beats.map(
      (metric) => units.emotional_beats[metric] || 0,
    );
    scores.emotionalBeats =
      emotionalMetrics.reduce((a, b) => a + b, 0) / emotionalMetrics.length;
  }

  // Line Delivery (like Scoring Attempts)
  if (units.line_delivery) {
    const lineMetrics = schema.line_delivery.map(
      (metric) => units.line_delivery[metric] || 0,
    );
    scores.lineDelivery =
      lineMetrics.reduce((a, b) => a + b, 0) / lineMetrics.length;
  }

  // Physical/Stunt Performance (like Sprint Bursts)
  if (units.stunts_physical) {
    const stuntMetrics = schema.stunts_physical.map(
      (metric) => units.stunts_physical[metric] || 0,
    );
    scores.physicalPerformance =
      stuntMetrics.reduce((a, b) => a + b, 0) / stuntMetrics.length;
  }

  // Micro-Expressions (like Technical Skills)
  if (units.micro_expressions) {
    const microMetrics = schema.micro_expressions.map(
      (metric) => units.micro_expressions[metric] || 0,
    );
    scores.microExpressions =
      microMetrics.reduce((a, b) => a + b, 0) / microMetrics.length;
  }

  // Continuity Control
  if (units.continuity) {
    const contMetrics = schema.continuity.map(
      (metric) => units.continuity[metric] || 0,
    );
    scores.continuityControl =
      contMetrics.reduce((a, b) => a + b, 0) / contMetrics.length;
  }

  // Retake Efficiency (inverse of turnover rate)
  if (units.retakes) {
    const retakeMetrics = schema.retakes.map(
      (metric) => units.retakes[metric] || 0,
    );
    scores.retakeEfficiency =
      retakeMetrics.reduce((a, b) => a + b, 0) / retakeMetrics.length;
  }

  // Calculate overall APS (weighted by role)
  const weights = getRoleWeights(role);
  scores.overallAPS =
    scores.sceneExecution * weights.sceneExecution +
    scores.emotionalBeats * weights.emotionalBeats +
    scores.lineDelivery * weights.lineDelivery +
    scores.physicalPerformance * weights.physicalPerformance +
    scores.microExpressions * weights.microExpressions +
    scores.continuityControl * weights.continuityControl +
    scores.retakeEfficiency * weights.retakeEfficiency;

  return scores;
}

// Role-specific weights (different roles value different performance elements)
function getRoleWeights(role) {
  const weights = {
    lead: {
      sceneExecution: 0.25,
      emotionalBeats: 0.25,
      lineDelivery: 0.2,
      physicalPerformance: 0.05,
      microExpressions: 0.15,
      continuityControl: 0.05,
      retakeEfficiency: 0.05,
    },
    supporting: {
      sceneExecution: 0.2,
      emotionalBeats: 0.2,
      lineDelivery: 0.2,
      physicalPerformance: 0.1,
      microExpressions: 0.15,
      continuityControl: 0.1,
      retakeEfficiency: 0.05,
    },
    ensemble: {
      sceneExecution: 0.2,
      emotionalBeats: 0.1,
      lineDelivery: 0.15,
      physicalPerformance: 0.15,
      microExpressions: 0.1,
      continuityControl: 0.2,
      retakeEfficiency: 0.1,
    },
    stunt: {
      sceneExecution: 0.15,
      emotionalBeats: 0.05,
      lineDelivery: 0.05,
      physicalPerformance: 0.5, // Stunt work is primary
      microExpressions: 0.05,
      continuityControl: 0.15,
      retakeEfficiency: 0.05,
    },
    voice: {
      sceneExecution: 0.15,
      emotionalBeats: 0.3,
      lineDelivery: 0.4, // Voice work emphasizes delivery
      physicalPerformance: 0.0,
      microExpressions: 0.0,
      continuityControl: 0.05,
      retakeEfficiency: 0.1,
    },
  };

  return weights[role] || weights.lead;
}

// Calculate BIM metrics for acting
function calculateActingBIM(units, role) {
  return {
    emotionalStamina: calculateEmotionalStamina(units, role),
    characterConsistency: calculateCharacterConsistency(units, role),
    technicalProficiency: calculateTechnicalProficiency(units, role),
    onSetPresence: calculateOnSetPresence(units, role),
    adaptability: calculateAdaptability(units, role),
    collaborativeSkill: calculateCollaborativeSkill(units, role),
  };
}

function calculateEmotionalStamina(units, role) {
  const depth = units.emotional_beats?.authenticity || 0;
  const energy = units.scenes?.energy_retention || 0;
  const fatigue = units.retakes?.fatigue_resistance || 0;
  return depth * 0.35 + energy * 0.35 + fatigue * 0.3;
}

function calculateCharacterConsistency(units, role) {
  const sceneConsistency = units.scenes?.consistency || 0;
  const emotionalConsistency = units.continuity?.emotional_continuity || 0;
  const movementMatching = units.continuity?.movement_matching || 0;
  return (
    sceneConsistency * 0.35 +
    emotionalConsistency * 0.35 +
    movementMatching * 0.3
  );
}

function calculateTechnicalProficiency(units, role) {
  const timing = units.line_delivery?.timing || 0;
  const blocking = units.scenes?.blocking_precision || 0;
  const microExpression = units.micro_expressions?.facial_fidelity || 0;
  return timing * 0.35 + blocking * 0.3 + microExpression * 0.35;
}

function calculateOnSetPresence(units, role) {
  const chemistry = units.scenes?.scene_chemistry || 0;
  const awareness = units.micro_expressions?.camera_awareness || 0;
  const energy = units.scenes?.energy_retention || 0;
  return chemistry * 0.4 + awareness * 0.3 + energy * 0.3;
}

function calculateAdaptability(units, role) {
  const adaptation = units.retakes?.adaptation_speed || 0;
  const feedback = units.retakes?.director_feedback_incorporation || 0;
  const transition = units.emotional_beats?.transition_smoothness || 0;
  return adaptation * 0.4 + feedback * 0.3 + transition * 0.3;
}

function calculateCollaborativeSkill(units, role) {
  const chemistry = units.scenes?.scene_chemistry || 0;
  const feedback = units.retakes?.director_feedback_incorporation || 0;
  const propHandling = units.continuity?.prop_handling || 0;
  return chemistry * 0.45 + feedback * 0.35 + propHandling * 0.2;
}

// Calculate take-to-take consistency
async function calculateTakeConsistency(actorId, role) {
  const recentProjects = await sql`
    SELECT metadata FROM motion_scans
    WHERE athlete_id = ${parseInt(actorId)}
    AND motion_type LIKE ${`%${role}%acting%`}
    ORDER BY created_at DESC
    LIMIT 20
  `;

  if (recentProjects.length < 3) {
    return {
      takeToTakeConsistency: 0.75,
      averagePerformance: 0.78,
      varianceScore: 0.12,
      trendDirection: "insufficient_data",
    };
  }

  const scores = recentProjects.map(
    (p) => p.metadata?.actingScores?.overallAPS || 0.75,
  );
  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const consistency = Math.max(0, 1 - variance * 2);

  // Calculate trend
  const recent = scores.slice(0, 5);
  const previous = scores.slice(5, 10);
  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const previousAvg =
    previous.length > 0
      ? previous.reduce((a, b) => a + b, 0) / previous.length
      : recentAvg;

  let trendDirection = "stable";
  if (recentAvg > previousAvg + 0.05) trendDirection = "improving";
  else if (recentAvg < previousAvg - 0.05) trendDirection = "declining";

  return {
    takeToTakeConsistency: consistency,
    averagePerformance: mean,
    varianceScore: variance,
    trendDirection,
    recentPerformances: scores.slice(0, 5),
  };
}

// Calculate Digital Double Value (for AI/performance capture licensing)
function calculateDigitalDoubleValue(scores, bim, role) {
  // Digital double value is based on performance consistency + technical proficiency
  const baseValue =
    scores.overallAPS * 0.4 +
    bim.technicalProficiency * 0.25 +
    bim.characterConsistency * 0.2 +
    scores.microExpressions * 0.15;

  // Role multipliers for digital double licensing
  const roleMultipliers = {
    lead: 1.5,
    supporting: 1.2,
    stunt: 1.4, // High value for stunt doubles
    ensemble: 0.9,
    voice: 1.1,
  };

  const multiplier = roleMultipliers[role] || 1.0;
  const digitalValue = baseValue * multiplier;

  return {
    baseValue: digitalValue,
    aiLikenessValue: digitalValue * 100000, // Base licensing value
    performanceCaptureValue: digitalValue * 80000,
    voiceModelValue: digitalValue * 60000,
    deAgingValue: digitalValue * 90000,
    totalDigitalAssetValue: Math.round(digitalValue * 330000),
  };
}

// Calculate NIL impact from acting performance
function calculateActorNILImpact(scores, bim, digitalValue, role) {
  // Role multipliers based on market value
  const roleMultipliers = {
    lead: 1.5,
    supporting: 1.2,
    stunt: 1.1,
    ensemble: 0.9,
    voice: 1.0,
  };

  const baseMultiplier = roleMultipliers[role] || 1.0;

  const performanceScore =
    (scores.overallAPS * 0.4 +
      bim.emotionalStamina * 0.15 +
      bim.onSetPresence * 0.2 +
      bim.adaptability * 0.15 +
      bim.technicalProficiency * 0.1) *
    baseMultiplier;

  const nilLiftLow = performanceScore * 120;
  const nilLiftHigh = performanceScore * 180;

  return {
    performanceScore,
    nilLiftRange: {
      low: Math.round(nilLiftLow),
      high: Math.round(nilLiftHigh),
    },
    indexContribution: performanceScore,
    marketability: calculateActorMarketability(scores, bim, role),
    projectValue: calculateProjectValue(performanceScore, role),
    digitalAssetValue: digitalValue.totalDigitalAssetValue,
  };
}

function calculateActorMarketability(scores, bim, role) {
  const marketabilityFactors = {
    lead: scores.emotionalBeats * 1.5, // Emotional range drives value
    supporting: bim.collaborativeSkill * 1.3, // Chemistry valued
    stunt: scores.physicalPerformance * 1.4, // Physical ability valued
    ensemble: scores.retakeEfficiency * 1.2, // Efficiency valued
    voice: scores.lineDelivery * 1.3, // Voice work valued
  };
  return marketabilityFactors[role] || scores.overallAPS;
}

function calculateProjectValue(performanceScore, role) {
  // Projects potential project value based on performance
  const baseDayRate = 5000; // Per day baseline
  const performanceMultiplier = 1 + performanceScore * 3;
  const roleMultipliers = {
    lead: 2.0,
    supporting: 1.3,
    stunt: 1.2,
    ensemble: 0.8,
    voice: 1.1,
  };

  const projectedDayRate =
    baseDayRate * performanceMultiplier * (roleMultipliers[role] || 1.0);

  return {
    perDayRate: Math.round(projectedDayRate),
    thirtyDayProject: Math.round(projectedDayRate * 30),
    ninetyDayProject: Math.round(projectedDayRate * 90),
  };
}

// Generate acting insights
function generateActingInsights(scores, consistency, role) {
  const insights = [];

  if (scores.overallAPS > 0.85) {
    insights.push({
      type: "strength",
      area: "Elite Acting Performance",
      message: `Outstanding performance score (${(scores.overallAPS * 100).toFixed(1)}%) - Premium NIL value`,
      nilImpact: "very_high",
    });
  }

  if (scores.retakeEfficiency > 0.8) {
    insights.push({
      type: "strength",
      area: "Production Efficiency",
      message: `Exceptional first-take success rate - Low production cost`,
      nilImpact: "high",
    });
  }

  if (consistency.takeToTakeConsistency > 0.85) {
    insights.push({
      type: "strength",
      area: "Performance Reliability",
      message: `High take-to-take consistency - Low risk for studios`,
      nilImpact: "high",
    });
  }

  if (scores.microExpressions > 0.8) {
    insights.push({
      type: "strength",
      area: "Technical Precision",
      message: `Strong micro-expression control - High digital double value`,
      nilImpact: "high",
    });
  }

  if (scores.emotionalBeats < 0.65 && role === "lead") {
    insights.push({
      type: "improvement",
      area: "Emotional Range",
      message: `Work on emotional depth and authenticity for ${role} roles`,
      nilImpact: "medium",
    });
  }

  if (consistency.trendDirection === "declining") {
    insights.push({
      type: "risk",
      area: "Performance Trend",
      message: `Recent performance decline detected - Monitor closely`,
      nilImpact: "negative",
    });
  }

  return insights;
}

// GET: Retrieve acting performance history
export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const actorId = url.searchParams.get("actorId");
    const role = url.searchParams.get("role");

    if (!actorId) {
      return Response.json({ error: "Actor ID required" }, { status: 400 });
    }

    let scans;
    if (role) {
      scans = await sql`
        SELECT * FROM motion_scans
        WHERE athlete_id = ${parseInt(actorId)}
        AND motion_type LIKE ${`%${role}%acting%`}
        ORDER BY created_at DESC
        LIMIT 50
      `;
    } else {
      scans = await sql`
        SELECT * FROM motion_scans
        WHERE athlete_id = ${parseInt(actorId)}
        AND motion_type LIKE '%acting%'
        ORDER BY created_at DESC
        LIMIT 50
      `;
    }

    return Response.json({ scans });
  } catch (error) {
    console.error("Get acting performance error:", error);
    return Response.json(
      { error: "Failed to fetch acting data" },
      { status: 500 },
    );
  }
}
