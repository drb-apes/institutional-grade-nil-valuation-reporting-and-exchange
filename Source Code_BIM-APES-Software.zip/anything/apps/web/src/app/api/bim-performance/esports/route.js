import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Esports-specific metric calculations
function calculateEsportsAPM(gameData) {
  // Actions Per Minute - core esports metric
  const totalActions =
    gameData.clicks + gameData.keystrokes + (gameData.mouse_movements || 0);
  const gameTimeMinutes = gameData.match_duration / 60;
  return Math.min(totalActions / gameTimeMinutes, 500); // Cap at 500 APM
}

function calculateReactionTime(gameData) {
  // Average reaction time in milliseconds, normalized to 0-1
  const avgReactionMs =
    gameData.reaction_times?.reduce((a, b) => a + b, 0) /
    (gameData.reaction_times?.length || 1);
  return Math.max(0, 1 - (avgReactionMs - 150) / 350); // 150ms = perfect, 500ms = poor
}

function calculateGameSense(gameData, gameType) {
  // Decision-making quality based on game type
  const baseScore = gameData.accuracy || 0.7;

  switch (gameType) {
    case "moba":
      return baseScore * (1 + (gameData.map_awareness || 0) * 0.3);
    case "fps":
      return baseScore * (1 + (gameData.crosshair_placement || 0) * 0.2);
    case "fighting":
      return baseScore * (1 + (gameData.combo_efficiency || 0) * 0.25);
    case "battle_royale":
      return baseScore * (1 + (gameData.positioning_score || 0) * 0.35);
    default:
      return baseScore;
  }
}

function calculateClutchPerformance(gameData) {
  // Performance under pressure
  const clutchSituations = gameData.clutch_situations || [];
  if (clutchSituations.length === 0) return 0.7; // Default

  const clutchWins = clutchSituations.filter((s) => s.won).length;
  return Math.min(clutchWins / clutchSituations.length, 1.0);
}

function calculateTeamSynergy(gameData) {
  // Communication and coordination
  const baseComm = gameData.communication_score || 0.6;
  const teamwork = gameData.assists / Math.max(gameData.eliminations || 1, 1);
  return Math.min((baseComm + teamwork) / 2, 1.0);
}

// Game-specific tactical efficiency
function calculateEsportsTacticalEfficiency(gameData, gameType) {
  switch (gameType) {
    case "moba":
      // MOBA: Map control, objective timing, team fight positioning
      const mapControl = gameData.vision_score || 0.6;
      const objectiveControl = gameData.objective_participation || 0.7;
      const teamfightPositioning = gameData.teamfight_positioning || 0.65;
      return (
        mapControl * 0.4 + objectiveControl * 0.4 + teamfightPositioning * 0.2
      );

    case "fps":
      // FPS: Crosshair placement, angle control, utility usage
      const crosshairPlacement = gameData.crosshair_placement || 0.7;
      const angleControl = gameData.angle_control || 0.6;
      const utilityUsage = gameData.utility_efficiency || 0.65;
      return crosshairPlacement * 0.5 + angleControl * 0.3 + utilityUsage * 0.2;

    case "fighting":
      // Fighting: Frame advantage, spacing, mix-up effectiveness
      const frameAdvantage = gameData.frame_advantage || 0.6;
      const spacing = gameData.spacing_control || 0.7;
      const mixups = gameData.mixup_effectiveness || 0.65;
      return frameAdvantage * 0.4 + spacing * 0.3 + mixups * 0.3;

    case "battle_royale":
      // BR: Zone positioning, rotation timing, third-party avoidance
      const zonePositioning = gameData.zone_positioning || 0.6;
      const rotationTiming = gameData.rotation_timing || 0.7;
      const thirdPartyAvoidance = gameData.third_party_avoidance || 0.65;
      return (
        zonePositioning * 0.4 + rotationTiming * 0.3 + thirdPartyAvoidance * 0.3
      );

    default:
      return calculateGameSense(gameData, gameType);
  }
}

// Esports-specific spike score
function calculateEsportsSpikeScore(gameData, gameType) {
  const basePerformance = gameData.accuracy || 0.7;

  switch (gameType) {
    case "fps":
      // Headshot percentage and first blood rate
      const headshotRate = gameData.headshot_percentage || 0.3;
      const firstBloodRate = gameData.first_blood_rate || 0.2;
      return Math.min(
        basePerformance + headshotRate * 0.3 + firstBloodRate * 0.2,
        1.0,
      );

    case "moba":
      // Solo kill rate and multi-kill frequency
      const soloKillRate = gameData.solo_kill_rate || 0.15;
      const multiKillFreq = gameData.multi_kill_frequency || 0.1;
      return Math.min(
        basePerformance + soloKillRate * 0.4 + multiKillFreq * 0.3,
        1.0,
      );

    case "fighting":
      // Perfect round rate and combo completion
      const perfectRounds = gameData.perfect_round_rate || 0.1;
      const comboCompletion = gameData.combo_completion_rate || 0.7;
      return Math.min(
        basePerformance + perfectRounds * 0.5 + comboCompletion * 0.2,
        1.0,
      );

    case "battle_royale":
      // High elimination games and squad wipe frequency
      const highElimGames = gameData.high_elim_game_rate || 0.2;
      const squadWipes = gameData.squad_wipe_rate || 0.1;
      return Math.min(
        basePerformance + highElimGames * 0.4 + squadWipes * 0.3,
        1.0,
      );

    default:
      return basePerformance;
  }
}

// Esports session consistency
async function calculateEsportsSessionConsistency(athleteId, gameType) {
  const recentSessions = await sql`
    SELECT simulation_data->'performance_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
    ORDER BY created_at DESC
    LIMIT 10
  `;

  if (recentSessions.length < 3) return 0.7;

  const scores = recentSessions.map((s) => s.metrics?.overall_score || 0.7);
  const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
  const variance =
    scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    scores.length;
  const consistency = Math.max(0, 1 - variance * 2);

  return Math.min(consistency, 1.0);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { game_data, game_type, match_metadata } = await request.json();

    if (!game_data || !game_type) {
      return Response.json(
        {
          error:
            "Game data and game type required for esports performance calculation",
        },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate esports-specific metrics
    const apm = calculateEsportsAPM(game_data);
    const reactionTime = calculateReactionTime(game_data);
    const gameSense = calculateGameSense(game_data, game_type);
    const clutchPerformance = calculateClutchPerformance(game_data);
    const teamSynergy = calculateTeamSynergy(game_data);
    const tacticalEfficiency = calculateEsportsTacticalEfficiency(
      game_data,
      game_type,
    );
    const spikeScore = calculateEsportsSpikeScore(game_data, game_type);
    const sessionConsistency = await calculateEsportsSessionConsistency(
      athlete.id,
      game_type,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      apm: Math.min(apm / 300, 1.0), // Normalize APM to 300 max
      reaction_time: reactionTime,
      game_sense: gameSense,
      clutch_performance: clutchPerformance,
      team_synergy: teamSynergy,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall esports performance index
    const weights = {
      apm: 0.15,
      reaction_time: 0.15,
      game_sense: 0.2,
      clutch_performance: 0.15,
      team_synergy: 0.1,
      tactical_efficiency: 0.15,
      spike_score: 0.1,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => key !== "session_consistency")
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display (professional vs amateur)
    const isProfessional = athlete.tier_level >= 3;
    const displayScale = isProfessional ? 1000 : 100;

    const displayMetrics = {
      apm: Math.round(apm),
      reaction_time: Math.round((1 - reactionTime) * 500 + 150), // Convert back to ms
      game_sense: Math.round(gameSense * displayScale),
      clutch_performance: Math.round(clutchPerformance * displayScale),
      team_synergy: Math.round(teamSynergy * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isProfessional ? "professional_esports" : "amateur_esports",
      game_type: game_type,
      timestamp: new Date().toISOString(),
    };

    // Generate esports-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      game_specific_tips: [],
    };

    // Identify strengths and weaknesses
    Object.entries(performanceMetrics).forEach(([metric, value]) => {
      if (value >= 0.8) {
        insights.strengths.push(`Excellent ${metric.replace("_", " ")}`);
      } else if (value <= 0.6) {
        insights.improvements.push(
          `Focus on improving ${metric.replace("_", " ")}`,
        );
      }
    });

    // Game-specific coaching tips
    switch (game_type) {
      case "moba":
        if (performanceMetrics.game_sense < 0.7) {
          insights.game_specific_tips.push(
            "Practice map awareness and ward placement",
          );
        }
        if (performanceMetrics.team_synergy < 0.7) {
          insights.game_specific_tips.push(
            "Work on communication and team fight coordination",
          );
        }
        break;
      case "fps":
        if (performanceMetrics.reaction_time < 0.7) {
          insights.game_specific_tips.push(
            "Use aim trainers to improve reaction time",
          );
        }
        if (performanceMetrics.tactical_efficiency < 0.7) {
          insights.game_specific_tips.push(
            "Focus on crosshair placement and angle clearing",
          );
        }
        break;
      case "fighting":
        if (performanceMetrics.spike_score < 0.7) {
          insights.game_specific_tips.push(
            "Practice combo execution and frame traps",
          );
        }
        break;
      case "battle_royale":
        if (performanceMetrics.tactical_efficiency < 0.7) {
          insights.game_specific_tips.push(
            "Improve zone positioning and rotation timing",
          );
        }
        break;
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.5, 1.0)}, -- ROI based on performance
        ${Math.max(0, 1 - sessionConsistency)}, -- Higher consistency = lower risk
        ${JSON.stringify({
          performance_metrics: displayMetrics,
          game_data: game_data,
          match_metadata: match_metadata,
        })},
        ${JSON.stringify({
          insights: insights,
          game_type: game_type,
          analysis_type: "esports_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      performance_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      game_type: game_type,
      message: `Esports Performance Index calculated for ${game_type.toUpperCase()}`,
    });
  } catch (error) {
    console.error("Esports performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate esports performance metrics" },
      { status: 500 },
    );
  }
}
