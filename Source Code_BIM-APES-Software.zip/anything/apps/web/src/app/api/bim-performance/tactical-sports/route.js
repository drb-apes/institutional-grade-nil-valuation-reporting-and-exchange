import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Field position analysis for tactical sports
function calculateFieldPositioning(tacticalData, sport) {
  const heatmapData = tacticalData.position_heatmap || {};

  switch (sport) {
    case "soccer":
      // Analyze thirds of the field (defensive, middle, attacking)
      const defensiveThird = heatmapData.defensive_third || 0.3;
      const middleThird = heatmapData.middle_third || 0.4;
      const attackingThird = heatmapData.attacking_third || 0.3;

      // Reward balanced positioning with slight emphasis on attacking presence
      return defensiveThird * 0.2 + middleThird * 0.3 + attackingThird * 0.5;

    case "basketball":
      // Court zones: paint, mid-range, three-point
      const paintTime = heatmapData.paint_percentage || 0.4;
      const midRangeTime = heatmapData.mid_range_percentage || 0.3;
      const threePointTime = heatmapData.three_point_percentage || 0.3;

      return paintTime * 0.4 + midRangeTime * 0.3 + threePointTime * 0.3;

    case "rugby":
      // Field positioning: forwards vs backs positioning
      const forwardWork = heatmapData.forward_zones || 0.5;
      const backlinePlay = heatmapData.backline_zones || 0.5;

      return forwardWork * 0.6 + backlinePlay * 0.4;

    default:
      return 0.7;
  }
}

// Decision making under pressure
function calculateDecisionMaking(tacticalData, sport) {
  const passAccuracy = tacticalData.pass_accuracy || 0.75;
  const decisionSpeed = tacticalData.decision_speed_ms
    ? Math.max(0, 1 - (tacticalData.decision_speed_ms - 500) / 2000)
    : 0.7;

  const contextualDecisions = tacticalData.contextual_decisions || {};

  switch (sport) {
    case "soccer":
      const keyPasses = contextualDecisions.key_passes || 0;
      const totalPasses = tacticalData.total_passes || 1;
      const creativityScore = Math.min(keyPasses / (totalPasses * 0.1), 1.0);

      return passAccuracy * 0.4 + decisionSpeed * 0.3 + creativityScore * 0.3;

    case "basketball":
      const assists = contextualDecisions.assists || 0;
      const turnovers = contextualDecisions.turnovers || 0;
      const assistTurnoverRatio = assists / Math.max(turnovers, 1);
      const ratioScore = Math.min(assistTurnoverRatio / 3, 1.0);

      return passAccuracy * 0.3 + decisionSpeed * 0.4 + ratioScore * 0.3;

    case "rugby":
      const offloads = contextualDecisions.successful_offloads || 0;
      const rucks = contextualDecisions.ruck_decisions || 0;
      const rugbyIQ = Math.min((offloads + rucks) / 10, 1.0);

      return passAccuracy * 0.3 + decisionSpeed * 0.3 + rugbyIQ * 0.4;

    default:
      return passAccuracy * 0.6 + decisionSpeed * 0.4;
  }
}

// Team coordination and communication
function calculateTeamSynergy(tacticalData, sport) {
  const communicationScore = tacticalData.communication_rating || 0.7;
  const positionDiscipline = tacticalData.position_discipline || 0.75;

  switch (sport) {
    case "soccer":
      const offsideAvoidance = tacticalData.offside_avoidance || 0.9;
      const setPlayExecution = tacticalData.set_play_success || 0.6;

      return (
        communicationScore * 0.3 +
        positionDiscipline * 0.3 +
        offsideAvoidance * 0.2 +
        setPlayExecution * 0.2
      );

    case "basketball":
      const screenEffectiveness = tacticalData.screen_effectiveness || 0.7;
      const defensiveRotations = tacticalData.defensive_rotations || 0.65;

      return (
        communicationScore * 0.25 +
        positionDiscipline * 0.25 +
        screenEffectiveness * 0.25 +
        defensiveRotations * 0.25
      );

    case "rugby":
      const lineoutSuccess = tacticalData.lineout_success || 0.8;
      const scrumStability = tacticalData.scrum_stability || 0.75;

      return (
        communicationScore * 0.3 +
        positionDiscipline * 0.2 +
        lineoutSuccess * 0.25 +
        scrumStability * 0.25
      );

    default:
      return communicationScore * 0.6 + positionDiscipline * 0.4;
  }
}

// Tactical efficiency main calculation
function calculateTacticalEfficiency(tacticalData, sport) {
  const fieldPositioning = calculateFieldPositioning(tacticalData, sport);
  const decisionMaking = calculateDecisionMaking(tacticalData, sport);
  const teamSynergy = calculateTeamSynergy(tacticalData, sport);

  // Weight based on sport characteristics
  const weights = {
    soccer: { positioning: 0.35, decisions: 0.4, synergy: 0.25 },
    basketball: { positioning: 0.3, decisions: 0.45, synergy: 0.25 },
    rugby: { positioning: 0.25, decisions: 0.35, synergy: 0.4 },
  };

  const w = weights[sport] || weights.soccer;

  return (
    fieldPositioning * w.positioning +
    decisionMaking * w.decisions +
    teamSynergy * w.synergy
  );
}

// Sport-specific spike score calculation
function calculateTacticalSpikeScore(tacticalData, sport) {
  switch (sport) {
    case "soccer":
      const goals = tacticalData.goals || 0;
      const assists = tacticalData.assists || 0;
      const gameChangingPlays = tacticalData.game_changing_plays || 0;
      const matchesPlayed = tacticalData.matches_played || 1;

      return Math.min(
        (goals * 1.0 + assists * 0.8 + gameChangingPlays * 0.6) / matchesPlayed,
        1.0,
      );

    case "basketball":
      const clutchShots = tacticalData.clutch_shots_made || 0;
      const clutchShotAttempts = tacticalData.clutch_shot_attempts || 1;
      const doubleDoubles = tacticalData.double_doubles || 0;
      const gamesPlayed = tacticalData.games_played || 1;

      const clutchPercentage = clutchShots / clutchShotAttempts;
      const statStuffing = doubleDoubles / gamesPlayed;

      return Math.min(clutchPercentage * 0.6 + statStuffing * 0.4, 1.0);

    case "rugby":
      const tries = tacticalData.tries || 0;
      const lineBreaks = tacticalData.line_breaks || 0;
      const turnoversForced = tacticalData.turnovers_forced || 0;
      const rugbyMatches = tacticalData.matches_played || 1;

      return Math.min(
        (tries * 1.0 + lineBreaks * 0.7 + turnoversForced * 0.5) / rugbyMatches,
        1.0,
      );

    default:
      return tacticalData.performance_rating || 0.7;
  }
}

// Session consistency for tactical sports
async function calculateTacticalSessionConsistency(athleteId, sport) {
  const recentSessions = await sql`
    SELECT simulation_data->'tactical_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
    AND valuation_factors->>'sport' = ${sport}
    ORDER BY created_at DESC
    LIMIT 10
  `;

  if (recentSessions.length < 3) return 0.7;

  const tacticalScores = recentSessions.map(
    (s) => s.metrics?.tactical_efficiency || 0.7,
  );

  const mean =
    tacticalScores.reduce((a, b) => a + b, 0) / tacticalScores.length;
  const variance =
    tacticalScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    tacticalScores.length;

  return Math.max(0, 1 - variance * 2);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { tactical_data, sport, position, competition_level } =
      await request.json();

    if (!tactical_data || !sport) {
      return Response.json(
        { error: "Tactical data and sport type required" },
        { status: 400 },
      );
    }

    const supportedSports = ["soccer", "basketball", "rugby"];
    if (!supportedSports.includes(sport)) {
      return Response.json(
        { error: `Sport must be one of: ${supportedSports.join(", ")}` },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate tactical sport metrics
    const fieldPositioning = calculateFieldPositioning(tactical_data, sport);
    const decisionMaking = calculateDecisionMaking(tactical_data, sport);
    const teamSynergy = calculateTeamSynergy(tactical_data, sport);
    const tacticalEfficiency = calculateTacticalEfficiency(
      tactical_data,
      sport,
    );
    const spikeScore = calculateTacticalSpikeScore(tactical_data, sport);
    const sessionConsistency = await calculateTacticalSessionConsistency(
      athlete.id,
      sport,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      field_positioning: fieldPositioning,
      decision_making: decisionMaking,
      team_synergy: teamSynergy,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall tactical performance index
    const weights = {
      field_positioning: 0.25,
      decision_making: 0.3,
      team_synergy: 0.2,
      tactical_efficiency: 0.25,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => !["session_consistency", "spike_score"].includes(key))
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display based on competition level
    const isProfessional =
      competition_level === "professional" || athlete.tier_level >= 4;
    const displayScale = isProfessional ? 100 : 80;

    const displayMetrics = {
      field_positioning: Math.round(fieldPositioning * displayScale),
      decision_making: Math.round(decisionMaking * displayScale),
      team_synergy: Math.round(teamSynergy * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isProfessional ? `professional_${sport}` : `amateur_${sport}`,
      sport: sport,
      position: position,
      timestamp: new Date().toISOString(),
    };

    // Generate sport-specific insights
    const insights = {
      strengths: [],
      improvements: [],
      sport_specific_tips: [],
    };

    // Analyze strengths and weaknesses
    if (performanceMetrics.field_positioning >= 0.8) {
      insights.strengths.push("Excellent field awareness and positioning");
    } else if (performanceMetrics.field_positioning <= 0.6) {
      insights.improvements.push(
        "Work on field positioning and spatial awareness",
      );
    }

    if (performanceMetrics.decision_making >= 0.8) {
      insights.strengths.push("Outstanding decision-making under pressure");
    } else if (performanceMetrics.decision_making <= 0.6) {
      insights.improvements.push("Focus on quicker, more accurate decisions");
    }

    if (performanceMetrics.team_synergy >= 0.8) {
      insights.strengths.push("Strong team coordination and communication");
    } else if (performanceMetrics.team_synergy <= 0.6) {
      insights.improvements.push(
        "Improve team communication and positioning discipline",
      );
    }

    // Sport-specific tips
    switch (sport) {
      case "soccer":
        if (performanceMetrics.field_positioning <= 0.6) {
          insights.sport_specific_tips.push(
            "Practice small-sided games to improve positioning",
          );
        }
        if (performanceMetrics.decision_making <= 0.6) {
          insights.sport_specific_tips.push(
            "Work on first touch and quick passing combinations",
          );
        }
        if (position) {
          if (position.includes("defender")) {
            insights.sport_specific_tips.push(
              "Focus on reading the game and communication with midfield",
            );
          } else if (position.includes("midfield")) {
            insights.sport_specific_tips.push(
              "Develop 360-degree awareness and switching play",
            );
          } else if (position.includes("forward")) {
            insights.sport_specific_tips.push(
              "Practice movement in the box and creating space",
            );
          }
        }
        break;

      case "basketball":
        if (performanceMetrics.field_positioning <= 0.6) {
          insights.sport_specific_tips.push(
            "Study team offensive sets and defensive rotations",
          );
        }
        if (performanceMetrics.team_synergy <= 0.6) {
          insights.sport_specific_tips.push(
            "Practice screening techniques and help defense communication",
          );
        }
        if (position) {
          if (position.includes("guard")) {
            insights.sport_specific_tips.push(
              "Develop court vision and pick-and-roll execution",
            );
          } else if (position.includes("forward")) {
            insights.sport_specific_tips.push(
              "Work on high-low passing and help defense positioning",
            );
          }
        }
        break;

      case "rugby":
        if (performanceMetrics.team_synergy <= 0.6) {
          insights.sport_specific_tips.push(
            "Focus on lineout calls and scrum communication",
          );
        }
        if (performanceMetrics.decision_making <= 0.6) {
          insights.sport_specific_tips.push(
            "Practice decision-making at breakdown and in contact",
          );
        }
        if (position) {
          if (position.includes("forward")) {
            insights.sport_specific_tips.push(
              "Develop set-piece accuracy and breakdown technique",
            );
          } else if (position.includes("back")) {
            insights.sport_specific_tips.push(
              "Work on passing under pressure and attacking lines",
            );
          }
        }
        break;
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.3, 1.0)},
        ${Math.max(0, 1 - sessionConsistency)},
        ${JSON.stringify({
          tactical_metrics: displayMetrics,
          tactical_data: tactical_data,
          sport_context: { sport, position, competition_level },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: sport,
          analysis_type: "tactical_sports_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      tactical_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: sport,
      position: position,
      message: `Tactical Performance Index calculated for ${sport.toUpperCase()} - ${position || "All Positions"}`,
    });
  } catch (error) {
    console.error("Tactical sports performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate tactical sports performance metrics" },
      { status: 500 },
    );
  }
}
