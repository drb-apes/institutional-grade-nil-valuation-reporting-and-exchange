import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Event category performance calculations
function calculateSprintPerformance(trackData) {
  const personalBest = trackData.personal_best_time || 12.0; // 100m default
  const seasonBest = trackData.season_best_time || personalBest;
  const eventDistance = trackData.event_distance || 100;

  // Calculate improvement rate
  const improvementRate = Math.max(
    0,
    (personalBest - seasonBest) / personalBest,
  );

  // Reaction time analysis
  const reactionTime = trackData.reaction_time || 0.18;
  const reactionScore = Math.max(0, 1 - (reactionTime - 0.12) / 0.15); // 0.12s = perfect

  // Block clearance and acceleration
  const blockClearance = trackData.block_clearance_score || 0.7;
  const accelerationPhase = trackData.acceleration_phase_score || 0.75;

  // Speed endurance (for 200m+)
  const speedEndurance =
    eventDistance > 100 ? trackData.speed_endurance_score || 0.7 : 1.0;

  return (
    improvementRate * 2 +
    reactionScore * 0.25 +
    blockClearance * 0.25 +
    accelerationPhase * 0.3 +
    speedEndurance * 0.2
  );
}

function calculateDistancePerformance(trackData) {
  const personalBest = trackData.personal_best_time || 300; // 5000m default (seconds)
  const seasonBest = trackData.season_best_time || personalBest;

  // Pacing consistency
  const splitVariance = trackData.split_variance || 0.05; // Lower is better
  const pacingScore = Math.max(0, 1 - splitVariance * 10);

  // Kick finish strength
  const finalKickTime = trackData.final_400m_split || 70;
  const averageLapTime = personalBest / (trackData.event_distance / 400);
  const kickStrength = Math.min(averageLapTime / finalKickTime, 1.2);

  // Race tactics and positioning
  const raceTactics = trackData.race_tactics_score || 0.7;
  const positioningAwareness = trackData.positioning_awareness || 0.75;

  return (
    pacingScore * 0.3 +
    kickStrength * 0.3 +
    raceTactics * 0.25 +
    positioningAwareness * 0.15
  );
}

function calculateFieldEventPerformance(trackData, eventType) {
  const personalBest = trackData.personal_best_mark || 10.0; // meters/feet
  const seasonBest = trackData.season_best_mark || personalBest;

  // Technical execution scoring
  const techniqueScore = trackData.technique_score || 0.7;
  const consistencyScore = trackData.mark_consistency || 0.65;

  switch (eventType) {
    case "shot_put":
    case "discus":
    case "hammer":
    case "javelin":
      const rotationalSpeed = trackData.rotational_speed_score || 0.7;
      const releaseAngle = trackData.release_angle_score || 0.65;
      const footwork = trackData.footwork_score || 0.7;

      return (
        techniqueScore * 0.3 +
        rotationalSpeed * 0.25 +
        releaseAngle * 0.25 +
        footwork * 0.2
      );

    case "long_jump":
    case "triple_jump":
      const approachSpeed = trackData.approach_speed_score || 0.7;
      const takeoffAccuracy = trackData.takeoff_accuracy || 0.65;
      const flightTechnique = trackData.flight_technique || 0.7;

      return (
        approachSpeed * 0.3 +
        takeoffAccuracy * 0.3 +
        flightTechnique * 0.25 +
        techniqueScore * 0.15
      );

    case "high_jump":
    case "pole_vault":
      const approachRhythm = trackData.approach_rhythm_score || 0.7;
      const takeoffTiming = trackData.takeoff_timing || 0.65;
      const clearanceTechnique = trackData.clearance_technique || 0.7;

      return (
        approachRhythm * 0.25 +
        takeoffTiming * 0.3 +
        clearanceTechnique * 0.3 +
        techniqueScore * 0.15
      );

    default:
      return techniqueScore * 0.6 + consistencyScore * 0.4;
  }
}

// Multi-event performance (decathlon/heptathlon)
function calculateMultiEventPerformance(trackData) {
  const eventScores = trackData.event_scores || [];
  if (eventScores.length < 7) return 0.7; // Need minimum events

  // Calculate balance across events
  const mean = eventScores.reduce((a, b) => a + b, 0) / eventScores.length;
  const variance =
    eventScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    eventScores.length;

  const balanceScore = Math.max(0, 1 - variance / (mean * mean));

  // Event transition efficiency
  const transitionRecovery = trackData.transition_recovery_score || 0.75;
  const mentalToughness = trackData.mental_toughness_score || 0.7;

  return balanceScore * 0.4 + transitionRecovery * 0.3 + mentalToughness * 0.3;
}

// Track & Field tactical efficiency
function calculateTrackFieldTacticalEfficiency(
  trackData,
  eventCategory,
  eventType,
) {
  switch (eventCategory) {
    case "sprint":
      return calculateSprintPerformance(trackData);
    case "distance":
      return calculateDistancePerformance(trackData);
    case "field":
      return calculateFieldEventPerformance(trackData, eventType);
    case "multi":
      return calculateMultiEventPerformance(trackData);
    default:
      return 0.7;
  }
}

// Track & Field spike score
function calculateTrackFieldSpikeScore(trackData, eventCategory) {
  const personalRecords = trackData.personal_records_this_season || 0;
  const meetWins = trackData.meet_wins || 0;
  const qualifyingMarks = trackData.qualifying_marks_hit || 0;
  const competitions = trackData.competitions_entered || 1;

  const prRate = personalRecords / competitions;
  const winRate = meetWins / competitions;
  const qualifyingRate = qualifyingMarks / competitions;

  // Big performance moments
  const clutchPerformances = trackData.clutch_performances || 0;
  const clutchRate = clutchPerformances / competitions;

  return Math.min(
    prRate * 0.4 + winRate * 0.3 + qualifyingRate * 0.2 + clutchRate * 0.1,
    1.0,
  );
}

// Session consistency for track & field
async function calculateTrackFieldSessionConsistency(athleteId, eventCategory) {
  const recentSessions = await sql`
    SELECT simulation_data->'track_field_metrics' as metrics
    FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    AND created_at > CURRENT_TIMESTAMP - INTERVAL '45 days'
    AND valuation_factors->>'sport' = 'track_field'
    AND valuation_factors->>'event_category' = ${eventCategory}
    ORDER BY created_at DESC
    LIMIT 12
  `;

  if (recentSessions.length < 3) return 0.7;

  const tacticalScores = recentSessions.map(
    (s) => s.metrics?.tactical_efficiency || 0.7,
  );

  const mean =
    tacticalScores.reduce((a, b) => a + b, 0) / tacticalScores.length;
  const variance =
    tacticalScores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) /
    tacticalScores.length;

  return Math.max(0, 1 - variance * 1.5);
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { track_data, event_category, event_type, competition_level } =
      await request.json();

    if (!track_data || !event_category) {
      return Response.json(
        { error: "Track & Field data and event category required" },
        { status: 400 },
      );
    }

    const validCategories = ["sprint", "distance", "field", "multi"];
    if (!validCategories.includes(event_category)) {
      return Response.json(
        {
          error: `Event category must be one of: ${validCategories.join(", ")}`,
        },
        { status: 400 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT * FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const athlete = userProfile[0];

    // Calculate track & field metrics
    const techniqueScore = track_data.technique_score || 0.7;
    const conditioningScore = track_data.conditioning_score || 0.75;
    const competitionReadiness = track_data.competition_readiness || 0.7;
    const tacticalEfficiency = calculateTrackFieldTacticalEfficiency(
      track_data,
      event_category,
      event_type,
    );
    const spikeScore = calculateTrackFieldSpikeScore(
      track_data,
      event_category,
    );
    const sessionConsistency = await calculateTrackFieldSessionConsistency(
      athlete.id,
      event_category,
    );

    // Normalized performance metrics (0-1 scale)
    const performanceMetrics = {
      technique_score: techniqueScore,
      conditioning_score: conditioningScore,
      competition_readiness: competitionReadiness,
      tactical_efficiency: tacticalEfficiency,
      spike_score: spikeScore,
      session_consistency: sessionConsistency,
    };

    // Calculate overall track & field performance index
    const weights = {
      technique_score: 0.3,
      conditioning_score: 0.25,
      competition_readiness: 0.2,
      tactical_efficiency: 0.25,
    };

    const overallScore = Object.entries(performanceMetrics)
      .filter(([key]) => !["session_consistency", "spike_score"].includes(key))
      .reduce((sum, [key, value]) => sum + value * weights[key], 0);

    // Scale for display based on competition level
    const isCollegiate =
      competition_level === "collegiate" ||
      competition_level === "professional" ||
      athlete.tier_level >= 3;
    const displayScale = isCollegiate ? 100 : 85;

    const displayMetrics = {
      technique_score: Math.round(techniqueScore * displayScale),
      conditioning_score: Math.round(conditioningScore * displayScale),
      competition_readiness: Math.round(competitionReadiness * displayScale),
      tactical_efficiency: Math.round(tacticalEfficiency * displayScale),
      spike_score: Math.round(spikeScore * displayScale),
      session_consistency: Math.round(sessionConsistency * displayScale),
      overall_score: Math.round(overallScore * displayScale),
      scale_type: isCollegiate
        ? "collegiate_track_field"
        : "high_school_track_field",
      event_category: event_category,
      event_type: event_type,
      timestamp: new Date().toISOString(),
    };

    // Generate track & field specific insights
    const insights = {
      strengths: [],
      improvements: [],
      track_field_tips: [],
    };

    // Analyze strengths and weaknesses
    if (performanceMetrics.technique_score >= 0.8) {
      insights.strengths.push("Excellent technical execution");
    } else if (performanceMetrics.technique_score <= 0.6) {
      insights.improvements.push("Focus on technical refinement and form");
    }

    if (performanceMetrics.conditioning_score >= 0.8) {
      insights.strengths.push("Outstanding physical conditioning");
    } else if (performanceMetrics.conditioning_score <= 0.6) {
      insights.improvements.push("Improve event-specific conditioning");
    }

    // Event-specific tips
    switch (event_category) {
      case "sprint":
        if (performanceMetrics.tactical_efficiency <= 0.6) {
          insights.track_field_tips.push(
            "Work on block starts and acceleration mechanics",
          );
        }
        insights.track_field_tips.push(
          "Practice race simulation and pressure situations",
        );
        break;

      case "distance":
        if (performanceMetrics.tactical_efficiency <= 0.6) {
          insights.track_field_tips.push(
            "Focus on pacing strategy and race tactics",
          );
        }
        insights.track_field_tips.push(
          "Develop kick finish and surging ability",
        );
        break;

      case "field":
        if (performanceMetrics.technique_score <= 0.6) {
          insights.track_field_tips.push(
            "Video analysis for technical improvements",
          );
        }
        insights.track_field_tips.push(
          "Practice visualization and routine consistency",
        );
        break;

      case "multi":
        if (performanceMetrics.session_consistency <= 0.6) {
          insights.track_field_tips.push(
            "Focus on event transition and recovery protocols",
          );
        }
        insights.track_field_tips.push(
          "Balance training across all event disciplines",
        );
        break;
    }

    // Competition level advice
    if (competition_level === "professional") {
      insights.track_field_tips.push(
        "Optimize peak performance timing for major competitions",
      );
    } else if (competition_level === "collegiate") {
      insights.track_field_tips.push(
        "Focus on consistent improvement and qualifying marks",
      );
    }

    // Store performance data
    const simulationRecord = await sql`
      INSERT INTO asset_simulations (
        athlete_id,
        asset_value,
        roi_projection,
        risk_score,
        simulation_data,
        valuation_factors
      ) VALUES (
        ${athlete.id},
        ${displayMetrics.overall_score},
        ${Math.min(overallScore * 1.3, 1.0)},
        ${Math.max(0, 1 - sessionConsistency)},
        ${JSON.stringify({
          track_field_metrics: displayMetrics,
          track_data: track_data,
          sport_context: { event_category, event_type, competition_level },
        })},
        ${JSON.stringify({
          insights: insights,
          sport: "track_field",
          event_category: event_category,
          analysis_type: "track_field_performance",
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      track_field_metrics: displayMetrics,
      insights: insights,
      simulation_id: simulationRecord[0].id,
      sport: "track_field",
      event_category: event_category,
      event_type: event_type,
      message: `Track & Field Performance Index - ${event_category.toUpperCase()} ${event_type ? `(${event_type})` : ""}`,
    });
  } catch (error) {
    console.error("Track & Field performance calculation error:", error);
    return Response.json(
      { error: "Failed to calculate Track & Field performance metrics" },
      { status: 500 },
    );
  }
}
