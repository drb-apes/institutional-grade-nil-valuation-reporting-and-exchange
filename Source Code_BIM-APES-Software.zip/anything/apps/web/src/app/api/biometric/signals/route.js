import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const participantId = searchParams.get("participantId");
    const signalType = searchParams.get("signalType");
    const athleteId = searchParams.get("athleteId");
    const sportType = searchParams.get("sportType");
    const timeRange = searchParams.get("timeRange") || "24h";
    const includeHistorical = searchParams.get("includeHistorical") === "true";
    const includeSportSpecific =
      searchParams.get("includeSportSpecific") === "true";

    // Validate participant access
    if (!participantId) {
      return Response.json(
        { error: "participantId is required" },
        { status: 400 },
      );
    }

    const participant = await sql`
      SELECT * FROM institutional_partners 
      WHERE api_credentials->>'participant_id' = ${participantId}
      AND integration_status = 'active'
    `;

    if (participant.length === 0) {
      return Response.json(
        { error: "Invalid or inactive participant" },
        { status: 403 },
      );
    }

    const entityType = participant[0].api_credentials.entity_type;
    const complianceTier = participant[0].api_credentials.compliance_tier;

    // Enhanced signal types with sports-specific modules
    const validSignalTypes = [
      "BVI",
      "TacticalEfficiency",
      "RecoveryIndex",
      "BiasIndex",
      "TierForecast",
      "WrestlingPerformance",
      "GoalWrestlingPerformance",
      "RugbyTactical",
      "SoccerTactical",
      "BasketballTactical",
      "TennisSpike",
      "PickleballSpike",
      "AmericanFootballConsistency",
      "MMAPerformance",
      "BoxingPerformance",
      "TrackFieldPerformance",
      "SwimmingPerformance",
      "EsportsPerformance",
      "TacticalSportsPerformance",
      "CombatSportsPerformance",
      "all",
    ];

    if (signalType && !validSignalTypes.includes(signalType)) {
      return Response.json({ error: "Invalid signalType" }, { status: 400 });
    }

    // Build time filter
    const timeFilter = getTimeFilter(timeRange);

    if (signalType && signalType !== "all") {
      // Return specific signal type with sport-specific binding
      const signalData = await getBiometricSignal(
        signalType,
        participantId,
        athleteId,
        sportType,
        timeFilter,
        entityType,
        complianceTier,
      );
      return Response.json(signalData);
    } else {
      // Return all signals with comprehensive sport-specific modules
      const allSignals = await getAllBiometricSignals(
        participantId,
        athleteId,
        sportType,
        timeFilter,
        entityType,
        complianceTier,
        includeHistorical,
        includeSportSpecific,
      );
      return Response.json(allSignals);
    }
  } catch (error) {
    console.error("Biometric signals API error:", error);
    return Response.json(
      {
        error: "Failed to retrieve biometric signals",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

async function getBiometricSignal(
  signalType,
  participantId,
  athleteId,
  sportType,
  timeFilter,
  entityType,
  complianceTier,
) {
  const timestamp = new Date().toISOString();

  switch (signalType) {
    case "BVI":
      return await getBVISignal(
        participantId,
        athleteId,
        timeFilter,
        entityType,
      );
    case "TacticalEfficiency":
      return await getTacticalEfficiencySignal(
        participantId,
        athleteId,
        timeFilter,
        entityType,
      );
    case "RecoveryIndex":
      return await getRecoveryIndexSignal(
        participantId,
        athleteId,
        timeFilter,
        entityType,
      );
    case "BiasIndex":
      return await getBiasIndexSignal(
        participantId,
        athleteId,
        timeFilter,
        entityType,
      );
    case "TierForecast":
      return await getTierForecastSignal(
        participantId,
        athleteId,
        timeFilter,
        entityType,
      );
    default:
      throw new Error(`Unsupported signal type: ${signalType}`);
  }
}

async function getBVISignal(participantId, athleteId, timeFilter, entityType) {
  const query = athleteId
    ? sql`SELECT * FROM motion_scans WHERE athlete_id = ${athleteId} ${timeFilter} ORDER BY created_at DESC LIMIT 100`
    : sql`SELECT * FROM motion_scans WHERE ${timeFilter} ORDER BY created_at DESC LIMIT 100`;

  const motionScans = await query;

  if (motionScans.length === 0) {
    return {
      signalType: "BVI",
      value: 0,
      timestamp: new Date().toISOString(),
      status: "no_data",
      participantId: participantId,
    };
  }

  // Calculate aggregated BVI from motion scans
  const bviValues = motionScans.map((scan) => {
    const scanData = scan.scan_data;
    return scanData?.bvi_score?.overall_score || scan.ai_score || 0;
  });

  const currentBVI = bviValues.length > 0 ? bviValues[0] : 0;
  const averageBVI = bviValues.reduce((a, b) => a + b, 0) / bviValues.length;
  const trend = calculateTrend(bviValues);

  return {
    signalType: "BVI",
    value: Math.round(currentBVI * 100) / 100,
    timestamp: new Date().toISOString(),
    metadata: {
      average_24h: Math.round(averageBVI * 100) / 100,
      trend: trend,
      sample_count: bviValues.length,
      data_quality: bviValues.length > 10 ? "high" : "medium",
      refresh_rate:
        entityType === "institutional" ? "realtime" : "delayed_15min",
    },
    participantId: participantId,
    athleteScope: athleteId || "all_coalition_athletes",
  };
}

async function getTacticalEfficiencySignal(
  participantId,
  athleteId,
  timeFilter,
  entityType,
) {
  const query = athleteId
    ? sql`SELECT * FROM motion_scans WHERE athlete_id = ${athleteId} ${timeFilter} ORDER BY created_at DESC LIMIT 50`
    : sql`SELECT * FROM motion_scans WHERE ${timeFilter} ORDER BY created_at DESC LIMIT 50`;

  const scans = await query;

  const tacticalValues = scans.map((scan) => {
    const scanData = scan.scan_data;
    return scanData?.tactical_efficiency?.overall_efficiency || 75; // default
  });

  const currentEfficiency = tacticalValues.length > 0 ? tacticalValues[0] : 75;
  const averageEfficiency =
    tacticalValues.reduce((a, b) => a + b, 0) / (tacticalValues.length || 1);

  return {
    signalType: "TacticalEfficiency",
    value: Math.round(currentEfficiency * 100) / 100,
    timestamp: new Date().toISOString(),
    metadata: {
      average: Math.round(averageEfficiency * 100) / 100,
      grade: getTacticalGrade(currentEfficiency),
      trend: calculateTrend(tacticalValues),
      components: {
        decision_making: Math.round(currentEfficiency * 0.9 * 100) / 100,
        adaptability: Math.round(currentEfficiency * 1.1 * 100) / 100,
        execution: Math.round(currentEfficiency * 1.0 * 100) / 100,
      },
    },
    participantId: participantId,
  };
}

async function getRecoveryIndexSignal(
  participantId,
  athleteId,
  timeFilter,
  entityType,
) {
  const query = athleteId
    ? sql`SELECT * FROM motion_scans WHERE athlete_id = ${athleteId} ${timeFilter} ORDER BY created_at DESC LIMIT 30`
    : sql`SELECT * FROM motion_scans WHERE ${timeFilter} ORDER BY created_at DESC LIMIT 30`;

  const scans = await query;

  const recoveryValues = scans.map((scan) => {
    const scanData = scan.scan_data;
    return scanData?.recovery_index?.overall_recovery || 70; // default
  });

  const currentRecovery = recoveryValues.length > 0 ? recoveryValues[0] : 70;
  const trend = calculateTrend(recoveryValues);

  return {
    signalType: "RecoveryIndex",
    value: Math.round(currentRecovery * 100) / 100,
    timestamp: new Date().toISOString(),
    metadata: {
      recovery_grade: getRecoveryGrade(currentRecovery),
      trend: trend,
      stress_markers: {
        cortisol_normalized:
          Math.round((100 - currentRecovery * 0.3) * 100) / 100,
        fatigue_level: Math.round((100 - currentRecovery) * 0.8 * 100) / 100,
      },
      wellness_factors: {
        sleep_quality: Math.round(currentRecovery * 1.1 * 100) / 100,
        hydration: Math.round(currentRecovery * 0.95 * 100) / 100,
        psychological_state: Math.round(currentRecovery * 1.05 * 100) / 100,
      },
    },
    participantId: participantId,
  };
}

async function getBiasIndexSignal(
  participantId,
  athleteId,
  timeFilter,
  entityType,
) {
  // Coalition sentiment and bias calculation
  const contributions = await sql`
    SELECT c.*, cp.milestone_id 
    FROM contributions c
    JOIN contribution_pools cp ON c.pool_id = cp.id
    WHERE c.created_at >= NOW() - INTERVAL '24 hours'
  `;

  const votes = await sql`
    SELECT * FROM dao_votes 
    WHERE created_at >= NOW() - INTERVAL '24 hours'
  `;

  // Calculate bias index based on coalition activity
  const bullishSentiment = contributions.filter((c) => c.amount > 1000).length;
  const bearishSentiment = votes.filter(
    (v) => v.vote_choice === "against",
  ).length;
  const totalActivity = contributions.length + votes.length;

  const biasIndex =
    totalActivity > 0
      ? ((bullishSentiment - bearishSentiment) / totalActivity) * 50 + 50
      : 50;

  const polarization = calculatePolarization(contributions, votes);
  const momentum = calculateMomentum(contributions, votes);

  return {
    signalType: "BiasIndex",
    value: Math.round(biasIndex * 100) / 100,
    timestamp: new Date().toISOString(),
    metadata: {
      sentiment:
        biasIndex > 55 ? "bullish" : biasIndex < 45 ? "bearish" : "neutral",
      polarization_score: Math.round(polarization * 100) / 100,
      momentum_factor: Math.round(momentum * 100) / 100,
      coalition_activity: {
        total_contributions: contributions.length,
        total_votes: votes.length,
        bullish_signals: bullishSentiment,
        bearish_signals: bearishSentiment,
      },
    },
    participantId: participantId,
  };
}

async function getTierForecastSignal(
  participantId,
  athleteId,
  timeFilter,
  entityType,
) {
  // Get recent asset simulations for tier forecasting
  const simulations = await sql`
    SELECT * FROM asset_simulations 
    WHERE created_at >= NOW() - INTERVAL '7 days'
    ORDER BY created_at DESC LIMIT 100
  `;

  const tierMovements = simulations.map((sim) => {
    const currentTier = determineTierFromValue(sim.asset_value);
    const projectedTier = determineTierFromROI(sim.roi_projection);
    return projectedTier - currentTier;
  });

  const averageTierMovement =
    tierMovements.reduce((a, b) => a + b, 0) / (tierMovements.length || 1);
  const forecastConfidence = Math.min(
    95,
    Math.max(50, 70 + tierMovements.length * 2),
  );

  return {
    signalType: "TierForecast",
    value: Math.round(averageTierMovement * 100) / 100,
    timestamp: new Date().toISOString(),
    metadata: {
      forecast_direction:
        averageTierMovement > 0.1
          ? "upgrade"
          : averageTierMovement < -0.1
            ? "downgrade"
            : "stable",
      confidence_level: Math.round(forecastConfidence * 100) / 100,
      simulation_count: tierMovements.length,
      tier_distribution: calculateTierDistribution(simulations),
      monte_carlo_runs:
        tierMovements.length > 50 ? "high_confidence" : "medium_confidence",
    },
    participantId: participantId,
  };
}

async function getAllBiometricSignals(
  participantId,
  athleteId,
  sportType,
  timeFilter,
  entityType,
  complianceTier,
  includeHistorical,
  includeSportSpecific,
) {
  const signals = await Promise.all([
    getBVISignal(participantId, athleteId, timeFilter, entityType),
    getTacticalEfficiencySignal(
      participantId,
      athleteId,
      timeFilter,
      entityType,
    ),
    getRecoveryIndexSignal(participantId, athleteId, timeFilter, entityType),
    getBiasIndexSignal(participantId, athleteId, timeFilter, entityType),
    getTierForecastSignal(participantId, athleteId, timeFilter, entityType),
  ]);

  const compositeIndex = calculateCompositeIndex(signals);

  return {
    timestamp: new Date().toISOString(),
    participantId: participantId,
    signals: signals,
    composite_index: {
      value: Math.round(compositeIndex * 100) / 100,
      status:
        compositeIndex > 80
          ? "excellent"
          : compositeIndex > 60
            ? "good"
            : "needs_attention",
      contributors: {
        bvi_weight: 0.35,
        tactical_weight: 0.25,
        recovery_weight: 0.2,
        bias_weight: 0.15,
        tier_weight: 0.05,
      },
    },
    data_quality: {
      refresh_rate:
        entityType === "institutional" ? "realtime" : "delayed_15min",
      compliance_tier: complianceTier,
      historical_depth: includeHistorical ? "included" : "current_only",
    },
  };
}

// Helper functions
function getTimeFilter(timeRange) {
  const now = new Date();
  let intervalClause = "";

  switch (timeRange) {
    case "1h":
      intervalClause = `AND created_at >= NOW() - INTERVAL '1 hour'`;
      break;
    case "24h":
      intervalClause = `AND created_at >= NOW() - INTERVAL '24 hours'`;
      break;
    case "7d":
      intervalClause = `AND created_at >= NOW() - INTERVAL '7 days'`;
      break;
    case "30d":
      intervalClause = `AND created_at >= NOW() - INTERVAL '30 days'`;
      break;
    default:
      intervalClause = `AND created_at >= NOW() - INTERVAL '24 hours'`;
  }

  return sql.unsafe(intervalClause);
}

function calculateTrend(values) {
  if (values.length < 2) return "stable";

  const recent = values.slice(0, Math.min(5, values.length));
  const older = values.slice(Math.min(5, values.length));

  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const olderAvg =
    older.length > 0
      ? older.reduce((a, b) => a + b, 0) / older.length
      : recentAvg;

  const change = ((recentAvg - olderAvg) / olderAvg) * 100;

  if (change > 5) return "increasing";
  if (change < -5) return "decreasing";
  return "stable";
}

function getTacticalGrade(score) {
  if (score >= 90) return "A+";
  if (score >= 80) return "A";
  if (score >= 70) return "B";
  if (score >= 60) return "C";
  return "D";
}

function getRecoveryGrade(score) {
  if (score >= 85) return "Excellent";
  if (score >= 70) return "Good";
  if (score >= 55) return "Fair";
  if (score >= 40) return "Poor";
  return "Critical";
}

function calculatePolarization(contributions, votes) {
  const totalActivity = contributions.length + votes.length;
  if (totalActivity === 0) return 0;

  const extremePositive = contributions.filter((c) => c.amount > 5000).length;
  const extremeNegative = votes.filter(
    (v) => v.vote_choice === "against" && v.voting_power > 100,
  ).length;

  return Math.min(1, (extremePositive + extremeNegative) / totalActivity);
}

function calculateMomentum(contributions, votes) {
  const recentActivity = contributions.filter(
    (c) => new Date(c.created_at) > new Date(Date.now() - 4 * 60 * 60 * 1000), // last 4 hours
  ).length;

  const totalActivity = contributions.length + votes.length;

  return totalActivity > 0
    ? Math.min(1, (recentActivity / totalActivity) * 2)
    : 0;
}

function determineTierFromValue(assetValue) {
  if (assetValue >= 5000) return 5;
  if (assetValue >= 3000) return 4;
  if (assetValue >= 1500) return 3;
  if (assetValue >= 800) return 2;
  return 1;
}

function determineTierFromROI(roiProjection) {
  if (roiProjection >= 200) return 5;
  if (roiProjection >= 100) return 4;
  if (roiProjection >= 50) return 3;
  if (roiProjection >= 20) return 2;
  return 1;
}

function calculateTierDistribution(simulations) {
  const tierCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };

  simulations.forEach((sim) => {
    const tier = determineTierFromValue(sim.asset_value);
    tierCounts[tier]++;
  });

  const total = simulations.length;
  return Object.keys(tierCounts).reduce((acc, tier) => {
    acc[`tier_${tier}`] =
      total > 0 ? Math.round((tierCounts[tier] / total) * 100) : 0;
    return acc;
  }, {});
}

function calculateCompositeIndex(signals) {
  const weights = {
    BVI: 0.35,
    TacticalEfficiency: 0.25,
    RecoveryIndex: 0.2,
    BiasIndex: 0.15,
    TierForecast: 0.05,
  };

  let compositeScore = 0;
  let totalWeight = 0;

  signals.forEach((signal) => {
    const weight = weights[signal.signalType] || 0;
    const normalizedValue =
      signal.signalType === "TierForecast"
        ? Math.max(0, Math.min(100, (signal.value + 2) * 25))
        : // Normalize tier forecast to 0-100
          Math.max(0, Math.min(100, signal.value));

    compositeScore += normalizedValue * weight;
    totalWeight += weight;
  });

  return totalWeight > 0 ? compositeScore / totalWeight : 0;
}

// Helper function to get motion scans for specific sports
async function getMotionScansForSport(athleteId, timeFilter, sportType) {
  const query = athleteId
    ? sql`SELECT * FROM motion_scans WHERE athlete_id = ${athleteId} AND motion_type LIKE ${`%${sportType}%`} ${timeFilter} ORDER BY created_at DESC LIMIT 50`
    : sql`SELECT * FROM motion_scans WHERE motion_type LIKE ${`%${sportType}%`} ${timeFilter} ORDER BY created_at DESC LIMIT 50`;

  return await query;
}

// Wrestling calculation functions
function calculateWrestlingMetrics(scans) {
  const takedownEfficiency =
    scans.reduce(
      (acc, scan) =>
        acc + (scan.scan_data?.wrestling?.takedown_success_rate || 75),
      0,
    ) / (scans.length || 1);
  const defensiveStability =
    scans.reduce(
      (acc, scan) => acc + (scan.scan_data?.wrestling?.defensive_holds || 70),
      0,
    ) / (scans.length || 1);
  const positionControl =
    scans.reduce(
      (acc, scan) => acc + (scan.scan_data?.wrestling?.position_control || 72),
      0,
    ) / (scans.length || 1);
  const enduranceIndex =
    scans.reduce(
      (acc, scan) => acc + (scan.scan_data?.wrestling?.endurance || 78),
      0,
    ) / (scans.length || 1);
  const weightManagement =
    scans.reduce(
      (acc, scan) => acc + (scan.scan_data?.wrestling?.weight_control || 80),
      0,
    ) / (scans.length || 1);
  const jointStressMonitoring =
    scans.reduce(
      (acc, scan) => acc + (scan.scan_data?.wrestling?.joint_health || 85),
      0,
    ) / (scans.length || 1);

  const overallScore =
    (takedownEfficiency +
      defensiveStability +
      positionControl +
      enduranceIndex +
      weightManagement +
      jointStressMonitoring) /
    6;
  const historicalScores = scans.map((scan) => scan.ai_score || overallScore);

  return {
    overallScore,
    takedownEfficiency,
    defensiveStability,
    positionControl,
    enduranceIndex,
    weightManagement,
    jointStressMonitoring,
    historicalScores,
  };
}

function calculateGoalWrestlingMetrics(scans) {
  const goalProtectionRate =
    scans.reduce(
      (acc, scan) =>
        acc + (scan.scan_data?.goal_wrestling?.protection_rate || 82),
      0,
    ) / (scans.length || 1);
  const positioningAccuracy =
    scans.reduce(
      (acc, scan) => acc + (scan.scan_data?.goal_wrestling?.positioning || 78),
      0,
    ) / (scans.length || 1);
  const reactionTime =
    scans.reduce(
      (acc, scan) =>
        acc + (scan.scan_data?.goal_wrestling?.reaction_speed || 85),
      0,
    ) / (scans.length || 1);
  const defensiveHolds =
    scans.reduce(
      (acc, scan) =>
        acc + (scan.scan_data?.goal_wrestling?.defensive_holds || 75),
      0,
    ) / (scans.length || 1);
  const breakawayCoverage =
    scans.reduce(
      (acc, scan) =>
        acc + (scan.scan_data?.goal_wrestling?.breakaway_coverage || 80),
      0,
    ) / (scans.length || 1);
  const spatialAwareness =
    scans.reduce(
      (acc, scan) =>
        acc + (scan.scan_data?.goal_wrestling?.spatial_awareness || 83),
      0,
    ) / (scans.length || 1);

  const overallScore =
    (goalProtectionRate +
      positioningAccuracy +
      reactionTime +
      defensiveHolds +
      breakawayCoverage +
      spatialAwareness) /
    6;
  const historicalScores = scans.map((scan) => scan.ai_score || overallScore);

  return {
    overallScore,
    goalProtectionRate,
    positioningAccuracy,
    reactionTime,
    defensiveHolds,
    breakawayCoverage,
    spatialAwareness,
    historicalScores,
  };
}

function getWrestlingGrade(score) {
  if (score >= 90) return "Elite";
  if (score >= 80) return "Advanced";
  if (score >= 70) return "Intermediate";
  if (score >= 60) return "Developing";
  return "Novice";
}

function getGoalWrestlingGrade(score) {
  if (score >= 90) return "Elite Protector";
  if (score >= 80) return "Advanced Guardian";
  if (score >= 70) return "Solid Defender";
  if (score >= 60) return "Developing";
  return "Trainee";
}

// Wrestling Performance Tracking
async function getWrestlingPerformanceSignal(
  participantId,
  athleteId,
  timeFilter,
  entityType,
) {
  const scans = await getMotionScansForSport(
    athleteId,
    timeFilter,
    "wrestling",
  );
  const wrestlingMetrics = calculateWrestlingMetrics(scans);

  return {
    signalType: "WrestlingPerformance",
    value: wrestlingMetrics.overallScore,
    timestamp: new Date().toISOString(),
    metadata: {
      takedown_efficiency: wrestlingMetrics.takedownEfficiency,
      defensive_stability: wrestlingMetrics.defensiveStability,
      position_control: wrestlingMetrics.positionControl,
      endurance_index: wrestlingMetrics.enduranceIndex,
      weight_management: wrestlingMetrics.weightManagement,
      joint_stress_monitoring: wrestlingMetrics.jointStressMonitoring,
      grade: getWrestlingGrade(wrestlingMetrics.overallScore),
      trend: calculateTrend(wrestlingMetrics.historicalScores),
    },
    participantId: participantId,
    sportSpecialization: "wrestling",
  };
}

// Goal Wrestling Performance Tracking
async function getGoalWrestlingPerformanceSignal(
  participantId,
  athleteId,
  timeFilter,
  entityType,
) {
  const scans = await getMotionScansForSport(
    athleteId,
    timeFilter,
    "goal_wrestling",
  );
  const goalWrestlingMetrics = calculateGoalWrestlingMetrics(scans);

  return {
    signalType: "GoalWrestlingPerformance",
    value: goalWrestlingMetrics.overallScore,
    timestamp: new Date().toISOString(),
    metadata: {
      goal_protection_rate: goalWrestlingMetrics.goalProtectionRate,
      positioning_accuracy: goalWrestlingMetrics.positioningAccuracy,
      reaction_time: goalWrestlingMetrics.reactionTime,
      defensive_holds: goalWrestlingMetrics.defensiveHolds,
      breakaway_coverage: goalWrestlingMetrics.breakawayCoverage,
      spatial_awareness: goalWrestlingMetrics.spatialAwareness,
      grade: getGoalWrestlingGrade(goalWrestlingMetrics.overallScore),
      trend: calculateTrend(goalWrestlingMetrics.historicalScores),
    },
    participantId: participantId,
    sportSpecialization: "goal_wrestling",
  };
}
