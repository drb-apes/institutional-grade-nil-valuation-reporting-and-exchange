import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();

    if (!session?.user?.id) {
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        {
          status: 401,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    const body = await request.json();
    const { sessionCode, deviceInfo } = body;

    // Validate session code format
    if (!sessionCode || !sessionCode.match(/^SYNC-\d{4}$/)) {
      return new Response(
        JSON.stringify({
          error: "Invalid session code format",
        }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        },
      );
    }

    // In a real implementation, you would:
    // 1. Look up the session in the database
    // 2. Verify it exists and is active
    // 3. Add the device to the session
    // 4. Return session details

    // For now, we'll simulate a successful join
    const mockSessionData = {
      id: `session_${sessionCode.replace("SYNC-", "")}`,
      code: sessionCode,
      name: "Recording Session",
      quality: "1080p",
      status: "active",
      host_name: "Session Host",
      device_count: 2,
      settings: {
        sync_delay: 0,
        auto_start: true,
        record_duration: 300,
      },
    };

    const deviceData = {
      id: `device_${Date.now()}`,
      user_id: session.user.id,
      name: deviceInfo?.name || "Unknown Device",
      type: deviceInfo?.type || "mobile",
      angle: deviceInfo?.angle || "front",
      quality: deviceInfo?.quality || "1080p",
      battery: deviceInfo?.battery || 100,
      status: "connected",
      joined_at: new Date().toISOString(),
    };

    return new Response(
      JSON.stringify({
        success: true,
        session: mockSessionData,
        device: deviceData,
        message: `Successfully joined session ${sessionCode}`,
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      },
    );
  } catch (error) {
    console.error("Error joining sync session:", error);
    return new Response(
      JSON.stringify({
        error: "Failed to join sync session",
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      },
    );
  }
}
