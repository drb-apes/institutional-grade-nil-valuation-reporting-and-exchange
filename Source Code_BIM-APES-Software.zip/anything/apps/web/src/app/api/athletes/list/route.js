import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Get athletes with their latest performance data
    const athletes = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.user_type,
        up.tier_level,
        up.reputation_score,
        up.total_contributions,
        up.total_earnings,
        au.name,
        au.email,
        au.image,
        up.created_at,
        up.updated_at
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.user_type = 'athlete'
      ORDER BY up.tier_level DESC, up.reputation_score DESC, up.created_at DESC
    `;

    // Get latest motion scan data for each athlete
    const athleteIds = athletes.map((a) => a.id);

    let motionScans = [];
    if (athleteIds.length > 0) {
      motionScans = await sql`
        SELECT DISTINCT ON (athlete_id) 
          athlete_id,
          motion_type,
          ai_score,
          verification_status,
          created_at
        FROM motion_scans
        WHERE athlete_id = ANY(${athleteIds}) AND verification_status = 'verified'
        ORDER BY athlete_id, created_at DESC
      `;
    }

    // Get latest asset simulations for each athlete
    let simulations = [];
    if (athleteIds.length > 0) {
      simulations = await sql`
        SELECT DISTINCT ON (athlete_id)
          athlete_id,
          asset_value,
          roi_projection,
          risk_score,
          simulation_data,
          created_at
        FROM asset_simulations
        WHERE athlete_id = ANY(${athleteIds})
        ORDER BY athlete_id, created_at DESC
      `;
    }

    // Get contributor counts for each athlete
    let contributorCounts = [];
    if (athleteIds.length > 0) {
      contributorCounts = await sql`
        SELECT 
          athlete_profile_id as athlete_id,
          COUNT(*) as contributor_count
        FROM athlete_referrals
        WHERE athlete_profile_id = ANY(${athleteIds}) AND referral_status = 'approved'
        GROUP BY athlete_profile_id
      `;
    }

    // Combine all data
    const enrichedAthletes = athletes.map((athlete) => {
      const motionScan = motionScans.find((ms) => ms.athlete_id === athlete.id);
      const simulation = simulations.find(
        (sim) => sim.athlete_id === athlete.id,
      );
      const contributorData = contributorCounts.find(
        (cc) => cc.athlete_id === athlete.id,
      );

      // Extract sport from motion scan or simulation data
      const sport =
        motionScan?.motion_type ||
        simulation?.simulation_data?.sport_type ||
        "general";

      // Calculate biometric score from simulation data
      const biometricScore =
        simulation?.simulation_data?.overall_score ||
        Math.round(50 + athlete.tier_level * 10 + Math.random() * 20);

      // Generate position based on sport
      const getPosition = (sport) => {
        const positions = {
          wrestling: [
            "Heavyweight",
            "Light Heavyweight",
            "Middleweight",
            "Welterweight",
          ],
          american_football: [
            "QB",
            "RB",
            "WR",
            "TE",
            "OL",
            "DE",
            "LB",
            "CB",
            "S",
          ],
          basketball: ["PG", "SG", "SF", "PF", "C"],
          tennis: ["Singles", "Doubles"],
          pickleball: ["Singles", "Doubles"],
          soccer: ["GK", "DF", "MF", "FW"],
          rugby: [
            "Prop",
            "Hooker",
            "Lock",
            "Flanker",
            "Number 8",
            "Scrum-half",
            "Fly-half",
          ],
          mma: [
            "Lightweight",
            "Welterweight",
            "Middleweight",
            "Light Heavyweight",
            "Heavyweight",
          ],
          boxing: [
            "Flyweight",
            "Bantamweight",
            "Featherweight",
            "Lightweight",
            "Welterweight",
            "Middleweight",
            "Light Heavyweight",
            "Heavyweight",
          ],
          default: ["Athlete"],
        };

        const positionList =
          positions[sport.toLowerCase()] || positions.default;
        return positionList[Math.floor(Math.random() * positionList.length)];
      };

      return {
        id: athlete.id,
        name: athlete.name,
        email: athlete.email,
        image: athlete.image,
        sport: sport,
        position: getPosition(sport),
        tier_level: athlete.tier_level,
        biometric_score: biometricScore,
        reputation_score: athlete.reputation_score,
        total_contributions: athlete.total_contributions,
        total_earnings: athlete.total_earnings,
        coalition_id: `COA-${athlete.id.toString().padStart(6, "0")}`,
        ai_score: motionScan?.ai_score || null,
        asset_value: simulation?.asset_value || null,
        roi_projection: simulation?.roi_projection || null,
        risk_score: simulation?.risk_score || null,
        contributor_count: contributorData?.contributor_count || 0,
        last_scan: motionScan?.created_at || null,
        last_simulation: simulation?.created_at || null,
        verification_status: motionScan?.verification_status || "pending",
        created_at: athlete.created_at,
        updated_at: athlete.updated_at,
      };
    });

    // Add some demo combat sports athletes if the list is small
    if (enrichedAthletes.length < 5) {
      const demoCombatAthletes = [
        {
          id: 9999,
          name: "Marcus 'The Storm' Rodriguez",
          email: "marcus.rodriguez@demo.combat",
          image: null,
          sport: "mma",
          position: "Light Heavyweight",
          tier_level: 4,
          biometric_score: 89,
          reputation_score: 850,
          total_contributions: 15200.0,
          total_earnings: 48500.0,
          coalition_id: "COA-009999",
          ai_score: 87.3,
          asset_value: 127500,
          roi_projection: 28.5,
          risk_score: 15,
          contributor_count: 8,
          last_scan: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          last_simulation: new Date(
            Date.now() - 1 * 60 * 60 * 1000,
          ).toISOString(),
          verification_status: "verified",
          created_at: new Date(
            Date.now() - 30 * 24 * 60 * 60 * 1000,
          ).toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: 9998,
          name: "Sarah 'Lightning' Chen",
          email: "sarah.chen@demo.combat",
          image: null,
          sport: "boxing",
          position: "Featherweight",
          tier_level: 3,
          biometric_score: 84,
          reputation_score: 720,
          total_contributions: 12400.0,
          total_earnings: 32100.0,
          coalition_id: "COA-009998",
          ai_score: 82.1,
          asset_value: 98200,
          roi_projection: 22.8,
          risk_score: 18,
          contributor_count: 6,
          last_scan: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
          last_simulation: new Date(
            Date.now() - 2 * 60 * 60 * 1000,
          ).toISOString(),
          verification_status: "verified",
          created_at: new Date(
            Date.now() - 45 * 24 * 60 * 60 * 1000,
          ).toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: 9997,
          name: "Tommy 'Iron Fist' O'Connor",
          email: "tommy.oconnor@demo.combat",
          image: null,
          sport: "boxing",
          position: "Welterweight",
          tier_level: 2,
          biometric_score: 76,
          reputation_score: 580,
          total_contributions: 8900.0,
          total_earnings: 18750.0,
          coalition_id: "COA-009997",
          ai_score: 74.5,
          asset_value: 67800,
          roi_projection: 18.2,
          risk_score: 25,
          contributor_count: 4,
          last_scan: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
          last_simulation: new Date(
            Date.now() - 4 * 60 * 60 * 1000,
          ).toISOString(),
          verification_status: "verified",
          created_at: new Date(
            Date.now() - 60 * 24 * 60 * 60 * 1000,
          ).toISOString(),
          updated_at: new Date().toISOString(),
        },
      ];

      enrichedAthletes.push(...demoCombatAthletes);
    }

    // Filter by sport if provided
    const url = new URL(request.url);
    const sportFilter = url.searchParams.get("sport");
    const tierFilter = url.searchParams.get("tier");
    const limit = parseInt(url.searchParams.get("limit")) || 50;
    const offset = parseInt(url.searchParams.get("offset")) || 0;

    let filteredAthletes = enrichedAthletes;

    if (sportFilter && sportFilter !== "all") {
      filteredAthletes = filteredAthletes.filter(
        (a) => a.sport === sportFilter,
      );
    }

    if (tierFilter && tierFilter !== "all") {
      filteredAthletes = filteredAthletes.filter(
        (a) => a.tier_level.toString() === tierFilter,
      );
    }

    // Pagination
    const totalCount = filteredAthletes.length;
    const paginatedAthletes = filteredAthletes.slice(offset, offset + limit);

    // Generate stats
    const stats = {
      total_athletes: totalCount,
      by_sport: enrichedAthletes.reduce((acc, athlete) => {
        acc[athlete.sport] = (acc[athlete.sport] || 0) + 1;
        return acc;
      }, {}),
      by_tier: enrichedAthletes.reduce((acc, athlete) => {
        acc[`tier_${athlete.tier_level}`] =
          (acc[`tier_${athlete.tier_level}`] || 0) + 1;
        return acc;
      }, {}),
      elite_prospects: enrichedAthletes.filter((a) => a.tier_level >= 3).length,
      average_biometric:
        Math.round(
          enrichedAthletes.reduce((sum, a) => sum + a.biometric_score, 0) /
            enrichedAthletes.length,
        ) || 0,
      verified_scans: enrichedAthletes.filter(
        (a) => a.verification_status === "verified",
      ).length,
    };

    return Response.json({
      success: true,
      athletes: paginatedAthletes,
      stats,
      pagination: {
        total: totalCount,
        limit,
        offset,
        has_more: offset + limit < totalCount,
      },
    });
  } catch (error) {
    console.error("Athletes list error:", error);
    return Response.json(
      {
        error: "Failed to fetch athletes list",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
