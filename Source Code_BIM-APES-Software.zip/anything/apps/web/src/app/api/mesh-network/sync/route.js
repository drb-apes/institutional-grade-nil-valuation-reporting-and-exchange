import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { meshId, deviceId, syncData, syncType, timestamp } = body;

    if (!meshId || !deviceId || !syncData) {
      return Response.json(
        {
          error: "Missing required fields: meshId, deviceId, syncData",
        },
        { status: 400 },
      );
    }

    // Store mesh sync data
    const syncResult = await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        user_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${meshId},
        ${deviceId},
        ${session.user.id},
        ${syncType || "general"},
        ${JSON.stringify(syncData)},
        ${new Date(timestamp || Date.now())},
        NOW()
      )
      RETURNING id, created_at
    `;

    // Get all devices in the mesh for broadcasting
    const meshDevices = await sql`
      SELECT DISTINCT device_id, user_id 
      FROM mesh_sync_data 
      WHERE mesh_id = ${meshId} 
      AND created_at > NOW() - INTERVAL '1 hour'
      ORDER BY created_at DESC
    `;

    // Create sync broadcast entry for mesh network
    const broadcastData = {
      meshId,
      sourceDevice: deviceId,
      syncType,
      data: syncData,
      timestamp: timestamp || Date.now(),
      targetDevices: meshDevices.map((d) => d.device_id),
    };

    const broadcast = await sql`
      INSERT INTO mesh_broadcasts (
        mesh_id,
        source_device_id,
        broadcast_data,
        target_device_count,
        created_at
      ) VALUES (
        ${meshId},
        ${deviceId},
        ${JSON.stringify(broadcastData)},
        ${meshDevices.length},
        NOW()
      )
      RETURNING id
    `;

    return Response.json({
      success: true,
      syncId: syncResult[0].id,
      broadcastId: broadcast[0].id,
      meshDeviceCount: meshDevices.length,
      timestamp: syncResult[0].created_at,
    });
  } catch (error) {
    console.error("Mesh sync error:", error);
    return Response.json(
      {
        error: "Failed to sync mesh data",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const meshId = searchParams.get("meshId");
    const deviceId = searchParams.get("deviceId");
    const since = searchParams.get("since");

    if (!meshId) {
      return Response.json(
        { error: "meshId parameter required" },
        { status: 400 },
      );
    }

    let query = sql`
      SELECT 
        id,
        device_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      FROM mesh_sync_data 
      WHERE mesh_id = ${meshId}
    `;

    // Add time filter if provided
    if (since) {
      const sinceDate = new Date(parseInt(since));
      query = sql`
        SELECT 
          id,
          device_id,
          sync_type,
          sync_data,
          sync_timestamp,
          created_at
        FROM mesh_sync_data 
        WHERE mesh_id = ${meshId}
        AND created_at > ${sinceDate}
      `;
    }

    // Add device filter if provided
    if (deviceId) {
      if (since) {
        query = sql`
          SELECT 
            id,
            device_id,
            sync_type,
            sync_data,
            sync_timestamp,
            created_at
          FROM mesh_sync_data 
          WHERE mesh_id = ${meshId}
          AND device_id != ${deviceId}
          AND created_at > ${new Date(parseInt(since))}
        `;
      } else {
        query = sql`
          SELECT 
            id,
            device_id,
            sync_type,
            sync_data,
            sync_timestamp,
            created_at
          FROM mesh_sync_data 
          WHERE mesh_id = ${meshId}
          AND device_id != ${deviceId}
        `;
      }
    }

    const syncData = await query;

    // Get mesh network stats
    const meshStats = await sql`
      SELECT 
        COUNT(DISTINCT device_id) as device_count,
        COUNT(*) as total_syncs,
        MAX(created_at) as last_sync
      FROM mesh_sync_data 
      WHERE mesh_id = ${meshId}
      AND created_at > NOW() - INTERVAL '1 hour'
    `;

    return Response.json({
      success: true,
      meshId,
      syncData: syncData.map((item) => ({
        id: item.id,
        deviceId: item.device_id,
        syncType: item.sync_type,
        data: item.sync_data,
        timestamp: item.sync_timestamp,
        createdAt: item.created_at,
      })),
      meshStats: {
        deviceCount: parseInt(meshStats[0].device_count) || 0,
        totalSyncs: parseInt(meshStats[0].total_syncs) || 0,
        lastSync: meshStats[0].last_sync,
      },
    });
  } catch (error) {
    console.error("Mesh sync retrieval error:", error);
    return Response.json(
      {
        error: "Failed to retrieve mesh sync data",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

export async function DELETE(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const meshId = searchParams.get("meshId");
    const deviceId = searchParams.get("deviceId");

    if (!meshId || !deviceId) {
      return Response.json(
        {
          error: "meshId and deviceId parameters required",
        },
        { status: 400 },
      );
    }

    // Remove device from mesh network
    const result = await sql`
      DELETE FROM mesh_sync_data 
      WHERE mesh_id = ${meshId} 
      AND device_id = ${deviceId}
      AND user_id = ${session.user.id}
    `;

    // Clean up old broadcasts for this mesh
    await sql`
      DELETE FROM mesh_broadcasts 
      WHERE mesh_id = ${meshId} 
      AND created_at < NOW() - INTERVAL '24 hours'
    `;

    return Response.json({
      success: true,
      deletedRecords: result.length,
      message: "Device removed from mesh network",
    });
  } catch (error) {
    console.error("Mesh cleanup error:", error);
    return Response.json(
      {
        error: "Failed to remove device from mesh",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
