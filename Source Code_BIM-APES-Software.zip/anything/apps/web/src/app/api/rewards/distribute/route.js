import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { milestone_id, distribution_rules } = body;

    if (!milestone_id) {
      return Response.json({ error: "Milestone ID required" }, { status: 400 });
    }

    // Get contribution pool
    const [pool] = await sql`
      SELECT * FROM contribution_pools 
      WHERE milestone_id = ${milestone_id} AND pool_status = 'active'
    `;

    if (!pool) {
      return Response.json(
        { error: "Active contribution pool not found" },
        { status: 404 },
      );
    }

    // Get all contributions
    const contributions = await sql`
      SELECT * FROM contributions WHERE pool_id = ${pool.id}
    `;

    if (contributions.length === 0) {
      return Response.json(
        { error: "No contributions to distribute" },
        { status: 400 },
      );
    }

    // Calculate distribution (default: proportional to contribution)
    const total_amount = parseFloat(pool.total_amount);
    const rewards = [];

    for (const contribution of contributions) {
      const contribution_percentage =
        parseFloat(contribution.amount) / total_amount;
      const reward_amount = total_amount * contribution_percentage;

      rewards.push({
        recipient_id: contribution.contributor_id,
        milestone_id,
        amount: reward_amount,
        reward_type: "contribution_return",
      });
    }

    // Insert rewards
    const insertedRewards = [];
    for (const reward of rewards) {
      const [inserted] = await sql`
        INSERT INTO rewards (
          recipient_id, milestone_id, amount, reward_type
        )
        VALUES (
          ${reward.recipient_id}, ${reward.milestone_id}, 
          ${reward.amount}, ${reward.reward_type}
        )
        RETURNING *
      `;
      insertedRewards.push(inserted);
    }

    // Update pool status
    await sql`
      UPDATE contribution_pools
      SET pool_status = 'distributed',
          closed_at = CURRENT_TIMESTAMP
      WHERE id = ${pool.id}
    `;

    return Response.json({
      success: true,
      rewards: insertedRewards,
      total_distributed: total_amount,
    });
  } catch (error) {
    console.error("Distribute rewards error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
