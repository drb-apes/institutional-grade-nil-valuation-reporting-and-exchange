import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      athlete_id,
      moment_type,
      moment_intensity,
      spotlight_credits = 0,
      event_window_credits = 0,
      boost_credits = 0,
      moment_metadata,
    } = body;

    if (!athlete_id || !moment_type || !moment_metadata) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Calculate engagement spike based on moment intensity
    const engagement_spike = Math.round((moment_intensity || 0.5) * 100);

    const [scalpingMoment] = await sql`
      INSERT INTO scalping_moments (
        athlete_id, moment_type, moment_intensity,
        spotlight_credits, event_window_credits, boost_credits,
        moment_metadata, engagement_spike
      )
      VALUES (
        ${athlete_id}, ${moment_type}, ${moment_intensity || 0.5},
        ${spotlight_credits}, ${event_window_credits}, ${boost_credits},
        ${JSON.stringify(moment_metadata)}, ${engagement_spike}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      scalping_moment: scalpingMoment,
      engagement_spike,
    });
  } catch (error) {
    console.error("Capture scalping moment error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const athlete_id = searchParams.get("athlete_id");
  const moment_type = searchParams.get("moment_type");

  try {
    let moments;

    if (athlete_id && moment_type) {
      moments = await sql`
        SELECT * FROM scalping_moments 
        WHERE athlete_id = ${athlete_id} AND moment_type = ${moment_type}
        ORDER BY captured_at DESC 
        LIMIT 50
      `;
    } else if (athlete_id) {
      moments = await sql`
        SELECT * FROM scalping_moments 
        WHERE athlete_id = ${athlete_id}
        ORDER BY captured_at DESC 
        LIMIT 50
      `;
    } else {
      moments = await sql`
        SELECT * FROM scalping_moments 
        ORDER BY captured_at DESC 
        LIMIT 50
      `;
    }

    return Response.json({ moments });
  } catch (error) {
    console.error("Get scalping moments error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
