import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { meshId, deviceId, tradingParameters, athleteId } = body;

    // Validate mesh network status and get latest sync data
    const latestMeshData = await sql`
      SELECT * FROM mesh_sync_data 
      WHERE mesh_id = ${meshId} 
      AND device_id = ${deviceId}
      ORDER BY sync_timestamp DESC 
      LIMIT 1
    `;

    if (latestMeshData.length === 0) {
      return Response.json(
        { error: "No mesh sync data available for trading signals" },
        { status: 400 },
      );
    }

    const meshData = latestMeshData[0];
    const syncData = meshData.sync_data;

    // Extract real-time biometric signals from mesh data
    const biometricSignals = extractTradingSignals(syncData);

    // Get athlete's current trading profile and active positions
    const athleteProfile = await sql`
      SELECT up.*, dw.* FROM user_profiles up
      LEFT JOIN digital_wallets dw ON up.user_id = dw.user_id
      WHERE up.id = ${athleteId} AND up.user_type = 'athlete'
    `;

    if (athleteProfile.length === 0) {
      return Response.json(
        { error: "Athlete profile not found for trading" },
        { status: 404 },
      );
    }

    // Check for active contribution pools linked to this athlete
    const activePools = await sql`
      SELECT cp.*, m.title as milestone_title 
      FROM contribution_pools cp
      JOIN milestones m ON cp.milestone_id = m.id
      WHERE m.athlete_id = ${athleteId} 
      AND cp.pool_status = 'active'
      ORDER BY cp.created_at DESC
    `;

    // Generate real-time trading opportunities based on mesh signals
    const tradingOpportunities = await generateTradingOpportunities(
      biometricSignals,
      athleteProfile[0],
      activePools,
      tradingParameters,
    );

    // Check if any automated trading triggers are met
    const automatedTriggers = await checkAutomatedTriggers(
      biometricSignals,
      athleteId,
      tradingParameters,
    );

    // Get market sentiment and pricing data
    const marketData = await getMarketDataForAthlete(
      athleteId,
      biometricSignals,
    );

    // Calculate real-time asset valuations
    const assetValuations = await calculateRealTimeValuations(
      athleteId,
      biometricSignals,
      marketData,
    );

    return Response.json({
      success: true,
      mesh_sync_status: {
        mesh_id: meshId,
        device_id: deviceId,
        last_sync: meshData.sync_timestamp,
        data_quality: calculateDataQuality(syncData),
        network_status: "synchronized",
      },
      biometric_signals: biometricSignals,
      trading_opportunities: tradingOpportunities,
      automated_triggers: automatedTriggers,
      market_data: marketData,
      asset_valuations: assetValuations,
      active_pools: activePools.map((pool) => ({
        pool_id: pool.id,
        milestone: pool.milestone_title,
        current_amount: pool.total_amount,
        contributors: pool.contributor_count,
        status: pool.pool_status,
      })),
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Mesh trading signals error:", error);
    return Response.json(
      {
        error: "Failed to process mesh trading signals",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

function extractTradingSignals(syncData) {
  const signals = {
    performance_metrics: {},
    biometric_indicators: {},
    momentum_signals: {},
    risk_indicators: {},
  };

  // Extract performance metrics
  if (syncData.motion_capture) {
    const motionData = syncData.motion_capture;
    signals.performance_metrics = {
      velocity_peak: motionData.velocity_peak || 0,
      acceleration_max: motionData.acceleration_max || 0,
      power_output: motionData.power_output || 0,
      efficiency_score: motionData.efficiency_rating || 0,
      stability_index: motionData.stability_score || 0,
      consistency_rating: calculateConsistency(motionData),
      improvement_trend: calculateTrend(motionData),
    };
  }

  // Extract biometric indicators
  if (syncData.biometric_data) {
    const bioData = syncData.biometric_data;
    signals.biometric_indicators = {
      heart_rate_variability: bioData.hrv || 0,
      recovery_index: bioData.recovery_score || 0,
      fatigue_level: bioData.fatigue_indicator || 0,
      stress_index: bioData.stress_level || 0,
      readiness_score: bioData.readiness || 0,
    };
  }

  // Calculate momentum signals
  signals.momentum_signals = {
    performance_momentum: calculatePerformanceMomentum(
      signals.performance_metrics,
    ),
    recovery_momentum: calculateRecoveryMomentum(signals.biometric_indicators),
    overall_momentum: 0, // Will be calculated
  };

  signals.momentum_signals.overall_momentum =
    (signals.momentum_signals.performance_momentum +
      signals.momentum_signals.recovery_momentum) /
    2;

  // Calculate risk indicators
  signals.risk_indicators = {
    injury_risk: calculateInjuryRisk(signals),
    performance_volatility: calculateVolatility(signals.performance_metrics),
    consistency_risk: calculateConsistencyRisk(signals.performance_metrics),
    overall_risk_score: 0, // Will be calculated
  };

  signals.risk_indicators.overall_risk_score =
    (signals.risk_indicators.injury_risk +
      signals.risk_indicators.performance_volatility +
      signals.risk_indicators.consistency_risk) /
    3;

  return signals;
}

async function generateTradingOpportunities(
  biometricSignals,
  athleteProfile,
  activePools,
  tradingParams,
) {
  const opportunities = [];

  // Performance breakout opportunities
  if (biometricSignals.momentum_signals.performance_momentum > 75) {
    opportunities.push({
      type: "performance_breakout",
      confidence: 85,
      recommended_action: "buy",
      reason: "Strong performance momentum detected",
      signals: {
        momentum: biometricSignals.momentum_signals.performance_momentum,
        efficiency: biometricSignals.performance_metrics.efficiency_score,
        consistency: biometricSignals.performance_metrics.consistency_rating,
      },
      suggested_instruments: ["ProductA", "BVI_Future"],
      risk_level: "medium",
      time_horizon: "short_term",
    });
  }

  // Recovery-based trading opportunities
  if (
    biometricSignals.biometric_indicators.recovery_index > 80 &&
    biometricSignals.risk_indicators.injury_risk < 20
  ) {
    opportunities.push({
      type: "recovery_optimization",
      confidence: 78,
      recommended_action: "hold_or_accumulate",
      reason: "Excellent recovery metrics with low injury risk",
      signals: {
        recovery: biometricSignals.biometric_indicators.recovery_index,
        injury_risk: biometricSignals.risk_indicators.injury_risk,
        readiness: biometricSignals.biometric_indicators.readiness_score,
      },
      suggested_instruments: ["ProductB", "Recovery_Note"],
      risk_level: "low",
      time_horizon: "medium_term",
    });
  }

  // Milestone-based opportunities
  for (const pool of activePools) {
    if (
      pool.total_amount > 10000 &&
      biometricSignals.momentum_signals.overall_momentum > 60
    ) {
      opportunities.push({
        type: "milestone_momentum",
        confidence: 70,
        recommended_action: "contribute",
        reason: `Milestone '${pool.milestone_title}' showing strong momentum`,
        signals: {
          pool_amount: pool.total_amount,
          contributors: pool.contributor_count,
          momentum: biometricSignals.momentum_signals.overall_momentum,
        },
        pool_id: pool.id,
        suggested_contribution: Math.min(5000, pool.total_amount * 0.1),
        risk_level: "medium",
        time_horizon: "milestone_dependent",
      });
    }
  }

  // Risk management opportunities
  if (biometricSignals.risk_indicators.overall_risk_score > 70) {
    opportunities.push({
      type: "risk_hedge",
      confidence: 65,
      recommended_action: "hedge_positions",
      reason: "Elevated risk indicators suggest protective positioning",
      signals: {
        overall_risk: biometricSignals.risk_indicators.overall_risk_score,
        injury_risk: biometricSignals.risk_indicators.injury_risk,
        volatility: biometricSignals.risk_indicators.performance_volatility,
      },
      suggested_instruments: ["Tactical_Swap"],
      risk_level: "high",
      time_horizon: "immediate",
    });
  }

  return opportunities;
}

async function checkAutomatedTriggers(
  biometricSignals,
  athleteId,
  tradingParams,
) {
  const triggers = [];

  // Get user's automated trading preferences
  const automationSettings = await sql`
    SELECT wallet_settings->'automation' as automation_config
    FROM digital_wallets dw
    JOIN user_profiles up ON dw.user_id = up.user_id
    WHERE up.id = ${athleteId}
  `;

  if (
    automationSettings.length === 0 ||
    !automationSettings[0].automation_config
  ) {
    return triggers;
  }

  const config = automationSettings[0].automation_config;

  // Performance threshold triggers
  if (config.performance_triggers?.enabled) {
    const perfThreshold = config.performance_triggers.threshold || 80;
    if (
      biometricSignals.momentum_signals.performance_momentum > perfThreshold
    ) {
      triggers.push({
        type: "performance_threshold",
        triggered: true,
        threshold: perfThreshold,
        current_value: biometricSignals.momentum_signals.performance_momentum,
        action: config.performance_triggers.action || "notify",
        auto_execute: config.performance_triggers.auto_execute || false,
      });
    }
  }

  // Risk management triggers
  if (config.risk_triggers?.enabled) {
    const riskThreshold = config.risk_triggers.threshold || 75;
    if (biometricSignals.risk_indicators.overall_risk_score > riskThreshold) {
      triggers.push({
        type: "risk_threshold",
        triggered: true,
        threshold: riskThreshold,
        current_value: biometricSignals.risk_indicators.overall_risk_score,
        action: config.risk_triggers.action || "alert",
        auto_execute: config.risk_triggers.auto_execute || false,
      });
    }
  }

  return triggers;
}

async function getMarketDataForAthlete(athleteId, biometricSignals) {
  // Get recent asset simulations for trend analysis
  const recentSimulations = await sql`
    SELECT * FROM asset_simulations 
    WHERE athlete_id = ${athleteId}
    ORDER BY created_at DESC 
    LIMIT 10
  `;

  // Calculate market sentiment based on recent activity
  const marketSentiment = calculateMarketSentiment(
    recentSimulations,
    biometricSignals,
  );

  return {
    sentiment_score: marketSentiment,
    recent_valuations: recentSimulations.slice(0, 5).map((sim) => ({
      asset_value: sim.asset_value,
      roi_projection: sim.roi_projection,
      created_at: sim.created_at,
    })),
    trading_volume_trend: "increasing", // Placeholder
    market_conditions: "favorable", // Placeholder
    liquidity_index: 0.85, // Placeholder
  };
}

async function calculateRealTimeValuations(
  athleteId,
  biometricSignals,
  marketData,
) {
  // Base valuation on current biometric performance
  const baseValue = 10000; // Starting baseline

  // Performance multiplier
  const performanceMultiplier =
    1 + biometricSignals.momentum_signals.overall_momentum / 100;

  // Risk adjustment
  const riskAdjustment =
    1 - biometricSignals.risk_indicators.overall_risk_score / 200;

  // Market sentiment adjustment
  const sentimentAdjustment = 1 + marketData.sentiment_score / 100;

  const currentValuation =
    baseValue * performanceMultiplier * riskAdjustment * sentimentAdjustment;

  return {
    current_asset_value: Math.round(currentValuation * 100) / 100,
    performance_component:
      Math.round((performanceMultiplier - 1) * 100 * 100) / 100,
    risk_adjustment: Math.round((riskAdjustment - 1) * 100 * 100) / 100,
    sentiment_impact: Math.round((sentimentAdjustment - 1) * 100 * 100) / 100,
    valuation_confidence: calculateValuationConfidence(biometricSignals),
    last_updated: new Date().toISOString(),
  };
}

// Helper functions
function calculateDataQuality(syncData) {
  let qualityScore = 0;
  let totalChecks = 0;

  if (syncData.motion_capture) {
    qualityScore += syncData.motion_capture.velocity_peak ? 20 : 0;
    qualityScore += syncData.motion_capture.power_output ? 20 : 0;
    totalChecks += 2;
  }

  if (syncData.biometric_data) {
    qualityScore += syncData.biometric_data.hrv ? 20 : 0;
    qualityScore += syncData.biometric_data.recovery_score ? 20 : 0;
    totalChecks += 2;
  }

  return totalChecks > 0 ? (qualityScore / (totalChecks * 20)) * 100 : 0;
}

function calculateConsistency(motionData) {
  // Simplified consistency calculation
  return Math.random() * 30 + 70; // 70-100 range
}

function calculateTrend(motionData) {
  // Simplified trend calculation
  return Math.random() * 20 - 10; // -10 to +10 range
}

function calculatePerformanceMomentum(performanceMetrics) {
  const weights = {
    efficiency_score: 0.3,
    power_output: 0.25,
    velocity_peak: 0.2,
    consistency_rating: 0.15,
    improvement_trend: 0.1,
  };

  let momentum = 0;
  for (const [metric, weight] of Object.entries(weights)) {
    momentum += (performanceMetrics[metric] || 0) * weight;
  }

  return Math.min(100, Math.max(0, momentum));
}

function calculateRecoveryMomentum(biometricIndicators) {
  const weights = {
    recovery_index: 0.4,
    readiness_score: 0.3,
    heart_rate_variability: 0.2,
    stress_index: -0.1, // Negative weight for stress
  };

  let momentum = 0;
  for (const [metric, weight] of Object.entries(weights)) {
    momentum += (biometricIndicators[metric] || 0) * weight;
  }

  return Math.min(100, Math.max(0, momentum));
}

function calculateInjuryRisk(signals) {
  const riskFactors = [
    signals.biometric_indicators.fatigue_level || 0,
    signals.biometric_indicators.stress_index || 0,
    100 - (signals.biometric_indicators.recovery_index || 100),
    signals.performance_metrics.consistency_rating
      ? 100 - signals.performance_metrics.consistency_rating
      : 50,
  ];

  return (
    riskFactors.reduce((sum, factor) => sum + factor, 0) / riskFactors.length
  );
}

function calculateVolatility(performanceMetrics) {
  // Simplified volatility calculation based on consistency
  return 100 - (performanceMetrics.consistency_rating || 50);
}

function calculateConsistencyRisk(performanceMetrics) {
  return 100 - (performanceMetrics.consistency_rating || 50);
}

function calculateMarketSentiment(recentSimulations, biometricSignals) {
  if (recentSimulations.length === 0) return 50; // Neutral

  // Analyze trend in recent valuations
  const valuations = recentSimulations.map((sim) =>
    parseFloat(sim.asset_value),
  );
  const recentTrend =
    valuations.length > 1
      ? ((valuations[0] - valuations[valuations.length - 1]) /
          valuations[valuations.length - 1]) *
        100
      : 0;

  // Combine with current biometric momentum
  const currentMomentum =
    biometricSignals.momentum_signals.overall_momentum || 50;

  return Math.min(
    100,
    Math.max(0, 50 + recentTrend * 10 + (currentMomentum - 50) * 0.5),
  );
}

function calculateValuationConfidence(biometricSignals) {
  const dataCompleteness =
    (Object.values(biometricSignals.performance_metrics).filter((v) => v > 0)
      .length /
      7) *
    100;
  const signalStrength =
    biometricSignals.momentum_signals.overall_momentum || 0;
  const riskCertainty =
    100 - biometricSignals.risk_indicators.overall_risk_score;

  return dataCompleteness * 0.4 + signalStrength * 0.3 + riskCertainty * 0.3;
}
