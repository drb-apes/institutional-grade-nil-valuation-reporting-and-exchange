import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      meshId,
      deviceId,
      athleteId,
      triggerId,
      overrideChecks = false,
    } = body;

    // Get the trigger details and validate mesh data
    const trigger = await validateTriggerAndMeshData(
      meshId,
      deviceId,
      athleteId,
      triggerId,
    );

    if (!trigger.valid) {
      return Response.json({ error: trigger.error }, { status: 400 });
    }

    // Get real-time biometric signals from mesh
    const meshSignalsResponse = await fetch(
      `${process.env.APP_URL}/api/mesh-trading/real-time-signals`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          meshId,
          deviceId,
          athleteId,
          tradingParameters: trigger.triggerData.trading_parameters,
        }),
      },
    );

    if (!meshSignalsResponse.ok) {
      return Response.json(
        { error: "Failed to retrieve mesh trading signals" },
        { status: 500 },
      );
    }

    const meshSignals = await meshSignalsResponse.json();

    // Validate trigger conditions are still met
    if (!overrideChecks) {
      const triggerValidation = validateTriggerConditions(
        trigger.triggerData,
        meshSignals.biometric_signals,
      );

      if (!triggerValidation.valid) {
        return Response.json({
          success: false,
          reason: "Trigger conditions no longer met",
          details: triggerValidation.details,
          current_signals: meshSignals.biometric_signals,
          timestamp: new Date().toISOString(),
        });
      }
    }

    // Execute automated trades based on trigger type
    const executionResult = await executeAutomatedTrade(
      trigger.triggerData,
      meshSignals,
      session.user.id,
    );

    // Log automated execution
    await logAutomatedExecution(
      triggerId,
      athleteId,
      meshId,
      deviceId,
      executionResult,
      session.user.id,
    );

    return Response.json({
      success: true,
      execution_result: executionResult,
      trigger_details: {
        trigger_id: triggerId,
        trigger_type: trigger.triggerData.type,
        executed_at: new Date().toISOString(),
        mesh_sync_status: meshSignals.mesh_sync_status,
      },
      biometric_context: {
        signals_at_execution: meshSignals.biometric_signals,
        asset_valuation: meshSignals.asset_valuations,
        market_conditions: meshSignals.market_data,
      },
    });
  } catch (error) {
    console.error("Automated mesh trading execution error:", error);
    return Response.json(
      { error: "Failed to execute automated trade", details: error.message },
      { status: 500 },
    );
  }
}

async function validateTriggerAndMeshData(
  meshId,
  deviceId,
  athleteId,
  triggerId,
) {
  // Get latest mesh sync data
  const latestMeshData = await sql`
    SELECT * FROM mesh_sync_data 
    WHERE mesh_id = ${meshId} 
    AND device_id = ${deviceId}
    ORDER BY sync_timestamp DESC 
    LIMIT 1
  `;

  if (latestMeshData.length === 0) {
    return { valid: false, error: "No recent mesh sync data available" };
  }

  // Check mesh data freshness (within last 5 minutes)
  const dataAge =
    Date.now() - new Date(latestMeshData[0].sync_timestamp).getTime();
  if (dataAge > 5 * 60 * 1000) {
    return { valid: false, error: "Mesh data too stale for automated trading" };
  }

  // Get automation settings for athlete
  const automationSettings = await sql`
    SELECT wallet_settings->'automation' as automation_config
    FROM digital_wallets dw
    JOIN user_profiles up ON dw.user_id = up.user_id
    WHERE up.id = ${athleteId}
  `;

  if (
    automationSettings.length === 0 ||
    !automationSettings[0].automation_config
  ) {
    return { valid: false, error: "No automation settings found for athlete" };
  }

  const config = automationSettings[0].automation_config;

  // Find the specific trigger
  const triggers = [
    ...(config.performance_triggers?.enabled
      ? [
          {
            id: "performance_threshold",
            type: "performance_threshold",
            ...config.performance_triggers,
          },
        ]
      : []),
    ...(config.risk_triggers?.enabled
      ? [
          {
            id: "risk_threshold",
            type: "risk_threshold",
            ...config.risk_triggers,
          },
        ]
      : []),
    ...(config.milestone_triggers?.enabled
      ? [
          {
            id: "milestone_contribution",
            type: "milestone_contribution",
            ...config.milestone_triggers,
          },
        ]
      : []),
  ];

  const triggerData = triggers.find((t) => t.id === triggerId);
  if (!triggerData) {
    return { valid: false, error: "Trigger configuration not found" };
  }

  if (!triggerData.auto_execute) {
    return {
      valid: false,
      error: "Trigger not configured for automatic execution",
    };
  }

  return { valid: true, triggerData, meshData: latestMeshData[0] };
}

function validateTriggerConditions(triggerData, biometricSignals) {
  switch (triggerData.type) {
    case "performance_threshold":
      const perfMomentum =
        biometricSignals.momentum_signals.performance_momentum || 0;
      const perfThreshold = triggerData.threshold || 80;

      if (perfMomentum < perfThreshold) {
        return {
          valid: false,
          details: `Performance momentum ${perfMomentum} below threshold ${perfThreshold}`,
        };
      }
      break;

    case "risk_threshold":
      const riskScore =
        biometricSignals.risk_indicators.overall_risk_score || 0;
      const riskThreshold = triggerData.threshold || 75;

      if (riskScore < riskThreshold) {
        return {
          valid: false,
          details: `Risk score ${riskScore} below threshold ${riskThreshold}`,
        };
      }
      break;

    case "milestone_contribution":
      const overallMomentum =
        biometricSignals.momentum_signals.overall_momentum || 0;
      const momentumThreshold = triggerData.momentum_threshold || 60;

      if (overallMomentum < momentumThreshold) {
        return {
          valid: false,
          details: `Overall momentum ${overallMomentum} below threshold ${momentumThreshold}`,
        };
      }
      break;

    default:
      return {
        valid: false,
        details: `Unknown trigger type: ${triggerData.type}`,
      };
  }

  return { valid: true };
}

async function executeAutomatedTrade(triggerData, meshSignals, userId) {
  const executionResults = [];

  switch (triggerData.type) {
    case "performance_threshold":
      // Execute performance breakout trade
      const perfTradeResult = await executePerformanceBreakoutTrade(
        triggerData,
        meshSignals,
        userId,
      );
      executionResults.push(perfTradeResult);
      break;

    case "risk_threshold":
      // Execute risk hedge trade
      const riskTradeResult = await executeRiskHedgeTrade(
        triggerData,
        meshSignals,
        userId,
      );
      executionResults.push(riskTradeResult);
      break;

    case "milestone_contribution":
      // Execute milestone contribution
      const milestoneResult = await executeMilestoneContribution(
        triggerData,
        meshSignals,
        userId,
      );
      executionResults.push(milestoneResult);
      break;

    default:
      throw new Error(`Unsupported trigger type: ${triggerData.type}`);
  }

  return {
    trades_executed: executionResults.length,
    total_volume: executionResults.reduce(
      (sum, result) =>
        sum + (result.notional_value || result.contribution_amount || 0),
      0,
    ),
    execution_details: executionResults,
  };
}

async function executePerformanceBreakoutTrade(
  triggerData,
  meshSignals,
  userId,
) {
  const tradingParams = triggerData.trading_parameters || {};
  const notionalValue = tradingParams.position_size || 10000;

  // Get participant ID from user's institutional settings
  const participantSettings = await sql`
    SELECT wallet_settings->'participant_id' as participant_id
    FROM digital_wallets 
    WHERE user_id = ${userId}
    AND wallet_settings->>'participant_id' IS NOT NULL
    LIMIT 1
  `;

  if (participantSettings.length === 0) {
    throw new Error(
      "No institutional participant configured for automated trading",
    );
  }

  const participantId = participantSettings[0].participant_id;

  // Execute the trade using existing trade execution API
  const tradeRequest = {
    participantId: participantId,
    tradeType: "small",
    instrument: "ProductA", // Default for performance breakouts
    notionalValue: notionalValue,
    executionMode: "spot",
    biometricTriggers: {
      min_bvi:
        meshSignals.biometric_signals.performance_metrics.efficiency_score,
      min_tactical:
        meshSignals.biometric_signals.momentum_signals.performance_momentum,
    },
  };

  const tradeResponse = await fetch(
    `${process.env.APP_URL}/api/trades/execute`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tradeRequest),
    },
  );

  const tradeResult = await tradeResponse.json();

  return {
    trade_type: "performance_breakout",
    execution_status: tradeResponse.ok ? "completed" : "failed",
    trade_confirmation: tradeResult.trade_confirmation || null,
    notional_value: notionalValue,
    trigger_signals: {
      performance_momentum:
        meshSignals.biometric_signals.momentum_signals.performance_momentum,
      efficiency_score:
        meshSignals.biometric_signals.performance_metrics.efficiency_score,
    },
    error: tradeResponse.ok ? null : tradeResult.error,
  };
}

async function executeRiskHedgeTrade(triggerData, meshSignals, userId) {
  const tradingParams = triggerData.trading_parameters || {};
  const hedgeSize = tradingParams.hedge_percentage || 0.1; // 10% default hedge

  // Get current positions to calculate hedge size
  const currentPositions = await sql`
    SELECT SUM(amount) as total_exposure
    FROM treasury_transactions
    WHERE transaction_type = 'trade_execution'
    AND authorized_by = ${userId}
    AND created_at >= CURRENT_DATE - INTERVAL '30 days'
  `;

  const totalExposure = currentPositions[0]?.total_exposure || 0;
  const hedgeValue = totalExposure * hedgeSize;

  if (hedgeValue < 1000) {
    return {
      trade_type: "risk_hedge",
      execution_status: "skipped",
      reason: "Hedge value too small",
      calculated_hedge: hedgeValue,
    };
  }

  // Get participant ID
  const participantSettings = await sql`
    SELECT wallet_settings->'participant_id' as participant_id
    FROM digital_wallets 
    WHERE user_id = ${userId}
    AND wallet_settings->>'participant_id' IS NOT NULL
    LIMIT 1
  `;

  if (participantSettings.length === 0) {
    throw new Error(
      "No institutional participant configured for automated trading",
    );
  }

  const participantId = participantSettings[0].participant_id;

  // Execute hedge trade
  const tradeRequest = {
    participantId: participantId,
    tradeType: "small",
    instrument: "Tactical_Swap",
    notionalValue: hedgeValue,
    executionMode: "swap",
    riskLimits: {
      max_risk_score:
        meshSignals.biometric_signals.risk_indicators.overall_risk_score,
    },
  };

  const tradeResponse = await fetch(
    `${process.env.APP_URL}/api/trades/execute`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tradeRequest),
    },
  );

  const tradeResult = await tradeResponse.json();

  return {
    trade_type: "risk_hedge",
    execution_status: tradeResponse.ok ? "completed" : "failed",
    trade_confirmation: tradeResult.trade_confirmation || null,
    hedge_value: hedgeValue,
    total_exposure: totalExposure,
    hedge_percentage: hedgeSize * 100,
    trigger_signals: {
      risk_score:
        meshSignals.biometric_signals.risk_indicators.overall_risk_score,
      injury_risk: meshSignals.biometric_signals.risk_indicators.injury_risk,
    },
    error: tradeResponse.ok ? null : tradeResult.error,
  };
}

async function executeMilestoneContribution(triggerData, meshSignals, userId) {
  const contributionParams = triggerData.contribution_parameters || {};
  const contributionAmount = contributionParams.amount || 1000;

  // Get active pools for the athlete associated with this trigger
  const activePools = meshSignals.active_pools || [];

  if (activePools.length === 0) {
    return {
      contribution_type: "milestone_contribution",
      execution_status: "skipped",
      reason: "No active milestone pools available",
    };
  }

  // Select the pool with highest momentum potential
  const targetPool = activePools.reduce((best, current) =>
    current.current_amount > best.current_amount ? current : best,
  );

  // Create contribution record
  const contribution = await sql`
    INSERT INTO contributions (
      pool_id,
      contributor_id,
      amount,
      contribution_type,
      created_at
    ) VALUES (
      ${targetPool.pool_id},
      ${userId},
      ${contributionAmount},
      'auto_reinvest',
      CURRENT_TIMESTAMP
    ) RETURNING *
  `;

  // Update pool totals
  await sql`
    UPDATE contribution_pools 
    SET total_amount = total_amount + ${contributionAmount},
        contributor_count = contributor_count + 1
    WHERE id = ${targetPool.pool_id}
  `;

  // Update user wallet
  await sql`
    UPDATE digital_wallets 
    SET balance = balance - ${contributionAmount},
        available_balance = available_balance - ${contributionAmount}
    WHERE user_id = ${userId}
  `;

  return {
    contribution_type: "milestone_contribution",
    execution_status: "completed",
    contribution_id: contribution[0].id,
    pool_id: targetPool.pool_id,
    milestone_title: targetPool.milestone,
    contribution_amount: contributionAmount,
    trigger_signals: {
      overall_momentum:
        meshSignals.biometric_signals.momentum_signals.overall_momentum,
      performance_momentum:
        meshSignals.biometric_signals.momentum_signals.performance_momentum,
    },
  };
}

async function logAutomatedExecution(
  triggerId,
  athleteId,
  meshId,
  deviceId,
  executionResult,
  userId,
) {
  // Log to treasury transactions for audit trail
  await sql`
    INSERT INTO treasury_transactions (
      transaction_type,
      amount,
      balance_after,
      reference_id,
      reference_type,
      description,
      authorized_by
    ) VALUES (
      'automated_execution',
      ${executionResult.total_volume},
      0, -- Will be updated by actual trade execution
      ${athleteId},
      'mesh_automated_trade',
      ${`Automated execution - Trigger: ${triggerId}, Mesh: ${meshId}`},
      ${userId}
    )
  `;

  // Log mesh broadcast for network synchronization
  await sql`
    INSERT INTO mesh_broadcasts (
      mesh_id,
      source_device_id,
      broadcast_data,
      target_device_count
    ) VALUES (
      ${meshId},
      ${deviceId},
      ${JSON.stringify({
        event_type: "automated_trade_execution",
        trigger_id: triggerId,
        athlete_id: athleteId,
        execution_result: executionResult,
        timestamp: new Date().toISOString(),
      })},
      1 -- Broadcast to all devices in mesh
    )
  `;
}
