import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      athlete_id,
      contract_type,
      index_type,
      exposure_amount,
      predictable_spend,
      yield_target,
      duration_days = 90,
    } = body;

    if (
      !athlete_id ||
      !contract_type ||
      !exposure_amount ||
      !predictable_spend
    ) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [sponsorProfile] = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!sponsorProfile) {
      return Response.json(
        { error: "Sponsor profile not found" },
        { status: 404 },
      );
    }

    const expires_at = new Date();
    expires_at.setDate(expires_at.getDate() + duration_days);

    const [contract] = await sql`
      INSERT INTO sponsor_contracts (
        sponsor_id, athlete_id, contract_type, index_type,
        exposure_amount, predictable_spend, yield_target, expires_at
      )
      VALUES (
        ${sponsorProfile.id}, ${athlete_id}, ${contract_type}, ${index_type || null},
        ${exposure_amount}, ${predictable_spend}, ${JSON.stringify(yield_target)},
        ${expires_at.toISOString()}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      contract: contract,
    });
  } catch (error) {
    console.error("Create sponsor contract error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
