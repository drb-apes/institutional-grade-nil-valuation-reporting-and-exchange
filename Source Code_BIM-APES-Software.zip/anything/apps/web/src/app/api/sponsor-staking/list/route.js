import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const [sponsorProfile] = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (!sponsorProfile) {
      return Response.json(
        { error: "Sponsor profile not found" },
        { status: 404 },
      );
    }

    const contracts = await sql`
      SELECT 
        sc.*,
        up.wallet_address as athlete_wallet,
        au.name as athlete_name
      FROM sponsor_contracts sc
      JOIN user_profiles up ON up.id = sc.athlete_id
      LEFT JOIN auth_users au ON au.id = up.user_id
      WHERE sc.sponsor_id = ${sponsorProfile.id}
      ORDER BY sc.started_at DESC
    `;

    return Response.json({ contracts });
  } catch (error) {
    console.error("List sponsor contracts error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
