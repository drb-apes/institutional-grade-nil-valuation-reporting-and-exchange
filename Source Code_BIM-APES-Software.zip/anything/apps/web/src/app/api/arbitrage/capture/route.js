import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      athlete_id,
      event_type,
      current_tier,
      expected_tier,
      attention_value,
      arbitrage_metadata,
    } = body;

    if (!athlete_id || !event_type || !arbitrage_metadata) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const [arbitrageEvent] = await sql`
      INSERT INTO arbitrage_events (
        athlete_id, event_type, current_tier, expected_tier,
        attention_value, arbitrage_metadata
      )
      VALUES (
        ${athlete_id}, ${event_type}, ${current_tier || null}, ${expected_tier || null},
        ${attention_value || 0}, ${JSON.stringify(arbitrage_metadata)}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      arbitrage_event: arbitrageEvent,
    });
  } catch (error) {
    console.error("Capture arbitrage error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const athlete_id = searchParams.get("athlete_id");
  const is_resolved = searchParams.get("is_resolved");

  try {
    let query;
    const params = [];
    let paramIndex = 1;

    if (athlete_id && is_resolved !== null) {
      query = `SELECT * FROM arbitrage_events WHERE athlete_id = $${paramIndex++} AND is_resolved = $${paramIndex++} ORDER BY captured_at DESC LIMIT 50`;
      params.push(athlete_id, is_resolved === "true");
    } else if (athlete_id) {
      query = `SELECT * FROM arbitrage_events WHERE athlete_id = $${paramIndex++} ORDER BY captured_at DESC LIMIT 50`;
      params.push(athlete_id);
    } else if (is_resolved !== null) {
      query = `SELECT * FROM arbitrage_events WHERE is_resolved = $${paramIndex++} ORDER BY captured_at DESC LIMIT 50`;
      params.push(is_resolved === "true");
    } else {
      query =
        "SELECT * FROM arbitrage_events ORDER BY captured_at DESC LIMIT 50";
    }

    const events = await sql(query, params);

    return Response.json({ events });
  } catch (error) {
    console.error("Get arbitrage events error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
