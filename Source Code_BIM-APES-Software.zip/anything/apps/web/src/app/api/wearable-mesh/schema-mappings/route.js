import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sportId = searchParams.get("sport_id");
    const deviceTypeId = searchParams.get("device_type_id");

    let mappings;

    if (sportId && deviceTypeId) {
      // Get mappings for specific sport + device combination
      mappings = await sql`
        SELECT 
          id,
          sport_id,
          device_type_id,
          raw_field_name,
          bim_metric_name,
          transformation_function,
          transformation_params,
          priority,
          created_at
        FROM bim_schema_mappings
        WHERE sport_id = ${sportId}
        AND device_type_id = ${deviceTypeId}
        ORDER BY priority DESC, raw_field_name ASC
      `;
    } else if (sportId) {
      // Get all mappings for a sport
      mappings = await sql`
        SELECT 
          id,
          sport_id,
          device_type_id,
          raw_field_name,
          bim_metric_name,
          transformation_function,
          transformation_params,
          priority,
          created_at
        FROM bim_schema_mappings
        WHERE sport_id = ${sportId}
        ORDER BY device_type_id ASC, priority DESC, raw_field_name ASC
      `;
    } else if (deviceTypeId) {
      // Get all mappings for a device
      mappings = await sql`
        SELECT 
          id,
          sport_id,
          device_type_id,
          raw_field_name,
          bim_metric_name,
          transformation_function,
          transformation_params,
          priority,
          created_at
        FROM bim_schema_mappings
        WHERE device_type_id = ${deviceTypeId}
        ORDER BY sport_id ASC, priority DESC, raw_field_name ASC
      `;
    } else {
      // Get all mappings
      mappings = await sql`
        SELECT 
          id,
          sport_id,
          device_type_id,
          raw_field_name,
          bim_metric_name,
          transformation_function,
          transformation_params,
          priority,
          created_at
        FROM bim_schema_mappings
        ORDER BY sport_id ASC, device_type_id ASC, priority DESC
        LIMIT 100
      `;
    }

    return Response.json({
      success: true,
      mappings,
      count: mappings.length,
      filters: {
        sport_id: sportId,
        device_type_id: deviceTypeId,
      },
    });
  } catch (error) {
    console.error("Error fetching schema mappings:", error);
    return Response.json(
      { success: false, error: "Failed to fetch schema mappings" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      sport_id,
      device_type_id,
      raw_field_name,
      bim_metric_name,
      transformation_function,
      transformation_params,
      priority,
    } = body;

    // Validate required fields
    if (
      !sport_id ||
      !device_type_id ||
      !raw_field_name ||
      !bim_metric_name ||
      !transformation_function
    ) {
      return Response.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Validate transformation function
    const validTransformations = [
      "direct_map",
      "unit_conversion",
      "aggregation",
      "derived_calculation",
      "normalization",
    ];
    if (!validTransformations.includes(transformation_function)) {
      return Response.json(
        {
          success: false,
          error: `Invalid transformation function. Must be one of: ${validTransformations.join(", ")}`,
        },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO bim_schema_mappings (
        sport_id,
        device_type_id,
        raw_field_name,
        bim_metric_name,
        transformation_function,
        transformation_params,
        priority
      ) VALUES (
        ${sport_id},
        ${device_type_id},
        ${raw_field_name},
        ${bim_metric_name},
        ${transformation_function},
        ${transformation_params ? JSON.stringify(transformation_params) : null},
        ${priority || 1}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      mapping: result[0],
      message: "Schema mapping created successfully",
    });
  } catch (error) {
    console.error("Error creating schema mapping:", error);
    return Response.json(
      { success: false, error: "Failed to create schema mapping" },
      { status: 500 },
    );
  }
}
