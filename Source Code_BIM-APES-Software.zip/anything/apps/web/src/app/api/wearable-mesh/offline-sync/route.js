import sql from "@/app/api/utils/sql";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Offline Mesh Data Synchronization
 *
 * Handles batch uploads of data collected while offline
 * Supports conflict resolution, deduplication, and timeline reconstruction
 */

export async function POST(request) {
  try {
    // Rate limiting for batch uploads
    const ip = request.headers.get("x-forwarded-for") || "unknown";
    const rateLimit = checkRateLimit(`offline-sync-${ip}`, {
      maxRequests: 10,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      meshSessionId: { required: true, type: "string" },
      deviceUUID: { required: true, type: "string" },
      offlineDataBatch: { required: true, type: "object" },
      deviceTimestamp: { required: true, type: "number" },
      batchMetadata: { required: false, type: "object" },
    });

    const {
      meshSessionId,
      deviceUUID,
      offlineDataBatch,
      deviceTimestamp,
      batchMetadata = {},
    } = body;

    // Verify device exists
    const deviceCheck = await sql`
      SELECT * FROM wearable_devices
      WHERE device_uuid = ${deviceUUID}
    `;

    if (deviceCheck.length === 0) {
      return createSecureResponse(
        { error: "Device not found" },
        { status: 404 },
      );
    }

    // Calculate time drift
    const serverTimestamp = Date.now();
    const timeDrift = serverTimestamp - deviceTimestamp;

    // Process offline data batch
    const {
      dataPoints = [],
      sessionDuration = 0,
      offlineStartTime,
      offlineEndTime,
    } = offlineDataBatch;

    const processedResults = {
      success: 0,
      duplicates: 0,
      conflicts: 0,
      errors: 0,
      timeCorrected: 0,
    };

    const insertedIds = [];

    for (const dataPoint of dataPoints) {
      try {
        // Correct timestamp for drift
        const correctedTimestamp = dataPoint.timestamp + timeDrift;

        // Check for duplicates
        const existingData = await sql`
          SELECT id FROM wearable_data_streams
          WHERE device_uuid = ${deviceUUID}
            AND stream_type = ${dataPoint.streamType}
            AND timestamp BETWEEN 
              to_timestamp(${(correctedTimestamp - 5000) / 1000}) AND 
              to_timestamp(${(correctedTimestamp + 5000) / 1000})
          LIMIT 1
        `;

        if (existingData.length > 0) {
          processedResults.duplicates++;
          continue;
        }

        // Process data
        const processedData = processStreamData(
          dataPoint.streamType,
          dataPoint.data,
        );
        const qualityScore = calculateDataQuality(
          processedData,
          dataPoint.streamType,
        );

        // Insert data
        const result = await sql`
          INSERT INTO wearable_data_streams (
            device_uuid,
            stream_type,
            raw_data,
            processed_data,
            timestamp,
            session_id,
            data_quality_score,
            created_at
          ) VALUES (
            ${deviceUUID},
            ${dataPoint.streamType},
            ${JSON.stringify(dataPoint.data)},
            ${JSON.stringify(processedData)},
            to_timestamp(${correctedTimestamp / 1000}),
            ${meshSessionId},
            ${qualityScore},
            NOW()
          )
          RETURNING id
        `;

        insertedIds.push(result[0].id);
        processedResults.success++;

        if (Math.abs(timeDrift) > 1000) {
          processedResults.timeCorrected++;
        }
      } catch (error) {
        console.error("Data point processing error:", error);
        processedResults.errors++;
      }
    }

    // Log offline sync event
    await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        user_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${meshSessionId},
        ${deviceUUID},
        ${deviceCheck[0].owner_id},
        'offline_batch_sync',
        ${JSON.stringify({
          batch_size: dataPoints.length,
          session_duration: sessionDuration,
          offline_period: {
            start: offlineStartTime,
            end: offlineEndTime,
          },
          time_drift: timeDrift,
          results: processedResults,
          metadata: batchMetadata,
        })},
        NOW(),
        NOW()
      )
    `;

    // Reconstruct timeline
    const timeline = await reconstructTimeline(
      deviceUUID,
      meshSessionId,
      offlineStartTime,
      offlineEndTime,
    );

    return createSecureResponse({
      success: true,
      batchProcessed: {
        total: dataPoints.length,
        inserted: processedResults.success,
        duplicates: processedResults.duplicates,
        conflicts: processedResults.conflicts,
        errors: processedResults.errors,
      },
      timeDrift,
      timeCorrected: processedResults.timeCorrected,
      insertedIds,
      timeline,
    });
  } catch (error) {
    console.error("Offline sync error:", error);
    return createSecureResponse(
      { error: "Failed to sync offline data" },
      { status: 500 },
    );
  }
}

// GET: Retrieve offline sync status
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const deviceUUID = searchParams.get("deviceUUID");
    const meshSessionId = searchParams.get("meshSessionId");

    if (!deviceUUID) {
      return createSecureResponse(
        { error: "deviceUUID required" },
        { status: 400 },
      );
    }

    // Get offline sync history
    const syncHistory = await sql`
      SELECT * FROM mesh_sync_data
      WHERE device_id = ${deviceUUID}
        AND sync_type = 'offline_batch_sync'
      ORDER BY sync_timestamp DESC
      LIMIT 20
    `;

    // Calculate sync statistics
    const stats = {
      totalSyncs: syncHistory.length,
      totalDataPoints: syncHistory.reduce(
        (sum, s) => sum + (s.sync_data?.batch_size || 0),
        0,
      ),
      avgBatchSize:
        syncHistory.length > 0
          ? syncHistory.reduce(
              (sum, s) => sum + (s.sync_data?.batch_size || 0),
              0,
            ) / syncHistory.length
          : 0,
      lastSync: syncHistory[0]?.sync_timestamp || null,
    };

    return createSecureResponse({
      success: true,
      syncHistory,
      stats,
    });
  } catch (error) {
    console.error("Offline sync status error:", error);
    return createSecureResponse(
      { error: "Failed to fetch offline sync status" },
      { status: 500 },
    );
  }
}

// Utility functions
function processStreamData(streamType, rawData) {
  const processed = { ...rawData };

  switch (streamType) {
    case "heart_rate":
      processed.bpm = rawData.bpm || 0;
      processed.hrv = rawData.hrv || 0;
      processed.zone = calculateHRZone(processed.bpm);
      break;
    case "acceleration":
      processed.magnitude = Math.sqrt(
        Math.pow(rawData.x || 0, 2) +
          Math.pow(rawData.y || 0, 2) +
          Math.pow(rawData.z || 0, 2),
      );
      break;
    default:
      break;
  }

  processed.processedAt = Date.now();
  return processed;
}

function calculateDataQuality(processedData, streamType) {
  let score = 100;

  const requiredFields = {
    heart_rate: ["bpm"],
    acceleration: ["x", "y", "z"],
    gps: ["lat", "lng"],
  };

  const required = requiredFields[streamType] || [];
  const missingFields = required.filter(
    (field) => !processedData[field] && processedData[field] !== 0,
  );
  score -= missingFields.length * 20;

  if (streamType === "heart_rate") {
    if (processedData.bpm < 30 || processedData.bpm > 220) score -= 30;
  }

  return Math.max(0, Math.min(100, score)) / 100;
}

function calculateHRZone(bpm) {
  if (bpm < 100) return "recovery";
  if (bpm < 140) return "aerobic";
  if (bpm < 160) return "threshold";
  if (bpm < 180) return "vo2max";
  return "anaerobic";
}

async function reconstructTimeline(
  deviceUUID,
  meshSessionId,
  startTime,
  endTime,
) {
  try {
    // Get all data points in the offline period
    const dataPoints = await sql`
      SELECT stream_type, processed_data, timestamp
      FROM wearable_data_streams
      WHERE device_uuid = ${deviceUUID}
        AND session_id = ${meshSessionId}
        AND timestamp BETWEEN 
          to_timestamp(${startTime / 1000}) AND 
          to_timestamp(${endTime / 1000})
      ORDER BY timestamp ASC
    `;

    // Group by stream type
    const timeline = {};

    dataPoints.forEach((dp) => {
      if (!timeline[dp.stream_type]) {
        timeline[dp.stream_type] = [];
      }
      timeline[dp.stream_type].push({
        timestamp: dp.timestamp,
        data: dp.processed_data,
      });
    });

    // Calculate summary stats
    const summary = {
      duration: endTime - startTime,
      streamTypes: Object.keys(timeline),
      dataPointCount: dataPoints.length,
    };

    return {
      timeline,
      summary,
    };
  } catch (error) {
    console.error("Timeline reconstruction error:", error);
    return { timeline: {}, summary: {} };
  }
}
