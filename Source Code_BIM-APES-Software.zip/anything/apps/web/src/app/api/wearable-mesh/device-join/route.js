import sql from "@/app/api/utils/sql";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Wearable Device Mesh Join Handler
 *
 * Allows wearable devices to join an existing mesh network
 * Handles topology updates, parent selection, and routing optimization
 */

export async function POST(request) {
  try {
    // Rate limiting (more permissive for device connections)
    const ip = request.headers.get("x-forwarded-for") || "unknown";
    const rateLimit = checkRateLimit(`mesh-join-${ip}`, {
      maxRequests: 30,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      meshSessionId: { required: true, type: "string" },
      deviceUUID: { required: true, type: "string", maxLength: 255 },
      deviceTypeId: { required: true, type: "string" },
      parentDeviceUUID: { required: false, type: "string" },
      connectionStrength: { required: false, type: "number" },
      deviceCapabilities: { required: false, type: "object" },
    });

    const {
      meshSessionId,
      deviceUUID,
      deviceTypeId,
      parentDeviceUUID = null,
      connectionStrength = 100,
      deviceCapabilities = {},
    } = body;

    // Verify mesh session exists
    const sessionCheck = await sql`
      SELECT * FROM mesh_sync_data
      WHERE mesh_id = ${meshSessionId}
        AND sync_type = 'session_init'
      LIMIT 1
    `;

    if (sessionCheck.length === 0) {
      return createSecureResponse(
        { error: "Mesh session not found" },
        { status: 404 },
      );
    }

    const sessionData = sessionCheck[0].sync_data;
    const maxDevices = sessionData.max_devices || 50;

    // Check current device count
    const currentDeviceCount = await sql`
      SELECT COUNT(*) as count FROM mesh_network_topology
      WHERE mesh_session_id = ${meshSessionId}
    `;

    if (currentDeviceCount[0].count >= maxDevices) {
      return createSecureResponse(
        { error: "Mesh session at capacity" },
        { status: 429 },
      );
    }

    // Check if device already in mesh
    const existingNode = await sql`
      SELECT * FROM mesh_network_topology
      WHERE mesh_session_id = ${meshSessionId}
        AND child_device_uuid = ${deviceUUID}
    `;

    if (existingNode.length > 0) {
      // Update existing node
      await sql`
        UPDATE mesh_network_topology
        SET connection_strength = ${connectionStrength},
            last_active_at = NOW()
        WHERE mesh_session_id = ${meshSessionId}
          AND child_device_uuid = ${deviceUUID}
      `;

      return createSecureResponse({
        success: true,
        message: "Device reconnected to mesh",
        deviceUUID,
        existingNode: true,
      });
    }

    // Determine parent device and hop count
    let selectedParent = parentDeviceUUID;
    let hopCount = 1;

    if (!selectedParent) {
      // Auto-select best parent (coordinator or closest device)
      const potentialParents = await sql`
        SELECT child_device_uuid, hop_count, connection_strength
        FROM mesh_network_topology
        WHERE mesh_session_id = ${meshSessionId}
        ORDER BY hop_count ASC, connection_strength DESC
        LIMIT 1
      `;

      if (potentialParents.length > 0) {
        selectedParent = potentialParents[0].child_device_uuid;
        hopCount = potentialParents[0].hop_count + 1;
      } else {
        return createSecureResponse(
          { error: "No parent device available" },
          { status: 400 },
        );
      }
    } else {
      // Get hop count from parent
      const parentNode = await sql`
        SELECT hop_count FROM mesh_network_topology
        WHERE mesh_session_id = ${meshSessionId}
          AND child_device_uuid = ${selectedParent}
      `;

      if (parentNode.length > 0) {
        hopCount = parentNode[0].hop_count + 1;
      }
    }

    // Add device to topology
    await sql`
      INSERT INTO mesh_network_topology (
        mesh_session_id,
        parent_device_uuid,
        child_device_uuid,
        connection_strength,
        hop_count,
        last_active_at,
        created_at
      ) VALUES (
        ${meshSessionId},
        ${selectedParent},
        ${deviceUUID},
        ${connectionStrength},
        ${hopCount},
        NOW(),
        NOW()
      )
    `;

    // Log join event
    await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${meshSessionId},
        ${deviceUUID},
        'device_join',
        ${JSON.stringify({
          device_type: deviceTypeId,
          parent: selectedParent,
          hop_count: hopCount,
          capabilities: deviceCapabilities,
          joined_at: new Date().toISOString(),
        })},
        NOW(),
        NOW()
      )
    `;

    // Get updated mesh health
    const topology = await sql`
      SELECT * FROM mesh_network_topology
      WHERE mesh_session_id = ${meshSessionId}
    `;

    const meshHealth = calculateMeshHealth(topology);

    return createSecureResponse({
      success: true,
      deviceUUID,
      parentDevice: selectedParent,
      hopCount,
      meshSessionId,
      meshHealth,
      syncInterval: sessionData.metadata?.syncInterval || 2000,
      priorityMetrics: sessionData.metadata?.priorityMetrics || [],
    });
  } catch (error) {
    console.error("Device mesh join error:", error);
    return createSecureResponse(
      { error: "Failed to join mesh network" },
      { status: 500 },
    );
  }
}

// PUT: Update device connection status
export async function PUT(request) {
  try {
    const body = await validateRequestBody(request, {
      meshSessionId: { required: true, type: "string" },
      deviceUUID: { required: true, type: "string" },
      connectionStrength: { required: true, type: "number" },
    });

    const { meshSessionId, deviceUUID, connectionStrength } = body;

    // Update connection strength
    await sql`
      UPDATE mesh_network_topology
      SET connection_strength = ${connectionStrength},
          last_active_at = NOW()
      WHERE mesh_session_id = ${meshSessionId}
        AND child_device_uuid = ${deviceUUID}
    `;

    // Check if device needs to re-parent (connection too weak)
    if (connectionStrength < 30) {
      // Find better parent
      const betterParents = await sql`
        SELECT child_device_uuid, hop_count
        FROM mesh_network_topology
        WHERE mesh_session_id = ${meshSessionId}
          AND child_device_uuid != ${deviceUUID}
          AND connection_strength > 60
        ORDER BY hop_count ASC
        LIMIT 1
      `;

      if (betterParents.length > 0) {
        const newParent = betterParents[0].child_device_uuid;
        const newHopCount = betterParents[0].hop_count + 1;

        await sql`
          UPDATE mesh_network_topology
          SET parent_device_uuid = ${newParent},
              hop_count = ${newHopCount}
          WHERE mesh_session_id = ${meshSessionId}
            AND child_device_uuid = ${deviceUUID}
        `;

        return createSecureResponse({
          success: true,
          reparented: true,
          newParent,
          newHopCount,
        });
      }
    }

    return createSecureResponse({
      success: true,
      connectionStrength,
      reparented: false,
    });
  } catch (error) {
    console.error("Device connection update error:", error);
    return createSecureResponse(
      { error: "Failed to update device connection" },
      { status: 500 },
    );
  }
}

function calculateMeshHealth(topology) {
  if (topology.length === 0) {
    return { score: 0, status: "no_devices" };
  }

  const avgStrength =
    topology.reduce((sum, node) => sum + (node.connection_strength || 0), 0) /
    topology.length;
  const weakNodes = topology.filter(
    (node) => (node.connection_strength || 0) < 20,
  ).length;
  const weakNodePercentage = (weakNodes / topology.length) * 100;
  const maxHops = Math.max(...topology.map((node) => node.hop_count || 0));

  let score = 100;

  if (avgStrength < 50) score -= 30;
  else if (avgStrength < 70) score -= 15;

  if (weakNodePercentage > 20) score -= 25;
  else if (weakNodePercentage > 10) score -= 10;

  if (maxHops > 4) score -= 20;
  else if (maxHops > 3) score -= 10;

  let status = "excellent";
  if (score < 50) status = "poor";
  else if (score < 70) status = "fair";
  else if (score < 85) status = "good";

  return {
    score: Math.max(0, score),
    status,
    avgConnectionStrength: Math.round(avgStrength),
    weakNodeCount: weakNodes,
    maxHopCount: maxHops,
    totalDevices: topology.length,
  };
}
