import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Wearable Mesh Network Session Management
 *
 * Creates and manages mesh network sessions for multi-device synchronization
 * Supports: Bluetooth Low Energy mesh, NFC pairing, multi-hop topology
 * Use cases: Team training, multi-athlete monitoring, stadium-wide mesh
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Rate limiting
    const rateLimit = checkRateLimit(`mesh-session-${session.user.id}`, {
      maxRequests: 20,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      sessionName: { required: true, type: "string", maxLength: 255 },
      sessionType: { required: true, type: "string" }, // 'team_training' | 'competition' | 'research' | 'stadium'
      coordinatorDeviceUUID: { required: true, type: "string", maxLength: 255 },
      maxDevices: { required: false, type: "number" },
      sport: { required: true, type: "string", maxLength: 100 },
      meshProtocol: { required: false, type: "string" }, // 'bluetooth_mesh' | 'wifi_direct' | 'hybrid'
      encryptionEnabled: { required: false, type: "boolean" },
    });

    const {
      sessionName,
      sessionType,
      coordinatorDeviceUUID,
      maxDevices = 50,
      sport,
      meshProtocol = "bluetooth_mesh",
      encryptionEnabled = true,
    } = body;

    // Generate unique mesh session ID
    const meshSessionId = generateMeshSessionId();

    // Create mesh session metadata
    const meshSessionMetadata = {
      protocol: meshProtocol,
      encryption: encryptionEnabled,
      maxHops: 5,
      syncInterval: 2000, // ms
      compressionEnabled: true,
      priorityMetrics: getPriorityMetrics(sport),
      bandwidthOptimization: true,
    };

    // Record mesh session in mesh_sync_data
    await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        user_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${meshSessionId},
        ${coordinatorDeviceUUID},
        ${session.user.id},
        'session_init',
        ${JSON.stringify({
          session_name: sessionName,
          session_type: sessionType,
          max_devices: maxDevices,
          sport,
          metadata: meshSessionMetadata,
          status: "active",
        })},
        NOW(),
        NOW()
      )
    `;

    // Initialize mesh topology with coordinator as root
    await sql`
      INSERT INTO mesh_network_topology (
        mesh_session_id,
        parent_device_uuid,
        child_device_uuid,
        connection_strength,
        hop_count,
        last_active_at,
        created_at
      ) VALUES (
        ${meshSessionId},
        NULL,
        ${coordinatorDeviceUUID},
        100,
        0,
        NOW(),
        NOW()
      )
    `;

    return createSecureResponse({
      success: true,
      meshSessionId,
      coordinatorDevice: coordinatorDeviceUUID,
      sessionMetadata: meshSessionMetadata,
      maxDevices,
      connectionUrl: `/mesh/${meshSessionId}/join`,
      qrCodeData: generateMeshQRCode(meshSessionId, meshProtocol),
    });
  } catch (error) {
    console.error("Mesh session creation error:", error);
    return createSecureResponse(
      { error: "Failed to create mesh session" },
      { status: 500 },
    );
  }
}

// GET: Retrieve active mesh sessions
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const meshSessionId = searchParams.get("meshSessionId");

    if (meshSessionId) {
      // Get specific session details
      const sessionData = await sql`
        SELECT * FROM mesh_sync_data
        WHERE mesh_id = ${meshSessionId}
          AND sync_type = 'session_init'
        ORDER BY created_at DESC
        LIMIT 1
      `;

      if (sessionData.length === 0) {
        return createSecureResponse(
          { error: "Mesh session not found" },
          { status: 404 },
        );
      }

      // Get topology
      const topology = await sql`
        SELECT * FROM mesh_network_topology
        WHERE mesh_session_id = ${meshSessionId}
        ORDER BY hop_count ASC
      `;

      // Get connected devices count
      const connectedDevices = topology.length;

      // Get recent sync events
      const recentSyncs = await sql`
        SELECT * FROM mesh_sync_data
        WHERE mesh_id = ${meshSessionId}
        ORDER BY sync_timestamp DESC
        LIMIT 50
      `;

      return createSecureResponse({
        success: true,
        session: sessionData[0],
        topology,
        connectedDevices,
        recentSyncs,
        health: calculateMeshHealth(topology),
      });
    } else {
      // Get all user's active sessions
      const activeSessions = await sql`
        SELECT DISTINCT ON (mesh_id) *
        FROM mesh_sync_data
        WHERE user_id = ${session.user.id}
          AND sync_type = 'session_init'
        ORDER BY mesh_id, created_at DESC
      `;

      return createSecureResponse({
        success: true,
        sessions: activeSessions,
      });
    }
  } catch (error) {
    console.error("Mesh session fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch mesh session data" },
      { status: 500 },
    );
  }
}

// DELETE: Close mesh session
export async function DELETE(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const meshSessionId = searchParams.get("meshSessionId");

    if (!meshSessionId) {
      return createSecureResponse(
        { error: "meshSessionId required" },
        { status: 400 },
      );
    }

    // Mark session as closed
    await sql`
      INSERT INTO mesh_sync_data (
        mesh_id,
        device_id,
        user_id,
        sync_type,
        sync_data,
        sync_timestamp,
        created_at
      ) VALUES (
        ${meshSessionId},
        'coordinator',
        ${session.user.id},
        'session_close',
        ${JSON.stringify({
          status: "closed",
          closed_at: new Date().toISOString(),
        })},
        NOW(),
        NOW()
      )
    `;

    return createSecureResponse({
      success: true,
      message: "Mesh session closed",
    });
  } catch (error) {
    console.error("Mesh session close error:", error);
    return createSecureResponse(
      { error: "Failed to close mesh session" },
      { status: 500 },
    );
  }
}

// Utility functions
function generateMeshSessionId() {
  return `mesh_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

function getPriorityMetrics(sport) {
  const sportMetrics = {
    wrestling: ["heart_rate", "acceleration", "contact_force", "position"],
    basketball: ["heart_rate", "speed", "jump_height", "distance"],
    soccer: ["heart_rate", "speed", "distance", "sprint_count"],
    football: ["heart_rate", "impact_force", "acceleration", "position"],
    tennis: ["heart_rate", "movement_speed", "reaction_time", "stroke_count"],
    running: ["heart_rate", "pace", "cadence", "vo2max"],
    cycling: ["heart_rate", "power_output", "cadence", "speed"],
    swimming: ["heart_rate", "stroke_rate", "distance", "turn_time"],
  };

  return (
    sportMetrics[sport.toLowerCase()] || [
      "heart_rate",
      "speed",
      "distance",
      "time",
    ]
  );
}

function generateMeshQRCode(meshSessionId, protocol) {
  // Generate QR code data for easy device pairing
  return JSON.stringify({
    type: "mesh_join",
    session_id: meshSessionId,
    protocol,
    version: "1.0",
    timestamp: Date.now(),
  });
}

function calculateMeshHealth(topology) {
  if (topology.length === 0) {
    return { score: 0, status: "no_devices" };
  }

  // Calculate average connection strength
  const avgStrength =
    topology.reduce((sum, node) => sum + (node.connection_strength || 0), 0) /
    topology.length;

  // Check for disconnected nodes (connection strength < 20)
  const weakNodes = topology.filter(
    (node) => (node.connection_strength || 0) < 20,
  ).length;
  const weakNodePercentage = (weakNodes / topology.length) * 100;

  // Calculate max hop count
  const maxHops = Math.max(...topology.map((node) => node.hop_count || 0));

  let score = 100;

  // Penalties
  if (avgStrength < 50) score -= 30;
  else if (avgStrength < 70) score -= 15;

  if (weakNodePercentage > 20) score -= 25;
  else if (weakNodePercentage > 10) score -= 10;

  if (maxHops > 4) score -= 20;
  else if (maxHops > 3) score -= 10;

  let status = "excellent";
  if (score < 50) status = "poor";
  else if (score < 70) status = "fair";
  else if (score < 85) status = "good";

  return {
    score: Math.max(0, score),
    status,
    avgConnectionStrength: Math.round(avgStrength),
    weakNodeCount: weakNodes,
    maxHopCount: maxHops,
    totalDevices: topology.length,
  };
}
