import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const deviceTypes = await sql`
      SELECT 
        id,
        device_type_id,
        manufacturer,
        device_model,
        device_category,
        connection_protocol,
        sampling_rate_hz,
        battery_life_hours,
        supported_sports,
        certification_status,
        sdk_version,
        created_at
      FROM wearable_device_types
      WHERE certification_status = 'certified'
      ORDER BY manufacturer ASC, device_model ASC
    `;

    return Response.json({
      success: true,
      deviceTypes,
      count: deviceTypes.length,
    });
  } catch (error) {
    console.error("Error fetching device types:", error);
    return Response.json(
      { success: false, error: "Failed to fetch device types" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      device_type_id,
      manufacturer,
      device_model,
      device_category,
      connection_protocol,
      data_schema,
      sampling_rate_hz,
      battery_life_hours,
      supported_sports,
      sdk_version,
    } = body;

    // Validate required fields
    if (
      !device_type_id ||
      !manufacturer ||
      !device_model ||
      !device_category ||
      !connection_protocol ||
      !data_schema
    ) {
      return Response.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO wearable_device_types (
        device_type_id,
        manufacturer,
        device_model,
        device_category,
        connection_protocol,
        data_schema,
        sampling_rate_hz,
        battery_life_hours,
        supported_sports,
        certification_status,
        sdk_version
      ) VALUES (
        ${device_type_id},
        ${manufacturer},
        ${device_model},
        ${device_category},
        ${connection_protocol},
        ${JSON.stringify(data_schema)},
        ${sampling_rate_hz || null},
        ${battery_life_hours || null},
        ${supported_sports || []},
        'pending',
        ${sdk_version || null}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      deviceType: result[0],
      message: "Device type registered successfully (pending certification)",
    });
  } catch (error) {
    console.error("Error registering device type:", error);
    return Response.json(
      { success: false, error: "Failed to register device type" },
      { status: 500 },
    );
  }
}
