import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get("session_id");
    const activeOnly = searchParams.get("active_only") === "true";

    let topology;

    if (sessionId) {
      // Get topology for specific session
      topology = await sql`
        SELECT 
          mnt.id,
          mnt.mesh_session_id,
          mnt.parent_device_uuid,
          mnt.child_device_uuid,
          mnt.connection_strength,
          mnt.hop_count,
          mnt.last_active_at,
          mnt.created_at,
          pd.device_nickname as parent_nickname,
          pd.battery_level as parent_battery,
          cd.device_nickname as child_nickname,
          cd.battery_level as child_battery
        FROM mesh_network_topology mnt
        LEFT JOIN wearable_devices pd ON mnt.parent_device_uuid = pd.device_uuid
        LEFT JOIN wearable_devices cd ON mnt.child_device_uuid = cd.device_uuid
        WHERE mnt.mesh_session_id = ${sessionId}
        ORDER BY mnt.hop_count ASC, mnt.last_active_at DESC
      `;
    } else if (activeOnly) {
      // Get only active sessions (active in last 5 minutes)
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();

      topology = await sql`
        SELECT 
          mnt.id,
          mnt.mesh_session_id,
          mnt.parent_device_uuid,
          mnt.child_device_uuid,
          mnt.connection_strength,
          mnt.hop_count,
          mnt.last_active_at,
          mnt.created_at,
          pd.device_nickname as parent_nickname,
          pd.battery_level as parent_battery,
          cd.device_nickname as child_nickname,
          cd.battery_level as child_battery
        FROM mesh_network_topology mnt
        LEFT JOIN wearable_devices pd ON mnt.parent_device_uuid = pd.device_uuid
        LEFT JOIN wearable_devices cd ON mnt.child_device_uuid = cd.device_uuid
        WHERE mnt.last_active_at > ${fiveMinutesAgo}
        ORDER BY mnt.mesh_session_id DESC, mnt.hop_count ASC
        LIMIT 100
      `;
    } else {
      // Get recent topology (last 24 hours)
      const oneDayAgo = new Date(
        Date.now() - 24 * 60 * 60 * 1000,
      ).toISOString();

      topology = await sql`
        SELECT 
          mnt.id,
          mnt.mesh_session_id,
          mnt.parent_device_uuid,
          mnt.child_device_uuid,
          mnt.connection_strength,
          mnt.hop_count,
          mnt.last_active_at,
          mnt.created_at,
          pd.device_nickname as parent_nickname,
          pd.battery_level as parent_battery,
          cd.device_nickname as child_nickname,
          cd.battery_level as child_battery
        FROM mesh_network_topology mnt
        LEFT JOIN wearable_devices pd ON mnt.parent_device_uuid = pd.device_uuid
        LEFT JOIN wearable_devices cd ON mnt.child_device_uuid = cd.device_uuid
        WHERE mnt.created_at > ${oneDayAgo}
        ORDER BY mnt.mesh_session_id DESC, mnt.hop_count ASC
        LIMIT 100
      `;
    }

    // Group by session for better organization
    const sessionMap = {};
    topology.forEach((row) => {
      if (!sessionMap[row.mesh_session_id]) {
        sessionMap[row.mesh_session_id] = {
          session_id: row.mesh_session_id,
          connections: [],
          last_active: row.last_active_at,
        };
      }
      sessionMap[row.mesh_session_id].connections.push(row);

      // Update last_active to most recent
      if (
        new Date(row.last_active_at) >
        new Date(sessionMap[row.mesh_session_id].last_active)
      ) {
        sessionMap[row.mesh_session_id].last_active = row.last_active_at;
      }
    });

    const sessions = Object.values(sessionMap);

    return Response.json({
      success: true,
      topology,
      sessions,
      session_count: sessions.length,
      connection_count: topology.length,
      filters: {
        session_id: sessionId,
        active_only: activeOnly,
      },
    });
  } catch (error) {
    console.error("Error fetching mesh topology:", error);
    return Response.json(
      { success: false, error: "Failed to fetch mesh topology" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      mesh_session_id,
      parent_device_uuid,
      child_device_uuid,
      connection_strength,
      hop_count,
    } = body;

    // Validate required fields
    if (!mesh_session_id) {
      return Response.json(
        { success: false, error: "mesh_session_id is required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO mesh_network_topology (
        mesh_session_id,
        parent_device_uuid,
        child_device_uuid,
        connection_strength,
        hop_count,
        last_active_at
      ) VALUES (
        ${mesh_session_id},
        ${parent_device_uuid || null},
        ${child_device_uuid || null},
        ${connection_strength || null},
        ${hop_count || 1},
        CURRENT_TIMESTAMP
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      topology: result[0],
      message: "Mesh topology entry created successfully",
    });
  } catch (error) {
    console.error("Error creating mesh topology entry:", error);
    return Response.json(
      { success: false, error: "Failed to create mesh topology entry" },
      { status: 500 },
    );
  }
}
