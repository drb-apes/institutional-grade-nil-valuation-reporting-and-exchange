import sql from "@/app/api/utils/sql";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Wearable Mesh Data Stream Synchronization
 *
 * Handles real-time biometric data streaming from mesh-connected devices
 * Supports: Batch uploads, compression, priority routing, offline queuing
 */

export async function POST(request) {
  try {
    // High throughput rate limiting
    const ip = request.headers.get("x-forwarded-for") || "unknown";
    const rateLimit = checkRateLimit(`mesh-stream-${ip}`, {
      maxRequests: 100,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      meshSessionId: { required: true, type: "string" },
      deviceUUID: { required: true, type: "string" },
      streamType: { required: true, type: "string" },
      dataPoints: { required: true, type: "object" },
      timestamp: { required: false, type: "number" },
      compressed: { required: false, type: "boolean" },
    });

    const {
      meshSessionId,
      deviceUUID,
      streamType,
      dataPoints,
      timestamp = Date.now(),
      compressed = false,
    } = body;

    // Verify device is in mesh
    const deviceCheck = await sql`
      SELECT * FROM mesh_network_topology
      WHERE mesh_session_id = ${meshSessionId}
        AND child_device_uuid = ${deviceUUID}
    `;

    if (deviceCheck.length === 0) {
      return createSecureResponse(
        { error: "Device not in mesh network" },
        { status: 403 },
      );
    }

    // Process data based on stream type
    const processedData = processStreamData(streamType, dataPoints, compressed);

    // Calculate data quality score
    const qualityScore = calculateDataQuality(processedData, streamType);

    // Store in wearable_data_streams
    const streamResult = await sql`
      INSERT INTO wearable_data_streams (
        device_uuid,
        stream_type,
        raw_data,
        processed_data,
        timestamp,
        session_id,
        data_quality_score,
        created_at
      ) VALUES (
        ${deviceUUID},
        ${streamType},
        ${JSON.stringify(dataPoints)},
        ${JSON.stringify(processedData)},
        to_timestamp(${timestamp / 1000}),
        ${meshSessionId},
        ${qualityScore},
        NOW()
      )
      RETURNING *
    `;

    // Check if this should trigger a mesh broadcast
    const shouldBroadcast = checkBroadcastTrigger(processedData, streamType);

    if (shouldBroadcast) {
      await broadcastToMesh(meshSessionId, deviceUUID, processedData);
    }

    // Update device last active
    await sql`
      UPDATE mesh_network_topology
      SET last_active_at = NOW()
      WHERE mesh_session_id = ${meshSessionId}
        AND child_device_uuid = ${deviceUUID}
    `;

    return createSecureResponse({
      success: true,
      streamId: streamResult[0].id,
      dataQuality: qualityScore,
      broadcasted: shouldBroadcast,
      timestamp: streamResult[0].timestamp,
    });
  } catch (error) {
    console.error("Mesh stream sync error:", error);
    return createSecureResponse(
      { error: "Failed to sync stream data" },
      { status: 500 },
    );
  }
}

// GET: Retrieve mesh stream data
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const meshSessionId = searchParams.get("meshSessionId");
    const deviceUUID = searchParams.get("deviceUUID");
    const streamType = searchParams.get("streamType");
    const since = searchParams.get("since"); // timestamp
    const limit = parseInt(searchParams.get("limit") || "100");

    if (!meshSessionId) {
      return createSecureResponse(
        { error: "meshSessionId required" },
        { status: 400 },
      );
    }

    // Build query
    let query = sql`
      SELECT wds.*
      FROM wearable_data_streams wds
      JOIN mesh_network_topology mnt ON wds.device_uuid = mnt.child_device_uuid
      WHERE mnt.mesh_session_id = ${meshSessionId}
    `;

    if (deviceUUID) {
      query = sql`${query} AND wds.device_uuid = ${deviceUUID}`;
    }

    if (streamType) {
      query = sql`${query} AND wds.stream_type = ${streamType}`;
    }

    if (since) {
      query = sql`${query} AND wds.timestamp > to_timestamp(${parseInt(since) / 1000})`;
    }

    query = sql`${query} ORDER BY wds.timestamp DESC LIMIT ${limit}`;

    const streams = await query;

    // Aggregate statistics
    const stats = calculateStreamStats(streams);

    return createSecureResponse({
      success: true,
      streams,
      stats,
      count: streams.length,
    });
  } catch (error) {
    console.error("Mesh stream fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch stream data" },
      { status: 500 },
    );
  }
}

// Process stream data based on type
function processStreamData(streamType, rawData, compressed) {
  if (compressed) {
    // In production, decompress here
    // For now, assume rawData is already decompressed
  }

  const processed = { ...rawData };

  // Type-specific processing
  switch (streamType) {
    case "heart_rate":
      processed.bpm = rawData.bpm || 0;
      processed.hrv = rawData.hrv || 0;
      processed.zone = calculateHRZone(processed.bpm);
      break;

    case "acceleration":
      processed.magnitude = Math.sqrt(
        Math.pow(rawData.x || 0, 2) +
          Math.pow(rawData.y || 0, 2) +
          Math.pow(rawData.z || 0, 2),
      );
      processed.impact = classifyImpact(processed.magnitude);
      break;

    case "gps":
      processed.lat = rawData.lat || 0;
      processed.lng = rawData.lng || 0;
      processed.accuracy = rawData.accuracy || 0;
      if (rawData.prevLat && rawData.prevLng) {
        processed.speed = calculateSpeed(
          rawData.prevLat,
          rawData.prevLng,
          processed.lat,
          processed.lng,
          rawData.timeDelta || 1000,
        );
      }
      break;

    case "force":
      processed.newton = rawData.newton || 0;
      processed.duration = rawData.duration || 0;
      processed.type = rawData.type || "contact";
      break;

    case "motion":
      processed.gyro = rawData.gyro || { x: 0, y: 0, z: 0 };
      processed.orientation = rawData.orientation || 0;
      processed.activityType = classifyActivity(rawData);
      break;

    default:
      // Pass through
      break;
  }

  processed.processedAt = Date.now();
  return processed;
}

// Calculate data quality score
function calculateDataQuality(processedData, streamType) {
  let score = 100;

  // Check for missing required fields
  const requiredFields = {
    heart_rate: ["bpm"],
    acceleration: ["x", "y", "z"],
    gps: ["lat", "lng"],
    force: ["newton"],
    motion: ["gyro"],
  };

  const required = requiredFields[streamType] || [];
  const missingFields = required.filter(
    (field) => !processedData[field] && processedData[field] !== 0,
  );
  score -= missingFields.length * 20;

  // Check for anomalies
  if (streamType === "heart_rate") {
    if (processedData.bpm < 30 || processedData.bpm > 220) score -= 30;
    else if (processedData.bpm < 40 || processedData.bpm > 200) score -= 15;
  }

  if (streamType === "gps") {
    if (processedData.accuracy && processedData.accuracy > 50) score -= 20;
    else if (processedData.accuracy && processedData.accuracy > 20) score -= 10;
  }

  return Math.max(0, Math.min(100, score)) / 100;
}

// Check if data should trigger mesh broadcast
function checkBroadcastTrigger(processedData, streamType) {
  // Broadcast triggers for critical events
  if (streamType === "heart_rate" && processedData.bpm > 180) return true;
  if (streamType === "acceleration" && processedData.magnitude > 50)
    return true;
  if (streamType === "force" && processedData.newton > 1000) return true;

  return false;
}

// Broadcast to mesh network
async function broadcastToMesh(meshSessionId, sourceDeviceUUID, data) {
  try {
    // Get all devices in mesh
    const devices = await sql`
      SELECT child_device_uuid
      FROM mesh_network_topology
      WHERE mesh_session_id = ${meshSessionId}
        AND child_device_uuid != ${sourceDeviceUUID}
    `;

    // Record broadcast
    await sql`
      INSERT INTO mesh_broadcasts (
        mesh_id,
        source_device_id,
        broadcast_data,
        target_device_count,
        created_at
      ) VALUES (
        ${meshSessionId},
        ${sourceDeviceUUID},
        ${JSON.stringify(data)},
        ${devices.length},
        NOW()
      )
    `;
  } catch (error) {
    console.error("Mesh broadcast error:", error);
  }
}

// Utility functions
function calculateHRZone(bpm) {
  if (bpm < 100) return "recovery";
  if (bpm < 140) return "aerobic";
  if (bpm < 160) return "threshold";
  if (bpm < 180) return "vo2max";
  return "anaerobic";
}

function classifyImpact(magnitude) {
  if (magnitude < 2) return "light";
  if (magnitude < 5) return "moderate";
  if (magnitude < 10) return "heavy";
  return "severe";
}

function calculateSpeed(lat1, lng1, lat2, lng2, timeDelta) {
  // Haversine formula for distance
  const R = 6371e3; // Earth radius in meters
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // meters
  const timeSeconds = timeDelta / 1000;
  return distance / timeSeconds; // m/s
}

function classifyActivity(rawData) {
  const { gyro, acceleration } = rawData;

  if (!gyro || !acceleration) return "unknown";

  const gyroMag = Math.sqrt(gyro.x ** 2 + gyro.y ** 2 + gyro.z ** 2);
  const accelMag = Math.sqrt(
    acceleration.x ** 2 + acceleration.y ** 2 + acceleration.z ** 2,
  );

  if (accelMag < 1 && gyroMag < 1) return "stationary";
  if (accelMag < 3 && gyroMag < 2) return "walking";
  if (accelMag < 6 && gyroMag < 4) return "running";
  return "sprinting";
}

function calculateStreamStats(streams) {
  if (streams.length === 0) {
    return {
      avgQuality: 0,
      totalDataPoints: 0,
      streamTypes: [],
      deviceCount: 0,
    };
  }

  const avgQuality =
    streams.reduce((sum, s) => sum + (s.data_quality_score || 0), 0) /
    streams.length;
  const streamTypes = [...new Set(streams.map((s) => s.stream_type))];
  const deviceCount = [...new Set(streams.map((s) => s.device_uuid))].length;

  return {
    avgQuality: Math.round(avgQuality * 100) / 100,
    totalDataPoints: streams.length,
    streamTypes,
    deviceCount,
    timeRange: {
      start: streams[streams.length - 1]?.timestamp,
      end: streams[0]?.timestamp,
    },
  };
}
