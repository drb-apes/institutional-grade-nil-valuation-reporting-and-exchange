import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Pricing API
 * POST /pricing/domain-pack
 *
 * Return Domain Pack Index values for pricing logic
 *
 * Domain Pack Index modifies pricing based on:
 * - Brand Fit (increases license)
 * - Audience Overlap (increases NIL throughput weight)
 * - Market Penetration (increases NIL multiplier)
 * - Risk Profile (decreases license)
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      orgId,
      industry,
      subType,
      targetAudience = [],
      brandValues = [],
      geographicReach = "national",
    } = body;

    // --- VALIDATION ---
    if (!orgId || !industry) {
      return Response.json(
        {
          error: "Missing required fields: orgId, industry",
        },
        { status: 400 },
      );
    }

    // --- BRAND FIT CALCULATION ---
    const brandFit = calculateBrandFit({
      industry,
      subType,
      brandValues,
    });

    // --- AUDIENCE OVERLAP CALCULATION ---
    const audienceOverlap = calculateAudienceOverlap({
      industry,
      subType,
      targetAudience,
    });

    // --- MARKET PENETRATION CALCULATION ---
    const marketPenetration = calculateMarketPenetration({
      industry,
      subType,
      geographicReach,
    });

    // --- RISK PROFILE CALCULATION ---
    const riskProfile = calculateRiskProfile({
      industry,
      subType,
    });

    // --- DOMAIN PACK INDEX ---
    const domainPackIndex = {
      brandFit: Math.round(brandFit * 100) / 100,
      audienceOverlap: Math.round(audienceOverlap * 100) / 100,
      marketPenetration: Math.round(marketPenetration * 100) / 100,
      riskProfile: Math.round(riskProfile * 100) / 100,
    };

    // --- OVERALL DOMAIN PACK SCORE ---
    const overallScore =
      brandFit * 0.3 +
      audienceOverlap * 0.3 +
      marketPenetration * 0.2 +
      (1 - riskProfile) * 0.2; // Invert risk for overall score

    // --- RECOMMENDATIONS ---
    const recommendations = generateDomainPackRecommendations({
      brandFit,
      audienceOverlap,
      marketPenetration,
      riskProfile,
    });

    return Response.json({
      success: true,
      orgId,
      domainPackIndex,
      overallScore: Math.round(overallScore * 100) / 100,
      scoreInterpretation: interpretScore(overallScore),
      recommendations,
      metadata: {
        industry,
        subType,
        calculatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Domain Pack calculation error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- BRAND FIT CALCULATION ---
function calculateBrandFit({ industry, subType, brandValues }) {
  let score = 0.5; // Base score

  // Industry alignment
  const industryAlignmentScores = {
    music: 0.85,
    film: 0.9,
    modeling: 0.75,
    cheer_dance: 0.7,
    pageantry: 0.65,
    sports: 0.95,
  };

  score = industryAlignmentScores[industry?.toLowerCase()] || 0.5;

  // SubType premium
  const premiumSubTypes = [
    "major_label",
    "major_studio",
    "major_agency",
    "professional_team",
  ];
  if (premiumSubTypes.includes(subType?.toLowerCase())) {
    score += 0.1;
  }

  // Brand values alignment
  if (brandValues && brandValues.length > 0) {
    const valuableValues = [
      "performance",
      "innovation",
      "authenticity",
      "diversity",
    ];
    const matchCount = brandValues.filter((v) =>
      valuableValues.includes(v.toLowerCase()),
    ).length;
    score += (matchCount / valuableValues.length) * 0.05;
  }

  return Math.min(1.0, score);
}

// --- AUDIENCE OVERLAP CALCULATION ---
function calculateAudienceOverlap({ industry, subType, targetAudience }) {
  let score = 0.6; // Base score

  // Industry-specific audience strengths
  const industryAudienceScores = {
    music: 0.88,
    film: 0.85,
    modeling: 0.72,
    cheer_dance: 0.68,
    pageantry: 0.65,
    sports: 0.92,
  };

  score = industryAudienceScores[industry?.toLowerCase()] || 0.6;

  // Target audience breadth
  if (targetAudience && targetAudience.length > 0) {
    const broadAudiences = [
      "18-34",
      "18-49",
      "millennial",
      "gen_z",
      "sports_fans",
      "music_fans",
    ];
    const matchCount = targetAudience.filter((a) =>
      broadAudiences.includes(a.toLowerCase()),
    ).length;
    score += (matchCount / 3) * 0.08; // Bonus for broad reach
  }

  return Math.min(1.0, score);
}

// --- MARKET PENETRATION CALCULATION ---
function calculateMarketPenetration({ industry, subType, geographicReach }) {
  let score = 0.5; // Base score

  // Geographic reach multiplier
  const reachMultipliers = {
    local: 0.3,
    regional: 0.5,
    national: 0.7,
    international: 0.85,
    global: 1.0,
  };

  score = reachMultipliers[geographicReach?.toLowerCase()] || 0.5;

  // Industry market size
  const largeMarkets = ["music", "film", "sports"];
  if (largeMarkets.includes(industry?.toLowerCase())) {
    score += 0.15;
  }

  // SubType scale
  const scaledSubTypes = [
    "major_label",
    "major_studio",
    "major_agency",
    "national_organization",
  ];
  if (scaledSubTypes.includes(subType?.toLowerCase())) {
    score += 0.1;
  }

  return Math.min(1.0, score);
}

// --- RISK PROFILE CALCULATION ---
function calculateRiskProfile({ industry, subType }) {
  let risk = 0.3; // Base risk (30%)

  // Industry volatility
  const volatileIndustries = ["music", "modeling"];
  if (volatileIndustries.includes(industry?.toLowerCase())) {
    risk += 0.1;
  }

  const stableIndustries = ["sports", "film"];
  if (stableIndustries.includes(industry?.toLowerCase())) {
    risk -= 0.05;
  }

  // SubType stability
  const stableSubTypes = ["major_label", "major_studio", "professional_team"];
  if (stableSubTypes.includes(subType?.toLowerCase())) {
    risk -= 0.1;
  }

  const volatileSubTypes = ["independent_label", "boutique_agency"];
  if (volatileSubTypes.includes(subType?.toLowerCase())) {
    risk += 0.08;
  }

  return Math.max(0, Math.min(1.0, risk));
}

// --- SCORE INTERPRETATION ---
function interpretScore(score) {
  if (score >= 0.85) return "Excellent - Premium pricing justified";
  if (score >= 0.7) return "Strong - Above-market pricing supported";
  if (score >= 0.55) return "Good - Market-rate pricing appropriate";
  if (score >= 0.4) return "Fair - Conservative pricing recommended";
  return "Developing - Entry-level pricing suggested";
}

// --- RECOMMENDATIONS ---
function generateDomainPackRecommendations({
  brandFit,
  audienceOverlap,
  marketPenetration,
  riskProfile,
}) {
  const recommendations = [];

  if (brandFit < 0.6) {
    recommendations.push({
      area: "Brand Fit",
      message: "Strengthen brand alignment to justify premium pricing",
      actions: [
        "Clarify brand values",
        "Target aligned talent segments",
        "Build case studies",
      ],
    });
  }

  if (audienceOverlap < 0.6) {
    recommendations.push({
      area: "Audience Overlap",
      message: "Expand target audience reach",
      actions: [
        "Broaden demographic targeting",
        "Increase social media presence",
        "Partner with high-reach talent",
      ],
    });
  }

  if (marketPenetration < 0.5) {
    recommendations.push({
      area: "Market Penetration",
      message: "Scale operations to unlock higher pricing tiers",
      actions: [
        "Expand geographic reach",
        "Increase talent volume",
        "Build distribution partnerships",
      ],
    });
  }

  if (riskProfile > 0.4) {
    recommendations.push({
      area: "Risk Profile",
      message: "High volatility may limit pricing power",
      actions: [
        "Diversify talent portfolio",
        "Implement risk management",
        "Build financial reserves",
      ],
    });
  }

  return recommendations;
}
