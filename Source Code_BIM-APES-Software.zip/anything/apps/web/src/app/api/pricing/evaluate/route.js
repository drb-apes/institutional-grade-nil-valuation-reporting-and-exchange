import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Pricing API
 * POST /pricing/evaluate
 *
 * Calculate recommended license fee based on:
 * - Organization valuation
 * - NIL throughput
 * - Performance complexity
 * - Domain Pack Index
 *
 * Multi-tenant, deterministic, valuation-anchored
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      orgId,
      industry,
      subType,
      valuation,
      annualRevenue,
      nilThroughput,
      performanceComplexity = 0.5,
      domainPackIndex = {},
    } = body;

    // --- VALIDATION ---
    if (!orgId || !industry || !valuation) {
      return Response.json(
        {
          error: "Missing required fields: orgId, industry, valuation",
        },
        { status: 400 },
      );
    }

    // --- PRICING ENGINE WEIGHTS ---
    const alpha = 0.0015; // Valuation multiplier
    const beta = 0.005; // NIL throughput multiplier
    const gamma = 0.25; // Performance complexity multiplier

    // --- BASE LICENSE CALCULATION ---
    const valuationComponent = (valuation || 0) * alpha;
    const nilComponent = (nilThroughput || 0) * beta;
    const complexityComponent = (performanceComplexity || 0) * gamma * 1000000; // Scale to meaningful value

    let baseLicense = valuationComponent + nilComponent + complexityComponent;

    // --- DOMAIN PACK INDEX ADJUSTMENT ---
    const {
      brandFit = 0,
      audienceOverlap = 0,
      marketPenetration = 0,
      riskProfile = 0,
    } = domainPackIndex;

    // Brand fit boost
    const brandFitBoost = brandFit * 0.1;
    const brandFitAdjustment = baseLicense * brandFitBoost;

    // Audience overlap boost
    const audienceBoost = audienceOverlap * 0.08;
    const audienceAdjustment = baseLicense * audienceBoost;

    // Market penetration boost
    const marketBoost = marketPenetration * 0.05;
    const marketAdjustment = baseLicense * marketBoost;

    // Risk penalty
    const riskPenalty = riskProfile * -0.15;
    const riskAdjustment = baseLicense * riskPenalty;

    const totalDomainPackAdjustment =
      brandFitAdjustment +
      audienceAdjustment +
      marketAdjustment +
      riskAdjustment;

    // --- FINAL RECOMMENDED LICENSE ---
    const recommendedLicense = Math.round(
      baseLicense + totalDomainPackAdjustment,
    );

    // --- TIER DETERMINATION ---
    const tier = determineTier(industry, subType, recommendedLicense);

    // --- CONFIDENCE SCORE ---
    const confidence = calculateConfidence({
      valuation,
      nilThroughput,
      performanceComplexity,
      domainPackIndex,
    });

    // --- COMPONENT WEIGHTS (for transparency) ---
    const totalComponents =
      valuationComponent + nilComponent + complexityComponent;
    const drivers = {
      valuationWeight:
        Math.round((valuationComponent / totalComponents) * 100) / 100,
      nilWeight: Math.round((nilComponent / totalComponents) * 100) / 100,
      complexityWeight:
        Math.round((complexityComponent / totalComponents) * 100) / 100,
    };

    // --- DOMAIN PACK IMPACT (for transparency) ---
    const domainPackImpact = {
      brandFitBoost: Math.round(brandFitBoost * 100) / 100,
      audienceBoost: Math.round(audienceBoost * 100) / 100,
      marketBoost: Math.round(marketBoost * 100) / 100,
      riskAdjustment: Math.round(riskPenalty * 100) / 100,
      totalAdjustment: Math.round(totalDomainPackAdjustment),
    };

    // --- BREAKDOWN (detailed view) ---
    const breakdown = {
      baseComponents: {
        valuation: Math.round(valuationComponent),
        nilThroughput: Math.round(nilComponent),
        performanceComplexity: Math.round(complexityComponent),
        subtotal: Math.round(baseLicense),
      },
      domainPackAdjustments: {
        brandFit: Math.round(brandFitAdjustment),
        audienceOverlap: Math.round(audienceAdjustment),
        marketPenetration: Math.round(marketAdjustment),
        risk: Math.round(riskAdjustment),
        subtotal: Math.round(totalDomainPackAdjustment),
      },
      total: recommendedLicense,
    };

    return Response.json({
      success: true,
      orgId,
      recommendedLicense,
      tier,
      confidence,
      drivers,
      domainPackImpact,
      breakdown,
      metadata: {
        industry,
        subType,
        calculatedAt: new Date().toISOString(),
        currency: "USD",
      },
    });
  } catch (error) {
    console.error("Pricing evaluation error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- TIER DETERMINATION ---
function determineTier(industry, subType, license) {
  // Industry-specific tier mappings
  const tiers = {
    music: {
      major_label: { min: 1500000, max: 4000000, name: "Major Label" },
      independent_label: {
        min: 250000,
        max: 1500000,
        name: "Independent Label",
      },
      artist_management: {
        min: 100000,
        max: 750000,
        name: "Artist Management",
      },
    },
    film: {
      major_studio: { min: 2000000, max: 6000000, name: "Major Studio" },
      independent_studio: {
        min: 500000,
        max: 2000000,
        name: "Independent Studio",
      },
      production_company: {
        min: 150000,
        max: 1000000,
        name: "Production Company",
      },
    },
    modeling: {
      major_agency: { min: 500000, max: 2000000, name: "Major Agency" },
      boutique_agency: { min: 100000, max: 500000, name: "Boutique Agency" },
    },
    cheer_dance: {
      national_organization: {
        min: 200000,
        max: 800000,
        name: "National Organization",
      },
      regional_studio: { min: 75000, max: 200000, name: "Regional Studio" },
      local_gym: { min: 25000, max: 75000, name: "Local Gym" },
    },
    pageantry: {
      major_pageant: { min: 300000, max: 1000000, name: "Major Pageant" },
      state_pageant: { min: 75000, max: 300000, name: "State Pageant" },
    },
  };

  const industryTiers = tiers[industry?.toLowerCase()] || {};
  const tierConfig = industryTiers[subType?.toLowerCase()];

  if (tierConfig) {
    if (license >= tierConfig.min && license <= tierConfig.max) {
      return tierConfig.name;
    }
    if (license > tierConfig.max) {
      return `${tierConfig.name} (Premium)`;
    }
    if (license < tierConfig.min) {
      return `${tierConfig.name} (Entry)`;
    }
  }

  // Default tier based on license amount
  if (license >= 2000000) return "Enterprise";
  if (license >= 500000) return "Professional";
  if (license >= 100000) return "Standard";
  return "Starter";
}

// --- CONFIDENCE CALCULATION ---
function calculateConfidence({
  valuation,
  nilThroughput,
  performanceComplexity,
  domainPackIndex,
}) {
  let confidence = 0.5; // Base confidence

  // Valuation confidence
  if (valuation > 0) confidence += 0.15;
  if (valuation > 100000000) confidence += 0.05;

  // NIL throughput confidence
  if (nilThroughput > 0) confidence += 0.1;
  if (nilThroughput > 10000000) confidence += 0.05;

  // Performance complexity confidence
  if (performanceComplexity > 0) confidence += 0.05;

  // Domain Pack Index confidence
  const hasFullDomainPack =
    domainPackIndex.brandFit > 0 &&
    domainPackIndex.audienceOverlap > 0 &&
    domainPackIndex.riskProfile >= 0;

  if (hasFullDomainPack) {
    confidence += 0.1;
  }

  return Math.min(1.0, Math.round(confidence * 100) / 100);
}
