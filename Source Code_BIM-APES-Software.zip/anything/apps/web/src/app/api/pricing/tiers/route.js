/**
 * BIM-APES Pricing API
 * GET /pricing/tiers
 *
 * Return all industry pricing tiers
 */

export async function GET(request) {
  try {
    const tiers = [
      // MUSIC INDUSTRY
      {
        industry: "music",
        subType: "major_label",
        name: "Major Label",
        range: "1500000 - 4000000",
        description: "Universal, Sony, Warner, etc.",
        features: [
          "Unlimited artist NIL contracts",
          "Domain Pack optimization",
          "Live concert NIL analytics",
          "Streaming royalty integration",
          "Global rights management",
        ],
      },
      {
        industry: "music",
        subType: "independent_label",
        name: "Independent Label",
        range: "250000 - 1500000",
        description: "Mid-size labels with 20-200 artists",
        features: [
          "Up to 200 artist profiles",
          "Core NIL valuation engine",
          "Social media analytics",
          "Basic streaming integration",
        ],
      },
      {
        industry: "music",
        subType: "artist_management",
        name: "Artist Management",
        range: "100000 - 750000",
        description: "Management companies & agencies",
        features: [
          "Up to 50 artist profiles",
          "Performance tracking",
          "Brand deal optimization",
          "Tour analytics",
        ],
      },

      // FILM & TV INDUSTRY
      {
        industry: "film",
        subType: "major_studio",
        name: "Major Studio",
        range: "2000000 - 6000000",
        description: "Paramount, Disney, Warner Bros, etc.",
        features: [
          "Unlimited talent NIL contracts",
          "Digital double NIL engine",
          "Box office correlation",
          "Streaming platform integration",
          "Global distribution analytics",
        ],
      },
      {
        industry: "film",
        subType: "independent_studio",
        name: "Independent Studio",
        range: "500000 - 2000000",
        description: "Independent film studios",
        features: [
          "Up to 100 talent profiles",
          "Festival circuit analytics",
          "Distribution deal optimization",
          "NIL valuation for indie talent",
        ],
      },
      {
        industry: "film",
        subType: "production_company",
        name: "Production Company",
        range: "150000 - 1000000",
        description: "Production & casting companies",
        features: [
          "Up to 50 talent profiles",
          "Casting NIL optimization",
          "Project-based NIL tracking",
        ],
      },

      // MODELING INDUSTRY
      {
        industry: "modeling",
        subType: "major_agency",
        name: "Major Agency",
        range: "500000 - 2000000",
        description: "IMG, Elite, Wilhelmina, etc.",
        features: [
          "Unlimited model profiles",
          "Runway performance tracking",
          "Brand campaign optimization",
          "Social influence analytics",
          "Global market analysis",
        ],
      },
      {
        industry: "modeling",
        subType: "boutique_agency",
        name: "Boutique Agency",
        range: "100000 - 500000",
        description: "Specialized modeling agencies",
        features: [
          "Up to 50 model profiles",
          "Campaign ROI tracking",
          "Social analytics",
        ],
      },

      // CHEER & DANCE INDUSTRY
      {
        industry: "cheer_dance",
        subType: "national_organization",
        name: "National Organization",
        range: "200000 - 800000",
        description: "USASF, USA Cheer, national studios",
        features: [
          "Multi-studio management",
          "Competition performance tracking",
          "Athlete NIL optimization",
          "Brand partnership analytics",
        ],
      },
      {
        industry: "cheer_dance",
        subType: "regional_studio",
        name: "Regional Studio",
        range: "75000 - 200000",
        description: "Multi-location studios",
        features: [
          "Up to 200 athlete profiles",
          "Performance tracking",
          "Competition analytics",
        ],
      },
      {
        industry: "cheer_dance",
        subType: "local_gym",
        name: "Local Gym",
        range: "25000 - 75000",
        description: "Single-location gyms",
        features: [
          "Up to 50 athlete profiles",
          "Basic performance tracking",
          "Competition results",
        ],
      },

      // PAGEANTRY INDUSTRY
      {
        industry: "pageantry",
        subType: "major_pageant",
        name: "Major Pageant",
        range: "300000 - 1000000",
        description: "Miss Universe, Miss World, etc.",
        features: [
          "Unlimited contestant profiles",
          "Pageant performance tracking",
          "Brand partnership optimization",
          "Global media analytics",
        ],
      },
      {
        industry: "pageantry",
        subType: "state_pageant",
        name: "State Pageant",
        range: "75000 - 300000",
        description: "State & regional pageants",
        features: [
          "Up to 100 contestant profiles",
          "Competition tracking",
          "Sponsor analytics",
        ],
      },

      // SPORTS (for reference)
      {
        industry: "sports",
        subType: "professional_team",
        name: "Professional Team",
        range: "1000000 - 3000000",
        description: "NFL, NBA, MLB teams",
        features: [
          "Full roster NIL management",
          "Biometric performance integration",
          "Fan engagement analytics",
          "Sponsor activation tracking",
        ],
      },
      {
        industry: "sports",
        subType: "college_program",
        name: "College Program",
        range: "200000 - 800000",
        description: "NCAA Division I programs",
        features: [
          "Athlete NIL compliance",
          "Performance tracking",
          "NCAA compliance reporting",
        ],
      },
    ];

    // Group by industry
    const groupedTiers = tiers.reduce((acc, tier) => {
      if (!acc[tier.industry]) {
        acc[tier.industry] = [];
      }
      acc[tier.industry].push(tier);
      return acc;
    }, {});

    return Response.json({
      success: true,
      tiers,
      groupedTiers,
      totalTiers: tiers.length,
      industries: Object.keys(groupedTiers),
    });
  } catch (error) {
    console.error("Get tiers error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
