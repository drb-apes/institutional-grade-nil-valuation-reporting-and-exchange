/**
 * BIM-APES Pricing API
 * GET /pricing/addons
 *
 * Return optional modules + pricing
 */

export async function GET(request) {
  try {
    const addons = [
      {
        id: "digital_double",
        name: "Digital Double NIL Engine",
        category: "film_tv",
        priceRange: "150000 - 500000",
        basePrice: 250000,
        description: "AI-powered digital twin NIL valuation for film/TV talent",
        features: [
          "AI-generated digital double performance simulation",
          "Synthetic media NIL rights management",
          "Box office correlation modeling",
          "Streaming platform integration",
          "Deepfake NIL compliance",
        ],
        bestFor: ["Major studios", "Production companies", "VFX houses"],
      },
      {
        id: "hedging_engine",
        name: "Talent Portfolio Hedging Engine",
        category: "finance",
        priceRange: "100000 - 400000",
        basePrice: 300000,
        description:
          "Risk management & portfolio optimization for talent investments",
        features: [
          "Index-level & talent-level hedging",
          "Volatility analysis & prediction",
          "Automated rebalancing",
          "Downside protection strategies",
          "Performance attribution",
        ],
        bestFor: ["Agencies", "Investment firms", "Major labels"],
      },
      {
        id: "live_concert_analytics",
        name: "Live Concert NIL Analytics",
        category: "music",
        priceRange: "100000 - 350000",
        basePrice: 200000,
        description: "Real-time concert performance → NIL valuation",
        features: [
          "Concert Performance Units (CPUs) tracking",
          "Real-time NIL value updates during shows",
          "Crowd engagement analytics",
          "Setlist optimization",
          "Tour revenue forecasting",
        ],
        bestFor: ["Music labels", "Concert promoters", "Artist management"],
      },
      {
        id: "sandbox_enterprise",
        name: "Multi-Tenant Sandbox (Enterprise)",
        category: "platform",
        priceRange: "200000 - 600000",
        basePrice: 400000,
        description:
          "Unlimited sandboxes for testing, simulation & campaign planning",
        features: [
          "Unlimited concurrent sandboxes",
          "Campaign ROI simulation",
          "A/B testing framework",
          "Historical data replay",
          "Tenant isolation & governance",
        ],
        bestFor: ["Sponsors", "Agencies", "Research firms"],
      },
      {
        id: "coalition_network",
        name: "Multi-Sport Coalition Network",
        category: "sports",
        priceRange: "150000 - 500000",
        basePrice: 350000,
        description: "Cross-sport portfolio optimization & coalition building",
        features: [
          "Multi-sport talent tracking",
          "Coalition formation analytics",
          "Cross-sport fan engagement",
          "Portfolio diversification",
          "Syndication opportunities",
        ],
        bestFor: [
          "Sports agencies",
          "Multi-sport sponsors",
          "Talent collectives",
        ],
      },
      {
        id: "blockchain_integration",
        name: "Blockchain Smart Contracts",
        category: "technology",
        priceRange: "300000 - 800000",
        basePrice: 500000,
        description: "On-chain NIL contract execution & payment automation",
        features: [
          "Smart contract generation",
          "On-chain payment distribution",
          "Automated royalty splits",
          "Immutable audit trail",
          "Multi-chain support (Ethereum, Polygon, Solana)",
        ],
        bestFor: [
          "Web3 platforms",
          "Crypto-native brands",
          "Progressive agencies",
        ],
      },
      {
        id: "ai_agent_orchestration",
        name: "Agentic AI Orchestration Layer",
        category: "ai",
        priceRange: "400000 - 1000000",
        basePrice: 600000,
        description: "Semi-autonomous business process automation",
        features: [
          "NIL Contract Agent (full lifecycle)",
          "Revenue Optimization Agent",
          "Performance Monitoring Agent",
          "Compliance Agent",
          "Marketing Optimization Agent",
          "Multi-agent coordination",
        ],
        bestFor: ["Enterprises", "Large agencies", "Multi-brand organizations"],
      },
      {
        id: "white_label",
        name: "White Label Deployment",
        category: "platform",
        priceRange: "500000 - 1500000",
        basePrice: 750000,
        description: "Fully branded instance of BIM-APES for your organization",
        features: [
          "Custom domain & branding",
          "Dedicated infrastructure",
          "API white labeling",
          "Custom feature development",
          "Dedicated support team",
        ],
        bestFor: ["Major enterprises", "Leagues", "Government bodies"],
      },
      {
        id: "biometric_integration",
        name: "Advanced Biometric Integration",
        category: "sports",
        priceRange: "200000 - 600000",
        basePrice: 400000,
        description: "Wearable device integration & performance tracking",
        features: [
          "Multi-device support (Whoop, Polar, Garmin, etc.)",
          "Mesh network sync",
          "Real-time BIM calculation",
          "Injury prediction",
          "Recovery optimization",
        ],
        bestFor: [
          "Sports teams",
          "Training facilities",
          "Health-focused brands",
        ],
      },
      {
        id: "compliance_suite",
        name: "Compliance & Governance Suite",
        category: "legal",
        priceRange: "150000 - 400000",
        basePrice: 250000,
        description: "NCAA, league, & international compliance automation",
        features: [
          "Automated compliance checking",
          "Regulatory update tracking",
          "Audit trail generation",
          "Violation alerts",
          "Reporting dashboards",
        ],
        bestFor: ["Colleges", "Professional leagues", "Agencies"],
      },
    ];

    // Group by category
    const categories = {
      film_tv: [],
      music: [],
      sports: [],
      finance: [],
      technology: [],
      ai: [],
      platform: [],
      legal: [],
    };

    addons.forEach((addon) => {
      if (categories[addon.category]) {
        categories[addon.category].push(addon);
      }
    });

    return Response.json({
      success: true,
      addons,
      categories,
      totalAddons: addons.length,
    });
  } catch (error) {
    console.error("Get addons error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
