import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Pricing API
 * POST /pricing/quote
 *
 * Generate a formal quote with breakdown
 * Includes base license + addons
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      orgId,
      baseLicense, // Can be provided or will be calculated
      includeAddons = false,
      addons = [],
      customDiscount = 0, // Percentage (0-100)
      contractTerm = 12, // Months
      paymentPlan = "annual", // annual, quarterly, monthly
    } = body;

    // --- VALIDATION ---
    if (!orgId) {
      return Response.json(
        {
          error: "Missing required field: orgId",
        },
        { status: 400 },
      );
    }

    // --- GET BASE LICENSE (if not provided) ---
    let finalBaseLicense = baseLicense;

    if (!finalBaseLicense) {
      // Fetch org profile and calculate
      const profile = await sql`
        SELECT * FROM tenants WHERE tenant_id = ${orgId} LIMIT 1
      `;

      if (profile.length === 0) {
        return Response.json(
          {
            error:
              "Organization profile not found. Please create a profile first.",
          },
          { status: 404 },
        );
      }

      // For now, use a default calculation
      // In production, this would call /pricing/evaluate
      finalBaseLicense = 500000; // Default starter license
    }

    // --- ADDON PRICING ---
    const addonCatalog = {
      digital_double: {
        name: "Digital Double NIL Engine",
        basePrice: 250000,
        description: "AI-powered digital twin NIL valuation for film/TV",
      },
      hedging_engine: {
        name: "Talent Portfolio Hedging Engine",
        basePrice: 300000,
        description: "Risk management & portfolio optimization",
      },
      live_concert_analytics: {
        name: "Live Concert NIL Analytics",
        basePrice: 200000,
        description: "Real-time concert performance → NIL valuation",
      },
      sandbox_enterprise: {
        name: "Multi-Tenant Sandbox (Enterprise)",
        basePrice: 400000,
        description: "Unlimited sandboxes for testing & simulation",
      },
      coalition_network: {
        name: "Multi-Sport Coalition Network",
        basePrice: 350000,
        description: "Cross-sport portfolio optimization",
      },
      blockchain_integration: {
        name: "Blockchain Smart Contracts",
        basePrice: 500000,
        description: "On-chain NIL contract execution",
      },
      ai_agent_orchestration: {
        name: "Agentic AI Orchestration Layer",
        basePrice: 600000,
        description: "Semi-autonomous business process automation",
      },
      white_label: {
        name: "White Label Deployment",
        basePrice: 750000,
        description: "Fully branded instance of BIM-APES",
      },
    };

    const selectedAddons = [];
    let addonsTotal = 0;

    if (includeAddons && addons.length > 0) {
      addons.forEach((addonId) => {
        const addon = addonCatalog[addonId];
        if (addon) {
          selectedAddons.push({
            id: addonId,
            ...addon,
          });
          addonsTotal += addon.basePrice;
        }
      });
    }

    // --- CALCULATE SUBTOTAL ---
    const subtotal = finalBaseLicense + addonsTotal;

    // --- APPLY DISCOUNT ---
    const discountAmount = subtotal * (customDiscount / 100);
    const totalAfterDiscount = subtotal - discountAmount;

    // --- PAYMENT PLAN CALCULATION ---
    let paymentSchedule = [];

    if (paymentPlan === "annual") {
      paymentSchedule = [
        {
          installment: 1,
          amount: totalAfterDiscount,
          dueDate: "Upon signing",
        },
      ];
    } else if (paymentPlan === "quarterly") {
      const quarterlyAmount = totalAfterDiscount / 4;
      paymentSchedule = [
        { installment: 1, amount: quarterlyAmount, dueDate: "Upon signing" },
        { installment: 2, amount: quarterlyAmount, dueDate: "Q2" },
        { installment: 3, amount: quarterlyAmount, dueDate: "Q3" },
        { installment: 4, amount: quarterlyAmount, dueDate: "Q4" },
      ];
    } else if (paymentPlan === "monthly") {
      const monthlyAmount = totalAfterDiscount / contractTerm;
      paymentSchedule = Array.from({ length: contractTerm }, (_, i) => ({
        installment: i + 1,
        amount: Math.round(monthlyAmount * 100) / 100,
        dueDate: `Month ${i + 1}`,
      }));
    }

    // --- GENERATE QUOTE ID ---
    const quoteId = `QUOTE-${orgId}-${Date.now()}`;

    // --- EXPIRATION DATE ---
    const validForDays = 30;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + validForDays);

    // --- BUILD QUOTE ---
    const quote = {
      quoteId,
      orgId,
      pricing: {
        baseLicense: Math.round(finalBaseLicense),
        addons: selectedAddons.map((a) => ({
          id: a.id,
          name: a.name,
          price: a.basePrice,
        })),
        addonsTotal: Math.round(addonsTotal),
        subtotal: Math.round(subtotal),
        discount:
          customDiscount > 0
            ? {
                percentage: customDiscount,
                amount: Math.round(discountAmount),
              }
            : null,
        total: Math.round(totalAfterDiscount),
      },
      contract: {
        term: contractTerm,
        termUnit: "months",
        paymentPlan,
        paymentSchedule,
      },
      validity: {
        generatedAt: new Date().toISOString(),
        expiresAt: expiresAt.toISOString(),
        validForDays,
      },
      terms: {
        support: "24/7 enterprise support",
        sla: "99.9% uptime guarantee",
        updates: "Quarterly feature releases",
        training: "Onboarding & training included",
        dataRetention: "Unlimited historical data",
      },
    };

    return Response.json({
      success: true,
      quote,
    });
  } catch (error) {
    console.error("Quote generation error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
