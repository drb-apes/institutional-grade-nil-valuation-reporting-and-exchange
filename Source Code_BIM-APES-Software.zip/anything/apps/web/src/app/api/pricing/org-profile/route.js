import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Pricing API
 * POST /pricing/org-profile
 *
 * Store or update organization's financial + NIL profile
 *
 * This creates a pricing profile that can be referenced
 * for quick evaluations and quote generation
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      orgId,
      name,
      industry,
      subType,
      valuation,
      annualRevenue,
      nilThroughput,
      talentVolume,
      performanceComplexity,
      contactEmail,
      contactPhone,
      metadata = {},
    } = body;

    // --- VALIDATION ---
    if (!orgId || !industry) {
      return Response.json(
        {
          error: "Missing required fields: orgId, industry",
        },
        { status: 400 },
      );
    }

    // --- CHECK IF PROFILE EXISTS ---
    const existingProfile = await sql`
      SELECT * FROM tenants 
      WHERE tenant_id = ${orgId}
      LIMIT 1
    `;

    if (existingProfile.length > 0) {
      // --- UPDATE EXISTING PROFILE ---
      await sql`
        UPDATE tenants
        SET 
          tenant_name = ${name || existingProfile[0].tenant_name},
          tenant_type = ${subType || existingProfile[0].tenant_type},
          contact_email = ${contactEmail || existingProfile[0].contact_email},
          contact_phone = ${contactPhone || existingProfile[0].contact_phone},
          updated_at = CURRENT_TIMESTAMP
        WHERE tenant_id = ${orgId}
      `;

      // Store additional profile data in tenant_profiles if it exists
      const profileExists = await sql`
        SELECT * FROM tenant_profiles
        WHERE tenant_id = ${orgId}
        LIMIT 1
      `;

      if (profileExists.length > 0) {
        // Update existing tenant profile
        // Note: tenant_profiles table doesn't have all these fields,
        // so we'll store them in a JSON metadata column or create a new table
      }

      return Response.json({
        success: true,
        status: "updated",
        orgId,
        message: "Organization profile updated successfully",
      });
    } else {
      // --- CREATE NEW PROFILE ---
      await sql`
        INSERT INTO tenants (
          tenant_id,
          tenant_type,
          tenant_name,
          contact_email,
          contact_phone,
          tier_level,
          is_active
        ) VALUES (
          ${orgId},
          ${subType || industry},
          ${name || "Organization " + orgId},
          ${contactEmail || null},
          ${contactPhone || null},
          ${"standard"},
          ${true}
        )
      `;

      // Create tenant profile entry
      await sql`
        INSERT INTO tenant_profiles (
          tenant_id,
          nil_tier
        ) VALUES (
          ${orgId},
          ${"tier_1"}
        )
      `;

      return Response.json({
        success: true,
        status: "created",
        orgId,
        message: "Organization profile created successfully",
      });
    }
  } catch (error) {
    console.error("Org profile error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// --- GET ORGANIZATION PROFILE ---
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("orgId");

    if (!orgId) {
      return Response.json(
        {
          error: "Missing required parameter: orgId",
        },
        { status: 400 },
      );
    }

    const profile = await sql`
      SELECT 
        t.*,
        tp.nil_tier,
        tp.max_athlete_access,
        tp.allowed_export_formats
      FROM tenants t
      LEFT JOIN tenant_profiles tp ON t.tenant_id = tp.tenant_id
      WHERE t.tenant_id = ${orgId}
      LIMIT 1
    `;

    if (profile.length === 0) {
      return Response.json(
        {
          error: "Organization profile not found",
        },
        { status: 404 },
      );
    }

    return Response.json({
      success: true,
      profile: profile[0],
    });
  } catch (error) {
    console.error("Get org profile error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
