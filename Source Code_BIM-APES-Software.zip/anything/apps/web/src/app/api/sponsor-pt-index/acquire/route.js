import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { success: false, error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      indexId,
      athleteId,
      baseFee,
      nilRoyaltyMultiplier,
      convexityMultiplier,
      ptTokenAllocation,
      fanTipRoyalty,
      tradingRoyalty,
    } = body;

    if (!indexId || !athleteId || !baseFee || !ptTokenAllocation) {
      return Response.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql.transaction(async (txn) => {
      // Get sponsor's user_profile
      const sponsorProfile = await txn`
        SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
      `;

      if (sponsorProfile.length === 0) {
        throw new Error("Sponsor profile not found");
      }

      const sponsor_id = sponsorProfile[0].id;

      // Create sponsor contract
      const expires_at = new Date();
      expires_at.setDate(expires_at.getDate() + 365); // 1 year contract

      const contract = await txn`
        INSERT INTO sponsor_contracts (
          sponsor_id,
          athlete_id,
          contract_type,
          index_type,
          exposure_amount,
          predictable_spend,
          yield_target,
          performance_metrics,
          contract_status,
          expires_at
        ) VALUES (
          ${sponsor_id},
          ${athleteId},
          'biometric_index',
          ${indexId},
          ${baseFee},
          ${baseFee * 1.2},
          ${JSON.stringify({
            fanTipRoyalty: fanTipRoyalty,
            tradingRoyalty: tradingRoyalty,
            nilRoyaltyMultiplier: nilRoyaltyMultiplier,
            convexityMultiplier: convexityMultiplier,
          })},
          ${JSON.stringify({
            ptTokenAllocation: ptTokenAllocation,
            indexId: indexId,
            acquisitionDate: new Date().toISOString(),
          })},
          'active',
          ${expires_at.toISOString()}
        )
        RETURNING *
      `;

      // Allocate PT tokens to sponsor
      await txn`
        INSERT INTO pt_token_balances (user_id, balance, available_balance, total_earned)
        VALUES (${sponsor_id}, ${ptTokenAllocation}, ${ptTokenAllocation}, ${ptTokenAllocation})
        ON CONFLICT (user_id) DO UPDATE SET
          balance = pt_token_balances.balance + ${ptTokenAllocation},
          available_balance = pt_token_balances.available_balance + ${ptTokenAllocation},
          total_earned = pt_token_balances.total_earned + ${ptTokenAllocation},
          updated_at = CURRENT_TIMESTAMP
      `;

      // Create treasury transaction for base fee payment
      await txn`
        INSERT INTO treasury_transactions (
          transaction_type,
          amount,
          balance_after,
          reference_id,
          reference_type,
          description,
          authorized_by
        ) VALUES (
          'deposit',
          ${baseFee},
          ${baseFee},
          ${contract[0].id},
          'pt_index_acquisition',
          ${"PT Index acquisition: " + indexId + " for athlete " + athleteId},
          ${sponsor_id}
        )
      `;

      return { contract: contract[0] };
    });

    return Response.json({
      success: true,
      message: "PT Index acquired successfully",
      contract: result.contract,
      ptTokensAllocated: ptTokenAllocation,
      revenueSplits: {
        fanTipRoyalty: `${fanTipRoyalty}%`,
        tradingRoyalty: `${tradingRoyalty}%`,
      },
    });
  } catch (error) {
    console.error("PT Index acquisition error:", error);
    return Response.json(
      { success: false, error: error.message || "Failed to acquire PT Index" },
      { status: 500 },
    );
  }
}
