import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * SPONSOR ROI ENGINE
 * Calculate attribution, lift, and ROI metrics from campaign data
 *
 * Calculations:
 * - Multi-touch attribution modeling
 * - Brand lift measurement
 * - Cost per acquisition (CPA)
 * - Return on ad spend (ROAS)
 * - Customer lifetime value (CLV) projections
 * - Incremental lift vs baseline
 */

async function validateCampaignAccess(campaignId, tenantId) {
  const campaign = await sql`
    SELECT c.*
    FROM sandbox_campaigns c
    WHERE c.campaign_id = ${campaignId} AND c.tenant_id = ${tenantId}
  `;

  if (campaign.length === 0) {
    return { valid: false, error: "Campaign not found or access denied" };
  }

  return { valid: true, campaign: campaign[0] };
}

// Calculate multi-touch attribution
function calculateAttribution(events) {
  const attributionModels = {
    lastTouch: {},
    firstTouch: {},
    linear: {},
    timeDecay: {},
    positionBased: {},
  };

  // Group events by session/user
  const sessions = {};
  events.forEach((event) => {
    const sessionId = event.correlation_id || event.event_id;
    if (!sessions[sessionId]) {
      sessions[sessionId] = [];
    }
    sessions[sessionId].push(event);
  });

  // Process each session
  Object.values(sessions).forEach((sessionEvents) => {
    // Sort by timestamp
    sessionEvents.sort(
      (a, b) => new Date(a.event_timestamp) - new Date(b.event_timestamp),
    );

    const hasConversion = sessionEvents.some(
      (e) => e.event_type === "conversion",
    );
    if (!hasConversion) return;

    const touchpoints = sessionEvents.filter((e) =>
      [
        "exposure",
        "media_impression",
        "engagement",
        "qr_scan",
        "link_click",
      ].includes(e.event_type),
    );

    if (touchpoints.length === 0) return;

    // Last touch attribution
    const lastTouch = touchpoints[touchpoints.length - 1];
    attributionModels.lastTouch[lastTouch.event_type] =
      (attributionModels.lastTouch[lastTouch.event_type] || 0) + 1;

    // First touch attribution
    const firstTouch = touchpoints[0];
    attributionModels.firstTouch[firstTouch.event_type] =
      (attributionModels.firstTouch[firstTouch.event_type] || 0) + 1;

    // Linear attribution (equal credit)
    const linearCredit = 1 / touchpoints.length;
    touchpoints.forEach((tp) => {
      attributionModels.linear[tp.event_type] =
        (attributionModels.linear[tp.event_type] || 0) + linearCredit;
    });

    // Time decay attribution (more recent = more credit)
    const totalTime =
      new Date(touchpoints[touchpoints.length - 1].event_timestamp) -
      new Date(touchpoints[0].event_timestamp);
    touchpoints.forEach((tp, idx) => {
      const timeFromStart =
        new Date(tp.event_timestamp) - new Date(touchpoints[0].event_timestamp);
      const weight = totalTime > 0 ? Math.exp(timeFromStart / totalTime) : 1;
      const totalWeight = touchpoints.reduce((sum, t, i) => {
        const tf =
          new Date(t.event_timestamp) -
          new Date(touchpoints[0].event_timestamp);
        return sum + (totalTime > 0 ? Math.exp(tf / totalTime) : 1);
      }, 0);
      const credit = weight / totalWeight;

      attributionModels.timeDecay[tp.event_type] =
        (attributionModels.timeDecay[tp.event_type] || 0) + credit;
    });

    // Position-based (40% first, 40% last, 20% middle)
    if (touchpoints.length === 1) {
      attributionModels.positionBased[touchpoints[0].event_type] =
        (attributionModels.positionBased[touchpoints[0].event_type] || 0) + 1;
    } else if (touchpoints.length === 2) {
      attributionModels.positionBased[firstTouch.event_type] =
        (attributionModels.positionBased[firstTouch.event_type] || 0) + 0.5;
      attributionModels.positionBased[lastTouch.event_type] =
        (attributionModels.positionBased[lastTouch.event_type] || 0) + 0.5;
    } else {
      const middleCredit = 0.2 / (touchpoints.length - 2);
      attributionModels.positionBased[firstTouch.event_type] =
        (attributionModels.positionBased[firstTouch.event_type] || 0) + 0.4;
      attributionModels.positionBased[lastTouch.event_type] =
        (attributionModels.positionBased[lastTouch.event_type] || 0) + 0.4;

      touchpoints.slice(1, -1).forEach((tp) => {
        attributionModels.positionBased[tp.event_type] =
          (attributionModels.positionBased[tp.event_type] || 0) + middleCredit;
      });
    }
  });

  return attributionModels;
}

// Calculate brand lift (requires control group comparison)
function calculateBrandLift(campaignMetrics, baselineMetrics) {
  const lift = {
    exposureLift: 0,
    engagementLift: 0,
    conversionLift: 0,
    overallLift: 0,
  };

  if (baselineMetrics.exposures > 0) {
    lift.exposureLift =
      ((campaignMetrics.exposures - baselineMetrics.exposures) /
        baselineMetrics.exposures) *
      100;
  }

  if (baselineMetrics.engagements > 0) {
    lift.engagementLift =
      ((campaignMetrics.engagements - baselineMetrics.engagements) /
        baselineMetrics.engagements) *
      100;
  }

  if (baselineMetrics.conversions > 0) {
    lift.conversionLift =
      ((campaignMetrics.conversions - baselineMetrics.conversions) /
        baselineMetrics.conversions) *
      100;
  }

  // Overall lift (weighted average)
  lift.overallLift =
    lift.exposureLift * 0.2 +
    lift.engagementLift * 0.3 +
    lift.conversionLift * 0.5;

  return lift;
}

// POST - Calculate ROI for campaign
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      tenantId,
      campaignId,
      conversionValue, // Average value per conversion
      compareToBaseline, // Compare to pre-campaign baseline
      baselineStartDate,
      baselineEndDate,
    } = body;

    if (!tenantId || !campaignId) {
      return Response.json(
        {
          error: "Missing required fields: tenantId, campaignId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(campaignId, tenantId);
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // Get all campaign events
    const campaignEvents = await sql`
      SELECT *
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
      ORDER BY event_timestamp ASC
    `;

    // Calculate basic metrics
    const metrics = {
      exposures: campaignEvents.filter((e) => e.event_type === "exposure")
        .length,
      impressions: campaignEvents.filter(
        (e) => e.event_type === "media_impression",
      ).length,
      engagements: campaignEvents.filter((e) => e.event_type === "engagement")
        .length,
      qrScans: campaignEvents.filter((e) => e.event_type === "qr_scan").length,
      linkClicks: campaignEvents.filter((e) => e.event_type === "link_click")
        .length,
      conversions: campaignEvents.filter((e) => e.event_type === "conversion")
        .length,
      redemptions: campaignEvents.filter((e) => e.event_type === "redemption")
        .length,
      uniqueAthletes: new Set(
        campaignEvents
          .filter((e) => e.athlete_profile_id)
          .map((e) => e.athlete_profile_id),
      ).size,
      uniqueSessions: new Set(
        campaignEvents.map((e) => e.correlation_id || e.event_id),
      ).size,
    };

    // Financial calculations
    const spentApex = parseFloat(campaign.spent_apex || 0);
    const totalReach = metrics.exposures + metrics.impressions;
    const avgConversionValue = parseFloat(conversionValue || 0);
    const totalRevenue = metrics.conversions * avgConversionValue;

    const roi = {
      totalSpent: spentApex,
      totalRevenue,
      netProfit: totalRevenue - spentApex,
      roiPercentage:
        spentApex > 0
          ? (((totalRevenue - spentApex) / spentApex) * 100).toFixed(2)
          : 0,
      roas: spentApex > 0 ? (totalRevenue / spentApex).toFixed(2) : 0, // Return on Ad Spend
      cpa:
        metrics.conversions > 0
          ? (spentApex / metrics.conversions).toFixed(2)
          : 0, // Cost per Acquisition
      cpe:
        metrics.engagements > 0
          ? (spentApex / metrics.engagements).toFixed(2)
          : 0, // Cost per Engagement
      cpm: totalReach > 0 ? ((spentApex / totalReach) * 1000).toFixed(2) : 0, // Cost per Mille (1000 impressions)
      costPerClick:
        metrics.qrScans + metrics.linkClicks > 0
          ? (spentApex / (metrics.qrScans + metrics.linkClicks)).toFixed(2)
          : 0,
    };

    // Calculate attribution
    const attribution = calculateAttribution(campaignEvents);

    // Calculate conversion funnel efficiency
    const funnelEfficiency = {
      exposureToEngagement:
        totalReach > 0
          ? ((metrics.engagements / totalReach) * 100).toFixed(2) + "%"
          : "0%",
      engagementToConversion:
        metrics.engagements > 0
          ? ((metrics.conversions / metrics.engagements) * 100).toFixed(2) + "%"
          : "0%",
      overallConversion:
        totalReach > 0
          ? ((metrics.conversions / totalReach) * 100).toFixed(2) + "%"
          : "0%",
      dropoffAtEngagement:
        totalReach > 0
          ? (((totalReach - metrics.engagements) / totalReach) * 100).toFixed(
              2,
            ) + "%"
          : "0%",
      dropoffAtConversion:
        metrics.engagements > 0
          ? (
              ((metrics.engagements - metrics.conversions) /
                metrics.engagements) *
              100
            ).toFixed(2) + "%"
          : "0%",
    };

    // Calculate brand lift (if baseline provided)
    let brandLift = null;
    if (compareToBaseline && baselineStartDate && baselineEndDate) {
      const baselineEvents = await sql`
        SELECT *
        FROM sandbox_events
        WHERE sandbox_id = ${campaign.sandbox_id}
          AND event_timestamp >= ${baselineStartDate}
          AND event_timestamp <= ${baselineEndDate}
      `;

      const baselineMetrics = {
        exposures: baselineEvents.filter((e) => e.event_type === "exposure")
          .length,
        engagements: baselineEvents.filter((e) => e.event_type === "engagement")
          .length,
        conversions: baselineEvents.filter((e) => e.event_type === "conversion")
          .length,
      };

      brandLift = calculateBrandLift(metrics, baselineMetrics);
    }

    // Customer lifetime value projection (simple model)
    const clvProjection = {
      avgOrderValue: avgConversionValue,
      estimatedRepeatPurchases: 3.5, // Industry average
      estimatedRetentionRate: 0.65, // Industry average
      projectedCLV: (avgConversionValue * 3.5 * 0.65).toFixed(2),
      clvToCapRatio:
        spentApex > 0
          ? ((avgConversionValue * 3.5 * 0.65) / spentApex).toFixed(2)
          : 0,
    };

    // Performance benchmarks
    const performance = {
      excellent: parseFloat(roi.roiPercentage) > 300,
      good:
        parseFloat(roi.roiPercentage) > 150 &&
        parseFloat(roi.roiPercentage) <= 300,
      fair:
        parseFloat(roi.roiPercentage) > 50 &&
        parseFloat(roi.roiPercentage) <= 150,
      poor: parseFloat(roi.roiPercentage) <= 50,
      grade:
        parseFloat(roi.roiPercentage) > 300
          ? "A+"
          : parseFloat(roi.roiPercentage) > 200
            ? "A"
            : parseFloat(roi.roiPercentage) > 150
              ? "B+"
              : parseFloat(roi.roiPercentage) > 100
                ? "B"
                : parseFloat(roi.roiPercentage) > 50
                  ? "C"
                  : "D",
    };

    return Response.json({
      success: true,
      campaignId,
      campaign: {
        name: campaign.campaign_name,
        objective: campaign.objective,
        status: campaign.status,
        startDate: campaign.start_at,
        endDate: campaign.end_at,
      },
      metrics,
      roi,
      attribution,
      funnelEfficiency,
      brandLift,
      clvProjection,
      performance,
      recommendations: {
        budgetOptimization:
          spentApex > totalRevenue
            ? "Consider reducing budget or improving conversion rate"
            : "Campaign is profitable, consider scaling budget",
        channelMix: Object.entries(attribution.linear)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 3)
          .map(([channel, credit]) => ({
            channel,
            attributedConversions: credit.toFixed(2),
            recommendation:
              credit > metrics.conversions * 0.3
                ? "High-performing channel, increase investment"
                : "Optimize or reallocate budget",
          })),
        funnelOptimization: [
          parseFloat(funnelEfficiency.exposureToEngagement.replace("%", "")) <
          10
            ? "Low engagement rate: Improve creative or targeting"
            : null,
          parseFloat(funnelEfficiency.engagementToConversion.replace("%", "")) <
          5
            ? "Low conversion rate: Optimize landing page or offer"
            : null,
        ].filter(Boolean),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("ROI calculation error:", error);
    return Response.json(
      {
        error: "Failed to calculate ROI",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
