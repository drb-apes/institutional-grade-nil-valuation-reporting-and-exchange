import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { v4 as uuidv4 } from "crypto";

// GET /api/sandbox/sandboxes - List all sandboxes for tenant
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const tenantId = searchParams.get("tenant_id");

    if (!tenantId) {
      return Response.json({ error: "Missing tenant_id" }, { status: 400 });
    }

    // Verify user has access to this tenant
    const [mapping] = await sql`
      SELECT role_in_tenant FROM user_tenant_mappings
      WHERE user_id = ${session.user.id} AND tenant_id = ${tenantId}
    `;

    if (!mapping) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    // Get all sandboxes for this tenant
    const sandboxes = await sql`
      SELECT 
        s.*,
        sc.data_sources_allowed,
        sc.use_cases_allowed,
        sc.athlete_access_scope,
        sc.max_athlete_profiles,
        (SELECT COUNT(*) FROM sandbox_campaigns WHERE sandbox_id = s.sandbox_id AND status = 'active') as active_campaigns,
        (SELECT COUNT(*) FROM sandbox_events WHERE sandbox_id = s.sandbox_id) as total_events
      FROM sandboxes s
      LEFT JOIN sandbox_contracts sc ON s.sandbox_id = sc.sandbox_id
      WHERE s.tenant_id = ${tenantId}
      ORDER BY s.created_at DESC
    `;

    return Response.json({
      success: true,
      sandboxes: sandboxes.map((s) => ({
        sandboxId: s.sandbox_id,
        sandboxName: s.sandbox_name,
        sandboxType: s.sandbox_type,
        description: s.description,
        status: s.status,
        apexBudget: parseFloat(s.apex_budget),
        apexSpent: parseFloat(s.apex_spent),
        apexRemaining: parseFloat(s.apex_budget) - parseFloat(s.apex_spent),
        ttlHours: s.ttl_hours,
        expiresAt: s.expires_at,
        createdAt: s.created_at,
        activeCampaigns: parseInt(s.active_campaigns),
        totalEvents: parseInt(s.total_events),
        dataSourcesAllowed: s.data_sources_allowed,
        useCasesAllowed: s.use_cases_allowed,
        athleteAccessScope: s.athlete_access_scope,
        maxAthleteProfiles: s.max_athlete_profiles,
        metadata: s.metadata,
      })),
    });
  } catch (error) {
    console.error("Error fetching sandboxes:", error);
    return Response.json(
      { error: "Failed to fetch sandboxes" },
      { status: 500 },
    );
  }
}

// POST /api/sandbox/sandboxes - Create a new sandbox
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      tenantId,
      sandboxName,
      sandboxType,
      description,
      apexBudget = 1000,
      ttlHours = 720,
      dataSourcesAllowed = ["biometric", "nil", "sponsor_events"],
      useCasesAllowed = ["marketing", "analytics"],
      athleteAccessScope = "aggregated",
      maxAthleteProfiles = 100,
    } = body;

    if (!tenantId || !sandboxName || !sandboxType) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Verify user has access to this tenant
    const [mapping] = await sql`
      SELECT role_in_tenant FROM user_tenant_mappings
      WHERE user_id = ${session.user.id} AND tenant_id = ${tenantId}
    `;

    if (!mapping || !["owner", "admin"].includes(mapping.role_in_tenant)) {
      return Response.json({ error: "Access denied" }, { status: 403 });
    }

    // Check tenant limits
    const [tenant] = await sql`
      SELECT tp.max_concurrent_sandboxes
      FROM tenants t
      LEFT JOIN tenant_profiles tp ON t.tenant_id = tp.tenant_id
      WHERE t.tenant_id = ${tenantId}
    `;

    const [sandboxCount] = await sql`
      SELECT COUNT(*) as count FROM sandboxes
      WHERE tenant_id = ${tenantId} AND status = 'active'
    `;

    if (parseInt(sandboxCount.count) >= tenant.max_concurrent_sandboxes) {
      return Response.json(
        {
          error: `Maximum concurrent sandboxes (${tenant.max_concurrent_sandboxes}) reached`,
        },
        { status: 400 },
      );
    }

    const sandboxId = `${sandboxType}_${uuidv4().slice(0, 8)}`;
    const expiresAt = new Date(Date.now() + ttlHours * 60 * 60 * 1000);

    // Create sandbox
    await sql`
      INSERT INTO sandboxes (
        sandbox_id,
        tenant_id,
        sandbox_type,
        sandbox_name,
        description,
        apex_budget,
        ttl_hours,
        expires_at,
        status,
        metadata
      ) VALUES (
        ${sandboxId},
        ${tenantId},
        ${sandboxType},
        ${sandboxName},
        ${description},
        ${apexBudget},
        ${ttlHours},
        ${expiresAt},
        'active',
        ${JSON.stringify({ createdBy: session.user.id })}
      )
    `;

    // Create sandbox contract
    await sql`
      INSERT INTO sandbox_contracts (
        sandbox_id,
        data_sources_allowed,
        use_cases_allowed,
        athlete_access_scope,
        max_athlete_profiles,
        signed_by
      ) VALUES (
        ${sandboxId},
        ${dataSourcesAllowed},
        ${useCasesAllowed},
        ${athleteAccessScope},
        ${maxAthleteProfiles},
        ${session.user.id}
      )
    `;

    // Log sandbox creation
    await sql`
      INSERT INTO sandbox_audit_logs (
        log_id,
        tenant_id,
        sandbox_id,
        user_id,
        action,
        resource_type,
        resource_id,
        response_status
      ) VALUES (
        ${uuidv4()},
        ${tenantId},
        ${sandboxId},
        ${session.user.id},
        'sandbox.created',
        'sandbox',
        ${sandboxId},
        'success'
      )
    `;

    return Response.json({
      success: true,
      sandboxId,
      expiresAt,
      message: "Sandbox created successfully",
    });
  } catch (error) {
    console.error("Error creating sandbox:", error);
    return Response.json(
      { error: "Failed to create sandbox" },
      { status: 500 },
    );
  }
}
