import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Entertainment Industry Campaign Management
// Music: Concert tours, festival activations, streaming releases
// Acting: Film releases, TV premieres, digital asset licensing

export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      tenantId,
      sandboxId,
      campaignName,
      campaignType, // 'concert_tour', 'film_release', 'streaming_launch', 'digital_licensing', 'festival_activation'
      industry, // 'music' or 'acting'
      objective,
      targetAudience,
      budgetApex,
      startAt,
      endAt,
      targetArtists, // Array of artist/actor IDs
      performanceMetrics, // What to track
      expectedROI,
    } = await req.json();

    if (
      !tenantId ||
      !sandboxId ||
      !campaignName ||
      !campaignType ||
      !industry
    ) {
      return Response.json(
        {
          error:
            "Tenant ID, sandbox ID, campaign name, type, and industry required",
        },
        { status: 400 },
      );
    }

    // Verify tenant access
    const [tenantAccess] = await sql`
      SELECT * FROM user_tenant_mappings
      WHERE user_id = ${session.user.id}
      AND tenant_id = ${tenantId}
    `;

    if (!tenantAccess) {
      return Response.json(
        { error: "No access to this tenant" },
        { status: 403 },
      );
    }

    // Generate campaign ID
    const campaignId = `campaign_${industry}_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    // Create campaign
    const [campaign] = await sql`
      INSERT INTO sandbox_campaigns (
        campaign_id,
        tenant_id,
        sandbox_id,
        campaign_name,
        objective,
        target_audience,
        budget_apex,
        start_at,
        end_at,
        status,
        metadata
      ) VALUES (
        ${campaignId},
        ${tenantId},
        ${sandboxId},
        ${campaignName},
        ${objective || "engagement"},
        ${JSON.stringify(targetAudience || {})},
        ${budgetApex || 500},
        ${startAt},
        ${endAt},
        'draft',
        ${JSON.stringify({
          industry,
          campaignType,
          targetArtists: targetArtists || [],
          performanceMetrics: performanceMetrics || [],
          expectedROI: expectedROI || {},
          createdBy: session.user.id,
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      campaign,
      campaignId,
      message: `${industry} campaign created successfully`,
    });
  } catch (error) {
    console.error("Create entertainment campaign error:", error);
    return Response.json(
      { error: "Failed to create campaign" },
      { status: 500 },
    );
  }
}

// GET: List entertainment campaigns
export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const tenantId = url.searchParams.get("tenantId");
    const sandboxId = url.searchParams.get("sandboxId");
    const industry = url.searchParams.get("industry");
    const status = url.searchParams.get("status");

    let query = `
      SELECT 
        sc.*,
        t.tenant_name,
        s.sandbox_name
      FROM sandbox_campaigns sc
      JOIN tenants t ON sc.tenant_id = t.tenant_id
      JOIN sandboxes s ON sc.sandbox_id = s.sandbox_id
      JOIN user_tenant_mappings utm ON sc.tenant_id = utm.tenant_id
      WHERE utm.user_id = $1
    `;
    const params = [session.user.id];
    let paramIndex = 2;

    if (tenantId) {
      query += ` AND sc.tenant_id = $${paramIndex}`;
      params.push(tenantId);
      paramIndex++;
    }

    if (sandboxId) {
      query += ` AND sc.sandbox_id = $${paramIndex}`;
      params.push(sandboxId);
      paramIndex++;
    }

    if (industry) {
      query += ` AND sc.metadata->>'industry' = $${paramIndex}`;
      params.push(industry);
      paramIndex++;
    }

    if (status) {
      query += ` AND sc.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    query += " ORDER BY sc.created_at DESC LIMIT 50";

    const campaigns = await sql(query, params);

    return Response.json({ campaigns });
  } catch (error) {
    console.error("Get entertainment campaigns error:", error);
    return Response.json(
      { error: "Failed to fetch campaigns" },
      { status: 500 },
    );
  }
}

// PUT: Activate campaign
export async function PUT(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { campaignId, action } = await req.json();

    if (!campaignId || !action) {
      return Response.json(
        { error: "Campaign ID and action required" },
        { status: 400 },
      );
    }

    // Verify access
    const [campaign] = await sql`
      SELECT sc.* FROM sandbox_campaigns sc
      JOIN user_tenant_mappings utm ON sc.tenant_id = utm.tenant_id
      WHERE sc.campaign_id = ${campaignId}
      AND utm.user_id = ${session.user.id}
    `;

    if (!campaign) {
      return Response.json(
        { error: "Campaign not found or no access" },
        { status: 404 },
      );
    }

    let newStatus;
    if (action === "activate") newStatus = "active";
    else if (action === "pause") newStatus = "paused";
    else if (action === "complete") newStatus = "completed";
    else if (action === "cancel") newStatus = "cancelled";

    const [updated] = await sql`
      UPDATE sandbox_campaigns
      SET status = ${newStatus},
          updated_at = CURRENT_TIMESTAMP
      WHERE campaign_id = ${campaignId}
      RETURNING *
    `;

    return Response.json({
      success: true,
      campaign: updated,
      message: `Campaign ${action}d successfully`,
    });
  } catch (error) {
    console.error("Update campaign error:", error);
    return Response.json(
      { error: "Failed to update campaign" },
      { status: 500 },
    );
  }
}
