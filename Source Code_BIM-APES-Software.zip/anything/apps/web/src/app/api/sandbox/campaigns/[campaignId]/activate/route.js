import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * CAMPAIGN ACTIVATION API
 * Activate a draft campaign
 */

async function validateCampaignAccess(campaignId, tenantId) {
  const campaign = await sql`
    SELECT c.*, s.status as sandbox_status, s.apex_budget, s.apex_spent
    FROM sandbox_campaigns c
    JOIN sandboxes s ON c.sandbox_id = s.sandbox_id
    WHERE c.campaign_id = ${campaignId} AND c.tenant_id = ${tenantId}
  `;

  if (campaign.length === 0) {
    return { valid: false, error: "Campaign not found or access denied" };
  }

  return { valid: true, campaign: campaign[0] };
}

async function logAuditTrail(
  tenantId,
  sandboxId,
  userId,
  action,
  resourceType,
  resourceId,
  payload,
  status,
) {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO sandbox_audit_logs (
      log_id, tenant_id, sandbox_id, user_id, action,
      resource_type, resource_id, request_payload, response_status
    ) VALUES (
      ${logId}, ${tenantId}, ${sandboxId}, ${userId}, ${action},
      ${resourceType}, ${resourceId}, ${JSON.stringify(payload)}, ${status}
    )
  `;
}

// POST - Activate campaign
export async function POST(req, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { campaignId } = params;
    const body = await req.json();
    const { tenantId } = body;

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required field: tenantId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(campaignId, tenantId);
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // Validate campaign can be activated
    if (campaign.status !== "draft" && campaign.status !== "paused") {
      return Response.json(
        {
          error: `Campaign cannot be activated. Current status: ${campaign.status}`,
        },
        { status: 400 },
      );
    }

    // Validate sandbox is active
    if (campaign.sandbox_status !== "active") {
      return Response.json(
        {
          error: "Sandbox is not active",
        },
        { status: 403 },
      );
    }

    // Validate dates
    const now = new Date();
    const startDate = new Date(campaign.start_at);
    const endDate = new Date(campaign.end_at);

    if (endDate < now) {
      return Response.json(
        {
          error:
            "Campaign end date has passed. Update the campaign dates first.",
        },
        { status: 400 },
      );
    }

    // Validate sandbox has enough budget
    const availableBudget =
      parseFloat(campaign.apex_budget) - parseFloat(campaign.apex_spent || 0);
    const campaignBudget = parseFloat(campaign.budget_apex);

    if (campaignBudget > availableBudget) {
      return Response.json(
        {
          error: `Insufficient sandbox budget. Available: ${availableBudget.toFixed(2)}, Required: ${campaignBudget.toFixed(2)}`,
        },
        { status: 400 },
      );
    }

    // Activate campaign
    await sql`
      UPDATE sandbox_campaigns
      SET status = 'active', updated_at = NOW()
      WHERE campaign_id = ${campaignId} AND tenant_id = ${tenantId}
    `;

    // Log audit trail
    await logAuditTrail(
      tenantId,
      campaign.sandbox_id,
      session.user.id,
      "campaign_activated",
      "campaign",
      campaignId,
      { previousStatus: campaign.status },
      "success",
    );

    // Get updated campaign
    const updatedCampaign = await sql`
      SELECT * FROM sandbox_campaigns
      WHERE campaign_id = ${campaignId}
    `;

    return Response.json({
      success: true,
      campaign: updatedCampaign[0],
      message: "Campaign activated successfully",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign activation error:", error);
    return Response.json(
      {
        error: "Failed to activate campaign",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
