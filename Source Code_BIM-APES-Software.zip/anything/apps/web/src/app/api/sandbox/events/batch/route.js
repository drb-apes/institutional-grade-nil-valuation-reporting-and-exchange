import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * BATCH EVENT INGESTION API
 * Efficiently ingest multiple events in a single request
 *
 * Use cases:
 * - Bulk imports from external systems
 * - Offline sync from mobile devices
 * - Historical data migration
 * - High-volume event streams
 */

// Import validation logic from main events route
async function validateSandboxAccess(tenantId, sandboxId) {
  const sandbox = await sql`
    SELECT s.*, sc.data_sources_allowed, sc.use_cases_allowed, sc.athlete_access_scope
    FROM sandboxes s
    LEFT JOIN sandbox_contracts sc ON s.sandbox_id = sc.sandbox_id
    WHERE s.sandbox_id = ${sandboxId} AND s.tenant_id = ${tenantId} AND s.status = 'active'
  `;

  if (sandbox.length === 0) {
    return { valid: false, error: "Sandbox not found or access denied" };
  }

  if (sandbox[0].expires_at && new Date(sandbox[0].expires_at) < new Date()) {
    return { valid: false, error: "Sandbox has expired" };
  }

  return { valid: true, sandbox: sandbox[0] };
}

async function logAuditTrail(
  tenantId,
  sandboxId,
  userId,
  action,
  resourceType,
  resourceId,
  payload,
  status,
) {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO sandbox_audit_logs (
      log_id, tenant_id, sandbox_id, user_id, action,
      resource_type, resource_id, request_payload, response_status
    ) VALUES (
      ${logId}, ${tenantId}, ${sandboxId}, ${userId}, ${action},
      ${resourceType}, ${resourceId}, ${JSON.stringify(payload)}, ${status}
    )
  `;
}

// POST - Batch ingest events
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { tenantId, sandboxId, events } = body;

    // Validate required fields
    if (!tenantId || !sandboxId || !events || !Array.isArray(events)) {
      return Response.json(
        {
          error: "Missing required fields: tenantId, sandboxId, events (array)",
        },
        { status: 400 },
      );
    }

    if (events.length === 0) {
      return Response.json(
        { error: "Events array cannot be empty" },
        { status: 400 },
      );
    }

    if (events.length > 1000) {
      return Response.json(
        {
          error: "Maximum 1000 events per batch request",
        },
        { status: 400 },
      );
    }

    // Validate sandbox access once for the entire batch
    const sandboxValidation = await validateSandboxAccess(tenantId, sandboxId);
    if (!sandboxValidation.valid) {
      await logAuditTrail(
        tenantId,
        sandboxId,
        session.user.id,
        "batch_ingestion_denied",
        "sandbox",
        sandboxId,
        { reason: sandboxValidation.error, eventCount: events.length },
        "denied",
      );
      return Response.json({ error: sandboxValidation.error }, { status: 403 });
    }

    // Process events in batch
    const results = {
      success: [],
      failed: [],
      total: events.length,
    };

    const timestamp = new Date().toISOString();

    for (const event of events) {
      try {
        const {
          athleteProfileId,
          eventType,
          payload,
          correlationId,
          sourceSystem,
          eventTimestamp,
        } = event;

        if (!eventType || !payload) {
          results.failed.push({
            event,
            error: "Missing required fields: eventType, payload",
          });
          continue;
        }

        const eventId = `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        await sql`
          INSERT INTO sandbox_events (
            event_id, tenant_id, sandbox_id, athlete_profile_id,
            event_type, event_timestamp, payload, source_system,
            correlation_id, is_anonymized
          ) VALUES (
            ${eventId}, ${tenantId}, ${sandboxId}, ${athleteProfileId || null},
            ${eventType}, ${eventTimestamp || timestamp}, ${JSON.stringify(payload)},
            ${sourceSystem || "batch_api"}, ${correlationId || eventId}, ${false}
          )
        `;

        results.success.push({
          eventId,
          eventType,
          timestamp: eventTimestamp || timestamp,
        });
      } catch (error) {
        results.failed.push({
          event,
          error: error.message,
        });
      }
    }

    // Log audit trail for batch operation
    await logAuditTrail(
      tenantId,
      sandboxId,
      session.user.id,
      "batch_events_ingested",
      "events",
      sandboxId,
      {
        totalEvents: events.length,
        successCount: results.success.length,
        failedCount: results.failed.length,
      },
      "success",
    );

    return Response.json({
      success: true,
      tenantId,
      sandboxId,
      results,
      summary: {
        total: results.total,
        succeeded: results.success.length,
        failed: results.failed.length,
        successRate:
          ((results.success.length / results.total) * 100).toFixed(2) + "%",
      },
      timestamp,
    });
  } catch (error) {
    console.error("Batch event ingestion error:", error);
    return Response.json(
      {
        error: "Failed to ingest batch events",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
