import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * CAMPAIGN MANAGEMENT API
 * Create and manage sponsor campaigns across sandboxes
 *
 * Features:
 * - Campaign creation with objectives & budgets
 * - Target audience segmentation
 * - APEX credit allocation
 * - Campaign lifecycle management
 * - Multi-campaign orchestration
 */

async function validateSandboxAccess(tenantId, sandboxId) {
  const sandbox = await sql`
    SELECT s.* FROM sandboxes s
    WHERE s.sandbox_id = ${sandboxId} AND s.tenant_id = ${tenantId} AND s.status = 'active'
  `;

  if (sandbox.length === 0) {
    return { valid: false, error: "Sandbox not found or access denied" };
  }

  return { valid: true, sandbox: sandbox[0] };
}

async function logAuditTrail(
  tenantId,
  sandboxId,
  userId,
  action,
  resourceType,
  resourceId,
  payload,
  status,
) {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO sandbox_audit_logs (
      log_id, tenant_id, sandbox_id, user_id, action,
      resource_type, resource_id, request_payload, response_status
    ) VALUES (
      ${logId}, ${tenantId}, ${sandboxId}, ${userId}, ${action},
      ${resourceType}, ${resourceId}, ${JSON.stringify(payload)}, ${status}
    )
  `;
}

// Validate campaign budget against sandbox limits
async function validateCampaignBudget(tenantId, sandboxId, requestedBudget) {
  // Get sandbox budget limits
  const sandbox = await sql`
    SELECT apex_budget, apex_spent FROM sandboxes
    WHERE sandbox_id = ${sandboxId} AND tenant_id = ${tenantId}
  `;

  if (sandbox.length === 0) {
    return { valid: false, error: "Sandbox not found" };
  }

  const availableBudget =
    parseFloat(sandbox[0].apex_budget) - parseFloat(sandbox[0].apex_spent || 0);

  if (requestedBudget > availableBudget) {
    return {
      valid: false,
      error: `Insufficient APEX budget. Available: ${availableBudget.toFixed(2)}, Requested: ${requestedBudget.toFixed(2)}`,
    };
  }

  return { valid: true, availableBudget };
}

// POST - Create new campaign
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      tenantId,
      sandboxId,
      campaignName,
      objective,
      targetAudience,
      budgetApex,
      startAt,
      endAt,
      metadata,
    } = body;

    // Validate required fields
    if (
      !tenantId ||
      !sandboxId ||
      !campaignName ||
      !objective ||
      !budgetApex ||
      !startAt ||
      !endAt
    ) {
      return Response.json(
        {
          error:
            "Missing required fields: tenantId, sandboxId, campaignName, objective, budgetApex, startAt, endAt",
        },
        { status: 400 },
      );
    }

    // Validate objective
    const validObjectives = [
      "awareness",
      "engagement",
      "conversion",
      "retention",
      "research",
    ];
    if (!validObjectives.includes(objective)) {
      return Response.json(
        {
          error: `Invalid objective. Must be one of: ${validObjectives.join(", ")}`,
        },
        { status: 400 },
      );
    }

    // Validate dates
    const start = new Date(startAt);
    const end = new Date(endAt);
    if (end <= start) {
      return Response.json(
        { error: "End date must be after start date" },
        { status: 400 },
      );
    }

    // Validate sandbox access
    const sandboxValidation = await validateSandboxAccess(tenantId, sandboxId);
    if (!sandboxValidation.valid) {
      return Response.json({ error: sandboxValidation.error }, { status: 403 });
    }

    // Validate budget
    const budgetValidation = await validateCampaignBudget(
      tenantId,
      sandboxId,
      budgetApex,
    );
    if (!budgetValidation.valid) {
      return Response.json({ error: budgetValidation.error }, { status: 400 });
    }

    // Create campaign
    const campaignId = `camp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    await sql`
      INSERT INTO sandbox_campaigns (
        campaign_id, tenant_id, sandbox_id, campaign_name,
        objective, target_audience, budget_apex, spent_apex,
        start_at, end_at, status, metadata
      ) VALUES (
        ${campaignId}, ${tenantId}, ${sandboxId}, ${campaignName},
        ${objective}, ${JSON.stringify(targetAudience || {})}, ${budgetApex}, ${0},
        ${startAt}, ${endAt}, ${"draft"}, ${JSON.stringify(metadata || {})}
      )
    `;

    // Log audit trail
    await logAuditTrail(
      tenantId,
      sandboxId,
      session.user.id,
      "campaign_created",
      "campaign",
      campaignId,
      { campaignName, objective, budgetApex },
      "success",
    );

    // Get created campaign
    const campaign = await sql`
      SELECT * FROM sandbox_campaigns
      WHERE campaign_id = ${campaignId}
    `;

    return Response.json({
      success: true,
      campaign: campaign[0],
      message: "Campaign created successfully",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign creation error:", error);
    return Response.json(
      {
        error: "Failed to create campaign",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// GET - List campaigns
export async function GET(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get("tenantId");
    const sandboxId = searchParams.get("sandboxId");
    const status = searchParams.get("status");
    const objective = searchParams.get("objective");
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required parameter: tenantId",
        },
        { status: 400 },
      );
    }

    // Build dynamic query
    let queryParts = ["SELECT * FROM sandbox_campaigns WHERE tenant_id = $1"];
    let params = [tenantId];
    let paramIndex = 2;

    if (sandboxId) {
      queryParts.push(`AND sandbox_id = $${paramIndex++}`);
      params.push(sandboxId);
    }

    if (status) {
      queryParts.push(`AND status = $${paramIndex++}`);
      params.push(status);
    }

    if (objective) {
      queryParts.push(`AND objective = $${paramIndex++}`);
      params.push(objective);
    }

    queryParts.push("ORDER BY created_at DESC");
    queryParts.push(`LIMIT $${paramIndex++} OFFSET $${paramIndex++}`);
    params.push(limit, offset);

    const query = queryParts.join(" ");
    const campaigns = await sql(query, params);

    // Get total count for pagination
    let countQueryParts = [
      "SELECT COUNT(*) as total FROM sandbox_campaigns WHERE tenant_id = $1",
    ];
    let countParams = [tenantId];
    let countParamIndex = 2;

    if (sandboxId) {
      countQueryParts.push(`AND sandbox_id = $${countParamIndex++}`);
      countParams.push(sandboxId);
    }

    if (status) {
      countQueryParts.push(`AND status = $${countParamIndex++}`);
      countParams.push(status);
    }

    if (objective) {
      countQueryParts.push(`AND objective = $${countParamIndex++}`);
      countParams.push(objective);
    }

    const countQuery = countQueryParts.join(" ");
    const countResult = await sql(countQuery, countParams);
    const totalCount = parseInt(countResult[0].total);

    return Response.json({
      success: true,
      campaigns,
      pagination: {
        total: totalCount,
        limit,
        offset,
        pages: Math.ceil(totalCount / limit),
      },
      filters: { tenantId, sandboxId, status, objective },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign list error:", error);
    return Response.json(
      {
        error: "Failed to list campaigns",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
