import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { v4 as uuidv4 } from "crypto";

// GET /api/sandbox/tenants - List all tenants for current user
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Get all tenants the user has access to
    const tenants = await sql`
      SELECT 
        t.*,
        utm.role_in_tenant,
        utm.permissions,
        tp.nil_tier,
        tp.max_athlete_access,
        tp.max_concurrent_sandboxes,
        tp.max_campaigns_per_sandbox
      FROM tenants t
      INNER JOIN user_tenant_mappings utm ON t.tenant_id = utm.tenant_id
      LEFT JOIN tenant_profiles tp ON t.tenant_id = tp.tenant_id
      WHERE utm.user_id = ${userId}
        AND t.is_active = true
      ORDER BY t.created_at DESC
    `;

    return Response.json({
      success: true,
      tenants: tenants.map((t) => ({
        tenantId: t.tenant_id,
        tenantName: t.tenant_name,
        tenantType: t.tenant_type,
        tierLevel: t.tier_level,
        roleInTenant: t.role_in_tenant,
        apexCreditBalance: parseFloat(t.apex_credit_balance),
        monthlyApexLimit: parseFloat(t.monthly_apex_limit),
        sportFocus: t.sport_focus,
        allowedDataDomains: t.allowed_data_domains,
        nilTier: t.nil_tier,
        maxAthleteAccess: t.max_athlete_access,
        maxConcurrentSandboxes: t.max_concurrent_sandboxes,
        maxCampaignsPerSandbox: t.max_campaigns_per_sandbox,
        createdAt: t.created_at,
      })),
    });
  } catch (error) {
    console.error("Error fetching tenants:", error);
    return Response.json({ error: "Failed to fetch tenants" }, { status: 500 });
  }
}

// POST /api/sandbox/tenants - Create a new tenant
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      tenantName,
      tenantType,
      tierLevel = "standard",
      contactEmail,
      contactPhone,
      sportFocus = [],
      allowedDataDomains = [],
      nilTier = "tier_1",
      maxAthleteAccess = 100,
      maxConcurrentSandboxes = 3,
      maxCampaignsPerSandbox = 10,
    } = body;

    if (!tenantName || !tenantType) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const tenantId = `${tenantType}_${uuidv4().slice(0, 8)}`;

    // Create tenant
    await sql`
      INSERT INTO tenants (
        tenant_id,
        tenant_type,
        tenant_name,
        contact_email,
        contact_phone,
        tier_level,
        sport_focus,
        allowed_data_domains,
        apex_credit_balance,
        monthly_apex_limit
      ) VALUES (
        ${tenantId},
        ${tenantType},
        ${tenantName},
        ${contactEmail},
        ${contactPhone},
        ${tierLevel},
        ${sportFocus},
        ${JSON.stringify(allowedDataDomains)},
        ${tierLevel === "enterprise" ? 50000 : tierLevel === "premium" ? 25000 : 10000},
        ${tierLevel === "enterprise" ? 50000 : tierLevel === "premium" ? 25000 : 10000}
      )
    `;

    // Create tenant profile
    await sql`
      INSERT INTO tenant_profiles (
        tenant_id,
        nil_tier,
        max_athlete_access,
        max_concurrent_sandboxes,
        max_campaigns_per_sandbox
      ) VALUES (
        ${tenantId},
        ${nilTier},
        ${maxAthleteAccess},
        ${maxConcurrentSandboxes},
        ${maxCampaignsPerSandbox}
      )
    `;

    // Map current user as owner
    await sql`
      INSERT INTO user_tenant_mappings (
        user_id,
        tenant_id,
        role_in_tenant,
        permissions
      ) VALUES (
        ${session.user.id},
        ${tenantId},
        'owner',
        ${JSON.stringify({ all: true })}
      )
    `;

    return Response.json({
      success: true,
      tenantId,
      message: "Tenant created successfully",
    });
  } catch (error) {
    console.error("Error creating tenant:", error);
    return Response.json({ error: "Failed to create tenant" }, { status: 500 });
  }
}
