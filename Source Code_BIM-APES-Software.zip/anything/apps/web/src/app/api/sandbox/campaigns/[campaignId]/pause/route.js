import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * CAMPAIGN PAUSE API
 * Pause an active campaign
 */

async function validateCampaignAccess(campaignId, tenantId) {
  const campaign = await sql`
    SELECT c.*
    FROM sandbox_campaigns c
    WHERE c.campaign_id = ${campaignId} AND c.tenant_id = ${tenantId}
  `;

  if (campaign.length === 0) {
    return { valid: false, error: "Campaign not found or access denied" };
  }

  return { valid: true, campaign: campaign[0] };
}

async function logAuditTrail(
  tenantId,
  sandboxId,
  userId,
  action,
  resourceType,
  resourceId,
  payload,
  status,
) {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO sandbox_audit_logs (
      log_id, tenant_id, sandbox_id, user_id, action,
      resource_type, resource_id, request_payload, response_status
    ) VALUES (
      ${logId}, ${tenantId}, ${sandboxId}, ${userId}, ${action},
      ${resourceType}, ${resourceId}, ${JSON.stringify(payload)}, ${status}
    )
  `;
}

// POST - Pause campaign
export async function POST(req, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { campaignId } = params;
    const body = await req.json();
    const { tenantId } = body;

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required field: tenantId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(campaignId, tenantId);
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // Can only pause active campaigns
    if (campaign.status !== "active") {
      return Response.json(
        {
          error: `Campaign cannot be paused. Current status: ${campaign.status}`,
        },
        { status: 400 },
      );
    }

    // Pause campaign
    await sql`
      UPDATE sandbox_campaigns
      SET status = 'paused', updated_at = NOW()
      WHERE campaign_id = ${campaignId} AND tenant_id = ${tenantId}
    `;

    // Log audit trail
    await logAuditTrail(
      tenantId,
      campaign.sandbox_id,
      session.user.id,
      "campaign_paused",
      "campaign",
      campaignId,
      { previousStatus: campaign.status },
      "success",
    );

    // Get updated campaign
    const updatedCampaign = await sql`
      SELECT * FROM sandbox_campaigns
      WHERE campaign_id = ${campaignId}
    `;

    return Response.json({
      success: true,
      campaign: updatedCampaign[0],
      message: "Campaign paused successfully",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign pause error:", error);
    return Response.json(
      {
        error: "Failed to pause campaign",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
