import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * CAMPAIGN PERFORMANCE API
 * Real-time campaign performance metrics and ROI analysis
 *
 * Metrics:
 * - Conversion funnel (Exposure → Engagement → Conversion)
 * - Event volume trends
 * - Cost per event/conversion
 * - ROI calculations
 * - Athlete engagement breakdown
 * - Temporal performance patterns
 */

async function validateCampaignAccess(campaignId, tenantId) {
  const campaign = await sql`
    SELECT c.*
    FROM sandbox_campaigns c
    WHERE c.campaign_id = ${campaignId} AND c.tenant_id = ${tenantId}
  `;

  if (campaign.length === 0) {
    return { valid: false, error: "Campaign not found or access denied" };
  }

  return { valid: true, campaign: campaign[0] };
}

// GET - Campaign performance metrics
export async function GET(req, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { campaignId } = params;
    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get("tenantId");

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required parameter: tenantId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(campaignId, tenantId);
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // 1. Conversion funnel metrics
    const funnelMetrics = await sql`
      SELECT 
        SUM(CASE WHEN event_type = 'exposure' THEN 1 ELSE 0 END) as exposures,
        SUM(CASE WHEN event_type = 'media_impression' THEN 1 ELSE 0 END) as impressions,
        SUM(CASE WHEN event_type = 'engagement' THEN 1 ELSE 0 END) as engagements,
        SUM(CASE WHEN event_type = 'qr_scan' THEN 1 ELSE 0 END) as qr_scans,
        SUM(CASE WHEN event_type = 'link_click' THEN 1 ELSE 0 END) as link_clicks,
        SUM(CASE WHEN event_type = 'conversion' THEN 1 ELSE 0 END) as conversions,
        SUM(CASE WHEN event_type = 'redemption' THEN 1 ELSE 0 END) as redemptions,
        COUNT(DISTINCT athlete_profile_id) as unique_athletes,
        COUNT(DISTINCT correlation_id) as unique_sessions
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
    `;

    const funnel = funnelMetrics[0];

    // Calculate conversion rates
    const exposureTotal =
      parseInt(funnel.exposures || 0) + parseInt(funnel.impressions || 0);
    const engagementRate =
      exposureTotal > 0
        ? ((parseInt(funnel.engagements) / exposureTotal) * 100).toFixed(2)
        : 0;
    const conversionRate =
      parseInt(funnel.engagements) > 0
        ? (
            (parseInt(funnel.conversions) / parseInt(funnel.engagements)) *
            100
          ).toFixed(2)
        : 0;
    const overallConversionRate =
      exposureTotal > 0
        ? ((parseInt(funnel.conversions) / exposureTotal) * 100).toFixed(2)
        : 0;

    // 2. Cost metrics
    const spentApex = parseFloat(campaign.spent_apex || 0);
    const totalEvents =
      exposureTotal +
      parseInt(funnel.engagements) +
      parseInt(funnel.conversions);
    const costPerEvent =
      totalEvents > 0 ? (spentApex / totalEvents).toFixed(2) : 0;
    const costPerConversion =
      parseInt(funnel.conversions) > 0
        ? (spentApex / parseInt(funnel.conversions)).toFixed(2)
        : 0;

    // 3. Daily performance trends
    const dailyTrends = await sql`
      SELECT 
        DATE(event_timestamp) as event_date,
        COUNT(*) as total_events,
        SUM(CASE WHEN event_type = 'exposure' THEN 1 ELSE 0 END) as exposures,
        SUM(CASE WHEN event_type = 'engagement' THEN 1 ELSE 0 END) as engagements,
        SUM(CASE WHEN event_type = 'conversion' THEN 1 ELSE 0 END) as conversions,
        COUNT(DISTINCT athlete_profile_id) as unique_athletes
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
      GROUP BY DATE(event_timestamp)
      ORDER BY event_date DESC
    `;

    // 4. Top performing athletes
    const topAthletes = await sql`
      SELECT 
        athlete_profile_id,
        COUNT(*) as total_events,
        SUM(CASE WHEN event_type = 'conversion' THEN 1 ELSE 0 END) as conversions,
        MAX(event_timestamp) as last_activity
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND athlete_profile_id IS NOT NULL
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
      GROUP BY athlete_profile_id
      ORDER BY conversions DESC, total_events DESC
      LIMIT 10
    `;

    // 5. Event type distribution
    const eventDistribution = await sql`
      SELECT 
        event_type,
        COUNT(*) as event_count,
        (COUNT(*) * 100.0 / SUM(COUNT(*)) OVER ()) as percentage
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
      GROUP BY event_type
      ORDER BY event_count DESC
    `;

    // 6. Hourly activity patterns
    const hourlyPatterns = await sql`
      SELECT 
        EXTRACT(HOUR FROM event_timestamp) as hour_of_day,
        COUNT(*) as event_count,
        AVG(CASE WHEN event_type = 'conversion' THEN 1.0 ELSE 0.0 END) as conversion_rate
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
      GROUP BY EXTRACT(HOUR FROM event_timestamp)
      ORDER BY hour_of_day
    `;

    // 7. Campaign health score
    const budgetUsageRate =
      (spentApex / parseFloat(campaign.budget_apex)) * 100;
    const now = new Date();
    const start = new Date(campaign.start_at);
    const end = new Date(campaign.end_at);
    const totalDuration = end - start;
    const elapsed = Math.min(now - start, totalDuration);
    const timeProgress =
      totalDuration > 0 ? (elapsed / totalDuration) * 100 : 0;

    const paceHealth =
      budgetUsageRate <= timeProgress + 10 &&
      budgetUsageRate >= timeProgress - 10
        ? "on_track"
        : budgetUsageRate > timeProgress + 10
          ? "overspending"
          : "underspending";

    const performanceHealth =
      parseFloat(overallConversionRate) > 2
        ? "excellent"
        : parseFloat(overallConversionRate) > 1
          ? "good"
          : parseFloat(overallConversionRate) > 0.5
            ? "fair"
            : "needs_improvement";

    return Response.json({
      success: true,
      campaignId,
      campaign: {
        name: campaign.campaign_name,
        objective: campaign.objective,
        status: campaign.status,
        budget: parseFloat(campaign.budget_apex),
        spent: spentApex,
        startDate: campaign.start_at,
        endDate: campaign.end_at,
      },
      performance: {
        funnel: {
          exposures: parseInt(funnel.exposures || 0),
          impressions: parseInt(funnel.impressions || 0),
          engagements: parseInt(funnel.engagements || 0),
          qrScans: parseInt(funnel.qr_scans || 0),
          linkClicks: parseInt(funnel.link_clicks || 0),
          conversions: parseInt(funnel.conversions || 0),
          redemptions: parseInt(funnel.redemptions || 0),
          rates: {
            engagementRate: `${engagementRate}%`,
            conversionRate: `${conversionRate}%`,
            overallConversionRate: `${overallConversionRate}%`,
          },
        },
        costs: {
          totalSpent: spentApex,
          costPerEvent: parseFloat(costPerEvent),
          costPerConversion: parseFloat(costPerConversion),
          budgetRemaining: parseFloat(campaign.budget_apex) - spentApex,
          budgetUsageRate: `${budgetUsageRate.toFixed(2)}%`,
        },
        reach: {
          uniqueAthletes: parseInt(funnel.unique_athletes || 0),
          uniqueSessions: parseInt(funnel.unique_sessions || 0),
          totalEvents: totalEvents,
        },
        health: {
          paceHealth,
          performanceHealth,
          timeProgress: `${timeProgress.toFixed(2)}%`,
          budgetProgress: `${budgetUsageRate.toFixed(2)}%`,
        },
      },
      analytics: {
        dailyTrends,
        topAthletes,
        eventDistribution,
        hourlyPatterns,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign performance error:", error);
    return Response.json(
      {
        error: "Failed to get campaign performance",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
