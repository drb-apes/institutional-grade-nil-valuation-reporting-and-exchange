import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * EVENT ANALYTICS API
 * Generate analytics and insights from sandbox events
 *
 * Provides:
 * - Event volume trends
 * - Conversion funnels
 * - Event type distribution
 * - Athlete engagement metrics
 * - Temporal patterns
 */

async function validateSandboxAccess(tenantId, sandboxId) {
  const sandbox = await sql`
    SELECT s.* FROM sandboxes s
    WHERE s.sandbox_id = ${sandboxId} AND s.tenant_id = ${tenantId} AND s.status = 'active'
  `;

  if (sandbox.length === 0) {
    return { valid: false, error: "Sandbox not found or access denied" };
  }

  return { valid: true, sandbox: sandbox[0] };
}

// GET - Event analytics
export async function GET(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get("tenantId");
    const sandboxId = searchParams.get("sandboxId");
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");

    if (!tenantId || !sandboxId) {
      return Response.json(
        {
          error: "Missing required parameters: tenantId, sandboxId",
        },
        { status: 400 },
      );
    }

    // Validate sandbox access
    const sandboxValidation = await validateSandboxAccess(tenantId, sandboxId);
    if (!sandboxValidation.valid) {
      return Response.json({ error: sandboxValidation.error }, { status: 403 });
    }

    // Build date filter
    let dateFilter = sql``;
    if (startDate && endDate) {
      dateFilter = sql`AND event_timestamp >= ${startDate} AND event_timestamp <= ${endDate}`;
    } else if (startDate) {
      dateFilter = sql`AND event_timestamp >= ${startDate}`;
    } else if (endDate) {
      dateFilter = sql`AND event_timestamp <= ${endDate}`;
    }

    // 1. Event volume by type
    const volumeByType = await sql`
      SELECT 
        event_type,
        COUNT(*) as event_count,
        COUNT(DISTINCT athlete_profile_id) as unique_athletes,
        COUNT(DISTINCT correlation_id) as unique_sessions
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        ${dateFilter}
      GROUP BY event_type
      ORDER BY event_count DESC
    `;

    // 2. Conversion funnel (exposure → engagement → conversion)
    const conversionFunnel = await sql`
      SELECT 
        SUM(CASE WHEN event_type = 'exposure' THEN 1 ELSE 0 END) as exposure_count,
        SUM(CASE WHEN event_type = 'engagement' THEN 1 ELSE 0 END) as engagement_count,
        SUM(CASE WHEN event_type = 'conversion' THEN 1 ELSE 0 END) as conversion_count,
        SUM(CASE WHEN event_type = 'qr_scan' THEN 1 ELSE 0 END) as qr_scan_count,
        SUM(CASE WHEN event_type = 'link_click' THEN 1 ELSE 0 END) as link_click_count,
        SUM(CASE WHEN event_type = 'redemption' THEN 1 ELSE 0 END) as redemption_count
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        ${dateFilter}
    `;

    // Calculate conversion rates
    const funnel = conversionFunnel[0];
    const conversionMetrics = {
      exposure: parseInt(funnel.exposure_count || 0),
      engagement: parseInt(funnel.engagement_count || 0),
      conversion: parseInt(funnel.conversion_count || 0),
      qrScans: parseInt(funnel.qr_scan_count || 0),
      linkClicks: parseInt(funnel.link_click_count || 0),
      redemptions: parseInt(funnel.redemption_count || 0),
      engagementRate:
        funnel.exposure_count > 0
          ? ((funnel.engagement_count / funnel.exposure_count) * 100).toFixed(
              2,
            ) + "%"
          : "0%",
      conversionRate:
        funnel.engagement_count > 0
          ? ((funnel.conversion_count / funnel.engagement_count) * 100).toFixed(
              2,
            ) + "%"
          : "0%",
      overallConversionRate:
        funnel.exposure_count > 0
          ? ((funnel.conversion_count / funnel.exposure_count) * 100).toFixed(
              2,
            ) + "%"
          : "0%",
    };

    // 3. Temporal patterns (events by hour of day)
    const temporalPatterns = await sql`
      SELECT 
        EXTRACT(HOUR FROM event_timestamp) as hour_of_day,
        COUNT(*) as event_count
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        ${dateFilter}
      GROUP BY EXTRACT(HOUR FROM event_timestamp)
      ORDER BY hour_of_day
    `;

    // 4. Top athletes by engagement
    const topAthletes = await sql`
      SELECT 
        athlete_profile_id,
        COUNT(*) as total_events,
        COUNT(DISTINCT event_type) as event_types,
        MAX(event_timestamp) as last_activity
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        AND athlete_profile_id IS NOT NULL
        ${dateFilter}
      GROUP BY athlete_profile_id
      ORDER BY total_events DESC
      LIMIT 10
    `;

    // 5. Daily event trends
    const dailyTrends = await sql`
      SELECT 
        DATE(event_timestamp) as event_date,
        COUNT(*) as total_events,
        COUNT(DISTINCT athlete_profile_id) as unique_athletes,
        COUNT(DISTINCT correlation_id) as unique_sessions
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        ${dateFilter}
      GROUP BY DATE(event_timestamp)
      ORDER BY event_date DESC
      LIMIT 30
    `;

    // 6. Data source breakdown
    const dataSourceBreakdown = await sql`
      SELECT 
        source_system,
        COUNT(*) as event_count,
        COUNT(DISTINCT event_type) as unique_event_types
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        ${dateFilter}
      GROUP BY source_system
      ORDER BY event_count DESC
    `;

    // 7. Anonymization stats
    const anonymizationStats = await sql`
      SELECT 
        is_anonymized,
        COUNT(*) as event_count,
        (COUNT(*) * 100.0 / SUM(COUNT(*)) OVER ()) as percentage
      FROM sandbox_events
      WHERE tenant_id = ${tenantId} 
        AND sandbox_id = ${sandboxId}
        ${dateFilter}
      GROUP BY is_anonymized
    `;

    return Response.json({
      success: true,
      tenantId,
      sandboxId,
      dateRange: { startDate, endDate },
      analytics: {
        volumeByType,
        conversionFunnel: conversionMetrics,
        temporalPatterns,
        topAthletes,
        dailyTrends,
        dataSourceBreakdown,
        anonymizationStats,
        summary: {
          totalEvents: volumeByType.reduce(
            (sum, row) => sum + parseInt(row.event_count),
            0,
          ),
          uniqueAthletes: topAthletes.length,
          eventTypes: volumeByType.length,
          dataSources: dataSourceBreakdown.length,
        },
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Event analytics error:", error);
    return Response.json(
      {
        error: "Failed to generate analytics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
