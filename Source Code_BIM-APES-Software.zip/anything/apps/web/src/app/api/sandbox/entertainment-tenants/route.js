import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

// Entertainment Industry Multi-Tenant Sandbox Management
// Supports: Music Venues (Live Nation, AEG), Studios (Warner, Paramount, Universal, Disney), Streaming Platforms

export async function POST(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      tenantName,
      tenantType, // 'music_venue', 'studio', 'streaming_platform', 'agency', 'label'
      industry, // 'music', 'acting', 'both'
      tierLevel,
      contactEmail,
      contactPhone,
      allowedDataDomains,
      sportFocus, // Will be 'music' or 'acting' industry types
      apexCreditBalance,
      monthlyApexLimit,
    } = await req.json();

    if (!tenantName || !tenantType || !industry) {
      return Response.json(
        {
          error: "Tenant name, type, and industry required",
        },
        { status: 400 },
      );
    }

    // Generate unique tenant ID
    const tenantId = `${tenantType}_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    // Create tenant
    const [tenant] = await sql`
      INSERT INTO tenants (
        tenant_id,
        tenant_type,
        tenant_name,
        contact_email,
        contact_phone,
        tier_level,
        allowed_data_domains,
        sport_focus,
        apex_credit_balance,
        monthly_apex_limit
      ) VALUES (
        ${tenantId},
        ${tenantType},
        ${tenantName},
        ${contactEmail || null},
        ${contactPhone || null},
        ${tierLevel || "standard"},
        ${JSON.stringify(allowedDataDomains || [])},
        ${JSON.stringify([industry])},
        ${apexCreditBalance || 1000},
        ${monthlyApexLimit || 10000}
      )
      RETURNING *
    `;

    // Create tenant profile with industry-specific settings
    const [profile] = await sql`
      INSERT INTO tenant_profiles (
        tenant_id,
        nil_tier,
        max_athlete_access,
        max_concurrent_sandboxes,
        max_campaigns_per_sandbox,
        allowed_export_formats,
        compliance_requirements
      ) VALUES (
        ${tenantId},
        'tier_2',
        ${industry === "both" ? 200 : 100},
        ${tierLevel === "premium" ? 10 : 5},
        ${tierLevel === "premium" ? 20 : 10},
        ARRAY['csv', 'json', 'pdf'],
        ${JSON.stringify({
          industry,
          requiresConsent: true,
          allowsDigitalDoubles: industry === "acting",
          allowsConcertData: industry === "music",
          complianceLevel: tierLevel === "premium" ? "enterprise" : "standard",
        })}
      )
      RETURNING *
    `;

    // Map user to tenant
    const [mapping] = await sql`
      INSERT INTO user_tenant_mappings (
        user_id,
        tenant_id,
        role_in_tenant,
        permissions
      ) VALUES (
        ${session.user.id},
        ${tenantId},
        'owner',
        ${JSON.stringify({
          canCreateSandboxes: true,
          canManageCampaigns: true,
          canAccessAnalytics: true,
          canExportData: true,
          canManageUsers: true,
        })}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      tenant,
      profile,
      tenantId,
      message: `Entertainment tenant ${tenantName} created successfully`,
    });
  } catch (error) {
    console.error("Create entertainment tenant error:", error);
    return Response.json({ error: "Failed to create tenant" }, { status: 500 });
  }
}

// GET: List entertainment tenants
export async function GET(req) {
  const session = await auth();
  if (!session?.user?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const industry = url.searchParams.get("industry"); // 'music' or 'acting'

    // Get tenants user has access to
    let tenants;
    if (industry) {
      tenants = await sql`
        SELECT 
          t.*,
          tp.nil_tier,
          tp.max_athlete_access,
          tp.max_concurrent_sandboxes,
          utm.role_in_tenant
        FROM tenants t
        JOIN tenant_profiles tp ON t.tenant_id = tp.tenant_id
        JOIN user_tenant_mappings utm ON t.tenant_id = utm.tenant_id
        WHERE utm.user_id = ${session.user.id}
        AND t.sport_focus::jsonb ? ${industry}
        AND t.is_active = true
        ORDER BY t.created_at DESC
      `;
    } else {
      tenants = await sql`
        SELECT 
          t.*,
          tp.nil_tier,
          tp.max_athlete_access,
          tp.max_concurrent_sandboxes,
          utm.role_in_tenant
        FROM tenants t
        JOIN tenant_profiles tp ON t.tenant_id = tp.tenant_id
        JOIN user_tenant_mappings utm ON t.tenant_id = utm.tenant_id
        WHERE utm.user_id = ${session.user.id}
        AND t.is_active = true
        ORDER BY t.created_at DESC
      `;
    }

    return Response.json({ tenants });
  } catch (error) {
    console.error("Get entertainment tenants error:", error);
    return Response.json({ error: "Failed to fetch tenants" }, { status: 500 });
  }
}
