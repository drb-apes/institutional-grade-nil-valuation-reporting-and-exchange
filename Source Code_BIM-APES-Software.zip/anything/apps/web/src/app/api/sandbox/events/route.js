import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * EVENT INGESTION API
 * Unified Schema Hub - All data flows through here
 *
 * Flow:
 * 1. Authenticate user
 * 2. Validate tenant + sandbox access
 * 3. Check consent state
 * 4. Validate event schema
 * 5. Enforce policy bundle
 * 6. Store event
 * 7. Log to audit trail
 * 8. Return confirmation
 */

// Event schema validators
const EVENT_SCHEMAS = {
  exposure: ["impression_id", "channel", "creative_id", "reach"],
  engagement: ["interaction_type", "duration_seconds", "device_type"],
  conversion: ["conversion_type", "value", "verified", "attribution_window"],
  biometric: ["metric_type", "value", "unit", "device_id", "session_id"],
  nil_update: ["update_type", "previous_value", "new_value", "source"],
  sponsor_activation: ["activation_type", "location", "participants"],
  media_impression: ["media_type", "platform", "reach", "engagement_score"],
  qr_scan: ["qr_code_id", "location", "device_type", "timestamp"],
  link_click: ["link_id", "destination_url", "referrer", "utm_params"],
  redemption: ["offer_id", "redemption_value", "location", "verified"],
  performance_milestone: ["milestone_type", "metric", "value", "verified_by"],
};

// Validate event payload against schema
function validateEventPayload(eventType, payload) {
  const requiredFields = EVENT_SCHEMAS[eventType];
  if (!requiredFields) {
    return { valid: false, error: `Unknown event type: ${eventType}` };
  }

  const missingFields = requiredFields.filter((field) => !(field in payload));
  if (missingFields.length > 0) {
    return {
      valid: false,
      error: `Missing required fields for ${eventType}: ${missingFields.join(", ")}`,
    };
  }

  return { valid: true };
}

// Check if tenant has access to sandbox
async function validateSandboxAccess(tenantId, sandboxId) {
  const sandbox = await sql`
    SELECT s.*, sc.data_sources_allowed, sc.use_cases_allowed, sc.athlete_access_scope
    FROM sandboxes s
    LEFT JOIN sandbox_contracts sc ON s.sandbox_id = sc.sandbox_id
    WHERE s.sandbox_id = ${sandboxId} AND s.tenant_id = ${tenantId} AND s.status = 'active'
  `;

  if (sandbox.length === 0) {
    return { valid: false, error: "Sandbox not found or access denied" };
  }

  if (sandbox[0].expires_at && new Date(sandbox[0].expires_at) < new Date()) {
    return { valid: false, error: "Sandbox has expired" };
  }

  return { valid: true, sandbox: sandbox[0] };
}

// Check consent state for athlete data
async function checkConsentState(
  athleteProfileId,
  tenantId,
  sandboxId,
  eventType,
  useCase,
) {
  if (!athleteProfileId) {
    // Aggregate/anonymous event - no consent check needed
    return { allowed: true, anonymize: false };
  }

  const consent = await sql`
    SELECT * FROM sandbox_consent_state
    WHERE athlete_profile_id = ${athleteProfileId}
      AND tenant_id = ${tenantId}
      AND sandbox_id = ${sandboxId}
      AND is_active = true
      AND (expiry_date IS NULL OR expiry_date > NOW())
  `;

  if (consent.length === 0) {
    // No consent found - deny or anonymize based on policy
    return {
      allowed: false,
      anonymize: true,
      reason: "No active consent found - data will be anonymized",
    };
  }

  const consentState = consent[0];

  // Check if use case is allowed
  if (
    useCase &&
    consentState.allowed_use_cases &&
    !consentState.allowed_use_cases.includes(useCase)
  ) {
    return {
      allowed: false,
      reason: `Use case '${useCase}' not permitted by athlete consent`,
    };
  }

  // Determine if anonymization is needed based on consent level
  const anonymizationRequired = ["tier_1"].includes(consentState.consent_level);

  return {
    allowed: true,
    anonymize: anonymizationRequired,
    consentLevel: consentState.consent_level,
  };
}

// Enforce policy bundle rules
function enforcePolicyBundle(sandbox, eventType, dataSource, useCase) {
  const contract = sandbox;

  // Check if event type is allowed
  const allowedEvents = contract.data_sources_allowed || [];
  if (dataSource && !allowedEvents.includes(dataSource)) {
    return {
      allowed: false,
      error: `Data source '${dataSource}' not permitted in this sandbox`,
    };
  }

  // Check if use case is allowed
  const allowedUseCases = contract.use_cases_allowed || [];
  if (useCase && !allowedUseCases.includes(useCase)) {
    return {
      allowed: false,
      error: `Use case '${useCase}' not permitted in this sandbox`,
    };
  }

  return { allowed: true };
}

// Anonymize athlete data
function anonymizePayload(payload, athleteProfileId) {
  return {
    ...payload,
    athlete_identifier: `anon_${athleteProfileId.toString().substring(0, 8)}`,
    pii_removed: true,
  };
}

// Log NIL governance decision
async function logGovernanceDecision(
  tenantId,
  sandboxId,
  athleteProfileId,
  decision,
  reason,
) {
  const decisionId = `nil_decision_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO nil_governance_decisions (
      decision_id, tenant_id, sandbox_id, athlete_profile_id,
      requested_action, requested_resource, decision, reason
    ) VALUES (
      ${decisionId}, ${tenantId}, ${sandboxId}, ${athleteProfileId},
      'event_ingestion', 'athlete_data', ${decision}, ${reason}
    )
  `;
}

// Log to audit trail
async function logAuditTrail(
  tenantId,
  sandboxId,
  userId,
  action,
  resourceType,
  resourceId,
  payload,
  status,
) {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO sandbox_audit_logs (
      log_id, tenant_id, sandbox_id, user_id, action,
      resource_type, resource_id, request_payload, response_status
    ) VALUES (
      ${logId}, ${tenantId}, ${sandboxId}, ${userId}, ${action},
      ${resourceType}, ${resourceId}, ${JSON.stringify(payload)}, ${status}
    )
  `;
}

// POST - Ingest event into unified schema hub
export async function POST(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      tenantId,
      sandboxId,
      athleteProfileId,
      eventType,
      payload,
      dataSource,
      useCase,
      correlationId,
      sourceSystem,
    } = body;

    // Validate required fields
    if (!tenantId || !sandboxId || !eventType || !payload) {
      return Response.json(
        {
          error:
            "Missing required fields: tenantId, sandboxId, eventType, payload",
        },
        { status: 400 },
      );
    }

    // 1. Validate tenant access to sandbox
    const sandboxValidation = await validateSandboxAccess(tenantId, sandboxId);
    if (!sandboxValidation.valid) {
      await logAuditTrail(
        tenantId,
        sandboxId,
        session.user.id,
        "event_ingestion_denied",
        "sandbox",
        sandboxId,
        { reason: sandboxValidation.error },
        "denied",
      );
      return Response.json({ error: sandboxValidation.error }, { status: 403 });
    }

    const sandbox = sandboxValidation.sandbox;

    // 2. Validate event schema
    const schemaValidation = validateEventPayload(eventType, payload);
    if (!schemaValidation.valid) {
      return Response.json({ error: schemaValidation.error }, { status: 400 });
    }

    // 3. Enforce policy bundle
    const policyCheck = enforcePolicyBundle(
      sandbox,
      eventType,
      dataSource,
      useCase,
    );
    if (!policyCheck.allowed) {
      await logAuditTrail(
        tenantId,
        sandboxId,
        session.user.id,
        "policy_violation",
        "event",
        eventType,
        { reason: policyCheck.error },
        "denied",
      );
      return Response.json({ error: policyCheck.error }, { status: 403 });
    }

    // 4. Check consent state (if athlete data involved)
    let finalPayload = payload;
    let isAnonymized = false;
    let consentDecision = null;

    if (athleteProfileId) {
      const consentCheck = await checkConsentState(
        athleteProfileId,
        tenantId,
        sandboxId,
        eventType,
        useCase,
      );

      if (!consentCheck.allowed && !consentCheck.anonymize) {
        await logGovernanceDecision(
          tenantId,
          sandboxId,
          athleteProfileId,
          "denied",
          consentCheck.reason,
        );
        await logAuditTrail(
          tenantId,
          sandboxId,
          session.user.id,
          "consent_denied",
          "athlete",
          athleteProfileId,
          { reason: consentCheck.reason },
          "denied",
        );
        return Response.json(
          {
            error: "Consent check failed",
            reason: consentCheck.reason,
          },
          { status: 403 },
        );
      }

      if (consentCheck.anonymize) {
        finalPayload = anonymizePayload(payload, athleteProfileId);
        isAnonymized = true;
        await logGovernanceDecision(
          tenantId,
          sandboxId,
          athleteProfileId,
          "anonymized",
          "Data anonymized per consent level",
        );
      } else {
        await logGovernanceDecision(
          tenantId,
          sandboxId,
          athleteProfileId,
          "approved",
          `Consent level: ${consentCheck.consentLevel}`,
        );
      }

      consentDecision = consentCheck;
    }

    // 5. Store event in unified schema hub
    const eventId = `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    await sql`
      INSERT INTO sandbox_events (
        event_id, tenant_id, sandbox_id, athlete_profile_id,
        event_type, event_timestamp, payload, source_system,
        correlation_id, is_anonymized
      ) VALUES (
        ${eventId}, ${tenantId}, ${sandboxId}, ${isAnonymized ? null : athleteProfileId},
        ${eventType}, ${new Date().toISOString()}, ${JSON.stringify(finalPayload)},
        ${sourceSystem || "api"}, ${correlationId || eventId}, ${isAnonymized}
      )
    `;

    // 6. Log to audit trail
    await logAuditTrail(
      tenantId,
      sandboxId,
      session.user.id,
      "event_ingested",
      "event",
      eventId,
      { eventType, dataSource, useCase, isAnonymized },
      "success",
    );

    // 7. Check APEX budget and trigger alert if needed
    const currentSpend = parseFloat(sandbox.apex_spent || 0);
    const budget = parseFloat(sandbox.apex_budget || 0);
    const spendPercentage = (currentSpend / budget) * 100;

    if (spendPercentage > 80) {
      // Trigger budget alert
      const alertId = `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await sql`
        INSERT INTO sandbox_alerts (
          alert_id, tenant_id, sandbox_id, alert_type, severity,
          message, context, status
        ) VALUES (
          ${alertId}, ${tenantId}, ${sandboxId}, 'apex_budget_threshold', 'high',
          ${`Sandbox has used ${spendPercentage.toFixed(1)}% of APEX budget`},
          ${JSON.stringify({ currentSpend, budget, percentage: spendPercentage })},
          'open'
        )
      `;
    }

    return Response.json({
      success: true,
      eventId,
      tenantId,
      sandboxId,
      eventType,
      timestamp: new Date().toISOString(),
      isAnonymized,
      consentDecision: consentDecision
        ? {
            allowed: consentDecision.allowed,
            consentLevel: consentDecision.consentLevel,
            anonymized: isAnonymized,
          }
        : null,
      message: "Event successfully ingested into unified schema hub",
    });
  } catch (error) {
    console.error("Event ingestion error:", error);
    return Response.json(
      {
        error: "Failed to ingest event",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// GET - Query events from sandbox
export async function GET(req) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get("tenantId");
    const sandboxId = searchParams.get("sandboxId");
    const eventType = searchParams.get("eventType");
    const athleteProfileId = searchParams.get("athleteProfileId");
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");
    const limit = parseInt(searchParams.get("limit") || "100");

    if (!tenantId || !sandboxId) {
      return Response.json(
        {
          error: "Missing required parameters: tenantId, sandboxId",
        },
        { status: 400 },
      );
    }

    // Validate sandbox access
    const sandboxValidation = await validateSandboxAccess(tenantId, sandboxId);
    if (!sandboxValidation.valid) {
      return Response.json({ error: sandboxValidation.error }, { status: 403 });
    }

    // Build dynamic query
    let queryParts = ["SELECT * FROM sandbox_events WHERE 1=1"];
    let params = [];
    let paramIndex = 1;

    queryParts.push(`AND tenant_id = $${paramIndex++}`);
    params.push(tenantId);

    queryParts.push(`AND sandbox_id = $${paramIndex++}`);
    params.push(sandboxId);

    if (eventType) {
      queryParts.push(`AND event_type = $${paramIndex++}`);
      params.push(eventType);
    }

    if (athleteProfileId) {
      queryParts.push(`AND athlete_profile_id = $${paramIndex++}`);
      params.push(parseInt(athleteProfileId));
    }

    if (startDate) {
      queryParts.push(`AND event_timestamp >= $${paramIndex++}`);
      params.push(startDate);
    }

    if (endDate) {
      queryParts.push(`AND event_timestamp <= $${paramIndex++}`);
      params.push(endDate);
    }

    queryParts.push("ORDER BY event_timestamp DESC");
    queryParts.push(`LIMIT $${paramIndex++}`);
    params.push(limit);

    const query = queryParts.join(" ");
    const events = await sql(query, params);

    // Log audit trail for query
    await logAuditTrail(
      tenantId,
      sandboxId,
      session.user.id,
      "events_queried",
      "events",
      sandboxId,
      { eventType, athleteProfileId, startDate, endDate, limit },
      "success",
    );

    return Response.json({
      success: true,
      events,
      count: events.length,
      filters: {
        tenantId,
        sandboxId,
        eventType,
        athleteProfileId,
        startDate,
        endDate,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Event query error:", error);
    return Response.json(
      {
        error: "Failed to query events",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
