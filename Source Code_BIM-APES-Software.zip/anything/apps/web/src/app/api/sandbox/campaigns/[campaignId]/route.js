import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

/**
 * INDIVIDUAL CAMPAIGN MANAGEMENT API
 * Manage specific campaign operations
 *
 * Operations:
 * - GET: Retrieve campaign details
 * - PUT: Update campaign
 * - DELETE: Cancel campaign
 */

async function validateCampaignAccess(campaignId, tenantId, userId) {
  const campaign = await sql`
    SELECT c.*, s.status as sandbox_status
    FROM sandbox_campaigns c
    JOIN sandboxes s ON c.sandbox_id = s.sandbox_id
    WHERE c.campaign_id = ${campaignId} AND c.tenant_id = ${tenantId}
  `;

  if (campaign.length === 0) {
    return { valid: false, error: "Campaign not found or access denied" };
  }

  return { valid: true, campaign: campaign[0] };
}

async function logAuditTrail(
  tenantId,
  sandboxId,
  userId,
  action,
  resourceType,
  resourceId,
  payload,
  status,
) {
  const logId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  await sql`
    INSERT INTO sandbox_audit_logs (
      log_id, tenant_id, sandbox_id, user_id, action,
      resource_type, resource_id, request_payload, response_status
    ) VALUES (
      ${logId}, ${tenantId}, ${sandboxId}, ${userId}, ${action},
      ${resourceType}, ${resourceId}, ${JSON.stringify(payload)}, ${status}
    )
  `;
}

// GET - Get campaign details
export async function GET(req, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { campaignId } = params;
    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get("tenantId");

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required parameter: tenantId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(
      campaignId,
      tenantId,
      session.user.id,
    );
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // Get campaign event counts
    const eventStats = await sql`
      SELECT 
        event_type,
        COUNT(*) as event_count
      FROM sandbox_events
      WHERE sandbox_id = ${campaign.sandbox_id}
        AND event_timestamp >= ${campaign.start_at}
        AND event_timestamp <= ${campaign.end_at}
      GROUP BY event_type
    `;

    // Calculate campaign metrics
    const totalEvents = eventStats.reduce(
      (sum, row) => sum + parseInt(row.event_count),
      0,
    );
    const spendPercentage = (
      (parseFloat(campaign.spent_apex) / parseFloat(campaign.budget_apex)) *
      100
    ).toFixed(2);

    const now = new Date();
    const start = new Date(campaign.start_at);
    const end = new Date(campaign.end_at);
    const totalDuration = end - start;
    const elapsed = Math.min(now - start, totalDuration);
    const timeProgress =
      totalDuration > 0 ? ((elapsed / totalDuration) * 100).toFixed(2) : 0;

    return Response.json({
      success: true,
      campaign,
      stats: {
        totalEvents,
        eventBreakdown: eventStats,
        budgetUsed: parseFloat(campaign.spent_apex),
        budgetRemaining:
          parseFloat(campaign.budget_apex) - parseFloat(campaign.spent_apex),
        spendPercentage: `${spendPercentage}%`,
        timeProgress: `${timeProgress}%`,
        daysRemaining: Math.max(
          0,
          Math.ceil((end - now) / (1000 * 60 * 60 * 24)),
        ),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign get error:", error);
    return Response.json(
      {
        error: "Failed to get campaign",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// PUT - Update campaign
export async function PUT(req, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { campaignId } = params;
    const body = await req.json();
    const {
      tenantId,
      campaignName,
      objective,
      targetAudience,
      budgetApex,
      startAt,
      endAt,
      metadata,
    } = body;

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required parameter: tenantId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(
      campaignId,
      tenantId,
      session.user.id,
    );
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // Can't update active or completed campaigns (except metadata)
    if (
      ["active", "completed"].includes(campaign.status) &&
      (campaignName || objective || budgetApex || startAt || endAt)
    ) {
      return Response.json(
        {
          error:
            "Cannot modify active or completed campaigns. Only metadata can be updated.",
        },
        { status: 400 },
      );
    }

    // Build update query dynamically
    const updates = [];
    const updateParams = [];
    let paramIndex = 1;

    if (campaignName) {
      updates.push(`campaign_name = $${paramIndex++}`);
      updateParams.push(campaignName);
    }

    if (objective) {
      const validObjectives = [
        "awareness",
        "engagement",
        "conversion",
        "retention",
        "research",
      ];
      if (!validObjectives.includes(objective)) {
        return Response.json(
          {
            error: `Invalid objective. Must be one of: ${validObjectives.join(", ")}`,
          },
          { status: 400 },
        );
      }
      updates.push(`objective = $${paramIndex++}`);
      updateParams.push(objective);
    }

    if (targetAudience) {
      updates.push(`target_audience = $${paramIndex++}`);
      updateParams.push(JSON.stringify(targetAudience));
    }

    if (budgetApex) {
      updates.push(`budget_apex = $${paramIndex++}`);
      updateParams.push(budgetApex);
    }

    if (startAt) {
      updates.push(`start_at = $${paramIndex++}`);
      updateParams.push(startAt);
    }

    if (endAt) {
      updates.push(`end_at = $${paramIndex++}`);
      updateParams.push(endAt);
    }

    if (metadata) {
      updates.push(`metadata = $${paramIndex++}`);
      updateParams.push(JSON.stringify(metadata));
    }

    updates.push(`updated_at = NOW()`);

    if (updates.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    // Add WHERE clause params
    updateParams.push(campaignId);
    updateParams.push(tenantId);

    const updateQuery = `
      UPDATE sandbox_campaigns 
      SET ${updates.join(", ")}
      WHERE campaign_id = $${paramIndex++} AND tenant_id = $${paramIndex++}
      RETURNING *
    `;

    const updatedCampaign = await sql(updateQuery, updateParams);

    // Log audit trail
    await logAuditTrail(
      tenantId,
      campaign.sandbox_id,
      session.user.id,
      "campaign_updated",
      "campaign",
      campaignId,
      { updates: Object.keys(body) },
      "success",
    );

    return Response.json({
      success: true,
      campaign: updatedCampaign[0],
      message: "Campaign updated successfully",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign update error:", error);
    return Response.json(
      {
        error: "Failed to update campaign",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// DELETE - Cancel campaign
export async function DELETE(req, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { campaignId } = params;
    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get("tenantId");

    if (!tenantId) {
      return Response.json(
        {
          error: "Missing required parameter: tenantId",
        },
        { status: 400 },
      );
    }

    // Validate campaign access
    const validation = await validateCampaignAccess(
      campaignId,
      tenantId,
      session.user.id,
    );
    if (!validation.valid) {
      return Response.json({ error: validation.error }, { status: 403 });
    }

    const campaign = validation.campaign;

    // Can't delete completed campaigns
    if (campaign.status === "completed") {
      return Response.json(
        {
          error: "Cannot delete completed campaigns",
        },
        { status: 400 },
      );
    }

    // Mark as cancelled instead of hard delete
    await sql`
      UPDATE sandbox_campaigns
      SET status = 'cancelled', updated_at = NOW()
      WHERE campaign_id = ${campaignId} AND tenant_id = ${tenantId}
    `;

    // Log audit trail
    await logAuditTrail(
      tenantId,
      campaign.sandbox_id,
      session.user.id,
      "campaign_cancelled",
      "campaign",
      campaignId,
      { previousStatus: campaign.status },
      "success",
    );

    return Response.json({
      success: true,
      message: "Campaign cancelled successfully",
      campaignId,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Campaign delete error:", error);
    return Response.json(
      {
        error: "Failed to cancel campaign",
        details: error.message,
      },
      { status: 500 },
    );
  }
}
