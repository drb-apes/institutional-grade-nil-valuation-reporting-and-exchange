import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Family Office Services
 *
 * Comprehensive financial planning for athletes and entertainers:
 * - Multi-generational wealth planning
 * - Tax optimization strategies
 * - Philanthropic advisory
 * - Estate planning
 * - Investment portfolio management
 * - Risk management & insurance
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      familySize: { required: false, type: "number" },
      annualIncome: { required: false, type: "number" },
      taxJurisdiction: { required: false, type: "string" },
      philanthropicGoals: { required: false, type: "object" },
    });

    const {
      athleteId,
      familySize = 1,
      annualIncome = 0,
      taxJurisdiction = "US",
      philanthropicGoals = {},
    } = body;

    // Get athlete profile
    const athlete = await sql`
      SELECT up.*, au.name, au.email
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId}
    `;

    if (athlete.length === 0) {
      return createSecureResponse(
        { error: "Athlete not found" },
        { status: 404 },
      );
    }

    // Get NIL account for current valuation
    const nilAccount = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE athlete_id = ${athleteId}
    `;

    const currentValuation =
      nilAccount.length > 0 ? parseFloat(nilAccount[0].current_valuation) : 0;

    // Generate tax optimization strategy
    const taxStrategy = generateTaxOptimizationStrategy(
      annualIncome,
      currentValuation,
      taxJurisdiction,
    );

    // Generate philanthropic plan
    const philanthropicPlan = generatePhilanthropicPlan(
      philanthropicGoals,
      annualIncome,
    );

    // Generate estate planning recommendations
    const estatePlan = generateEstatePlan(currentValuation, familySize);

    // Create family office profile
    const profile = await sql`
      INSERT INTO family_office_profiles (
        athlete_id,
        family_size,
        annual_income,
        tax_jurisdiction,
        current_net_worth,
        tax_strategy,
        philanthropic_plan,
        estate_plan,
        philanthropic_goals,
        profile_status,
        created_at,
        updated_at
      ) VALUES (
        ${athleteId},
        ${familySize},
        ${annualIncome},
        ${taxJurisdiction},
        ${currentValuation},
        ${JSON.stringify(taxStrategy)},
        ${JSON.stringify(philanthropicPlan)},
        ${JSON.stringify(estatePlan)},
        ${JSON.stringify(philanthropicGoals)},
        'active',
        NOW(),
        NOW()
      )
      RETURNING *
    `;

    // Calculate comprehensive financial health score
    const financialHealthScore = calculateFinancialHealth(
      profile[0],
      nilAccount[0],
    );

    return createSecureResponse({
      success: true,
      profile: profile[0],
      taxStrategy,
      philanthropicPlan,
      estatePlan,
      financialHealthScore,
      message: "Family office profile created successfully",
    });
  } catch (error) {
    console.error("Family office creation error:", error);
    return createSecureResponse(
      { error: "Failed to create family office profile" },
      { status: 500 },
    );
  }
}

// GET: Retrieve family office profile
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");

    if (!athleteId) {
      return createSecureResponse(
        { error: "athleteId required" },
        { status: 400 },
      );
    }

    const profile = await sql`
      SELECT * FROM family_office_profiles
      WHERE athlete_id = ${parseInt(athleteId)}
      ORDER BY created_at DESC
      LIMIT 1
    `;

    if (profile.length === 0) {
      return createSecureResponse(
        { error: "Family office profile not found" },
        { status: 404 },
      );
    }

    // Get comprehensive financial snapshot
    const nilAccount = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE athlete_id = ${parseInt(athleteId)}
    `;

    const legacyPlan = await sql`
      SELECT * FROM legacy_planning_profiles
      WHERE athlete_id = ${parseInt(athleteId)}
      ORDER BY created_at DESC
      LIMIT 1
    `;

    // Calculate financial health
    const financialHealth = calculateFinancialHealth(profile[0], nilAccount[0]);

    // Generate action items
    const actionItems = generateFinancialActionItems(
      profile[0],
      financialHealth,
    );

    return createSecureResponse({
      success: true,
      profile: profile[0],
      financialHealth,
      actionItems,
      nilValuation: nilAccount.length > 0 ? nilAccount[0].current_valuation : 0,
      legacyPlanning: legacyPlan.length > 0 ? legacyPlan[0] : null,
    });
  } catch (error) {
    console.error("Family office fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch family office profile" },
      { status: 500 },
    );
  }
}

// Utility functions
function generateTaxOptimizationStrategy(annualIncome, netWorth, jurisdiction) {
  const strategies = [];

  // Income-based strategies
  if (annualIncome > 500000) {
    strategies.push({
      strategy: "Qualified Retirement Plans",
      description: "Max out 401(k) and Roth IRA contributions",
      estimatedSavings: Math.min(annualIncome * 0.1, 100000),
      implementation: "Work with CPA to set up retirement accounts",
    });

    strategies.push({
      strategy: "Charitable Giving",
      description: "Donor-Advised Fund for tax-deductible contributions",
      estimatedSavings: annualIncome * 0.05,
      implementation: "Establish DAF through Fidelity or Schwab",
    });
  }

  // Net worth-based strategies
  if (netWorth > 1000000) {
    strategies.push({
      strategy: "Estate Planning Trusts",
      description:
        "Irrevocable Life Insurance Trust (ILIT) for estate tax reduction",
      estimatedSavings: netWorth * 0.15,
      implementation: "Consult with estate planning attorney",
    });
  }

  // NIL-specific strategies
  strategies.push({
    strategy: "NIL Entity Structuring",
    description: "LLC or S-Corp for NIL income to optimize self-employment tax",
    estimatedSavings: annualIncome * 0.08,
    implementation: "Form business entity with tax advisor",
  });

  return {
    jurisdiction,
    estimatedTaxRate: calculateTaxRate(annualIncome, jurisdiction),
    strategies,
    totalEstimatedSavings: strategies.reduce(
      (sum, s) => sum + s.estimatedSavings,
      0,
    ),
    nextReviewDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year
  };
}

function generatePhilanthropicPlan(goals, annualIncome) {
  const recommendedContribution = annualIncome * 0.05; // 5% of income

  return {
    recommendedAnnualContribution: recommendedContribution,
    givingVehicles: [
      {
        vehicle: "Donor-Advised Fund",
        contribution: recommendedContribution * 0.6,
        taxBenefit: "Immediate deduction, flexible distribution",
        setup: "Establish with financial institution",
      },
      {
        vehicle: "Direct Charitable Giving",
        contribution: recommendedContribution * 0.3,
        taxBenefit: "Standard deduction for qualified organizations",
        setup: "Identify 501(c)(3) organizations aligned with goals",
      },
      {
        vehicle: "Private Foundation",
        contribution: recommendedContribution * 0.1,
        taxBenefit: "Long-term legacy, family involvement",
        setup: "Consult attorney (recommended for net worth > $5M)",
      },
    ],
    causeAreas: goals.causeAreas || [
      "Youth sports",
      "Education",
      "Community development",
    ],
    impactMeasurement: {
      trackMetrics: [
        "Students impacted",
        "Programs funded",
        "Communities served",
      ],
      reportingFrequency: "Quarterly",
    },
  };
}

function generateEstatePlan(netWorth, familySize) {
  const plan = {
    essentialDocuments: [
      {
        document: "Last Will and Testament",
        priority: "Critical",
        status: "Pending",
      },
      {
        document: "Durable Power of Attorney",
        priority: "Critical",
        status: "Pending",
      },
      { document: "Healthcare Proxy", priority: "Critical", status: "Pending" },
      { document: "Living Will", priority: "High", status: "Pending" },
    ],
    recommendations: [],
  };

  if (netWorth > 1000000) {
    plan.recommendations.push({
      recommendation: "Establish Revocable Living Trust",
      reason: "Avoid probate, maintain privacy, provide for minor children",
      estimatedCost: "$3,000-$5,000",
    });
  }

  if (netWorth > 5000000) {
    plan.recommendations.push({
      recommendation: "Irrevocable Life Insurance Trust (ILIT)",
      reason: "Remove life insurance proceeds from taxable estate",
      estimatedCost: "$5,000-$10,000",
    });
  }

  if (familySize > 1) {
    plan.recommendations.push({
      recommendation: "Guardianship Designation",
      reason: "Ensure minor children are cared for by trusted individuals",
      estimatedCost: "Included in will",
    });
  }

  plan.recommendations.push({
    recommendation: "Beneficiary Review",
    reason:
      "Ensure all accounts (retirement, insurance) have updated beneficiaries",
    estimatedCost: "Free (annual review)",
  });

  return plan;
}

function calculateTaxRate(income, jurisdiction) {
  // Simplified US federal tax rate
  if (jurisdiction === "US") {
    if (income > 578125) return 0.37;
    if (income > 231250) return 0.35;
    if (income > 182100) return 0.32;
    if (income > 95375) return 0.24;
    if (income > 44725) return 0.22;
    return 0.12;
  }
  return 0.3; // Default
}

function calculateFinancialHealth(profile, nilAccount) {
  let score = 0;

  // Net worth (40 points)
  const netWorth = parseFloat(profile.current_net_worth || 0);
  if (netWorth > 5000000) score += 40;
  else if (netWorth > 1000000) score += 30;
  else if (netWorth > 500000) score += 20;
  else score += 10;

  // Tax strategy (20 points)
  if (profile.tax_strategy && profile.tax_strategy.strategies?.length > 0) {
    score += 20;
  } else {
    score += 5;
  }

  // Estate planning (20 points)
  if (
    profile.estate_plan &&
    profile.estate_plan.essentialDocuments?.length > 0
  ) {
    score += 20;
  } else {
    score += 5;
  }

  // Philanthropic engagement (10 points)
  if (
    profile.philanthropic_plan &&
    profile.philanthropic_plan.recommendedAnnualContribution > 0
  ) {
    score += 10;
  }

  // Player index (10 points)
  if (nilAccount && parseFloat(nilAccount.player_index) > 80) score += 10;
  else if (nilAccount && parseFloat(nilAccount.player_index) > 60) score += 7;
  else score += 3;

  return {
    score: Math.min(100, score),
    rating:
      score >= 80
        ? "Excellent"
        : score >= 60
          ? "Good"
          : score >= 40
            ? "Fair"
            : "Needs Attention",
    components: {
      netWorth: netWorth,
      taxOptimization: profile.tax_strategy ? "Active" : "Pending",
      estatePlanning: profile.estate_plan ? "Active" : "Pending",
      philanthropy: profile.philanthropic_plan ? "Active" : "Pending",
    },
  };
}

function generateFinancialActionItems(profile, financialHealth) {
  const items = [];

  if (financialHealth.score < 60) {
    items.push({
      priority: "Critical",
      action: "Schedule comprehensive financial review",
      timeline: "This week",
      impact: "Foundation for all other planning",
    });
  }

  if (!profile.tax_strategy || profile.tax_strategy.strategies?.length === 0) {
    items.push({
      priority: "High",
      action: "Implement tax optimization strategies",
      timeline: "This month",
      impact: `Potential savings: $${Math.round(profile.annual_income * 0.1).toLocaleString()}`,
    });
  }

  if (
    !profile.estate_plan ||
    profile.estate_plan.essentialDocuments?.length === 0
  ) {
    items.push({
      priority: "High",
      action: "Complete essential estate planning documents",
      timeline: "Next 2 months",
      impact: "Protect family and assets",
    });
  }

  if (
    !profile.philanthropic_plan ||
    profile.philanthropic_plan.recommendedAnnualContribution === 0
  ) {
    items.push({
      priority: "Medium",
      action: "Establish philanthropic giving strategy",
      timeline: "Next quarter",
      impact: "Tax benefits + community impact",
    });
  }

  items.push({
    priority: "Medium",
    action: "Review and update beneficiaries on all accounts",
    timeline: "Next month",
    impact: "Ensure assets transfer as intended",
  });

  return items;
}
