import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Legacy Planning & Post-Career Transitions
 *
 * Prepares athletes for life after sports through:
 * - Career transition roadmaps
 * - Entrepreneurial venture planning
 * - Education pathways
 * - Investment portfolio diversification
 * - Brand longevity strategies
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      careerStage: { required: true, type: "string" },
      estimatedRetirementAge: { required: false, type: "number" },
      transitionGoals: { required: false, type: "object" },
      skillsInventory: { required: false, type: "object" },
    });

    const {
      athleteId,
      careerStage, // 'early_career' | 'peak' | 'late_career' | 'transitioning' | 'retired'
      estimatedRetirementAge = 35,
      transitionGoals = {},
      skillsInventory = {},
    } = body;

    // Get athlete profile
    const athlete = await sql`
      SELECT up.*, au.name, au.email
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.id = ${athleteId}
        AND up.user_type = 'athlete'
    `;

    if (athlete.length === 0) {
      return createSecureResponse(
        { error: "Athlete not found" },
        { status: 404 },
      );
    }

    // Calculate career timeline
    const currentAge = calculateAge(athlete[0].created_at); // Simplified
    const yearsToRetirement = Math.max(0, estimatedRetirementAge - currentAge);

    // Generate transition roadmap
    const roadmap = generateTransitionRoadmap(
      careerStage,
      yearsToRetirement,
      transitionGoals,
    );

    // Create legacy planning profile
    const profile = await sql`
      INSERT INTO legacy_planning_profiles (
        athlete_id,
        career_stage,
        current_age,
        estimated_retirement_age,
        years_to_retirement,
        transition_goals,
        skills_inventory,
        roadmap,
        profile_status,
        created_at,
        updated_at
      ) VALUES (
        ${athleteId},
        ${careerStage},
        ${currentAge},
        ${estimatedRetirementAge},
        ${yearsToRetirement},
        ${JSON.stringify(transitionGoals)},
        ${JSON.stringify(skillsInventory)},
        ${JSON.stringify(roadmap)},
        'active',
        NOW(),
        NOW()
      )
      RETURNING *
    `;

    // Generate entrepreneurial opportunities
    const entrepreneurialOpportunities =
      await generateEntrepreneurialOpportunities(
        athleteId,
        skillsInventory,
        transitionGoals,
      );

    // Generate education pathways
    const educationPathways = generateEducationPathways(
      careerStage,
      transitionGoals,
    );

    return createSecureResponse({
      success: true,
      profile: profile[0],
      roadmap,
      entrepreneurialOpportunities,
      educationPathways,
      message: "Legacy planning profile created successfully",
    });
  } catch (error) {
    console.error("Legacy planning creation error:", error);
    return createSecureResponse(
      { error: "Failed to create legacy planning profile" },
      { status: 500 },
    );
  }
}

// GET: Retrieve legacy planning profile
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");

    if (!athleteId) {
      return createSecureResponse(
        { error: "athleteId required" },
        { status: 400 },
      );
    }

    const profile = await sql`
      SELECT * FROM legacy_planning_profiles
      WHERE athlete_id = ${parseInt(athleteId)}
      ORDER BY created_at DESC
      LIMIT 1
    `;

    if (profile.length === 0) {
      return createSecureResponse(
        { error: "Legacy planning profile not found" },
        { status: 404 },
      );
    }

    // Get NIL account to assess financial readiness
    const nilAccount = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE athlete_id = ${parseInt(athleteId)}
    `;

    // Calculate transition readiness score
    const readinessScore = calculateTransitionReadiness(
      profile[0],
      nilAccount[0],
    );

    // Get recommended next steps
    const nextSteps = generateNextSteps(profile[0], readinessScore);

    return createSecureResponse({
      success: true,
      profile: profile[0],
      readinessScore,
      nextSteps,
      financialReadiness:
        nilAccount.length > 0
          ? {
              currentValuation: nilAccount[0].current_valuation,
              playerIndex: nilAccount[0].player_index,
            }
          : null,
    });
  } catch (error) {
    console.error("Legacy planning fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch legacy planning profile" },
      { status: 500 },
    );
  }
}

// PUT: Update legacy planning profile
export async function PUT(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      profileId: { required: true, type: "number" },
      updates: { required: true, type: "object" },
    });

    const { profileId, updates } = body;

    // Build update query dynamically
    const allowedFields = [
      "career_stage",
      "estimated_retirement_age",
      "transition_goals",
      "skills_inventory",
      "roadmap",
    ];

    const updatePairs = [];
    const values = [];
    let paramIndex = 1;

    Object.keys(updates).forEach((key) => {
      if (allowedFields.includes(key)) {
        updatePairs.push(`${key} = $${paramIndex}`);
        values.push(
          typeof updates[key] === "object"
            ? JSON.stringify(updates[key])
            : updates[key],
        );
        paramIndex++;
      }
    });

    if (updatePairs.length === 0) {
      return createSecureResponse(
        { error: "No valid fields to update" },
        { status: 400 },
      );
    }

    updatePairs.push(`updated_at = NOW()`);

    const query = `
      UPDATE legacy_planning_profiles
      SET ${updatePairs.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `;

    values.push(profileId);

    const result = await sql.unsafe(query, values);

    return createSecureResponse({
      success: true,
      profile: result[0],
      message: "Legacy planning profile updated successfully",
    });
  } catch (error) {
    console.error("Legacy planning update error:", error);
    return createSecureResponse(
      { error: "Failed to update legacy planning profile" },
      { status: 500 },
    );
  }
}

// Utility functions
function calculateAge(createdAt) {
  // Simplified - in production, use actual birth date
  return 25; // Default
}

function generateTransitionRoadmap(careerStage, yearsToRetirement, goals) {
  const roadmap = {
    phases: [],
    milestones: [],
    recommendations: [],
  };

  if (yearsToRetirement > 5) {
    roadmap.phases.push({
      phase: "Foundation Building",
      timeframe: "Years 1-3",
      focus: ["Brand development", "Education initiation", "Network expansion"],
      actions: [
        "Enroll in business courses",
        "Build personal brand on social media",
        "Attend entrepreneurship workshops",
        "Identify mentor in desired industry",
      ],
    });

    roadmap.phases.push({
      phase: "Skill Acquisition",
      timeframe: "Years 3-5",
      focus: [
        "Professional certifications",
        "Side ventures",
        "Investment education",
      ],
      actions: [
        "Launch side business or consulting",
        "Complete relevant certifications",
        "Shadow professionals in target industry",
        "Build investment portfolio",
      ],
    });
  }

  if (yearsToRetirement <= 5 || careerStage === "late_career") {
    roadmap.phases.push({
      phase: "Transition Preparation",
      timeframe: "Years 0-2",
      focus: [
        "Career pivot execution",
        "Financial security",
        "Legacy branding",
      ],
      actions: [
        "Finalize post-career business plan",
        "Secure seed funding if needed",
        "Establish advisory board",
        "Launch personal brand platform",
      ],
    });
  }

  roadmap.milestones = [
    {
      milestone: "Complete first professional certification",
      targetDate: "12 months",
    },
    { milestone: "Launch side venture", targetDate: "24 months" },
    { milestone: "Achieve $1M in NIL valuation", targetDate: "36 months" },
    {
      milestone: "Secure post-career role/partnership",
      targetDate: "48 months",
    },
  ];

  roadmap.recommendations = [
    "Prioritize education and skill development during off-season",
    "Leverage current fame to build long-term brand equity",
    "Diversify income streams beyond active competition",
    "Build relationships with industry leaders in target field",
  ];

  return roadmap;
}

async function generateEntrepreneurialOpportunities(
  athleteId,
  skillsInventory,
  goals,
) {
  // AI-powered opportunity matching (simplified)
  const opportunities = [
    {
      category: "Brand Extension",
      opportunity: "Athletic Apparel Line",
      capitalRequired: 50000,
      timeToLaunch: "6-12 months",
      requiredSkills: ["Brand development", "Marketing"],
      potentialROI: "150-300%",
      fit: 85,
    },
    {
      category: "Coaching & Training",
      opportunity: "Online Training Platform",
      capitalRequired: 25000,
      timeToLaunch: "3-6 months",
      requiredSkills: ["Teaching", "Video production"],
      potentialROI: "200-400%",
      fit: 90,
    },
    {
      category: "Media & Content",
      opportunity: "Sports Podcast/YouTube Channel",
      capitalRequired: 10000,
      timeToLaunch: "1-3 months",
      requiredSkills: ["Communication", "Social media"],
      potentialROI: "100-250%",
      fit: 80,
    },
    {
      category: "Investment",
      opportunity: "Athlete-Focused Venture Fund",
      capitalRequired: 500000,
      timeToLaunch: "12-18 months",
      requiredSkills: ["Finance", "Network"],
      potentialROI: "300-500%",
      fit: 70,
    },
  ];

  return opportunities.sort((a, b) => b.fit - a.fit);
}

function generateEducationPathways(careerStage, goals) {
  return [
    {
      pathway: "Business Administration",
      programs: ["MBA (Part-time)", "Executive Business Program"],
      duration: "18-24 months",
      cost: "$50,000-$150,000",
      careerOutcomes: [
        "Sports management",
        "Entrepreneurship",
        "Corporate leadership",
      ],
      recommended: careerStage === "peak" || careerStage === "late_career",
    },
    {
      pathway: "Sports Management",
      programs: ["Sports Management Certificate", "Coaching Certification"],
      duration: "6-12 months",
      cost: "$10,000-$30,000",
      careerOutcomes: ["Coach", "Sports administrator", "Talent scout"],
      recommended: true,
    },
    {
      pathway: "Financial Planning",
      programs: ["CFP Certification", "Wealth Management Certificate"],
      duration: "12-18 months",
      cost: "$5,000-$20,000",
      careerOutcomes: ["Financial advisor", "Wealth manager", "NIL consultant"],
      recommended:
        careerStage === "late_career" || careerStage === "transitioning",
    },
    {
      pathway: "Media & Communications",
      programs: ["Sports Broadcasting Course", "Digital Media Certificate"],
      duration: "3-6 months",
      cost: "$3,000-$10,000",
      careerOutcomes: ["Broadcaster", "Content creator", "Sports journalist"],
      recommended: true,
    },
  ];
}

function calculateTransitionReadiness(profile, nilAccount) {
  let score = 0;

  // Financial readiness (40%)
  if (nilAccount && parseFloat(nilAccount.current_valuation) > 500000) {
    score += 40;
  } else if (nilAccount && parseFloat(nilAccount.current_valuation) > 100000) {
    score += 25;
  } else {
    score += 10;
  }

  // Skills inventory (30%)
  const skillsCount = Object.keys(profile.skills_inventory || {}).length;
  score += Math.min(30, skillsCount * 5);

  // Planning completion (30%)
  if (profile.roadmap && Object.keys(profile.roadmap).length > 0) score += 15;
  if (
    profile.transition_goals &&
    Object.keys(profile.transition_goals).length > 0
  )
    score += 15;

  return Math.min(100, score);
}

function generateNextSteps(profile, readinessScore) {
  const steps = [];

  if (readinessScore < 40) {
    steps.push({
      priority: "high",
      action: "Complete skills inventory assessment",
      timeline: "This week",
    });
    steps.push({
      priority: "high",
      action: "Schedule consultation with financial advisor",
      timeline: "This month",
    });
  } else if (readinessScore < 70) {
    steps.push({
      priority: "medium",
      action: "Enroll in first education program",
      timeline: "Next quarter",
    });
    steps.push({
      priority: "medium",
      action: "Launch side business or venture",
      timeline: "Next 6 months",
    });
  } else {
    steps.push({
      priority: "low",
      action: "Refine post-career business plan",
      timeline: "Next quarter",
    });
    steps.push({
      priority: "low",
      action: "Begin transition marketing campaign",
      timeline: "Next 6 months",
    });
  }

  return steps;
}
