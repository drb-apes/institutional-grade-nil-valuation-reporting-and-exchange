import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Contract Adjustment Engine
 *
 * Real-time NIL valuation updates based on:
 * - Biometric performance changes
 * - Milestone achievements
 * - Social engagement shifts
 * - Market momentum
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Rate limiting
    const rateLimit = checkRateLimit(`contract-adj-${session.user.id}`, {
      maxRequests: 30,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    // Validate input
    const body = await validateRequestBody(request, {
      nilAccountId: { required: true, type: "number" },
      adjustmentType: { required: true, type: "string" },
      adjustmentAmount: { required: true, type: "number" },
      performanceMetrics: { required: false, type: "object" },
      adjustmentReason: { required: false, type: "string" },
    });

    const {
      nilAccountId,
      adjustmentType,
      adjustmentAmount,
      performanceMetrics = {},
      adjustmentReason = "",
    } = body;

    // Get current account valuation
    const account = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE id = ${nilAccountId}
    `;

    if (account.length === 0) {
      return createSecureResponse(
        { error: "NIL account not found" },
        { status: 404 },
      );
    }

    const previousValuation = parseFloat(account[0].current_valuation);
    const newValuation = previousValuation + adjustmentAmount;

    // Record contract adjustment
    const adjustment = await sql`
      INSERT INTO contract_adjustments (
        nil_account_id,
        adjustment_type,
        adjustment_amount,
        previous_valuation,
        new_valuation,
        performance_metrics,
        adjustment_reason,
        adjustment_date,
        created_at
      ) VALUES (
        ${nilAccountId},
        ${adjustmentType},
        ${adjustmentAmount},
        ${previousValuation},
        ${newValuation},
        ${JSON.stringify(performanceMetrics)},
        ${adjustmentReason},
        NOW(),
        NOW()
      )
      RETURNING *
    `;

    // Update NIL account valuation
    await sql`
      UPDATE nil_valuation_accounts
      SET current_valuation = ${newValuation},
          updated_at = NOW()
      WHERE id = ${nilAccountId}
    `;

    // Recalculate player index
    const newPlayerIndex = await calculatePlayerIndexFromPerformance(
      account[0].athlete_id,
      performanceMetrics,
    );

    // Update player index
    await sql`
      UPDATE nil_valuation_accounts
      SET player_index = ${newPlayerIndex}
      WHERE id = ${nilAccountId}
    `;

    // Record player index history
    await sql`
      INSERT INTO player_index_history (
        athlete_id,
        index_value,
        valuation,
        recorded_at
      ) VALUES (
        ${account[0].athlete_id},
        ${newPlayerIndex},
        ${newValuation},
        NOW()
      )
    `;

    // Check if margin account needs adjustment
    if (account[0].margin_enabled) {
      await adjustMarginAccount(
        nilAccountId,
        newValuation,
        account[0].account_type,
      );
    }

    return createSecureResponse({
      success: true,
      adjustment: adjustment[0],
      previousValuation,
      newValuation,
      adjustmentPercentage: (
        (adjustmentAmount / previousValuation) *
        100
      ).toFixed(2),
      newPlayerIndex,
    });
  } catch (error) {
    console.error("Contract adjustment error:", error);
    return createSecureResponse(
      { error: "Failed to process contract adjustment" },
      { status: 500 },
    );
  }
}

// GET: Retrieve contract adjustment history
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const nilAccountId = searchParams.get("nilAccountId");
    const athleteId = searchParams.get("athleteId");
    const limit = parseInt(searchParams.get("limit") || "20");

    if (!nilAccountId && !athleteId) {
      return createSecureResponse(
        { error: "nilAccountId or athleteId required" },
        { status: 400 },
      );
    }

    let adjustments;

    if (nilAccountId) {
      adjustments = await sql`
        SELECT * FROM contract_adjustments
        WHERE nil_account_id = ${parseInt(nilAccountId)}
        ORDER BY adjustment_date DESC
        LIMIT ${limit}
      `;
    } else {
      // Get all accounts for athlete first
      const accounts = await sql`
        SELECT id FROM nil_valuation_accounts
        WHERE athlete_id = ${parseInt(athleteId)}
      `;

      const accountIds = accounts.map((a) => a.id);

      if (accountIds.length === 0) {
        return createSecureResponse({ success: true, adjustments: [] });
      }

      adjustments = await sql`
        SELECT * FROM contract_adjustments
        WHERE nil_account_id = ANY(${accountIds})
        ORDER BY adjustment_date DESC
        LIMIT ${limit}
      `;
    }

    // Calculate statistics
    const stats = calculateAdjustmentStats(adjustments);

    return createSecureResponse({
      success: true,
      adjustments,
      stats,
    });
  } catch (error) {
    console.error("Contract adjustment fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch contract adjustments" },
      { status: 500 },
    );
  }
}

// Utility functions
async function calculatePlayerIndexFromPerformance(
  athleteId,
  performanceMetrics,
) {
  try {
    // Get baseline from motion scans
    const scans = await sql`
      SELECT ai_score FROM motion_scans
      WHERE athlete_id = ${athleteId}
        AND verification_status = 'verified'
      ORDER BY created_at DESC
      LIMIT 10
    `;

    let baseScore = 50;
    if (scans.length > 0) {
      baseScore =
        scans.reduce((sum, scan) => sum + parseFloat(scan.ai_score), 0) /
        scans.length;
    }

    // Apply performance metric adjustments
    let adjustedScore = baseScore;

    if (performanceMetrics.bimScore) {
      adjustedScore = adjustedScore * 0.7 + performanceMetrics.bimScore * 0.3;
    }

    if (performanceMetrics.socialGrowth) {
      const socialBoost = Math.min(10, performanceMetrics.socialGrowth / 10);
      adjustedScore += socialBoost;
    }

    if (performanceMetrics.milestoneAchieved) {
      adjustedScore += 5;
    }

    return Math.min(100, Math.max(0, adjustedScore));
  } catch (error) {
    console.error("Player index calculation error:", error);
    return 50;
  }
}

async function adjustMarginAccount(nilAccountId, newValuation, accountType) {
  try {
    const multipliers = {
      standard: 0.5,
      premium: 1.0,
      family_office: 2.0,
    };

    const newMarginLimit = newValuation * (multipliers[accountType] || 0.5);
    const newMaintenanceMargin = newMarginLimit * 0.25;

    await sql`
      UPDATE margin_accounts
      SET available_margin = ${newMarginLimit},
          maintenance_margin = ${newMaintenanceMargin},
          updated_at = NOW()
      WHERE nil_account_id = ${nilAccountId}
    `;
  } catch (error) {
    console.error("Margin account adjustment error:", error);
  }
}

function calculateAdjustmentStats(adjustments) {
  if (adjustments.length === 0) {
    return {
      totalAdjustments: 0,
      totalValueChange: 0,
      avgAdjustmentAmount: 0,
      positiveAdjustments: 0,
      negativeAdjustments: 0,
    };
  }

  const totalValueChange = adjustments.reduce(
    (sum, adj) => sum + parseFloat(adj.adjustment_amount),
    0,
  );

  const positiveAdjustments = adjustments.filter(
    (adj) => parseFloat(adj.adjustment_amount) > 0,
  ).length;

  const negativeAdjustments = adjustments.filter(
    (adj) => parseFloat(adj.adjustment_amount) < 0,
  ).length;

  return {
    totalAdjustments: adjustments.length,
    totalValueChange,
    avgAdjustmentAmount: totalValueChange / adjustments.length,
    positiveAdjustments,
    negativeAdjustments,
    latestValuation: adjustments[0]?.new_valuation || 0,
  };
}
