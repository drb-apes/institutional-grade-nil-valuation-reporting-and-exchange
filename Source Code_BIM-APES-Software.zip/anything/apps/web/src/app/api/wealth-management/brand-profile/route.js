import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Brand Identity Profile Management
 *
 * Tracks and optimizes athlete brand equity through:
 * - Fan sentiment analysis
 * - Social reach monitoring
 * - Sponsorship potential scoring
 * - Authenticity index (anti-inauthentic brand deals)
 * - Market positioning assessment
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      socialMetrics: { required: false, type: "object" },
      brandMetrics: { required: false, type: "object" },
      sponsorshipData: { required: false, type: "object" },
    });

    const {
      athleteId,
      socialMetrics = {},
      brandMetrics = {},
      sponsorshipData = {},
    } = body;

    // Calculate brand scores
    const brandEquityScore = calculateBrandEquity(socialMetrics, brandMetrics);
    const fanSentimentScore = calculateFanSentiment(socialMetrics);
    const sponsorshipPotential = calculateSponsorshipPotential(
      brandMetrics,
      sponsorshipData,
    );
    const authenticityIndex = calculateAuthenticity(
      socialMetrics,
      brandMetrics,
    );
    const marketPositioning = determineMarketPositioning(
      brandEquityScore,
      fanSentimentScore,
    );

    // Get or create NIL account
    let nilAccount = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE athlete_id = ${athleteId}
    `;

    if (nilAccount.length === 0) {
      return createSecureResponse(
        { error: "NIL account required. Create NIL account first." },
        { status: 400 },
      );
    }

    // Update or create brand profile
    const existingProfile = await sql`
      SELECT * FROM brand_identity_profiles
      WHERE nil_account_id = ${nilAccount[0].id}
    `;

    let profile;

    if (existingProfile.length > 0) {
      // Update existing
      profile = await sql`
        UPDATE brand_identity_profiles
        SET brand_equity_score = ${brandEquityScore},
            fan_sentiment_score = ${fanSentimentScore},
            social_reach = ${socialMetrics.totalFollowers || 0},
            sponsorship_potential = ${sponsorshipPotential},
            authenticity_index = ${authenticityIndex},
            market_positioning = ${marketPositioning},
            brand_metrics = ${JSON.stringify(brandMetrics)},
            updated_at = NOW()
        WHERE nil_account_id = ${nilAccount[0].id}
        RETURNING *
      `;
    } else {
      // Create new
      profile = await sql`
        INSERT INTO brand_identity_profiles (
          nil_account_id,
          athlete_id,
          brand_equity_score,
          fan_sentiment_score,
          social_reach,
          sponsorship_potential,
          authenticity_index,
          market_positioning,
          brand_metrics,
          profile_status,
          created_at,
          updated_at
        ) VALUES (
          ${nilAccount[0].id},
          ${athleteId},
          ${brandEquityScore},
          ${fanSentimentScore},
          ${socialMetrics.totalFollowers || 0},
          ${sponsorshipPotential},
          ${authenticityIndex},
          ${marketPositioning},
          ${JSON.stringify(brandMetrics)},
          'active',
          NOW(),
          NOW()
        )
        RETURNING *
      `;
    }

    // Generate brand recommendations
    const recommendations = generateBrandRecommendations(
      profile[0],
      socialMetrics,
    );

    // Calculate brand value impact on NIL
    const brandLiftValue = calculateBrandLiftValue(
      brandEquityScore,
      parseFloat(nilAccount[0].current_valuation),
    );

    return createSecureResponse({
      success: true,
      profile: profile[0],
      recommendations,
      brandLiftValue,
      scores: {
        brandEquity: brandEquityScore,
        fanSentiment: fanSentimentScore,
        sponsorshipPotential,
        authenticity: authenticityIndex,
      },
      message: "Brand profile updated successfully",
    });
  } catch (error) {
    console.error("Brand profile creation error:", error);
    return createSecureResponse(
      { error: "Failed to create brand profile" },
      { status: 500 },
    );
  }
}

// GET: Retrieve brand profile with analytics
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");

    if (!athleteId) {
      return createSecureResponse(
        { error: "athleteId required" },
        { status: 400 },
      );
    }

    // Get brand profile
    const profile = await sql`
      SELECT bp.*, nva.current_valuation, nva.player_index
      FROM brand_identity_profiles bp
      JOIN nil_valuation_accounts nva ON bp.nil_account_id = nva.id
      WHERE bp.athlete_id = ${parseInt(athleteId)}
      ORDER BY bp.created_at DESC
      LIMIT 1
    `;

    if (profile.length === 0) {
      return createSecureResponse(
        { error: "Brand profile not found" },
        { status: 404 },
      );
    }

    // Get fan engagement data
    const fanEngagement = await sql`
      SELECT 
        action_type,
        COUNT(*) as action_count,
        SUM(engagement_weight) as total_weight,
        AVG(metadata_multiplier) as avg_multiplier
      FROM fan_engagement_actions
      WHERE athlete_id = ${parseInt(athleteId)}
        AND created_at > NOW() - INTERVAL '90 days'
      GROUP BY action_type
    `;

    // Get sponsor contracts
    const sponsorContracts = await sql`
      SELECT * FROM sponsor_contracts
      WHERE athlete_id = ${parseInt(athleteId)}
        AND contract_status = 'active'
    `;

    // Calculate brand growth trend
    const brandGrowthTrend = calculateBrandGrowthTrend(profile[0]);

    // Generate sponsorship recommendations
    const sponsorshipRecs = generateSponsorshipRecommendations(
      profile[0],
      fanEngagement,
    );

    return createSecureResponse({
      success: true,
      profile: profile[0],
      fanEngagement,
      activeSponsorships: sponsorContracts.length,
      brandGrowthTrend,
      sponsorshipRecommendations: sponsorshipRecs,
    });
  } catch (error) {
    console.error("Brand profile fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch brand profile" },
      { status: 500 },
    );
  }
}

// PUT: Update brand profile
export async function PUT(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      profileId: { required: true, type: "number" },
      updates: { required: true, type: "object" },
    });

    const { profileId, updates } = body;

    // Allowed fields for update
    const allowedFields = [
      "brand_equity_score",
      "fan_sentiment_score",
      "social_reach",
      "sponsorship_potential",
      "authenticity_index",
      "market_positioning",
      "brand_metrics",
    ];

    const updatePairs = [];
    const values = [];
    let paramIndex = 1;

    Object.keys(updates).forEach((key) => {
      if (allowedFields.includes(key)) {
        updatePairs.push(`${key} = $${paramIndex}`);
        values.push(
          typeof updates[key] === "object"
            ? JSON.stringify(updates[key])
            : updates[key],
        );
        paramIndex++;
      }
    });

    if (updatePairs.length === 0) {
      return createSecureResponse(
        { error: "No valid fields to update" },
        { status: 400 },
      );
    }

    updatePairs.push(`updated_at = NOW()`);

    const query = `
      UPDATE brand_identity_profiles
      SET ${updatePairs.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `;

    values.push(profileId);

    const result = await sql.unsafe(query, values);

    return createSecureResponse({
      success: true,
      profile: result[0],
      message: "Brand profile updated successfully",
    });
  } catch (error) {
    console.error("Brand profile update error:", error);
    return createSecureResponse(
      { error: "Failed to update brand profile" },
      { status: 500 },
    );
  }
}

// Calculation functions
function calculateBrandEquity(socialMetrics, brandMetrics) {
  let score = 50; // Baseline

  // Social metrics component (30 points)
  const followers = socialMetrics.totalFollowers || 0;
  if (followers > 1000000) score += 30;
  else if (followers > 500000) score += 25;
  else if (followers > 100000) score += 20;
  else if (followers > 50000) score += 15;
  else score += Math.min(10, followers / 5000);

  // Engagement rate component (30 points)
  const engagementRate = socialMetrics.engagementRate || 0;
  score += Math.min(30, engagementRate * 3);

  // Brand deal quality (20 points)
  const sponsorCount = brandMetrics.activeSponsorships || 0;
  score += Math.min(20, sponsorCount * 5);

  // Media mentions (20 points)
  const mediaMentions = brandMetrics.mediaMentions || 0;
  score += Math.min(20, mediaMentions / 5);

  return Math.min(100, Math.max(0, score));
}

function calculateFanSentiment(socialMetrics) {
  let score = 50; // Baseline

  // Positive sentiment ratio
  const sentimentRatio = socialMetrics.positiveSentimentRatio || 0.5;
  score += (sentimentRatio - 0.5) * 80;

  // Response rate
  const responseRate = socialMetrics.fanResponseRate || 0;
  score += responseRate * 20;

  return Math.min(100, Math.max(0, score));
}

function calculateSponsorshipPotential(brandMetrics, sponsorshipData) {
  let score = 50; // Baseline

  // Current sponsorship value
  const currentValue = sponsorshipData.totalAnnualValue || 0;
  if (currentValue > 1000000) score += 30;
  else if (currentValue > 500000) score += 25;
  else if (currentValue > 100000) score += 20;
  else score += currentValue / 10000;

  // Brand alignment
  const alignmentScore = brandMetrics.brandAlignmentScore || 50;
  score += (alignmentScore - 50) * 0.4;

  // Market demand
  const inboundOffers = sponsorshipData.inboundOffers || 0;
  score += Math.min(20, inboundOffers * 5);

  return Math.min(100, Math.max(0, score));
}

function calculateAuthenticity(socialMetrics, brandMetrics) {
  let score = 100; // Start high, deduct for red flags

  // Follower quality (detect fake followers)
  const suspiciousFollowerRatio = socialMetrics.suspiciousFollowerRatio || 0;
  score -= suspiciousFollowerRatio * 50;

  // Engagement authenticity
  const botEngagementRatio = socialMetrics.botEngagementRatio || 0;
  score -= botEngagementRatio * 30;

  // Brand deal misalignment
  const misalignedDeals = brandMetrics.misalignedDeals || 0;
  score -= misalignedDeals * 10;

  // Controversy/scandal impact
  const controversyScore = brandMetrics.controversyScore || 0;
  score -= controversyScore;

  return Math.min(100, Math.max(0, score));
}

function determineMarketPositioning(brandEquity, fanSentiment) {
  const composite = (brandEquity + fanSentiment) / 2;

  if (composite >= 85) return "iconic";
  if (composite >= 70) return "established";
  if (composite >= 50) return "growing";
  return "emerging";
}

function calculateBrandLiftValue(brandEquityScore, currentValuation) {
  // Brand lift multiplier (1.0 to 2.0)
  const liftMultiplier = 1.0 + brandEquityScore / 100;
  const brandLiftedValue = currentValuation * liftMultiplier;
  const liftAmount = brandLiftedValue - currentValuation;

  return {
    currentValuation,
    brandLiftedValue,
    liftAmount,
    liftPercentage: ((liftAmount / currentValuation) * 100).toFixed(2),
    brandEquityScore,
  };
}

function generateBrandRecommendations(profile, socialMetrics) {
  const recommendations = [];

  const brandEquity = parseFloat(profile.brand_equity_score);
  const fanSentiment = parseFloat(profile.fan_sentiment_score);
  const sponsorshipPotential = parseFloat(profile.sponsorship_potential);
  const authenticity = parseFloat(profile.authenticity_index);

  // Brand equity recommendations
  if (brandEquity < 60) {
    recommendations.push({
      category: "Brand Equity",
      priority: "high",
      recommendation: "Increase social media presence and content consistency",
      actions: [
        "Post 3-5x per week across all platforms",
        "Engage directly with fans through Q&A sessions",
        "Share behind-the-scenes training content",
        "Collaborate with complementary athletes/influencers",
      ],
      expectedImpact: "+15-25 points in 90 days",
    });
  }

  // Fan sentiment recommendations
  if (fanSentiment < 60) {
    recommendations.push({
      category: "Fan Sentiment",
      priority: "high",
      recommendation: "Improve fan engagement and community building",
      actions: [
        "Respond to fan comments and messages",
        "Host meet-and-greet events",
        "Launch fan loyalty program",
        "Share personal stories and values",
      ],
      expectedImpact: "+10-20 points in 60 days",
    });
  }

  // Sponsorship recommendations
  if (sponsorshipPotential < 70) {
    recommendations.push({
      category: "Sponsorship Potential",
      priority: "medium",
      recommendation: "Build professional brand assets and media kit",
      actions: [
        "Create polished brand deck with demographics and engagement data",
        "Produce high-quality photo and video content",
        "Identify target sponsors aligned with personal brand",
        "Attend industry networking events",
      ],
      expectedImpact: "+15-30 points in 120 days",
    });
  }

  // Authenticity recommendations
  if (authenticity < 75) {
    recommendations.push({
      category: "Authenticity",
      priority: "critical",
      recommendation: "Focus on authentic brand partnerships and content",
      actions: [
        "Decline sponsorships that conflict with personal values",
        "Share genuine experiences and challenges",
        "Maintain consistent messaging across platforms",
        "Avoid purchasing followers or engagement",
      ],
      expectedImpact: "Protect long-term brand value",
    });
  }

  // Always include growth recommendation
  recommendations.push({
    category: "Market Positioning",
    priority: "medium",
    recommendation: `Advance from '${profile.market_positioning}' to next tier`,
    actions: [
      "Execute high-impact brand collaborations",
      "Increase mainstream media appearances",
      "Expand into adjacent markets or demographics",
      "Launch signature initiative or campaign",
    ],
    expectedImpact: "Tier advancement in 6-12 months",
  });

  return recommendations;
}

function calculateBrandGrowthTrend(profile) {
  // Simplified - in production, query historical data
  const currentScore = parseFloat(profile.brand_equity_score);

  return {
    current: currentScore,
    trend: "positive", // 'positive' | 'negative' | 'stable'
    growthRate: 5.2, // % per quarter
    projection30Days: currentScore + 1.7,
    projection90Days: currentScore + 5.2,
    projection180Days: currentScore + 10.5,
  };
}

function generateSponsorshipRecommendations(profile, fanEngagement) {
  const brandEquity = parseFloat(profile.brand_equity_score);
  const authenticity = parseFloat(profile.authenticity_index);

  const recommendations = [];

  // Tier-based sponsorship targets
  if (brandEquity >= 75 && authenticity >= 75) {
    recommendations.push({
      tier: "Premium",
      brands: ["Nike", "Gatorade", "Apple", "Mercedes-Benz"],
      estimatedValue: "$500K-$2M annual",
      requirements: "Maintain brand equity > 75, authenticity > 75",
    });
  } else if (brandEquity >= 60) {
    recommendations.push({
      tier: "Mid-Tier",
      brands: ["Under Armour", "Powerade", "Samsung", "Toyota"],
      estimatedValue: "$100K-$500K annual",
      requirements: "Grow brand equity to 75+, maintain authenticity",
    });
  } else {
    recommendations.push({
      tier: "Emerging",
      brands: ["Local businesses", "Regional chains", "Startups"],
      estimatedValue: "$10K-$100K annual",
      requirements: "Build foundational brand equity and fan base",
    });
  }

  return recommendations;
}
