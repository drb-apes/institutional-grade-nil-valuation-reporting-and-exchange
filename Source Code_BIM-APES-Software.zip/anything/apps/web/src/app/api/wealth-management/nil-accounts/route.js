import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import {
  validateRequestBody,
  createSecureResponse,
  checkRateLimit,
} from "@/app/api/utils/security";

/**
 * Biometric NIL Valuation Accounts
 *
 * Core wealth management accounts that integrate:
 * - Contract adjustments (performance-linked)
 * - Player indices (dynamic valuation)
 * - Margin accounts (leverage for athlete assets)
 * - Brand identity profiles (brand equity tracking)
 */

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const rateLimit = checkRateLimit(`nil-account-${session.user.id}`, {
      maxRequests: 10,
      windowMs: 60 * 1000,
    });
    if (!rateLimit.allowed) {
      return createSecureResponse(
        { error: "Rate limit exceeded" },
        { status: 429 },
      );
    }

    const body = await validateRequestBody(request, {
      athleteId: { required: true, type: "number" },
      accountType: { required: true, type: "string" },
      initialValuation: { required: false, type: "number" },
      marginEnabled: { required: false, type: "boolean" },
      riskTolerance: { required: false, type: "string" },
    });

    const {
      athleteId,
      accountType, // 'standard' | 'premium' | 'family_office'
      initialValuation = 0,
      marginEnabled = false,
      riskTolerance = "moderate",
    } = body;

    // Verify athlete exists
    const athlete = await sql`
      SELECT * FROM user_profiles
      WHERE id = ${athleteId}
        AND user_type = 'athlete'
    `;

    if (athlete.length === 0) {
      return createSecureResponse(
        { error: "Athlete not found" },
        { status: 404 },
      );
    }

    // Check if account already exists
    const existingAccount = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE athlete_id = ${athleteId}
    `;

    if (existingAccount.length > 0) {
      return createSecureResponse(
        { error: "NIL account already exists for this athlete" },
        { status: 409 },
      );
    }

    // Generate account number
    const accountNumber = generateAccountNumber();

    // Calculate initial player index
    const playerIndex = await calculatePlayerIndex(athleteId);

    // Create NIL valuation account
    const account = await sql`
      INSERT INTO nil_valuation_accounts (
        account_number,
        athlete_id,
        account_type,
        current_valuation,
        player_index,
        margin_enabled,
        risk_tolerance,
        account_status,
        created_at,
        updated_at
      ) VALUES (
        ${accountNumber},
        ${athleteId},
        ${accountType},
        ${initialValuation},
        ${playerIndex},
        ${marginEnabled},
        ${riskTolerance},
        'active',
        NOW(),
        NOW()
      )
      RETURNING *
    `;

    // Create brand identity profile
    const brandProfile = await createBrandIdentityProfile(
      athleteId,
      account[0].id,
    );

    // Create margin account if enabled
    let marginAccount = null;
    if (marginEnabled) {
      marginAccount = await createMarginAccount(account[0].id, riskTolerance);
    }

    return createSecureResponse({
      success: true,
      account: account[0],
      brandProfile,
      marginAccount,
      playerIndex,
      message: "NIL Valuation Account created successfully",
    });
  } catch (error) {
    console.error("NIL account creation error:", error);
    return createSecureResponse(
      { error: "Failed to create NIL account" },
      { status: 500 },
    );
  }
}

// GET: Retrieve NIL account details
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");
    const accountId = searchParams.get("accountId");

    let account;

    if (accountId) {
      account = await sql`
        SELECT * FROM nil_valuation_accounts
        WHERE id = ${parseInt(accountId)}
      `;
    } else if (athleteId) {
      account = await sql`
        SELECT * FROM nil_valuation_accounts
        WHERE athlete_id = ${parseInt(athleteId)}
      `;
    } else {
      // Get all accounts for advisor
      account = await sql`
        SELECT nva.*, up.user_id, au.name as athlete_name
        FROM nil_valuation_accounts nva
        JOIN user_profiles up ON nva.athlete_id = up.id
        JOIN auth_users au ON up.user_id = au.id
        ORDER BY nva.created_at DESC
        LIMIT 50
      `;
    }

    if (account.length === 0) {
      return createSecureResponse(
        { error: "NIL account not found" },
        { status: 404 },
      );
    }

    // Get brand profile
    const brandProfile = await sql`
      SELECT * FROM brand_identity_profiles
      WHERE nil_account_id = ${account[0].id}
    `;

    // Get margin account if exists
    const marginAccount = await sql`
      SELECT * FROM margin_accounts
      WHERE nil_account_id = ${account[0].id}
    `;

    // Get recent contract adjustments
    const contractAdjustments = await sql`
      SELECT * FROM contract_adjustments
      WHERE nil_account_id = ${account[0].id}
      ORDER BY adjustment_date DESC
      LIMIT 20
    `;

    // Get player index history
    const indexHistory = await sql`
      SELECT * FROM player_index_history
      WHERE athlete_id = ${account[0].athlete_id}
      ORDER BY recorded_at DESC
      LIMIT 30
    `;

    return createSecureResponse({
      success: true,
      account: account[0],
      brandProfile: brandProfile[0] || null,
      marginAccount: marginAccount[0] || null,
      contractAdjustments,
      indexHistory,
      currentPlayerIndex: account[0].player_index,
    });
  } catch (error) {
    console.error("NIL account fetch error:", error);
    return createSecureResponse(
      { error: "Failed to fetch NIL account" },
      { status: 500 },
    );
  }
}

// PUT: Update NIL account valuation
export async function PUT(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return createSecureResponse(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await validateRequestBody(request, {
      accountId: { required: true, type: "number" },
      adjustmentType: { required: true, type: "string" },
      adjustmentAmount: { required: false, type: "number" },
      performanceMetrics: { required: false, type: "object" },
      reason: { required: false, type: "string" },
    });

    const {
      accountId,
      adjustmentType, // 'performance_bonus' | 'milestone_achieved' | 'brand_lift' | 'market_correction'
      adjustmentAmount = 0,
      performanceMetrics = {},
      reason = "",
    } = body;

    // Get current account
    const account = await sql`
      SELECT * FROM nil_valuation_accounts
      WHERE id = ${accountId}
    `;

    if (account.length === 0) {
      return createSecureResponse(
        { error: "NIL account not found" },
        { status: 404 },
      );
    }

    const currentValuation = parseFloat(account[0].current_valuation);
    const newValuation = currentValuation + adjustmentAmount;

    // Update account valuation
    await sql`
      UPDATE nil_valuation_accounts
      SET current_valuation = ${newValuation},
          updated_at = NOW()
      WHERE id = ${accountId}
    `;

    // Record contract adjustment
    await sql`
      INSERT INTO contract_adjustments (
        nil_account_id,
        adjustment_type,
        adjustment_amount,
        previous_valuation,
        new_valuation,
        performance_metrics,
        adjustment_reason,
        adjustment_date,
        created_at
      ) VALUES (
        ${accountId},
        ${adjustmentType},
        ${adjustmentAmount},
        ${currentValuation},
        ${newValuation},
        ${JSON.stringify(performanceMetrics)},
        ${reason},
        NOW(),
        NOW()
      )
    `;

    // Recalculate player index
    const newPlayerIndex = await calculatePlayerIndex(account[0].athlete_id);

    await sql`
      UPDATE nil_valuation_accounts
      SET player_index = ${newPlayerIndex}
      WHERE id = ${accountId}
    `;

    // Record player index history
    await sql`
      INSERT INTO player_index_history (
        athlete_id,
        index_value,
        valuation,
        recorded_at
      ) VALUES (
        ${account[0].athlete_id},
        ${newPlayerIndex},
        ${newValuation},
        NOW()
      )
    `;

    return createSecureResponse({
      success: true,
      previousValuation: currentValuation,
      newValuation,
      adjustmentAmount,
      newPlayerIndex,
      message: "NIL account updated successfully",
    });
  } catch (error) {
    console.error("NIL account update error:", error);
    return createSecureResponse(
      { error: "Failed to update NIL account" },
      { status: 500 },
    );
  }
}

// Utility functions
function generateAccountNumber() {
  const prefix = "NIL";
  const timestamp = Date.now().toString().slice(-8);
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}

async function calculatePlayerIndex(athleteId) {
  // Get athlete performance data
  const performance = await sql`
    SELECT AVG(ai_score) as avg_score, COUNT(*) as scan_count
    FROM motion_scans
    WHERE athlete_id = ${athleteId}
      AND created_at > NOW() - INTERVAL '90 days'
  `;

  // Get fan engagement
  const engagement = await sql`
    SELECT SUM(engagement_weight) as total_engagement
    FROM fan_engagement_actions
    WHERE athlete_id = ${athleteId}
      AND created_at > NOW() - INTERVAL '90 days'
  `;

  // Get milestone achievements
  const milestones = await sql`
    SELECT COUNT(*) as completed_milestones
    FROM milestones
    WHERE athlete_id = ${athleteId}
      AND milestone_status = 'completed'
  `;

  const avgScore = parseFloat(performance[0]?.avg_score || 0);
  const scanCount = parseInt(performance[0]?.scan_count || 0);
  const totalEngagement = parseInt(engagement[0]?.total_engagement || 0);
  const completedMilestones = parseInt(
    milestones[0]?.completed_milestones || 0,
  );

  // Player Index formula: weighted composite
  const performanceComponent = avgScore * 0.4;
  const engagementComponent = Math.min(totalEngagement / 100, 40); // Cap at 40
  const consistencyComponent = Math.min(scanCount * 0.5, 15); // Cap at 15
  const milestoneComponent = completedMilestones * 5; // 5 points per milestone

  const playerIndex =
    performanceComponent +
    engagementComponent +
    consistencyComponent +
    milestoneComponent;

  return Math.min(100, Math.max(0, playerIndex)); // Clamp to 0-100
}

async function createBrandIdentityProfile(athleteId, nilAccountId) {
  const profile = await sql`
    INSERT INTO brand_identity_profiles (
      nil_account_id,
      athlete_id,
      brand_equity_score,
      fan_sentiment_score,
      social_reach,
      sponsorship_potential,
      authenticity_index,
      market_positioning,
      profile_status,
      created_at,
      updated_at
    ) VALUES (
      ${nilAccountId},
      ${athleteId},
      50, -- Initial baseline
      50,
      0,
      50,
      75, -- Start with good authenticity
      'emerging',
      'active',
      NOW(),
      NOW()
    )
    RETURNING *
  `;

  return profile[0];
}

async function createMarginAccount(nilAccountId, riskTolerance) {
  // Calculate margin limits based on risk tolerance
  const marginLimits = {
    conservative: { maxLeverage: 1.5, marginRate: 0.05 },
    moderate: { maxLeverage: 2.0, marginRate: 0.07 },
    aggressive: { maxLeverage: 3.0, marginRate: 0.1 },
  };

  const limits = marginLimits[riskTolerance] || marginLimits.moderate;

  const marginAccount = await sql`
    INSERT INTO margin_accounts (
      nil_account_id,
      available_margin,
      utilized_margin,
      max_leverage,
      margin_rate,
      maintenance_margin,
      account_status,
      created_at,
      updated_at
    ) VALUES (
      ${nilAccountId},
      0,
      0,
      ${limits.maxLeverage},
      ${limits.marginRate},
      0,
      'active',
      NOW(),
      NOW()
    )
    RETURNING *
  `;

  return marginAccount[0];
}
