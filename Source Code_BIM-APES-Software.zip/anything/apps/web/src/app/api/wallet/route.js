import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    // Get user profile
    const userProfile = await sql`
      SELECT up.*, au.name, au.email
      FROM user_profiles up
      JOIN auth_users au ON up.user_id = au.id
      WHERE up.user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const profile = userProfile[0];

    // Get or create digital wallet
    let wallet = await sql`
      SELECT * FROM digital_wallets 
      WHERE user_id = ${profile.id}
    `;

    if (wallet.length === 0) {
      // Create new wallet
      await sql`
        INSERT INTO digital_wallets (
          user_id, 
          wallet_type, 
          balance, 
          available_balance,
          locked_balance,
          auto_reinvest_percentage,
          wallet_settings
        ) VALUES (
          ${profile.id},
          ${profile.user_type || "athlete"},
          ${0},
          ${0},
          ${0},
          ${10},
          ${JSON.stringify({
            qr_enabled: true,
            nfc_enabled: true,
            auto_pay_insurance: true,
            dao_notifications: true,
          })}
        )
      `;

      wallet = await sql`
        SELECT * FROM digital_wallets 
        WHERE user_id = ${profile.id}
      `;
    }

    const walletData = wallet[0];

    // Get recent rewards/transactions
    const recentRewards = await sql`
      SELECT * FROM rewards 
      WHERE recipient_id = ${profile.id}
      ORDER BY created_at DESC
      LIMIT 10
    `;

    // Get active milestones
    const activeMilestones = await sql`
      SELECT * FROM milestones 
      WHERE athlete_id = ${profile.id} 
      AND milestone_status = 'active'
    `;

    // Get DAO voting power (based on tier and contributions)
    let daoVotingPower = profile.tier_level * 5; // Base voting power
    if (profile.total_contributions > 100) daoVotingPower += 10;
    if (profile.total_contributions > 500) daoVotingPower += 20;

    // Determine tier name
    let tierName = "Bronze";
    if (profile.tier_level >= 5) tierName = "Elite";
    else if (profile.tier_level >= 4) tierName = "Platinum";
    else if (profile.tier_level >= 3) tierName = "Bluechip";
    else if (profile.tier_level >= 2) tierName = "Gold";
    else if (profile.tier_level >= 1) tierName = "Silver";

    // Calculate asset score based on performance and milestones
    const completedMilestones = await sql`
      SELECT COUNT(*) as completed FROM milestones 
      WHERE athlete_id = ${profile.id} 
      AND milestone_status = 'completed'
    `;

    const assetScore = Math.min(
      100,
      profile.reputation_score * 0.4 +
        completedMilestones[0].completed * 5 +
        profile.tier_level * 10 +
        (profile.total_contributions > 0 ? 20 : 0),
    );

    // Format recent activity
    const recentActivity = recentRewards.map((reward) => ({
      id: reward.id,
      type: reward.reward_type,
      description: getActivityDescription(reward.reward_type, reward.amount),
      amount: parseFloat(reward.amount),
      date: formatRelativeTime(reward.created_at),
      status: reward.distribution_status,
    }));

    return Response.json({
      success: true,
      wallet: {
        balance: parseFloat(walletData.balance),
        available_balance: parseFloat(walletData.available_balance),
        locked_balance: parseFloat(walletData.locked_balance),
        tier: tierName,
        tier_level: profile.tier_level,
        asset_score: assetScore.toFixed(1),
        dao_voting_power: daoVotingPower,
        auto_reinvest_percentage: parseFloat(
          walletData.auto_reinvest_percentage,
        ),
        settings: walletData.wallet_settings,
        insurance: {
          active: profile.tier_level >= 2, // Silver tier and above get insurance
          coverage:
            profile.tier_level >= 2
              ? ["Injury Protection", "Equipment Coverage"]
              : [],
          next_payment: "2025-04-15",
        },
      },
      profile: {
        name: profile.name,
        user_type: profile.user_type,
        reputation_score: profile.reputation_score,
        total_contributions: parseFloat(profile.total_contributions),
        total_earnings: parseFloat(profile.total_earnings),
      },
      milestones: {
        active: activeMilestones.length,
        completed: parseInt(completedMilestones[0].completed),
      },
      recent_activity: recentActivity,
    });
  } catch (error) {
    console.error("Wallet fetch error:", error);
    return Response.json(
      { error: "Failed to fetch wallet data" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json(
        { error: "Authentication required" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { action, amount, settings } = body;

    // Get user profile
    const userProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json(
        { error: "User profile not found" },
        { status: 404 },
      );
    }

    const profile = userProfile[0];

    switch (action) {
      case "update_settings":
        await sql`
          UPDATE digital_wallets 
          SET wallet_settings = ${JSON.stringify(settings)},
              updated_at = CURRENT_TIMESTAMP
          WHERE user_id = ${profile.id}
        `;
        break;

      case "update_auto_reinvest":
        const percentage = Math.max(0, Math.min(100, amount));
        await sql`
          UPDATE digital_wallets 
          SET auto_reinvest_percentage = ${percentage},
              updated_at = CURRENT_TIMESTAMP
          WHERE user_id = ${profile.id}
        `;
        break;

      case "transfer":
        // Implement transfer logic
        const wallet = await sql`
          SELECT * FROM digital_wallets WHERE user_id = ${profile.id}
        `;

        if (
          wallet.length === 0 ||
          parseFloat(wallet[0].available_balance) < amount
        ) {
          return Response.json(
            { error: "Insufficient funds" },
            { status: 400 },
          );
        }

        await sql`
          UPDATE digital_wallets 
          SET available_balance = available_balance - ${amount},
              updated_at = CURRENT_TIMESTAMP
          WHERE user_id = ${profile.id}
        `;

        // Log the transaction
        await sql`
          INSERT INTO treasury_transactions (
            transaction_type,
            amount,
            balance_after,
            reference_id,
            reference_type,
            description,
            authorized_by
          ) VALUES (
            'withdrawal',
            ${amount},
            (SELECT available_balance FROM digital_wallets WHERE user_id = ${profile.id}),
            ${profile.id},
            'wallet_transfer',
            'Wallet transfer transaction',
            ${profile.id}
          )
        `;
        break;

      default:
        return Response.json({ error: "Invalid action" }, { status: 400 });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("Wallet update error:", error);
    return Response.json({ error: "Failed to update wallet" }, { status: 500 });
  }
}

function getActivityDescription(rewardType, amount) {
  switch (rewardType) {
    case "milestone_completion":
      return `Milestone Hit: Achievement Bonus`;
    case "contribution_return":
      return `Investment Return Payout`;
    case "dao_dividend":
      return `DAO Treasury Dividend`;
    case "insurance_payout":
      return `Insurance Claim Processed`;
    case "tier_bonus":
      return `Tier Upgrade Bonus`;
    default:
      return `Reward Payment: $${amount}`;
  }
}

function formatRelativeTime(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 60) {
    return `${diffMins} minutes ago`;
  } else if (diffHours < 24) {
    return `${diffHours} hours ago`;
  } else {
    return `${diffDays} days ago`;
  }
}
