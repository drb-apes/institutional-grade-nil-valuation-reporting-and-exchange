"use client";

import { useState } from "react";
import {
  DollarSign,
  TrendingUp,
  Users,
  Zap,
  Activity,
  Target,
  ArrowRight,
  CheckCircle,
  Shield,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function SponsorPTIndexPage() {
  const { data: user, loading: authLoading } = useUser();
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [acquisitionStep, setAcquisitionStep] = useState("browse"); // browse, configure, confirm, complete
  const [configuration, setConfiguration] = useState({
    baseFee: 6000000,
    nilRoyaltyMultiplier: 1.2,
    convexityMultiplier: 0.25,
    ptTokenAllocation: 100000,
    fanTipRoyalty: 10,
    tradingRoyalty: 10,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const ptIndices = [
    {
      id: "pt-sprint-001",
      name: "PT Sprint Index",
      athlete: "Dashawn Bledsoe",
      athleteId: 1,
      sport: "Track & Field",
      tier: "Tier 1",
      baseFee: 6000000,
      fanBase: 10000,
      avgEngagement: 0.5,
      metrics: {
        sprint: { current: 18.2, threshold: 18.0 },
        acceleration: { current: 2.7, threshold: 2.5 },
        clutch: { current: 92, threshold: 85 },
      },
      projectedRevenue: {
        perGame: 4700,
        perSeason: 385400,
      },
      description:
        "Real-time sprint performance index powered by BIM-APES biometric triggers",
      benefits: [
        "Naming rights: 'PT Sprint Index powered by [Brand]'",
        "Real-time biometric overlay branding",
        "Highlight frame co-branding",
        "Coalition metadata syndication",
        "Fan-tip liquidity royalties (10%)",
        "Trading volume royalties (10%)",
        "PT token appreciation upside",
      ],
    },
    {
      id: "pt-tactical-002",
      name: "PT Tactical Efficiency Index",
      athlete: "Marcus Chen",
      athleteId: 2,
      sport: "Soccer",
      tier: "Tier 1",
      baseFee: 5500000,
      fanBase: 8500,
      avgEngagement: 0.45,
      metrics: {
        passAccuracy: { current: 89.5, threshold: 85.0 },
        tacticalIQ: { current: 91, threshold: 88 },
        positioning: { current: 87, threshold: 82 },
      },
      projectedRevenue: {
        perGame: 3900,
        perSeason: 294600,
      },
      description:
        "Tactical decision-making and positioning index for soccer performance",
      benefits: [
        "Naming rights: 'PT Tactical Index powered by [Brand]'",
        "Heat map overlay branding",
        "Match analytics co-branding",
        "Coalition syndication",
        "Fan engagement royalties",
        "Trading royalties",
        "Token upside participation",
      ],
    },
    {
      id: "pt-recovery-003",
      name: "PT Recovery Index",
      athlete: "Sarah Martinez",
      athleteId: 3,
      sport: "Wrestling",
      tier: "Tier 2",
      baseFee: 4200000,
      fanBase: 6200,
      avgEngagement: 0.38,
      metrics: {
        hrv: { current: 72, threshold: 65 },
        lactate: { current: 3.2, threshold: 4.0 },
        vo2recovery: { current: 88, threshold: 80 },
      },
      projectedRevenue: {
        perGame: 2800,
        perSeason: 201600,
      },
      description: "Post-match recovery and resilience performance index",
      benefits: [
        "Recovery analytics branding",
        "Wellness data overlay",
        "Training insights co-branding",
        "Coalition participation",
        "Fan tip royalties",
        "Trading royalties",
        "Recovery product alignment",
      ],
    },
  ];

  const handleSelectIndex = (index) => {
    setSelectedIndex(index);
    setAcquisitionStep("configure");
    setConfiguration({
      baseFee: index.baseFee,
      nilRoyaltyMultiplier: 1.2,
      convexityMultiplier: 0.25,
      ptTokenAllocation: 100000,
      fanTipRoyalty: 10,
      tradingRoyalty: 10,
    });
  };

  const handlePurchaseIndex = async () => {
    if (!selectedIndex) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/sponsor-pt-index/acquire", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          indexId: selectedIndex.id,
          athleteId: selectedIndex.athleteId,
          baseFee: configuration.baseFee,
          nilRoyaltyMultiplier: configuration.nilRoyaltyMultiplier,
          convexityMultiplier: configuration.convexityMultiplier,
          ptTokenAllocation: configuration.ptTokenAllocation,
          fanTipRoyalty: configuration.fanTipRoyalty,
          tradingRoyalty: configuration.tradingRoyalty,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to acquire PT Index");
      }

      const data = await response.json();
      setAcquisitionStep("complete");
    } catch (err) {
      console.error("Acquisition error:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#B8860B] mb-4"></div>
          <p className="text-slate-400">Loading PT Index Marketplace...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900/50 border border-slate-800 rounded-lg p-8 text-center">
          <Shield className="w-16 h-16 text-[#B8860B] mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-4">
            Sponsor Access Required
          </h2>
          <p className="text-slate-400 mb-6">
            Sign in to access the PT Index acquisition marketplace
          </p>
          <a
            href="/account/signin"
            className="inline-block px-6 py-3 bg-[#B8860B] hover:bg-[#9A7209] text-black font-semibold rounded-lg transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#B8860B]/10 to-blue-600/10 border-b border-[#B8860B]/30">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                PT Index Marketplace
              </h1>
              <p className="text-slate-400">
                Acquire biometric-powered athlete performance indices
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-400">Available Indices</div>
              <div className="text-2xl font-bold text-[#B8860B]">
                {ptIndices.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {acquisitionStep === "browse" && (
          <div className="space-y-6">
            {/* Hero Case Study */}
            <div className="bg-gradient-to-br from-[#B8860B]/20 to-blue-600/20 border border-[#B8860B]/30 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <Target className="w-12 h-12 text-[#B8860B] flex-shrink-0" />
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">
                    Hedge-Fund-Grade Case Study
                  </h3>
                  <p className="text-slate-300 mb-4">
                    <strong className="text-[#B8860B]">Adidas</strong> acquired
                    the PT Sprint Index for{" "}
                    <strong className="text-green-400">$6M</strong> base fee.
                    With <strong className="text-blue-400">10,000 fans</strong>{" "}
                    micro-tipping at <strong>$0.50 avg</strong> and{" "}
                    <strong className="text-purple-400">
                      $250K trading volume
                    </strong>{" "}
                    per game:
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-700">
                      <div className="text-xs text-slate-400">
                        Fan-Tip Royalties
                      </div>
                      <div className="text-lg font-bold text-green-400">
                        $500/game
                      </div>
                    </div>
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-700">
                      <div className="text-xs text-slate-400">
                        Trading Royalties
                      </div>
                      <div className="text-lg font-bold text-blue-400">
                        $2,500/game
                      </div>
                    </div>
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-700">
                      <div className="text-xs text-slate-400">
                        Token Appreciation
                      </div>
                      <div className="text-lg font-bold text-purple-400">
                        $1,700/game
                      </div>
                    </div>
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-[#B8860B]">
                      <div className="text-xs text-slate-400">
                        Season Projection
                      </div>
                      <div className="text-lg font-bold text-[#B8860B]">
                        $385,400
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Available Indices */}
            <div className="grid grid-cols-1 gap-6">
              {ptIndices.map((index) => (
                <div
                  key={index.id}
                  className="bg-slate-900/50 border border-slate-700 hover:border-[#B8860B]/50 rounded-xl p-6 transition-all cursor-pointer"
                  onClick={() => handleSelectIndex(index)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <Activity className="w-6 h-6 text-[#B8860B]" />
                        <h3 className="text-xl font-bold text-white">
                          {index.name}
                        </h3>
                        <span className="px-2 py-1 bg-[#B8860B]/20 text-[#B8860B] text-xs rounded">
                          {index.tier}
                        </span>
                      </div>
                      <p className="text-slate-400 text-sm">
                        {index.athlete} • {index.sport}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-slate-400">Base Fee</div>
                      <div className="text-2xl font-bold text-white">
                        ${(index.baseFee / 1000000).toFixed(1)}M
                      </div>
                    </div>
                  </div>

                  <p className="text-slate-300 text-sm mb-4">
                    {index.description}
                  </p>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    {Object.entries(index.metrics).map(([key, value]) => (
                      <div key={key} className="bg-slate-800/50 rounded-lg p-3">
                        <div className="text-xs text-slate-400 capitalize mb-1">
                          {key.replace(/([A-Z])/g, " $1").trim()}
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-lg font-bold text-white">
                            {value.current}
                          </div>
                          {value.current >= value.threshold && (
                            <CheckCircle className="w-4 h-4 text-green-400" />
                          )}
                        </div>
                        <div className="text-xs text-slate-500">
                          Threshold: {value.threshold}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Revenue Projections */}
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-gradient-to-br from-green-600/10 to-green-600/5 border border-green-600/30 rounded-lg p-3">
                      <div className="text-xs text-slate-400">
                        Per Game Revenue
                      </div>
                      <div className="text-xl font-bold text-green-400">
                        ${index.projectedRevenue.perGame.toLocaleString()}
                      </div>
                    </div>
                    <div className="bg-gradient-to-br from-[#B8860B]/10 to-[#B8860B]/5 border border-[#B8860B]/30 rounded-lg p-3">
                      <div className="text-xs text-slate-400">
                        Season Projection
                      </div>
                      <div className="text-xl font-bold text-[#B8860B]">
                        ${index.projectedRevenue.perSeason.toLocaleString()}
                      </div>
                    </div>
                  </div>

                  {/* Fan Base */}
                  <div className="flex items-center gap-4 text-sm text-slate-400 mb-4">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>{index.fanBase.toLocaleString()} active fans</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      <span>${index.avgEngagement.toFixed(2)} avg tip</span>
                    </div>
                  </div>

                  {/* CTA */}
                  <button className="w-full px-4 py-3 bg-[#B8860B] hover:bg-[#9A7209] text-black font-semibold rounded-lg transition-colors flex items-center justify-center gap-2">
                    Acquire Index
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {acquisitionStep === "configure" && selectedIndex && (
          <div className="max-w-4xl mx-auto space-y-6">
            <button
              onClick={() => {
                setAcquisitionStep("browse");
                setSelectedIndex(null);
              }}
              className="text-slate-400 hover:text-white transition-colors flex items-center gap-2"
            >
              ← Back to marketplace
            </button>

            <div className="bg-slate-900/50 border border-[#B8860B]/30 rounded-xl p-6">
              <h2 className="text-2xl font-bold text-white mb-4">
                Configure Acquisition
              </h2>
              <p className="text-slate-400 mb-6">
                {selectedIndex.name} • {selectedIndex.athlete}
              </p>

              <div className="space-y-6">
                {/* Base Fee */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Base Fee (USD)
                  </label>
                  <input
                    type="number"
                    value={configuration.baseFee}
                    onChange={(e) =>
                      setConfiguration({
                        ...configuration,
                        baseFee: parseInt(e.target.value),
                      })
                    }
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-[#B8860B]"
                  />
                  <p className="text-xs text-slate-500 mt-1">
                    Standard base fee for {selectedIndex.tier} indices
                  </p>
                </div>

                {/* NIL Royalty Multiplier */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    NIL Royalty Multiplier (%)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={configuration.nilRoyaltyMultiplier}
                    onChange={(e) =>
                      setConfiguration({
                        ...configuration,
                        nilRoyaltyMultiplier: parseFloat(e.target.value),
                      })
                    }
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-[#B8860B]"
                  />
                </div>

                {/* PT Token Allocation */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    PT Token Allocation
                  </label>
                  <input
                    type="number"
                    value={configuration.ptTokenAllocation}
                    onChange={(e) =>
                      setConfiguration({
                        ...configuration,
                        ptTokenAllocation: parseInt(e.target.value),
                      })
                    }
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-[#B8860B]"
                  />
                  <p className="text-xs text-slate-500 mt-1">
                    Token appreciation upside participation
                  </p>
                </div>

                {/* Royalty Splits */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Fan-Tip Royalty (%)
                    </label>
                    <input
                      type="number"
                      value={configuration.fanTipRoyalty}
                      onChange={(e) =>
                        setConfiguration({
                          ...configuration,
                          fanTipRoyalty: parseInt(e.target.value),
                        })
                      }
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-[#B8860B]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Trading Royalty (%)
                    </label>
                    <input
                      type="number"
                      value={configuration.tradingRoyalty}
                      onChange={(e) =>
                        setConfiguration({
                          ...configuration,
                          tradingRoyalty: parseInt(e.target.value),
                        })
                      }
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-[#B8860B]"
                    />
                  </div>
                </div>

                {/* Benefits Summary */}
                <div className="bg-gradient-to-br from-[#B8860B]/10 to-blue-600/10 border border-[#B8860B]/30 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-white mb-3">
                    Included Benefits
                  </h4>
                  <ul className="space-y-2">
                    {selectedIndex.benefits.map((benefit, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2 text-sm text-slate-300"
                      >
                        <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {error && (
                  <div className="bg-red-600/10 border border-red-600/30 rounded-lg p-4">
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                <div className="flex gap-4">
                  <button
                    onClick={() => setAcquisitionStep("browse")}
                    className="flex-1 px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handlePurchaseIndex}
                    disabled={loading}
                    className="flex-1 px-6 py-3 bg-[#B8860B] hover:bg-[#9A7209] text-black font-semibold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-black"></div>
                        Processing...
                      </>
                    ) : (
                      <>
                        Confirm Acquisition
                        <ArrowRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {acquisitionStep === "complete" && selectedIndex && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-gradient-to-br from-green-600/20 to-green-600/5 border border-green-600/30 rounded-xl p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-600 rounded-full mb-4">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">
                Acquisition Complete!
              </h2>
              <p className="text-slate-300 mb-6">
                You now own the{" "}
                <strong className="text-[#B8860B]">{selectedIndex.name}</strong>
              </p>

              <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-6 mb-6">
                <div className="grid grid-cols-2 gap-4 text-left">
                  <div>
                    <div className="text-sm text-slate-400">Base Fee Paid</div>
                    <div className="text-xl font-bold text-white">
                      ${(configuration.baseFee / 1000000).toFixed(1)}M
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-slate-400">
                      PT Tokens Allocated
                    </div>
                    <div className="text-xl font-bold text-[#B8860B]">
                      {configuration.ptTokenAllocation.toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-slate-400">
                      Fan-Tip Royalty
                    </div>
                    <div className="text-xl font-bold text-green-400">
                      {configuration.fanTipRoyalty}%
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-slate-400">
                      Trading Royalty
                    </div>
                    <div className="text-xl font-bold text-blue-400">
                      {configuration.tradingRoyalty}%
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <a
                  href="/sponsor-hedge-dashboard"
                  className="flex-1 px-6 py-3 bg-[#B8860B] hover:bg-[#9A7209] text-black font-semibold rounded-lg transition-colors inline-flex items-center justify-center gap-2"
                >
                  <TrendingUp className="w-5 h-5" />
                  Go to Dashboard
                </a>
                <button
                  onClick={() => {
                    setAcquisitionStep("browse");
                    setSelectedIndex(null);
                  }}
                  className="flex-1 px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
                >
                  Acquire Another
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
