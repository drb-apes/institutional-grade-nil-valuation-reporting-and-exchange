"use client";

import {
  Activity,
  Users,
  Zap,
  Target,
  Music,
  Network,
  BarChart3,
  Eye,
  Shield,
} from "lucide-react";
import useUser from "@/utils/useUser";
import LicensingFooter from "@/components/LicensingFooter";

const DASHBOARD_MODULES = [
  {
    category: "Advanced Visualization",
    dashboards: [
      {
        name: "BIM Visualization Suite",
        description:
          "AR Biomechanical Overlay & Biomechflow Charts for all 47 sports",
        icon: Eye,
        url: "/bim-visualization-dashboard",
        color: "indigo",
        features: [
          "AR Overlay",
          "Biomechflow Charts",
          "47 Sports",
          "Real-Time Analysis",
        ],
      },
      {
        name: "BiomechFlow Capsule",
        description:
          "BiomechFlow Capsule™ · Takedown efficiency, control time, pin probability",
        icon: Eye,
        url: "/biomechflow-capsule-dashboard",
        color: "indigo",
        features: [
          "Takedown Analysis",
          "Period Breakdown",
          "BIM Score",
          "Pin Probability",
        ],
      },
    ],
  },
  {
    category: "Combat Sports",
    dashboards: [
      {
        name: "Wrestling Performance",
        description:
          "BiomechFlow Capsule™ · Takedown efficiency, control time, pin probability",
        icon: Activity,
        url: "/wrestling-dashboard",
        color: "blue",
        features: [
          "BiomechFlow Capsule",
          "Takedown Analysis",
          "Period Breakdown",
          "BIM Score",
        ],
      },
      {
        name: "Consistency Monitor",
        description:
          "Session-by-session consistency tracking with NIL premium calculation",
        icon: Shield,
        url: "/american-football-dashboard",
        color: "amber",
        features: [
          "QB · RB · WR · DB · LB",
          "Session Consistency Curve",
          "BIM Score",
          "NIL Premium",
        ],
      },
    ],
  },
  {
    category: "Tactical Sports",
    dashboards: [
      {
        name: "Tactical Efficiency",
        description:
          "Possession efficiency for Rugby, Soccer, Basketball with BIM scoring",
        icon: Users,
        url: "/tactical-sports-dashboard",
        color: "green",
        features: [
          "Rugby · Soccer · Basketball",
          "Possession Analysis",
          "Spatial Awareness",
          "Decision Making",
        ],
      },
    ],
  },
  {
    category: "Racket Sports",
    dashboards: [
      {
        name: "Spike Analysis",
        description:
          "Serve quality, momentum spikes, court heatmap — Tennis, Pickleball, Badminton",
        icon: Zap,
        url: "/racket-sports-dashboard",
        color: "purple",
        features: [
          "Spike Score",
          "Court Heatmap",
          "Momentum Peaks",
          "Break Point Analysis",
        ],
      },
    ],
  },
  {
    category: "Entertainment NIL",
    dashboards: [
      {
        name: "Music NIL Concert",
        description:
          "Concert Performance Units™ · Songs = Possessions · Live NIL valuation",
        icon: Music,
        url: "/concert-nil-dashboard",
        color: "pink",
        features: [
          "CPU Feed",
          "Live NIL Chart",
          "Sponsor ROI",
          "Social Spike Detection",
        ],
      },
    ],
  },
  {
    category: "Infrastructure",
    dashboards: [
      {
        name: "Mesh Network",
        description: "Wearable device synchronization & topology management",
        icon: Network,
        url: "/mesh-network-dashboard",
        color: "cyan",
        features: [
          "Multi-Device Sync",
          "Offline Support",
          "Topology Health",
          "Real-Time Streaming",
        ],
      },
    ],
  },
];

export default function SportsHub() {
  const { data: user, loading } = useUser();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">
            BIM-APES Sports Intelligence Hub
          </h1>
          <p className="text-indigo-300 mb-8">
            Please sign in to access sport-specific dashboards
          </p>
          <a
            href="/account/signin"
            className="inline-block bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 p-6">
      {/* Hero Header */}
      <div className="max-w-7xl mx-auto mb-12">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <BarChart3 className="w-16 h-16 text-indigo-400" />
            <h1 className="text-5xl font-bold text-white">
              BIM-APES Sports Hub
            </h1>
          </div>
          <p className="text-indigo-200 text-xl mb-6">
            Biomechanical Intelligence · Multi-Sport Analytics · Performance
            Ecosystem
          </p>

          <div className="flex items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2 text-green-400">
              <Activity className="w-5 h-5" />
              <span className="font-semibold">47 Sports Supported</span>
            </div>
            <div className="flex items-center gap-2 text-blue-400">
              <Network className="w-5 h-5" />
              <span className="font-semibold">Mesh Network Ready</span>
            </div>
            <div className="flex items-center gap-2 text-purple-400">
              <Eye className="w-5 h-5" />
              <span className="font-semibold">AR Visualization</span>
            </div>
          </div>
        </div>

        {/* User Info */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 max-w-md mx-auto">
          <p className="text-white text-center">
            Welcome,{" "}
            <span className="font-bold text-indigo-400">
              {user.name || user.email}
            </span>
          </p>
        </div>
      </div>

      {/* Dashboard Grid */}
      <div className="max-w-7xl mx-auto space-y-12">
        {DASHBOARD_MODULES.map((module) => (
          <div key={module.category}>
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
              <div className="w-1 h-8 bg-gradient-to-b from-indigo-500 to-purple-500 rounded-full" />
              {module.category}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {module.dashboards.map((dashboard) => {
                const Icon = dashboard.icon;
                const colorClasses = {
                  indigo:
                    "from-indigo-600 to-indigo-700 border-indigo-500/50 hover:border-indigo-400",
                  blue: "from-blue-600 to-blue-700 border-blue-500/50 hover:border-blue-400",
                  green:
                    "from-green-600 to-green-700 border-green-500/50 hover:border-green-400",
                  purple:
                    "from-purple-600 to-purple-700 border-purple-500/50 hover:border-purple-400",
                  pink: "from-pink-600 to-pink-700 border-pink-500/50 hover:border-pink-400",
                  cyan: "from-cyan-600 to-cyan-700 border-cyan-500/50 hover:border-cyan-400",
                  amber:
                    "from-amber-600 to-amber-700 border-amber-500/50 hover:border-amber-400",
                };

                return (
                  <a
                    key={dashboard.name}
                    href={dashboard.url}
                    className={`group bg-gradient-to-br ${colorClasses[dashboard.color]} p-6 rounded-xl border-2 transition-all hover:scale-105 hover:shadow-2xl`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <Icon className="w-10 h-10 text-white" />
                      <div className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                        <span className="text-white text-xs font-semibold">
                          LIVE
                        </span>
                      </div>
                    </div>

                    <h3 className="text-xl font-bold text-white mb-2">
                      {dashboard.name}
                    </h3>
                    <p className="text-white/80 text-sm mb-4">
                      {dashboard.description}
                    </p>

                    <div className="space-y-2">
                      {dashboard.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-white/60" />
                          <span className="text-white/70 text-xs">
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 pt-4 border-t border-white/20">
                      <span className="text-white font-semibold text-sm group-hover:underline">
                        Open Dashboard →
                      </span>
                    </div>
                  </a>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Quick Access Panel */}
      <div className="max-w-7xl mx-auto mt-12">
        <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8 border border-white/10">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">
            Quick Access
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <QuickAccessButton
              href="/motion-scan"
              label="Motion Capture"
              icon={Activity}
            />
            <QuickAccessButton
              href="/athlete-dashboard"
              label="Athlete Portal"
              icon={Target}
            />
            <QuickAccessButton
              href="/coach-portal"
              label="Coach Portal"
              icon={Users}
            />
            <QuickAccessButton
              href="/mesh-network-dashboard"
              label="Mesh Network"
              icon={Network}
            />
          </div>
        </div>
      </div>

      {/* Licensing Footer */}
      <div className="max-w-7xl mx-auto mt-12">
        <LicensingFooter />
      </div>
    </div>
  );
}

function QuickAccessButton({ href, label, icon: Icon }) {
  return (
    <a
      href={href}
      className="flex flex-col items-center gap-3 p-6 bg-slate-800 rounded-xl border border-slate-700 hover:border-indigo-500 hover:bg-slate-700 transition-all group"
    >
      <Icon className="w-8 h-8 text-indigo-400 group-hover:text-indigo-300" />
      <span className="text-white font-medium text-sm text-center">
        {label}
      </span>
    </a>
  );
}
