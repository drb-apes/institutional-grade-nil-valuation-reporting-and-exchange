"use client";

import { useState, useEffect, useRef } from "react";
import { Box, MapPin, Thermometer, Wind, Activity } from "lucide-react";
import useUser from "@/utils/useUser";

export default function SpatialIntelligenceDashboard() {
  const { data: user, loading } = useUser();
  const [activeTab, setActiveTab] = useState("biomech");
  const [athleteId, setAthleteId] = useState("");
  const [capsuleData, setCapsuleData] = useState(null);
  const [spatialData, setSpatialData] = useState(null);
  const [envData, setEnvData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  const handleTestBiomechCapsule = async () => {
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }

    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/spatial-intelligence/biomech-capsules",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            capsuleType: "joint",
            spatialContext: {
              joint: "knee",
              position3D: { x: 0, y: 1.2, z: 0 },
              orientation: { pitch: 45, roll: 0, yaw: 0 },
              jointAngle: 90,
              rangeOfMotion: 135,
            },
            biomechanicalData: {
              force: 850,
              torque: 120,
              velocity: 2.5,
              acceleration: 5.2,
              power: 450,
              rangeOfMotion: 135,
              muscleActivation: 75,
              jointLoad: 65,
              impactForce: 3200,
              repetitionCount: 45,
            },
            environmentalContext: {
              temperature: 22,
              humidity: 55,
              altitude: 300,
            },
          }),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to create biomech capsule");
      }

      const data = await response.json();
      setCapsuleData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  const handleTest3DMapping = async () => {
    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch("/api/spatial-intelligence/3d-mapping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: "test_session_123",
          athleteIds: [1, 2, 3, 4, 5],
          venueId: "stadium_001",
          positions: [
            {
              athleteId: 1,
              position3D: { x: 10, y: 20, z: 1 },
              velocity: { x: 2, y: 1, z: 0 },
            },
            {
              athleteId: 2,
              position3D: { x: 15, y: 25, z: 1 },
              velocity: { x: 1.5, y: 2, z: 0 },
            },
            {
              athleteId: 3,
              position3D: { x: 20, y: 30, z: 1 },
              velocity: { x: 3, y: 1.5, z: 0 },
            },
            {
              athleteId: 4,
              position3D: { x: 12, y: 22, z: 1 },
              velocity: { x: 2.5, y: 1.8, z: 0 },
            },
            {
              athleteId: 5,
              position3D: { x: 18, y: 28, z: 1 },
              velocity: { x: 1.8, y: 2.2, z: 0 },
            },
          ],
          environmentalData: {
            temperature: 25,
            humidity: 60,
            altitude: 500,
            windSpeed: 3,
          },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to process 3D mapping");
      }

      const data = await response.json();
      setSpatialData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  const handleTestEnvironmental = async () => {
    setLoadingData(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/spatial-intelligence/environmental-context",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sessionId: "test_session_123",
            venueId: "stadium_001",
            environmentalReadings: {
              temperature: 32,
              humidity: 75,
              altitude: 2000,
              windSpeed: 8,
              windDirection: 180,
              airQualityIndex: 85,
              lightingConditions: "outdoor_sunny",
              surfaceType: "artificial_turf",
            },
          }),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to process environmental context");
      }

      const data = await response.json();
      setEnvData(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-indigo-400 underline">
            sign in
          </a>{" "}
          to access this dashboard
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center gap-4 mb-2">
          <Box className="w-10 h-10 text-indigo-400" />
          <h1 className="text-4xl font-bold text-white">
            Spatial Intelligence Layer
          </h1>
        </div>
        <p className="text-indigo-200 text-lg">
          3D Mapping · Biomech Capsules · Environmental Context
        </p>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Tab Navigation */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab("biomech")}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === "biomech"
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-800 text-indigo-300 hover:bg-slate-700"
              }`}
            >
              <Activity className="w-5 h-5 inline-block mr-2" />
              Biomech Capsules
            </button>
            <button
              onClick={() => setActiveTab("3d")}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === "3d"
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-800 text-indigo-300 hover:bg-slate-700"
              }`}
            >
              <MapPin className="w-5 h-5 inline-block mr-2" />
              3D Mapping
            </button>
            <button
              onClick={() => setActiveTab("environmental")}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === "environmental"
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-800 text-indigo-300 hover:bg-slate-700"
              }`}
            >
              <Thermometer className="w-5 h-5 inline-block mr-2" />
              Environmental
            </button>
          </div>
        </div>

        {/* Biomech Capsules Tab */}
        {activeTab === "biomech" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">
                Create Biomech Capsule
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-indigo-200 mb-2 font-medium">
                    Athlete ID
                  </label>
                  <input
                    type="number"
                    value={athleteId}
                    onChange={(e) => setAthleteId(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg bg-slate-800 text-white border border-slate-600 focus:border-indigo-400 focus:outline-none"
                    placeholder="Enter athlete ID"
                  />
                </div>

                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
                  <p className="text-indigo-200 text-sm mb-2">
                    Test Configuration:
                  </p>
                  <p className="text-white text-sm">• Joint: Knee</p>
                  <p className="text-white text-sm">• Force: 850 N</p>
                  <p className="text-white text-sm">• Power: 450 W</p>
                  <p className="text-white text-sm">• Joint Angle: 90°</p>
                  <p className="text-white text-sm">• Muscle Activation: 75%</p>
                </div>

                {error && (
                  <div className="bg-red-500/20 border border-red-500 rounded-lg p-4">
                    <p className="text-red-200">{error}</p>
                  </div>
                )}

                <button
                  onClick={handleTestBiomechCapsule}
                  disabled={loadingData}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all disabled:opacity-50"
                >
                  {loadingData ? "Processing..." : "Create Biomech Capsule"}
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              {!capsuleData ? (
                <div className="flex flex-col items-center justify-center h-full text-indigo-300">
                  <Box className="w-16 h-16 mb-4 opacity-50" />
                  <p>Capsule analysis will appear here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Capsule Analysis
                  </h3>

                  <div className="grid grid-cols-3 gap-3">
                    <MetricBox
                      label="Stress"
                      value={capsuleData.metrics.stress.toFixed(1)}
                      max={100}
                      color="red"
                    />
                    <MetricBox
                      label="Fatigue"
                      value={capsuleData.metrics.fatigue.toFixed(1)}
                      max={100}
                      color="yellow"
                    />
                    <MetricBox
                      label="Injury Risk"
                      value={capsuleData.metrics.injuryRisk.toFixed(1)}
                      max={100}
                      color="orange"
                    />
                  </div>

                  <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
                    <p className="text-indigo-200 text-sm mb-2">
                      Capsule ID: {capsuleData.capsuleId}
                    </p>
                    <p className="text-white text-sm">
                      Type:{" "}
                      <span className="font-mono">
                        {capsuleData.capsuleType}
                      </span>
                    </p>
                    <p className="text-white text-sm">
                      Localization:{" "}
                      <span className="font-mono">
                        {capsuleData.spatialLocalization}
                      </span>
                    </p>
                  </div>

                  {capsuleData.recommendations &&
                    capsuleData.recommendations.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-white font-semibold">
                          Recommendations
                        </h4>
                        {capsuleData.recommendations.map((rec, idx) => (
                          <div
                            key={idx}
                            className={`rounded-lg p-3 border ${
                              rec.priority === "critical"
                                ? "bg-red-500/10 border-red-500/30"
                                : rec.priority === "high"
                                  ? "bg-orange-500/10 border-orange-500/30"
                                  : "bg-blue-500/10 border-blue-500/30"
                            }`}
                          >
                            <p className="text-white text-sm font-medium mb-1">
                              {rec.message}
                            </p>
                            {rec.actions && (
                              <ul className="text-xs text-blue-200 list-disc list-inside">
                                {rec.actions.map((action, i) => (
                                  <li key={i}>{action}</li>
                                ))}
                              </ul>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3D Mapping Tab */}
        {activeTab === "3d" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">
                3D Position Mapping
              </h2>

              <div className="space-y-4">
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
                  <p className="text-indigo-200 text-sm mb-2">
                    Test Configuration:
                  </p>
                  <p className="text-white text-sm">• 5 athletes tracked</p>
                  <p className="text-white text-sm">• Venue: stadium_001</p>
                  <p className="text-white text-sm">
                    • Real-time position + velocity
                  </p>
                  <p className="text-white text-sm">
                    • Environmental context included
                  </p>
                </div>

                {error && (
                  <div className="bg-red-500/20 border border-red-500 rounded-lg p-4">
                    <p className="text-red-200">{error}</p>
                  </div>
                )}

                <button
                  onClick={handleTest3DMapping}
                  disabled={loadingData}
                  className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-indigo-700 hover:to-blue-700 transition-all disabled:opacity-50"
                >
                  {loadingData ? "Processing..." : "Test 3D Mapping"}
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              {!spatialData ? (
                <div className="flex flex-col items-center justify-center h-full text-indigo-300">
                  <MapPin className="w-16 h-16 mb-4 opacity-50" />
                  <p>3D mapping results will appear here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Spatial Metrics
                  </h3>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-600">
                      <p className="text-indigo-200 text-xs mb-1">Spread</p>
                      <p className="text-white text-xl font-bold">
                        {spatialData.spatialMetrics.spread.toFixed(2)}m
                      </p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-600">
                      <p className="text-indigo-200 text-xs mb-1">Density</p>
                      <p className="text-white text-xl font-bold">
                        {spatialData.spatialMetrics.density.toFixed(3)}
                      </p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-600">
                      <p className="text-indigo-200 text-xs mb-1">
                        Avg Velocity
                      </p>
                      <p className="text-white text-xl font-bold">
                        {spatialData.spatialMetrics.avgVelocity.toFixed(2)} m/s
                      </p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-600">
                      <p className="text-indigo-200 text-xs mb-1">
                        Max Velocity
                      </p>
                      <p className="text-white text-xl font-bold">
                        {spatialData.spatialMetrics.maxVelocity.toFixed(2)} m/s
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
                    <h4 className="text-white font-semibold mb-2">
                      Center of Mass
                    </h4>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <p className="text-indigo-200 text-xs">X</p>
                        <p className="text-white font-mono">
                          {spatialData.spatialMetrics.centerOfMass.x.toFixed(2)}
                        </p>
                      </div>
                      <div>
                        <p className="text-indigo-200 text-xs">Y</p>
                        <p className="text-white font-mono">
                          {spatialData.spatialMetrics.centerOfMass.y.toFixed(2)}
                        </p>
                      </div>
                      <div>
                        <p className="text-indigo-200 text-xs">Z</p>
                        <p className="text-white font-mono">
                          {spatialData.spatialMetrics.centerOfMass.z.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {spatialData.proximityEvents &&
                    spatialData.proximityEvents.length > 0 && (
                      <div className="bg-yellow-500/10 rounded-lg p-4 border border-yellow-500/30">
                        <h4 className="text-yellow-200 font-semibold mb-2">
                          Proximity Events
                        </h4>
                        <p className="text-white text-sm">
                          {spatialData.proximityEvents.length} event(s) detected
                        </p>
                      </div>
                    )}

                  {spatialData.heatmapData &&
                    spatialData.heatmapData.length > 0 && (
                      <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
                        <h4 className="text-white font-semibold mb-2">
                          Heatmap Hotspots
                        </h4>
                        <div className="space-y-1">
                          {spatialData.heatmapData
                            .slice(0, 5)
                            .map((spot, idx) => (
                              <div
                                key={idx}
                                className="flex justify-between items-center"
                              >
                                <span className="text-indigo-200 text-sm font-mono">
                                  ({spot.x}, {spot.y}, {spot.z})
                                </span>
                                <span className="text-white text-sm">
                                  Intensity: {spot.intensity}
                                </span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Environmental Tab */}
        {activeTab === "environmental" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <h2 className="text-2xl font-bold text-white mb-6">
                Environmental Context
              </h2>

              <div className="space-y-4">
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-600">
                  <p className="text-indigo-200 text-sm mb-2">
                    Test Conditions:
                  </p>
                  <p className="text-white text-sm">
                    • Temperature: 32°C (Hot)
                  </p>
                  <p className="text-white text-sm">
                    • Humidity: 75% (Very Humid)
                  </p>
                  <p className="text-white text-sm">
                    • Altitude: 2000m (Elevated)
                  </p>
                  <p className="text-white text-sm">• Wind: 8 m/s (Moderate)</p>
                  <p className="text-white text-sm">• AQI: 85 (Moderate)</p>
                </div>

                {error && (
                  <div className="bg-red-500/20 border border-red-500 rounded-lg p-4">
                    <p className="text-red-200">{error}</p>
                  </div>
                )}

                <button
                  onClick={handleTestEnvironmental}
                  disabled={loadingData}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 transition-all disabled:opacity-50"
                >
                  {loadingData
                    ? "Processing..."
                    : "Analyze Environmental Impact"}
                </button>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              {!envData ? (
                <div className="flex flex-col items-center justify-center h-full text-indigo-300">
                  <Wind className="w-16 h-16 mb-4 opacity-50" />
                  <p>Environmental analysis will appear here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Environmental Impact
                  </h3>

                  <div className="bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-lg p-6 border border-orange-400/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-orange-200 font-medium">
                        Impact Score
                      </span>
                      <span className="text-3xl font-bold text-orange-400">
                        {envData.impactScore.toFixed(0)}
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-orange-400 to-red-400 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${envData.impactScore}%` }}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <EnvironmentalMetric
                      label="Temperature"
                      value={`${envData.environmentalContext.temperature.value}°C`}
                      impact={envData.environmentalContext.temperature.impact}
                    />
                    <EnvironmentalMetric
                      label="Humidity"
                      value={`${envData.environmentalContext.humidity.value}%`}
                      impact={envData.environmentalContext.humidity.impact}
                    />
                    <EnvironmentalMetric
                      label="Altitude"
                      value={`${envData.environmentalContext.altitude.value}m`}
                      impact={envData.environmentalContext.altitude.impact}
                    />
                    <EnvironmentalMetric
                      label="Wind Speed"
                      value={`${envData.environmentalContext.wind.speed} m/s`}
                      impact={envData.environmentalContext.wind.impact}
                    />
                  </div>

                  {envData.recommendations &&
                    envData.recommendations.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-white font-semibold">
                          Recommendations
                        </h4>
                        {envData.recommendations.map((rec, idx) => (
                          <div
                            key={idx}
                            className={`rounded-lg p-3 border ${
                              rec.priority === "critical"
                                ? "bg-red-500/10 border-red-500/30"
                                : rec.priority === "high"
                                  ? "bg-orange-500/10 border-orange-500/30"
                                  : "bg-blue-500/10 border-blue-500/30"
                            }`}
                          >
                            <p className="text-white text-sm font-medium mb-1">
                              {rec.message}
                            </p>
                            {rec.actions && (
                              <ul className="text-xs text-blue-200 list-disc list-inside">
                                {rec.actions.map((action, i) => (
                                  <li key={i}>{action}</li>
                                ))}
                              </ul>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function MetricBox({ label, value, max, color }) {
  const percentage = (parseFloat(value) / max) * 100;

  const colorClasses = {
    red: "from-red-500/20 to-red-600/20 border-red-400/30 text-red-400",
    yellow:
      "from-yellow-500/20 to-yellow-600/20 border-yellow-400/30 text-yellow-400",
    orange:
      "from-orange-500/20 to-orange-600/20 border-orange-400/30 text-orange-400",
    blue: "from-blue-500/20 to-blue-600/20 border-blue-400/30 text-blue-400",
  };

  return (
    <div
      className={`bg-gradient-to-r ${colorClasses[color]} rounded-lg p-4 border`}
    >
      <p className="text-white text-xs mb-1">{label}</p>
      <p
        className={`text-2xl font-bold ${colorClasses[color].split(" ").pop()}`}
      >
        {value}
      </p>
      <div className="w-full bg-slate-700 rounded-full h-1 mt-2">
        <div
          className={`bg-gradient-to-r ${color === "red" ? "from-red-400 to-red-500" : color === "yellow" ? "from-yellow-400 to-yellow-500" : color === "orange" ? "from-orange-400 to-orange-500" : "from-blue-400 to-blue-500"} h-1 rounded-full`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

function EnvironmentalMetric({ label, value, impact }) {
  const getImpactColor = (impact) => {
    if (
      impact.includes("severe") ||
      impact === "hazardous" ||
      impact === "critical"
    )
      return "text-red-400";
    if (
      impact.includes("hot") ||
      impact.includes("cold") ||
      impact === "unhealthy" ||
      impact === "high_altitude"
    )
      return "text-orange-400";
    if (
      impact === "optimal" ||
      impact === "comfortable" ||
      impact === "good" ||
      impact === "calm"
    )
      return "text-green-400";
    return "text-yellow-400";
  };

  return (
    <div className="flex justify-between items-center bg-slate-800/50 rounded-lg p-3 border border-slate-600">
      <span className="text-indigo-200 text-sm">{label}</span>
      <div className="text-right">
        <p className="text-white text-sm font-mono">{value}</p>
        <p
          className={`text-xs uppercase font-semibold ${getImpactColor(impact)}`}
        >
          {impact.replace(/_/g, " ")}
        </p>
      </div>
    </div>
  );
}
