"use client";
import { useState } from "react";
import useUser from "@/utils/useUser";
import { useAnalyticsDashboard } from "@/hooks/useAnalyticsDashboard";
import { AnalyticsHeader } from "@/components/AnalyticsDashboard/AnalyticsHeader";
import { AnalyticsTabs } from "@/components/AnalyticsDashboard/AnalyticsTabs";
import { OverviewTab } from "@/components/AnalyticsDashboard/OverviewTab";
import { AdvancedMetricsTab } from "@/components/AnalyticsDashboard/AdvancedMetricsTab";
import { PredictiveModelsTab } from "@/components/AnalyticsDashboard/PredictiveModelsTab";
import { TierAnalysisTab } from "@/components/AnalyticsDashboard/TierAnalysisTab";
import { RiskAssessmentTab } from "@/components/AnalyticsDashboard/RiskAssessmentTab";
import { LoadingView } from "@/components/AnalyticsDashboard/LoadingView";
import { AuthRequiredView } from "@/components/AnalyticsDashboard/AuthRequiredView";

export default function AnalyticsDashboardPage() {
  const { data: user, loading: userLoading } = useUser();
  const {
    analytics,
    predictions,
    loading,
    timeframe,
    setTimeframe,
    predictionHorizon,
    setPredictionHorizon,
  } = useAnalyticsDashboard(user);

  const [activeTab, setActiveTab] = useState("overview");

  if (userLoading) {
    return <LoadingView />;
  }

  if (!user) {
    return <AuthRequiredView />;
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-12">
        <div className="max-w-7xl mx-auto">
          <AnalyticsHeader
            timeframe={timeframe}
            setTimeframe={setTimeframe}
            predictionHorizon={predictionHorizon}
            setPredictionHorizon={setPredictionHorizon}
          />

          <AnalyticsTabs activeTab={activeTab} setActiveTab={setActiveTab} />

          {loading && (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin w-8 h-8 border-2 border-[#B8860B] border-t-transparent rounded-full mr-4"></div>
              <span className="text-[#B8860B]">Generating analytics...</span>
            </div>
          )}

          {!loading && (
            <>
              {activeTab === "overview" && (
                <OverviewTab analytics={analytics} predictions={predictions} />
              )}
              {activeTab === "metrics" && (
                <AdvancedMetricsTab analytics={analytics} />
              )}
              {activeTab === "predictions" && (
                <PredictiveModelsTab predictions={predictions} />
              )}
              {activeTab === "tiers" && (
                <TierAnalysisTab analytics={analytics} />
              )}
              {activeTab === "risk" && (
                <RiskAssessmentTab analytics={analytics} />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
