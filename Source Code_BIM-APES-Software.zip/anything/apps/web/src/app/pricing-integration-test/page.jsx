"use client";

import { useState } from "react";

export default function PricingIntegrationTest() {
  const [testResults, setTestResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);

  const addResult = (name, success, data, error = null) => {
    setTestResults((prev) => [
      ...prev,
      {
        name,
        success,
        data,
        error,
        timestamp: new Date().toISOString(),
      },
    ]);
  };

  // TEST 1: Get Pricing Tiers
  const testGetTiers = async () => {
    try {
      const response = await fetch("/api/pricing/tiers");
      const data = await response.json();

      addResult("GET /pricing/tiers", response.ok, data);
      return data;
    } catch (error) {
      addResult("GET /pricing/tiers", false, null, error.message);
      throw error;
    }
  };

  // TEST 2: Calculate Domain Pack Index
  const testDomainPack = async (orgData) => {
    try {
      const response = await fetch("/api/pricing/domain-pack", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orgData),
      });
      const data = await response.json();

      addResult("POST /pricing/domain-pack", response.ok, data);
      return data;
    } catch (error) {
      addResult("POST /pricing/domain-pack", false, null, error.message);
      throw error;
    }
  };

  // TEST 3: Create/Update Org Profile
  const testOrgProfile = async (profileData) => {
    try {
      const response = await fetch("/api/pricing/org-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profileData),
      });
      const data = await response.json();

      addResult("POST /pricing/org-profile", response.ok, data);
      return data;
    } catch (error) {
      addResult("POST /pricing/org-profile", false, null, error.message);
      throw error;
    }
  };

  // TEST 4: Evaluate Pricing
  const testEvaluate = async (evalData) => {
    try {
      const response = await fetch("/api/pricing/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(evalData),
      });
      const data = await response.json();

      addResult("POST /pricing/evaluate", response.ok, data);
      return data;
    } catch (error) {
      addResult("POST /pricing/evaluate", false, null, error.message);
      throw error;
    }
  };

  // TEST 5: Get Addons
  const testGetAddons = async () => {
    try {
      const response = await fetch("/api/pricing/addons");
      const data = await response.json();

      addResult("GET /pricing/addons", response.ok, data);
      return data;
    } catch (error) {
      addResult("GET /pricing/addons", false, null, error.message);
      throw error;
    }
  };

  // TEST 6: Generate Quote
  const testGenerateQuote = async (quoteData) => {
    try {
      const response = await fetch("/api/pricing/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(quoteData),
      });
      const data = await response.json();

      addResult("POST /pricing/quote", response.ok, data);
      return data;
    } catch (error) {
      addResult("POST /pricing/quote", false, null, error.message);
      throw error;
    }
  };

  // FULL WORKFLOW TEST: Major Label Music
  const runMajorLabelWorkflow = async () => {
    setLoading(true);
    setTestResults([]);
    setSelectedWorkflow("major_label");

    try {
      // Step 1: Get Tiers
      console.log("Step 1: Getting pricing tiers...");
      await testGetTiers();

      // Step 2: Create Org Profile
      console.log("Step 2: Creating org profile...");
      const orgProfile = {
        orgId: "SONY_MUSIC_001",
        name: "Sony Music Entertainment",
        industry: "music",
        subType: "major_label",
        contactEmail: "licensing@sonymusic.com",
        contactPhone: "+1-555-0100",
      };
      await testOrgProfile(orgProfile);

      // Step 3: Calculate Domain Pack
      console.log("Step 3: Calculating Domain Pack Index...");
      const domainPackResult = await testDomainPack({
        orgId: "SONY_MUSIC_001",
        industry: "music",
        subType: "major_label",
        targetAudience: ["18-34", "millennial", "gen_z", "music_fans"],
        brandValues: ["performance", "innovation", "authenticity"],
        geographicReach: "global",
      });

      // Step 4: Evaluate Pricing
      console.log("Step 4: Evaluating pricing...");
      const pricingResult = await testEvaluate({
        orgId: "SONY_MUSIC_001",
        industry: "music",
        subType: "major_label",
        valuation: 2000000000,
        annualRevenue: 450000000,
        nilThroughput: 120000000,
        performanceComplexity: 0.92,
        domainPackIndex: domainPackResult.domainPackIndex,
      });

      // Step 5: Get Addons
      console.log("Step 5: Getting available addons...");
      await testGetAddons();

      // Step 6: Generate Quote
      console.log("Step 6: Generating quote...");
      await testGenerateQuote({
        orgId: "SONY_MUSIC_001",
        baseLicense: pricingResult.recommendedLicense,
        includeAddons: true,
        addons: ["live_concert_analytics", "hedging_engine"],
        customDiscount: 5,
        contractTerm: 12,
        paymentPlan: "quarterly",
      });

      console.log("✅ Major Label workflow complete!");
    } catch (error) {
      console.error("❌ Workflow failed:", error);
    } finally {
      setLoading(false);
    }
  };

  // FULL WORKFLOW TEST: Independent Studio Film
  const runIndieStudioWorkflow = async () => {
    setLoading(true);
    setTestResults([]);
    setSelectedWorkflow("indie_studio");

    try {
      await testGetTiers();

      const orgProfile = {
        orgId: "A24_FILMS_001",
        name: "A24 Films",
        industry: "film",
        subType: "independent_studio",
        contactEmail: "business@a24films.com",
        contactPhone: "+1-555-0200",
      };
      await testOrgProfile(orgProfile);

      const domainPackResult = await testDomainPack({
        orgId: "A24_FILMS_001",
        industry: "film",
        subType: "independent_studio",
        targetAudience: ["18-49", "millennial", "film_enthusiasts"],
        brandValues: ["authenticity", "innovation", "diversity"],
        geographicReach: "international",
      });

      const pricingResult = await testEvaluate({
        orgId: "A24_FILMS_001",
        industry: "film",
        subType: "independent_studio",
        valuation: 500000000,
        annualRevenue: 85000000,
        nilThroughput: 25000000,
        performanceComplexity: 0.78,
        domainPackIndex: domainPackResult.domainPackIndex,
      });

      await testGetAddons();

      await testGenerateQuote({
        orgId: "A24_FILMS_001",
        baseLicense: pricingResult.recommendedLicense,
        includeAddons: true,
        addons: ["digital_double", "compliance_suite"],
        customDiscount: 0,
        contractTerm: 24,
        paymentPlan: "annual",
      });

      console.log("✅ Independent Studio workflow complete!");
    } catch (error) {
      console.error("❌ Workflow failed:", error);
    } finally {
      setLoading(false);
    }
  };

  // FULL WORKFLOW TEST: Modeling Agency
  const runModelingAgencyWorkflow = async () => {
    setLoading(true);
    setTestResults([]);
    setSelectedWorkflow("modeling_agency");

    try {
      await testGetTiers();

      const orgProfile = {
        orgId: "IMG_MODELS_001",
        name: "IMG Models",
        industry: "modeling",
        subType: "major_agency",
        contactEmail: "contact@imgmodels.com",
        contactPhone: "+1-555-0300",
      };
      await testOrgProfile(orgProfile);

      const domainPackResult = await testDomainPack({
        orgId: "IMG_MODELS_001",
        industry: "modeling",
        subType: "major_agency",
        targetAudience: ["18-34", "fashion_enthusiasts"],
        brandValues: ["performance", "authenticity", "diversity"],
        geographicReach: "global",
      });

      const pricingResult = await testEvaluate({
        orgId: "IMG_MODELS_001",
        industry: "modeling",
        subType: "major_agency",
        valuation: 750000000,
        annualRevenue: 125000000,
        nilThroughput: 45000000,
        performanceComplexity: 0.68,
        domainPackIndex: domainPackResult.domainPackIndex,
      });

      await testGetAddons();

      await testGenerateQuote({
        orgId: "IMG_MODELS_001",
        baseLicense: pricingResult.recommendedLicense,
        includeAddons: true,
        addons: ["sandbox_enterprise"],
        customDiscount: 10,
        contractTerm: 12,
        paymentPlan: "annual",
      });

      console.log("✅ Modeling Agency workflow complete!");
    } catch (error) {
      console.error("❌ Workflow failed:", error);
    } finally {
      setLoading(false);
    }
  };

  const clearResults = () => {
    setTestResults([]);
    setSelectedWorkflow(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-5xl font-bold text-white mb-4">
            🧪 BIM-APES Pricing API Integration Tests
          </h1>
          <p className="text-xl text-purple-200">
            End-to-end workflow testing for enterprise pricing engine
          </p>
        </div>

        {/* Test Workflows */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <WorkflowButton
            title="Major Label (Music)"
            description="Sony Music Entertainment"
            onClick={runMajorLabelWorkflow}
            loading={loading && selectedWorkflow === "major_label"}
            disabled={loading}
            icon="🎵"
          />
          <WorkflowButton
            title="Independent Studio (Film)"
            description="A24 Films"
            onClick={runIndieStudioWorkflow}
            loading={loading && selectedWorkflow === "indie_studio"}
            disabled={loading}
            icon="🎬"
          />
          <WorkflowButton
            title="Modeling Agency"
            description="IMG Models"
            onClick={runModelingAgencyWorkflow}
            loading={loading && selectedWorkflow === "modeling_agency"}
            disabled={loading}
            icon="👗"
          />
        </div>

        {/* Individual API Tests */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 mb-8 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-4">
            Individual API Tests
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <button
              onClick={testGetTiers}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white px-4 py-3 rounded-lg font-semibold transition"
            >
              GET /tiers
            </button>
            <button
              onClick={testGetAddons}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white px-4 py-3 rounded-lg font-semibold transition"
            >
              GET /addons
            </button>
            <button
              onClick={clearResults}
              disabled={loading}
              className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white px-4 py-3 rounded-lg font-semibold transition"
            >
              Clear Results
            </button>
          </div>
        </div>

        {/* Test Results */}
        {testResults.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-white">Test Results</h2>
              <div className="text-sm text-white/80">
                {testResults.filter((r) => r.success).length} /{" "}
                {testResults.length} passed
              </div>
            </div>
            <div className="space-y-4">
              {testResults.map((result, idx) => (
                <TestResult key={idx} result={result} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function WorkflowButton({
  title,
  description,
  onClick,
  loading,
  disabled,
  icon,
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="bg-gradient-to-br from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 text-white p-6 rounded-xl transition shadow-lg"
    >
      <div className="text-5xl mb-3">{icon}</div>
      <div className="text-xl font-bold mb-2">{title}</div>
      <div className="text-sm text-white/80 mb-4">{description}</div>
      {loading ? (
        <div className="text-sm">Running tests...</div>
      ) : (
        <div className="text-sm font-semibold">Run Full Workflow</div>
      )}
    </button>
  );
}

function TestResult({ result }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className={`rounded-lg p-4 border-2 ${result.success ? "bg-green-900/30 border-green-500" : "bg-red-900/30 border-red-500"}`}
    >
      <div
        className="flex justify-between items-start cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">{result.success ? "✅" : "❌"}</span>
            <span className="text-white font-semibold">{result.name}</span>
          </div>
          <div className="text-xs text-white/60">
            {new Date(result.timestamp).toLocaleTimeString()}
          </div>
        </div>
        <button className="text-white/80 hover:text-white">
          {expanded ? "▼" : "▶"}
        </button>
      </div>

      {expanded && (
        <div className="mt-4 bg-black/30 rounded p-4">
          {result.error ? (
            <div className="text-red-300">
              <div className="font-semibold mb-2">Error:</div>
              <pre className="text-xs overflow-auto">{result.error}</pre>
            </div>
          ) : (
            <div className="text-green-200">
              <div className="font-semibold mb-2">Response Data:</div>
              <pre className="text-xs overflow-auto max-h-96">
                {JSON.stringify(result.data, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
