"use client";

import { useState } from "react";
import { Eye, Layers, Play, Users, Activity } from "lucide-react";
import useUser from "@/utils/useUser";
import BiomechFlowCapsule, {
  CAPSULE_MODES,
} from "@/components/BiomechFlowCapsule/BiomechFlowCapsule";
import ThreeDSkeletonRenderer from "@/components/BiomechFlowCapsule/ThreeDSkeletonRenderer";

export default function ARVisualizationPage() {
  const { data: user, loading } = useUser();
  const [viewMode, setViewMode] = useState("capsule");
  const [selectedMode, setSelectedMode] = useState("neutral");
  const [showOverlay, setShowOverlay] = useState(true);
  const [autoRotate, setAutoRotate] = useState(false);

  // Sample athlete data
  const athlete1Data = {
    name: "Athlete 1",
    sport: "Basketball",
    position: "Guard",
    capsuleData: {
      shoulderRight: {
        stressLoad: 75,
        fatigue: 60,
        nilMomentum: 85,
        recoveryVelocity: 15,
        subProbability: 25,
        injuryRisk: 65,
      },
      kneeLeft: {
        stressLoad: 85,
        fatigue: 80,
        nilMomentum: 70,
        recoveryVelocity: -10,
        subProbability: 45,
        injuryRisk: 80,
      },
      ankleRight: {
        stressLoad: 70,
        fatigue: 65,
        nilMomentum: 75,
        recoveryVelocity: 5,
        subProbability: 30,
        injuryRisk: 60,
      },
    },
  };

  const athlete2Data = {
    name: "Athlete 2",
    sport: "Basketball",
    position: "Forward",
    capsuleData: {
      shoulderRight: {
        stressLoad: 45,
        fatigue: 35,
        nilMomentum: 90,
        recoveryVelocity: 25,
        subProbability: 15,
        injuryRisk: 30,
      },
      kneeLeft: {
        stressLoad: 55,
        fatigue: 50,
        nilMomentum: 85,
        recoveryVelocity: 10,
        subProbability: 20,
        injuryRisk: 45,
      },
      ankleRight: {
        stressLoad: 40,
        fatigue: 30,
        nilMomentum: 88,
        recoveryVelocity: 20,
        subProbability: 12,
        injuryRisk: 25,
      },
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center">
        <div className="text-white text-xl">
          Please{" "}
          <a href="/account/signin" className="text-blue-400 underline">
            sign in
          </a>{" "}
          to access AR Visualization
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 p-6">
      {/* ... rest of component with all view modes */}
    </div>
  );
}

// ... all helper components
