"use client";

import { useState, useEffect } from "react";
import {
  Brain,
  Target,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  Users,
  Play,
  RefreshCw,
  ChevronDown,
  ChevronRight,
  Activity,
  Zap,
  Shield,
  Trophy,
} from "lucide-react";

export default function CoachScenarioAnalyzer() {
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [selectedSport, setSelectedSport] = useState("");
  const [scenarioVariables, setScenarioVariables] = useState({
    fatigue_level: 80,
    weather_condition: 0.9,
    opponent_strength: 75,
    position_change: false,
  });
  const [scenarioResults, setScenarioResults] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [athletes, setAthletes] = useState([]);
  const [expandedSection, setExpandedSection] = useState("overview");

  const sportTypes = [
    { value: "wrestling", label: "Wrestling/Goal Wrestling", icon: "🤼" },
    { value: "rugby", label: "Rugby", icon: "🏉" },
    { value: "soccer", label: "Soccer", icon: "⚽" },
    { value: "basketball", label: "Basketball", icon: "🏀" },
    { value: "tennis", label: "Tennis", icon: "🎾" },
    { value: "pickleball", label: "Pickleball", icon: "🏓" },
    { value: "american_football", label: "American Football", icon: "🏈" },
  ];

  useEffect(() => {
    loadAthletes();
  }, []);

  const loadAthletes = async () => {
    try {
      const response = await fetch("/api/athletes/list");
      if (response.ok) {
        const data = await response.json();
        setAthletes(data.athletes || []);
      }
    } catch (error) {
      console.error("Failed to load athletes:", error);
    }
  };

  const runScenarioAnalysis = async () => {
    if (!selectedAthlete || !selectedSport) return;

    setIsAnalyzing(true);
    try {
      const response = await fetch("/api/qaas/generate", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete.id,
          sport_type: selectedSport,
          scenario_variables: scenarioVariables,
          scenario_count: 1000,
          baseline_performance: selectedAthlete.baseline_performance || 75,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setScenarioResults(data);
        setExpandedSection("overview");
      }
    } catch (error) {
      console.error("Scenario analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const renderScenarioControls = () => (
    <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm mb-6">
      <h3 className="text-xl font-semibold text-[#1D2B3D] mb-6 flex items-center space-x-2">
        <Target className="w-5 h-5" />
        <span>Scenario Parameters</span>
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Athlete Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Athlete
          </label>
          <select
            value={selectedAthlete?.id || ""}
            onChange={(e) => {
              const athlete = athletes.find(
                (a) => a.id === parseInt(e.target.value),
              );
              setSelectedAthlete(athlete);
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
          >
            <option value="">Choose Athlete...</option>
            {athletes.map((athlete) => (
              <option key={athlete.id} value={athlete.id}>
                {athlete.name} (Tier {athlete.tier_level})
              </option>
            ))}
          </select>
        </div>

        {/* Sport Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Sport Type
          </label>
          <select
            value={selectedSport}
            onChange={(e) => setSelectedSport(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#B8860B] focus:border-transparent"
          >
            <option value="">Select Sport...</option>
            {sportTypes.map((sport) => (
              <option key={sport.value} value={sport.value}>
                {sport.icon} {sport.label}
              </option>
            ))}
          </select>
        </div>

        {/* Fatigue Level */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fatigue Level: {scenarioVariables.fatigue_level}%
          </label>
          <input
            type="range"
            min="50"
            max="100"
            value={scenarioVariables.fatigue_level}
            onChange={(e) =>
              setScenarioVariables((prev) => ({
                ...prev,
                fatigue_level: parseInt(e.target.value),
              }))
            }
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            style={{
              background: `linear-gradient(to right, #ef4444 0%, #eab308 50%, #22c55e 100%)`,
            }}
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Exhausted</span>
            <span>Fresh</span>
          </div>
        </div>

        {/* Weather Conditions (for outdoor sports) */}
        {[
          "rugby",
          "soccer",
          "american_football",
          "tennis",
          "pickleball",
        ].includes(selectedSport) && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Weather Conditions:{" "}
              {Math.round(scenarioVariables.weather_condition * 100)}%
            </label>
            <input
              type="range"
              min="0.6"
              max="1.1"
              step="0.1"
              value={scenarioVariables.weather_condition}
              onChange={(e) =>
                setScenarioVariables((prev) => ({
                  ...prev,
                  weather_condition: parseFloat(e.target.value),
                }))
              }
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Poor</span>
              <span>Ideal</span>
            </div>
          </div>
        )}

        {/* Opponent Strength */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Opponent Strength: {scenarioVariables.opponent_strength}
          </label>
          <input
            type="range"
            min="50"
            max="100"
            value={scenarioVariables.opponent_strength}
            onChange={(e) =>
              setScenarioVariables((prev) => ({
                ...prev,
                opponent_strength: parseInt(e.target.value),
              }))
            }
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Weak</span>
            <span>Elite</span>
          </div>
        </div>

        {/* Position Change */}
        <div className="flex items-center space-x-3">
          <input
            type="checkbox"
            id="position_change"
            checked={scenarioVariables.position_change}
            onChange={(e) =>
              setScenarioVariables((prev) => ({
                ...prev,
                position_change: e.target.checked,
              }))
            }
            className="w-4 h-4 text-[#B8860B] rounded focus:ring-[#B8860B]"
          />
          <label
            htmlFor="position_change"
            className="text-sm font-medium text-gray-700"
          >
            Position/Role Change
          </label>
        </div>
      </div>

      <div className="mt-6">
        <button
          onClick={runScenarioAnalysis}
          disabled={!selectedAthlete || !selectedSport || isAnalyzing}
          className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-8 py-3 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 transition-colors"
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Analyzing 1000 Scenarios...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>Run Monte Carlo Analysis</span>
            </>
          )}
        </button>
      </div>
    </div>
  );

  const renderResultsSection = (title, icon, content, sectionKey) => (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm mb-4">
      <button
        onClick={() =>
          setExpandedSection(expandedSection === sectionKey ? "" : sectionKey)
        }
        className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center space-x-3">
          {icon}
          <span className="text-lg font-semibold text-[#1D2B3D]">{title}</span>
        </div>
        {expandedSection === sectionKey ? (
          <ChevronDown className="w-5 h-5 text-gray-400" />
        ) : (
          <ChevronRight className="w-5 h-5 text-gray-400" />
        )}
      </button>

      {expandedSection === sectionKey && (
        <div className="px-6 pb-6 border-t border-gray-100">{content}</div>
      )}
    </div>
  );

  const renderOverview = () => {
    const stats = scenarioResults?.scenario_analysis?.statistics;
    if (!stats) return null;

    return (
      <div className="pt-4 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#B8860B]/10 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Activity className="w-5 h-5 text-[#B8860B]" />
              <span className="font-medium text-[#1D2B3D]">
                Avg Performance
              </span>
            </div>
            <div className="text-2xl font-bold text-[#1D2B3D]">
              {stats.performance_stats.mean.toFixed(1)}%
            </div>
            <div className="text-sm text-gray-600">
              Range: {stats.performance_stats.min.toFixed(0)}-
              {stats.performance_stats.max.toFixed(0)}%
            </div>
          </div>

          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Trophy className="w-5 h-5 text-green-600" />
              <span className="font-medium text-[#1D2B3D]">
                Win Probability
              </span>
            </div>
            <div className="text-2xl font-bold text-[#1D2B3D]">
              {(stats.win_probability.mean * 100).toFixed(1)}%
            </div>
            <div className="text-sm text-gray-600">
              High confidence:{" "}
              {(stats.win_probability.high_confidence * 100).toFixed(0)}%
            </div>
          </div>

          <div className="bg-red-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <span className="font-medium text-[#1D2B3D]">
                Risk Assessment
              </span>
            </div>
            <div className="text-2xl font-bold text-[#1D2B3D]">
              {stats.risk_stats.average_risk.toFixed(1)}/10
            </div>
            <div className="text-sm text-gray-600">
              High-risk scenarios: {stats.risk_stats.high_risk_scenarios}
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-semibold text-[#1D2B3D] mb-3">
            Performance Distribution
          </h4>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-lg font-bold text-green-600">
                {scenarioResults.scenario_analysis.outcomes.excellent.percentage.toFixed(
                  1,
                )}
                %
              </div>
              <div className="text-sm text-gray-600">Excellent (85%+)</div>
            </div>
            <div>
              <div className="text-lg font-bold text-blue-600">
                {scenarioResults.scenario_analysis.outcomes.good.percentage.toFixed(
                  1,
                )}
                %
              </div>
              <div className="text-sm text-gray-600">Good (70-84%)</div>
            </div>
            <div>
              <div className="text-lg font-bold text-yellow-600">
                {scenarioResults.scenario_analysis.outcomes.average.percentage.toFixed(
                  1,
                )}
                %
              </div>
              <div className="text-sm text-gray-600">Average (55-69%)</div>
            </div>
            <div>
              <div className="text-lg font-bold text-red-600">
                {scenarioResults.scenario_analysis.outcomes.poor.percentage.toFixed(
                  1,
                )}
                %
              </div>
              <div className="text-sm text-gray-600">Poor (&lt;55%)</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderWhatIfQuestions = () => (
    <div className="pt-4 space-y-4">
      {scenarioResults?.what_if_questions?.map((question, index) => (
        <div
          key={index}
          className="bg-gray-50 rounded-lg p-4 border-l-4 border-[#B8860B]"
        >
          <div className="flex items-start justify-between mb-2">
            <h4 className="font-semibold text-[#1D2B3D]">
              {question.category}
            </h4>
            {question.predicted_impact && (
              <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">
                {question.predicted_impact}
              </span>
            )}
          </div>
          <p className="text-gray-700 mb-2">{question.question}</p>
          {question.scenario_context && (
            <div className="text-sm text-gray-500">
              Context: {question.scenario_context.replace(/_/g, " ")}
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const renderRecommendations = () => (
    <div className="pt-4 space-y-4">
      {scenarioResults?.scenario_analysis?.recommendations?.map(
        (rec, index) => (
          <div
            key={index}
            className={`rounded-lg p-4 border-l-4 ${
              rec.priority === "high"
                ? "bg-red-50 border-red-400"
                : rec.priority === "medium"
                  ? "bg-yellow-50 border-yellow-400"
                  : "bg-blue-50 border-blue-400"
            }`}
          >
            <div className="flex items-center space-x-2 mb-2">
              <span
                className={`text-sm font-medium px-2 py-1 rounded ${
                  rec.priority === "high"
                    ? "bg-red-100 text-red-800"
                    : rec.priority === "medium"
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-blue-100 text-blue-800"
                }`}
              >
                {rec.priority.toUpperCase()}
              </span>
              <span className="font-semibold text-[#1D2B3D]">
                {rec.category}
              </span>
            </div>
            <p className="text-gray-700 mb-2">{rec.recommendation}</p>
            {rec.sport_specific && (
              <div className="text-sm text-gray-600 bg-white rounded p-2 border">
                <strong>Sport-specific action:</strong> {rec.sport_specific}
              </div>
            )}
          </div>
        ),
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1D2B3D] to-[#2C3E50] text-white">
        <div className="px-6 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center space-x-3 mb-4">
              <Brain className="w-8 h-8 text-[#B8860B]" />
              <h1 className="text-3xl font-bold">Coach Scenario Analyzer</h1>
            </div>
            <p className="text-xl text-gray-300">
              Monte Carlo "What If" Analysis for Sport-Specific Performance
              Optimization
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Scenario Controls */}
        {renderScenarioControls()}

        {/* Results */}
        {scenarioResults && (
          <div>
            <h2 className="text-2xl font-bold text-[#1D2B3D] mb-6 flex items-center space-x-2">
              <BarChart3 className="w-6 h-6" />
              <span>Analysis Results</span>
              <span className="text-sm font-normal text-gray-500">
                ({scenarioResults.metadata.scenarios_run} scenarios)
              </span>
            </h2>

            {renderResultsSection(
              "Performance Overview",
              <TrendingUp className="w-5 h-5 text-[#B8860B]" />,
              renderOverview(),
              "overview",
            )}

            {renderResultsSection(
              "What If Questions",
              <Brain className="w-5 h-5 text-blue-600" />,
              renderWhatIfQuestions(),
              "questions",
            )}

            {renderResultsSection(
              "Training Recommendations",
              <Shield className="w-5 h-5 text-green-600" />,
              renderRecommendations(),
              "recommendations",
            )}
          </div>
        )}

        {/* Help Section */}
        <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm mt-8">
          <h3 className="text-lg font-semibold text-[#1D2B3D] mb-4">
            How to Use
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-gray-600">
            <div>
              <h4 className="font-medium text-[#1D2B3D] mb-2">
                Sport-Specific Analysis
              </h4>
              <ul className="space-y-1">
                <li>• Wrestling: Takedown efficiency, endurance impact</li>
                <li>• Tactical Sports: Team coordination, weather effects</li>
                <li>
                  • Racket Sports: Spike score optimization, pressure handling
                </li>
                <li>
                  • American Football: Session consistency, position flexibility
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-[#1D2B3D] mb-2">
                Variable Controls
              </h4>
              <ul className="space-y-1">
                <li>• Fatigue Level: Athlete's energy state (50-100%)</li>
                <li>• Weather: Environmental conditions for outdoor sports</li>
                <li>• Opponent Strength: Competition level (50-100)</li>
                <li>• Position Change: Role/position adaptation scenarios</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
