"use client";

import { useState } from "react";
import {
  Users,
  Zap,
  Target,
  TrendingUp,
  Activity,
  AlertCircle,
  ChevronRight,
  BarChart2,
} from "lucide-react";
import useUser from "@/utils/useUser";
import Footer from "@/components/Footer";

const SPORTS = {
  soccer: {
    label: "⚽ Soccer",
    color: "#3CFF7A",
    accent: "#005522",
    desc: "Possession · Passing · Defensive Pressure",
  },
  rugby: {
    label: "🏉 Rugby",
    color: "#FF8C33",
    accent: "#662200",
    desc: "Breakdown · Linebreak · Defensive Line Speed",
  },
  basketball: {
    label: "🏀 Basketball",
    color: "#4DA6FF",
    accent: "#001E66",
    desc: "Off-Ball Movement · Screen Efficiency · IQ",
  },
};

const SPORT_DEFAULTS = {
  soccer: {
    possessions: 48,
    productivePossessions: 14,
    totalPasses: 55,
    successfulPasses: 47,
    tackles: 9,
    successfulTackles: 7,
    shots: 5,
    assists: 2,
    turnovers: 4,
    distanceCovered: 11200,
    sprintDistance: 1350,
  },
  rugby: {
    possessions: 32,
    productivePossessions: 11,
    totalPasses: 40,
    successfulPasses: 35,
    tackles: 18,
    successfulTackles: 15,
    shots: 3,
    assists: 1,
    turnovers: 2,
    distanceCovered: 9800,
    sprintDistance: 1100,
  },
  basketball: {
    possessions: 60,
    productivePossessions: 22,
    totalPasses: 70,
    successfulPasses: 62,
    tackles: 5,
    successfulTackles: 4,
    shots: 12,
    assists: 6,
    turnovers: 3,
    distanceCovered: 4500,
    sprintDistance: 900,
  },
};

function GaugeArc({ value, color, size = 140, label }) {
  const r = 54,
    cx = 70,
    cy = 74;
  const circ = Math.PI * r;
  const offset = circ * (1 - Math.min(100, Math.max(0, value)) / 100);
  return (
    <div style={{ textAlign: "center", width: size }}>
      <svg width={size} height={size * 0.75} viewBox="0 0 140 110">
        <path
          d={`M 16 74 A 54 54 0 0 1 124 74`}
          fill="none"
          stroke="#1a2a4a"
          strokeWidth="12"
          strokeLinecap="round"
        />
        <path
          d={`M 16 74 A 54 54 0 0 1 124 74`}
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1s ease" }}
        />
        <text
          x={cx}
          y={cy - 10}
          textAnchor="middle"
          fill={color}
          fontSize="22"
          fontWeight="900"
          fontFamily="monospace"
        >
          {value?.toFixed(0)}
        </text>
        <text
          x={cx}
          y={cy + 8}
          textAnchor="middle"
          fill="#666"
          fontSize="9"
          textTransform="uppercase"
        >
          / 100
        </text>
      </svg>
      <p
        style={{
          color: "#aaa",
          fontSize: 11,
          textTransform: "uppercase",
          letterSpacing: 1,
        }}
      >
        {label}
      </p>
    </div>
  );
}

function MetricBar({ label, value, color = "#4DA6FF", max = 100 }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="mb-3">
      <div className="flex justify-between mb-1">
        <span className="text-slate-300 text-sm">{label}</span>
        <span
          style={{
            color,
            fontFamily: "monospace",
            fontSize: 13,
            fontWeight: 700,
          }}
        >
          {value?.toFixed(1)}
          {max === 100 ? "%" : ""}
        </span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className="h-2 rounded-full transition-all duration-700"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, ${color}88, ${color})`,
          }}
        />
      </div>
    </div>
  );
}

function InsightCard({ insight, sport }) {
  const sportColor = SPORTS[sport]?.color || "#4DA6FF";
  const types = {
    strength: { border: "rgba(60,255,122,0.3)", dot: "#3CFF7A" },
    weakness: { border: "rgba(255,60,60,0.3)", dot: "#FF3C3C" },
    warning: { border: "rgba(255,204,51,0.3)", dot: "#FFCC33" },
  };
  const t = types[insight.type] || types.warning;
  return (
    <div
      style={{
        border: `1px solid ${t.border}`,
        borderRadius: 12,
        padding: "12px 16px",
        background: "rgba(255,255,255,0.03)",
      }}
    >
      <div className="flex items-center gap-2 mb-1">
        <div
          style={{
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: t.dot,
            flexShrink: 0,
          }}
        />
        <span
          style={{
            color: sportColor,
            fontSize: 12,
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: 1,
          }}
        >
          {insight.area}
        </span>
      </div>
      <p className="text-white text-sm mb-1">{insight.message}</p>
      {insight.recommendation && (
        <p className="text-slate-400 text-xs flex items-start gap-1">
          <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
          {insight.recommendation}
        </p>
      )}
    </div>
  );
}

export default function TacticalSportsDashboard() {
  const { data: user, loading } = useUser();
  const [sport, setSport] = useState("soccer");
  const [athleteId, setAthleteId] = useState("1");
  const [performanceData, setPerformanceData] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);
  const [matchData, setMatchData] = useState(SPORT_DEFAULTS.soccer);

  const changeSport = (s) => {
    setSport(s);
    setMatchData(SPORT_DEFAULTS[s]);
    setPerformanceData(null);
  };
  const upd = (f, v) =>
    setMatchData((p) => ({ ...p, [f]: parseFloat(v) || 0 }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!athleteId) {
      setError("Please enter an athlete ID");
      return;
    }
    setLoadingData(true);
    setError(null);
    try {
      const res = await fetch(
        "/api/sport-specific/tactical-sports/efficiency",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athleteId: parseInt(athleteId),
            sport,
            matchData,
          }),
        },
      );
      if (!res.ok) throw new Error(`Server error: ${res.status}`);
      setPerformanceData(await res.json());
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoadingData(false);
    }
  };

  const sc = SPORTS[sport];

  if (loading)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{
          background: "linear-gradient(135deg, #0a1628, #0d2b1a, #0a1628)",
        }}
      >
        <div className="text-white text-xl animate-pulse">
          Loading Tactical Intelligence Module...
        </div>
      </div>
    );
  if (!user)
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{
          background: "linear-gradient(135deg, #0a1628, #0d2b1a, #0a1628)",
        }}
      >
        <div className="text-center">
          <Users className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <p className="text-white text-xl mb-4">
            Tactical Sports Intelligence
          </p>
          <a
            href="/account/signin"
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
          >
            Sign In
          </a>
        </div>
      </div>
    );

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "linear-gradient(135deg, #0a1628, #0d2b1a, #0a1628)",
      }}
    >
      {/* Header */}
      <div className="border-b border-white/10 bg-black/20 backdrop-blur-lg sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: sc.color + "33" }}
          >
            <Users className="w-6 h-6" style={{ color: sc.color }} />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg leading-tight">
              Tactical Sports Efficiency
            </h1>
            <p className="text-xs" style={{ color: sc.color }}>
              BIM-APES · {sc.desc}
            </p>
          </div>
        </div>
      </div>

      {/* Sport Selector */}
      <div className="max-w-7xl mx-auto w-full px-4 md:px-6 pt-6">
        <div className="flex gap-3 flex-wrap">
          {Object.entries(SPORTS).map(([key, s]) => (
            <button
              key={key}
              onClick={() => changeSport(key)}
              className="px-5 py-2.5 rounded-xl font-bold text-sm transition-all"
              style={{
                background: sport === key ? s.color : "rgba(255,255,255,0.05)",
                color: sport === key ? "#000" : "#aaa",
                border: `1px solid ${sport === key ? s.color : "transparent"}`,
              }}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-4 md:p-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Panel */}
          <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
            <h2 className="text-white font-bold text-base mb-4">
              Match Statistics
            </h2>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label
                  className="block text-xs uppercase tracking-wider mb-1"
                  style={{ color: sc.color }}
                >
                  Athlete ID
                </label>
                <input
                  type="number"
                  value={athleteId}
                  onChange={(e) => setAthleteId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  style={{ borderColor: "transparent" }}
                  onFocus={(e) => (e.target.style.borderColor = sc.color)}
                  onBlur={(e) => (e.target.style.borderColor = "transparent")}
                />
              </div>

              {[
                [
                  "possessions",
                  "productivePossessions",
                  "Possessions",
                  "Productive",
                ],
                [
                  "totalPasses",
                  "successfulPasses",
                  "Total Passes",
                  "Successful",
                ],
                ["tackles", "successfulTackles", "Tackles", "Successful"],
              ].map(([f1, f2, l1, l2]) => (
                <div key={f1} className="grid grid-cols-2 gap-2">
                  {[
                    [f1, l1],
                    [f2, l2],
                  ].map(([f, l]) => (
                    <div key={f}>
                      <label className="block text-slate-400 text-xs mb-1">
                        {l}
                      </label>
                      <input
                        type="number"
                        value={matchData[f]}
                        min="0"
                        onChange={(e) => upd(f, e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                      />
                    </div>
                  ))}
                </div>
              ))}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 text-xs mb-1">
                    Assists
                  </label>
                  <input
                    type="number"
                    value={matchData.assists}
                    min="0"
                    onChange={(e) => upd("assists", e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-xs mb-1">
                    Turnovers
                  </label>
                  <input
                    type="number"
                    value={matchData.turnovers}
                    min="0"
                    onChange={(e) => upd("turnovers", e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 text-xs mb-1">
                    Distance (m)
                  </label>
                  <input
                    type="number"
                    value={matchData.distanceCovered}
                    min="0"
                    onChange={(e) => upd("distanceCovered", e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 text-xs mb-1">
                    Sprint (m)
                  </label>
                  <input
                    type="number"
                    value={matchData.sprintDistance}
                    min="0"
                    onChange={(e) => upd("sprintDistance", e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none text-sm"
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3">
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loadingData}
                className="w-full py-3 px-6 rounded-xl font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50"
                style={{
                  background: loadingData
                    ? "#334"
                    : `linear-gradient(135deg, ${sc.color}, ${sc.accent})`,
                  color: loadingData
                    ? "#888"
                    : sport === "rugby"
                      ? "#fff"
                      : "#000",
                }}
              >
                {loadingData
                  ? "⚡ Analyzing..."
                  : "⚡ Analyze Tactical Efficiency"}
              </button>
            </form>
          </div>

          {/* Results */}
          <div className="lg:col-span-2 space-y-5">
            {!performanceData ? (
              <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-12 border border-white/10 flex flex-col items-center justify-center min-h-[400px]">
                <BarChart2
                  className="w-20 h-20 opacity-20 mb-4"
                  style={{ color: sc.color }}
                />
                <p className="text-slate-400 text-lg">
                  Tactical Intelligence Ready
                </p>
                <p className="text-slate-500 text-sm mt-1">
                  Select a sport, enter match data, and run analysis
                </p>
              </div>
            ) : (
              <>
                {/* Score Gauges */}
                <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                  <h3 className="text-white font-bold text-base mb-6">
                    Tactical Performance Index
                  </h3>
                  <div className="flex flex-wrap gap-6 justify-center">
                    <GaugeArc
                      value={performanceData.tacticalScore}
                      color={sc.color}
                      label="Tactical Score"
                    />
                    <GaugeArc
                      value={performanceData.bimScore}
                      color="#FFCC33"
                      label="BIM Score"
                    />
                    <GaugeArc
                      value={performanceData.efficiency?.coordination}
                      color="#4DA6FF"
                      label="Coordination"
                    />
                    <GaugeArc
                      value={performanceData.efficiency?.transition}
                      color="#FF8C33"
                      label="Transition"
                    />
                  </div>
                  <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
                    <span className="text-slate-400 text-sm">BIM Tier</span>
                    <span
                      className="font-bold uppercase text-sm px-3 py-1 rounded-full"
                      style={{ background: sc.color + "22", color: sc.color }}
                    >
                      {performanceData.tier || "competitive"}
                    </span>
                  </div>
                </div>

                {/* Efficiency Breakdown */}
                {performanceData.efficiency && (
                  <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                    <h3 className="text-white font-bold text-base mb-4">
                      Efficiency Metrics
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <MetricBar
                          label="Possession Efficiency"
                          value={performanceData.efficiency.possession}
                          color={sc.color}
                        />
                        <MetricBar
                          label="Passing Accuracy"
                          value={performanceData.efficiency.passing}
                          color="#4DA6FF"
                        />
                        <MetricBar
                          label="Defensive Success"
                          value={performanceData.efficiency.defensive}
                          color="#FF8C33"
                        />
                      </div>
                      <div>
                        <MetricBar
                          label="Spatial Awareness"
                          value={performanceData.efficiency.spatial}
                          color="#FFCC33"
                        />
                        <MetricBar
                          label="Decision Making"
                          value={performanceData.efficiency.decisionMaking}
                          color="#33FFF3"
                        />
                        <MetricBar
                          label="Team Coordination"
                          value={performanceData.efficiency.coordination}
                          color="#FF3C3C"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Physical Stats */}
                {performanceData.physical && (
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      [
                        "Distance",
                        `${(performanceData.physical.distanceCovered / 1000).toFixed(2)} km`,
                        "#4DA6FF",
                      ],
                      [
                        "Sprint Dist.",
                        `${performanceData.physical.sprintDistance} m`,
                        "#FFCC33",
                      ],
                      [
                        "Sprint Ratio",
                        `${((performanceData.physical.sprintDistance / Math.max(1, performanceData.physical.distanceCovered)) * 100).toFixed(1)}%`,
                        "#FF8C33",
                      ],
                    ].map(([label, value, color]) => (
                      <div
                        key={label}
                        className="bg-white/5 rounded-2xl p-4 border border-white/10 text-center"
                      >
                        <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                          {label}
                        </p>
                        <p
                          className="font-bold text-xl font-mono"
                          style={{ color }}
                        >
                          {value}
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Insights */}
                {performanceData.insights &&
                  performanceData.insights.length > 0 && (
                    <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
                      <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2">
                        <AlertCircle
                          className="w-5 h-5"
                          style={{ color: sc.color }}
                        />{" "}
                        Tactical Insights
                      </h3>
                      <div className="space-y-3">
                        {performanceData.insights.map((ins, i) => (
                          <InsightCard key={i} insight={ins} sport={sport} />
                        ))}
                      </div>
                    </div>
                  )}

                {/* NIL Value */}
                <div
                  style={{
                    background: `linear-gradient(135deg, ${sc.color}11, rgba(30,95,168,0.1))`,
                    border: `1px solid ${sc.color}30`,
                    borderRadius: 16,
                    padding: 20,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-xs uppercase tracking-wider mb-1">
                        Estimated NIL Value ({sport})
                      </p>
                      <p
                        style={{
                          color: sc.color,
                          fontSize: 26,
                          fontWeight: 900,
                          fontFamily: "monospace",
                        }}
                      >
                        ${(performanceData.bimScore * 1400).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-slate-400 text-xs mb-1">
                        Sponsor Signal
                      </p>
                      <p
                        className="font-bold text-lg"
                        style={{
                          color:
                            performanceData.bimScore >= 70
                              ? "#3CFF7A"
                              : "#FFD93C",
                        }}
                      >
                        {performanceData.bimScore >= 70
                          ? "STRONG BUY"
                          : performanceData.bimScore >= 50
                            ? "HOLD"
                            : "MONITOR"}
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
