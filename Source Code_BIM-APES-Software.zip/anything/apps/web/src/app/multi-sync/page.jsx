"use client";

import { useState, useRef, useEffect } from "react";
import {
  Smartphone,
  Video,
  Wifi,
  Users,
  Play,
  StopCircle,
  Settings,
  Plus,
  Check,
  X,
  Camera,
  Monitor,
  Tablet,
  Clock,
  Zap,
  Target,
  Brain,
  Activity,
  RotateCcw,
  Download,
  Share2,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function MultiSyncPage() {
  const { data: user, loading: userLoading } = useUser();

  // Connection and device management
  const [isHosting, setIsHosting] = useState(false);
  const [connectedDevices, setConnectedDevices] = useState([]);
  const [roomCode, setRoomCode] = useState("");
  const [joinCode, setJoinCode] = useState("");

  // Recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [countdown, setCountdown] = useState(0);
  const [recordings, setRecordings] = useState([]);

  // Settings
  const [syncSettings, setSyncSettings] = useState({
    recordingQuality: "high",
    syncDelay: 0,
    autoStart: true,
    recordDuration: 30,
  });

  const [deviceType, setDeviceType] = useState("controller"); // controller, camera, viewer

  // Mock device data for demonstration
  useEffect(() => {
    if (isHosting) {
      const mockDevices = [
        {
          id: "device_1",
          name: "iPhone 14 Pro",
          type: "mobile",
          status: "connected",
          angle: "front",
          battery: 85,
          quality: "4K",
        },
        {
          id: "device_2",
          name: "Samsung Galaxy S23",
          type: "mobile",
          status: "connected",
          angle: "side",
          battery: 92,
          quality: "1080p",
        },
        {
          id: "device_3",
          name: "iPad Air",
          type: "tablet",
          status: "connected",
          angle: "overhead",
          battery: 78,
          quality: "4K",
        },
      ];
      setConnectedDevices(mockDevices);
      setRoomCode("SYNC-4829");
    }
  }, [isHosting]);

  // Recording timer
  useEffect(() => {
    let interval;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const startHosting = () => {
    setIsHosting(true);
    setDeviceType("controller");
    setRoomCode(`SYNC-${Math.floor(Math.random() * 9000) + 1000}`);
  };

  const joinSession = () => {
    if (joinCode.length === 9) {
      setDeviceType("camera");
      // Simulate joining
      alert(`Joined session: ${joinCode}`);
    }
  };

  const startSyncedRecording = () => {
    if (connectedDevices.length === 0) {
      alert("No devices connected. Add camera devices to start recording.");
      return;
    }

    setCountdown(3);
    const countInterval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countInterval);
          setIsRecording(true);
          setRecordingDuration(0);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const stopSyncedRecording = () => {
    setIsRecording(false);

    // Simulate recording completion
    const newRecording = {
      id: `recording_${Date.now()}`,
      duration: recordingDuration,
      devices: connectedDevices.length,
      timestamp: new Date(),
      quality: syncSettings.recordingQuality,
    };

    setRecordings((prev) => [newRecording, ...prev]);
    setRecordingDuration(0);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getDeviceIcon = (type) => {
    switch (type) {
      case "mobile":
        return Smartphone;
      case "tablet":
        return Tablet;
      case "camera":
        return Video;
      default:
        return Monitor;
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#B8860B] border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Authentication Required</h1>
          <p className="text-gray-600 mb-6">
            Please sign in to access multi-device sync
          </p>
          <a
            href="/account/signin"
            className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors text-white"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      <div className="px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-[#B8860B]/20 px-4 py-2 rounded-full border border-[#B8860B]/30 mb-6">
              <Wifi className="w-5 h-5 text-[#B8860B]" />
              <span className="text-[#1D2B3D] font-medium">
                Multi-Device Sync
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-[#1D2B3D] via-[#B8860B] to-[#1D2B3D] bg-clip-text text-transparent">
              Synchronized Motion Capture
            </h1>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              Connect multiple camera devices for comprehensive multi-angle
              performance analysis
            </p>
          </div>

          {/* Device Type Selection */}
          {!isHosting && deviceType === "controller" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              {/* Host Session */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
                <div className="text-center">
                  <div className="w-16 h-16 bg-[#B8860B]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Users className="w-8 h-8 text-[#B8860B]" />
                  </div>
                  <h2 className="text-2xl font-bold text-[#1D2B3D] mb-4">
                    Host Recording Session
                  </h2>
                  <p className="text-gray-600 mb-6">
                    Create a new session and invite camera devices to join for
                    synchronized recording
                  </p>
                  <button
                    onClick={startHosting}
                    className="bg-[#1D2B3D] hover:bg-[#B8860B] px-8 py-3 rounded-lg font-semibold transition-colors text-white"
                  >
                    Start Hosting
                  </button>
                </div>
              </div>

              {/* Join Session */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
                <div className="text-center">
                  <div className="w-16 h-16 bg-[#1D2B3D]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Camera className="w-8 h-8 text-[#1D2B3D]" />
                  </div>
                  <h2 className="text-2xl font-bold text-[#1D2B3D] mb-4">
                    Join as Camera Device
                  </h2>
                  <p className="text-gray-600 mb-6">
                    Enter a session code to join an existing recording session
                  </p>
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={joinCode}
                      onChange={(e) =>
                        setJoinCode(e.target.value.toUpperCase())
                      }
                      placeholder="SYNC-XXXX"
                      className="w-full bg-white border border-[#1D2B3D]/30 rounded-lg px-4 py-3 text-[#1D2B3D] placeholder-gray-500 focus:border-[#B8860B] focus:outline-none text-center font-mono text-lg"
                      maxLength={9}
                    />
                    <button
                      onClick={joinSession}
                      disabled={joinCode.length !== 9}
                      className="bg-[#B8860B] hover:bg-[#1D2B3D] disabled:bg-gray-400 disabled:cursor-not-allowed px-8 py-3 rounded-lg font-semibold transition-colors text-white"
                    >
                      Join Session
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Host Controller Interface */}
          {isHosting && (
            <div className="space-y-8">
              {/* Back Button and Session Info */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="flex items-center space-x-4 mb-2">
                      <h2 className="text-2xl font-bold text-[#1D2B3D]">
                        Recording Session
                      </h2>
                      <button
                        onClick={() => {
                          setIsHosting(false);
                          setConnectedDevices([]);
                          setRoomCode("");
                          setDeviceType("controller");
                          setIsRecording(false);
                          setRecordingDuration(0);
                          setCountdown(0);
                        }}
                        className="bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-lg text-sm text-gray-600 transition-colors"
                      >
                        ← Back to Setup
                      </button>
                    </div>
                    <p className="text-gray-600">
                      Share this code with camera devices to join
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-[#B8860B] font-mono bg-[#B8860B]/20 px-6 py-3 rounded-lg border border-[#B8860B]/30">
                      {roomCode}
                    </div>
                    <p className="text-sm text-gray-600 mt-2">Session Code</p>
                  </div>
                </div>

                {/* Recording Controls */}
                <div className="flex items-center justify-center space-x-6">
                  {!isRecording && countdown === 0 && (
                    <button
                      onClick={startSyncedRecording}
                      className="bg-[#B8860B] hover:bg-[#1D2B3D] px-8 py-4 rounded-lg font-semibold transition-colors flex items-center space-x-3 text-white"
                    >
                      <Play className="w-6 h-6" />
                      <span>Start Synchronized Recording</span>
                    </button>
                  )}

                  {isRecording && (
                    <button
                      onClick={stopSyncedRecording}
                      className="bg-red-600 hover:bg-red-700 px-8 py-4 rounded-lg font-semibold transition-colors flex items-center space-x-3 text-white"
                    >
                      <StopCircle className="w-6 h-6" />
                      <span>Stop Recording</span>
                    </button>
                  )}

                  {(isRecording || countdown > 0) && (
                    <div className="text-center">
                      <div className="text-2xl font-bold text-[#1D2B3D] font-mono">
                        {countdown > 0
                          ? countdown
                          : formatTime(recordingDuration)}
                      </div>
                      <p className="text-sm text-gray-600">
                        {countdown > 0 ? "Starting in..." : "Recording"}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Connected Devices */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-[#1D2B3D]">
                    Connected Devices ({connectedDevices.length})
                  </h3>
                  <button className="bg-[#1D2B3D]/10 hover:bg-[#1D2B3D]/20 p-2 rounded-lg transition-colors">
                    <Settings className="w-5 h-5 text-[#1D2B3D]" />
                  </button>
                </div>

                {connectedDevices.length === 0 ? (
                  <div className="text-center py-12 text-gray-600">
                    <Smartphone className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg mb-2">No devices connected</p>
                    <p className="text-sm">
                      Share the session code to add camera devices
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {connectedDevices.map((device) => {
                      const DeviceIcon = getDeviceIcon(device.type);
                      return (
                        <div
                          key={device.id}
                          className="bg-white border border-[#1D2B3D]/20 rounded-lg p-4"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-2">
                              <DeviceIcon className="w-5 h-5 text-[#B8860B]" />
                              <span className="font-medium text-[#1D2B3D]">
                                {device.name}
                              </span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              <span className="text-xs text-green-600">
                                Connected
                              </span>
                            </div>
                          </div>

                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Angle:</span>
                              <span className="text-[#1D2B3D] capitalize">
                                {device.angle}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Quality:</span>
                              <span className="text-[#B8860B]">
                                {device.quality}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Battery:</span>
                              <span
                                className={`${device.battery > 50 ? "text-green-600" : device.battery > 20 ? "text-yellow-600" : "text-red-600"}`}
                              >
                                {device.battery}%
                              </span>
                            </div>
                          </div>

                          {isRecording && (
                            <div className="mt-3 flex items-center space-x-2 text-red-600">
                              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                              <span className="text-xs font-medium">
                                Recording
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Sync Settings */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
                <h3 className="text-xl font-bold text-[#1D2B3D] mb-6">
                  Sync Settings
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-2">
                      Recording Quality
                    </label>
                    <select
                      value={syncSettings.recordingQuality}
                      onChange={(e) =>
                        setSyncSettings((prev) => ({
                          ...prev,
                          recordingQuality: e.target.value,
                        }))
                      }
                      className="w-full bg-white border border-[#1D2B3D]/30 rounded-lg px-3 py-2 text-[#1D2B3D] focus:border-[#B8860B] focus:outline-none"
                    >
                      <option value="4k">4K Ultra HD</option>
                      <option value="high">1080p HD</option>
                      <option value="medium">720p</option>
                      <option value="low">480p</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-2">
                      Sync Delay (ms)
                    </label>
                    <input
                      type="number"
                      value={syncSettings.syncDelay}
                      onChange={(e) =>
                        setSyncSettings((prev) => ({
                          ...prev,
                          syncDelay: parseInt(e.target.value) || 0,
                        }))
                      }
                      className="w-full bg-white border border-[#1D2B3D]/30 rounded-lg px-3 py-2 text-[#1D2B3D] focus:border-[#B8860B] focus:outline-none"
                      min="0"
                      max="1000"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-2">
                      Max Duration (sec)
                    </label>
                    <input
                      type="number"
                      value={syncSettings.recordDuration}
                      onChange={(e) =>
                        setSyncSettings((prev) => ({
                          ...prev,
                          recordDuration: parseInt(e.target.value) || 30,
                        }))
                      }
                      className="w-full bg-white border border-[#1D2B3D]/30 rounded-lg px-3 py-2 text-[#1D2B3D] focus:border-[#B8860B] focus:outline-none"
                      min="5"
                      max="300"
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="autoStart"
                      checked={syncSettings.autoStart}
                      onChange={(e) =>
                        setSyncSettings((prev) => ({
                          ...prev,
                          autoStart: e.target.checked,
                        }))
                      }
                      className="w-4 h-4 text-[#B8860B] bg-white border-[#1D2B3D]/30 rounded focus:ring-[#B8860B] focus:ring-2"
                    />
                    <label
                      htmlFor="autoStart"
                      className="text-sm text-gray-600"
                    >
                      Auto-start devices
                    </label>
                  </div>
                </div>
              </div>

              {/* Recording History */}
              {recordings.length > 0 && (
                <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
                  <h3 className="text-xl font-bold text-[#1D2B3D] mb-6">
                    Recent Recordings
                  </h3>

                  <div className="space-y-4">
                    {recordings.slice(0, 5).map((recording) => (
                      <div
                        key={recording.id}
                        className="flex items-center justify-between p-4 bg-white border border-[#1D2B3D]/20 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <Video className="w-5 h-5 text-[#B8860B]" />
                          <div>
                            <p className="font-medium text-[#1D2B3D]">
                              Multi-Angle Recording
                            </p>
                            <p className="text-sm text-gray-600">
                              {formatTime(recording.duration)} •{" "}
                              {recording.devices} devices • {recording.quality}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <button className="bg-[#1D2B3D]/10 hover:bg-[#1D2B3D]/20 p-2 rounded-lg transition-colors">
                            <Download className="w-4 h-4 text-[#1D2B3D]" />
                          </button>
                          <button className="bg-[#B8860B]/10 hover:bg-[#B8860B]/20 p-2 rounded-lg transition-colors">
                            <Share2 className="w-4 h-4 text-[#B8860B]" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Camera Device Interface */}
          {deviceType === "camera" && (
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg text-center">
              <div className="w-16 h-16 bg-[#B8860B]/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Camera className="w-8 h-8 text-[#B8860B]" />
              </div>
              <h2 className="text-2xl font-bold text-[#1D2B3D] mb-4">
                Camera Mode
              </h2>
              <p className="text-gray-600 mb-6">
                Connected to session. Waiting for recording to start...
              </p>

              <div className="bg-[#1D2B3D]/5 rounded-lg p-6">
                <div className="text-lg font-medium text-[#1D2B3D] mb-2">
                  Ready to Record
                </div>
                <div className="text-sm text-gray-600">
                  Position your device and wait for the host to start recording
                </div>
              </div>
            </div>
          )}

          {/* Feature Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-[#B8860B]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-[#B8860B]" />
              </div>
              <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                Multi-Angle Analysis
              </h3>
              <p className="text-gray-600">
                Capture performance from multiple viewpoints for comprehensive
                biomechanical analysis
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#1D2B3D]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-[#1D2B3D]" />
              </div>
              <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                Perfect Synchronization
              </h3>
              <p className="text-gray-600">
                All devices record simultaneously with precision timing for
                accurate motion tracking
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#B8860B]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-[#B8860B]" />
              </div>
              <h3 className="text-lg font-semibold text-[#1D2B3D] mb-2">
                Enhanced BIM Analysis
              </h3>
              <p className="text-gray-600">
                Multi-device footage provides richer data for advanced
                performance indexing
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
