"use client";

import {
  TrendingUp,
  Activity,
  Shield,
  Zap,
  Brain,
  Target,
  BarChart3,
  Heart,
} from "lucide-react";

export default function BIMAPESHome() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#1e3a5f] border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-white text-xl font-bold tracking-wide">
              BLEDSOE
            </h1>
            <p className="text-slate-300 text-xs tracking-widest">
              INVESTMENT MANAGEMENT
            </p>
          </div>
          <nav className="flex items-center gap-8">
            <a
              href="/"
              className="text-slate-300 hover:text-white transition-colors"
            >
              Home
            </a>
            <a
              href="/analytics-dashboard"
              className="text-slate-300 hover:text-white transition-colors"
            >
              Intelligence
            </a>
            <a
              href="/coach-portal"
              className="text-slate-300 hover:text-white transition-colors"
            >
              Coach Portal
            </a>
            <a
              href="/account/signup"
              className="bg-[#2d5a8a] hover:bg-[#3d6a9a] text-white px-6 py-2 rounded-lg font-semibold transition-all"
            >
              Get Started
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#1e3a5f] via-[#2d4a6f] to-[#1e3a5f] py-20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-6xl font-bold text-white mb-4 tracking-tight">
            BIM-APES
          </h2>
          <div className="w-32 h-1 bg-gradient-to-r from-yellow-400 to-orange-400 mx-auto mb-6"></div>
          <p className="text-2xl text-slate-200 mb-3 font-light">
            Biometric Intelligence Management System
          </p>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Coalition-Grade Analytics for Performance & NIL Valuation
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-16 max-w-5xl mx-auto">
            <StatCard number="4" label="Intelligence Engines" />
            <StatCard number="10+" label="AR Overlays" />
            <StatCard number="1000" label="Biometric Indices" />
            <StatCard number="24/7" label="Real-Time Analysis" />
          </div>
        </div>
      </section>

      {/* Dashboard Selection */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-slate-800 mb-3">
            Choose Your Dashboard
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto mb-16"></div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Intelligence Dashboard */}
            <DashboardCard
              title="Intelligence Dashboard"
              badge="NEW"
              icon={<Brain className="w-8 h-8 text-white" />}
              description="Complete real-time biomechanical intelligence with stress, fatigue, recovery, and training analysis plus market signals"
              features={[
                "Stress Intelligence (joint torque, asymmetry, HRV)",
                "Fatigue Intelligence (ACWR, stride analysis, hydration)",
                "Recovery Intelligence (sleep, muscle soreness, tissue repair)",
                "Training Intelligence (ACWR, velocity loss, technique drift)",
                "Market Intelligence (bull/bear signals, NIL momentum)",
                "AR Biomechanical Overlays",
                "BiomechFlow™ Charts",
                "Trading Signals (LONG, SHORT, ARBITRAGE, BREAKOUT)",
              ]}
              buttonLabel="Launch Intelligence Dashboard"
              href="/analytics-dashboard"
              gradient="from-blue-600 to-purple-600"
            />

            {/* Coach Dashboard */}
            <DashboardCard
              title="Coach Dashboard"
              icon={<Activity className="w-8 h-8 text-white" />}
              description="Advanced analytics and biometric tracking for athletic performance optimization and team management"
              features={[
                "Athlete roster management",
                "Performance session tracking",
                "NIL valuation analysis",
                "Mispricing detection",
                "AR biomechanical visualization",
                "Risk forecasting",
                "BiomechFlow™ charts",
                "Market trend intelligence",
              ]}
              buttonLabel="Launch Coach Dashboard"
              href="/coach-portal"
              gradient="from-teal-600 to-cyan-600"
            />
          </div>
        </div>
      </section>

      {/* Platform Capabilities */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-slate-800 mb-3">
            Platform Capabilities
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto mb-16"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <CapabilityCard
              icon={<TrendingUp className="w-10 h-10 text-amber-600" />}
              title="Market Intelligence"
              description="Bull/bear signal detection with NIL momentum tracking and trading recommendations"
              bgColor="bg-amber-50"
            />
            <CapabilityCard
              icon={<Shield className="w-10 h-10 text-blue-600" />}
              title="Risk Management"
              description="ACWR monitoring, injury prediction, and performance breakdown prevention"
              bgColor="bg-blue-50"
            />
            <CapabilityCard
              icon={<Zap className="w-10 h-10 text-purple-600" />}
              title="Real-Time Alerts"
              description="Critical stress, fatigue, and recovery alerts with actionable intervention protocols"
              bgColor="bg-purple-50"
            />
            <CapabilityCard
              icon={<Target className="w-10 h-10 text-teal-600" />}
              title="Biomechanical Analysis"
              description="Joint torque modeling, asymmetry detection, and AR spatial overlays"
              bgColor="bg-teal-50"
            />
          </div>
        </div>
      </section>

      {/* Intelligence Engines */}
      <section className="py-20 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-white mb-3">
            Four Intelligence Engines Working in Harmony
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-400 to-orange-400 mx-auto mb-16"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <EngineCard
              icon={<Shield className="w-12 h-12" />}
              title="Stress Intelligence"
              color="text-red-400"
              bgColor="bg-red-500/10"
              borderColor="border-red-500/30"
            />
            <EngineCard
              icon={<Zap className="w-12 h-12" />}
              title="Fatigue Intelligence"
              color="text-yellow-400"
              bgColor="bg-yellow-500/10"
              borderColor="border-yellow-500/30"
            />
            <EngineCard
              icon={<Heart className="w-12 h-12" />}
              title="Recovery Intelligence"
              color="text-green-400"
              bgColor="bg-green-500/10"
              borderColor="border-green-500/30"
            />
            <EngineCard
              icon={<BarChart3 className="w-12 h-12" />}
              title="Training Intelligence"
              color="text-blue-400"
              bgColor="bg-blue-500/10"
              borderColor="border-blue-500/30"
            />
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold text-slate-800 mb-6">
            Ready to Transform Performance Analytics?
          </h2>
          <p className="text-xl text-slate-600 mb-8">
            Join federations, sponsors, and elite coaches using BIM-APES for
            real-time biometric intelligence.
          </p>
          <div className="flex gap-4 justify-center">
            <a
              href="/account/signup"
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg inline-block"
            >
              Start Free Trial
            </a>
            <a
              href="/analytics-dashboard"
              className="bg-white text-slate-700 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-slate-100 transition-all border-2 border-slate-300 inline-block"
            >
              View Demo
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1e3a5f] py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-white font-bold text-lg mb-4">BIM-APES</h3>
              <p className="text-slate-300 text-sm">
                Coalition-grade biometric intelligence for performance
                optimization and NIL valuation.
              </p>
            </div>
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="/analytics-dashboard"
                    className="text-slate-300 hover:text-white text-sm transition-colors"
                  >
                    Intelligence Dashboard
                  </a>
                </li>
                <li>
                  <a
                    href="/coach-portal"
                    className="text-slate-300 hover:text-white text-sm transition-colors"
                  >
                    Coach Portal
                  </a>
                </li>
                <li>
                  <a
                    href="/sandbox-builder"
                    className="text-slate-300 hover:text-white text-sm transition-colors"
                  >
                    Sandbox Builder
                  </a>
                </li>
                <li>
                  <a
                    href="/privacy"
                    className="text-slate-300 hover:text-white text-sm transition-colors"
                  >
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Contact</h3>
              <p className="text-slate-300 text-sm mb-2">
                Business Partnerships
              </p>
              <p className="text-slate-400 text-sm">bim-apes@consultant.com</p>
              <p className="text-slate-400 text-sm mt-2">
                LinkedIn: Bledsoe Investment Management
              </p>
            </div>
          </div>

          <div className="border-t border-slate-600 pt-8">
            <p className="text-slate-400 text-xs text-center mb-2">
              © {new Date().getFullYear()} Dashawn Ramel Bledsoe / NIBLS Inc.
              All Rights Reserved.
            </p>
            <p className="text-slate-500 text-xs text-center">
              BIM-APES Software is developed and published by Bledsoe Investment
              Management, a division of NIBLS Inc.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function StatCard({ number, label }) {
  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all">
      <div className="text-5xl font-bold text-white mb-2">{number}</div>
      <div className="text-slate-300">{label}</div>
    </div>
  );
}

function DashboardCard({
  title,
  badge,
  icon,
  description,
  features,
  buttonLabel,
  href,
  gradient,
}) {
  return (
    <div className="bg-white rounded-2xl p-8 shadow-xl border border-slate-200 hover:shadow-2xl transition-all">
      <div className="flex items-start gap-4 mb-6">
        <div className={`bg-gradient-to-br ${gradient} p-3 rounded-xl`}>
          {icon}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-2xl font-bold text-slate-800">{title}</h3>
            {badge && (
              <span className="bg-gradient-to-r from-yellow-400 to-orange-400 text-white text-xs font-bold px-3 py-1 rounded-full">
                {badge}
              </span>
            )}
          </div>
        </div>
      </div>

      <p className="text-slate-600 mb-6 leading-relaxed">{description}</p>

      <div className="mb-8">
        <h4 className="text-sm font-bold text-slate-700 mb-4 uppercase tracking-wide">
          Key Features
        </h4>
        <ul className="space-y-2">
          {features.map((feature, idx) => (
            <li key={idx} className="flex items-start gap-3">
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2"></div>
              <span className="text-slate-600 text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      <a
        href={href}
        className={`block text-center w-full bg-gradient-to-r ${gradient} text-white py-4 px-6 rounded-xl font-semibold hover:shadow-lg transition-all`}
      >
        {buttonLabel}
      </a>
    </div>
  );
}

function CapabilityCard({ icon, title, description, bgColor }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-md border border-slate-200 hover:shadow-lg transition-all">
      <div
        className={`${bgColor} w-16 h-16 rounded-xl flex items-center justify-center mb-4`}
      >
        {icon}
      </div>
      <h3 className="text-lg font-bold text-slate-800 mb-3">{title}</h3>
      <p className="text-slate-600 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function EngineCard({ icon, title, color, bgColor, borderColor }) {
  return (
    <div
      className={`${bgColor} backdrop-blur-sm rounded-xl p-8 border ${borderColor} hover:scale-105 transition-all`}
    >
      <div className={`${color} mb-4 flex justify-center`}>{icon}</div>
      <h3 className={`text-xl font-bold ${color} text-center`}>{title}</h3>
    </div>
  );
}
