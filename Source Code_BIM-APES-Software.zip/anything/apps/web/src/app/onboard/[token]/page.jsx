"use client";

import { useState, useEffect } from "react";
import {
  CheckCircle,
  Trophy,
  Target,
  Wallet,
  Shield,
  Activity,
  Users,
  User,
  TrendingUp,
  ArrowRight,
  Camera,
  Vote,
  Gift,
  Star,
  Zap,
  PieChart,
  Heart,
  Clock,
  DollarSign,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function AthleteOnboardingPage({ params }) {
  const { data: user, loading } = useUser();
  const [onboardingData, setOnboardingData] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const steps = [
    {
      id: "welcome",
      title: "Welcome to BIM-APES",
      description: "Your verified athletic investment profile",
      icon: Trophy,
    },
    {
      id: "profile",
      title: "Profile Overview",
      description: "Review your athlete profile and milestones",
      icon: User,
    },
    {
      id: "milestones",
      title: "Active Milestones",
      description: "Performance goals and fan staking pools",
      icon: Target,
    },
    {
      id: "wallet",
      title: "Digital Wallet",
      description: "Motion-backed finance account activation",
      icon: Wallet,
    },
    {
      id: "dao",
      title: "DAO Governance",
      description: "Community voting and investment decisions",
      icon: Vote,
    },
    {
      id: "complete",
      title: "Platform Access",
      description: "Full BIM-APES ecosystem activation",
      icon: Zap,
    },
  ];

  useEffect(() => {
    fetchOnboardingData();
  }, [params.token]);

  const fetchOnboardingData = async () => {
    try {
      const response = await fetch(`/api/onboard/${params.token}`);
      if (response.ok) {
        const data = await response.json();
        setOnboardingData(data);
      } else {
        console.error("Invalid onboarding token");
      }
    } catch (error) {
      console.error("Failed to fetch onboarding data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const completeOnboarding = async () => {
    try {
      const response = await fetch(`/api/onboard/${params.token}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agreed_to_terms: agreedToTerms }),
      });

      if (response.ok) {
        window.location.href = "/dashboard";
      }
    } catch (error) {
      console.error("Failed to complete onboarding:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#B8860B] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your athlete profile...</p>
        </div>
      </div>
    );
  }

  if (!onboardingData) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center p-8">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Target className="w-10 h-10 text-red-600" />
          </div>
          <h1 className="text-3xl font-bold text-[#1D2B3D] mb-4">
            Invalid Onboarding Link
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            This onboarding link is invalid or has expired. Please contact your
            coach or representative for a new activation link.
          </p>
          <a
            href="/"
            className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-8 py-3 rounded-lg font-semibold transition-colors"
          >
            Return to Platform
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1D2B3D] to-[#2C3E50] text-white">
        <div className="px-6 py-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center space-x-2 bg-[#B8860B]/20 px-4 py-2 rounded-full border border-[#B8860B]/30 mb-6">
              <Trophy className="w-5 h-5 text-[#B8860B]" />
              <span className="text-[#B8860B] font-medium">
                Verified Athlete Profile
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Welcome to BIM-APES
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Your coach has successfully referred you to our institutional
              athletic investment platform. Let's activate your verified athlete
              profile.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Progress Steps */}
        <div className="mb-12">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;

              return (
                <div key={step.id} className="flex items-center">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-colors ${
                        isCompleted
                          ? "bg-green-600 border-green-600 text-white"
                          : isActive
                            ? "bg-[#B8860B] border-[#B8860B] text-white"
                            : "bg-white border-gray-300 text-gray-500"
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle className="w-6 h-6" />
                      ) : (
                        <StepIcon className="w-6 h-6" />
                      )}
                    </div>
                    <div className="mt-2 text-center">
                      <div
                        className={`text-sm font-medium ${isActive ? "text-[#B8860B]" : "text-gray-600"}`}
                      >
                        {step.title}
                      </div>
                      <div className="text-xs text-gray-500">
                        {step.description}
                      </div>
                    </div>
                  </div>

                  {index < steps.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-4 transition-colors ${
                        index < currentStep ? "bg-green-600" : "bg-gray-300"
                      }`}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-sm">
          {currentStep === 0 && (
            <div className="text-center">
              <div className="w-20 h-20 bg-[#B8860B]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trophy className="w-10 h-10 text-[#B8860B]" />
              </div>
              <h2 className="text-3xl font-bold text-[#1D2B3D] mb-4">
                Welcome {onboardingData.athlete_name}!
              </h2>
              <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
                Your coach <strong>{onboardingData.rep_name}</strong> from{" "}
                <strong>{onboardingData.rep_organization}</strong> has submitted
                you to the BIM-APES platform as a verified athletic investment
                asset.
              </p>

              <div className="bg-[#F5F5F0] rounded-lg p-6 mb-8">
                <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                  Your Profile Summary
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#B8860B]">
                      {onboardingData.athlete_sport}
                    </div>
                    <div className="text-sm text-gray-600">Sport</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#B8860B]">
                      {onboardingData.athlete_level
                        ?.replace(/_/g, " ")
                        .replace(/\b\w/g, (l) => l.toUpperCase())}
                    </div>
                    <div className="text-sm text-gray-600">Level</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#B8860B]">
                      {onboardingData.milestones?.length || 0}
                    </div>
                    <div className="text-sm text-gray-600">Milestones</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#B8860B]">
                      Silver
                    </div>
                    <div className="text-sm text-gray-600">Starting Tier</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 1 && (
            <div>
              <h2 className="text-3xl font-bold text-[#1D2B3D] mb-6">
                Your Athlete Profile
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                    Performance Highlights
                  </h3>
                  <div className="bg-[#F5F5F0] rounded-lg p-4 mb-4">
                    <h4 className="font-medium text-gray-700 mb-2">
                      Standout Traits
                    </h4>
                    <p className="text-gray-600">
                      {onboardingData.standout_traits}
                    </p>
                  </div>
                  <div className="bg-[#F5F5F0] rounded-lg p-4">
                    <h4 className="font-medium text-gray-700 mb-2">
                      Training Schedule
                    </h4>
                    <p className="text-gray-600">
                      {onboardingData.training_schedule}
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                    Asset Metrics
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                      <span className="text-gray-700">
                        Initial Reputation Score
                      </span>
                      <span className="font-bold text-[#B8860B]">
                        {onboardingData.reputation_score}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                      <span className="text-gray-700">Starting Tier</span>
                      <span className="font-bold text-[#B8860B]">Silver</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-[#F5F5F0] rounded-lg">
                      <span className="text-gray-700">
                        Investment Eligibility
                      </span>
                      <span className="font-bold text-green-600">Active</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div>
              <h2 className="text-3xl font-bold text-[#1D2B3D] mb-6">
                Your Active Milestones
              </h2>
              <p className="text-gray-600 mb-8">
                Your coach has pre-selected these performance milestones based
                on your strengths. Fans can now stake on your success, and
                you'll earn rewards when you hit these goals.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {onboardingData.milestones?.map((milestone, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-[#B8860B]/10 rounded-lg flex items-center justify-center">
                        <Target className="w-6 h-6 text-[#B8860B]" />
                      </div>
                      <div className="text-sm text-gray-500">
                        ${milestone.reward_pool} Pool
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-[#1D2B3D] mb-2">
                      {milestone.title}
                    </h3>
                    <p className="text-gray-600 mb-4">
                      {milestone.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">
                        Target:{" "}
                        {new Date(milestone.target_date).toLocaleDateString()}
                      </span>
                      <span className="text-sm font-medium text-[#B8860B]">
                        Ready for Staking
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div>
              <h2 className="text-3xl font-bold text-[#1D2B3D] mb-6">
                Digital Wallet Activation
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4 flex items-center space-x-2">
                    <Wallet className="w-5 h-5" />
                    <span>Wallet Features</span>
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-3 bg-[#F5F5F0] rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">
                        Milestone payout processing
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-[#F5F5F0] rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">
                        QR code & NFC payments
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-[#F5F5F0] rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">
                        Auto-reinvestment settings
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-[#F5F5F0] rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">
                        Insurance eligibility (Silver+)
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                    Wallet Settings
                  </h3>
                  <div className="bg-[#F5F5F0] rounded-lg p-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">Starting Balance</span>
                        <span className="font-bold text-[#B8860B]">$0.00</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">Auto-Reinvestment</span>
                        <span className="font-bold text-[#B8860B]">10%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">
                          Insurance Coverage
                        </span>
                        <span className="font-bold text-green-600">
                          Eligible
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">Payment Methods</span>
                        <span className="font-bold text-blue-600">
                          QR + NFC
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div>
              <h2 className="text-3xl font-bold text-[#1D2B3D] mb-6">
                DAO Governance Access
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                    Your Voting Power
                  </h3>
                  <div className="bg-[#F5F5F0] rounded-lg p-6">
                    <div className="text-center mb-6">
                      <div className="text-4xl font-bold text-[#B8860B] mb-2">
                        5
                      </div>
                      <div className="text-gray-600">Initial Voting Power</div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          Base Votes (Silver Tier)
                        </span>
                        <span className="font-medium">5</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          Performance Bonus
                        </span>
                        <span className="font-medium">+0</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          Contribution Bonus
                        </span>
                        <span className="font-medium">+0</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                    DAO Participation
                  </h3>
                  <div className="space-y-4">
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h4 className="font-medium text-[#1D2B3D] mb-2">
                        Vote on Proposals
                      </h4>
                      <p className="text-sm text-gray-600">
                        Participate in platform governance decisions
                      </p>
                    </div>
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h4 className="font-medium text-[#1D2B3D] mb-2">
                        Treasury Oversight
                      </h4>
                      <p className="text-sm text-gray-600">
                        View transparent fund allocation
                      </p>
                    </div>
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h4 className="font-medium text-[#1D2B3D] mb-2">
                        Milestone Proposals
                      </h4>
                      <p className="text-sm text-gray-600">
                        Suggest new performance categories
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 5 && (
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-[#1D2B3D] mb-4">
                Ready to Activate!
              </h2>
              <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
                Your BIM-APES athlete profile is configured and ready. By
                proceeding, you'll have full access to the motion-backed finance
                ecosystem.
              </p>

              <div className="bg-[#F5F5F0] rounded-lg p-6 mb-8 max-w-2xl mx-auto">
                <h3 className="text-xl font-semibold text-[#1D2B3D] mb-4">
                  What happens next:
                </h3>
                <div className="space-y-3 text-left">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">1</span>
                    </div>
                    <span className="text-gray-700">
                      Your milestones go live for fan staking
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">2</span>
                    </div>
                    <span className="text-gray-700">
                      You'll receive a secure sign-in link via SMS
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-[#B8860B] rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">3</span>
                    </div>
                    <span className="text-gray-700">
                      Start earning from verified performance
                    </span>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <label className="flex items-center justify-center space-x-3">
                  <input
                    type="checkbox"
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    className="w-4 h-4 text-[#B8860B] rounded focus:ring-[#B8860B]"
                  />
                  <span className="text-gray-700">
                    I agree to the BIM-APES Athlete Terms and understand the
                    investment nature of this platform
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>

            {currentStep < steps.length - 1 ? (
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                className="bg-[#1D2B3D] hover:bg-[#B8860B] text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2"
              >
                <span>Next Step</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={completeOnboarding}
                disabled={!agreedToTerms}
                className="bg-[#B8860B] hover:bg-[#A0750A] text-white px-8 py-3 rounded-lg font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <Zap className="w-5 h-5" />
                <span>Activate Profile</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
