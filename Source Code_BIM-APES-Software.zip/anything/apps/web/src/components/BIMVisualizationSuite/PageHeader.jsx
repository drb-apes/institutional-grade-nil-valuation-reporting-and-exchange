import { BarChart3 } from "lucide-react";

export function PageHeader() {
  return (
    <div className="max-w-7xl mx-auto mb-8">
      <div className="flex items-center gap-4 mb-2">
        <BarChart3 className="w-12 h-12 text-indigo-400" />
        <div>
          <h1 className="text-4xl font-bold text-white">
            BIM-APES Visualization Suite
          </h1>
          <p className="text-indigo-200 text-lg">
            AR Biomechanical Overlay · Biomechflow Charts · All Sports Coverage
          </p>
        </div>
      </div>
    </div>
  );
}
