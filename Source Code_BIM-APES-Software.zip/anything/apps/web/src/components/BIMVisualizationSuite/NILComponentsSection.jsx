import { BarChart3 } from "lucide-react";
import RadarChart from "@/components/AdvancedVisualizations/RadarChart";

function ComponentBar({ label, value, color }) {
  const colors = {
    blue: "from-blue-500 to-blue-600",
    purple: "from-purple-500 to-purple-600",
    green: "from-green-500 to-green-600",
    yellow: "from-yellow-500 to-yellow-600",
    pink: "from-pink-500 to-pink-600",
    indigo: "from-indigo-500 to-indigo-600",
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <span className="text-blue-200 text-sm">{label}</span>
        <span className="text-white font-mono font-semibold">{value}</span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-3">
        <div
          className={`bg-gradient-to-r ${colors[color]} h-3 rounded-full transition-all duration-500`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

export function NILComponentsSection({ nilRadar }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-4">
        <BarChart3 className="w-6 h-6 text-purple-400" />
        <h2 className="text-xl font-bold text-white">
          NIL Value Component Breakdown
        </h2>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <RadarChart data={nilRadar} width={450} height={400} />
        </div>
        <div className="flex items-center">
          <div className="space-y-4 w-full">
            <ComponentBar label="Performance NIL" value={88} color="blue" />
            <ComponentBar label="Social Media NIL" value={75} color="purple" />
            <ComponentBar label="Brand Fit NIL" value={82} color="green" />
            <ComponentBar label="Engagement NIL" value={90} color="yellow" />
            <ComponentBar label="Marketability NIL" value={85} color="pink" />
            <ComponentBar label="Consistency NIL" value={78} color="indigo" />
          </div>
        </div>
      </div>
    </div>
  );
}
