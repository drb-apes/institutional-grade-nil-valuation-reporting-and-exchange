export function IntegrationExamples() {
  return (
    <div className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10 backdrop-blur-lg rounded-xl p-6 border border-indigo-400/30">
      <h3 className="text-white font-semibold text-xl mb-4">
        Component Integration Examples
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
          <h4 className="text-indigo-300 font-semibold mb-3">HeatmapChart</h4>
          <pre className="text-green-400 text-xs overflow-x-auto">
            {`<HeatmapChart
  data={heatmapData}
  width={500}
  height={400}
/>`}
          </pre>
        </div>
        <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
          <h4 className="text-indigo-300 font-semibold mb-3">RadarChart</h4>
          <pre className="text-green-400 text-xs overflow-x-auto">
            {`<RadarChart
  data={radarData}
  width={400}
  height={400}
/>`}
          </pre>
        </div>
        <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
          <h4 className="text-indigo-300 font-semibold mb-3">
            CandlestickChart
          </h4>
          <pre className="text-green-400 text-xs overflow-x-auto">
            {`<CandlestickChart
  data={candlestickData}
  showVolume={true}
  height={400}
/>`}
          </pre>
        </div>
        <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
          <h4 className="text-indigo-300 font-semibold mb-3">TrendlineChart</h4>
          <pre className="text-green-400 text-xs overflow-x-auto">
            {`<TrendlineChart
  data={trendlineData}
  width={600}
  height={400}
/>`}
          </pre>
        </div>
      </div>
    </div>
  );
}
