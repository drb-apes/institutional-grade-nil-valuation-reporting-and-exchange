import { GitBranch } from "lucide-react";
import { generateFlowMockData } from "./mockDataGenerators";

export function BiomechflowChart({ sport, sportConfig }) {
  const flowData = generateFlowMockData(sport);

  return (
    <div className="space-y-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center gap-3 mb-4">
          <GitBranch className="w-6 h-6 text-purple-400" />
          <h2 className="text-2xl font-bold text-white">
            Biomechflow Chart - {sportConfig.name}
          </h2>
        </div>

        {/* Flow Sequence Visualization */}
        <div
          className="relative bg-slate-900 rounded-lg p-8"
          style={{ height: "400px" }}
        >
          <svg width="100%" height="100%" viewBox="0 0 1200 350">
            {/* Flow curve path */}
            <path
              d="M 80 175 Q 180 80, 280 175 T 480 175 T 680 175 T 880 175 T 1080 175"
              fill="none"
              stroke="url(#flowGradient)"
              strokeWidth="6"
              opacity="0.6"
            />

            {/* Phase nodes */}
            {flowData.phases.map((phase, idx) => {
              const x = 80 + idx * 200;
              const y = 175 + Math.sin(idx * 0.8) * 60;
              const efficiency = phase.efficiency;
              const nodeColor =
                efficiency > 85
                  ? "#10B981"
                  : efficiency > 70
                    ? "#F59E0B"
                    : "#EF4444";

              return (
                <g key={idx}>
                  {/* Node circle */}
                  <circle
                    cx={x}
                    cy={y}
                    r={efficiency > 85 ? 24 : 20}
                    fill={nodeColor}
                    opacity="0.9"
                    stroke="white"
                    strokeWidth="2"
                  />
                  {/* Efficiency value */}
                  <text
                    x={x}
                    y={y + 5}
                    textAnchor="middle"
                    fill="white"
                    fontSize="14"
                    fontWeight="bold"
                  >
                    {efficiency.toFixed(0)}
                  </text>
                  {/* Phase label */}
                  <text
                    x={x}
                    y={y + 50}
                    textAnchor="middle"
                    fill="#94A3B8"
                    fontSize="12"
                  >
                    {phase.name}
                  </text>
                  {/* Duration */}
                  <text
                    x={x}
                    y={y + 68}
                    textAnchor="middle"
                    fill="#64748B"
                    fontSize="10"
                  >
                    {phase.duration.toFixed(0)}ms
                  </text>
                </g>
              );
            })}

            {/* Connection lines with data flow indicators */}
            {flowData.phases.slice(0, -1).map((phase, idx) => {
              const x1 = 80 + idx * 200;
              const x2 = 80 + (idx + 1) * 200;
              const y1 = 175 + Math.sin(idx * 0.8) * 60;
              const y2 = 175 + Math.sin((idx + 1) * 0.8) * 60;

              return (
                <line
                  key={`flow-${idx}`}
                  x1={x1 + 24}
                  y1={y1}
                  x2={x2 - 24}
                  y2={y2}
                  stroke="#64748B"
                  strokeWidth="2"
                  strokeDasharray="4,4"
                  opacity="0.5"
                  markerEnd="url(#flowArrow)"
                />
              );
            })}

            <defs>
              <linearGradient
                id="flowGradient"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="0%"
              >
                <stop offset="0%" stopColor="#3B82F6" />
                <stop offset="25%" stopColor="#8B5CF6" />
                <stop offset="50%" stopColor="#EC4899" />
                <stop offset="75%" stopColor="#F59E0B" />
                <stop offset="100%" stopColor="#10B981" />
              </linearGradient>
              <marker
                id="flowArrow"
                markerWidth="10"
                markerHeight="10"
                refX="8"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 10 3, 0 6" fill="#64748B" />
              </marker>
            </defs>
          </svg>

          {/* Legend */}
          <div className="absolute bottom-6 left-6 bg-black/80 rounded-lg px-4 py-3 border border-slate-600">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-green-500" />
                <span className="text-xs text-slate-300">
                  Excellent (&gt;85%)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-yellow-500" />
                <span className="text-xs text-slate-300">Good (70-85%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-red-500" />
                <span className="text-xs text-slate-300">
                  Needs Work (&lt;70%)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Phase Breakdown Table */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-6 gap-3">
          {flowData.phases.map((phase, idx) => (
            <div
              key={idx}
              className={`rounded-lg p-4 border ${
                phase.efficiency > 85
                  ? "bg-green-500/10 border-green-500/30"
                  : phase.efficiency > 70
                    ? "bg-yellow-500/10 border-yellow-500/30"
                    : "bg-red-500/10 border-red-500/30"
              }`}
            >
              <div className="text-xs text-slate-400 mb-1 uppercase">
                {phase.name}
              </div>
              <div className="text-2xl font-bold text-white">
                {phase.efficiency.toFixed(0)}%
              </div>
              <div className="text-xs text-slate-500 mt-1">
                {phase.duration.toFixed(0)}ms
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Energy Transfer Analysis */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h3 className="text-white font-semibold mb-4">
          Energy Transfer Efficiency
        </h3>
        <div className="h-40 flex items-end gap-2">
          {flowData.energyTransfer.map((point, idx) => (
            <div
              key={idx}
              className="flex-1 bg-gradient-to-t from-purple-600 to-pink-600 rounded-t transition-all hover:opacity-75 cursor-pointer relative group"
              style={{ height: `${point.value}%` }}
            >
              <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-black/90 px-2 py-1 rounded text-xs text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                {point.value.toFixed(0)}% @ {point.time}ms
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 flex justify-between text-xs text-slate-400">
          <span>Start</span>
          <span>Movement Sequence Timeline</span>
          <span>End</span>
        </div>
      </div>
    </div>
  );
}
