import { Target } from "lucide-react";

export function SportSelector({ sportConfigs, activeSport, onSportChange }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
      <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
        <Target className="w-5 h-5" />
        Select Sport (47 Sports Coverage)
      </h3>
      <div className="flex gap-3 flex-wrap">
        {Object.entries(sportConfigs).map(([key, config]) => (
          <button
            key={key}
            onClick={() => onSportChange(key)}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
              activeSport === key
                ? "bg-indigo-600 text-white shadow-lg scale-105"
                : "bg-slate-800/50 text-indigo-300 hover:bg-slate-700"
            }`}
          >
            {config.icon}
            <span>{config.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
