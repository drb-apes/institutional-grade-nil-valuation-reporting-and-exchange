import {
  Layers,
  Eye,
  GitBranch,
  Target,
  Activity,
  TrendingUp,
  BarChart3,
} from "lucide-react";

function ChartTab({ id, label, icon, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-2 px-4 py-4 rounded-lg font-medium transition-all ${
        active
          ? "bg-indigo-600 text-white shadow-lg scale-105"
          : "bg-slate-800/50 text-slate-300 hover:bg-slate-700"
      }`}
    >
      {icon}
      <span className="text-xs text-center">{label}</span>
    </button>
  );
}

export function ChartTypeSelector({ activeChart, onChartChange }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
      <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
        <Layers className="w-5 h-5" />
        Visualization Type
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <ChartTab
          id="ar-overlay"
          label="AR Biomechanical Overlay"
          icon={<Eye className="w-5 h-5" />}
          active={activeChart === "ar-overlay"}
          onClick={() => onChartChange("ar-overlay")}
        />
        <ChartTab
          id="biomechflow"
          label="Biomechflow Chart"
          icon={<GitBranch className="w-5 h-5" />}
          active={activeChart === "biomechflow"}
          onClick={() => onChartChange("biomechflow")}
        />
        <ChartTab
          id="heatmap"
          label="3D Heatmap"
          icon={<Target className="w-5 h-5" />}
          active={activeChart === "heatmap"}
          onClick={() => onChartChange("heatmap")}
        />
        <ChartTab
          id="radar"
          label="Radar Profile"
          icon={<Activity className="w-5 h-5" />}
          active={activeChart === "radar"}
          onClick={() => onChartChange("radar")}
        />
        <ChartTab
          id="candlestick"
          label="NIL Volatility"
          icon={<TrendingUp className="w-5 h-5" />}
          active={activeChart === "candlestick"}
          onClick={() => onChartChange("candlestick")}
        />
        <ChartTab
          id="trendline"
          label="Progression"
          icon={<BarChart3 className="w-5 h-5" />}
          active={activeChart === "trendline"}
          onClick={() => onChartChange("trendline")}
        />
      </div>
    </div>
  );
}
