import { Eye } from "lucide-react";
import { generateARMockData } from "./mockDataGenerators";

function JointMetric({ joint, angle, optimal, status }) {
  const statusConfig = {
    optimal: { color: "green", text: "Optimal" },
    acceptable: { color: "yellow", text: "Acceptable" },
    attention: { color: "red", text: "Attention" },
  };

  const config = statusConfig[status] || statusConfig.attention;

  return (
    <div
      className={`bg-${config.color}-500/10 rounded-lg p-4 border border-${config.color}-500/30`}
    >
      <div className="text-xs text-slate-400 mb-2 uppercase">{joint}</div>
      <div className={`text-2xl font-bold text-${config.color}-400`}>
        {angle}°
      </div>
      <div className="text-xs text-slate-500 mt-1">Target: {optimal}°</div>
      <div className={`text-xs text-${config.color}-400 mt-1 font-semibold`}>
        {config.text}
      </div>
    </div>
  );
}

function MetricRow({ label, value, color }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-slate-300 text-sm">{label}</span>
      <span className={`text-${color}-400 font-mono font-bold`}>{value}</span>
    </div>
  );
}

export function ARBiomechanicalOverlay({ sport, sportConfig }) {
  const mockData = generateARMockData(sport);

  return (
    <div className="space-y-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center gap-3 mb-4">
          <Eye className="w-6 h-6 text-cyan-400" />
          <h2 className="text-2xl font-bold text-white">
            AR Biomechanical Overlay - {sportConfig.name}
          </h2>
        </div>

        {/* AR Skeleton View */}
        <div
          className="relative bg-black rounded-lg overflow-hidden"
          style={{ height: "500px" }}
        >
          <svg
            width="100%"
            height="100%"
            viewBox="0 0 600 500"
            className="opacity-95"
          >
            {/* Head */}
            <circle
              cx="300"
              cy="80"
              r="30"
              fill="none"
              stroke="#06B6D4"
              strokeWidth="3"
            />
            <circle
              cx="300"
              cy="80"
              r="32"
              fill="none"
              stroke="#06B6D4"
              strokeWidth="1"
              opacity="0.3"
            />

            {/* Spine */}
            <line
              x1="300"
              y1="110"
              x2="300"
              y2="250"
              stroke="#06B6D4"
              strokeWidth="4"
            />

            {/* Shoulders */}
            <line
              x1="220"
              y1="140"
              x2="380"
              y2="140"
              stroke="#06B6D4"
              strokeWidth="4"
            />
            <circle
              cx="220"
              cy="140"
              r="10"
              fill="#06B6D4"
              stroke="#0891B2"
              strokeWidth="2"
            />
            <circle
              cx="380"
              cy="140"
              r="10"
              fill="#06B6D4"
              stroke="#0891B2"
              strokeWidth="2"
            />

            {/* Left Arm */}
            <line
              x1="220"
              y1="140"
              x2="180"
              y2="220"
              stroke="#10B981"
              strokeWidth="4"
            />
            <circle
              cx="180"
              cy="220"
              r="8"
              fill="#10B981"
              stroke="#059669"
              strokeWidth="2"
            />
            <line
              x1="180"
              y1="220"
              x2="150"
              y2="310"
              stroke="#10B981"
              strokeWidth="4"
            />
            <circle
              cx="150"
              cy="310"
              r="8"
              fill="#10B981"
              stroke="#059669"
              strokeWidth="2"
            />

            {/* Right Arm */}
            <line
              x1="380"
              y1="140"
              x2="420"
              y2="220"
              stroke="#10B981"
              strokeWidth="4"
            />
            <circle
              cx="420"
              cy="220"
              r="8"
              fill="#10B981"
              stroke="#059669"
              strokeWidth="2"
            />
            <line
              x1="420"
              y1="220"
              x2="450"
              y2="310"
              stroke="#10B981"
              strokeWidth="4"
            />
            <circle
              cx="450"
              cy="310"
              r="8"
              fill="#10B981"
              stroke="#059669"
              strokeWidth="2"
            />

            {/* Hips */}
            <line
              x1="260"
              y1="250"
              x2="340"
              y2="250"
              stroke="#06B6D4"
              strokeWidth="4"
            />
            <circle
              cx="260"
              cy="250"
              r="10"
              fill="#06B6D4"
              stroke="#0891B2"
              strokeWidth="2"
            />
            <circle
              cx="340"
              cy="250"
              r="10"
              fill="#06B6D4"
              stroke="#0891B2"
              strokeWidth="2"
            />

            {/* Left Leg */}
            <line
              x1="260"
              y1="250"
              x2="240"
              y2="360"
              stroke="#F59E0B"
              strokeWidth="4"
            />
            <circle
              cx="240"
              cy="360"
              r="8"
              fill="#F59E0B"
              stroke="#D97706"
              strokeWidth="2"
            />
            <line
              x1="240"
              y1="360"
              x2="220"
              y2="470"
              stroke="#F59E0B"
              strokeWidth="4"
            />
            <circle
              cx="220"
              cy="470"
              r="8"
              fill="#F59E0B"
              stroke="#D97706"
              strokeWidth="2"
            />

            {/* Right Leg */}
            <line
              x1="340"
              y1="250"
              x2="360"
              y2="360"
              stroke="#F59E0B"
              strokeWidth="4"
            />
            <circle
              cx="360"
              cy="360"
              r="8"
              fill="#F59E0B"
              stroke="#D97706"
              strokeWidth="2"
            />
            <line
              x1="360"
              y1="360"
              x2="380"
              y2="470"
              stroke="#F59E0B"
              strokeWidth="4"
            />
            <circle
              cx="380"
              cy="470"
              r="8"
              fill="#F59E0B"
              stroke="#D97706"
              strokeWidth="2"
            />

            {/* Force Vectors */}
            <line
              x1="300"
              y1="250"
              x2="300"
              y2="150"
              stroke="#EF4444"
              strokeWidth="3"
              strokeDasharray="5,5"
              markerEnd="url(#arrowRed)"
            />
            <line
              x1="180"
              y1="220"
              x2="120"
              y2="180"
              stroke="#EF4444"
              strokeWidth="3"
              strokeDasharray="5,5"
              markerEnd="url(#arrowRed)"
            />
            <line
              x1="420"
              y1="220"
              x2="480"
              y2="180"
              stroke="#EF4444"
              strokeWidth="3"
              strokeDasharray="5,5"
              markerEnd="url(#arrowRed)"
            />

            {/* Joint Angle Indicators */}
            <text
              x="180"
              y="210"
              fill="#10B981"
              fontSize="12"
              fontWeight="bold"
            >
              92°
            </text>
            <text
              x="420"
              y="210"
              fill="#10B981"
              fontSize="12"
              fontWeight="bold"
            >
              88°
            </text>
            <text
              x="240"
              y="350"
              fill="#F59E0B"
              fontSize="12"
              fontWeight="bold"
            >
              118°
            </text>
            <text
              x="360"
              y="350"
              fill="#F59E0B"
              fontSize="12"
              fontWeight="bold"
            >
              122°
            </text>

            <defs>
              <marker
                id="arrowRed"
                markerWidth="12"
                markerHeight="12"
                refX="10"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 12 3, 0 6" fill="#EF4444" />
              </marker>
            </defs>
          </svg>

          {/* AR Overlay UI */}
          <div className="absolute top-4 left-4 bg-black/80 rounded-lg px-4 py-2 border border-cyan-500/50">
            <div className="text-cyan-400 text-xs font-mono">
              TRACKING: ACTIVE
            </div>
            <div className="text-green-400 text-xs font-mono mt-1">
              JOINTS: 16/16
            </div>
          </div>
          <div className="absolute top-4 right-4 bg-black/80 rounded-lg px-4 py-2 border border-cyan-500/50">
            <div className="text-cyan-400 text-xs font-mono">
              FPS: 60 | LAT: 8ms
            </div>
          </div>
          <div className="absolute bottom-4 left-4 bg-black/80 rounded-lg px-4 py-2 border border-purple-500/50">
            <div className="text-purple-400 text-xs font-mono">
              BIM SCORE: {mockData.bimScore.toFixed(1)}
            </div>
          </div>
        </div>

        {/* Joint Analysis Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <JointMetric
            joint="L Shoulder"
            angle={mockData.joints.leftShoulder}
            optimal={90}
            status={mockData.jointStatus.leftShoulder}
          />
          <JointMetric
            joint="R Shoulder"
            angle={mockData.joints.rightShoulder}
            optimal={90}
            status={mockData.jointStatus.rightShoulder}
          />
          <JointMetric
            joint="L Knee"
            angle={mockData.joints.leftKnee}
            optimal={120}
            status={mockData.jointStatus.leftKnee}
          />
          <JointMetric
            joint="R Knee"
            angle={mockData.joints.rightKnee}
            optimal={120}
            status={mockData.jointStatus.rightKnee}
          />
        </div>
      </div>

      {/* Biomechanical Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-white font-semibold mb-4">
            Force Output Analysis
          </h4>
          <div className="space-y-3">
            <MetricRow
              label="Peak Force"
              value={`${mockData.peakForce.toFixed(0)}N`}
              color="red"
            />
            <MetricRow
              label="Avg Force"
              value={`${mockData.avgForce.toFixed(0)}N`}
              color="orange"
            />
            <MetricRow
              label="Force Efficiency"
              value={`${mockData.forceEfficiency.toFixed(0)}%`}
              color="green"
            />
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-white font-semibold mb-4">Movement Quality</h4>
          <div className="space-y-3">
            <MetricRow
              label="Range of Motion"
              value={`${mockData.rangeOfMotion.toFixed(0)}%`}
              color="blue"
            />
            <MetricRow
              label="Symmetry Score"
              value={`${mockData.symmetry.toFixed(0)}%`}
              color="purple"
            />
            <MetricRow
              label="Fluidity Index"
              value={`${mockData.fluidity.toFixed(0)}%`}
              color="cyan"
            />
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h4 className="text-white font-semibold mb-4">
            Injury Risk Indicators
          </h4>
          <div className="space-y-3">
            <MetricRow
              label="Fatigue Level"
              value={`${mockData.fatigueLevel.toFixed(0)}%`}
              color="yellow"
            />
            <MetricRow
              label="Asymmetry Risk"
              value={`${mockData.asymmetryRisk.toFixed(0)}%`}
              color="red"
            />
            <MetricRow
              label="Load Capacity"
              value={`${mockData.loadCapacity.toFixed(0)}%`}
              color="green"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
