export const CHART_TYPES = [
  {
    id: "ar_overlay",
    label: "AR Biomechanical Overlay",
    description: "Real-time joint tracking with force vectors",
  },
  {
    id: "biomechflow",
    label: "Biomechflow Chart",
    description: "Performance phase flow analysis",
  },
  {
    id: "heatmap",
    label: "Performance Heatmap",
    description: "Spatial intensity mapping",
  },
  {
    id: "radar",
    label: "Capability Radar",
    description: "Multi-dimensional athlete profile",
  },
  {
    id: "candlestick",
    label: "NIL Valuation Chart",
    description: "Real-time NIL price action",
  },
  {
    id: "trendline",
    label: "Performance Trendline",
    description: "Historical performance trajectory",
  },
];
