import { combatSports } from "./combatSports";
import { tacticalSports } from "./tacticalSports";
import { racketSports } from "./racketSports";
import { trackAndField } from "./trackAndField";
import { aquaticSports } from "./aquaticSports";
import { cyclingSports } from "./cyclingSports";
import { gymnasticsSports } from "./gymnasticsSports";
import { entertainmentSports } from "./entertainmentSports";
import { precisionSports } from "./precisionSports";
import { winterSports } from "./winterSports";
import { strengthSports } from "./strengthSports";
import { enduranceSports } from "./enduranceSports";
import { otherSports } from "./otherSports";

export const allSports = {
  ...combatSports,
  ...tacticalSports,
  ...racketSports,
  ...trackAndField,
  ...aquaticSports,
  ...cyclingSports,
  ...gymnasticsSports,
  ...entertainmentSports,
  ...precisionSports,
  ...winterSports,
  ...strengthSports,
  ...enduranceSports,
  ...otherSports,
};
