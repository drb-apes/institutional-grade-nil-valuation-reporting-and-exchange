import { Bike, Mountain } from "../icons";
import { soccerHeatmap, tennisHeatmap } from "../constants";

export const cyclingSports = {
  cycling: {
    name: "Cycling",
    icon: <Bike className="w-6 h-6" />,
    color: "green",
    heatmap: soccerHeatmap,
    heatmapTitle: "Power Distribution & Cadence",
    biomechanicalZones: ["Core", "Hips", "Legs", "Feet"],
    keyMetrics: [
      "power_output",
      "cadence",
      "heart_rate_efficiency",
      "pedal_stroke_smoothness",
    ],
    movementPatterns: [
      "seated_climb",
      "standing_sprint",
      "descent",
      "time_trial",
    ],
    arOverlayPoints: [
      { zone: "Legs", type: "power", color: "#10b981", label: "Pedal Force" },
    ],
  },
  bmx: {
    name: "BMX",
    icon: <Bike className="w-6 h-6" />,
    color: "orange",
    heatmap: tennisHeatmap,
    heatmapTitle: "Track Speed Zones",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "pump_efficiency",
      "jump_height",
      "manual_distance",
      "cornering_speed",
    ],
    movementPatterns: ["pump", "jump", "manual", "corner"],
    arOverlayPoints: [
      { zone: "Legs", type: "pump", color: "#f97316", label: "Pump Power" },
    ],
  },
  mountain_bike: {
    name: "Mountain Biking",
    icon: <Mountain className="w-6 h-6" />,
    color: "green",
    heatmap: soccerHeatmap,
    heatmapTitle: "Trail Performance",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: ["technical_skill", "power_output", "balance", "endurance"],
    movementPatterns: ["pedal", "bunny_hop", "manual", "drop"],
    arOverlayPoints: [
      { zone: "Arms", type: "control", color: "#10b981", label: "Bar Control" },
    ],
  },
};
