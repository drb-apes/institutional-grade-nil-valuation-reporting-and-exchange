import { Zap, Target } from "../icons";
import { tennisHeatmap } from "../constants";

export const racketSports = {
  tennis: {
    name: "Tennis",
    icon: <Zap className="w-6 h-6" />,
    color: "purple",
    heatmap: tennisHeatmap,
    heatmapTitle: "Shot Placement Heatmap",
    biomechanicalZones: ["Shoulders", "Arms", "Core", "Legs", "Feet"],
    keyMetrics: [
      "serve_speed",
      "shot_accuracy",
      "court_coverage",
      "reaction_time",
      "footwork",
      "spin_generation",
    ],
    movementPatterns: ["serve", "forehand", "backhand", "volley", "smash"],
    arOverlayPoints: [
      {
        zone: "Arms",
        type: "racket_speed",
        color: "#8b5cf6",
        label: "Racket Velocity",
      },
      {
        zone: "Core",
        type: "rotation",
        color: "#ec4899",
        label: "Torso Rotation",
      },
    ],
  },
  pickleball: {
    name: "Pickleball",
    icon: <Target className="w-6 h-6" />,
    color: "purple",
    heatmap: tennisHeatmap,
    heatmapTitle: "Dink & Drive Zones",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "dink_accuracy",
      "drive_power",
      "court_positioning",
      "reaction_time",
    ],
    movementPatterns: ["dink", "drive", "lob", "volley"],
    arOverlayPoints: [
      {
        zone: "Arms",
        type: "paddle_control",
        color: "#8b5cf6",
        label: "Touch Control",
      },
    ],
  },
  badminton: {
    name: "Badminton",
    icon: <Zap className="w-6 h-6" />,
    color: "green",
    heatmap: tennisHeatmap,
    heatmapTitle: "Shuttle Placement",
    biomechanicalZones: ["Shoulders", "Arms", "Core", "Legs"],
    keyMetrics: ["smash_speed", "drop_accuracy", "court_speed", "endurance"],
    movementPatterns: ["smash", "drop", "clear", "drive"],
    arOverlayPoints: [
      {
        zone: "Arms",
        type: "wrist_snap",
        color: "#10b981",
        label: "Wrist Power",
      },
    ],
  },
  table_tennis: {
    name: "Table Tennis",
    icon: <Target className="w-6 h-6" />,
    color: "blue",
    heatmap: tennisHeatmap,
    heatmapTitle: "Table Coverage",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "spin_generation",
      "placement_accuracy",
      "reaction_time",
      "footwork",
    ],
    movementPatterns: ["topspin", "backspin", "sidespin", "counter"],
    arOverlayPoints: [
      { zone: "Arms", type: "spin", color: "#3b82f6", label: "Spin Axis" },
    ],
  },
  squash: {
    name: "Squash",
    icon: <Zap className="w-6 h-6" />,
    color: "orange",
    heatmap: tennisHeatmap,
    heatmapTitle: "Wall Target Zones",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "shot_accuracy",
      "court_coverage",
      "endurance",
      "reaction_time",
    ],
    movementPatterns: ["drive", "drop", "boast", "volley"],
    arOverlayPoints: [
      { zone: "Arms", type: "racket", color: "#f97316", label: "Racket Speed" },
    ],
  },
};
