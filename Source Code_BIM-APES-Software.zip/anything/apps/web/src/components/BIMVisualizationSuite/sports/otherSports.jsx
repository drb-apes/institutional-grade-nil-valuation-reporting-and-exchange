import { Activity, Mountain, TrendingUp, Bike } from "../icons";
import { soccerHeatmap, tennisHeatmap } from "../constants";

export const otherSports = {
  equestrian: {
    name: "Equestrian",
    icon: <Activity className="w-6 h-6" />,
    color: "brown",
    heatmap: soccerHeatmap,
    heatmapTitle: "Course Navigation",
    biomechanicalZones: ["Core", "Legs"],
    keyMetrics: [
      "rider_balance",
      "communication",
      "jump_approach",
      "landing_stability",
    ],
    movementPatterns: ["approach", "takeoff", "flight", "landing"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "balance",
        color: "#92400e",
        label: "Rider Balance",
      },
    ],
  },
  racing: {
    name: "Auto Racing",
    icon: <TrendingUp className="w-6 h-6" />,
    color: "red",
    heatmap: soccerHeatmap,
    heatmapTitle: "Track Speed Zones",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "reaction_time",
      "steering_precision",
      "braking_efficiency",
      "cornering_speed",
    ],
    movementPatterns: ["acceleration", "braking", "cornering", "overtaking"],
    arOverlayPoints: [
      {
        zone: "Arms",
        type: "steering",
        color: "#ef4444",
        label: "Steering Input",
      },
    ],
  },
  motocross: {
    name: "Motocross",
    icon: <Bike className="w-6 h-6" />,
    color: "orange",
    heatmap: soccerHeatmap,
    heatmapTitle: "Jump & Corner Analysis",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "jump_distance",
      "landing_stability",
      "cornering_speed",
      "whoops_efficiency",
    ],
    movementPatterns: ["jump", "landing", "whoops", "berm"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "balance",
        color: "#f97316",
        label: "Bike Control",
      },
    ],
  },
  climbing: {
    name: "Sport Climbing",
    icon: <Mountain className="w-6 h-6" />,
    color: "orange",
    heatmap: tennisHeatmap,
    heatmapTitle: "Route Efficiency",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: ["grip_strength", "route_efficiency", "balance", "endurance"],
    movementPatterns: ["grip", "pull", "push", "reach"],
    arOverlayPoints: [
      { zone: "Arms", type: "grip", color: "#f97316", label: "Grip Force" },
    ],
  },
  skateboarding: {
    name: "Skateboarding",
    icon: <Activity className="w-6 h-6" />,
    color: "purple",
    heatmap: tennisHeatmap,
    heatmapTitle: "Trick Landing Zones",
    biomechanicalZones: ["Core", "Legs", "Feet"],
    keyMetrics: [
      "trick_difficulty",
      "landing_stability",
      "board_control",
      "amplitude",
    ],
    movementPatterns: ["ollie", "grind", "flip", "landing"],
    arOverlayPoints: [
      { zone: "Legs", type: "pop", color: "#8b5cf6", label: "Pop Power" },
    ],
  },
  breaking: {
    name: "Breaking/Breakdance",
    icon: <Activity className="w-6 h-6" />,
    color: "orange",
    heatmap: soccerHeatmap,
    heatmapTitle: "Floor Coverage & Freezes",
    biomechanicalZones: ["Head", "Arms", "Core", "Legs"],
    keyMetrics: [
      "power_move_rotation",
      "freeze_stability",
      "footwork_speed",
      "musicality",
    ],
    movementPatterns: ["toprock", "downrock", "power_move", "freeze"],
    arOverlayPoints: [
      { zone: "Core", type: "rotation", color: "#f97316", label: "Spin Speed" },
    ],
  },
};
