import { TrendingUp, Mountain } from "../icons";
import { soccerHeatmap } from "../constants";

export const enduranceSports = {
  triathlon: {
    name: "Triathlon",
    icon: <TrendingUp className="w-6 h-6" />,
    color: "blue",
    heatmap: soccerHeatmap,
    heatmapTitle: "Multi-Discipline Performance",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "transition_speed",
      "pacing",
      "endurance",
      "multi_discipline_efficiency",
    ],
    movementPatterns: ["swim", "bike", "run", "transition"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "endurance",
        color: "#3b82f6",
        label: "Core Stability",
      },
    ],
  },
  cross_country: {
    name: "Cross Country",
    icon: <Mountain className="w-6 h-6" />,
    color: "green",
    heatmap: soccerHeatmap,
    heatmapTitle: "Terrain Performance",
    biomechanicalZones: ["Core", "Legs", "Feet"],
    keyMetrics: ["hill_climbing", "terrain_adaptation", "pacing", "endurance"],
    movementPatterns: ["hill_climb", "descent", "flat_cruise"],
    arOverlayPoints: [
      {
        zone: "Legs",
        type: "terrain",
        color: "#10b981",
        label: "Terrain Power",
      },
    ],
  },
};
