import { Activity, Sparkles } from "../icons";
import { tennisHeatmap } from "../constants";

export const gymnasticsSports = {
  gymnastics: {
    name: "Gymnastics",
    icon: <Activity className="w-6 h-6" />,
    color: "purple",
    heatmap: tennisHeatmap,
    heatmapTitle: "Element Execution Map",
    biomechanicalZones: ["Head", "Shoulders", "Arms", "Core", "Hips", "Legs"],
    keyMetrics: [
      "rotation_speed",
      "landing_stability",
      "form_precision",
      "height",
      "amplitude",
    ],
    movementPatterns: ["tumbling", "vault", "bars", "beam", "floor"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "rotation",
        color: "#8b5cf6",
        label: "Angular Momentum",
      },
      {
        zone: "Legs",
        type: "landing_force",
        color: "#ef4444",
        label: "Impact Absorption",
      },
    ],
  },
  rhythmic_gymnastics: {
    name: "Rhythmic Gymnastics",
    icon: <Sparkles className="w-6 h-6" />,
    color: "pink",
    heatmap: tennisHeatmap,
    heatmapTitle: "Apparatus Handling",
    biomechanicalZones: ["Head", "Arms", "Core", "Legs"],
    keyMetrics: [
      "apparatus_control",
      "body_flexibility",
      "rhythm",
      "artistic_expression",
    ],
    movementPatterns: ["throw", "catch", "balance", "pivot", "leap"],
    arOverlayPoints: [
      {
        zone: "Arms",
        type: "apparatus",
        color: "#ec4899",
        label: "Apparatus Control",
      },
    ],
  },
  trampoline: {
    name: "Trampoline",
    icon: <Activity className="w-6 h-6" />,
    color: "yellow",
    heatmap: tennisHeatmap,
    heatmapTitle: "Air Time & Rotation",
    biomechanicalZones: ["Core", "Legs"],
    keyMetrics: [
      "height",
      "rotation_speed",
      "body_position",
      "landing_precision",
    ],
    movementPatterns: ["jump", "rotation", "landing"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "rotation",
        color: "#eab308",
        label: "Angular Momentum",
      },
    ],
  },
};
