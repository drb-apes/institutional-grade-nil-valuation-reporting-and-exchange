import { Music, Film, Camera, Activity, Users } from "../icons";
import { concertHeatmap, tennisHeatmap, soccerHeatmap } from "../constants";

export const entertainmentSports = {
  concert: {
    name: "Live Concerts",
    icon: <Music className="w-6 h-6" />,
    color: "pink",
    heatmap: concertHeatmap,
    heatmapTitle: "Venue Engagement Zones",
    biomechanicalZones: ["Head", "Core", "Arms", "Legs"],
    keyMetrics: [
      "vocal_stability",
      "breath_control",
      "stage_movement",
      "crowd_engagement",
      "energy_maintenance",
    ],
    movementPatterns: [
      "verse_delivery",
      "chorus_execution",
      "dance_sequence",
      "crowd_interaction",
    ],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "breath_support",
        color: "#ec4899",
        label: "Diaphragm Control",
      },
      {
        zone: "Legs",
        type: "stage_coverage",
        color: "#8b5cf6",
        label: "Stage Presence",
      },
    ],
  },
  acting: {
    name: "Acting/Theater",
    icon: <Film className="w-6 h-6" />,
    color: "purple",
    heatmap: concertHeatmap,
    heatmapTitle: "Scene Performance Map",
    biomechanicalZones: ["Head", "Arms", "Core"],
    keyMetrics: [
      "expression_fidelity",
      "vocal_projection",
      "movement_authenticity",
      "emotional_range",
    ],
    movementPatterns: ["blocking", "gesture", "expression_shift"],
    arOverlayPoints: [
      {
        zone: "Head",
        type: "expression",
        color: "#8b5cf6",
        label: "Facial Tracking",
      },
    ],
  },
  modeling: {
    name: "Modeling/Runway",
    icon: <Camera className="w-6 h-6" />,
    color: "pink",
    heatmap: tennisHeatmap,
    heatmapTitle: "Runway Coverage",
    biomechanicalZones: ["Core", "Hips", "Legs"],
    keyMetrics: [
      "posture_precision",
      "stride_consistency",
      "pose_quality",
      "camera_alignment",
    ],
    movementPatterns: ["walk", "turn", "pose", "transition"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "posture",
        color: "#ec4899",
        label: "Posture Alignment",
      },
    ],
  },
  dance: {
    name: "Dance/Choreography",
    icon: <Activity className="w-6 h-6" />,
    color: "purple",
    heatmap: soccerHeatmap,
    heatmapTitle: "Stage Coverage & Flow",
    biomechanicalZones: ["Head", "Shoulders", "Arms", "Core", "Hips", "Legs"],
    keyMetrics: [
      "synchronization",
      "fluidity",
      "power",
      "flexibility",
      "musicality",
    ],
    movementPatterns: ["leap", "turn", "extension", "formation_shift"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "balance",
        color: "#8b5cf6",
        label: "Center Balance",
      },
    ],
  },
  cheerleading: {
    name: "Cheerleading",
    icon: <Users className="w-6 h-6" />,
    color: "yellow",
    heatmap: tennisHeatmap,
    heatmapTitle: "Formation & Stunts",
    biomechanicalZones: ["Head", "Arms", "Core", "Legs"],
    keyMetrics: [
      "stunt_stability",
      "tumbling_quality",
      "synchronization",
      "energy",
    ],
    movementPatterns: [
      "formation",
      "stunt_build",
      "extension",
      "dismount",
      "tumbling",
    ],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "balance",
        color: "#eab308",
        label: "Stunt Balance",
      },
    ],
  },
};
