import { Waves, Wind } from "../icons";
import { tennisHeatmap, soccerHeatmap } from "../constants";

export const aquaticSports = {
  swimming: {
    name: "Swimming",
    icon: <Waves className="w-6 h-6" />,
    color: "blue",
    heatmap: tennisHeatmap,
    heatmapTitle: "Stroke Efficiency & Lap Analysis",
    biomechanicalZones: ["Shoulders", "Arms", "Core", "Hips", "Legs"],
    keyMetrics: [
      "stroke_rate",
      "stroke_length",
      "turn_efficiency",
      "underwater_kick",
      "pace_consistency",
    ],
    movementPatterns: ["pull", "kick", "turn", "streamline"],
    arOverlayPoints: [
      {
        zone: "Arms",
        type: "pull_power",
        color: "#3b82f6",
        label: "Propulsion",
      },
      { zone: "Core", type: "rotation", color: "#06b6d4", label: "Body Roll" },
    ],
  },
  diving: {
    name: "Diving",
    icon: <Waves className="w-6 h-6" />,
    color: "cyan",
    heatmap: tennisHeatmap,
    heatmapTitle: "Entry Point & Rotation",
    biomechanicalZones: ["Core", "Arms", "Legs"],
    keyMetrics: [
      "rotation_speed",
      "entry_angle",
      "splash_minimization",
      "air_position",
    ],
    movementPatterns: ["takeoff", "tuck", "rotation", "entry"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "spin_axis",
        color: "#06b6d4",
        label: "Rotation Axis",
      },
    ],
  },
  rowing: {
    name: "Rowing",
    icon: <Waves className="w-6 h-6" />,
    color: "indigo",
    heatmap: tennisHeatmap,
    heatmapTitle: "Stroke Power Distribution",
    biomechanicalZones: ["Shoulders", "Arms", "Core", "Hips", "Legs"],
    keyMetrics: [
      "stroke_power",
      "catch_efficiency",
      "stroke_rate",
      "synchronization",
    ],
    movementPatterns: ["catch", "drive", "finish", "recovery"],
    arOverlayPoints: [
      { zone: "Legs", type: "drive", color: "#6366f1", label: "Leg Drive" },
    ],
  },
  sailing: {
    name: "Sailing",
    icon: <Wind className="w-6 h-6" />,
    color: "blue",
    heatmap: soccerHeatmap,
    heatmapTitle: "Course Navigation",
    biomechanicalZones: ["Arms", "Core", "Legs"],
    keyMetrics: [
      "tacking_efficiency",
      "trim_precision",
      "balance",
      "course_optimization",
    ],
    movementPatterns: ["tack", "jibe", "trim", "hike"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "balance",
        color: "#3b82f6",
        label: "Boat Balance",
      },
    ],
  },
  surfing: {
    name: "Surfing",
    icon: <Waves className="w-6 h-6" />,
    color: "cyan",
    heatmap: tennisHeatmap,
    heatmapTitle: "Wave Riding Zones",
    biomechanicalZones: ["Core", "Legs", "Feet"],
    keyMetrics: [
      "wave_selection",
      "pop_up_speed",
      "balance",
      "maneuver_quality",
    ],
    movementPatterns: ["paddle", "pop_up", "bottom_turn", "cutback", "floater"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "balance",
        color: "#06b6d4",
        label: "Board Control",
      },
    ],
  },
  kayaking: {
    name: "Kayaking",
    icon: <Waves className="w-6 h-6" />,
    color: "blue",
    heatmap: tennisHeatmap,
    heatmapTitle: "Stroke Efficiency",
    biomechanicalZones: ["Shoulders", "Arms", "Core"],
    keyMetrics: ["stroke_power", "stroke_rate", "stability", "navigation"],
    movementPatterns: ["forward_stroke", "sweep", "brace", "roll"],
    arOverlayPoints: [
      {
        zone: "Core",
        type: "rotation",
        color: "#3b82f6",
        label: "Torso Rotation",
      },
    ],
  },
  synchronized_swimming: {
    name: "Synchronized Swimming",
    icon: <Waves className="w-6 h-6" />,
    color: "purple",
    heatmap: tennisHeatmap,
    heatmapTitle: "Formation Precision",
    biomechanicalZones: ["Head", "Arms", "Core", "Legs"],
    keyMetrics: [
      "synchronization",
      "artistic_expression",
      "technical_execution",
      "treading_efficiency",
    ],
    movementPatterns: ["sculling", "eggbeater", "boost", "descent"],
    arOverlayPoints: [
      {
        zone: "Legs",
        type: "treading",
        color: "#8b5cf6",
        label: "Eggbeater Power",
      },
    ],
  },
};
