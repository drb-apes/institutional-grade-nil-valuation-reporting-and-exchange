export function generateARMockData(sport) {
  return {
    bimScore: 82 + Math.random() * 15,
    joints: {
      leftShoulder: 88 + Math.random() * 10,
      rightShoulder: 85 + Math.random() * 10,
      leftKnee: 118 + Math.random() * 10,
      rightKnee: 122 + Math.random() * 10,
    },
    jointStatus: {
      leftShoulder: "optimal",
      rightShoulder: "acceptable",
      leftKnee: "optimal",
      rightKnee: "optimal",
    },
    peakForce: 1200 + Math.random() * 300,
    avgForce: 750 + Math.random() * 150,
    forceEfficiency: 82 + Math.random() * 12,
    rangeOfMotion: 88 + Math.random() * 10,
    symmetry: 85 + Math.random() * 10,
    fluidity: 78 + Math.random() * 15,
    fatigueLevel: 25 + Math.random() * 20,
    asymmetryRisk: 15 + Math.random() * 15,
    loadCapacity: 85 + Math.random() * 10,
  };
}

export function generateFlowMockData(sport) {
  const sportPhases = {
    // Combat Sports
    wrestling: [
      "Setup",
      "Penetration",
      "Control",
      "Finish",
      "Recovery",
      "Reset",
    ],
    boxing: [
      "Stance",
      "Jab Setup",
      "Power Shot",
      "Slip/Weave",
      "Counter",
      "Reset",
    ],
    judo: ["Grip", "Off-Balance", "Entry", "Throw", "Control", "Pin"],
    taekwondo: ["Stance", "Chamber", "Strike", "Retract", "Guard", "Reset"],
    karate: ["Ready", "Block", "Counter", "Strike", "Kiai", "Return"],
    mma: [
      "Engage",
      "Strike Exchange",
      "Clinch",
      "Takedown",
      "Ground Control",
      "Reset",
    ],
    fencing: ["En Garde", "Advance", "Attack", "Parry", "Riposte", "Retreat"],

    // Team Sports
    soccer: ["Receive", "Turn", "Accelerate", "Strike", "Follow", "Recover"],
    rugby: ["Set", "Engage", "Drive", "Break", "Support", "Ruck"],
    basketball: ["Stance", "Dribble", "Drive", "Jump", "Release", "Land"],
    volleyball: ["Ready", "Pass", "Set", "Approach", "Spike", "Land"],
    handball: ["Receive", "Dribble", "Jump", "Throw", "Land", "Defend"],
    field_hockey: ["Control", "Dribble", "Pass", "Receive", "Shoot", "Follow"],
    ice_hockey: ["Stride", "Control", "Pass", "Shoot", "Recover", "Position"],
    football: ["Snap", "Read", "Execute", "Contact", "Drive", "Reset"],
    lacrosse: ["Cradle", "Dodge", "Pass", "Shoot", "Follow", "Defend"],

    // Racket Sports
    tennis: ["Ready", "Split Step", "Load", "Swing", "Contact", "Follow"],
    pickleball: ["Ready", "Split", "Dink Setup", "Drive", "Reset", "Recover"],
    badminton: ["Ready", "Shuffle", "Jump", "Smash", "Land", "Return"],
    table_tennis: ["Stance", "Footwork", "Stroke", "Follow", "Reset", "Ready"],
    squash: ["Ready", "Move", "Stroke", "Follow", "Recover", "Position"],

    // Precision Sports
    baseball: ["Stance", "Load", "Stride", "Swing", "Contact", "Follow"],
    softball: ["Stance", "Load", "Swing", "Contact", "Follow", "Reset"],
    golf: ["Setup", "Backswing", "Transition", "Downswing", "Impact", "Follow"],
    archery: ["Stance", "Draw", "Anchor", "Aim", "Release", "Follow"],
    shooting: [
      "Position",
      "Sight",
      "Breath Control",
      "Squeeze",
      "Fire",
      "Reset",
    ],

    // Aquatic Sports
    swimming: ["Entry", "Catch", "Pull", "Push", "Recovery", "Glide"],
    diving: ["Approach", "Hurdle", "Takeoff", "Flight", "Entry", "Resurface"],
    water_polo: ["Tread", "Catch", "Position", "Shoot", "Follow", "Defend"],
    rowing: ["Catch", "Drive", "Finish", "Recovery", "Feather", "Prepare"],
    sailing: [
      "Tack Prepare",
      "Release",
      "Turn",
      "Sheet In",
      "Trim",
      "Stabilize",
    ],
    surfing: ["Paddle", "Pop-Up", "Stance", "Carve", "Ride", "Exit"],

    // Track & Field
    track: [
      "Start",
      "Acceleration",
      "Transition",
      "Max Velocity",
      "Maintain",
      "Finish",
    ],
    sprinting: [
      "Blocks",
      "Explosion",
      "Drive",
      "Transition",
      "Top Speed",
      "Finish",
    ],
    long_distance: ["Stride", "Rhythm", "Maintain", "Surge", "Kick", "Finish"],
    hurdles: ["Approach", "Takeoff", "Clearance", "Land", "Transition", "Next"],
    pole_vault: [
      "Approach",
      "Plant",
      "Swing",
      "Extension",
      "Clearance",
      "Land",
    ],
    long_jump: ["Approach", "Takeoff", "Flight", "Hitch", "Landing", "Settle"],
    high_jump: ["Approach", "Curve", "Plant", "Jump", "Clearance", "Land"],
    javelin: ["Approach", "Crossover", "Plant", "Pull", "Release", "Follow"],
    shot_put: [
      "Stance",
      "Glide",
      "Power Position",
      "Drive",
      "Release",
      "Follow",
    ],

    // Cycling & Wheeled
    cycling: [
      "Pedal Down",
      "Power Phase",
      "Recovery",
      "Cadence Peak",
      "Sustain",
      "Rest",
    ],
    bmx: ["Gate Start", "Pump", "Jump", "Manual", "Pedal", "Land"],
    mountain_bike: [
      "Pedal",
      "Obstacle",
      "Bunny Hop",
      "Land",
      "Corner",
      "Accelerate",
    ],

    // Winter Sports
    skiing: [
      "Pole Plant",
      "Edge Set",
      "Turn Init",
      "Apex",
      "Release",
      "Transition",
    ],
    snowboarding: ["Approach", "Edge", "Carve", "Jump", "Grab", "Land"],
    figure_skating: ["Entry", "Takeoff", "Rotation", "Landing", "Edge", "Exit"],
    speed_skating: [
      "Push",
      "Glide",
      "Crossover",
      "Stride",
      "Corner",
      "Straightaway",
    ],

    // Gymnastics
    gymnastics: [
      "Approach",
      "Takeoff",
      "Flight",
      "Rotation",
      "Spotting",
      "Landing",
    ],
    rhythmic_gymnastics: [
      "Throw",
      "Body Wave",
      "Catch",
      "Pivot",
      "Balance",
      "Finish",
    ],
    trampoline: ["Jump", "Ascent", "Peak", "Rotation", "Descent", "Landing"],

    // Strength Sports
    weightlifting: [
      "Setup",
      "First Pull",
      "Transition",
      "Second Pull",
      "Catch",
      "Recovery",
    ],
    powerlifting: ["Setup", "Descent", "Pause", "Drive", "Lockout", "Reset"],

    // Endurance
    triathlon: ["Swim", "T1", "Bike", "T2", "Run", "Finish"],
    marathon: ["Warm-Up", "Settle", "Rhythm", "Mile 20 Wall", "Kick", "Finish"],
    cross_country: [
      "Start",
      "Hill Climb",
      "Descent",
      "Flat Cruise",
      "Surge",
      "Finish",
    ],

    // Equestrian
    equestrian: [
      "Approach",
      "Takeoff",
      "Flight",
      "Landing",
      "Recovery",
      "Next Obstacle",
    ],

    // Entertainment
    concert: [
      "Intro",
      "Verse Build",
      "Hook Drop",
      "Peak Energy",
      "Sustain",
      "Outro",
    ],
    acting: [
      "Blocking",
      "Emotion Build",
      "Peak Moment",
      "Reaction",
      "Resolution",
      "Exit",
    ],
    modeling: ["Entry", "Pause", "Turn", "Walk", "Pose", "Exit"],
    dance: ["Prep", "Sequence A", "Transition", "Sequence B", "Peak", "Finale"],
    cheerleading: [
      "Formation",
      "Stunt Build",
      "Extension",
      "Dismount",
      "Tumbling",
      "Finish",
    ],

    // Motorsports
    racing: [
      "Grid Start",
      "Acceleration",
      "Corner Entry",
      "Apex",
      "Exit",
      "Straight",
    ],
    motocross: [
      "Gate Drop",
      "Whoops",
      "Jump",
      "Landing",
      "Berm",
      "Acceleration",
    ],

    // Other Sports
    cricket: [
      "Stance",
      "Backlift",
      "Downswing",
      "Contact",
      "Follow",
      "Recovery",
    ],
    climbing: ["Grip", "Pull", "Push", "Balance", "Reach", "Secure"],
    breaking: [
      "Top Rock",
      "Go Down",
      "Footwork",
      "Power Move",
      "Freeze",
      "Exit",
    ],
    curling: ["Stance", "Slide", "Release", "Sweeping", "Shot Path", "Result"],
    bocce: ["Stance", "Backswing", "Release", "Roll", "Target", "Result"],
  };

  const phases = (sportPhases[sport] || sportPhases.wrestling).map(
    (name, idx) => ({
      name,
      efficiency: 70 + Math.random() * 25,
      duration: 80 + Math.random() * 180,
    }),
  );

  const energyTransfer = Array.from({ length: 20 }, (_, idx) => ({
    value: 60 + Math.random() * 35,
    time: idx * 50,
  }));

  return { phases, energyTransfer };
}
