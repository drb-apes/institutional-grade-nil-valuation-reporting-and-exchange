import { Activity } from "lucide-react";
import { allSports } from "./sports/index.js";
import { CHART_TYPES } from "./chartTypes.js";

/**
 * Main export of all sport configurations
 * This file has been refactored to import from categorized sport files
 */
export const SPORT_CONFIGS = allSports;

// Export chart types
export { CHART_TYPES };

// Re-export original sportConfigs as well for backward compatibility
export const sportConfigs = SPORT_CONFIGS;
