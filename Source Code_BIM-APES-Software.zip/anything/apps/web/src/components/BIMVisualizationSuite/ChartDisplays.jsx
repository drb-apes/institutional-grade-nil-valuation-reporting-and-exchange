import { Target, Activity, TrendingUp, Zap } from "lucide-react";
import HeatmapChart from "@/components/AdvancedVisualizations/HeatmapChart";
import RadarChart from "@/components/AdvancedVisualizations/RadarChart";
import CandlestickChart from "@/components/AdvancedVisualizations/CandlestickChart";
import TrendlineChart from "@/components/AdvancedVisualizations/TrendlineChart";

export function HeatmapDisplay({ currentConfig }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-4">
        <Target className={`w-6 h-6 text-${currentConfig.color}-400`} />
        <h2 className="text-xl font-bold text-white">
          {currentConfig.heatmapTitle}
        </h2>
      </div>
      <HeatmapChart data={currentConfig.heatmap} width={500} height={400} />
      <p className="text-blue-300 text-sm mt-4">
        Intensity visualization showing performance distribution across spatial
        zones
      </p>
    </div>
  );
}

export function RadarDisplay({ athleteRadar }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-4">
        <Activity className="w-6 h-6 text-blue-400" />
        <h2 className="text-xl font-bold text-white">
          Multi-Dimensional Athlete Profile
        </h2>
      </div>
      <RadarChart data={athleteRadar} width={450} height={400} />
      <p className="text-blue-300 text-sm mt-4">
        Hexagonal profile showing strength across 6 key performance dimensions
      </p>
    </div>
  );
}

export function CandlestickDisplay({ nilCandlestick }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-4">
        <TrendingUp className="w-6 h-6 text-green-400" />
        <h2 className="text-xl font-bold text-white">
          NIL Valuation Volatility
        </h2>
      </div>
      <CandlestickChart
        data={nilCandlestick}
        title=""
        xLabel="Match/Event"
        yLabel="NIL Value ($)"
        showVolume={true}
        height={400}
      />
      <p className="text-blue-300 text-sm mt-4">
        Market-style candlesticks showing NIL value range and trending over 12
        events
      </p>
    </div>
  );
}

export function TrendlineDisplay({ performanceTrend }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-4">
        <Zap className="w-6 h-6 text-yellow-400" />
        <h2 className="text-xl font-bold text-white">
          Performance Progression
        </h2>
      </div>
      <TrendlineChart data={performanceTrend} width={500} height={400} />
      <p className="text-blue-300 text-sm mt-4">
        Time-series analysis with trend projection and confidence bands
      </p>
    </div>
  );
}
