export const wrestlingHeatmap = {
  data: [
    { xLabel: "Left", yLabel: "Head", value: 35, intensity: 60 },
    { xLabel: "Center", yLabel: "Head", value: 45, intensity: 75 },
    { xLabel: "Right", yLabel: "Head", value: 30, intensity: 55 },
    { xLabel: "Left", yLabel: "Shoulder", value: 65, intensity: 90 },
    { xLabel: "Center", yLabel: "Shoulder", value: 85, intensity: 100 },
    { xLabel: "Right", yLabel: "Shoulder", value: 60, intensity: 88 },
    { xLabel: "Left", yLabel: "Core", value: 75, intensity: 95 },
    { xLabel: "Center", yLabel: "Core", value: 95, intensity: 100 },
    { xLabel: "Right", yLabel: "Core", value: 70, intensity: 92 },
    { xLabel: "Left", yLabel: "Hips", value: 50, intensity: 78 },
    { xLabel: "Center", yLabel: "Hips", value: 70, intensity: 92 },
    { xLabel: "Right", yLabel: "Hips", value: 48, intensity: 75 },
    { xLabel: "Left", yLabel: "Legs", value: 30, intensity: 55 },
    { xLabel: "Center", yLabel: "Legs", value: 40, intensity: 65 },
    { xLabel: "Right", yLabel: "Legs", value: 28, intensity: 52 },
  ],
  colorScale: {
    gradient: ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"],
  },
};

export const tennisHeatmap = {
  data: [
    { xLabel: "Left", yLabel: "Baseline", value: 45, intensity: 75 },
    { xLabel: "Center", yLabel: "Baseline", value: 52, intensity: 85 },
    { xLabel: "Right", yLabel: "Baseline", value: 38, intensity: 65 },
    { xLabel: "Left", yLabel: "Mid", value: 28, intensity: 50 },
    { xLabel: "Center", yLabel: "Mid", value: 35, intensity: 60 },
    { xLabel: "Right", yLabel: "Mid", value: 30, intensity: 55 },
    { xLabel: "Left", yLabel: "Net", value: 18, intensity: 35 },
    { xLabel: "Center", yLabel: "Net", value: 22, intensity: 40 },
    { xLabel: "Right", yLabel: "Net", value: 20, intensity: 38 },
  ],
  colorScale: {
    gradient: ["#8b5cf6", "#a78bfa", "#ec4899", "#f472b6"],
  },
};

export const soccerHeatmap = {
  data: [
    { xLabel: "Left", yLabel: "Defense", value: 40, intensity: 60 },
    { xLabel: "Center", yLabel: "Defense", value: 55, intensity: 75 },
    { xLabel: "Right", yLabel: "Defense", value: 38, intensity: 58 },
    { xLabel: "Left", yLabel: "Midfield", value: 75, intensity: 90 },
    { xLabel: "Center", yLabel: "Midfield", value: 90, intensity: 100 },
    { xLabel: "Right", yLabel: "Midfield", value: 70, intensity: 88 },
    { xLabel: "Left", yLabel: "Attack", value: 50, intensity: 70 },
    { xLabel: "Center", yLabel: "Attack", value: 65, intensity: 82 },
    { xLabel: "Right", yLabel: "Attack", value: 48, intensity: 68 },
  ],
  colorScale: {
    gradient: ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"],
  },
};

export const concertHeatmap = {
  data: [
    { xLabel: "Left", yLabel: "Front", value: 95, intensity: 95 },
    { xLabel: "Center", yLabel: "Front", value: 100, intensity: 100 },
    { xLabel: "Right", yLabel: "Front", value: 92, intensity: 92 },
    { xLabel: "Left", yLabel: "Mid", value: 80, intensity: 80 },
    { xLabel: "Center", yLabel: "Mid", value: 85, intensity: 85 },
    { xLabel: "Right", yLabel: "Mid", value: 78, intensity: 78 },
    { xLabel: "Left", yLabel: "Back", value: 60, intensity: 60 },
    { xLabel: "Center", yLabel: "Back", value: 65, intensity: 65 },
    { xLabel: "Right", yLabel: "Back", value: 58, intensity: 58 },
  ],
  colorScale: {
    gradient: ["#3b82f6", "#8b5cf6", "#ec4899", "#f472b6"],
  },
};

export const athleteRadar = {
  axes: [
    { label: "Power", max: 100 },
    { label: "Speed", max: 100 },
    { label: "Endurance", max: 100 },
    { label: "Technique", max: 100 },
    { label: "Mental", max: 100 },
    { label: "Recovery", max: 100 },
  ],
  datasets: [
    {
      label: "Current Profile",
      data: [85, 78, 92, 88, 75, 82],
    },
  ],
};

export const nilRadar = {
  axes: [
    { label: "Performance", max: 100 },
    { label: "Social", max: 100 },
    { label: "Brand Fit", max: 100 },
    { label: "Engagement", max: 100 },
    { label: "Marketability", max: 100 },
    { label: "Consistency", max: 100 },
  ],
  datasets: [
    {
      label: "NIL Profile",
      data: [88, 75, 82, 90, 85, 78],
    },
  ],
};

export const generateNILCandlestick = () => {
  return Array.from({ length: 12 }).map((_, i) => {
    const baseValue = 50000 + i * 2000;
    const volatility = 4000;
    const open = baseValue + (Math.random() - 0.5) * volatility;
    const close = open + (Math.random() - 0.45) * volatility;
    const high = Math.max(open, close) + Math.random() * volatility * 0.5;
    const low = Math.min(open, close) - Math.random() * volatility * 0.3;

    return {
      label: `Match ${i + 1}`,
      open,
      high,
      low,
      close,
      volume: Math.floor(Math.random() * 5000) + 3000,
    };
  });
};

export const performanceTrend = {
  timeSeries: [
    { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 65, label: "Week 1" },
    { x: Date.now() - 25 * 24 * 60 * 60 * 1000, y: 68, label: "Week 2" },
    { x: Date.now() - 20 * 24 * 60 * 60 * 1000, y: 70, label: "Week 3" },
    { x: Date.now() - 15 * 24 * 60 * 60 * 1000, y: 72, label: "Week 4" },
    { x: Date.now() - 10 * 24 * 60 * 60 * 1000, y: 75, label: "Week 5" },
    { x: Date.now() - 5 * 24 * 60 * 60 * 1000, y: 78, label: "Week 6" },
    { x: Date.now(), y: 82, label: "Week 7" },
  ],
  trendline: [
    { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 66 },
    { x: Date.now(), y: 80 },
  ],
  upperBound: [
    { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 75 },
    { x: Date.now(), y: 90 },
  ],
  lowerBound: [
    { x: Date.now() - 30 * 24 * 60 * 60 * 1000, y: 57 },
    { x: Date.now(), y: 70 },
  ],
};
