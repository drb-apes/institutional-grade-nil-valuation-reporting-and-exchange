"use client";

import { useState, useEffect } from "react";
import { Maximize2, RotateCw, Zap } from "lucide-react";

export default function ARBiomechanicalOverlay({ sport, performanceData }) {
  const [rotation, setRotation] = useState(0);
  const [highlightedJoint, setHighlightedJoint] = useState(null);
  const [activePhase, setActivePhase] = useState(0);

  useEffect(() => {
    // Auto-rotate through phases
    const interval = setInterval(() => {
      setActivePhase(
        (prev) => (prev + 1) % performanceData.biomechanicalData.length,
      );
    }, 2000);
    return () => clearInterval(interval);
  }, [performanceData]);

  const currentPhaseData = performanceData.biomechanicalData[activePhase];

  // Human figure skeleton points (simplified SVG representation)
  const skeletonPoints = {
    head: { x: 200, y: 50 },
    neck: { x: 200, y: 90 },
    shoulder_left: { x: 150, y: 110 },
    shoulder_right: { x: 250, y: 110 },
    elbow_left: { x: 130, y: 180 },
    elbow_right: { x: 270, y: 180 },
    wrist_left: { x: 120, y: 250 },
    wrist_right: { x: 280, y: 250 },
    spine_mid: { x: 200, y: 180 },
    hip_center: { x: 200, y: 250 },
    hip_left: { x: 180, y: 260 },
    hip_right: { x: 220, y: 260 },
    knee_left: { x: 170, y: 340 },
    knee_right: { x: 230, y: 340 },
    ankle_left: { x: 165, y: 420 },
    ankle_right: { x: 235, y: 420 },
  };

  // Apply sport-specific pose adjustments
  const adjustedPoints = applyPoseAdjustment(
    skeletonPoints,
    sport,
    activePhase,
  );

  // Calculate joint stress based on angles
  const getJointStress = (jointName) => {
    const angle = performanceData.jointAngles[jointName.toLowerCase()] || 90;
    if (angle < 30 || angle > 160) return "high";
    if (angle < 45 || angle > 135) return "medium";
    return "low";
  };

  return (
    <div className="relative">
      {/* Control Panel */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="bg-slate-800 rounded-lg px-3 py-1.5">
            <span className="text-white text-sm font-medium">
              Phase: {currentPhaseData.phase}
            </span>
          </div>
          <div className="bg-slate-800 rounded-lg px-3 py-1.5">
            <span className="text-green-400 text-sm font-mono">
              {currentPhaseData.power.toFixed(0)}W
            </span>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setRotation((r) => r - 15)}
            className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors"
            title="Rotate Left"
          >
            <RotateCw className="w-4 h-4 text-white transform scale-x-[-1]" />
          </button>
          <button
            onClick={() => setRotation((r) => r + 15)}
            className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors"
            title="Rotate Right"
          >
            <RotateCw className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      {/* AR Overlay Canvas */}
      <div className="bg-slate-900 rounded-xl p-8 border border-slate-700 relative overflow-hidden min-h-[500px]">
        {/* Grid Background */}
        <div className="absolute inset-0 opacity-20">
          <svg width="100%" height="100%">
            <defs>
              <pattern
                id="grid"
                width="40"
                height="40"
                patternUnits="userSpaceOnUse"
              >
                <path
                  d="M 40 0 L 0 0 0 40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="0.5"
                  className="text-indigo-400"
                />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Biomechanical Skeleton */}
        <svg
          viewBox="0 0 400 500"
          className="w-full h-full"
          style={{
            transform: `rotate(${rotation}deg)`,
            transition: "transform 0.3s ease",
          }}
        >
          {/* Torso */}
          <line
            x1={adjustedPoints.neck.x}
            y1={adjustedPoints.neck.y}
            x2={adjustedPoints.hip_center.x}
            y2={adjustedPoints.hip_center.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />

          {/* Left Arm */}
          <line
            x1={adjustedPoints.neck.x}
            y1={adjustedPoints.neck.y}
            x2={adjustedPoints.shoulder_left.x}
            y2={adjustedPoints.shoulder_left.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />
          <line
            x1={adjustedPoints.shoulder_left.x}
            y1={adjustedPoints.shoulder_left.y}
            x2={adjustedPoints.elbow_left.x}
            y2={adjustedPoints.elbow_left.y}
            stroke="#60a5fa"
            strokeWidth="3"
          />
          <line
            x1={adjustedPoints.elbow_left.x}
            y1={adjustedPoints.elbow_left.y}
            x2={adjustedPoints.wrist_left.x}
            y2={adjustedPoints.wrist_left.y}
            stroke="#60a5fa"
            strokeWidth="3"
          />

          {/* Right Arm */}
          <line
            x1={adjustedPoints.neck.x}
            y1={adjustedPoints.neck.y}
            x2={adjustedPoints.shoulder_right.x}
            y2={adjustedPoints.shoulder_right.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />
          <line
            x1={adjustedPoints.shoulder_right.x}
            y1={adjustedPoints.shoulder_right.y}
            x2={adjustedPoints.elbow_right.x}
            y2={adjustedPoints.elbow_right.y}
            stroke="#60a5fa"
            strokeWidth="3"
          />
          <line
            x1={adjustedPoints.elbow_right.x}
            y1={adjustedPoints.elbow_right.y}
            x2={adjustedPoints.wrist_right.x}
            y2={adjustedPoints.wrist_right.y}
            stroke="#60a5fa"
            strokeWidth="3"
          />

          {/* Left Leg */}
          <line
            x1={adjustedPoints.hip_left.x}
            y1={adjustedPoints.hip_left.y}
            x2={adjustedPoints.knee_left.x}
            y2={adjustedPoints.knee_left.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />
          <line
            x1={adjustedPoints.knee_left.x}
            y1={adjustedPoints.knee_left.y}
            x2={adjustedPoints.ankle_left.x}
            y2={adjustedPoints.ankle_left.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />

          {/* Right Leg */}
          <line
            x1={adjustedPoints.hip_right.x}
            y1={adjustedPoints.hip_right.y}
            x2={adjustedPoints.knee_right.x}
            y2={adjustedPoints.knee_right.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />
          <line
            x1={adjustedPoints.knee_right.x}
            y1={adjustedPoints.knee_right.y}
            x2={adjustedPoints.ankle_right.x}
            y2={adjustedPoints.ankle_right.y}
            stroke="#60a5fa"
            strokeWidth="4"
          />

          {/* Joints with stress indicators */}
          {Object.entries(adjustedPoints).map(([jointName, point]) => {
            const stress = getJointStress(jointName);
            const colors = {
              low: "#10b981",
              medium: "#f59e0b",
              high: "#ef4444",
            };
            const isHighlighted = highlightedJoint === jointName;

            return (
              <g key={jointName}>
                <circle
                  cx={point.x}
                  cy={point.y}
                  r={isHighlighted ? 10 : 6}
                  fill={colors[stress]}
                  stroke="#fff"
                  strokeWidth="2"
                  className="cursor-pointer transition-all"
                  onMouseEnter={() => setHighlightedJoint(jointName)}
                  onMouseLeave={() => setHighlightedJoint(null)}
                />
                {stress === "high" && (
                  <circle
                    cx={point.x}
                    cy={point.y}
                    r="12"
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="2"
                    opacity="0.5"
                  >
                    <animate
                      attributeName="r"
                      from="12"
                      to="18"
                      dur="1s"
                      repeatCount="indefinite"
                    />
                    <animate
                      attributeName="opacity"
                      from="0.5"
                      to="0"
                      dur="1s"
                      repeatCount="indefinite"
                    />
                  </circle>
                )}
              </g>
            );
          })}

          {/* Head */}
          <circle
            cx={adjustedPoints.head.x}
            cy={adjustedPoints.head.y}
            r="25"
            fill="#60a5fa"
            stroke="#fff"
            strokeWidth="2"
          />

          {/* Force Vectors */}
          {currentPhaseData.force > 500 && (
            <>
              <line
                x1={adjustedPoints.wrist_right.x}
                y1={adjustedPoints.wrist_right.y}
                x2={adjustedPoints.wrist_right.x + 40}
                y2={adjustedPoints.wrist_right.y - 40}
                stroke="#fbbf24"
                strokeWidth="3"
                markerEnd="url(#arrowhead)"
              />
              <text
                x={adjustedPoints.wrist_right.x + 45}
                y={adjustedPoints.wrist_right.y - 45}
                fill="#fbbf24"
                fontSize="12"
                fontWeight="bold"
              >
                {currentPhaseData.force.toFixed(0)}N
              </text>
            </>
          )}

          {/* Arrow marker definition */}
          <defs>
            <marker
              id="arrowhead"
              markerWidth="10"
              markerHeight="10"
              refX="9"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 10 3, 0 6" fill="#fbbf24" />
            </marker>
          </defs>
        </svg>

        {/* Power Indicator */}
        <div className="absolute top-4 right-4 bg-slate-800/90 backdrop-blur-sm rounded-lg p-4 border border-indigo-500/30">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span className="text-white text-sm font-semibold">
              Power Output
            </span>
          </div>
          <div className="text-3xl font-bold text-yellow-400">
            {currentPhaseData.power.toFixed(0)}
          </div>
          <div className="text-xs text-gray-400">Watts</div>
          <div className="mt-2 w-32 bg-slate-700 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-yellow-400 to-orange-500 h-2 rounded-full transition-all duration-300"
              style={{
                width: `${Math.min(100, (currentPhaseData.power / 1000) * 100)}%`,
              }}
            />
          </div>
        </div>

        {/* Joint Info Tooltip */}
        {highlightedJoint && (
          <div className="absolute bottom-4 left-4 bg-slate-800/90 backdrop-blur-sm rounded-lg p-3 border border-blue-500/30">
            <p className="text-white font-semibold capitalize">
              {highlightedJoint.replace("_", " ")}
            </p>
            <p className="text-sm text-gray-300">
              Angle:{" "}
              {performanceData.jointAngles[highlightedJoint.split("_")[0]] ||
                "N/A"}
              °
            </p>
            <p className="text-sm text-gray-300">
              Stress:{" "}
              <span
                className={`font-semibold ${getJointStress(highlightedJoint) === "high" ? "text-red-400" : getJointStress(highlightedJoint) === "medium" ? "text-yellow-400" : "text-green-400"}`}
              >
                {getJointStress(highlightedJoint)}
              </span>
            </p>
          </div>
        )}
      </div>

      {/* Phase Progress */}
      <div className="mt-4 flex gap-2">
        {performanceData.biomechanicalData.map((phase, idx) => (
          <button
            key={idx}
            onClick={() => setActivePhase(idx)}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              idx === activePhase
                ? "bg-indigo-600 text-white"
                : "bg-slate-800 text-gray-400 hover:bg-slate-700"
            }`}
          >
            {phase.phase}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div className="mt-4 flex gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-500" />
          <span className="text-gray-300">Low Stress</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-yellow-500" />
          <span className="text-gray-300">Medium Stress</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500" />
          <span className="text-gray-300">High Stress</span>
        </div>
      </div>
    </div>
  );
}

// Sport-specific pose adjustments
function applyPoseAdjustment(points, sport, phaseIndex) {
  const adjusted = { ...points };

  // Apply different poses based on sport and phase
  if (sport === "wrestling" && phaseIndex === 1) {
    // Penetration step - lower stance
    adjusted.hip_center.y += 20;
    adjusted.knee_left.y += 15;
    adjusted.knee_right.y += 15;
  } else if (sport === "boxing" && phaseIndex === 2) {
    // Cross punch - extended arm
    adjusted.elbow_right.x += 30;
    adjusted.wrist_right.x += 60;
    adjusted.wrist_right.y -= 20;
  } else if (sport === "basketball" && phaseIndex === 2) {
    // Flight phase - arms up
    adjusted.shoulder_left.y -= 20;
    adjusted.shoulder_right.y -= 20;
    adjusted.elbow_left.y -= 40;
    adjusted.elbow_right.y -= 40;
    adjusted.wrist_left.y -= 60;
    adjusted.wrist_right.y -= 60;
  } else if (sport === "tennis" && phaseIndex === 3) {
    // Contact - extended reach
    adjusted.shoulder_right.x += 20;
    adjusted.elbow_right.x += 40;
    adjusted.wrist_right.x += 70;
    adjusted.wrist_right.y -= 30;
  }

  return adjusted;
}
