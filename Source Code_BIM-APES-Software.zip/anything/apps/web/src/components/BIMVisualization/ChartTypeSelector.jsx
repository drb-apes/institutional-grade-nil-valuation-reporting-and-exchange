"use client";

export default function ChartTypeSelector({
  chartTypes,
  selectedType,
  onSelectType,
}) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-4">Visualization Type</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {chartTypes.map((chartType) => {
          const Icon = chartType.icon;
          const isSelected = selectedType === chartType.id;

          return (
            <button
              key={chartType.id}
              onClick={() => onSelectType(chartType.id)}
              className={`flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all ${
                isSelected
                  ? "bg-indigo-600 border-indigo-400 shadow-lg shadow-indigo-500/50"
                  : "bg-slate-800 border-slate-600 hover:border-slate-500 hover:bg-slate-700"
              }`}
            >
              <Icon
                className={`w-8 h-8 ${isSelected ? "text-white" : "text-indigo-400"}`}
              />
              <span
                className={`font-semibold ${isSelected ? "text-white" : "text-gray-300"}`}
              >
                {chartType.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
