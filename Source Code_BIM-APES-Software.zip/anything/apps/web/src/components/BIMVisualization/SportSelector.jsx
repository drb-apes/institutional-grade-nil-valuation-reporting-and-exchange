"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

export default function SportSelector({
  sportCategories,
  selectedSport,
  onSelectSport,
}) {
  const [expandedCategory, setExpandedCategory] = useState("Combat Sports");

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-4">Select Sport</h3>
      <div className="space-y-2">
        {sportCategories.map((category) => {
          const isExpanded = expandedCategory === category.category;

          return (
            <div
              key={category.category}
              className="bg-slate-800/50 rounded-lg overflow-hidden border border-slate-700"
            >
              <button
                onClick={() =>
                  setExpandedCategory(isExpanded ? null : category.category)
                }
                className="w-full flex items-center justify-between p-3 hover:bg-slate-700/50 transition-colors"
              >
                <span className="text-white font-semibold">
                  {category.category}
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">
                    {category.sports.length} sports
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-2 p-3 bg-slate-900/30">
                  {category.sports.map((sport) => (
                    <button
                      key={sport}
                      onClick={() => onSelectSport(sport)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        selectedSport === sport
                          ? "bg-indigo-600 text-white shadow-lg scale-105"
                          : "bg-slate-700 text-gray-300 hover:bg-slate-600"
                      }`}
                    >
                      {sport.replace("_", " ")}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
