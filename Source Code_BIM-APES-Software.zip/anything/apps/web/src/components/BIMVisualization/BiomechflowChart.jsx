"use client";

import { useState } from "react";
import { TrendingUp, Activity, Zap, Gauge } from "lucide-react";

export default function BiomechflowChart({ sport, performanceData }) {
  const [selectedMetric, setSelectedMetric] = useState("power");
  const [viewMode, setViewMode] = useState("stacked"); // 'stacked' or 'overlay'

  const metrics = [
    { id: "power", name: "Power", unit: "W", color: "#fbbf24", icon: Zap },
    { id: "force", name: "Force", unit: "N", color: "#ef4444", icon: Activity },
    {
      id: "velocity",
      name: "Velocity",
      unit: "m/s",
      color: "#10b981",
      icon: TrendingUp,
    },
    {
      id: "efficiency",
      name: "Efficiency",
      unit: "%",
      color: "#3b82f6",
      icon: Gauge,
    },
  ];

  const maxValues = {
    power: Math.max(...performanceData.biomechanicalData.map((d) => d.power)),
    force: Math.max(...performanceData.biomechanicalData.map((d) => d.force)),
    velocity: Math.max(
      ...performanceData.biomechanicalData.map((d) => d.velocity),
    ),
    efficiency: 100,
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-wrap gap-3">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <button
              key={metric.id}
              onClick={() => setSelectedMetric(metric.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                selectedMetric === metric.id
                  ? "bg-slate-700 text-white border-2"
                  : "bg-slate-800 text-gray-400 hover:bg-slate-700 border-2 border-transparent"
              }`}
              style={
                selectedMetric === metric.id
                  ? { borderColor: metric.color }
                  : {}
              }
            >
              <Icon className="w-4 h-4" style={{ color: metric.color }} />
              <span>{metric.name}</span>
            </button>
          );
        })}
      </div>

      {/* View Mode Toggle */}
      <div className="flex gap-2">
        <button
          onClick={() => setViewMode("stacked")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            viewMode === "stacked"
              ? "bg-indigo-600 text-white"
              : "bg-slate-800 text-gray-400 hover:bg-slate-700"
          }`}
        >
          Stacked View
        </button>
        <button
          onClick={() => setViewMode("overlay")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            viewMode === "overlay"
              ? "bg-indigo-600 text-white"
              : "bg-slate-800 text-gray-400 hover:bg-slate-700"
          }`}
        >
          Overlay View
        </button>
      </div>

      {/* Biomechflow Chart */}
      {viewMode === "stacked" ? (
        <div className="space-y-4">
          {metrics.map((metric) => (
            <ChartRow
              key={metric.id}
              metric={metric}
              data={performanceData.biomechanicalData}
              maxValue={maxValues[metric.id]}
              isActive={selectedMetric === metric.id}
            />
          ))}
        </div>
      ) : (
        <OverlayChart
          metrics={metrics}
          data={performanceData.biomechanicalData}
          maxValues={maxValues}
          selectedMetric={selectedMetric}
        />
      )}

      {/* Phase Annotations */}
      <div className="bg-slate-800 rounded-lg p-4">
        <h4 className="text-white font-semibold mb-3">Phase Breakdown</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {performanceData.biomechanicalData.map((phase, idx) => {
            const metric = metrics.find((m) => m.id === selectedMetric);
            const value = phase[selectedMetric];
            const normalizedValue = (value / maxValues[selectedMetric]) * 100;

            return (
              <div
                key={idx}
                className="bg-slate-900 rounded-lg p-3 border border-slate-700"
              >
                <p className="text-gray-400 text-xs mb-1">{phase.phase}</p>
                <p
                  className="text-white font-bold text-lg"
                  style={{ color: metric.color }}
                >
                  {value.toFixed(1)}{" "}
                  <span className="text-sm font-normal text-gray-400">
                    {metric.unit}
                  </span>
                </p>
                <div className="mt-2 w-full bg-slate-700 rounded-full h-1.5">
                  <div
                    className="h-1.5 rounded-full transition-all duration-300"
                    style={{
                      width: `${normalizedValue}%`,
                      backgroundColor: metric.color,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {metrics.map((metric) => {
          const values = performanceData.biomechanicalData.map(
            (d) => d[metric.id],
          );
          const avg = values.reduce((sum, v) => sum + v, 0) / values.length;
          const max = Math.max(...values);
          const min = Math.min(...values);

          return (
            <div
              key={metric.id}
              className="bg-slate-800 rounded-lg p-4 border border-slate-700"
            >
              <div className="flex items-center gap-2 mb-2">
                {
                  <metric.icon
                    className="w-4 h-4"
                    style={{ color: metric.color }}
                  />
                }
                <span className="text-gray-400 text-sm">{metric.name}</span>
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-500">Avg:</span>
                  <span className="text-white font-mono">
                    {avg.toFixed(1)} {metric.unit}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Max:</span>
                  <span className="text-green-400 font-mono">
                    {max.toFixed(1)} {metric.unit}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Min:</span>
                  <span className="text-red-400 font-mono">
                    {min.toFixed(1)} {metric.unit}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ChartRow({ metric, data, maxValue, isActive }) {
  return (
    <div
      className={`bg-slate-800 rounded-lg p-4 border transition-all ${isActive ? "border-2" : "border"}`}
      style={
        isActive
          ? { borderColor: metric.color }
          : { borderColor: "rgb(51, 65, 85)" }
      }
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {<metric.icon className="w-4 h-4" style={{ color: metric.color }} />}
          <span className="text-white font-semibold">{metric.name}</span>
        </div>
        <span className="text-gray-400 text-sm">{metric.unit}</span>
      </div>

      <div className="relative h-20">
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 1000 100"
          preserveAspectRatio="none"
        >
          {/* Grid lines */}
          {[0, 25, 50, 75, 100].map((y) => (
            <line
              key={y}
              x1="0"
              y1={y}
              x2="1000"
              y2={y}
              stroke="rgb(51, 65, 85)"
              strokeWidth="0.5"
              opacity="0.5"
            />
          ))}

          {/* Data line */}
          <polyline
            points={data
              .map((d, idx) => {
                const x = (idx / (data.length - 1)) * 1000;
                const y = 100 - (d[metric.id] / maxValue) * 100;
                return `${x},${y}`;
              })
              .join(" ")}
            fill="none"
            stroke={metric.color}
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Area fill */}
          <polygon
            points={`0,100 ${data
              .map((d, idx) => {
                const x = (idx / (data.length - 1)) * 1000;
                const y = 100 - (d[metric.id] / maxValue) * 100;
                return `${x},${y}`;
              })
              .join(" ")} 1000,100`}
            fill={metric.color}
            opacity="0.2"
          />

          {/* Data points */}
          {data.map((d, idx) => {
            const x = (idx / (data.length - 1)) * 1000;
            const y = 100 - (d[metric.id] / maxValue) * 100;
            return (
              <circle
                key={idx}
                cx={x}
                cy={y}
                r="4"
                fill={metric.color}
                stroke="#fff"
                strokeWidth="2"
              />
            );
          })}
        </svg>

        {/* Phase labels */}
        <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-gray-500 mt-1">
          {data.map((d, idx) => (
            <span
              key={idx}
              className="text-center"
              style={{ width: `${100 / data.length}%` }}
            >
              {d.phase.slice(0, 3)}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function OverlayChart({ metrics, data, maxValues, selectedMetric }) {
  return (
    <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
      <div className="relative h-80">
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 1000 300"
          preserveAspectRatio="none"
        >
          {/* Grid */}
          {[0, 25, 50, 75, 100].map((y) => (
            <line
              key={y}
              x1="0"
              y1={(y / 100) * 300}
              x2="1000"
              y2={(y / 100) * 300}
              stroke="rgb(51, 65, 85)"
              strokeWidth="1"
              opacity="0.5"
            />
          ))}

          {/* All metrics */}
          {metrics.map((metric) => {
            const isSelected = metric.id === selectedMetric;
            const opacity = isSelected ? 1 : 0.3;

            return (
              <g key={metric.id}>
                {/* Line */}
                <polyline
                  points={data
                    .map((d, idx) => {
                      const x = (idx / (data.length - 1)) * 1000;
                      const y =
                        300 - (d[metric.id] / maxValues[metric.id]) * 300;
                      return `${x},${y}`;
                    })
                    .join(" ")}
                  fill="none"
                  stroke={metric.color}
                  strokeWidth={isSelected ? "4" : "2"}
                  opacity={opacity}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Points */}
                {isSelected &&
                  data.map((d, idx) => {
                    const x = (idx / (data.length - 1)) * 1000;
                    const y = 300 - (d[metric.id] / maxValues[metric.id]) * 300;
                    return (
                      <circle
                        key={idx}
                        cx={x}
                        cy={y}
                        r="5"
                        fill={metric.color}
                        stroke="#fff"
                        strokeWidth="2"
                      />
                    );
                  })}
              </g>
            );
          })}
        </svg>

        {/* Phase labels */}
        <div className="absolute bottom-0 left-0 right-0 flex justify-between text-sm text-gray-400 mt-2">
          {data.map((d, idx) => (
            <span
              key={idx}
              className="text-center"
              style={{ width: `${100 / data.length}%` }}
            >
              {d.phase}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
