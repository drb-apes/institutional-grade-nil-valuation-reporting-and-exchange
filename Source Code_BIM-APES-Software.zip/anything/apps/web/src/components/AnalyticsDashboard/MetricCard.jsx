export function MetricCard({ title, value, trend, icon: Icon }) {
  return (
    <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-semibold text-gray-600 text-sm">{title}</h4>
        {Icon && <Icon className="w-4 h-4 text-[#B8860B]" />}
      </div>
      <p className="text-xl font-bold text-[#1D2B3D]">{value}</p>
      {trend && (
        <p
          className={`text-xs font-medium capitalize mt-1 ${
            trend === "accelerating" || trend === "improving"
              ? "text-[#B8860B]"
              : trend === "decelerating" || trend === "declining"
                ? "text-red-600"
                : "text-gray-600"
          }`}
        >
          {trend}
        </p>
      )}
    </div>
  );
}
