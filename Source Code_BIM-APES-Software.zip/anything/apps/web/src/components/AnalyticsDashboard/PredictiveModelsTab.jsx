import { LineChart } from "lucide-react";
import { ModelCard } from "@/components/AnalyticsDashboard/ModelCard";

export function PredictiveModelsTab({ predictions }) {
  if (!predictions?.predictions) {
    return (
      <div className="text-center py-12 text-gray-600">
        <LineChart className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>No predictive models available.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Model Overview */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
          <LineChart className="w-6 h-6 text-[#B8860B]" />
          <span>Predictive Model Results</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
            <h4 className="font-semibold text-[#1D2B3D] mb-2">
              Data Points Used
            </h4>
            <p className="text-2xl font-bold text-[#B8860B]">
              {predictions.data_points_used}
            </p>
          </div>
          <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
            <h4 className="font-semibold text-[#1D2B3D] mb-2">
              Model Confidence
            </h4>
            <p className="text-2xl font-bold text-[#B8860B]">
              {(
                (predictions.prediction_confidence?.overall_confidence || 0) *
                100
              ).toFixed(0)}
              %
            </p>
          </div>
          <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
            <h4 className="font-semibold text-[#1D2B3D] mb-2">Models Active</h4>
            <p className="text-2xl font-bold text-[#B8860B]">
              {Object.keys(predictions.predictions).length}
            </p>
          </div>
          <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
            <h4 className="font-semibold text-[#1D2B3D] mb-2">Status</h4>
            <p className="text-lg font-semibold text-[#B8860B]">
              {predictions.status === "complete" ? "Complete" : "Processing"}
            </p>
          </div>
        </div>
      </div>

      {/* Individual Models */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {Object.entries(predictions.predictions).map(
          ([modelName, modelData]) => (
            <ModelCard key={modelName} name={modelName} data={modelData} />
          ),
        )}
      </div>
    </div>
  );
}
