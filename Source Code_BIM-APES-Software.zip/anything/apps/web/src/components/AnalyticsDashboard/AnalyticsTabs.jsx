import { BarChart3, Calculator, LineChart, Award, Shield } from "lucide-react";

const TABS = [
  { id: "overview", label: "Overview", icon: BarChart3 },
  { id: "metrics", label: "Advanced Metrics", icon: Calculator },
  { id: "predictions", label: "Predictive Models", icon: LineChart },
  { id: "tiers", label: "Tier Analysis", icon: Award },
  { id: "risk", label: "Risk Assessment", icon: Shield },
];

export function AnalyticsTabs({ activeTab, setActiveTab }) {
  return (
    <div className="mb-8 border-b-2 border-[#C8A882]">
      <nav className="flex space-x-8">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 py-4 px-2 border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "border-[#C8A882] text-[#C8A882]"
                  : "border-transparent text-gray-600 hover:text-[#1B3A57]"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
