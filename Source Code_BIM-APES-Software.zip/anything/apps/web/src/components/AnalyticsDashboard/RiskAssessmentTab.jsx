import { Shield } from "lucide-react";

export function RiskAssessmentTab({ analytics }) {
  return (
    <div className="text-center py-12 text-gray-600">
      <Shield className="w-16 h-16 mx-auto mb-4 opacity-50" />
      <p className="text-lg mb-2">Risk Assessment Module</p>
      <p className="text-sm">
        Advanced risk metrics and portfolio analysis coming soon.
      </p>
    </div>
  );
}
