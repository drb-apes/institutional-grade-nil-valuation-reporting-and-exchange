import { TrendingUp, Target, Award, LineChart, BarChart3 } from "lucide-react";

export function OverviewTab({ analytics, predictions }) {
  if (!analytics) {
    return (
      <div className="text-center py-12 text-gray-600">
        <BarChart3 className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>
          No analytics data available. Perform motion scans to generate
          insights.
        </p>
      </div>
    );
  }

  const { advanced_metrics, tier_movement_analysis } = analytics;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
      {/* Performance Velocity */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#1D2B3D]">
            Performance Velocity
          </h3>
          <TrendingUp className="w-6 h-6 text-[#B8860B]" />
        </div>

        {advanced_metrics?.performance_velocity && (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Trend:</span>
              <span
                className={`font-medium capitalize ${
                  advanced_metrics.performance_velocity.trend === "accelerating"
                    ? "text-[#B8860B]"
                    : advanced_metrics.performance_velocity.trend ===
                        "decelerating"
                      ? "text-red-600"
                      : "text-gray-600"
                }`}
              >
                {advanced_metrics.performance_velocity.trend}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Velocity:</span>
              <span className="text-[#1D2B3D] font-mono">
                {advanced_metrics.performance_velocity.average_velocity?.toFixed(
                  4,
                )}{" "}
                pts/day
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Acceleration:</span>
              <span className="text-[#1D2B3D] font-mono">
                {advanced_metrics.performance_velocity.acceleration?.toFixed(4)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Consistency Analysis */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#1D2B3D]">
            Consistency Score
          </h3>
          <Target className="w-6 h-6 text-blue-400" />
        </div>

        {advanced_metrics?.consistency_analysis && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Index:</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 h-2 bg-slate-600 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-400 transition-all duration-500"
                    style={{
                      width: `${(advanced_metrics.consistency_analysis.consistency_index || 0) * 100}%`,
                    }}
                  ></div>
                </div>
                <span className="text-white font-mono text-sm">
                  {(
                    (advanced_metrics.consistency_analysis.consistency_index ||
                      0) * 100
                  ).toFixed(1)}
                  %
                </span>
              </div>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Stability:</span>
              <span className="text-white font-mono">
                {(
                  (advanced_metrics.consistency_analysis.stability_score || 0) *
                  100
                ).toFixed(1)}
                %
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Variation:</span>
              <span className="text-white font-mono">
                {(
                  (advanced_metrics.consistency_analysis
                    .coefficient_of_variation || 0) * 100
                ).toFixed(1)}
                %
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Tier Status */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#1D2B3D]">Tier Status</h3>
          <Award className="w-6 h-6 text-purple-400" />
        </div>

        {tier_movement_analysis?.current_tier_analysis && (
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Current Tier:</span>
              <span className="text-white font-bold text-xl">
                {tier_movement_analysis.current_tier_analysis.tier}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <span
                className={`font-medium capitalize text-sm px-2 py-1 rounded-full ${
                  tier_movement_analysis.current_tier_analysis
                    .performance_vs_tier === "ready_for_advancement"
                    ? "bg-green-500/20 text-green-400"
                    : tier_movement_analysis.current_tier_analysis
                          .performance_vs_tier === "at_risk_of_demotion"
                      ? "bg-red-500/20 text-red-400"
                      : "bg-blue-500/20 text-blue-400"
                }`}
              >
                {tier_movement_analysis.current_tier_analysis.performance_vs_tier?.replace(
                  /_/g,
                  " ",
                )}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Advancement:</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 h-2 bg-slate-600 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-400 transition-all duration-500"
                    style={{
                      width: `${(tier_movement_analysis.current_tier_analysis.advancement_readiness || 0) * 100}%`,
                    }}
                  ></div>
                </div>
                <span className="text-white font-mono text-sm">
                  {(
                    (tier_movement_analysis.current_tier_analysis
                      .advancement_readiness || 0) * 100
                  ).toFixed(0)}
                  %
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Prediction Summary */}
      {predictions?.predictions?.ensemble && (
        <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#1D2B3D]">
              30-Day Forecast
            </h3>
            <LineChart className="w-6 h-6 text-cyan-400" />
          </div>

          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Predicted Score:</span>
              <span className="text-white font-mono text-lg">
                {predictions.predictions.ensemble.predictions?.[29]?.predicted_score?.toFixed(
                  2,
                ) || "N/A"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Confidence:</span>
              <span className="text-cyan-400 font-medium">
                {(
                  (predictions.prediction_confidence?.overall_confidence || 0) *
                  100
                ).toFixed(0)}
                %
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Model Type:</span>
              <span className="text-white font-medium">Ensemble</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
