import { Award, TrendingUp, Target, Shield, ArrowUp } from "lucide-react";
import { MetricCard } from "@/components/AnalyticsDashboard/MetricCard";

export function TierAnalysisTab({ analytics }) {
  if (!analytics?.tier_movement_analysis) {
    return (
      <div className="text-center py-12 text-gray-600">
        <Award className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>No tier analysis available.</p>
      </div>
    );
  }

  const tierAnalysis = analytics.tier_movement_analysis;

  return (
    <div className="space-y-8">
      {/* Current Tier Analysis */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
          <Award className="w-6 h-6 text-purple-400" />
          <span>Current Tier Analysis</span>
        </h3>

        {tierAnalysis.current_tier_analysis && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Current Tier"
              value={`Tier ${tierAnalysis.current_tier_analysis.tier}`}
              icon={Award}
            />
            <MetricCard
              title="Average Performance"
              value={`${tierAnalysis.current_tier_analysis.average_performance?.toFixed(2) || 0}`}
              icon={TrendingUp}
            />
            <MetricCard
              title="Advancement Readiness"
              value={`${((tierAnalysis.current_tier_analysis.advancement_readiness || 0) * 100).toFixed(0)}%`}
              icon={Target}
            />
            <MetricCard
              title="Tier Stability"
              value={`${((tierAnalysis.current_tier_analysis.tier_stability || 0) * 100).toFixed(0)}%`}
              icon={Shield}
            />
          </div>
        )}
      </div>

      {/* Advancement Probability */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
          <ArrowUp className="w-6 h-6 text-green-400" />
          <span>Advancement Probability</span>
        </h3>

        {tierAnalysis.tier_advancement_probability && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <span className="text-xl font-semibold text-[#1D2B3D]">
                Probability of Advancement:
              </span>
              <div className="flex items-center space-x-4">
                <div className="w-32 h-4 bg-slate-600 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-400 transition-all duration-1000"
                    style={{
                      width: `${(tierAnalysis.tier_advancement_probability.probability || 0) * 100}%`,
                    }}
                  ></div>
                </div>
                <span className="text-2xl font-bold text-green-400">
                  {(
                    (tierAnalysis.tier_advancement_probability.probability ||
                      0) * 100
                  ).toFixed(1)}
                  %
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
                <h4 className="font-semibold text-[#1D2B3D] mb-2">
                  Confidence
                </h4>
                <p
                  className={`text-lg font-bold capitalize ${
                    tierAnalysis.tier_advancement_probability.confidence ===
                    "high"
                      ? "text-green-400"
                      : tierAnalysis.tier_advancement_probability.confidence ===
                          "medium"
                        ? "text-yellow-400"
                        : "text-red-400"
                  }`}
                >
                  {tierAnalysis.tier_advancement_probability.confidence}
                </p>
              </div>
              <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
                <h4 className="font-semibold text-[#1D2B3D] mb-2">Timeline</h4>
                <p className="text-lg font-bold text-[#B8860B]">
                  {typeof tierAnalysis.tier_advancement_probability
                    .estimated_timeline_days === "number"
                    ? `${tierAnalysis.tier_advancement_probability.estimated_timeline_days} days`
                    : tierAnalysis.tier_advancement_probability
                        .estimated_timeline_days}
                </p>
              </div>
              <div className="bg-[#1D2B3D]/5 p-4 rounded-lg">
                <h4 className="font-semibold text-[#1D2B3D] mb-2">
                  Risk Level
                </h4>
                <p
                  className={`text-lg font-bold capitalize ${
                    tierAnalysis.tier_risk_factors?.overall_risk_level ===
                    "high"
                      ? "text-red-400"
                      : tierAnalysis.tier_risk_factors?.overall_risk_level ===
                          "medium"
                        ? "text-yellow-400"
                        : "text-green-400"
                  }`}
                >
                  {tierAnalysis.tier_risk_factors?.overall_risk_level || "Low"}
                </p>
              </div>
            </div>

            {/* Key Factors */}
            {tierAnalysis.tier_advancement_probability.key_factors && (
              <div>
                <h4 className="font-semibold text-[#1D2B3D] mb-4">
                  Contributing Factors:
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-[#1D2B3D]/30 p-3 rounded-lg">
                    <span className="text-gray-600">Trend:</span>
                    <span className="text-[#1D2B3D] font-mono ml-2">
                      {(
                        tierAnalysis.tier_advancement_probability.key_factors
                          .trend_contribution * 100
                      ).toFixed(1)}
                      %
                    </span>
                  </div>
                  <div className="bg-[#1D2B3D]/30 p-3 rounded-lg">
                    <span className="text-gray-600">Consistency:</span>
                    <span className="text-[#1D2B3D] font-mono ml-2">
                      {(
                        tierAnalysis.tier_advancement_probability.key_factors
                          .consistency_contribution * 100
                      ).toFixed(1)}
                      %
                    </span>
                  </div>
                  <div className="bg-[#1D2B3D]/30 p-3 rounded-lg">
                    <span className="text-gray-600">Current Score:</span>
                    <span className="text-[#1D2B3D] font-mono ml-2">
                      {(
                        tierAnalysis.tier_advancement_probability.key_factors
                          .current_score_contribution * 100
                      ).toFixed(1)}
                      %
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
