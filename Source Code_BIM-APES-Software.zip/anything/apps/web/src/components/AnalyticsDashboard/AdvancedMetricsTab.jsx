import {
  TrendingUp,
  Brain,
  Target,
  BarChart3,
  Activity,
  Zap,
  Award,
  Calculator,
  Clock,
} from "lucide-react";
import { MetricCard } from "@/components/AnalyticsDashboard/MetricCard";

export function AdvancedMetricsTab({ analytics }) {
  if (!analytics?.advanced_metrics) {
    return (
      <div className="text-center py-12 text-gray-600">
        <Calculator className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <p>No advanced metrics available.</p>
      </div>
    );
  }

  const metrics = analytics.advanced_metrics;

  return (
    <div className="space-y-8">
      {/* Performance Velocity Details */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
          <TrendingUp className="w-6 h-6 text-[#B8860B]" />
          <span>Performance Velocity Analysis</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Average Velocity"
            value={`${metrics.performance_velocity?.average_velocity?.toFixed(4) || 0} pts/day`}
            trend={metrics.performance_velocity?.trend}
            icon={Activity}
          />
          <MetricCard
            title="Acceleration"
            value={`${metrics.performance_velocity?.acceleration?.toFixed(4) || 0}`}
            icon={Zap}
          />
          <MetricCard
            title="Velocity Variance"
            value={`${metrics.performance_velocity?.velocity_variance?.toFixed(4) || 0}`}
            icon={BarChart3}
          />
          <MetricCard
            title="Consistency"
            value={`${((metrics.performance_velocity?.velocity_consistency || 0) * 100).toFixed(1)}%`}
            icon={Target}
          />
        </div>
      </div>

      {/* Peak Performance Analysis */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
          <Award className="w-6 h-6 text-yellow-400" />
          <span>Peak Performance Metrics</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MetricCard
            title="Peak Score"
            value={`${metrics.peak_performance_metrics?.peak_score?.toFixed(2) || 0}`}
            icon={TrendingUp}
          />
          <MetricCard
            title="Peak Frequency"
            value={`${((metrics.peak_performance_metrics?.peak_frequency || 0) * 100).toFixed(1)}%`}
            icon={Activity}
          />
          <MetricCard
            title="Peak Sustainability"
            value={`${metrics.peak_performance_metrics?.peak_sustainability_days || 0} days`}
            icon={Clock}
          />
          <MetricCard
            title="Performance Ceiling"
            value={`${metrics.peak_performance_metrics?.performance_ceiling?.toFixed(2) || 0}`}
            icon={Target}
          />
          <MetricCard
            title="Peak Consistency"
            value={`${((metrics.peak_performance_metrics?.peak_consistency || 0) * 100).toFixed(1)}%`}
            icon={BarChart3}
          />
          <MetricCard
            title="Recovery Time"
            value={`${metrics.peak_performance_metrics?.time_to_peak_recovery?.toFixed(1) || 0} periods`}
            icon={Clock}
          />
        </div>
      </div>

      {/* Learning & Efficiency */}
      <div className="bg-white/70 backdrop-blur-sm rounded-xl p-8 border border-[#1D2B3D]/20 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 text-[#1D2B3D] flex items-center space-x-2">
          <Brain className="w-6 h-6 text-purple-400" />
          <span>Learning & Efficiency Analysis</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MetricCard
            title="Learning Rate"
            value={`${((metrics.learning_rate_coefficient || 0) * 100).toFixed(1)}%`}
            icon={Brain}
          />
          <MetricCard
            title="Overall Efficiency"
            value={`${((metrics.efficiency_ratios?.overall_efficiency || 0) * 100).toFixed(1)}%`}
            icon={Zap}
          />
          <MetricCard
            title="Motion-Performance Ratio"
            value={`${metrics.efficiency_ratios?.motion_to_performance_ratio?.toFixed(3) || 0}`}
            icon={Activity}
          />
        </div>
      </div>
    </div>
  );
}
