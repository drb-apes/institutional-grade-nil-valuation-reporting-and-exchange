export function AuthRequiredView() {
  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1D2B3D] flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">Authentication Required</h1>
        <p className="text-gray-600 mb-6">
          Please sign in to access analytics dashboard
        </p>
        <a
          href="/account/signin"
          className="bg-[#1D2B3D] hover:bg-[#B8860B] px-6 py-3 rounded-lg font-semibold transition-colors text-white"
        >
          Sign In
        </a>
      </div>
    </div>
  );
}
