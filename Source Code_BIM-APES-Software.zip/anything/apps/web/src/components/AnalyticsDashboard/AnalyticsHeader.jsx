import { Brain } from "lucide-react";

export function AnalyticsHeader({
  timeframe,
  setTimeframe,
  predictionHorizon,
  setPredictionHorizon,
}) {
  return (
    <div className="mb-12">
      <div className="flex items-center space-x-2 mb-6">
        <Brain className="w-8 h-8 text-[#C8A882]" />
        <div className="text-sm text-[#1B3A57] bg-[#C8A882]/20 px-3 py-1 rounded-full border border-[#C8A882]/30">
          Performance Analytics Engine
        </div>
      </div>

      <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-[#1B3A57] via-[#C8A882] to-[#1B3A57] bg-clip-text text-transparent">
        Advanced Analytics Dashboard
      </h1>

      <p className="text-xl text-gray-600 max-w-3xl">
        Institutional-grade performance analytics, predictive modeling, and risk
        assessment for athlete asset optimization
      </p>

      {/* Controls */}
      <div className="flex flex-wrap gap-4 mt-8">
        <div className="flex items-center space-x-2">
          <label className="text-sm text-gray-600">Timeframe:</label>
          <select
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            className="bg-white border border-[#1B3A57]/20 rounded-lg px-3 py-2 text-[#1B3A57] focus:outline-none focus:border-[#C8A882]"
          >
            <option value="30">30 Days</option>
            <option value="60">60 Days</option>
            <option value="90">90 Days</option>
            <option value="180">180 Days</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <label className="text-sm text-gray-600">Prediction Horizon:</label>
          <select
            value={predictionHorizon}
            onChange={(e) => setPredictionHorizon(e.target.value)}
            className="bg-white border border-[#1B3A57]/20 rounded-lg px-3 py-2 text-[#1B3A57] focus:outline-none focus:border-[#C8A882]"
          >
            <option value="7">7 Days</option>
            <option value="14">14 Days</option>
            <option value="30">30 Days</option>
            <option value="60">60 Days</option>
            <option value="90">90 Days</option>
          </select>
        </div>
      </div>
    </div>
  );
}
