import { LineChart } from "lucide-react";

export function ModelCard({ name, data }) {
  const displayName = name
    .replace(/_/g, " ")
    .replace(/\b\w/g, (l) => l.toUpperCase());

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-[#1D2B3D]/20 shadow-lg">
      <h4 className="text-lg font-semibold text-[#1D2B3D] mb-4 flex items-center space-x-2">
        <LineChart className="w-5 h-5 text-[#B8860B]" />
        <span>{displayName}</span>
      </h4>

      <div className="space-y-3">
        <div className="flex justify-between">
          <span className="text-gray-600">Model Type:</span>
          <span className="text-[#1D2B3D] font-medium">
            {data.model_type || name}
          </span>
        </div>

        {data.predictions && data.predictions.length > 0 && (
          <>
            <div className="flex justify-between">
              <span className="text-gray-600">7-Day Forecast:</span>
              <span className="text-[#B8860B] font-mono">
                {data.predictions[6]?.predicted_score?.toFixed(2) || "N/A"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">30-Day Forecast:</span>
              <span className="text-[#B8860B] font-mono">
                {data.predictions[29]?.predicted_score?.toFixed(2) || "N/A"}
              </span>
            </div>
          </>
        )}

        {data.r_squared && (
          <div className="flex justify-between">
            <span className="text-gray-600">R²:</span>
            <span className="text-[#1D2B3D] font-mono">
              {data.r_squared.toFixed(3)}
            </span>
          </div>
        )}

        {data.slope && (
          <div className="flex justify-between">
            <span className="text-gray-600">Slope:</span>
            <span className="text-[#1D2B3D] font-mono">
              {data.slope.toFixed(6)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
