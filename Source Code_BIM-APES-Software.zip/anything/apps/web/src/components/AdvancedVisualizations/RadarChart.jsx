import { useMemo } from "react";

export default function RadarChart({ data, width = 400, height = 400 }) {
  const radarData = useMemo(() => {
    if (!data || !data.axes || !data.datasets) return null;

    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 2 - 60;
    const numAxes = data.axes.length;

    // Calculate axis points
    const axisPoints = data.axes.map((axis, index) => {
      const angle = (Math.PI * 2 * index) / numAxes - Math.PI / 2;
      return {
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        label: axis.label,
        angle,
      };
    });

    // Calculate data points for each dataset
    const datasets = data.datasets.map((dataset, datasetIndex) => {
      const points = dataset.data.map((value, index) => {
        const normalizedValue = value / (data.axes[index].max || 100);
        const angle = axisPoints[index].angle;
        const r = radius * normalizedValue;

        return {
          x: centerX + Math.cos(angle) * r,
          y: centerY + Math.sin(angle) * r,
          value,
        };
      });

      return {
        ...dataset,
        points,
        pathData: generatePath(points),
      };
    });

    // Grid circles
    const gridCircles = [0.2, 0.4, 0.6, 0.8, 1.0].map((factor) => ({
      radius: radius * factor,
      label: Math.round((data.axes[0].max || 100) * factor),
    }));

    return {
      centerX,
      centerY,
      radius,
      axisPoints,
      datasets,
      gridCircles,
    };
  }, [data, width, height]);

  if (!radarData) {
    return (
      <div
        className="flex items-center justify-center bg-slate-800 rounded-lg"
        style={{ width, height }}
      >
        <p className="text-slate-400">No radar data available</p>
      </div>
    );
  }

  const colors = ["#3b82f6", "#10b981", "#f59e0b"];

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      {/* Grid circles */}
      {radarData.gridCircles.map((circle, idx) => (
        <g key={idx}>
          <circle
            cx={radarData.centerX}
            cy={radarData.centerY}
            r={circle.radius}
            fill="none"
            stroke="#475569"
            strokeWidth="1"
            opacity="0.3"
          />
          <text
            x={radarData.centerX + 5}
            y={radarData.centerY - circle.radius + 5}
            className="text-xs fill-slate-500"
          >
            {circle.label}
          </text>
        </g>
      ))}

      {/* Axis lines */}
      {radarData.axisPoints.map((point, idx) => (
        <line
          key={idx}
          x1={radarData.centerX}
          y1={radarData.centerY}
          x2={point.x}
          y2={point.y}
          stroke="#475569"
          strokeWidth="1"
          opacity="0.5"
        />
      ))}

      {/* Data polygons */}
      {radarData.datasets.map((dataset, datasetIndex) => (
        <g key={datasetIndex}>
          <path
            d={dataset.pathData}
            fill={colors[datasetIndex % colors.length]}
            fillOpacity="0.2"
            stroke={colors[datasetIndex % colors.length]}
            strokeWidth="2"
          />
          {/* Data points */}
          {dataset.points.map((point, pointIndex) => (
            <circle
              key={pointIndex}
              cx={point.x}
              cy={point.y}
              r="4"
              fill={colors[datasetIndex % colors.length]}
            >
              <title>{`${data.axes[pointIndex].label}: ${point.value.toFixed(1)}`}</title>
            </circle>
          ))}
        </g>
      ))}

      {/* Axis labels */}
      {radarData.axisPoints.map((point, idx) => {
        const labelOffset = 20;
        const angle = point.angle;
        const labelX =
          radarData.centerX +
          Math.cos(angle) * (radarData.radius + labelOffset);
        const labelY =
          radarData.centerY +
          Math.sin(angle) * (radarData.radius + labelOffset);

        return (
          <text
            key={idx}
            x={labelX}
            y={labelY}
            textAnchor="middle"
            alignmentBaseline="middle"
            className="text-xs fill-slate-200 font-semibold"
          >
            {point.label}
          </text>
        );
      })}
    </svg>
  );
}

function generatePath(points) {
  if (points.length === 0) return "";

  const pathData = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x},${p.y}`)
    .join(" ");
  return `${pathData} Z`;
}
