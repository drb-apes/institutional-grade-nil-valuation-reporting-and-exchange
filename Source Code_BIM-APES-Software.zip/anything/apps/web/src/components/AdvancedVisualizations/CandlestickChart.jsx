"use client";

import { useState } from "react";

/**
 * Candlestick Chart Component
 *
 * Use cases:
 * - NIL valuation volatility (open, high, low, close per day/week)
 * - Performance variability (min, max, avg per session)
 * - Training load fluctuation
 * - Match-to-match consistency
 */

export default function CandlestickChart({
  data = [],
  title = "Performance Volatility",
  xLabel = "Period",
  yLabel = "Value",
  showVolume = false,
  height = 400,
}) {
  const [hoveredCandle, setHoveredCandle] = useState(null);

  if (data.length === 0) {
    return (
      <div className="w-full h-64 flex items-center justify-center bg-slate-800/50 rounded-lg border border-slate-600">
        <p className="text-blue-300">No data available</p>
      </div>
    );
  }

  const padding = {
    top: 20,
    right: 20,
    bottom: showVolume ? 80 : 40,
    left: 60,
  };
  const width = 700;
  const chartWidth = width - padding.left - padding.right;
  const volumeHeight = showVolume ? 60 : 0;
  const candleChartHeight =
    height - padding.top - padding.bottom - volumeHeight;

  // Get min/max values
  const allValues = data.flatMap((d) => [d.high, d.low]);
  const minValue = Math.min(...allValues);
  const maxValue = Math.max(...allValues);
  const valueRange = maxValue - minValue || 1;

  const maxVolume = showVolume
    ? Math.max(...data.map((d) => d.volume || 0))
    : 0;

  // Scale functions
  const scaleX = (index) => ((index + 0.5) / data.length) * chartWidth;
  const scaleY = (value) =>
    candleChartHeight - ((value - minValue) / valueRange) * candleChartHeight;
  const scaleVolume = (volume) => (volume / maxVolume) * volumeHeight;

  const candleWidth = Math.max(
    5,
    Math.min(20, (chartWidth / data.length) * 0.7),
  );

  return (
    <div className="w-full">
      {title && (
        <h3 className="text-white text-lg font-semibold mb-4">{title}</h3>
      )}

      <div className="bg-slate-800/50 rounded-lg border border-slate-600 p-4">
        <svg
          width="100%"
          height={height}
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="xMidYMid meet"
        >
          <g transform={`translate(${padding.left}, ${padding.top})`}>
            {/* Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1].map((ratio) => (
              <line
                key={ratio}
                x1={0}
                y1={candleChartHeight * ratio}
                x2={chartWidth}
                y2={candleChartHeight * ratio}
                stroke="rgba(148, 163, 184, 0.1)"
                strokeWidth="1"
              />
            ))}

            {/* Y-axis labels */}
            {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
              const value = maxValue - valueRange * ratio;
              return (
                <text
                  key={ratio}
                  x={-10}
                  y={candleChartHeight * ratio}
                  textAnchor="end"
                  dominantBaseline="middle"
                  className="text-[10px] fill-blue-300"
                >
                  {value.toFixed(0)}
                </text>
              );
            })}

            {/* Candlesticks */}
            {data.map((d, i) => {
              const x = scaleX(i);
              const isUp = d.close >= d.open;
              const bodyTop = scaleY(Math.max(d.open, d.close));
              const bodyBottom = scaleY(Math.min(d.open, d.close));
              const bodyHeight = Math.max(2, bodyBottom - bodyTop);

              const isHovered = hoveredCandle === i;

              return (
                <g
                  key={i}
                  onMouseEnter={() => setHoveredCandle(i)}
                  onMouseLeave={() => setHoveredCandle(null)}
                  className="cursor-pointer"
                >
                  {/* High-Low wick */}
                  <line
                    x1={x}
                    y1={scaleY(d.high)}
                    x2={x}
                    y2={scaleY(d.low)}
                    stroke={isUp ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"}
                    strokeWidth={isHovered ? 3 : 2}
                    opacity={isHovered ? 1 : 0.8}
                  />

                  {/* Open-Close body */}
                  <rect
                    x={x - candleWidth / 2}
                    y={bodyTop}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={isUp ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"}
                    stroke={isUp ? "rgb(22, 163, 74)" : "rgb(220, 38, 38)"}
                    strokeWidth={isHovered ? 2 : 1}
                    opacity={isHovered ? 1 : 0.9}
                  />

                  {/* Hover indicator */}
                  {isHovered && (
                    <line
                      x1={x}
                      y1={0}
                      x2={x}
                      y2={candleChartHeight}
                      stroke="rgba(59, 130, 246, 0.3)"
                      strokeWidth="1"
                      strokeDasharray="4 2"
                    />
                  )}
                </g>
              );
            })}

            {/* X-axis */}
            <line
              x1={0}
              y1={candleChartHeight}
              x2={chartWidth}
              y2={candleChartHeight}
              stroke="rgba(148, 163, 184, 0.3)"
              strokeWidth="2"
            />

            {/* Y-axis */}
            <line
              x1={0}
              y1={0}
              x2={0}
              y2={candleChartHeight}
              stroke="rgba(148, 163, 184, 0.3)"
              strokeWidth="2"
            />

            {/* Volume bars */}
            {showVolume && (
              <g transform={`translate(0, ${candleChartHeight + 10})`}>
                {data.map((d, i) => {
                  const x = scaleX(i);
                  const barHeight = scaleVolume(d.volume || 0);
                  const isUp = d.close >= d.open;
                  const isHovered = hoveredCandle === i;

                  return (
                    <rect
                      key={i}
                      x={x - candleWidth / 2}
                      y={volumeHeight - barHeight}
                      width={candleWidth}
                      height={barHeight}
                      fill={isUp ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"}
                      opacity={isHovered ? 0.8 : 0.4}
                    />
                  );
                })}

                {/* Volume baseline */}
                <line
                  x1={0}
                  y1={volumeHeight}
                  x2={chartWidth}
                  y2={volumeHeight}
                  stroke="rgba(148, 163, 184, 0.3)"
                  strokeWidth="1"
                />
              </g>
            )}

            {/* X-axis labels */}
            {data.map((d, i) => {
              if (i % Math.ceil(data.length / 8) !== 0) return null;
              return (
                <text
                  key={i}
                  x={scaleX(i)}
                  y={candleChartHeight + (showVolume ? volumeHeight + 25 : 20)}
                  textAnchor="middle"
                  className="text-[9px] fill-blue-300"
                >
                  {d.label}
                </text>
              );
            })}

            {/* Axis labels */}
            <text
              x={chartWidth / 2}
              y={candleChartHeight + (showVolume ? volumeHeight + 40 : 35)}
              textAnchor="middle"
              className="text-[11px] fill-blue-300"
            >
              {xLabel}
            </text>

            <text
              x={-candleChartHeight / 2}
              y={-45}
              textAnchor="middle"
              transform={`rotate(-90, -${candleChartHeight / 2}, -45)`}
              className="text-[11px] fill-blue-300"
            >
              {yLabel}
            </text>
          </g>
        </svg>

        {/* Hover details */}
        {hoveredCandle !== null && (
          <div className="mt-4 bg-slate-900 border border-slate-600 rounded-lg p-4">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div>
                <p className="text-blue-300 text-xs mb-1">Period</p>
                <p className="text-white font-semibold">
                  {data[hoveredCandle].label}
                </p>
              </div>
              <div>
                <p className="text-blue-300 text-xs mb-1">Open</p>
                <p className="text-white font-mono">
                  {data[hoveredCandle].open.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-blue-300 text-xs mb-1">High</p>
                <p className="text-green-400 font-mono font-semibold">
                  {data[hoveredCandle].high.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-blue-300 text-xs mb-1">Low</p>
                <p className="text-red-400 font-mono font-semibold">
                  {data[hoveredCandle].low.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-blue-300 text-xs mb-1">Close</p>
                <p
                  className={`font-mono font-semibold ${
                    data[hoveredCandle].close >= data[hoveredCandle].open
                      ? "text-green-400"
                      : "text-red-400"
                  }`}
                >
                  {data[hoveredCandle].close.toFixed(2)}
                </p>
              </div>
              {showVolume && (
                <div>
                  <p className="text-blue-300 text-xs mb-1">Volume</p>
                  <p className="text-white font-mono">
                    {data[hoveredCandle].volume?.toLocaleString()}
                  </p>
                </div>
              )}
            </div>
            <div className="mt-3 flex items-center gap-4">
              <div>
                <span className="text-blue-300 text-xs">Change: </span>
                <span
                  className={`font-semibold ${
                    data[hoveredCandle].close >= data[hoveredCandle].open
                      ? "text-green-400"
                      : "text-red-400"
                  }`}
                >
                  {(
                    data[hoveredCandle].close - data[hoveredCandle].open
                  ).toFixed(2)}{" "}
                  (
                  {(
                    ((data[hoveredCandle].close - data[hoveredCandle].open) /
                      data[hoveredCandle].open) *
                    100
                  ).toFixed(1)}
                  %)
                </span>
              </div>
              <div>
                <span className="text-blue-300 text-xs">Range: </span>
                <span className="text-white font-semibold">
                  {(data[hoveredCandle].high - data[hoveredCandle].low).toFixed(
                    2,
                  )}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Legend */}
        <div className="mt-4 flex items-center justify-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-4 h-6 bg-green-500 border border-green-600 rounded"></div>
            <span className="text-blue-300 text-sm">Gain (Close ≥ Open)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-6 bg-red-500 border border-red-600 rounded"></div>
            <span className="text-blue-300 text-sm">
              Loss (Close {"<"} Open)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
