import { useMemo } from "react";

export default function TrendlineChart({ data, width = 800, height = 300 }) {
  const chartData = useMemo(() => {
    if (!data || !data.timeSeries) return null;

    const padding = { top: 20, right: 40, bottom: 50, left: 60 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // Find data ranges
    const xValues = data.timeSeries.map((p) => p.x);
    const yValues = data.timeSeries.map((p) => p.y);

    const xMin = Math.min(...xValues);
    const xMax = Math.max(...xValues);
    const yMin = Math.min(
      ...yValues,
      ...(data.lowerBound || []).map((p) => p.y),
    );
    const yMax = Math.max(
      ...yValues,
      ...(data.upperBound || []).map((p) => p.y),
    );

    // Create scale functions
    const scaleX = (x) =>
      padding.left + ((x - xMin) / (xMax - xMin)) * chartWidth;
    const scaleY = (y) =>
      padding.top + chartHeight - ((y - yMin) / (yMax - yMin)) * chartHeight;

    // Transform data points
    const points = data.timeSeries.map((p) => ({
      x: scaleX(p.x),
      y: scaleY(p.y),
      originalX: p.x,
      originalY: p.y,
      label: p.label,
    }));

    const trendlinePoints = (data.trendline || []).map((p) => ({
      x: scaleX(p.x),
      y: scaleY(p.y),
    }));

    const upperBoundPoints = (data.upperBound || []).map((p) => ({
      x: scaleX(p.x),
      y: scaleY(p.y),
    }));

    const lowerBoundPoints = (data.lowerBound || []).map((p) => ({
      x: scaleX(p.x),
      y: scaleY(p.y),
    }));

    // Generate tick marks
    const xTicks = generateTicks(xMin, xMax, 5).map((value) => ({
      value,
      x: scaleX(value),
      y: padding.top + chartHeight,
      label: formatXLabel(value),
    }));

    const yTicks = generateTicks(yMin, yMax, 5).map((value) => ({
      value,
      x: padding.left,
      y: scaleY(value),
      label: value.toFixed(0),
    }));

    return {
      points,
      trendlinePoints,
      upperBoundPoints,
      lowerBoundPoints,
      xTicks,
      yTicks,
      padding,
      chartWidth,
      chartHeight,
    };
  }, [data, width, height]);

  if (!chartData) {
    return (
      <div
        className="flex items-center justify-center bg-slate-800 rounded-lg"
        style={{ width, height }}
      >
        <p className="text-slate-400">No trendline data available</p>
      </div>
    );
  }

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      {/* Grid lines */}
      {chartData.yTicks.map((tick, idx) => (
        <line
          key={`y-grid-${idx}`}
          x1={chartData.padding.left}
          y1={tick.y}
          x2={chartData.padding.left + chartData.chartWidth}
          y2={tick.y}
          stroke="#475569"
          strokeWidth="1"
          opacity="0.2"
        />
      ))}

      {/* Upper bound area */}
      {chartData.upperBoundPoints.length > 0 &&
        chartData.lowerBoundPoints.length > 0 && (
          <path
            d={generateAreaPath(
              chartData.upperBoundPoints,
              chartData.lowerBoundPoints,
            )}
            fill="#3b82f6"
            fillOpacity="0.1"
          />
        )}

      {/* Trendline */}
      {chartData.trendlinePoints.length > 0 && (
        <path
          d={generateLinePath(chartData.trendlinePoints)}
          fill="none"
          stroke="#3b82f6"
          strokeWidth="2"
          strokeDasharray="5,5"
        />
      )}

      {/* Data line */}
      <path
        d={generateLinePath(chartData.points)}
        fill="none"
        stroke="#10b981"
        strokeWidth="3"
      />

      {/* Data points */}
      {chartData.points.map((point, idx) => (
        <circle
          key={idx}
          cx={point.x}
          cy={point.y}
          r="4"
          fill="#10b981"
          className="hover:r-6 transition-all"
        >
          <title>{`${point.label}: ${point.originalY.toFixed(1)}`}</title>
        </circle>
      ))}

      {/* Y-axis labels */}
      {chartData.yTicks.map((tick, idx) => (
        <text
          key={idx}
          x={tick.x - 10}
          y={tick.y}
          textAnchor="end"
          alignmentBaseline="middle"
          className="text-xs fill-slate-300"
        >
          {tick.label}
        </text>
      ))}

      {/* X-axis labels */}
      {chartData.xTicks.map((tick, idx) => (
        <text
          key={idx}
          x={tick.x}
          y={tick.y + 20}
          textAnchor="middle"
          className="text-xs fill-slate-300"
        >
          {tick.label}
        </text>
      ))}

      {/* Axes */}
      <line
        x1={chartData.padding.left}
        y1={chartData.padding.top}
        x2={chartData.padding.left}
        y2={chartData.padding.top + chartData.chartHeight}
        stroke="#64748b"
        strokeWidth="2"
      />
      <line
        x1={chartData.padding.left}
        y1={chartData.padding.top + chartData.chartHeight}
        x2={chartData.padding.left + chartData.chartWidth}
        y2={chartData.padding.top + chartData.chartHeight}
        stroke="#64748b"
        strokeWidth="2"
      />
    </svg>
  );
}

function generateLinePath(points) {
  if (points.length === 0) return "";
  return points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x},${p.y}`).join(" ");
}

function generateAreaPath(upperPoints, lowerPoints) {
  if (upperPoints.length === 0 || lowerPoints.length === 0) return "";

  const upperPath = upperPoints
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x},${p.y}`)
    .join(" ");
  const lowerPath = [...lowerPoints]
    .reverse()
    .map((p) => `L ${p.x},${p.y}`)
    .join(" ");

  return `${upperPath} ${lowerPath} Z`;
}

function generateTicks(min, max, count) {
  const range = max - min;
  const step = range / (count - 1);
  return Array.from({ length: count }, (_, i) => min + i * step);
}

function formatXLabel(timestamp) {
  const date = new Date(timestamp);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}
