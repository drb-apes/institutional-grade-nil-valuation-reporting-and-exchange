import { useMemo } from "react";

export default function HeatmapChart({
  data,
  width = 800,
  height = 400,
  colorScale,
}) {
  const heatmapData = useMemo(() => {
    if (!data || !data.data) return { cells: [], xLabels: [], yLabels: [] };

    // Extract unique x and y labels
    const xLabels = [...new Set(data.data.map((d) => d.xLabel))];
    const yLabels = [...new Set(data.data.map((d) => d.yLabel))];

    // Calculate cell dimensions
    const cellWidth = width / xLabels.length;
    const cellHeight = height / yLabels.length;

    // Create cells
    const cells = data.data.map((point) => {
      const xIndex = xLabels.indexOf(point.xLabel);
      const yIndex = yLabels.indexOf(point.yLabel);

      return {
        x: xIndex * cellWidth,
        y: yIndex * cellHeight,
        width: cellWidth,
        height: cellHeight,
        value: point.value,
        intensity: point.intensity,
        xLabel: point.xLabel,
        yLabel: point.yLabel,
        color: getHeatmapColor(point.intensity, colorScale || data.colorScale),
      };
    });

    return { cells, xLabels, yLabels, cellWidth, cellHeight };
  }, [data, width, height, colorScale]);

  if (!heatmapData.cells.length) {
    return (
      <div
        className="flex items-center justify-center bg-slate-800 rounded-lg"
        style={{ width, height }}
      >
        <p className="text-slate-400">No heatmap data available</p>
      </div>
    );
  }

  return (
    <div className="relative">
      <svg width={width} height={height} className="bg-slate-900 rounded-lg">
        {/* Heatmap cells */}
        {heatmapData.cells.map((cell, idx) => (
          <g key={idx}>
            <rect
              x={cell.x}
              y={cell.y}
              width={cell.width - 2}
              height={cell.height - 2}
              fill={cell.color}
              className="transition-all duration-300 hover:opacity-80"
            />
            <title>{`${cell.xLabel} - ${cell.yLabel}: ${cell.value.toFixed(1)}`}</title>
          </g>
        ))}

        {/* Y-axis labels */}
        {heatmapData.yLabels.map((label, idx) => (
          <text
            key={idx}
            x={-10}
            y={idx * heatmapData.cellHeight + heatmapData.cellHeight / 2}
            textAnchor="end"
            alignmentBaseline="middle"
            className="text-xs fill-slate-300 font-medium"
          >
            {formatLabel(label)}
          </text>
        ))}
      </svg>

      {/* X-axis labels */}
      <div className="flex mt-2" style={{ width }}>
        {heatmapData.xLabels.map((label, idx) => (
          <div
            key={idx}
            className="text-xs text-slate-300 text-center font-medium"
            style={{ width: heatmapData.cellWidth }}
          >
            {label}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="mt-4 flex items-center gap-2">
        <span className="text-xs text-slate-400">Low</span>
        <div
          className="flex-1 h-4 rounded"
          style={{
            background: `linear-gradient(to right, ${getHeatmapColor(0, data.colorScale)}, ${getHeatmapColor(50, data.colorScale)}, ${getHeatmapColor(100, data.colorScale)})`,
          }}
        />
        <span className="text-xs text-slate-400">High</span>
      </div>
    </div>
  );
}

function getHeatmapColor(intensity, colorScale) {
  if (!colorScale) {
    // Default gradient: blue -> green -> yellow -> red
    if (intensity < 25) return `rgb(59, 130, 246)`; // blue
    if (intensity < 50) return `rgb(16, 185, 129)`; // green
    if (intensity < 75) return `rgb(251, 191, 36)`; // yellow
    return `rgb(239, 68, 68)`; // red
  }

  const { gradient } = colorScale;
  const index = Math.min(
    Math.floor((intensity / 100) * gradient.length),
    gradient.length - 1,
  );
  return gradient[index];
}

function formatLabel(label) {
  if (typeof label !== "string") return String(label);

  return label
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
    .substring(0, 15);
}
