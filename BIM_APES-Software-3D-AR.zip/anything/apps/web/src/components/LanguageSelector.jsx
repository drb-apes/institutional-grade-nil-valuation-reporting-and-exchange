"use client";

import { useLanguage } from "@/utils/LanguageContext";
import { BRAND_COLORS } from "@/utils/brandColors";

export default function LanguageSelector({ className = "" }) {
  const { language, changeLanguage, languages } = useLanguage();

  return (
    <div className={`relative ${className}`}>
      <select
        value={language}
        onChange={(e) => changeLanguage(e.target.value)}
        className="appearance-none bg-[#0D1421] border border-[#C8A882]/20 rounded-lg px-4 py-2 pr-10 text-white focus:outline-none focus:border-[#C8A882] cursor-pointer hover:bg-[#152E45] transition-all"
        style={{ minWidth: "140px" }}
      >
        {Object.entries(languages).map(([code, { name, flag }]) => (
          <option key={code} value={code}>
            {flag} {name}
          </option>
        ))}
      </select>
      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
        <svg
          className="w-4 h-4 text-[#C8A882]"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 9l-7 7-7-7"
          />
        </svg>
      </div>
    </div>
  );
}
