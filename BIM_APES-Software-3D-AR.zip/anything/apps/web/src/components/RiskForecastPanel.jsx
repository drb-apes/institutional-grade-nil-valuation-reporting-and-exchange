"use client";

import {
  TrendingUp,
  AlertTriangle,
  Shield,
  Activity,
  Clock,
} from "lucide-react";

/**
 * Risk Forecasting Panel
 * AWS-powered predictive analytics for:
 * - Injury risk probability
 * - Fatigue trajectory
 * - Recovery velocity
 * - Substitution probability
 * - NIL valuation shifts
 */
export default function RiskForecastPanel({
  athleteId,
  athleteName,
  forecastData,
}) {
  const forecasts = forecastData || generateSampleForecast();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-[#E5E7EB] p-6">
      {/* Header */}
      <div className="mb-6">
        <h3 className="text-xl font-bold text-[#1B3A57] flex items-center gap-2">
          <Activity className="text-[#C8A882]" size={24} />
          Risk Forecasting & Predictive Analytics
        </h3>
        <p className="text-sm text-[#6B7280] mt-1">
          {athleteName} • AWS ML-powered predictions
        </p>
      </div>

      {/* Main Risk Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Injury Risk */}
        <div
          className={`p-4 rounded-lg border-2 ${
            forecasts.injuryRisk.level === "high"
              ? "border-red-500 bg-red-50"
              : forecasts.injuryRisk.level === "moderate"
                ? "border-yellow-500 bg-yellow-50"
                : "border-green-500 bg-green-50"
          }`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle
                className={
                  forecasts.injuryRisk.level === "high"
                    ? "text-red-600"
                    : forecasts.injuryRisk.level === "moderate"
                      ? "text-yellow-600"
                      : "text-green-600"
                }
                size={20}
              />
              <span className="font-bold text-[#1B3A57]">Injury Risk</span>
            </div>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold ${
                forecasts.injuryRisk.level === "high"
                  ? "bg-red-200 text-red-800"
                  : forecasts.injuryRisk.level === "moderate"
                    ? "bg-yellow-200 text-yellow-800"
                    : "bg-green-200 text-green-800"
              }`}
            >
              {forecasts.injuryRisk.level.toUpperCase()}
            </span>
          </div>

          <div className="mb-3">
            <div className="flex items-end gap-2">
              <span className="text-3xl font-bold text-[#1B3A57]">
                {forecasts.injuryRisk.probability}%
              </span>
              <span className="text-sm text-[#6B7280] mb-1">probability</span>
            </div>
            <p className="text-xs text-[#6B7280] mt-1">
              Next {forecasts.injuryRisk.timeframe}
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium text-[#1B3A57]">Key Factors:</p>
            <ul className="text-xs text-[#6B7280] space-y-1">
              {forecasts.injuryRisk.factors.map((factor, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-[#C8A882]">•</span>
                  <span>{factor}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Substitution Probability */}
        <div
          className={`p-4 rounded-lg border-2 ${
            forecasts.substitutionProb.level === "high"
              ? "border-blue-500 bg-blue-50"
              : forecasts.substitutionProb.level === "moderate"
                ? "border-blue-400 bg-blue-50"
                : "border-blue-300 bg-blue-50"
          }`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <Clock className="text-blue-600" size={20} />
              <span className="font-bold text-[#1B3A57]">
                Substitution Risk
              </span>
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-200 text-blue-800">
              {forecasts.substitutionProb.level.toUpperCase()}
            </span>
          </div>

          <div className="mb-3">
            <div className="flex items-end gap-2">
              <span className="text-3xl font-bold text-[#1B3A57]">
                {forecasts.substitutionProb.probability}%
              </span>
              <span className="text-sm text-[#6B7280] mb-1">probability</span>
            </div>
            <p className="text-xs text-[#6B7280] mt-1">
              {forecasts.substitutionProb.timeframe}
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-medium text-[#1B3A57]">Indicators:</p>
            <ul className="text-xs text-[#6B7280] space-y-1">
              {forecasts.substitutionProb.indicators.map((indicator, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-[#C8A882]">•</span>
                  <span>{indicator}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Trajectory Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Fatigue Trajectory */}
        <div>
          <p className="text-sm font-bold text-[#1B3A57] mb-3 flex items-center gap-2">
            <TrendingUp size={16} />
            Fatigue Trajectory (Next 7 Days)
          </p>
          <div className="h-32 bg-[#F9F9F9] rounded-lg p-4 relative">
            <svg className="w-full h-full" viewBox="0 0 200 100">
              <path
                d={generateTrajectoryCurve(forecasts.fatigueTrajectory)}
                fill="none"
                stroke="#F97316"
                strokeWidth="2"
              />
              {/* Threshold line */}
              <line
                x1="0"
                y1="30"
                x2="200"
                y2="30"
                stroke="#EF4444"
                strokeWidth="1"
                strokeDasharray="4"
              />
            </svg>
            <div className="absolute top-2 right-2 text-xs text-[#6B7280]">
              <span className="text-red-500">━ </span>Critical threshold
            </div>
          </div>
        </div>

        {/* Recovery Velocity */}
        <div>
          <p className="text-sm font-bold text-[#1B3A57] mb-3 flex items-center gap-2">
            <Shield size={16} />
            Recovery Velocity (Next 7 Days)
          </p>
          <div className="h-32 bg-[#F9F9F9] rounded-lg p-4 relative">
            <svg className="w-full h-full" viewBox="0 0 200 100">
              <path
                d={generateTrajectoryCurve(forecasts.recoveryTrajectory)}
                fill="none"
                stroke="#10B981"
                strokeWidth="2"
              />
              {/* Optimal line */}
              <line
                x1="0"
                y1="20"
                x2="200"
                y2="20"
                stroke="#10B981"
                strokeWidth="1"
                strokeDasharray="4"
              />
            </svg>
            <div className="absolute top-2 right-2 text-xs text-[#6B7280]">
              <span className="text-green-500">━ </span>Optimal recovery
            </div>
          </div>
        </div>
      </div>

      {/* NIL Valuation Impact */}
      <div className="p-4 bg-gradient-to-r from-[#F0F4F8] to-[#E8DCC8] rounded-lg border border-[#C8A882]">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="font-bold text-[#1B3A57] mb-1">
              NIL Valuation Forecast
            </p>
            <p className="text-xs text-[#6B7280]">
              Based on projected performance and market trends
            </p>
          </div>
          <div
            className={`flex items-center gap-2 ${
              forecasts.nilImpact.direction === "positive"
                ? "text-green-600"
                : "text-red-600"
            }`}
          >
            <TrendingUp size={20} />
            <span className="text-xl font-bold">
              {forecasts.nilImpact.direction === "positive" ? "+" : ""}
              {forecasts.nilImpact.change}%
            </span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-xs text-[#6B7280] mb-1">Current</p>
            <p className="text-lg font-bold text-[#1B3A57]">
              ${forecasts.nilImpact.current.toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-xs text-[#6B7280] mb-1">7-Day Forecast</p>
            <p className="text-lg font-bold text-[#1B3A57]">
              ${forecasts.nilImpact.forecast.toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-xs text-[#6B7280] mb-1">Confidence</p>
            <p className="text-lg font-bold text-[#1B3A57]">
              {forecasts.nilImpact.confidence}%
            </p>
          </div>
        </div>
      </div>

      {/* AWS Integration Badge */}
      <div className="mt-4 flex items-center justify-between text-xs text-[#6B7280]">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span>AWS SageMaker ML • Real-time inference</span>
        </div>
        <span>Last updated: {new Date().toLocaleTimeString()}</span>
      </div>
    </div>
  );
}

/**
 * Helper functions
 */
function generateTrajectoryCurve(dataPoints) {
  const points = dataPoints
    .map((value, index) => {
      const x = (index / (dataPoints.length - 1)) * 200;
      const y = 100 - value * 80; // Invert Y for SVG
      return `${index === 0 ? "M" : "L"} ${x} ${y}`;
    })
    .join(" ");

  return points;
}

function generateSampleForecast() {
  return {
    injuryRisk: {
      probability: 23,
      level: "moderate",
      timeframe: "14 days",
      factors: [
        "Elevated joint torque (L-knee)",
        "Recovery velocity below baseline",
        "Training load accumulation",
      ],
    },
    substitutionProb: {
      probability: 35,
      level: "moderate",
      timeframe: "Next match (72 hours)",
      indicators: [
        "Fatigue severity trending up",
        "Performance dip detected",
        "Backup ready (James Williams)",
      ],
    },
    fatigueTrajectory: [0.4, 0.45, 0.5, 0.55, 0.6, 0.58, 0.55],
    recoveryTrajectory: [0.6, 0.65, 0.7, 0.68, 0.72, 0.75, 0.78],
    nilImpact: {
      current: 95000,
      forecast: 98500,
      change: 3.7,
      direction: "positive",
      confidence: 82,
    },
  };
}
