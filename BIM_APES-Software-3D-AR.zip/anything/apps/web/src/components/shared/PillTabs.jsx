/**
 * Pill-style tab navigation component
 * Used in Investor and Federation dashboards
 */
export default function PillTabs({ tabs, activeTab, onChange }) {
  return (
    <div className="flex gap-3">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === tab.id
                ? "bg-[#C8A882] text-white shadow-lg"
                : "bg-[#0D1421]/60 text-gray-400 hover:bg-[#0D1421]/80 hover:text-white border border-[#C8A882]/10"
            }`}
          >
            <Icon size={18} />
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}
