"use client";

import { useLanguage } from "@/utils/LanguageContext";
import { useEffect, useState } from "react";

export default function StatCard({
  icon,
  label,
  value,
  trend,
  trendLabel,
  color = "#C8A882",
}) {
  const { t } = useLanguage();
  const [translatedLabel, setTranslatedLabel] = useState(label);
  const [translatedTrendLabel, setTranslatedTrendLabel] = useState(trendLabel);

  useEffect(() => {
    t(label).then(setTranslatedLabel);
    if (trendLabel) t(trendLabel).then(setTranslatedTrendLabel);
  }, [label, trendLabel, t]);

  return (
    <div className="bg-[#0D1421]/60 backdrop-blur-sm border border-[#C8A882]/20 rounded-xl p-6 hover:bg-[#1B3A57]/30 hover:border-[#C8A882]/40 transition-all duration-300">
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-12 h-12 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: `${color}20` }}
        >
          {icon}
        </div>
        {trend && (
          <div
            className={`flex items-center gap-1 text-sm ${
              trend > 0
                ? "text-emerald-400"
                : trend < 0
                  ? "text-red-400"
                  : "text-gray-400"
            }`}
          >
            {trend > 0 ? "↑" : trend < 0 ? "↓" : "→"}
            <span>{Math.abs(trend)}%</span>
          </div>
        )}
      </div>
      <div className="text-3xl font-bold text-white mb-1">{value}</div>
      <div className="text-[#9CA3AF] text-sm uppercase tracking-wide">
        {translatedLabel}
      </div>
      {translatedTrendLabel && (
        <div className="text-[#C8A882]/70 text-xs mt-2">
          {translatedTrendLabel}
        </div>
      )}
    </div>
  );
}
