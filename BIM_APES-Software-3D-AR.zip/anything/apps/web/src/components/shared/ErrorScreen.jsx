import { AlertCircle } from "lucide-react";

/**
 * Unified error screen component
 * Provides consistent error handling across all dashboards
 */
export default function ErrorScreen({
  title = "Error Loading Data",
  message,
  onRetry,
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421] flex items-center justify-center p-6">
      <div className="bg-[#0D1421]/60 backdrop-blur-sm rounded-xl border border-red-500/40 p-8 max-w-md">
        <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white text-center mb-2">
          {title}
        </h2>
        <p className="text-gray-300 text-center">{message}</p>
        {onRetry && (
          <button
            onClick={onRetry}
            className="bg-[#C8A882] hover:bg-[#B8956A] text-white px-6 py-3 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl w-full mt-4"
          >
            Retry
          </button>
        )}
      </div>
    </div>
  );
}
