import { RefreshCw } from "lucide-react";

/**
 * Unified dashboard header component
 * Used across Intelligence, Investor, and Federation dashboards
 */
export default function DashboardHeader({
  icon: Icon,
  title,
  description,
  onRefresh,
  loading = false,
  children, // For additional header content like athlete info
}) {
  return (
    <div className="bg-gradient-to-r from-[#1B3A57]/90 to-[#152E45]/90 border-b border-[#C8A882]/20 backdrop-blur-xl sticky top-0 z-50">
      <div className="max-w-[1600px] mx-auto px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
              <div className="w-12 h-12 bg-[#C8A882]/10 rounded-xl flex items-center justify-center">
                <Icon className="text-[#C8A882]" size={28} />
              </div>
              {title}
            </h1>
            <p className="text-gray-300 text-lg">{description}</p>
          </div>
          {onRefresh && (
            <button
              onClick={onRefresh}
              disabled={loading}
              className="bg-[#C8A882] hover:bg-[#B8956A] text-white px-6 py-3 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw className={loading ? "animate-spin" : ""} size={18} />
              Refresh
            </button>
          )}
        </div>
        {children}
      </div>
    </div>
  );
}
