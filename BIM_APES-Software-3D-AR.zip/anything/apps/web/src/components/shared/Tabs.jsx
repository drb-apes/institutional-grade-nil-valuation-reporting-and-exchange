"use client";

import { useLanguage } from "@/utils/LanguageContext";
import { useEffect, useState } from "react";

export default function Tabs({ tabs, activeTab, onChange }) {
  const { t } = useLanguage();
  const [translatedTabs, setTranslatedTabs] = useState(tabs);

  useEffect(() => {
    Promise.all(
      tabs.map((tab) => t(tab.label).then((label) => ({ ...tab, label }))),
    ).then(setTranslatedTabs);
  }, [tabs, t]);

  return (
    <div className="flex gap-1 border-b border-[#C8A882]/20">
      {translatedTabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`
            px-6 py-3 text-sm font-medium transition-all relative
            ${
              activeTab === tab.id
                ? "text-[#C8A882]"
                : "text-gray-400 hover:text-white"
            }
          `}
        >
          {tab.label}
          {activeTab === tab.id && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#C8A882]" />
          )}
        </button>
      ))}
    </div>
  );
}
