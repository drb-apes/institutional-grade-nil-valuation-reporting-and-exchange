/**
 * Glass panel component with optional gradient header
 * Used for content sections across dashboards
 */
export default function GlassPanel({
  title,
  icon: Icon,
  children,
  className = "",
}) {
  return (
    <div
      className={`bg-[#0D1421]/60 backdrop-blur-sm rounded-xl border border-[#C8A882]/20 overflow-hidden ${className}`}
    >
      {title && (
        <div className="bg-gradient-to-r from-[#1B3A57] to-[#0D1421] border-b border-[#C8A882]/20 p-6">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            {Icon && <Icon className="text-[#C8A882]" size={20} />}
            {title}
          </h3>
        </div>
      )}
      <div className={title ? "" : "p-6"}>{children}</div>
    </div>
  );
}
