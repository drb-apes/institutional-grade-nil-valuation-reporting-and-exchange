"use client";

export default function Card({
  children,
  className = "",
  header,
  footer,
  gradient = false,
  hover = true,
}) {
  const baseClasses = `
    bg-[#0D1421]/60 backdrop-blur-sm
    border border-[#C8A882]/20 rounded-xl
    ${hover ? "hover:bg-[#1B3A57]/30 hover:border-[#C8A882]/40 transition-all duration-300" : ""}
    ${className}
  `;

  return (
    <div className={baseClasses}>
      {header && (
        <div
          className={`
          ${gradient ? "bg-gradient-to-r from-[#1B3A57] to-[#0D1421]" : "bg-[#1B3A57]/40"}
          border-b border-[#C8A882]/20 px-6 py-4 rounded-t-xl
        `}
        >
          {header}
        </div>
      )}
      <div className="p-6">{children}</div>
      {footer && (
        <div className="border-t border-[#C8A882]/20 px-6 py-4 bg-[#0D1421]/40 rounded-b-xl">
          {footer}
        </div>
      )}
    </div>
  );
}
