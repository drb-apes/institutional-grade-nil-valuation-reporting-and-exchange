"use client";

import { BRAND_COLORS, BRAND_CLASSES } from "@/utils/brandColors";
import LanguageSelector from "@/components/LanguageSelector";
import { useLanguage } from "@/utils/LanguageContext";
import { useEffect, useState } from "react";

export default function DashboardLayout({
  title,
  icon,
  children,
  onRefresh,
  showLanguageSelector = true,
}) {
  const { t } = useLanguage();
  const [translatedTitle, setTranslatedTitle] = useState(title);

  useEffect(() => {
    t(title).then(setTranslatedTitle);
  }, [title, t]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0F1C] via-[#0D1421] to-[#152E45]">
      {/* Sticky Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-gradient-to-r from-[#1B3A57]/95 via-[#0D1421]/95 to-[#1B3A57]/95 border-b border-[#C8A882]/20">
        <div className="max-w-[1600px] mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {icon && (
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#C8A882] to-[#B8956A] flex items-center justify-center shadow-lg">
                  {icon}
                </div>
              )}
              <div>
                <h1 className="text-3xl font-bold text-white">
                  {translatedTitle}
                </h1>
                <p className="text-[#C8A882]/70 text-sm mt-1">
                  BIM-APES Intelligence Platform
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {showLanguageSelector && <LanguageSelector />}
              {onRefresh && (
                <button
                  onClick={onRefresh}
                  className={BRAND_CLASSES.btnPrimary}
                >
                  Refresh
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1600px] mx-auto px-8 py-8">{children}</div>
    </div>
  );
}
