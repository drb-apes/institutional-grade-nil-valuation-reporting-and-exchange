/**
 * Metric/stat card component
 * Used for displaying KPIs and metrics across dashboards
 */
export default function MetricCard({
  label,
  value,
  subtext,
  icon: Icon,
  valueColor = "text-white",
  children, // For custom bottom content (e.g., PnL trends)
}) {
  return (
    <div className="bg-gradient-to-br from-[#0D1421] to-[#1B3A57]/50 border border-[#C8A882]/20 rounded-xl p-6 hover:shadow-xl transition-all hover:border-[#C8A882]/40">
      <div className="flex items-center justify-between mb-4">
        <span className="text-gray-400 text-sm font-semibold tracking-wide uppercase">
          {label}
        </span>
        <div className="w-10 h-10 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
          <Icon className="text-[#C8A882]" size={20} />
        </div>
      </div>
      <div className={`text-3xl font-bold mb-2 ${valueColor}`}>{value}</div>
      {subtext && <div className="text-sm text-gray-400">{subtext}</div>}
      {children}
    </div>
  );
}
