/**
 * Unified loading screen component
 * Used across all dashboards for consistent loading states
 */
export default function LoadingScreen({ message = "Loading..." }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421] flex items-center justify-center">
      <div className="text-center">
        <div className="relative w-16 h-16 mx-auto mb-6">
          <div className="absolute inset-0 border-4 border-[#C8A882]/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-[#C8A882] border-t-transparent rounded-full animate-spin"></div>
        </div>
        <p className="text-gray-400 font-medium">{message}</p>
      </div>
    </div>
  );
}
