"use client";

import { useState, useEffect } from "react";

export default function MMAPerformanceDashboard({ fightData }) {
  const [performanceMetrics, setPerformanceMetrics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (fightData) {
      fetchPerformanceMetrics();
    }
  }, [fightData]);

  async function fetchPerformanceMetrics() {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/sport-specific/mma/performance-tracking",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(fightData),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to fetch MMA performance metrics");
      }

      const data = await response.json();
      setPerformanceMetrics(data);
    } catch (err) {
      console.error("Error fetching MMA metrics:", err);
      setError(err.message);
      // Use mock data on error
      setPerformanceMetrics(getMockMMAMetrics());
    } finally {
      setLoading(false);
    }
  }

  function getMockMMAMetrics() {
    return {
      mmaPerformanceIndex: 86,
      metrics: {
        strikingAccuracy: 64,
        grapplingControl: 78,
        takedownDefense: 72,
        submissionAttempts: 3,
        cageControl: 76,
        transitionSpeed: 82,
        groundAndPound: 74,
        cardio: 85,
      },
      coachingCues: [
        "Maintain cage center control",
        "Watch for guillotine attempts",
        "Improve takedown timing",
        "Use jab to set up power shots",
      ],
      roundBreakdown: [
        { round: 1, striking: 75, grappling: 80, control: 70 },
        { round: 2, striking: 68, grappling: 72, control: 75 },
        { round: 3, striking: 72, grappling: 85, control: 80 },
      ],
      fightStats: {
        significantStrikes: "45/71",
        takedowns: "3/6",
        submissions: 1,
        controlTime: "4:32",
      },
    };
  }

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center py-8">
          <div className="text-[#C8A882] font-semibold">
            Loading MMA metrics...
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center py-8">
          <div className="text-red-400 font-semibold">Error: {error}</div>
        </div>
      </div>
    );
  }

  if (!performanceMetrics) {
    return (
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center py-8">
          <div className="text-gray-400">No MMA data available</div>
        </div>
      </div>
    );
  }

  const {
    mmaPerformanceIndex,
    metrics,
    coachingCues,
    roundBreakdown,
    fightStats,
  } = performanceMetrics;

  return (
    <div className="space-y-6">
      {/* Performance Index */}
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <h3 className="text-xl font-bold text-[#C8A882] mb-4">
          MMA Performance Index
        </h3>
        <div className="flex items-center justify-center">
          <div className="text-6xl font-bold text-white">
            {mmaPerformanceIndex}
          </div>
          <div className="ml-4 text-gray-400">/ 100</div>
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="Striking Accuracy"
          value={metrics.strikingAccuracy}
          unit="%"
        />
        <MetricCard
          title="Grappling Control"
          value={metrics.grapplingControl}
          unit=""
        />
        <MetricCard
          title="Takedown Defense"
          value={metrics.takedownDefense}
          unit="%"
        />
        <MetricCard
          title="Submission Attempts"
          value={metrics.submissionAttempts}
          unit=""
        />
        <MetricCard title="Cage Control" value={metrics.cageControl} unit="" />
        <MetricCard
          title="Transition Speed"
          value={metrics.transitionSpeed}
          unit=""
        />
        <MetricCard
          title="Ground & Pound"
          value={metrics.groundAndPound}
          unit=""
        />
        <MetricCard title="Cardio" value={metrics.cardio} unit="" />
      </div>

      {/* Fight Statistics */}
      {fightStats && (
        <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
          <h4 className="text-lg font-bold text-[#C8A882] mb-4">
            Fight Statistics
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="text-gray-400">Significant Strikes</div>
              <div className="text-2xl font-bold text-white">
                {fightStats.significantStrikes}
              </div>
            </div>
            <div>
              <div className="text-gray-400">Takedowns</div>
              <div className="text-2xl font-bold text-white">
                {fightStats.takedowns}
              </div>
            </div>
            <div>
              <div className="text-gray-400">Submissions</div>
              <div className="text-2xl font-bold text-white">
                {fightStats.submissions}
              </div>
            </div>
            <div>
              <div className="text-gray-400">Control Time</div>
              <div className="text-2xl font-bold text-white">
                {fightStats.controlTime}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Round Breakdown */}
      {roundBreakdown && roundBreakdown.length > 0 && (
        <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
          <h4 className="text-lg font-bold text-[#C8A882] mb-4">
            Round-by-Round Breakdown
          </h4>
          <div className="space-y-3">
            {roundBreakdown.map((round, index) => (
              <div key={index} className="bg-[#152E45] rounded-lg p-4">
                <div className="text-white font-semibold mb-2">
                  Round {round.round}
                </div>
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <div className="text-gray-400 text-xs">Striking</div>
                    <div className="text-lg font-bold text-white">
                      {round.striking}
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs">Grappling</div>
                    <div className="text-lg font-bold text-white">
                      {round.grappling}
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs">Control</div>
                    <div className="text-lg font-bold text-white">
                      {round.control}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Coaching Cues */}
      {coachingCues && coachingCues.length > 0 && (
        <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
          <h4 className="text-lg font-bold text-[#C8A882] mb-4">
            Coaching Cues
          </h4>
          <ul className="space-y-2">
            {coachingCues.map((cue, index) => (
              <li key={index} className="flex items-start gap-2 text-gray-300">
                <span className="text-[#C8A882] mt-1">▸</span>
                <span>{cue}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function MetricCard({ title, value, unit }) {
  const getColorClass = (val) => {
    if (val >= 80) return "text-green-400";
    if (val >= 60) return "text-yellow-400";
    return "text-orange-400";
  };

  return (
    <div className="bg-[#152E45] rounded-lg p-4 border border-gray-700">
      <div className="text-xs text-gray-400 mb-1">{title}</div>
      <div className={`text-2xl font-bold ${getColorClass(value)}`}>
        {value}
        {unit}
      </div>
    </div>
  );
}
