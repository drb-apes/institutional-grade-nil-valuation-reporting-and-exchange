"use client";

import {
  LineChart,
  Line,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, Shield, Award, Heart, Star, Zap } from "lucide-react";

// A. NIL Valuation Progression Chart
export function NILValuationProgressionChart({ data }) {
  const defaultData = data || [
    { age: 14, model: 5.2, market: 0 },
    { age: 15, model: 12.8, market: 0 },
    { age: 16, model: 24.5, market: 0 },
    { age: 17, model: 38.9, market: 0 },
    { age: 18, model: 52.3, market: 45.0 },
    { age: 19, model: 68.7, market: 72.4 },
    { age: 20, model: 89.2, market: 95.8 },
    { age: 21, model: 112.5, market: 125.3 },
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-[#C8A882] rounded-lg flex items-center justify-center">
          <TrendingUp className="text-[#1B3A57]" size={20} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">
            NIL Valuation Progression
          </h3>
          <p className="text-[#D4B896] text-sm">
            Youth → Adult → Market NIL Growth
          </p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={defaultData}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis
            dataKey="age"
            stroke="#D4B896"
            label={{
              value: "Age",
              position: "insideBottom",
              offset: -5,
              fill: "#D4B896",
            }}
          />
          <YAxis
            stroke="#D4B896"
            label={{
              value: "NIL Value ($K)",
              angle: -90,
              position: "insideLeft",
              fill: "#D4B896",
            }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#1B3A57",
              border: "1px solid #C8A882",
              borderRadius: "8px",
              color: "#fff",
            }}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="model"
            stroke="#C8A882"
            strokeWidth={3}
            name="Model NIL (Youth-Safe)"
            dot={{ fill: "#C8A882", r: 5 }}
          />
          <Line
            type="monotone"
            dataKey="market"
            stroke="#D4B896"
            strokeWidth={3}
            strokeDasharray="5 5"
            name="Market NIL (Pro)"
            dot={{ fill: "#D4B896", r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
      <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-3 h-3 bg-[#C8A882] rounded-full" />
            <span className="text-white font-medium">Model NIL</span>
          </div>
          <p className="text-[#D4B896] text-xs">
            Development-focused, non-monetary valuation
          </p>
        </div>
        <div className="bg-white/5 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-3 h-3 bg-[#D4B896] rounded-full" />
            <span className="text-white font-medium">Market NIL</span>
          </div>
          <p className="text-[#D4B896] text-xs">
            Commercial valuation at age 18+
          </p>
        </div>
      </div>
    </div>
  );
}

// B. Risk-Adjusted Performance Dashboard
export function RiskAdjustedPerformanceDashboard({ data }) {
  const defaultData = data || [
    { metric: "Consistency", value: 85, fullMark: 100 },
    { metric: "Volatility Control", value: 72, fullMark: 100 },
    { metric: "Difficulty", value: 68, fullMark: 100 },
    { metric: "Engagement", value: 92, fullMark: 100 },
    { metric: "Recovery", value: 78, fullMark: 100 },
    { metric: "Performance", value: 88, fullMark: 100 },
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-[#C8A882] rounded-lg flex items-center justify-center">
          <Shield className="text-[#1B3A57]" size={20} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">
            Risk-Adjusted Performance
          </h3>
          <p className="text-[#D4B896] text-sm">
            Multi-dimensional athlete profile
          </p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={350}>
        <RadarChart data={defaultData}>
          <PolarGrid stroke="rgba(255,255,255,0.2)" />
          <PolarAngleAxis
            dataKey="metric"
            stroke="#D4B896"
            tick={{ fill: "#D4B896", fontSize: 12 }}
          />
          <PolarRadiusAxis
            angle={90}
            domain={[0, 100]}
            stroke="#D4B896"
            tick={{ fill: "#D4B896" }}
          />
          <Radar
            name="Performance Score"
            dataKey="value"
            stroke="#C8A882"
            fill="#C8A882"
            fillOpacity={0.6}
            strokeWidth={2}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#1B3A57",
              border: "1px solid #C8A882",
              borderRadius: "8px",
              color: "#fff",
            }}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

// D. Boost Credits Chart
export function BoostCreditsChart({ data }) {
  const defaultData = data || [
    { athlete: "Sarah C.", boosts: 247 },
    { athlete: "Marcus J.", boosts: 189 },
    { athlete: "Emily R.", boosts: 156 },
    { athlete: "Jordan L.", boosts: 142 },
    { athlete: "Taylor B.", boosts: 128 },
    { athlete: "Alex M.", boosts: 115 },
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-[#C8A882] rounded-lg flex items-center justify-center">
          <Heart className="text-[#1B3A57]" size={20} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">
            Boost Credits by Athlete
          </h3>
          <p className="text-[#D4B896] text-sm">Fan engagement volume</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={defaultData}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis
            dataKey="athlete"
            stroke="#D4B896"
            tick={{ fill: "#D4B896", fontSize: 12 }}
          />
          <YAxis stroke="#D4B896" tick={{ fill: "#D4B896" }} />
          <Tooltip
            contentStyle={{
              backgroundColor: "#1B3A57",
              border: "1px solid #C8A882",
              borderRadius: "8px",
              color: "#fff",
            }}
          />
          <Bar dataKey="boosts" fill="#C8A882" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// E. Kid-Friendly Model NIL Visual
export function KidFriendlyNILVisual({ athlete }) {
  const badges = [
    { icon: "⭐", label: "Welcome", active: true },
    { icon: "🏆", label: "First Highlight", active: true },
    { icon: "📊", label: "Verified Metrics", active: true },
    { icon: "📖", label: "Storyline Arc", active: false },
    { icon: "🎯", label: "Pro Ready", active: false },
  ];

  const storylineProgress = 60;

  return (
    <div className="bg-gradient-to-br from-[#C8A882]/20 to-[#C8A882]/5 rounded-xl p-6 border border-[#C8A882]/30">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-[#C8A882] rounded-lg flex items-center justify-center">
          <Star className="text-[#1B3A57]" size={20} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Achievement Journey</h3>
          <p className="text-[#D4B896] text-sm">
            Kid-friendly progress tracker
          </p>
        </div>
      </div>

      {/* Badge Collection */}
      <div className="grid grid-cols-5 gap-3 mb-6">
        {badges.map((badge, idx) => (
          <div
            key={idx}
            className={`text-center p-4 rounded-lg transition-all ${
              badge.active
                ? "bg-white/10 border border-[#C8A882]"
                : "bg-white/5 border border-white/10 opacity-50"
            }`}
          >
            <div className="text-4xl mb-2">{badge.icon}</div>
            <p
              className={`text-xs font-medium ${badge.active ? "text-[#C8A882]" : "text-[#D4B896]"}`}
            >
              {badge.label}
            </p>
          </div>
        ))}
      </div>

      {/* Storyline Progress */}
      <div className="bg-white/10 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-white font-medium">Your Storyline</span>
          <span className="text-[#C8A882] font-bold">{storylineProgress}%</span>
        </div>
        <div className="w-full bg-white/20 rounded-full h-4 overflow-hidden">
          <div
            className="bg-gradient-to-r from-[#C8A882] to-[#D4B896] h-4 rounded-full transition-all duration-500 flex items-center justify-end pr-2"
            style={{ width: `${storylineProgress}%` }}
          >
            <span className="text-[#1B3A57] text-xs font-bold">🚀</span>
          </div>
        </div>
        <p className="text-[#D4B896] text-xs mt-2 text-center">
          Keep going! Next milestone: Storyline Arc 📖
        </p>
      </div>
    </div>
  );
}

// C. Fan Tipping Flow (Simplified Sankey alternative)
export function FanTippingFlow({ data }) {
  const flowData = data || {
    totalBoosts: 5834,
    nilMoments: 3245,
    sponsorBonuses: 1289,
    athleteRewards: 1956,
  };

  const stages = [
    {
      label: "Fan Boosts",
      value: flowData.totalBoosts,
      color: "#C8A882",
      icon: "👏",
    },
    {
      label: "NIL Moments",
      value: flowData.nilMoments,
      color: "#D4B896",
      icon: "⭐",
    },
    {
      label: "Sponsor Bonuses",
      value: flowData.sponsorBonuses,
      color: "#E8DCC8",
      icon: "💰",
    },
    {
      label: "Athlete Rewards",
      value: flowData.athleteRewards,
      color: "#C8A882",
      icon: "🏆",
    },
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-[#C8A882] rounded-lg flex items-center justify-center">
          <Zap className="text-[#1B3A57]" size={20} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Fan Engagement Flow</h3>
          <p className="text-[#D4B896] text-sm">
            Boosts → Moments → Bonuses → Rewards
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {stages.map((stage, idx) => (
          <div key={idx}>
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-lg flex items-center justify-center text-3xl"
                style={{ backgroundColor: `${stage.color}40` }}
              >
                {stage.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-semibold">
                    {stage.label}
                  </span>
                  <span className="text-[#C8A882] font-bold text-lg">
                    {stage.value.toLocaleString()}
                  </span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                  <div
                    className="h-3 rounded-full transition-all"
                    style={{
                      width: `${(stage.value / flowData.totalBoosts) * 100}%`,
                      backgroundColor: stage.color,
                    }}
                  />
                </div>
              </div>
            </div>
            {idx < stages.length - 1 && (
              <div className="ml-8 my-2">
                <div className="w-0.5 h-6 bg-gradient-to-b from-[#C8A882] to-[#D4B896]" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
