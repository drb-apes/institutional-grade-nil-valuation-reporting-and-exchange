"use client";

import { useState, useEffect } from "react";
import { Target, Zap, TrendingUp, Activity } from "lucide-react";

export default function WrestlingPerformanceDashboard({
  athleteId,
  sessionId,
}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (athleteId) {
      fetchWrestlingData();
    }
  }, [athleteId, sessionId]);

  async function fetchWrestlingData() {
    try {
      setLoading(true);
      const response = await fetch(
        "/api/sport-specific/wrestling/performance-tracking",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            athlete_id: athleteId,
            session_id: sessionId || "current",
            match_data: {
              takedowns_attempted: 12,
              takedowns_successful: 8,
              grip_force_peak_n: 450,
              stance_stability_score: 82,
              explosive_power_index: 88,
              technique_precision_pct: 76,
              match_duration_seconds: 360,
            },
          }),
        },
      );

      if (!response.ok) throw new Error("Failed to fetch wrestling data");
      const result = await response.json();
      setData(result);
    } catch (error) {
      console.error("Wrestling data fetch error:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="bg-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="animate-pulse flex space-x-4">
          <div className="flex-1 space-y-4 py-1">
            <div className="h-4 bg-[#1B3A57] rounded w-3/4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-[#1B3A57] rounded"></div>
              <div className="h-4 bg-[#1B3A57] rounded w-5/6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="bg-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-3">
          🤼 Wrestling Performance Analysis
        </h2>
        <div className="bg-[#C8A882] px-4 py-2 rounded text-[#1B3A57] font-bold">
          Index: {data.wrestling_performance_index}
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <MetricCard
          icon={<Target className="w-5 h-5 text-[#C8A882]" />}
          label="Takedown Efficiency"
          value={`${data.takedown_efficiency}%`}
          color={
            data.takedown_efficiency > 60 ? "text-green-400" : "text-amber-400"
          }
        />
        <MetricCard
          icon={<Zap className="w-5 h-5 text-[#C8A882]" />}
          label="Explosive Power"
          value={data.explosive_power_index}
          color="text-white"
        />
        <MetricCard
          icon={<Activity className="w-5 h-5 text-[#C8A882]" />}
          label="Stance Stability"
          value={data.stance_stability_score}
          color="text-white"
        />
        <MetricCard
          icon={<TrendingUp className="w-5 h-5 text-[#C8A882]" />}
          label="Technique Precision"
          value={`${data.technique_precision_pct}%`}
          color="text-white"
        />
      </div>

      {/* Coaching Cues */}
      {data.coaching_cues && data.coaching_cues.length > 0 && (
        <div className="bg-[#1B3A57] rounded-lg p-4 border border-[#C8A882]/30">
          <h3 className="text-white font-bold mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-[#C8A882]" />
            Real-Time Coaching Cues
          </h3>
          <div className="space-y-3">
            {data.coaching_cues.map((cue, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <span
                  className={`px-2 py-1 rounded text-xs font-bold ${
                    cue.priority === "high"
                      ? "bg-red-500/20 text-red-400"
                      : cue.priority === "medium"
                        ? "bg-amber-500/20 text-amber-400"
                        : "bg-blue-500/20 text-blue-400"
                  }`}
                >
                  {cue.priority}
                </span>
                <div className="flex-1">
                  <p className="text-white text-sm">{cue.cue}</p>
                  <p className="text-gray-400 text-xs mt-1">
                    Target: {cue.target} {cue.metric}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Grip Force Visualization */}
      <div className="mt-6">
        <h3 className="text-white font-bold mb-3">Grip Force Peak</h3>
        <div className="bg-[#1B3A57] rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400 text-sm">Force (Newtons)</span>
            <span className="text-white font-bold">
              {data.grip_force_peak_n}N
            </span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-[#C8A882] to-[#D4B896] h-3 rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(100, (data.grip_force_peak_n / 500) * 100)}%`,
              }}
            />
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>0N</span>
            <span>500N</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ icon, label, value, color }) {
  return (
    <div className="bg-[#1B3A57] rounded-lg p-4 border border-[#C8A882]/20">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-gray-400 text-xs">{label}</span>
      </div>
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
    </div>
  );
}
