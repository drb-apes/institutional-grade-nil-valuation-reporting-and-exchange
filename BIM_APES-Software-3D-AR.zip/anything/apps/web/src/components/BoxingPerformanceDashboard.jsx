"use client";

import { useState, useEffect } from "react";

export default function BoxingPerformanceDashboard({ fightData }) {
  const [performanceMetrics, setPerformanceMetrics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (fightData) {
      fetchPerformanceMetrics();
    }
  }, [fightData]);

  async function fetchPerformanceMetrics() {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        "/api/sport-specific/boxing/performance-tracking",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(fightData),
        },
      );

      if (!response.ok) {
        throw new Error("Failed to fetch boxing performance metrics");
      }

      const data = await response.json();
      setPerformanceMetrics(data);
    } catch (err) {
      console.error("Error fetching boxing metrics:", err);
      setError(err.message);
      // Use mock data on error
      setPerformanceMetrics(getMockBoxingMetrics());
    } finally {
      setLoading(false);
    }
  }

  function getMockBoxingMetrics() {
    return {
      boxingPerformanceIndex: 84,
      metrics: {
        punchAccuracy: 68,
        punchPower: 82,
        handSpeed: 76,
        footwork: 71,
        headMovement: 79,
        ringControl: 74,
        staminaManagement: 80,
        defensiveEfficiency: 77,
      },
      coachingCues: [
        "Maintain hand speed in later rounds",
        "Improve jab accuracy",
        "Watch opponent's left hook counter",
        "Control ring center more effectively",
      ],
      roundScores: [10, 9, 10, 9, 10, 9, 10, 9],
      punchStats: {
        totalThrown: 524,
        totalLanded: 356,
        powerPunchesLanded: 142,
        jabsLanded: 214,
      },
    };
  }

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center py-8">
          <div className="text-[#C8A882] font-semibold">
            Loading boxing metrics...
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center py-8">
          <div className="text-red-400 font-semibold">Error: {error}</div>
        </div>
      </div>
    );
  }

  if (!performanceMetrics) {
    return (
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center py-8">
          <div className="text-gray-400">No boxing data available</div>
        </div>
      </div>
    );
  }

  const {
    boxingPerformanceIndex,
    metrics,
    coachingCues,
    roundScores,
    punchStats,
  } = performanceMetrics;

  return (
    <div className="space-y-6">
      {/* Performance Index */}
      <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <h3 className="text-xl font-bold text-[#C8A882] mb-4">
          Boxing Performance Index
        </h3>
        <div className="flex items-center justify-center">
          <div className="text-6xl font-bold text-white">
            {boxingPerformanceIndex}
          </div>
          <div className="ml-4 text-gray-400">/ 100</div>
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="Punch Accuracy"
          value={metrics.punchAccuracy}
          unit="%"
        />
        <MetricCard title="Punch Power" value={metrics.punchPower} unit="" />
        <MetricCard title="Hand Speed" value={metrics.handSpeed} unit="" />
        <MetricCard title="Footwork" value={metrics.footwork} unit="" />
        <MetricCard
          title="Head Movement"
          value={metrics.headMovement}
          unit=""
        />
        <MetricCard title="Ring Control" value={metrics.ringControl} unit="" />
        <MetricCard title="Stamina" value={metrics.staminaManagement} unit="" />
        <MetricCard
          title="Defense"
          value={metrics.defensiveEfficiency}
          unit=""
        />
      </div>

      {/* Punch Statistics */}
      {punchStats && (
        <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
          <h4 className="text-lg font-bold text-[#C8A882] mb-4">
            Punch Statistics
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="text-gray-400">Total Thrown</div>
              <div className="text-2xl font-bold text-white">
                {punchStats.totalThrown}
              </div>
            </div>
            <div>
              <div className="text-gray-400">Total Landed</div>
              <div className="text-2xl font-bold text-white">
                {punchStats.totalLanded}
              </div>
            </div>
            <div>
              <div className="text-gray-400">Power Punches</div>
              <div className="text-2xl font-bold text-white">
                {punchStats.powerPunchesLanded}
              </div>
            </div>
            <div>
              <div className="text-gray-400">Jabs Landed</div>
              <div className="text-2xl font-bold text-white">
                {punchStats.jabsLanded}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Round Scores */}
      {roundScores && roundScores.length > 0 && (
        <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
          <h4 className="text-lg font-bold text-[#C8A882] mb-4">
            Round-by-Round Scores
          </h4>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {roundScores.map((score, index) => (
              <div
                key={index}
                className={`flex-shrink-0 w-16 h-16 rounded-lg flex flex-col items-center justify-center border ${
                  score === 10
                    ? "bg-green-500/20 border-green-500"
                    : "bg-[#152E45] border-gray-600"
                }`}
              >
                <div className="text-xs text-gray-400">R{index + 1}</div>
                <div className="text-2xl font-bold text-white">{score}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Coaching Cues */}
      {coachingCues && coachingCues.length > 0 && (
        <div className="bg-gradient-to-br from-[#1B3A57] to-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
          <h4 className="text-lg font-bold text-[#C8A882] mb-4">
            Coaching Cues
          </h4>
          <ul className="space-y-2">
            {coachingCues.map((cue, index) => (
              <li key={index} className="flex items-start gap-2 text-gray-300">
                <span className="text-[#C8A882] mt-1">▸</span>
                <span>{cue}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function MetricCard({ title, value, unit }) {
  const getColorClass = (val) => {
    if (val >= 80) return "text-green-400";
    if (val >= 60) return "text-yellow-400";
    return "text-orange-400";
  };

  return (
    <div className="bg-[#152E45] rounded-lg p-4 border border-gray-700">
      <div className="text-xs text-gray-400 mb-1">{title}</div>
      <div className={`text-2xl font-bold ${getColorClass(value)}`}>
        {value}
        {unit}
      </div>
    </div>
  );
}
