"use client";

import { useState, useEffect } from "react";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Clock,
  AlertCircle,
} from "lucide-react";

export default function TradingDashboard({ athleteId }) {
  const [mispricingData, setMispricingData] = useState(null);
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (athleteId) {
      fetchTradingData();
      const interval = setInterval(fetchTradingData, 5000); // Update every 5s
      return () => clearInterval(interval);
    }
  }, [athleteId]);

  async function fetchTradingData() {
    try {
      // Fetch mispricing detection
      const mispricingRes = await fetch("/api/trading/detect-mispricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ athlete_id: athleteId }),
      });

      if (mispricingRes.ok) {
        const mispricing = await mispricingRes.json();
        setMispricingData(mispricing);
      }

      // Fetch active positions (would need a real endpoint)
      // For now, using mock data
      setPositions([
        {
          id: 1,
          athlete_name: "John Doe",
          position_type: "long",
          strategy: "arbitrage",
          entry_price: 95000,
          current_price: 98500,
          size: 10,
          pnl: 35000,
          pnl_pct: 3.68,
          status: "open",
        },
      ]);
    } catch (error) {
      console.error("Trading data fetch error:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="bg-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center text-gray-400">Loading trading data...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Mispricing Detection */}
      {mispricingData?.mispriced && (
        <div className="bg-[#152E45] rounded-lg p-6 border-2 border-[#C8A882]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-[#C8A882]" />
              Active Mispricing Window
            </h2>
            <span
              className={`px-4 py-2 rounded font-bold ${
                mispricingData.event_type === "major_mispricing"
                  ? "bg-red-500/20 text-red-400"
                  : mispricingData.event_type === "standard_mispricing"
                    ? "bg-amber-500/20 text-amber-400"
                    : "bg-blue-500/20 text-blue-400"
              }`}
            >
              {mispricingData.event_type.replace("_", " ").toUpperCase()}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <TradingMetricCard
              label="Gap"
              value={`${mispricingData.gap_pct}%`}
              icon={<TrendingUp className="w-5 h-5 text-[#C8A882]" />}
              color="text-white"
            />
            <TradingMetricCard
              label="Direction"
              value={mispricingData.direction.toUpperCase()}
              icon={
                mispricingData.direction === "long" ? (
                  <TrendingUp className="w-5 h-5 text-green-400" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-400" />
                )
              }
              color={
                mispricingData.direction === "long"
                  ? "text-green-400"
                  : "text-red-400"
              }
            />
            <TradingMetricCard
              label="Confidence"
              value={`${(mispricingData.confidence * 100).toFixed(0)}%`}
              icon={<DollarSign className="w-5 h-5 text-[#C8A882]" />}
              color="text-white"
            />
            <TradingMetricCard
              label="TTL"
              value={`${Math.floor(mispricingData.ttl_seconds / 60)}m ${mispricingData.ttl_seconds % 60}s`}
              icon={<Clock className="w-5 h-5 text-[#C8A882]" />}
              color="text-white"
            />
          </div>

          {/* Trade Recommendation */}
          {mispricingData.trade_recommendation && (
            <div className="bg-[#1B3A57] rounded-lg p-4 border border-[#C8A882]/30">
              <h3 className="text-white font-bold mb-3">
                Trade Recommendation
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-400 block mb-1">Action</span>
                  <span
                    className={`font-bold ${
                      mispricingData.trade_recommendation.action === "BUY"
                        ? "text-green-400"
                        : "text-red-400"
                    }`}
                  >
                    {mispricingData.trade_recommendation.action}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block mb-1">Strategy</span>
                  <span className="text-white font-bold">
                    {mispricingData.trade_recommendation.strategy}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block mb-1">
                    Size Multiplier
                  </span>
                  <span className="text-white font-bold">
                    {mispricingData.trade_recommendation.size_multiplier}x
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block mb-1">Stop Loss</span>
                  <span className="text-red-400 font-bold">
                    {mispricingData.trade_recommendation.stop_loss_pct}%
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block mb-1">Take Profit</span>
                  <span className="text-green-400 font-bold">
                    {mispricingData.trade_recommendation.take_profit_pct}%
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block mb-1">Urgency</span>
                  <span
                    className={`font-bold ${
                      mispricingData.trade_recommendation.urgency === "high"
                        ? "text-red-400"
                        : "text-amber-400"
                    }`}
                  >
                    {mispricingData.trade_recommendation.urgency}
                  </span>
                </div>
              </div>

              <button className="w-full mt-4 bg-[#C8A882] hover:bg-[#B8956A] text-[#1B3A57] font-bold py-3 rounded transition">
                Execute Trade
              </button>
            </div>
          )}
        </div>
      )}

      {/* Active Positions */}
      <div className="bg-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-3">
          <DollarSign className="w-6 h-6 text-[#C8A882]" />
          Active Positions
        </h2>

        {positions.length === 0 ? (
          <p className="text-gray-400 text-center py-4">No active positions</p>
        ) : (
          <div className="space-y-4">
            {positions.map((position) => (
              <PositionCard key={position.id} position={position} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TradingMetricCard({ label, value, icon, color }) {
  return (
    <div className="bg-[#1B3A57] rounded-lg p-4 border border-[#C8A882]/20">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-gray-400 text-xs">{label}</span>
      </div>
      <div className={`text-xl font-bold ${color}`}>{value}</div>
    </div>
  );
}

function PositionCard({ position }) {
  const pnlColor = position.pnl >= 0 ? "text-green-400" : "text-red-400";

  return (
    <div className="bg-[#1B3A57] rounded-lg p-4 border border-[#C8A882]/30">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-white font-bold">{position.athlete_name}</h3>
          <p className="text-gray-400 text-sm">
            {position.strategy} • {position.position_type}
          </p>
        </div>
        <div className="text-right">
          <div className={`text-xl font-bold ${pnlColor}`}>
            {position.pnl >= 0 ? "+" : ""}
            {position.pnl.toLocaleString()}
          </div>
          <div className={`text-sm ${pnlColor}`}>
            {position.pnl_pct >= 0 ? "+" : ""}
            {position.pnl_pct.toFixed(2)}%
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 text-sm">
        <div>
          <span className="text-gray-400 block">Entry</span>
          <span className="text-white font-bold">
            ${position.entry_price.toLocaleString()}
          </span>
        </div>
        <div>
          <span className="text-gray-400 block">Current</span>
          <span className="text-white font-bold">
            ${position.current_price.toLocaleString()}
          </span>
        </div>
        <div>
          <span className="text-gray-400 block">Size</span>
          <span className="text-white font-bold">{position.size}</span>
        </div>
      </div>

      <button className="w-full mt-3 bg-red-500/20 hover:bg-red-500/30 text-red-400 font-bold py-2 rounded transition">
        Close Position
      </button>
    </div>
  );
}
