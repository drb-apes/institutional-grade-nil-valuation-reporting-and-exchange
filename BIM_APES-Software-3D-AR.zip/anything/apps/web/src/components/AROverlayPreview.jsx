"use client";

import { useState, useEffect } from "react";
import { Eye, Activity, Target } from "lucide-react";

export default function AROverlayPreview({
  athleteId,
  displayMode: initialDisplayMode = "mobile",
}) {
  const [arPackage, setArPackage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [displayMode, setDisplayMode] = useState(initialDisplayMode);

  useEffect(() => {
    if (athleteId) {
      fetchARPackage();
      const interval = setInterval(fetchARPackage, 3000); // Update every 3s
      return () => clearInterval(interval);
    }
  }, [athleteId, displayMode]);

  async function fetchARPackage() {
    try {
      const response = await fetch("/api/broadcast/ar-package", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: athleteId,
          display_mode: displayMode,
        }),
      });

      if (!response.ok) throw new Error("Failed to fetch AR package");
      const data = await response.json();
      setArPackage(data);
    } catch (error) {
      console.error("AR package fetch error:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading || !arPackage) {
    return (
      <div className="bg-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
        <div className="text-center text-gray-400">Loading AR overlay...</div>
      </div>
    );
  }

  const {
    frame,
    components,
    medical_overlay,
    coaching_overlay,
    trade_signals,
  } = arPackage;

  return (
    <div className="bg-[#152E45] rounded-lg p-6 border border-[#C8A882]/20">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-3">
          <Eye className="w-6 h-6 text-[#C8A882]" />
          AR Overlay Preview
        </h2>
        <div className="flex gap-2">
          <button
            onClick={() => setDisplayMode("mobile")}
            className={`px-3 py-1 rounded text-sm font-bold transition ${
              displayMode === "mobile"
                ? "bg-[#C8A882] text-[#1B3A57]"
                : "bg-[#1B3A57] text-gray-400"
            }`}
          >
            Mobile
          </button>
          <button
            onClick={() => setDisplayMode("stadium")}
            className={`px-3 py-1 rounded text-sm font-bold transition ${
              displayMode === "stadium"
                ? "bg-[#C8A882] text-[#1B3A57]"
                : "bg-[#1B3A57] text-gray-400"
            }`}
          >
            Stadium
          </button>
        </div>
      </div>

      {/* AR Canvas */}
      <div
        className="bg-black rounded-lg overflow-hidden relative"
        style={{
          width: displayMode === "mobile" ? "390px" : "100%",
          height: displayMode === "mobile" ? "400px" : "600px",
          maxWidth: "100%",
          margin: "0 auto",
        }}
      >
        {/* Medical Banner */}
        {medical_overlay?.visible && (
          <div
            className="absolute top-0 left-0 right-0 px-4 py-2 text-white font-bold text-center z-50"
            style={{
              backgroundColor: medical_overlay.banner_color,
              opacity: 0.9,
            }}
          >
            ⚠️ {medical_overlay.risk_level.toUpperCase()} RISK -{" "}
            {medical_overlay.risk_score.toFixed(0)}
          </div>
        )}

        {/* Value Bar */}
        {components.value_bar?.visible && (
          <div className="absolute top-12 left-4 right-4 bg-[#1B3A57]/90 rounded-lg p-3 border border-[#C8A882]/50">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-gray-400 text-xs block">True Value</span>
                <span className="text-white font-bold text-lg">
                  ${components.value_bar.TV.toLocaleString()}
                </span>
              </div>
              <div className="flex-1 mx-4">
                <div className="h-2 bg-gray-700 rounded-full relative">
                  <div
                    className="absolute h-2 rounded-full transition-all duration-500"
                    style={{
                      width: "50%",
                      backgroundColor: components.value_bar.gap_color,
                    }}
                  />
                </div>
                <div className="text-center mt-1">
                  <span
                    className="font-bold text-sm"
                    style={{ color: components.value_bar.gap_color }}
                  >
                    Gap: {frame.gap.toFixed(0)}
                  </span>
                </div>
              </div>
              <div>
                <span className="text-gray-400 text-xs block">
                  Market Value
                </span>
                <span className="text-white font-bold text-lg">
                  ${components.value_bar.MV.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Athlete Portrait */}
        <div className="absolute top-32 left-1/2 transform -translate-x-1/2">
          <div className="relative">
            {/* Spread Ring */}
            {components.spread_ring?.visible && (
              <div
                className="absolute inset-0 rounded-full border-4"
                style={{
                  borderColor: components.spread_ring.color,
                  borderWidth: `${Math.max(2, components.spread_ring.gap_norm * 10)}px`,
                  width: "200px",
                  height: "200px",
                  top: "-10px",
                  left: "-10px",
                  animation: "pulse 2s infinite",
                }}
              />
            )}

            {/* Portrait */}
            <div className="w-48 h-48 rounded-full bg-gradient-to-br from-[#C8A882] to-[#D4B896] flex items-center justify-center border-4 border-white/20">
              <Activity className="w-20 h-20 text-white" />
            </div>

            {/* Stability Badge */}
            {components.stability_badge?.visible && (
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-[#1B3A57]/95 px-4 py-2 rounded-full border border-[#C8A882]/50">
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-gray-400">CLi:</span>
                  <span
                    className={`font-bold ${components.stability_badge.jitter ? "text-red-400" : "text-green-400"}`}
                  >
                    {(components.stability_badge.CLi * 100).toFixed(0)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Momentum Arrow */}
        {components.momentum_arrow?.visible && (
          <div className="absolute bottom-32 left-1/2 transform -translate-x-1/2 text-center">
            <Target
              className={`w-8 h-8 mx-auto mb-1 ${
                components.momentum_arrow.vector === "up"
                  ? "text-green-400"
                  : "text-red-400"
              }`}
            />
            <span className="text-xs font-bold text-white">
              {(components.momentum_arrow.intensity * 100).toFixed(0)}% Momentum
            </span>
          </div>
        )}

        {/* Trade Signals */}
        {trade_signals?.visible && (
          <div className="absolute bottom-4 left-4 right-4 bg-[#1B3A57]/95 rounded-lg p-3 border-2 border-[#C8A882]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-3 h-3 rounded-full ${
                    trade_signals.action === "BUY"
                      ? "bg-green-400"
                      : "bg-red-400"
                  }`}
                  style={{ animation: "pulse 1s infinite" }}
                />
                <span className="text-white font-bold">
                  {trade_signals.action} SIGNAL
                </span>
              </div>
              <div className="text-right">
                <span className="text-gray-400 text-xs block">TTL</span>
                <span className="text-[#C8A882] font-bold text-sm">
                  {Math.floor(trade_signals.ttl_seconds / 60)}m{" "}
                  {trade_signals.ttl_seconds % 60}s
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Coaching Overlay */}
        {coaching_overlay?.visible && coaching_overlay.cues?.length > 0 && (
          <div className="absolute top-1/2 right-4 transform -translate-y-1/2 w-64 space-y-2">
            {coaching_overlay.cues.map((cue, idx) => (
              <div
                key={idx}
                className={`bg-[#1B3A57]/95 rounded-lg p-3 border-l-4 ${
                  cue.priority === "high"
                    ? "border-red-400"
                    : cue.priority === "medium"
                      ? "border-amber-400"
                      : "border-blue-400"
                }`}
              >
                <p className="text-white text-sm">{cue.message}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Overlay Stats */}
      <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
        <div className="bg-[#1B3A57] rounded p-3">
          <span className="text-gray-400 block mb-1">Confidence</span>
          <span className="text-white font-bold">
            {(frame.confidence * 100).toFixed(0)}%
          </span>
        </div>
        <div className="bg-[#1B3A57] rounded p-3">
          <span className="text-gray-400 block mb-1">Convexity</span>
          <span className="text-[#C8A882] font-bold">
            {(frame.CF * 100).toFixed(0)}
          </span>
        </div>
        <div className="bg-[#1B3A57] rounded p-3">
          <span className="text-gray-400 block mb-1">Momentum</span>
          <span className="text-white font-bold">
            {(frame.momentum_intensity * 100).toFixed(0)}%
          </span>
        </div>
      </div>

      <style jsx global>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
}
