import { Mail, Linkedin } from "lucide-react";

/**
 * BIM-APES Footer Component
 *
 * Contains licensing information, copyright notice, and contact details
 * for NIBLS Inc. and Bledsoe Investment Management
 */
export default function Footer() {
  const dashboardLinks = [
    { label: "Intelligence Dashboard", href: "/intelligence-dashboard" },
    { label: "Coach Dashboard", href: "/coach-dashboard" },
    { label: "Investor Dashboard", href: "/investor-dashboard" },
    { label: "Federation Dashboard", href: "/federation-dashboard" },
    { label: "Sponsor ROI Dashboard", href: "/sponsor-roi-dashboard" },
    { label: "Medical Dashboard", href: "/console/medical-dashboard" },
    { label: "Broadcast Control", href: "/broadcast-control" },
    { label: "XR Performance Lab", href: "/xr-lab" },
    { label: "Console", href: "/console" },
  ];

  return (
    <footer className="bg-[#1B3A57] text-white py-12 mt-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Dashboard Quick Links */}
        <div className="mb-10">
          <h3 className="text-sm font-bold text-[#C8A882] uppercase tracking-widest mb-4">
            Platform Dashboards
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {dashboardLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-xs text-white/70 hover:text-[#C8A882] transition-colors no-underline py-1"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        <div className="border-t border-white/10 mb-10"></div>

        {/* Main Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {/* Left Column */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-[#C8A882]">
              Licensing Information
            </h3>
            <div className="space-y-4 text-sm text-white/90">
              <div>
                <p className="font-semibold mb-1">Software License:</p>
                <p>
                  Portions of this application are licensed under the{" "}
                  <a
                    href="http://www.apache.org/licenses/LICENSE-2.0"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#C8A882] hover:underline"
                  >
                    Apache License, Version 2.0
                  </a>
                  .
                </p>
              </div>

              <div>
                <p className="font-semibold mb-1">Content License:</p>
                <p>
                  All non-software content—including reports, visualizations,
                  branding, and documentation—is licensed under the{" "}
                  <a
                    href="https://creativecommons.org/licenses/by-nc-nd/4.0/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#C8A882] hover:underline"
                  >
                    Creative Commons Attribution–NonCommercial–NoDerivatives 4.0
                    International License
                  </a>
                  .
                </p>
              </div>

              <div>
                <p className="font-semibold mb-1">Trademark & Authorization:</p>
                <p>
                  Use of trademarks, NIL valuation models, or proprietary
                  biomechanical intelligence requires written authorization from
                  NIBLS Inc.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-[#C8A882]">
              Enterprise Partnerships
            </h3>

            <div className="space-y-4 text-sm text-white/90">
              <p>
                For enterprise partnerships, NIL valuation integrations,
                sponsorship platforms, or commercial licensing of BIM-APES
                Software, contact:
              </p>

              <div className="bg-white/10 rounded-lg p-4 border border-[#C8A882]/30">
                <p className="font-bold text-white mb-3">
                  NIBLS Inc. — Licensing and Commercial Partnerships Division
                </p>

                <div className="space-y-2">
                  <a
                    href="mailto:bim-apes@consultant.com"
                    className="flex items-center gap-2 text-[#C8A882] hover:underline"
                  >
                    <Mail size={16} />
                    <span>bim-apes@consultant.com</span>
                  </a>

                  <a
                    href="https://www.linkedin.com/company/bledsoe-investment-management-ai-consultancy-firm/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-[#C8A882] hover:underline"
                  >
                    <Linkedin size={16} />
                    <span>
                      Bledsoe Investment Management (AI Consultancy Firm)
                    </span>
                  </a>
                </div>
              </div>

              <div className="bg-[#C8A882]/20 rounded-lg p-3 text-xs">
                <p className="font-semibold text-white mb-1">
                  About NIBLS Inc.
                </p>
                <p className="text-white/80">
                  Bledsoe Investment Management is a division of NIBLS Inc.,
                  specializing in AI-driven biometric intelligence, NIL
                  valuation, and sports performance analytics.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/20 mb-6"></div>

        {/* Copyright Notice */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/70">
          <div>
            <p className="font-semibold text-white">
              © {new Date().getFullYear()} Dashawn Ramel Bledsoe / NIBLS Inc.
              All Rights Reserved.
            </p>
            <p className="text-xs mt-1">
              BIM-APES Software is developed and published by Bledsoe Investment
              Management, a division of NIBLS Inc.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <a
              href="http://www.apache.org/licenses/LICENSE-2.0"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#C8A882] transition-colors"
            >
              Apache 2.0
            </a>
            <span className="text-white/30">|</span>
            <a
              href="https://creativecommons.org/licenses/by-nc-nd/4.0/"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#C8A882] transition-colors"
            >
              CC BY-NC-ND 4.0
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
