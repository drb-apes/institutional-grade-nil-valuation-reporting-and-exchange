"use client";

import { useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  AlertTriangle,
  Heart,
} from "lucide-react";

/**
 * BiomechFlow Chart - Enterprise biomechanical visualization
 * Replaces traditional candlesticks with intuitive biomechanical capsules
 *
 * Each capsule shows:
 * - Stress Load (Top Arc)
 * - Fatigue Severity (Bottom Arc)
 * - Recovery Velocity (Center Line)
 * - Substitution Probability (Left Bar)
 * - Injury-Risk Premium (Right Bar)
 * - NIL Momentum (Glow Ring)
 */
export default function BiomechFlowChart({
  athleteId,
  athleteName,
  data = [],
}) {
  const [selectedCapsule, setSelectedCapsule] = useState(null);
  const [viewMode, setViewMode] = useState("daily"); // 'hourly', 'daily', 'weekly'

  // Generate sample data if none provided (for demo)
  const sampleData = data.length > 0 ? data : generateSampleBiomechData();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-[#E5E7EB] p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-[#1B3A57] flex items-center gap-2">
            <Activity className="text-[#C8A882]" size={24} />
            BiomechFlow Chart
          </h3>
          <p className="text-sm text-[#6B7280] mt-1">
            {athleteName} • Real-time biomechanical intelligence
          </p>
        </div>

        {/* View Mode Selector */}
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode("hourly")}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              viewMode === "hourly"
                ? "bg-[#1B3A57] text-white"
                : "bg-[#F9F9F9] text-[#6B7280] hover:bg-[#E5E7EB]"
            }`}
          >
            Hourly
          </button>
          <button
            onClick={() => setViewMode("daily")}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              viewMode === "daily"
                ? "bg-[#1B3A57] text-white"
                : "bg-[#F9F9F9] text-[#6B7280] hover:bg-[#E5E7EB]"
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setViewMode("weekly")}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              viewMode === "weekly"
                ? "bg-[#1B3A57] text-white"
                : "bg-[#F9F9F9] text-[#6B7280] hover:bg-[#E5E7EB]"
            }`}
          >
            Weekly
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="mb-6 p-4 bg-[#F9F9F9] rounded-lg">
        <p className="text-xs font-medium text-[#6B7280] mb-3">
          CAPSULE COMPONENTS
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-[#4B5563]">Stress Load</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span className="text-[#4B5563]">Fatigue</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-[#4B5563]">Recovery</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span className="text-[#4B5563]">Substitution Risk</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span className="text-[#4B5563]">Injury Risk</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#C8A882]"></div>
            <span className="text-[#4B5563]">NIL Momentum</span>
          </div>
        </div>
      </div>

      {/* Chart Area */}
      <div className="relative h-80 mb-6 overflow-x-auto">
        <div className="flex items-end justify-around h-full min-w-[800px] px-4">
          {sampleData.map((capsule, index) => (
            <BiomechCapsule
              key={index}
              data={capsule}
              isSelected={selectedCapsule === index}
              onClick={() => setSelectedCapsule(index)}
            />
          ))}
        </div>
      </div>

      {/* Selected Capsule Detail */}
      {selectedCapsule !== null && (
        <div className="mt-6 p-4 bg-[#F0F4F8] rounded-lg border-2 border-[#1B3A57]">
          <CapsuleDetail data={sampleData[selectedCapsule]} />
        </div>
      )}

      {/* Market Trend Indicator */}
      <div className="mt-6 pt-6 border-t border-[#E5E7EB]">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-[#6B7280]">
              Performance Market Trend
            </p>
            <p className="text-xs text-[#9CA3AF] mt-1">
              Based on biomechanical momentum
            </p>
          </div>
          <div className="flex items-center gap-3">
            {calculateMarketTrend(sampleData) === "bull" ? (
              <div className="flex items-center gap-2 text-green-600">
                <TrendingUp size={20} />
                <span className="font-bold">BULL</span>
                <span className="text-sm text-[#6B7280]">High readiness</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-red-600">
                <TrendingDown size={20} />
                <span className="font-bold">BEAR</span>
                <span className="text-sm text-[#6B7280]">
                  Fatigue accumulation
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Individual BiomechCapsule Component
 */
function BiomechCapsule({ data, isSelected, onClick }) {
  const {
    timestamp,
    stressLoad,
    fatigueSeverity,
    recoveryVelocity,
    substitutionProbability,
    injuryRiskPremium,
    nilMomentum,
  } = data;

  // Calculate height based on stress + fatigue
  const totalLoad = stressLoad + fatigueSeverity;
  const height = Math.min(Math.max(totalLoad * 100, 40), 280); // 40px to 280px

  return (
    <div
      onClick={onClick}
      className={`relative flex flex-col items-center cursor-pointer transition-all ${
        isSelected ? "scale-110" : "hover:scale-105"
      }`}
      style={{ height: `${height}px` }}
    >
      {/* NIL Momentum Glow Ring */}
      <div
        className="absolute inset-0 rounded-full blur-xl opacity-30"
        style={{
          backgroundColor: nilMomentum > 0 ? "#C8A882" : "#9CA3AF",
          width: "120%",
          height: "100%",
          left: "-10%",
        }}
      />

      {/* Stress Load Arc (Top) */}
      <div
        className="w-12 rounded-t-full"
        style={{
          height: `${stressLoad * 100}%`,
          backgroundColor:
            stressLoad > 0.7
              ? "#EF4444"
              : stressLoad > 0.4
                ? "#F59E0B"
                : "#10B981",
          opacity: 0.8,
        }}
      />

      {/* Recovery Velocity Line (Center) */}
      <div
        className="w-16 border-t-4"
        style={{
          borderColor:
            recoveryVelocity > 0.6
              ? "#10B981"
              : recoveryVelocity > 0.3
                ? "#F59E0B"
                : "#EF4444",
          marginTop: "4px",
          marginBottom: "4px",
        }}
      />

      {/* Fatigue Severity Arc (Bottom) */}
      <div
        className="w-12 rounded-b-full"
        style={{
          height: `${fatigueSeverity * 100}%`,
          backgroundColor:
            fatigueSeverity > 0.7
              ? "#F97316"
              : fatigueSeverity > 0.4
                ? "#FBBF24"
                : "#10B981",
          opacity: 0.8,
        }}
      />

      {/* Substitution Probability (Left Bar) */}
      <div
        className="absolute left-0 bottom-0 w-1 rounded-t"
        style={{
          height: `${substitutionProbability * 100}%`,
          backgroundColor: "#3B82F6",
          opacity: 0.7,
        }}
      />

      {/* Injury Risk Premium (Right Bar) */}
      <div
        className="absolute right-0 bottom-0 w-1 rounded-t"
        style={{
          height: `${injuryRiskPremium * 100}%`,
          backgroundColor: "#EAB308",
          opacity: 0.7,
        }}
      />

      {/* Timestamp Label */}
      <p className="text-xs text-[#6B7280] mt-2 text-center w-16">
        {new Date(timestamp).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })}
      </p>

      {/* Alert Badge */}
      {(injuryRiskPremium > 0.7 || substitutionProbability > 0.7) && (
        <AlertTriangle className="absolute -top-6 text-red-500" size={16} />
      )}
    </div>
  );
}

/**
 * Capsule Detail Panel
 */
function CapsuleDetail({ data }) {
  return (
    <div>
      <p className="text-sm font-bold text-[#1B3A57] mb-4">
        {new Date(data.timestamp).toLocaleString()}
      </p>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div>
          <p className="text-xs text-[#6B7280] mb-1">Stress Load</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-[#E5E7EB] rounded-full overflow-hidden">
              <div
                className="h-full bg-red-500"
                style={{ width: `${data.stressLoad * 100}%` }}
              />
            </div>
            <span className="text-sm font-bold text-[#1B3A57]">
              {(data.stressLoad * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        <div>
          <p className="text-xs text-[#6B7280] mb-1">Fatigue Severity</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-[#E5E7EB] rounded-full overflow-hidden">
              <div
                className="h-full bg-orange-500"
                style={{ width: `${data.fatigueSeverity * 100}%` }}
              />
            </div>
            <span className="text-sm font-bold text-[#1B3A57]">
              {(data.fatigueSeverity * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        <div>
          <p className="text-xs text-[#6B7280] mb-1">Recovery Velocity</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-[#E5E7EB] rounded-full overflow-hidden">
              <div
                className="h-full bg-green-500"
                style={{ width: `${data.recoveryVelocity * 100}%` }}
              />
            </div>
            <span className="text-sm font-bold text-[#1B3A57]">
              {(data.recoveryVelocity * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        <div>
          <p className="text-xs text-[#6B7280] mb-1">Substitution Risk</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-[#E5E7EB] rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-500"
                style={{ width: `${data.substitutionProbability * 100}%` }}
              />
            </div>
            <span className="text-sm font-bold text-[#1B3A57]">
              {(data.substitutionProbability * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        <div>
          <p className="text-xs text-[#6B7280] mb-1">Injury Risk</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-[#E5E7EB] rounded-full overflow-hidden">
              <div
                className="h-full bg-yellow-500"
                style={{ width: `${data.injuryRiskPremium * 100}%` }}
              />
            </div>
            <span className="text-sm font-bold text-[#1B3A57]">
              {(data.injuryRiskPremium * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        <div>
          <p className="text-xs text-[#6B7280] mb-1">NIL Momentum</p>
          <div className="flex items-center gap-2">
            <Heart
              className={
                data.nilMomentum > 0 ? "text-[#C8A882]" : "text-[#9CA3AF]"
              }
              size={16}
              fill={data.nilMomentum > 0 ? "#C8A882" : "none"}
            />
            <span
              className={`text-sm font-bold ${
                data.nilMomentum > 0 ? "text-[#C8A882]" : "text-[#6B7280]"
              }`}
            >
              {data.nilMomentum > 0 ? "+" : ""}
              {(data.nilMomentum * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="mt-4 pt-4 border-t border-[#E5E7EB]">
        <p className="text-xs font-medium text-[#6B7280] mb-2">
          SYSTEM RECOMMENDATIONS
        </p>
        <div className="space-y-2">
          {data.injuryRiskPremium > 0.7 && (
            <div className="flex items-start gap-2 text-sm text-red-600">
              <AlertTriangle size={16} className="mt-0.5" />
              <span>High injury risk - Consider load reduction</span>
            </div>
          )}
          {data.substitutionProbability > 0.7 && (
            <div className="flex items-start gap-2 text-sm text-blue-600">
              <AlertTriangle size={16} className="mt-0.5" />
              <span>High substitution probability - Prepare backup</span>
            </div>
          )}
          {data.recoveryVelocity < 0.3 && (
            <div className="flex items-start gap-2 text-sm text-orange-600">
              <AlertTriangle size={16} className="mt-0.5" />
              <span>Slow recovery - Extend rest period</span>
            </div>
          )}
          {data.nilMomentum > 0.5 && (
            <div className="flex items-start gap-2 text-sm text-[#C8A882]">
              <TrendingUp size={16} className="mt-0.5" />
              <span>Strong NIL momentum - Optimal performance window</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Generate sample biomechanical data
 */
function generateSampleBiomechData() {
  const data = [];
  const now = new Date();

  for (let i = 11; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 2 * 60 * 60 * 1000); // 2-hour intervals

    data.push({
      timestamp: timestamp.toISOString(),
      stressLoad: Math.random() * 0.8 + 0.1,
      fatigueSeverity: Math.random() * 0.7 + 0.1,
      recoveryVelocity: Math.random() * 0.8 + 0.2,
      substitutionProbability: Math.random() * 0.6,
      injuryRiskPremium: Math.random() * 0.5,
      nilMomentum: (Math.random() - 0.5) * 0.4,
    });
  }

  return data;
}

/**
 * Calculate market trend from biomechanical data
 */
function calculateMarketTrend(data) {
  if (data.length === 0) return "neutral";

  const recent = data.slice(-3); // Last 3 capsules
  const avgRecovery =
    recent.reduce((sum, d) => sum + d.recoveryVelocity, 0) / recent.length;
  const avgFatigue =
    recent.reduce((sum, d) => sum + d.fatigueSeverity, 0) / recent.length;
  const avgNIL =
    recent.reduce((sum, d) => sum + d.nilMomentum, 0) / recent.length;

  if (avgRecovery > 0.6 && avgFatigue < 0.4 && avgNIL > 0) {
    return "bull";
  } else {
    return "bear";
  }
}
