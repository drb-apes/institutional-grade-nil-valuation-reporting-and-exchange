"use client";

import { useEffect, useRef, useState } from "react";
import {
  Scene,
  PerspectiveCamera,
  WebGLRenderer,
  SphereGeometry,
  MeshStandardMaterial,
  Mesh,
  AmbientLight,
  PointLight,
  Group,
  Vector3,
  TorusGeometry,
  ConeGeometry,
  BoxGeometry,
} from "three";

export default function XRCombatVisualization({
  athleteData,
  sport = "wrestling",
}) {
  const canvasRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const animationFrameRef = useRef(null);
  const athleteGroupsRef = useRef([]);
  const [hoveredAthlete, setHoveredAthlete] = useState(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize scene
    const scene = new Scene();
    sceneRef.current = scene;

    // Initialize camera
    const camera = new PerspectiveCamera(
      75,
      canvasRef.current.clientWidth / canvasRef.current.clientHeight,
      0.1,
      1000,
    );
    camera.position.set(0, 5, sport === "boxing" ? 8 : 10);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Initialize renderer
    const renderer = new WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      alpha: true,
    });
    renderer.setSize(
      canvasRef.current.clientWidth,
      canvasRef.current.clientHeight,
    );
    renderer.setClearColor(0x000000, 0);
    rendererRef.current = renderer;

    // Add lighting
    const ambientLight = new AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const pointLight1 = new PointLight(0xffffff, 1);
    pointLight1.position.set(5, 5, 5);
    scene.add(pointLight1);

    const pointLight2 = new PointLight(0x4488ff, 0.5);
    pointLight2.position.set(-5, 5, -5);
    scene.add(pointLight2);

    // Create arena/mat based on sport
    createArena(scene, sport);

    // Create athlete capsules
    if (athleteData && athleteData.length > 0) {
      athleteData.forEach((athlete, index) => {
        const athleteGroup = createAthleteCapsule(athlete, index, sport);
        scene.add(athleteGroup);
        athleteGroupsRef.current.push({ group: athleteGroup, data: athlete });
      });
    } else {
      // Create sample athletes if no data provided
      const sampleAthletes = createSampleAthletes(sport);
      sampleAthletes.forEach((athlete, index) => {
        const athleteGroup = createAthleteCapsule(athlete, index, sport);
        scene.add(athleteGroup);
        athleteGroupsRef.current.push({ group: athleteGroup, data: athlete });
      });
    }

    // Animation loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);

      // Animate athlete capsules (wobble, pulse, drift)
      athleteGroupsRef.current.forEach(({ group, data }) => {
        const time = Date.now() * 0.001;

        // Wobble based on stress
        const wobbleAmount = (data.stress || 0.5) * 0.1;
        group.rotation.y = Math.sin(time * 2) * wobbleAmount;

        // Pulse the glow ring based on NIL momentum
        const glowRing = group.children.find(
          (child) => child.userData.isGlowRing,
        );
        if (glowRing) {
          const pulseScale =
            1 + Math.sin(time * 3) * (data.nilMomentum || 0.3) * 0.1;
          glowRing.scale.set(pulseScale, pulseScale, pulseScale);
        }

        // Drift based on fatigue
        const driftAmount = (data.fatigue || 0.5) * 0.05;
        group.position.x += Math.sin(time * 0.5) * driftAmount * 0.01;
        group.position.z += Math.cos(time * 0.5) * driftAmount * 0.01;
      });

      renderer.render(scene, camera);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      if (!canvasRef.current) return;
      const width = canvasRef.current.clientWidth;
      const height = canvasRef.current.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [athleteData, sport]);

  function createArena(scene, sport) {
    // Create mat/ring based on sport type
    let arenaGeometry, arenaMaterial;

    if (sport === "boxing") {
      // Boxing ring (square)
      arenaGeometry = new BoxGeometry(8, 0.2, 8);
      arenaMaterial = new MeshStandardMaterial({
        color: 0x2a2a2a,
        roughness: 0.8,
        metalness: 0.2,
      });
    } else if (sport === "mma") {
      // Octagon cage floor
      arenaGeometry = new BoxGeometry(10, 0.2, 10);
      arenaMaterial = new MeshStandardMaterial({
        color: 0x1a1a1a,
        roughness: 0.9,
        metalness: 0.1,
      });
    } else {
      // Wrestling mat (circular)
      arenaGeometry = new BoxGeometry(12, 0.2, 12);
      arenaMaterial = new MeshStandardMaterial({
        color: 0x4a4a4a,
        roughness: 0.7,
        metalness: 0.3,
      });
    }

    const arenaMesh = new Mesh(arenaGeometry, arenaMaterial);
    arenaMesh.position.y = -0.1;
    scene.add(arenaMesh);

    // Add boundary lines
    if (sport === "boxing") {
      // Ring ropes (simplified as lines/bars)
      const ropeGeometry = new BoxGeometry(8.5, 0.1, 0.1);
      const ropeMaterial = new MeshStandardMaterial({ color: 0xff0000 });

      for (let i = 0; i < 4; i++) {
        const rope = new Mesh(ropeGeometry, ropeMaterial);
        rope.position.y = 0.5 + i * 0.4;
        rope.position.z = i % 2 === 0 ? 4 : -4;
        scene.add(rope);
      }
    }
  }

  function createAthleteCapsule(athlete, index, sport) {
    const group = new Group();

    // Position based on index and sport
    const positions = getAthletePositions(sport);
    const pos = positions[index] || { x: 0, y: 0, z: 0 };
    group.position.set(pos.x, pos.y, pos.z);

    // Main capsule body
    const bodyGeometry = new SphereGeometry(0.5, 32, 32);
    const bodyColor = getAthleteColor(athlete.ssi || 75);
    const bodyMaterial = new MeshStandardMaterial({
      color: bodyColor,
      roughness: 0.3,
      metalness: 0.7,
      emissive: bodyColor,
      emissiveIntensity: 0.2,
    });
    const bodyMesh = new Mesh(bodyGeometry, bodyMaterial);
    bodyMesh.userData.athleteId = athlete.id;
    group.add(bodyMesh);

    // Stress bloom (expanding cone above)
    const stressLevel = athlete.stress || 0.5;
    const bloomGeometry = new ConeGeometry(0.3 + stressLevel * 0.3, 1, 8);
    const stressColor = stressLevel > 0.7 ? 0xff4444 : 0xffaa44;
    const bloomMaterial = new MeshStandardMaterial({
      color: stressColor,
      transparent: true,
      opacity: stressLevel * 0.6,
      emissive: 0xff4444,
      emissiveIntensity: stressLevel * 0.5,
    });
    const bloomMesh = new Mesh(bloomGeometry, bloomMaterial);
    bloomMesh.position.y = 1;
    bloomMesh.rotation.x = Math.PI;
    group.add(bloomMesh);

    // Glow ring (NIL momentum indicator)
    const nilMomentum = athlete.nilMomentum || 0.5;
    const ringGeometry = new TorusGeometry(0.8, 0.05, 16, 32);
    const ringMaterial = new MeshStandardMaterial({
      color: 0xffc107,
      emissive: 0xffc107,
      emissiveIntensity: nilMomentum,
      transparent: true,
      opacity: 0.8,
    });
    const ringMesh = new Mesh(ringGeometry, ringMaterial);
    ringMesh.rotation.x = Math.PI / 2;
    ringMesh.position.y = -0.5;
    ringMesh.userData.isGlowRing = true;
    group.add(ringMesh);

    // Drift trail indicator (fatigue visualization)
    const fatigueLevel = athlete.fatigue || 0.5;
    if (fatigueLevel > 0.3) {
      const trailGeometry = new BoxGeometry(0.1, 0.1, 1);
      const trailMaterial = new MeshStandardMaterial({
        color: 0x4488ff,
        transparent: true,
        opacity: fatigueLevel * 0.5,
      });
      const trailMesh = new Mesh(trailGeometry, trailMaterial);
      trailMesh.position.z = -0.7;
      group.add(trailMesh);
    }

    group.userData.athleteData = athlete;
    return group;
  }

  function getAthletePositions(sport) {
    if (sport === "boxing") {
      return [
        { x: -2, y: 0, z: 0 }, // Red corner
        { x: 2, y: 0, z: 0 }, // Blue corner
      ];
    } else if (sport === "mma") {
      return [
        { x: -3, y: 0, z: 0 },
        { x: 3, y: 0, z: 0 },
      ];
    } else {
      // wrestling
      return [
        { x: -2, y: 0, z: -2 },
        { x: 2, y: 0, z: 2 },
        { x: -2, y: 0, z: 2 },
        { x: 2, y: 0, z: -2 },
      ];
    }
  }

  function getAthleteColor(ssi) {
    // Color based on Sport-Specific Index
    if (ssi >= 85) return 0x00ff00; // Green - excellent
    if (ssi >= 75) return 0x88ff00; // Yellow-green - good
    if (ssi >= 65) return 0xffaa00; // Orange - moderate
    return 0xff4444; // Red - poor
  }

  function createSampleAthletes(sport) {
    if (sport === "boxing") {
      return [
        {
          id: 1,
          name: "Fighter A",
          ssi: 82,
          stress: 0.6,
          fatigue: 0.4,
          nilMomentum: 0.7,
          corner: "red",
        },
        {
          id: 2,
          name: "Fighter B",
          ssi: 76,
          stress: 0.7,
          fatigue: 0.5,
          nilMomentum: 0.6,
          corner: "blue",
        },
      ];
    } else if (sport === "mma") {
      return [
        {
          id: 1,
          name: "Fighter 1",
          ssi: 88,
          stress: 0.5,
          fatigue: 0.3,
          nilMomentum: 0.8,
        },
        {
          id: 2,
          name: "Fighter 2",
          ssi: 79,
          stress: 0.6,
          fatigue: 0.5,
          nilMomentum: 0.65,
        },
      ];
    } else {
      // wrestling
      return [
        {
          id: 1,
          name: "Wrestler A",
          ssi: 85,
          stress: 0.4,
          fatigue: 0.3,
          nilMomentum: 0.75,
        },
        {
          id: 2,
          name: "Wrestler B",
          ssi: 78,
          stress: 0.6,
          fatigue: 0.5,
          nilMomentum: 0.6,
        },
        {
          id: 3,
          name: "Wrestler C",
          ssi: 80,
          stress: 0.5,
          fatigue: 0.4,
          nilMomentum: 0.7,
        },
        {
          id: 4,
          name: "Wrestler D",
          ssi: 72,
          stress: 0.7,
          fatigue: 0.6,
          nilMomentum: 0.55,
        },
      ];
    }
  }

  const displayAthletes =
    athleteData && athleteData.length > 0 ? athleteData : null;

  return (
    <div className="relative w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-800">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ minHeight: "500px" }}
      />

      {/* Overlay info panel */}
      <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg p-4 text-white border border-gray-700">
        <h3 className="text-lg font-bold mb-2 text-[#C8A882]">
          {sport.toUpperCase()} XR PERFORMANCE LAB
        </h3>
        <div className="space-y-1 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span>SSI 85+ (Excellent)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span>SSI 75-84 (Good)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span>SSI 65-74 (Moderate)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span>SSI &lt;65 (Poor)</span>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-gray-700 text-xs text-gray-400">
          <p>• Wobble = Stress level</p>
          <p>• Glow ring = NIL momentum</p>
          <p>• Cone bloom = Stress intensity</p>
          <p>• Drift trail = Fatigue</p>
        </div>
      </div>

      {/* Athletes list overlay */}
      {displayAthletes && displayAthletes.length > 0 && (
        <div className="absolute top-4 right-4 bg-black/80 backdrop-blur-sm rounded-lg p-4 text-white border border-gray-700 max-w-xs">
          <h4 className="text-sm font-bold mb-2 text-[#C8A882]">ATHLETES</h4>
          <div className="space-y-2">
            {displayAthletes.map((athlete, index) => {
              const ssi = athlete.ssi || 0;
              const nilMomentum = athlete.nilMomentum || 0;
              const stress = athlete.stress || 0;
              const fatigue = athlete.fatigue || 0;

              return (
                <div
                  key={athlete.id || index}
                  className="text-xs border-b border-gray-700 pb-2"
                >
                  <div className="font-semibold">{athlete.name}</div>
                  <div className="grid grid-cols-2 gap-1 mt-1 text-gray-400">
                    <span>SSI: {ssi || "N/A"}</span>
                    <span>
                      NIL:{" "}
                      {nilMomentum
                        ? `${(nilMomentum * 100).toFixed(0)}%`
                        : "N/A"}
                    </span>
                    <span>
                      Stress: {stress ? `${(stress * 100).toFixed(0)}%` : "N/A"}
                    </span>
                    <span>
                      Fatigue:{" "}
                      {fatigue ? `${(fatigue * 100).toFixed(0)}%` : "N/A"}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
