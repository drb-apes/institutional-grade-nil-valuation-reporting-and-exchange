"use client";

import { Box, Zap, Shield, Activity, AlertCircle } from "lucide-react";

/**
 * AR Biomechanical Overlay Component
 * Simulates AR/3D visualization of athlete biomechanics
 *
 * In production, this would integrate with:
 * - AR SDK integration
 * - Three.js for 3D rendering
 * - WebXR for AR capabilities
 * - Real-time biomechanical capture streams
 */
export default function ARBiomechOverlay({
  athleteId,
  athleteName,
  biomechData,
}) {
  const overlays = [
    {
      id: "stress-cone",
      name: "Stress Cone",
      icon: AlertCircle,
      description: "Joint load distribution and torque vectors",
      color: "#EF4444",
      intensity: biomechData?.stressLoad || 0.5,
      status:
        biomechData?.stressLoad > 0.7
          ? "critical"
          : biomechData?.stressLoad > 0.4
            ? "warning"
            : "normal",
    },
    {
      id: "fatigue-halo",
      name: "Fatigue Halo",
      icon: Zap,
      description: "Physiological decay and energy depletion",
      color: "#F97316",
      intensity: biomechData?.fatigueSeverity || 0.3,
      status:
        biomechData?.fatigueSeverity > 0.7
          ? "critical"
          : biomechData?.fatigueSeverity > 0.4
            ? "warning"
            : "normal",
    },
    {
      id: "recovery-ring",
      name: "Recovery Ring",
      icon: Activity,
      description: "Tissue repair progress and readiness",
      color: "#10B981",
      intensity: biomechData?.recoveryVelocity || 0.7,
      status:
        biomechData?.recoveryVelocity < 0.3
          ? "critical"
          : biomechData?.recoveryVelocity < 0.6
            ? "warning"
            : "normal",
    },
    {
      id: "load-pyramid",
      name: "Load Pyramid",
      icon: Shield,
      description: "Training load accumulation and safety margins",
      color: "#3B82F6",
      intensity: biomechData?.trainingLoad || 0.6,
      status:
        biomechData?.trainingLoad > 0.8
          ? "critical"
          : biomechData?.trainingLoad > 0.6
            ? "warning"
            : "normal",
    },
    {
      id: "technique-drift",
      name: "Technique Drift Lines",
      icon: Box,
      description: "Biomechanical form breakdown indicators",
      color: "#8B5CF6",
      intensity: biomechData?.techniqueDrift || 0.2,
      status:
        biomechData?.techniqueDrift > 0.5
          ? "critical"
          : biomechData?.techniqueDrift > 0.3
            ? "warning"
            : "normal",
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-[#E5E7EB] p-6">
      {/* Header */}
      <div className="mb-6">
        <h3 className="text-xl font-bold text-[#1B3A57] flex items-center gap-2">
          <Box className="text-[#C8A882]" size={24} />
          AR Biomechanical Overlays
        </h3>
        <p className="text-sm text-[#6B7280] mt-1">
          {athleteName} • Spatial biomechanical intelligence
        </p>
      </div>

      {/* AR Viewport Simulation */}
      <div className="relative bg-gradient-to-br from-[#1B3A57] to-[#2A4A68] rounded-xl p-8 mb-6 h-96 flex items-center justify-center overflow-hidden">
        {/* Grid overlay to simulate AR space */}
        <div className="absolute inset-0 opacity-20">
          <div
            className="h-full w-full"
            style={{
              backgroundImage: `
              linear-gradient(to right, #C8A882 1px, transparent 1px),
              linear-gradient(to bottom, #C8A882 1px, transparent 1px)
            `,
              backgroundSize: "40px 40px",
            }}
          />
        </div>

        {/* Athlete silhouette (placeholder) */}
        <div className="relative z-10">
          <div className="w-32 h-64 bg-[#3A5A78] rounded-full opacity-40 relative">
            {/* Overlays positioned around silhouette */}

            {/* Stress Cone - Head/Shoulders */}
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 animate-pulse">
              <div className="w-24 h-24 border-4 border-red-500 rounded-full opacity-60" />
              <div className="absolute inset-0 bg-red-500 rounded-full opacity-20" />
            </div>

            {/* Fatigue Halo - Torso */}
            <div
              className="absolute top-1/3 left-1/2 -translate-x-1/2 animate-pulse"
              style={{ animationDelay: "0.5s" }}
            >
              <div className="w-32 h-32 border-4 border-orange-500 rounded-full opacity-60" />
              <div className="absolute inset-0 bg-orange-500 rounded-full opacity-20" />
            </div>

            {/* Recovery Ring - Full body */}
            <div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse"
              style={{ animationDelay: "1s" }}
            >
              <div className="w-40 h-80 border-4 border-green-500 rounded-full opacity-40" />
            </div>

            {/* Load Pyramid - Legs */}
            <div className="absolute -bottom-8 left-1/2 -translate-x-1/2">
              <div className="w-0 h-0 border-l-[30px] border-r-[30px] border-b-[50px] border-l-transparent border-r-transparent border-b-blue-500 opacity-60" />
            </div>
          </div>

          {/* AR Metrics Floating Labels */}
          <div className="absolute -top-16 -right-16 bg-black/80 text-white px-3 py-2 rounded-lg text-xs backdrop-blur">
            <p className="font-bold">HRV: 87ms</p>
            <p className="text-green-400">Normal</p>
          </div>

          <div className="absolute top-1/4 -left-20 bg-black/80 text-white px-3 py-2 rounded-lg text-xs backdrop-blur">
            <p className="font-bold">Joint Load</p>
            <p className="text-yellow-400">Moderate</p>
          </div>

          <div className="absolute bottom-8 -right-20 bg-black/80 text-white px-3 py-2 rounded-lg text-xs backdrop-blur">
            <p className="font-bold">Ground Force</p>
            <p className="text-green-400">2.1x BW</p>
          </div>
        </div>

        {/* AR Instructions */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/60 text-white px-4 py-2 rounded-full text-sm backdrop-blur">
          <p>Rotate device to view 360° biomechanical analysis</p>
        </div>
      </div>

      {/* Overlay Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {overlays.map((overlay) => {
          const Icon = overlay.icon;
          return (
            <div
              key={overlay.id}
              className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                overlay.status === "critical"
                  ? "border-red-500 bg-red-50"
                  : overlay.status === "warning"
                    ? "border-yellow-500 bg-yellow-50"
                    : "border-[#E5E7EB] bg-white hover:border-[#C8A882]"
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className="p-2 rounded-lg"
                  style={{ backgroundColor: `${overlay.color}20` }}
                >
                  <Icon style={{ color: overlay.color }} size={20} />
                </div>

                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-semibold text-[#1B3A57] text-sm">
                      {overlay.name}
                    </p>
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-medium ${
                        overlay.status === "critical"
                          ? "bg-red-200 text-red-800"
                          : overlay.status === "warning"
                            ? "bg-yellow-200 text-yellow-800"
                            : "bg-green-200 text-green-800"
                      }`}
                    >
                      {overlay.status}
                    </span>
                  </div>

                  <p className="text-xs text-[#6B7280] mb-2">
                    {overlay.description}
                  </p>

                  {/* Intensity Bar */}
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-[#E5E7EB] rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${overlay.intensity * 100}%`,
                          backgroundColor: overlay.color,
                        }}
                      />
                    </div>
                    <span className="text-xs font-bold text-[#1B3A57]">
                      {(overlay.intensity * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* AR Integration Notice */}
      <div className="mt-6 p-4 bg-[#F0F4F8] rounded-lg border-l-4 border-[#C8A882]">
        <p className="text-sm text-[#1B3A57]">
          <span className="font-bold">AR Mode:</span> Full 3D visualization
          available via AR SDK integration. Overlay data updates in real-time
          from biomechanical capture streams.
        </p>
      </div>
    </div>
  );
}
