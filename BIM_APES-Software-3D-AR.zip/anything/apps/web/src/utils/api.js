/**
 * BIM-APES API Client
 * Centralized API utilities for console frontend
 */

const API_BASE = process.env.NEXT_PUBLIC_CREATE_APP_URL || "";

/**
 * Generic fetch wrapper with error handling
 */
async function fetchAPI(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;

  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response
        .json()
        .catch(() => ({ error: response.statusText }));
      throw new Error(error.error || `API error: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`API call failed: ${endpoint}`, error);
    throw error;
  }
}

/**
 * Dashboard API
 */
export const dashboardAPI = {
  getSummary: () => fetchAPI("/api/dashboard/summary"),
};

/**
 * Athletes API
 */
export const athletesAPI = {
  list: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetchAPI(`/api/athletes/list${query ? `?${query}` : ""}`);
  },

  get: (id) => fetchAPI(`/api/athletes/${id}`),

  update: (id, data) =>
    fetchAPI(`/api/athletes/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  getMetrics: (athleteId = null, params = {}) => {
    const query = new URLSearchParams({
      ...(athleteId && { athlete_id: athleteId }),
      ...params,
    }).toString();
    return fetchAPI(`/api/athletes/metrics${query ? `?${query}` : ""}`);
  },
};

/**
 * Biometric Readings API
 */
export const biometricsAPI = {
  record: (data) =>
    fetchAPI("/api/biometric-readings/record", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  recordBatch: (data) =>
    fetchAPI("/api/biometric-readings/record", {
      method: "PUT",
      body: JSON.stringify(data),
    }),
};

/**
 * NIL Valuation API
 */
export const nilAPI = {
  calculate: (athleteId) =>
    fetchAPI("/api/nil-valuation/calculate", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),
};

/**
 * Trading API
 */
export const tradingAPI = {
  detectMispricing: () =>
    fetchAPI("/api/trading/detect-mispricing", {
      method: "POST",
    }),

  getMispricingEvents: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return fetchAPI(
      `/api/trading/detect-mispricing${query ? `?${query}` : ""}`,
    );
  },

  arbitrage: {
    detect: (athleteId, autoExecute = false) =>
      fetchAPI("/api/trading/strategies/arbitrage", {
        method: "POST",
        body: JSON.stringify({
          athlete_id: athleteId,
          auto_execute: autoExecute,
        }),
      }),

    list: (params = {}) => {
      const query = new URLSearchParams(params).toString();
      return fetchAPI(
        `/api/trading/strategies/arbitrage${query ? `?${query}` : ""}`,
      );
    },
  },

  hedge: {
    analyze: (athleteIds, autoExecute = false) =>
      fetchAPI("/api/trading/strategies/hedge", {
        method: "POST",
        body: JSON.stringify({
          athlete_ids: athleteIds,
          auto_execute: autoExecute,
        }),
      }),

    list: (params = {}) => {
      const query = new URLSearchParams(params).toString();
      return fetchAPI(
        `/api/trading/strategies/hedge${query ? `?${query}` : ""}`,
      );
    },
  },

  scalping: {
    detect: (athleteId, autoExecute = false) =>
      fetchAPI("/api/trading/strategies/scalping", {
        method: "POST",
        body: JSON.stringify({
          athlete_id: athleteId,
          auto_execute: autoExecute,
        }),
      }),

    list: (params = {}) => {
      const query = new URLSearchParams(params).toString();
      return fetchAPI(
        `/api/trading/strategies/scalping${query ? `?${query}` : ""}`,
      );
    },

    close: (positionId) =>
      fetchAPI("/api/trading/strategies/scalping", {
        method: "PATCH",
        body: JSON.stringify({ position_id: positionId }),
      }),
  },
};

/**
 * Intelligence API
 */
export const intelligenceAPI = {
  stress: (athleteId) =>
    fetchAPI("/api/intelligence/stress", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),

  fatigue: (athleteId) =>
    fetchAPI("/api/intelligence/fatigue", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),

  recovery: (athleteId) =>
    fetchAPI("/api/intelligence/recovery", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),

  training: (athleteId) =>
    fetchAPI("/api/intelligence/training", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),

  market: (athleteId) =>
    fetchAPI("/api/intelligence/market", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),
};

/**
 * AR/Broadcast API
 */
export const broadcastAPI = {
  generateOverlay: (athleteId) =>
    fetchAPI("/api/ar/overlays/generate", {
      method: "POST",
      body: JSON.stringify({ athlete_id: athleteId }),
    }),

  generateARPackage: (params) =>
    fetchAPI("/api/broadcast/ar-package", {
      method: "POST",
      body: JSON.stringify(params),
    }),

  generateStadiumDisplay: (params) =>
    fetchAPI("/api/stadium/display", {
      method: "POST",
      body: JSON.stringify(params),
    }),
};

/**
 * Certificates & Coalition API
 */
export const coalitionAPI = {
  issueCertificate: (data) =>
    fetchAPI("/api/certificates/issue", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  listCertificates: (athleteId, status = null) => {
    const query = new URLSearchParams({
      athlete_id: athleteId,
      ...(status && { status }),
    }).toString();
    return fetchAPI(`/api/certificates/issue?${query}`);
  },

  activate: (data) =>
    fetchAPI("/api/coalition/activate", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  listActivations: (partner = null) => {
    const query = partner ? `?partner=${encodeURIComponent(partner)}` : "";
    return fetchAPI(`/api/coalition/activate${query}`);
  },
};

/**
 * Sponsor ROI API
 */
export const sponsorAPI = {
  trackROI: (athleteIds) =>
    fetchAPI("/api/sponsor/roi-tracking", {
      method: "POST",
      body: JSON.stringify({ athlete_ids: athleteIds }),
    }),

  listAthletes: (sponsor) => {
    const query = new URLSearchParams({ sponsor }).toString();
    return fetchAPI(`/api/sponsor/roi-tracking?${query}`);
  },
};

/**
 * Wearables API
 */
export const wearablesAPI = {
  appleWatch: {
    sync: (data) =>
      fetchAPI("/api/wearables/apple-watch/sync", {
        method: "POST",
        body: JSON.stringify(data),
      }),
  },

  garmin: {
    connect: (athleteId) =>
      fetchAPI("/api/wearables/garmin/connect", {
        method: "POST",
        body: JSON.stringify({ athlete_id: athleteId }),
      }),

    sync: (athleteId, dataTypes) =>
      fetchAPI("/api/wearables/garmin/sync", {
        method: "POST",
        body: JSON.stringify({ athlete_id: athleteId, data_types: dataTypes }),
      }),
  },

  whoop: {
    connect: (athleteId) =>
      fetchAPI("/api/wearables/whoop/connect", {
        method: "POST",
        body: JSON.stringify({ athlete_id: athleteId }),
      }),

    sync: (athleteId) =>
      fetchAPI("/api/wearables/whoop/sync", {
        method: "POST",
        body: JSON.stringify({ athlete_id: athleteId }),
      }),
  },
};

export default {
  dashboard: dashboardAPI,
  athletes: athletesAPI,
  biometrics: biometricsAPI,
  nil: nilAPI,
  trading: tradingAPI,
  intelligence: intelligenceAPI,
  broadcast: broadcastAPI,
  coalition: coalitionAPI,
  sponsor: sponsorAPI,
  wearables: wearablesAPI,
};
