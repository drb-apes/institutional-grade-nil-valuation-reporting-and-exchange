"use client";

import { createContext, useContext, useState, useEffect } from "react";
import {
  translateText,
  translateBatch,
  getStoredLanguage,
  setStoredLanguage,
  SUPPORTED_LANGUAGES,
} from "./translations";

const LanguageContext = createContext();

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState("en");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedLang = getStoredLanguage();
    setLanguage(storedLang);
    setIsLoading(false);
  }, []);

  const changeLanguage = (newLang) => {
    setLanguage(newLang);
    setStoredLanguage(newLang);
  };

  const t = async (text) => {
    if (language === "en") return text;
    return await translateText(text, language);
  };

  const tBatch = async (texts) => {
    if (language === "en") return texts;
    return await translateBatch(texts, language);
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        changeLanguage,
        t,
        tBatch,
        isLoading,
        languages: SUPPORTED_LANGUAGES,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}
