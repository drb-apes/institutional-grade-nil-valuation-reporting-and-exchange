// BIM-APES Brand Color System
// Based on BLEDSOE logo: Navy Blue + Gold accents

export const BRAND_COLORS = {
  // Primary Navy (from BLEDSOE text)
  navy: {
    main: "#1B3A57",
    dark: "#152E45",
    light: "#2A4A68",
    subtle: "#3A5A78",
  },

  // Accent Gold (from logo separator)
  gold: {
    main: "#C8A882",
    dark: "#B8956A",
    light: "#D4B896",
    pale: "#E8DCC8",
  },

  // Professional Neutrals
  neutral: {
    white: "#FFFFFF",
    offWhite: "#F9F9F9",
    lightGray: "#E5E7EB",
    gray: "#9CA3AF",
    darkGray: "#4B5563",
    charcoal: "#1F2937",
    black: "#000000",
  },

  // Functional Colors
  success: "#10B981",
  warning: "#F59E0B",
  error: "#EF4444",
  info: "#3B82F6",

  // Trading Signals
  long: "#10B981", // Green for long positions
  short: "#EF4444", // Red for short positions
  neutral: "#6B7280", // Gray for neutral
};

// Pre-built component classes for rapid development
export const BRAND_CLASSES = {
  // Buttons
  btnPrimary:
    "bg-[#1B3A57] hover:bg-[#152E45] text-white font-medium px-6 py-3 rounded-lg transition-colors",
  btnSecondary:
    "bg-[#C8A882] hover:bg-[#B8956A] text-[#1B3A57] font-medium px-6 py-3 rounded-lg transition-colors",
  btnOutline:
    "border-2 border-[#1B3A57] text-[#1B3A57] hover:bg-[#1B3A57] hover:text-white font-medium px-6 py-3 rounded-lg transition-colors",

  // Cards
  bgCard: "bg-white border border-[#E5E7EB] rounded-xl shadow-sm",
  bgCardDark: "bg-[#1F2937] border border-[#374151] rounded-xl shadow-sm",

  // Headers
  bgHeader: "bg-[#1B3A57] text-white",
  bgHeaderLight: "bg-[#2A4A68] text-white",

  // Text
  textPrimary: "text-[#1B3A57]",
  textGold: "text-[#C8A882]",
  textMuted: "text-[#6B7280]",

  // Tabs
  tabActive: "bg-[#1B3A57] text-white px-4 py-2 rounded-lg font-medium",
  tabInactive:
    "bg-transparent text-[#6B7280] hover:text-[#1B3A57] px-4 py-2 rounded-lg font-medium transition-colors",

  // Badges
  badgeGold:
    "bg-[#E8DCC8] text-[#B8956A] px-3 py-1 rounded-full text-sm font-medium",
  badgeNavy:
    "bg-[#3A5A78] text-white px-3 py-1 rounded-full text-sm font-medium",
  badgeSuccess:
    "bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium",
  badgeWarning:
    "bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium",
  badgeError:
    "bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium",

  // Dividers
  divider: "h-px bg-[#C8A882]",
  dividerLight: "h-px bg-[#E5E7EB]",
};

// Component-specific color combinations
export const BRAND_COMPONENTS = {
  dashboard: {
    background: BRAND_COLORS.neutral.offWhite,
    cardBg: BRAND_COLORS.neutral.white,
    headerBg: BRAND_COLORS.navy.main,
    accentBorder: BRAND_COLORS.gold.main,
  },

  trading: {
    longBg: "bg-green-50",
    longText: "text-green-700",
    longBorder: "border-green-200",
    shortBg: "bg-red-50",
    shortText: "text-red-700",
    shortBorder: "border-red-200",
  },

  biometric: {
    improving: BRAND_COLORS.success,
    stable: BRAND_COLORS.gold.main,
    declining: BRAND_COLORS.error,
  },
};

export default BRAND_COLORS;
