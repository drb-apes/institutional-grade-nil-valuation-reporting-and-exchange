/**
 * BIM-APES Translation Utility
 * Multi-language support for the entire platform
 */

const SUPPORTED_LANGUAGES = {
  en: { name: "English", flag: "🇬🇧" },
  es: { name: "Español", flag: "🇪🇸" },
  fr: { name: "Français", flag: "🇫🇷" },
  de: { name: "Deutsch", flag: "🇩🇪" },
  it: { name: "Italiano", flag: "🇮🇹" },
  pt: { name: "Português", flag: "🇵🇹" },
  zh: { name: "中文", flag: "🇨🇳" },
  ja: { name: "日本語", flag: "🇯🇵" },
  ar: { name: "العربية", flag: "🇸🇦" },
  ru: { name: "Русский", flag: "🇷🇺" },
};

// Translation cache to avoid repeated API calls
const translationCache = new Map();

/**
 * Translate text using Google Translate API
 */
export async function translateText(text, targetLang, sourceLang = "en") {
  if (!text || targetLang === "en") return text;

  const cacheKey = `${sourceLang}:${targetLang}:${text}`;
  if (translationCache.has(cacheKey)) {
    return translationCache.get(cacheKey);
  }

  try {
    const response = await fetch(
      "/integrations/google-translate/language/translate/v2",
      {
        method: "POST",
        body: new URLSearchParams({
          q: text,
          target: targetLang,
          source: sourceLang,
        }),
      },
    );

    const data = await response.json();
    const translated = data.data?.translations?.[0]?.translatedText || text;

    translationCache.set(cacheKey, translated);
    return translated;
  } catch (error) {
    console.error("Translation error:", error);
    return text;
  }
}

/**
 * Translate multiple texts in batch
 */
export async function translateBatch(texts, targetLang, sourceLang = "en") {
  if (!texts?.length || targetLang === "en") return texts;

  try {
    const params = new URLSearchParams();
    texts.forEach((text) => params.append("q", text));
    params.append("target", targetLang);
    if (sourceLang) params.append("source", sourceLang);

    const response = await fetch(
      "/integrations/google-translate/language/translate/v2",
      {
        method: "POST",
        body: params,
      },
    );

    const data = await response.json();
    return data.data?.translations?.map((t) => t.translatedText) || texts;
  } catch (error) {
    console.error("Batch translation error:", error);
    return texts;
  }
}

/**
 * Get user's preferred language from storage
 */
export function getStoredLanguage() {
  if (typeof window === "undefined") return "en";
  return localStorage.getItem("bim-apes-language") || "en";
}

/**
 * Store user's language preference
 */
export function setStoredLanguage(lang) {
  if (typeof window === "undefined") return;
  localStorage.setItem("bim-apes-language", lang);
}

/**
 * Detect browser language
 */
export function detectBrowserLanguage() {
  if (typeof window === "undefined") return "en";

  const browserLang = navigator.language?.split("-")[0] || "en";
  return SUPPORTED_LANGUAGES[browserLang] ? browserLang : "en";
}

export { SUPPORTED_LANGUAGES };
