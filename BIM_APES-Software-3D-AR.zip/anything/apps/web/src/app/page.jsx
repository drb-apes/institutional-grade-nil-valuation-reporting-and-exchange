"use client";

import { useState } from "react";
import {
  Brain,
  Activity,
  TrendingUp,
  Shield,
  AlertCircle,
  Zap,
  Users,
  Target,
  BarChart3,
  Globe,
  Heart,
  Tv,
  FlaskConical,
  Database,
  CheckCircle,
  FileText,
  DollarSign,
  Settings,
  Youtube,
} from "lucide-react";

export default function HomePage() {
  const [seeding, setSeeding] = useState(false);
  const [seeded, setSeeded] = useState(false);

  const handleSeedData = async () => {
    setSeeding(true);
    try {
      const r1 = await fetch("/api/database/seed-athletes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ count: 25 }),
      });
      const r2 = await fetch("/api/database/seed-biometrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hours: 48, frequency: 4 }),
      });
      if (r1.ok && r2.ok) setSeeded(true);
    } catch (e) {
      console.error("Seed error:", e);
    } finally {
      setSeeding(false);
    }
  };

  const dashboards = [
    {
      icon: Brain,
      title: "Intelligence Dashboard",
      description:
        "Real-time stress, fatigue, recovery & training intelligence with AR overlays and market signals",
      href: "/intelligence-dashboard",
      color: "#C8A882",
      badge: "FLAGSHIP",
      features: [
        "Stress Intelligence",
        "Fatigue Tracking",
        "Recovery Analysis",
        "Market Signals",
      ],
    },
    {
      icon: Activity,
      title: "Coach Dashboard",
      description:
        "Athlete roster management, NIL valuation, and AR biomechanical visualization",
      href: "/coach-dashboard",
      color: "#1B3A57",
      badge: null,
      features: [
        "Roster Management",
        "Biometric Tracking",
        "NIL Valuation",
        "Risk Forecasting",
      ],
    },
    {
      icon: TrendingUp,
      title: "Investor Dashboard",
      description:
        "NIL portfolio management, mispricing detection, and trading position management",
      href: "/investor-dashboard",
      color: "#10B981",
      badge: null,
      features: [
        "Portfolio Overview",
        "NIL Matrix",
        "Trading Signals",
        "Position Management",
      ],
    },
    {
      icon: Globe,
      title: "NIL Analytics System",
      description:
        "Model NIL vs Market NIL dual-track engine with Azure-powered divergence scoring — Bull/Sideways/Bear signals",
      href: "/nil-analytics",
      color: "#60A5FA",
      badge: "NEW",
      features: [
        "Model NIL Track",
        "Market NIL Track",
        "Divergence Engine",
        "Trading Signals",
      ],
    },
    {
      icon: Youtube,
      title: "Fan Engagement Hub",
      description:
        "Fan segmentation, YouTube overlays, NIL-driven merch campaigns, and sponsor blockchain integrations",
      href: "/fan-engagement",
      color: "#EF4444",
      badge: "NEW",
      features: [
        "Fan Segments",
        "YouTube Overlays",
        "Merch Campaigns",
        "Blockchain Rewards",
      ],
    },
    {
      icon: Globe,
      title: "Federation Dashboard",
      description:
        "Coalition management, athlete oversight, and global expansion tracking",
      href: "/federation-dashboard",
      color: "#8B5CF6",
      badge: null,
      features: [
        "Coalition Metrics",
        "Sport Distribution",
        "NIL Tier Analysis",
        "Expansion Tools",
      ],
    },
    {
      icon: Target,
      title: "Sponsor ROI Dashboard",
      description:
        "Campaign performance, ROI calculator, and distribution channel analytics",
      href: "/sponsor-roi-dashboard",
      color: "#F59E0B",
      badge: null,
      features: [
        "Campaign Tracking",
        "ROI Calculator",
        "Channel Analytics",
        "Engagement Metrics",
      ],
    },
    {
      icon: Heart,
      title: "Medical Dashboard",
      description:
        "AR spatial intelligence for athlete health, injury prediction, and recovery",
      href: "/console/medical-dashboard",
      color: "#EF4444",
      badge: null,
      features: [
        "Collapse Prediction",
        "Impact Analysis",
        "Joint Divergence",
        "Recovery Envelope",
      ],
    },
    {
      icon: Tv,
      title: "Broadcast Control",
      description:
        "Multi-platform AR overlay command center for live events and broadcasts",
      href: "/broadcast-control",
      color: "#8B5CF6",
      badge: null,
      features: [
        "AR Overlays",
        "Stadium Display",
        "Broadcast Partners",
        "Live Preview",
      ],
    },
    {
      icon: FlaskConical,
      title: "XR Performance Lab",
      description: "3D visualization of combat sports performance intelligence",
      href: "/xr-lab",
      color: "#06B6D4",
      badge: null,
      features: ["3D Visualization", "Wrestling", "Boxing/MMA", "Live Metrics"],
    },
    {
      icon: BarChart3,
      title: "Console Dashboard",
      description:
        "Full administrative console with athlete management, alerts, and system monitoring",
      href: "/console",
      color: "#6B7280",
      badge: null,
      features: [
        "Athlete Registry",
        "Event Tracking",
        "Alert Management",
        "AR Engine",
      ],
    },
  ];

  const capabilities = [
    {
      icon: Brain,
      title: "1000 Biometric Indices",
      description:
        "Complete physiological intelligence across all body systems",
    },
    {
      icon: Zap,
      title: "24 AR Overlay Methods",
      description:
        "Real-time biomechanical AR system for broadcast and coaching",
    },
    {
      icon: DollarSign,
      title: "NIL Valuation 2.0",
      description:
        "Performance-weighted NIL scoring with coalition exposure multipliers",
    },
    {
      icon: Shield,
      title: "Medical Intelligence",
      description:
        "Collapse prediction, impact overload, joint divergence detection",
    },
    {
      icon: Activity,
      title: "Trading Engine",
      description:
        "Mispricing detection, scalping, arbitrage, and hedging strategies",
    },
    {
      icon: Globe,
      title: "NIL Divergence Engine",
      description:
        "Model NIL vs Market NIL with Bull/Sideways/Bear Azure signals",
    },
    {
      icon: Youtube,
      title: "Fan Engagement",
      description:
        "YouTube overlays, fan segmentation, merch campaigns, blockchain rewards",
    },
    {
      icon: Target,
      title: "Sponsor ROI System",
      description:
        "Real-time activation windows with performance-linked branding",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-[1400px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <a
              href="/"
              className="flex flex-col group cursor-pointer no-underline"
            >
              <h1 className="text-3xl font-bold text-[#1B3A57] tracking-tight">
                BLEDSOE
              </h1>
              <div className="h-0.5 bg-[#C8A882] w-full my-1 group-hover:h-1 transition-all"></div>
              <p className="text-sm text-[#1B3A57] tracking-wide font-serif">
                INVESTMENT MANAGEMENT
              </p>
            </a>
            <nav className="hidden md:flex items-center gap-5">
              <a
                href="/console"
                className="text-gray-700 hover:text-[#1B3A57] font-medium transition-colors no-underline text-sm"
              >
                Console
              </a>
              <a
                href="/nil-analytics"
                className="text-gray-700 hover:text-[#1B3A57] font-medium transition-colors no-underline text-sm"
              >
                NIL Analytics
              </a>
              <a
                href="/fan-engagement"
                className="text-gray-700 hover:text-[#1B3A57] font-medium transition-colors no-underline text-sm"
              >
                Fan Hub
              </a>
              <a
                href="/investor-dashboard"
                className="text-gray-700 hover:text-[#1B3A57] font-medium transition-colors no-underline text-sm"
              >
                Investor
              </a>
              <a
                href="/intelligence-dashboard"
                className="text-gray-700 hover:text-[#1B3A57] font-medium transition-colors no-underline text-sm"
              >
                Intelligence
              </a>
              <button
                onClick={handleSeedData}
                disabled={seeding || seeded}
                className="bg-[#1B3A57] hover:bg-[#152E45] text-white px-5 py-2.5 rounded-lg font-semibold transition-colors shadow-sm disabled:opacity-60 flex items-center gap-2 text-sm"
              >
                {seeding ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Seeding...
                  </>
                ) : seeded ? (
                  <>
                    <CheckCircle size={15} />
                    Data Ready!
                  </>
                ) : (
                  <>
                    <Database size={15} />
                    Seed Demo Data
                  </>
                )}
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="bg-gradient-to-br from-[#1B3A57] via-[#2A4A68] to-[#1B3A57] text-white">
        <div className="max-w-[1400px] mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <h2 className="text-6xl font-bold mb-4 tracking-tight">
              BIM<span className="text-[#C8A882]">-</span>APES
            </h2>
            <div className="h-1 w-32 bg-[#C8A882] mx-auto mb-6"></div>
            <p className="text-2xl text-white/90 font-light">
              Biometric Intelligence Management System
            </p>
            <p className="text-lg text-white/70 mt-2">
              Coalition-Grade Analytics for Performance, NIL Valuation & Trading
            </p>
            <div className="mt-8 flex items-center justify-center gap-4 flex-wrap">
              <a
                href="/console"
                className="bg-[#C8A882] hover:bg-[#B8956A] text-white px-8 py-3 rounded-xl font-bold transition-colors no-underline"
              >
                Open Console
              </a>
              <a
                href="/intelligence-dashboard"
                className="bg-white/10 hover:bg-white/20 border border-white/30 text-white px-8 py-3 rounded-xl font-bold transition-colors no-underline"
              >
                Intelligence Dashboard
              </a>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {[
              { value: "1000", label: "Biometric Indices" },
              { value: "24", label: "AR Overlay Methods" },
              { value: "11+", label: "Intelligence Dashboards" },
              { value: "24/7", label: "Real-Time Analysis" },
            ].map((stat, i) => (
              <div
                key={i}
                className="bg-white/10 backdrop-blur rounded-xl p-6 text-center border border-white/20"
              >
                <p className="text-4xl font-bold text-[#C8A882]">
                  {stat.value}
                </p>
                <p className="text-sm text-white/70 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Seed Data Banner */}
      {!seeded ? (
        <div className="bg-amber-50 border-b border-amber-200">
          <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <Database className="text-amber-600" size={20} />
              <p className="text-amber-800 font-medium">
                Seed demo data to populate all dashboards with 25 athletes + 48h
                biometric data
              </p>
            </div>
            <button
              onClick={handleSeedData}
              disabled={seeding}
              className="bg-amber-600 hover:bg-amber-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors disabled:opacity-60 flex items-center gap-2 text-sm"
            >
              {seeding ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Seeding...
                </>
              ) : seeded ? (
                <>
                  <CheckCircle size={15} />
                  Data Ready!
                </>
              ) : (
                <>
                  <Database size={15} />
                  Seed Demo Data Now
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50 border-b border-emerald-200">
          <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center gap-3">
            <CheckCircle className="text-emerald-600" size={20} />
            <p className="text-emerald-800 font-medium">
              Demo data seeded! All dashboards are now populated with real
              athlete and biometric data.
            </p>
          </div>
        </div>
      )}

      <div className="max-w-[1400px] mx-auto px-6 py-12">
        <div className="h-0.5 bg-[#C8A882] mb-12"></div>

        {/* 9 Dashboard Grid */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-[#1B3A57] mb-2 text-center">
            Choose Your Dashboard
          </h3>
          <div className="h-1 w-24 bg-[#C8A882] mx-auto mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dashboards.map((dash, idx) => {
              const Icon = dash.icon;
              return (
                <a
                  key={idx}
                  href={dash.href}
                  className="group bg-white rounded-xl shadow-sm border-2 border-gray-200 hover:border-[#C8A882] transition-all duration-300 overflow-hidden block no-underline hover:shadow-lg"
                >
                  <div className="p-5 bg-gradient-to-r from-[#1B3A57] to-[#2A4A68] relative">
                    {dash.badge && (
                      <span className="absolute top-3 right-3 bg-[#C8A882] text-white text-xs font-bold px-2 py-1 rounded-full">
                        {dash.badge}
                      </span>
                    )}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-white/10 rounded-lg border border-white/20">
                        <Icon size={20} style={{ color: dash.color }} />
                      </div>
                      <h4 className="text-base font-bold text-white">
                        {dash.title}
                      </h4>
                    </div>
                    <p className="text-white/75 text-xs leading-relaxed">
                      {dash.description}
                    </p>
                  </div>
                  <div className="p-4">
                    <div className="grid grid-cols-2 gap-1.5 mb-3">
                      {dash.features.map((f, fi) => (
                        <div
                          key={fi}
                          className="flex items-center gap-1.5 text-xs text-gray-600"
                        >
                          <div className="w-1.5 h-1.5 rounded-full bg-[#C8A882] flex-shrink-0"></div>
                          <span>{f}</span>
                        </div>
                      ))}
                    </div>
                    <div className="text-center text-sm font-semibold text-[#1B3A57] group-hover:text-[#C8A882] transition-colors">
                      Launch →
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>

        <div className="h-0.5 bg-[#C8A882] mb-16"></div>

        {/* Capabilities */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-[#1B3A57] mb-2 text-center">
            Platform Capabilities
          </h3>
          <div className="h-1 w-24 bg-[#C8A882] mx-auto mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {capabilities.map((cap, idx) => {
              const Icon = cap.icon;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-[#C8A882] transition-all"
                >
                  <div className="p-3 bg-[#E8DCC8] rounded-lg inline-block mb-3">
                    <Icon className="text-[#1B3A57]" size={20} />
                  </div>
                  <h4 className="font-bold text-[#1B3A57] mb-2 text-sm">
                    {cap.title}
                  </h4>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    {cap.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Intelligence Engines */}
        <div className="bg-gradient-to-r from-[#1B3A57] to-[#2A4A68] rounded-2xl p-8 text-white shadow-xl mb-12">
          <h3 className="text-2xl font-bold mb-2 text-center">
            Four Intelligence Engines
          </h3>
          <div className="h-1 w-24 bg-[#C8A882] mx-auto mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: AlertCircle,
                colorClass: "bg-red-500/20 text-red-400",
                title: "Stress Intelligence",
                desc: "Joint torque, GRF mapping, asymmetry detection, HRV stress response",
              },
              {
                icon: Zap,
                colorClass: "bg-orange-500/20 text-orange-400",
                title: "Fatigue Intelligence",
                desc: "Accumulation index, stride analysis, reaction lag, hydration tracking",
              },
              {
                icon: Activity,
                colorClass: "bg-green-500/20 text-green-400",
                title: "Recovery Intelligence",
                desc: "Sleep debt, HRV recovery, muscle soreness, tissue repair biomarkers",
              },
              {
                icon: Shield,
                colorClass: "bg-blue-500/20 text-blue-400",
                title: "Training Intelligence",
                desc: "ACWR monitoring, velocity loss, power output, technique drift detection",
              },
            ].map((engine, idx) => {
              const Icon = engine.icon;
              return (
                <div
                  key={idx}
                  className="bg-white/10 backdrop-blur rounded-xl p-6 border border-white/20"
                >
                  <div
                    className={`w-12 h-12 ${engine.colorClass} rounded-lg flex items-center justify-center mb-3`}
                  >
                    <Icon size={24} />
                  </div>
                  <h5 className="font-bold mb-2">{engine.title}</h5>
                  <p className="text-sm text-white/70">{engine.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { href: "/nil-analytics", icon: Globe, label: "NIL Analytics" },
            {
              href: "/fan-engagement",
              icon: Youtube,
              label: "Fan Engagement Hub",
            },
            { href: "/data-library", icon: Database, label: "Data Library" },
            { href: "/test-harness", icon: Settings, label: "Test Harness" },
          ].map((link, idx) => {
            const Icon = link.icon;
            return (
              <a
                key={idx}
                href={link.href}
                className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-[#C8A882] hover:bg-[#E8DCC8]/30 transition-all no-underline text-[#1B3A57]"
              >
                <Icon size={18} className="text-[#C8A882]" />
                <span className="font-medium text-sm">{link.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}
