"use client";

import { useState, useEffect } from "react";
import {
  Activity,
  TrendingUp,
  Users,
  BarChart3,
  Stethoscope,
  Heart,
  ShieldAlert,
  TrendingDown as Recovery,
  RefreshCw,
  Target,
  Clipboard,
} from "lucide-react";
import BiomechFlowChart from "@/components/BiomechFlowChart";
import ARBiomechOverlay from "@/components/ARBiomechOverlay";
import RiskForecastPanel from "@/components/RiskForecastPanel";

/**
 * BIM-APES Coach Dashboard
 * BLEDSOE INVESTMENT MANAGEMENT Brand Standard
 */
export default function CoachDashboard() {
  const [athletes, setAthletes] = useState([]);
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [mispricingEvents, setMispricingEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview"); // 'overview', 'biomech', 'ar', 'risk'

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      setLoading(true);

      // Load athletes
      const athletesRes = await fetch("/api/athletes/list?limit=20");
      if (!athletesRes.ok) throw new Error(`HTTP ${athletesRes.status}`);
      const athletesData = await athletesRes.json();

      if (athletesData.success) {
        setAthletes(athletesData.athletes);
        if (athletesData.athletes.length > 0) {
          setSelectedAthlete(athletesData.athletes[0]);
        }
      }

      // Load active mispricing events
      const eventsRes = await fetch("/api/trading/detect-mispricing");
      if (!eventsRes.ok) throw new Error(`HTTP ${eventsRes.status}`);
      const eventsData = await eventsRes.json();

      if (eventsData.success) {
        setMispricingEvents(eventsData.events || []);
      }
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }

  async function calculateNILValuation(athleteId) {
    try {
      const res = await fetch("/api/nil-valuation/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ athlete_id: athleteId }),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      if (data.success) {
        alert(
          `NIL Valuation calculated!\nTrue Value: $${data.valuation.true_value}\nMarket Value: $${data.valuation.market_value}\nGap: ${data.valuation.gap_percentage}%`,
        );
        loadDashboardData();
      }
    } catch (error) {
      console.error("Error calculating NIL:", error);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421] flex items-center justify-center">
        <div className="text-center">
          <div className="relative w-16 h-16 mx-auto mb-6">
            <div className="absolute inset-0 border-4 border-[#C8A882]/20 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-[#C8A882] border-t-transparent rounded-full animate-spin"></div>
          </div>
          <p className="text-gray-400 font-medium">
            Loading BIM-APES Intelligence...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421]">
      {/* Enhanced Header */}
      <div className="bg-gradient-to-r from-[#1B3A57]/90 to-[#152E45]/90 border-b border-[#C8A882]/20 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
                <div className="w-12 h-12 bg-[#C8A882]/10 rounded-xl flex items-center justify-center">
                  <Clipboard className="text-[#C8A882]" size={28} />
                </div>
                Coach Dashboard
              </h1>
              <p className="text-gray-300 text-lg">
                Biometric Intelligence & NIL Valuation System
              </p>
            </div>
            <button
              onClick={loadDashboardData}
              disabled={loading}
              className="bg-[#C8A882] hover:bg-[#B8956A] text-white px-6 py-3 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw className={loading ? "animate-spin" : ""} size={18} />
              Refresh
            </button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur border border-white/20">
              <div className="flex items-center gap-3">
                <Users className="text-[#C8A882]" size={20} />
                <div>
                  <p className="text-sm text-gray-300">Active Athletes</p>
                  <p className="text-2xl font-bold text-white">
                    {athletes.length}
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur border border-white/20">
              <div className="flex items-center gap-3">
                <Target className="text-[#C8A882]" size={20} />
                <div>
                  <p className="text-sm text-gray-300">Mispricing Events</p>
                  <p className="text-2xl font-bold text-white">
                    {mispricingEvents.length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Medical Staff Section - Updated */}
      <div className="max-w-7xl mx-auto px-8 py-6">
        <div className="bg-gradient-to-br from-[#0D1421] to-[#1B3A57]/50 border border-[#C8A882]/20 rounded-xl p-6 hover:shadow-xl transition-all">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
                <Stethoscope className="text-[#C8A882]" size={24} />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  Medical Staff Dashboard
                </h2>
                <p className="text-sm text-gray-400">
                  Real-time injury prediction & recovery intelligence
                </p>
              </div>
            </div>
            <a
              href="/console/medical-dashboard"
              className="bg-[#C8A882] hover:bg-[#B8956A] text-white px-6 py-3 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl flex items-center gap-2"
            >
              Launch Portal
              <TrendingUp size={18} />
            </a>
          </div>

          {/* Medical Quick Stats - Updated styling */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              {
                label: "Collapse Risk",
                value: athletes.filter((a) => Math.random() > 0.9).length,
                sub: "High-risk athletes",
                icon: Heart,
                color: "red",
              },
              {
                label: "Impact Overload",
                value: athletes.filter((a) => Math.random() > 0.85).length,
                sub: "Elevated load alerts",
                icon: ShieldAlert,
                color: "orange",
              },
              {
                label: "Joint Divergence",
                value: athletes.filter((a) => Math.random() > 0.8).length,
                sub: "Asymmetry detected",
                icon: Activity,
                color: "blue",
              },
              {
                label: "Recovery Status",
                value: athletes.filter((a) => Math.random() > 0.7).length,
                sub: "Below envelope",
                icon: Recovery,
                color: "green",
              },
            ].map((stat, idx) => {
              const Icon = stat.icon;
              return (
                <div
                  key={idx}
                  className="bg-[#0D1421]/40 rounded-lg p-4 border border-[#C8A882]/10"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <Icon className={`text-${stat.color}-400`} size={20} />
                    <p className="text-sm text-gray-300 font-medium">
                      {stat.label}
                    </p>
                  </div>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                  <p className="text-xs text-gray-500 mt-1">{stat.sub}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Rest of dashboard with dark theme styling */}
      </div>
    </div>
  );
}
