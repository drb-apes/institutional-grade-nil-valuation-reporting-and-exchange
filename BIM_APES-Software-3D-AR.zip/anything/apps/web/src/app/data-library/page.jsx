"use client";

import { useState, useEffect } from "react";
import { BRAND_COLORS } from "@/utils/brandColors";

export default function DataLibraryPage() {
  const [userRole, setUserRole] = useState("coach");
  const [userId, setUserId] = useState("user-123");
  const [availableDatasets, setAvailableDatasets] = useState([]);
  const [activeStreams, setActiveStreams] = useState([]);
  const [selectedView, setSelectedView] = useState("s3-pull");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);

  useEffect(() => {
    loadAvailableDatasets();
    loadActiveStreams();
  }, [userRole, userId]);

  async function loadAvailableDatasets() {
    try {
      const response = await fetch(
        `/api/data-library/s3-pull?user_role=${userRole}&user_id=${userId}`,
      );
      const data = await response.json();
      setAvailableDatasets(data.datasets || []);
    } catch (error) {
      console.error("Failed to load datasets:", error);
    }
  }

  async function loadActiveStreams() {
    try {
      const response = await fetch(
        `/api/data-library/stream/register?user_role=${userRole}&user_id=${userId}`,
      );
      const data = await response.json();
      setActiveStreams(data.active_streams || []);
    } catch (error) {
      console.error("Failed to load streams:", error);
    }
  }

  async function pullS3Data(dataType) {
    setLoading(true);
    try {
      const response = await fetch("/api/data-library/s3-pull", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_role: userRole,
          user_id: userId,
          data_type: dataType,
          athlete_id: userId,
          date_range: {
            start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
              .toISOString()
              .split("T")[0],
            end: new Date().toISOString().split("T")[0],
          },
          format: "json",
        }),
      });

      const data = await response.json();
      setResults({
        type: "s3-pull",
        dataType,
        data,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("S3 pull error:", error);
      alert("Failed to pull data: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  async function registerStream(streamType) {
    setLoading(true);
    try {
      const response = await fetch("/api/data-library/stream/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_role: userRole,
          user_id: userId,
          stream_type: streamType,
          athlete_id: userId,
          frequency_hz: 30,
        }),
      });

      const data = await response.json();
      setResults({
        type: "stream-register",
        streamType,
        data,
        timestamp: new Date().toISOString(),
      });

      // Reload active streams
      await loadActiveStreams();
    } catch (error) {
      console.error("Stream registration error:", error);
      alert("Failed to register stream: " + error.message);
    } finally {
      setLoading(false);
    }
  }

  async function testLiveStream(streamUrl, accessToken) {
    // Open SSE connection
    const eventSource = new EventSource(streamUrl, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    let frameCount = 0;
    const maxFrames = 30; // Show 30 frames then close

    eventSource.onmessage = (event) => {
      frameCount++;
      const frame = JSON.parse(event.data);

      setResults((prev) => ({
        ...prev,
        liveData: frame,
        frameCount,
      }));

      if (frameCount >= maxFrames) {
        eventSource.close();
        alert(`Live stream test complete! Received ${frameCount} frames.`);
      }
    };

    eventSource.onerror = (error) => {
      console.error("SSE error:", error);
      eventSource.close();
    };
  }

  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: BRAND_COLORS.navy.dark }}
    >
      {/* Header */}
      <div
        style={{ backgroundColor: BRAND_COLORS.navy.main }}
        className="border-b border-gray-700"
      >
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-white mb-2">
            BIM-APES Data Library
          </h1>
          <p className="text-gray-300">
            S3 Raw Data Logs • Live Streaming • Private Endpoints
          </p>

          {/* Role Selector */}
          <div className="mt-6 flex gap-4 items-center">
            <label className="text-white font-medium">Select Role:</label>
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value)}
              className="px-4 py-2 rounded-lg bg-white text-gray-800 font-medium"
            >
              <option value="player">Player</option>
              <option value="coach">Coach</option>
              <option value="medical_staff">Medical Staff</option>
              <option value="team_admin">Team Admin</option>
              <option value="federation">Federation</option>
              <option value="broadcast">Broadcast</option>
            </select>

            <input
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              placeholder="User ID"
              className="px-4 py-2 rounded-lg bg-white text-gray-800"
            />
          </div>

          <div className="flex gap-4 mt-6">
            <button
              onClick={() => setSelectedView("s3-pull")}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                selectedView === "s3-pull"
                  ? "text-white"
                  : "text-gray-400 hover:text-white"
              }`}
              style={
                selectedView === "s3-pull"
                  ? { backgroundColor: BRAND_COLORS.gold.main }
                  : {}
              }
            >
              📦 S3 Data Pull
            </button>
            <button
              onClick={() => setSelectedView("live-stream")}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                selectedView === "live-stream"
                  ? "text-white"
                  : "text-gray-400 hover:text-white"
              }`}
              style={
                selectedView === "live-stream"
                  ? { backgroundColor: BRAND_COLORS.gold.main }
                  : {}
              }
            >
              📡 Live Streaming
            </button>
            <button
              onClick={() => setSelectedView("active-streams")}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                selectedView === "active-streams"
                  ? "text-white"
                  : "text-gray-400 hover:text-white"
              }`}
              style={
                selectedView === "active-streams"
                  ? { backgroundColor: BRAND_COLORS.gold.main }
                  : {}
              }
            >
              🔴 Active Streams ({activeStreams.length})
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* S3 Data Pull View */}
        {selectedView === "s3-pull" && (
          <div className="bg-white rounded-lg p-6 shadow-lg">
            <h3
              className="text-xl font-bold mb-4"
              style={{ color: BRAND_COLORS.navy.main }}
            >
              Available Datasets for {userRole}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {availableDatasets.map((dataset) => (
                <div
                  key={dataset.type}
                  className="p-6 border-2 rounded-lg hover:shadow-md transition-shadow"
                  style={{ borderColor: BRAND_COLORS.gold.light }}
                >
                  <h4 className="font-bold text-lg mb-2">{dataset.type}</h4>
                  <p className="text-sm text-gray-600 mb-4">
                    {dataset.description}
                  </p>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700 font-medium">
                      Access: {dataset.access}
                    </span>
                  </div>
                  <button
                    onClick={() => pullS3Data(dataset.type)}
                    disabled={loading}
                    className="w-full py-2 rounded-lg text-white font-semibold transition-colors disabled:opacity-50"
                    style={{ backgroundColor: BRAND_COLORS.navy.main }}
                  >
                    Pull Data
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Live Streaming View */}
        {selectedView === "live-stream" && (
          <div className="bg-white rounded-lg p-6 shadow-lg">
            <h3
              className="text-xl font-bold mb-4"
              style={{ color: BRAND_COLORS.navy.main }}
            >
              Register Live Stream Endpoint
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  type: "biometric_realtime",
                  desc: "Real-time biometric data (30-60 Hz)",
                  role: ["player", "coach", "medical_staff"],
                },
                {
                  type: "performance_live",
                  desc: "Live performance metrics",
                  role: ["player", "coach"],
                },
                {
                  type: "ar_medical_live",
                  desc: "AR medical overlay stream",
                  role: ["medical_staff", "coach"],
                },
                {
                  type: "team_session_live",
                  desc: "Team session live feed",
                  role: ["coach", "team_admin"],
                },
                {
                  type: "ar_overlay_live",
                  desc: "AR overlay broadcast",
                  role: ["coach", "broadcast"],
                },
                {
                  type: "medical_alerts_live",
                  desc: "Medical alerts stream",
                  role: ["medical_staff"],
                },
              ]
                .filter((s) => s.role.includes(userRole))
                .map((stream) => (
                  <div
                    key={stream.type}
                    className="p-6 border-2 rounded-lg"
                    style={{ borderColor: BRAND_COLORS.gold.main }}
                  >
                    <h4 className="font-bold text-lg mb-2">{stream.type}</h4>
                    <p className="text-sm text-gray-600 mb-4">{stream.desc}</p>
                    <button
                      onClick={() => registerStream(stream.type)}
                      disabled={loading}
                      className="w-full py-2 rounded-lg text-white font-semibold transition-colors disabled:opacity-50"
                      style={{ backgroundColor: BRAND_COLORS.gold.main }}
                    >
                      Register Stream
                    </button>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Active Streams View */}
        {selectedView === "active-streams" && (
          <div className="bg-white rounded-lg p-6 shadow-lg">
            <h3
              className="text-xl font-bold mb-4"
              style={{ color: BRAND_COLORS.navy.main }}
            >
              Your Active Streams
            </h3>
            {activeStreams.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                No active streams. Register a new stream to get started.
              </div>
            ) : (
              <div className="space-y-4">
                {activeStreams.map((stream) => (
                  <div
                    key={stream.stream_id}
                    className="p-6 bg-gray-50 rounded-lg"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-bold text-lg">
                          {stream.stream_type}
                        </h4>
                        <div className="text-sm text-gray-600 mt-1">
                          Stream ID: {stream.stream_id}
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-semibold ${
                          stream.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {stream.status}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 mb-2">
                      Created: {new Date(stream.created_at).toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">
                      Expires: {new Date(stream.expires_at).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Results Display */}
        {results && (
          <div className="mt-8 bg-white rounded-lg p-6 shadow-lg">
            <div className="flex justify-between items-center mb-4">
              <h3
                className="text-xl font-bold"
                style={{ color: BRAND_COLORS.navy.main }}
              >
                Results
              </h3>
              <button
                onClick={() => setResults(null)}
                className="px-4 py-2 rounded bg-gray-200 text-gray-700 hover:bg-gray-300"
              >
                Clear
              </button>
            </div>

            {results.type === "s3-pull" && (
              <div>
                <div className="mb-4 p-4 bg-blue-50 rounded">
                  <div className="font-semibold">
                    Data Type: {results.dataType}
                  </div>
                  <div className="text-sm text-gray-600">
                    Pulled: {results.timestamp}
                  </div>
                  {results.data.metadata && (
                    <div className="mt-2 text-sm">
                      <div>Records: {results.data.metadata.record_count}</div>
                      <div>Source: {results.data.metadata.source}</div>
                      <div>
                        Access Level: {results.data.metadata.access_level}
                      </div>
                    </div>
                  )}
                </div>
                <details className="mb-4">
                  <summary className="cursor-pointer font-semibold text-gray-700 hover:text-gray-900">
                    View Raw Data
                  </summary>
                  <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-x-auto">
                    {JSON.stringify(
                      results.data.data?.slice(0, 5) || results.data,
                      null,
                      2,
                    )}
                  </pre>
                </details>
              </div>
            )}

            {results.type === "stream-register" && results.data.success && (
              <div>
                <div className="mb-4 p-4 bg-green-50 rounded">
                  <div className="font-semibold text-green-800 mb-2">
                    ✓ Stream Registered Successfully
                  </div>
                  <div className="text-sm mb-2">
                    Stream ID: {results.data.stream.stream_id}
                  </div>
                  <div className="text-sm mb-2">
                    Frequency: {results.data.stream.frequency_hz} Hz
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded">
                    <div className="font-semibold mb-2">WebSocket URL:</div>
                    <code className="text-xs bg-gray-200 px-2 py-1 rounded block overflow-x-auto">
                      {results.data.stream.websocket_url}
                    </code>
                  </div>

                  <div className="p-4 bg-gray-50 rounded">
                    <div className="font-semibold mb-2">HTTP SSE URL:</div>
                    <code className="text-xs bg-gray-200 px-2 py-1 rounded block overflow-x-auto">
                      {results.data.stream.http_stream_url}
                    </code>
                  </div>

                  <div className="p-4 bg-gray-50 rounded">
                    <div className="font-semibold mb-2">Access Token:</div>
                    <code className="text-xs bg-gray-200 px-2 py-1 rounded block overflow-x-auto">
                      {results.data.stream.access_token}
                    </code>
                  </div>

                  <button
                    onClick={() =>
                      testLiveStream(
                        results.data.stream.http_stream_url,
                        results.data.stream.access_token,
                      )
                    }
                    className="w-full py-3 rounded-lg text-white font-bold"
                    style={{ backgroundColor: BRAND_COLORS.gold.main }}
                  >
                    🔴 Test Live Stream (30 frames)
                  </button>
                </div>

                {results.liveData && (
                  <div className="mt-4 p-4 bg-blue-50 rounded">
                    <div className="font-semibold mb-2">
                      Live Stream Data (Frame {results.frameCount}):
                    </div>
                    <pre className="text-xs bg-white p-3 rounded overflow-x-auto">
                      {JSON.stringify(results.liveData, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
