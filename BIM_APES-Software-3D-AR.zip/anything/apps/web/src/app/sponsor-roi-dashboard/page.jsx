"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/shared/DashboardLayout";
import { BRAND_COLORS } from "@/utils/brandColors";

export default function SponsorROIDashboard() {
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [campaignDetails, setCampaignDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  // ROI Calculator State
  const [roiInputs, setRoiInputs] = useState({
    incrementalSales: 150000,
    mediaValue: 80000,
    brandLift: 30000,
    activationCost: 50000,
  });

  useEffect(() => {
    loadCampaigns();
  }, []);

  useEffect(() => {
    if (selectedCampaign) {
      loadCampaignDetails(selectedCampaign);
    }
  }, [selectedCampaign]);

  const loadCampaigns = async () => {
    try {
      // For now, create sample campaigns via seeding
      setLoading(false);
    } catch (error) {
      console.error("Failed to load campaigns:", error);
      setLoading(false);
    }
  };

  const loadCampaignDetails = async (campaignId) => {
    try {
      const response = await fetch(`/api/sponsor/campaign/${campaignId}`);
      const data = await response.json();

      if (data.success) {
        setCampaignDetails(data);
      }
    } catch (error) {
      console.error("Failed to load campaign details:", error);
    }
  };

  const calculateROI = () => {
    const { incrementalSales, mediaValue, brandLift, activationCost } =
      roiInputs;
    const netGain = incrementalSales + mediaValue + brandLift - activationCost;
    const roi = activationCost > 0 ? (netGain / activationCost) * 100 : 0;
    return {
      netGain,
      roi,
    };
  };

  const { netGain, roi } = calculateROI();

  // Sample campaign data for demonstration
  const sampleCampaigns = [
    {
      id: "1",
      sponsor_name: "Nike",
      campaign_name: "Speed Index AR Overlay",
      campaign_type: "ar_overlay",
      pricing_model: "cpm",
      cpm_rate: 25,
      impressions: 2000000,
      engagement_rate: 5.2,
      cost: 50000,
      roi: 220,
    },
    {
      id: "2",
      sponsor_name: "Gatorade",
      campaign_name: "Recovery Challenge",
      campaign_type: "in_game_challenge",
      pricing_model: "flat_fee",
      flat_fee_amount: 100000,
      impressions: 1000000,
      engagement_rate: 7.0,
      cost: 100000,
      roi: 180,
    },
    {
      id: "3",
      sponsor_name: "Under Armour",
      campaign_name: "Performance Poll",
      campaign_type: "branded_poll",
      pricing_model: "cpm",
      cpm_rate: 18,
      impressions: 500000,
      engagement_rate: 8.0,
      cost: 9000,
      roi: 250,
    },
  ];

  // Distribution channels data
  const distributionChannels = [
    {
      channel: "Broadcaster",
      weight: 40,
      revenue: 400000,
      notes: "Annual or per-event",
    },
    {
      channel: "OTT Platform",
      weight: 35,
      revenue: 350000,
      notes: "Based on AR content consumption",
    },
    {
      channel: "Digital Channel",
      weight: 25,
      revenue: 225000,
      notes: "Ad-supported, variable by impressions",
    },
  ];

  return (
    <DashboardLayout
      title="Sponsor Activation ROI Dashboard"
      description="Track campaign performance, engagement metrics, and revenue allocation"
    >
      <div className="space-y-6">
        {/* Active Campaigns Section */}
        <div>
          <h2
            className="text-xl font-bold mb-4"
            style={{ color: BRAND_COLORS.navy.main }}
          >
            📊 Active Campaigns
          </h2>
          <div className="grid gap-4">
            {sampleCampaigns.map((campaign) => (
              <div
                key={campaign.id}
                className="p-6 rounded-lg border-2 cursor-pointer transition-all hover:scale-[1.02]"
                style={{
                  backgroundColor: "white",
                  borderColor:
                    selectedCampaign === campaign.id
                      ? BRAND_COLORS.gold.main
                      : "#E5E7EB",
                }}
                onClick={() => setSelectedCampaign(campaign.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3
                        className="text-lg font-bold"
                        style={{ color: BRAND_COLORS.navy.main }}
                      >
                        {campaign.sponsor_name} "{campaign.campaign_name}"
                      </h3>
                      <span
                        className="px-3 py-1 rounded-full text-sm font-medium"
                        style={{
                          backgroundColor: BRAND_COLORS.gold.pale,
                          color: BRAND_COLORS.navy.main,
                        }}
                      >
                        {campaign.campaign_type.replace("_", " ")}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      <div>
                        <div className="text-sm text-gray-600">Pricing</div>
                        <div
                          className="font-semibold"
                          style={{ color: BRAND_COLORS.navy.main }}
                        >
                          {campaign.pricing_model === "cpm"
                            ? `$${campaign.cpm_rate} CPM`
                            : `$${campaign.flat_fee_amount.toLocaleString()} Flat`}
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-gray-600">Impressions</div>
                        <div
                          className="font-semibold"
                          style={{ color: BRAND_COLORS.navy.main }}
                        >
                          {campaign.impressions.toLocaleString()}
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-gray-600">Engagement</div>
                        <div
                          className="font-semibold"
                          style={{ color: BRAND_COLORS.navy.main }}
                        >
                          {campaign.engagement_rate}%
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-gray-600">ROI</div>
                        <div
                          className="font-bold text-lg"
                          style={{ color: BRAND_COLORS.gold.main }}
                        >
                          {campaign.roi}%
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ROI Calculator Section */}
        <div>
          <h2
            className="text-xl font-bold mb-4"
            style={{ color: BRAND_COLORS.navy.main }}
          >
            💰 ROI Calculator
          </h2>
          <div
            className="p-6 rounded-lg border-2"
            style={{
              backgroundColor: "white",
              borderColor: BRAND_COLORS.gold.main,
            }}
          >
            <div className="grid gap-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label
                    className="block text-sm font-medium mb-2"
                    style={{ color: BRAND_COLORS.navy.main }}
                  >
                    Incremental Sales ($)
                  </label>
                  <input
                    type="number"
                    value={roiInputs.incrementalSales}
                    onChange={(e) =>
                      setRoiInputs({
                        ...roiInputs,
                        incrementalSales: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-4 py-2 border-2 rounded-lg"
                    style={{ borderColor: BRAND_COLORS.gold.light }}
                  />
                </div>

                <div>
                  <label
                    className="block text-sm font-medium mb-2"
                    style={{ color: BRAND_COLORS.navy.main }}
                  >
                    Media Value ($)
                  </label>
                  <input
                    type="number"
                    value={roiInputs.mediaValue}
                    onChange={(e) =>
                      setRoiInputs({
                        ...roiInputs,
                        mediaValue: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-4 py-2 border-2 rounded-lg"
                    style={{ borderColor: BRAND_COLORS.gold.light }}
                  />
                </div>

                <div>
                  <label
                    className="block text-sm font-medium mb-2"
                    style={{ color: BRAND_COLORS.navy.main }}
                  >
                    Brand Lift ($)
                  </label>
                  <input
                    type="number"
                    value={roiInputs.brandLift}
                    onChange={(e) =>
                      setRoiInputs({
                        ...roiInputs,
                        brandLift: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-4 py-2 border-2 rounded-lg"
                    style={{ borderColor: BRAND_COLORS.gold.light }}
                  />
                </div>

                <div>
                  <label
                    className="block text-sm font-medium mb-2"
                    style={{ color: BRAND_COLORS.navy.main }}
                  >
                    Activation Cost ($)
                  </label>
                  <input
                    type="number"
                    value={roiInputs.activationCost}
                    onChange={(e) =>
                      setRoiInputs({
                        ...roiInputs,
                        activationCost: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-4 py-2 border-2 rounded-lg"
                    style={{ borderColor: BRAND_COLORS.gold.light }}
                  />
                </div>
              </div>

              <div
                className="mt-4 p-4 rounded-lg"
                style={{ backgroundColor: BRAND_COLORS.gold.pale }}
              >
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-700">Net Gain</div>
                    <div
                      className="text-2xl font-bold"
                      style={{ color: BRAND_COLORS.navy.main }}
                    >
                      ${netGain.toLocaleString()}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-gray-700">ROI</div>
                    <div
                      className="text-3xl font-bold"
                      style={{ color: BRAND_COLORS.gold.main }}
                    >
                      {roi.toFixed(0)}%
                    </div>
                  </div>
                </div>

                <div
                  className="mt-4 pt-4 border-t"
                  style={{ borderColor: BRAND_COLORS.gold.main }}
                >
                  <div
                    className="text-sm font-medium mb-2"
                    style={{ color: BRAND_COLORS.navy.main }}
                  >
                    Formula: ROI = (Incremental Sales + Media Value + Brand Lift
                    - Activation Cost) / Activation Cost
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Distribution Channels Section */}
        <div>
          <h2
            className="text-xl font-bold mb-4"
            style={{ color: BRAND_COLORS.navy.main }}
          >
            📡 Distribution Channels
          </h2>
          <div className="overflow-x-auto">
            <table
              className="w-full border-2 rounded-lg"
              style={{ borderColor: BRAND_COLORS.gold.main }}
            >
              <thead style={{ backgroundColor: BRAND_COLORS.navy.main }}>
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-bold text-white">
                    Channel
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-bold text-white">
                    Weight
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-bold text-white">
                    Revenue Allocation
                  </th>
                  <th className="px-6 py-3 text-left text-sm font-bold text-white">
                    Notes
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white">
                {distributionChannels.map((channel, idx) => (
                  <tr
                    key={idx}
                    className="border-b"
                    style={{ borderColor: "#E5E7EB" }}
                  >
                    <td
                      className="px-6 py-4 font-semibold"
                      style={{ color: BRAND_COLORS.navy.main }}
                    >
                      {channel.channel}
                    </td>
                    <td
                      className="px-6 py-4"
                      style={{ color: BRAND_COLORS.navy.main }}
                    >
                      {channel.weight}%
                    </td>
                    <td
                      className="px-6 py-4 font-bold"
                      style={{ color: BRAND_COLORS.gold.main }}
                    >
                      ${channel.revenue.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {channel.notes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Engagement Metrics Section */}
        <div>
          <h2
            className="text-xl font-bold mb-4"
            style={{ color: BRAND_COLORS.navy.main }}
          >
            📈 Engagement Metrics
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            <div
              className="p-6 rounded-lg border-2"
              style={{
                backgroundColor: "white",
                borderColor: BRAND_COLORS.gold.light,
              }}
            >
              <div className="text-sm text-gray-600 mb-2">
                AR Highlight Overlay
              </div>
              <div
                className="text-2xl font-bold"
                style={{ color: BRAND_COLORS.navy.main }}
              >
                5.0%
              </div>
              <div className="text-sm text-gray-500 mt-1">engagement rate</div>
            </div>

            <div
              className="p-6 rounded-lg border-2"
              style={{
                backgroundColor: "white",
                borderColor: BRAND_COLORS.gold.light,
              }}
            >
              <div className="text-sm text-gray-600 mb-2">
                In-Game Challenge
              </div>
              <div
                className="text-2xl font-bold"
                style={{ color: BRAND_COLORS.navy.main }}
              >
                7.0%
              </div>
              <div className="text-sm text-gray-500 mt-1">engagement rate</div>
            </div>

            <div
              className="p-6 rounded-lg border-2"
              style={{
                backgroundColor: "white",
                borderColor: BRAND_COLORS.gold.light,
              }}
            >
              <div className="text-sm text-gray-600 mb-2">Branded Poll</div>
              <div
                className="text-2xl font-bold"
                style={{ color: BRAND_COLORS.navy.main }}
              >
                8.0%
              </div>
              <div className="text-sm text-gray-500 mt-1">engagement rate</div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
