import Footer from "@/components/Footer";
import QueryProvider from "./QueryProvider";
import { LanguageProvider } from "@/utils/LanguageContext";

export const metadata = {
  title: "BIM-APES | Biometric Intelligence & NIL Valuation Platform",
  description:
    "Advanced biometric intelligence, NIL valuation, and sports performance analytics by Bledsoe Investment Management",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <LanguageProvider>
          <QueryProvider>
            {children}
            <Footer />
          </QueryProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
