import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Stadium Display Adapter API
 * Generates large-format, high-contrast AR overlays for stadium jumbotrons and LED displays
 * Optimized for viewing from 100+ feet away
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      display_type, // "jumbotron" | "led_ribbon" | "courtside_display" | "tunnel_display"
      display_resolution, // "1920x1080" | "3840x2160" | "7680x4320" | "custom"
      custom_resolution, // { width: number, height: number }
      lighting_conditions, // "bright_arena" | "dim_arena" | "outdoor_day" | "outdoor_night"
      content_type, // "performance_snapshot" | "nil_valuation" | "sponsor_activation" | "medical_alert" | "full_overlay"
      duration_seconds, // How long to display
    } = body;

    if (!athlete_id || !display_type || !content_type) {
      return Response.json(
        {
          error:
            "Missing required fields: athlete_id, display_type, content_type",
        },
        { status: 400 },
      );
    }

    // Get athlete data
    const athleteResult = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteResult.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteResult[0];

    // Get latest biometric readings
    const readings = await sql`
      SELECT 
        br.index_code,
        br.score,
        br.baseline,
        br.trend,
        br.recorded_at,
        bid.index_name,
        bid.cluster
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
      ORDER BY br.recorded_at DESC
      LIMIT 30
    `;

    // Get latest NIL valuation
    const valuationResult = await sql`
      SELECT * FROM nil_valuations
      WHERE athlete_id = ${athlete_id}
      ORDER BY calculated_at DESC
      LIMIT 1
    `;

    const valuation = valuationResult.length > 0 ? valuationResult[0] : null;

    // Get active mispricing events
    const mispricingResult = await sql`
      SELECT * FROM mispricing_events
      WHERE athlete_id = ${athlete_id}
        AND status = 'active'
        AND expires_at > NOW()
      ORDER BY detected_at DESC
      LIMIT 1
    `;

    // Generate stadium display content
    const displayContent = generateStadiumDisplayContent({
      athlete,
      readings,
      valuation,
      mispricingEvent: mispricingResult.length > 0 ? mispricingResult[0] : null,
      display_type,
      content_type,
    });

    // Apply stadium-specific formatting
    const resolution = getDisplayResolution(
      display_resolution,
      custom_resolution,
    );
    const formattedContent = applyStadiumFormatting({
      content: displayContent,
      display_type,
      resolution,
      lighting_conditions,
    });

    // Apply extreme contrast enhancements for stadium viewing
    const enhancedContent = applyStadiumEnhancements({
      content: formattedContent,
      lighting_conditions,
      distance_feet: getViewingDistance(display_type),
    });

    return Response.json({
      success: true,
      athlete_id,
      athlete_name: `${athlete.first_name} ${athlete.last_name}`,
      display_type,
      content_type,
      resolution,
      lighting_conditions,
      duration_seconds: duration_seconds || 8,
      display_content: enhancedContent,
      metadata: {
        generated_at: new Date().toISOString(),
        readings_count: readings.length,
        has_valuation: !!valuation,
        has_mispricing_event: mispricingResult.length > 0,
      },
    });
  } catch (error) {
    console.error("Stadium display generation error:", error);
    return Response.json(
      { error: "Failed to generate stadium display", details: error.message },
      { status: 500 },
    );
  }
}

// ================================================================================
// GENERATE STADIUM DISPLAY CONTENT
// ================================================================================
function generateStadiumDisplayContent({
  athlete,
  readings,
  valuation,
  mispricingEvent,
  display_type,
  content_type,
}) {
  const biometrics = aggregateBiometrics(readings);

  switch (content_type) {
    case "performance_snapshot":
      return generatePerformanceSnapshot({ athlete, biometrics, display_type });

    case "nil_valuation":
      return generateNILValuationDisplay({
        athlete,
        valuation,
        mispricingEvent,
        display_type,
      });

    case "sponsor_activation":
      return generateSponsorActivationDisplay({
        athlete,
        biometrics,
        valuation,
        display_type,
      });

    case "medical_alert":
      return generateMedicalAlertDisplay({ athlete, biometrics, display_type });

    case "full_overlay":
      return generateFullOverlayDisplay({
        athlete,
        biometrics,
        valuation,
        mispricingEvent,
        display_type,
      });

    default:
      return generatePerformanceSnapshot({ athlete, biometrics, display_type });
  }
}

// ================================================================================
// PERFORMANCE SNAPSHOT
// ================================================================================
function generatePerformanceSnapshot({ athlete, biometrics, display_type }) {
  return {
    type: "performance_snapshot",
    layout: display_type === "jumbotron" ? "fullscreen" : "banner",
    elements: [
      {
        id: "athlete_name",
        type: "text",
        content: `${athlete.first_name} ${athlete.last_name}`.toUpperCase(),
        position: { x: 0.5, y: 0.15 },
        style: {
          font_size: 120,
          font_weight: "black",
          color: "#FFFFFF",
          stroke: "#000000",
          stroke_width: 8,
          text_align: "center",
        },
      },
      {
        id: "position_team",
        type: "text",
        content: `${athlete.position} • ${athlete.team}`.toUpperCase(),
        position: { x: 0.5, y: 0.25 },
        style: {
          font_size: 60,
          font_weight: "bold",
          color: "#C8A882",
          stroke: "#000000",
          stroke_width: 4,
          text_align: "center",
        },
      },
      {
        id: "readiness_meter",
        type: "radial_meter",
        label: "READINESS",
        value: biometrics.readiness?.score || 0,
        position: { x: 0.2, y: 0.5 },
        size: 280,
        style: {
          value_color: getStadiumColor(biometrics.readiness?.score || 0),
          track_color: "#333333",
          label_color: "#FFFFFF",
          label_size: 48,
          value_size: 96,
        },
      },
      {
        id: "power_meter",
        type: "radial_meter",
        label: "POWER",
        value: biometrics.power?.score || 0,
        position: { x: 0.5, y: 0.5 },
        size: 280,
        style: {
          value_color: getStadiumColor(biometrics.power?.score || 0),
          track_color: "#333333",
          label_color: "#FFFFFF",
          label_size: 48,
          value_size: 96,
        },
      },
      {
        id: "fatigue_meter",
        type: "radial_meter",
        label: "FATIGUE",
        value: biometrics.fatigue?.score || 0,
        position: { x: 0.8, y: 0.5 },
        size: 280,
        style: {
          value_color: getInverseStadiumColor(biometrics.fatigue?.score || 0),
          track_color: "#333333",
          label_color: "#FFFFFF",
          label_size: 48,
          value_size: 96,
        },
      },
    ],
    animation: {
      fade_in: 400,
      hold: 6000,
      fade_out: 400,
    },
  };
}

// ================================================================================
// NIL VALUATION DISPLAY
// ================================================================================
function generateNILValuationDisplay({
  athlete,
  valuation,
  mispricingEvent,
  display_type,
}) {
  const hasValuation = !!valuation;
  const hasMispricing = !!mispricingEvent;

  return {
    type: "nil_valuation",
    layout: "fullscreen_centered",
    elements: [
      {
        id: "athlete_name",
        type: "text",
        content: `${athlete.first_name} ${athlete.last_name}`.toUpperCase(),
        position: { x: 0.5, y: 0.12 },
        style: {
          font_size: 100,
          font_weight: "black",
          color: "#FFFFFF",
          stroke: "#000000",
          stroke_width: 6,
          text_align: "center",
        },
      },
      {
        id: "nil_label",
        type: "text",
        content: "NIL VALUE",
        position: { x: 0.5, y: 0.25 },
        style: {
          font_size: 56,
          font_weight: "bold",
          color: "#C8A882",
          stroke: "#000000",
          stroke_width: 3,
          text_align: "center",
        },
      },
      {
        id: "nil_value",
        type: "text",
        content: hasValuation
          ? `$${parseFloat(valuation.true_value).toLocaleString()}`
          : "$--",
        position: { x: 0.5, y: 0.45 },
        style: {
          font_size: 180,
          font_weight: "black",
          color: "#FFD700",
          stroke: "#000000",
          stroke_width: 10,
          text_align: "center",
          glow: true,
          glow_color: "#FFD700",
          glow_intensity: 40,
        },
      },
      {
        id: "gap_indicator",
        type: "text",
        content:
          hasValuation && parseFloat(valuation.gap) !== 0
            ? `${valuation.direction === "long" ? "+" : "-"}$${Math.abs(parseFloat(valuation.gap)).toLocaleString()} GAP`
            : "",
        position: { x: 0.5, y: 0.65 },
        style: {
          font_size: 72,
          font_weight: "bold",
          color: valuation?.direction === "long" ? "#00FF00" : "#FF0000",
          stroke: "#000000",
          stroke_width: 4,
          text_align: "center",
        },
      },
      {
        id: "momentum_badge",
        type: "badge",
        content: hasMispricing ? "MOMENTUM WINDOW ACTIVE" : "",
        position: { x: 0.5, y: 0.8 },
        style: {
          background: "#FFD700",
          color: "#000000",
          font_size: 64,
          font_weight: "black",
          padding: 20,
          border_radius: 12,
          pulse: true,
        },
      },
    ],
    animation: {
      fade_in: 500,
      hold: 10000,
      fade_out: 500,
    },
  };
}

// ================================================================================
// SPONSOR ACTIVATION DISPLAY
// ================================================================================
function generateSponsorActivationDisplay({
  athlete,
  biometrics,
  valuation,
  display_type,
}) {
  const sponsorName = "Nike"; // Would come from activation data
  const isHighPerformance =
    (biometrics.power?.score || 0) > 90 || (biometrics.speed?.score || 0) > 90;

  return {
    type: "sponsor_activation",
    layout: "branded_fullscreen",
    elements: [
      {
        id: "sponsor_logo",
        type: "image",
        src: "/sponsors/nike-logo-white.png",
        position: { x: 0.5, y: 0.15 },
        size: { width: 400, height: 200 },
        style: {
          filter: "drop-shadow(0 0 30px rgba(255,255,255,0.8))",
        },
      },
      {
        id: "activation_text",
        type: "text",
        content: "ATHLETE SPOTLIGHT",
        position: { x: 0.5, y: 0.3 },
        style: {
          font_size: 80,
          font_weight: "black",
          color: "#FFFFFF",
          stroke: "#000000",
          stroke_width: 5,
          text_align: "center",
        },
      },
      {
        id: "athlete_name",
        type: "text",
        content: `${athlete.first_name} ${athlete.last_name}`.toUpperCase(),
        position: { x: 0.5, y: 0.45 },
        style: {
          font_size: 140,
          font_weight: "black",
          color: "#FFD700",
          stroke: "#000000",
          stroke_width: 8,
          text_align: "center",
          glow: isHighPerformance,
          glow_color: "#FFD700",
          glow_intensity: 50,
        },
      },
      {
        id: "performance_badge",
        type: "badge",
        content: isHighPerformance ? "⚡ PEAK PERFORMANCE ⚡" : "",
        position: { x: 0.5, y: 0.65 },
        style: {
          background: "#FFD700",
          color: "#000000",
          font_size: 72,
          font_weight: "black",
          padding: 24,
          border_radius: 16,
          pulse: true,
          particle_effects: true,
        },
      },
      {
        id: "powered_by",
        type: "text",
        content: `POWERED BY ${sponsorName.toUpperCase()}`,
        position: { x: 0.5, y: 0.85 },
        style: {
          font_size: 56,
          font_weight: "bold",
          color: "#FFFFFF",
          stroke: "#000000",
          stroke_width: 3,
          text_align: "center",
        },
      },
    ],
    animation: {
      fade_in: 600,
      hold: 8000,
      fade_out: 400,
    },
  };
}

// ================================================================================
// MEDICAL ALERT DISPLAY
// ================================================================================
function generateMedicalAlertDisplay({ athlete, biometrics, display_type }) {
  const isCritical =
    (biometrics.fatigue?.score || 0) > 75 ||
    (biometrics.readiness?.score || 0) < 40;
  const alertSeverity = isCritical ? "CRITICAL" : "WARNING";
  const alertColor = isCritical ? "#FF0000" : "#FFB000";

  return {
    type: "medical_alert",
    layout: "alert_fullscreen",
    elements: [
      {
        id: "alert_icon",
        type: "icon",
        icon: "alert_triangle",
        position: { x: 0.5, y: 0.2 },
        size: 200,
        style: {
          color: alertColor,
          stroke: "#000000",
          stroke_width: 8,
          pulse: true,
        },
      },
      {
        id: "alert_severity",
        type: "text",
        content: `${alertSeverity} ALERT`,
        position: { x: 0.5, y: 0.38 },
        style: {
          font_size: 100,
          font_weight: "black",
          color: alertColor,
          stroke: "#000000",
          stroke_width: 6,
          text_align: "center",
        },
      },
      {
        id: "athlete_name",
        type: "text",
        content: `${athlete.first_name} ${athlete.last_name}`.toUpperCase(),
        position: { x: 0.5, y: 0.52 },
        style: {
          font_size: 120,
          font_weight: "black",
          color: "#FFFFFF",
          stroke: "#000000",
          stroke_width: 7,
          text_align: "center",
        },
      },
      {
        id: "alert_message",
        type: "text",
        content: isCritical
          ? "IMMEDIATE SUBSTITUTION REQUIRED"
          : "MONITOR CLOSELY",
        position: { x: 0.5, y: 0.7 },
        style: {
          font_size: 80,
          font_weight: "bold",
          color: "#FFFFFF",
          stroke: "#000000",
          stroke_width: 5,
          text_align: "center",
        },
      },
    ],
    animation: {
      fade_in: 200,
      hold: 15000,
      fade_out: 200,
    },
    emergency_override: isCritical,
  };
}

// ================================================================================
// FULL OVERLAY DISPLAY
// ================================================================================
function generateFullOverlayDisplay({
  athlete,
  biometrics,
  valuation,
  mispricingEvent,
  display_type,
}) {
  // Combines multiple data points into comprehensive view
  return {
    type: "full_overlay",
    layout: "quadrant",
    elements: [
      // Top banner - Athlete info
      {
        id: "athlete_banner",
        type: "banner",
        position: { x: 0.5, y: 0.08 },
        content: {
          name: `${athlete.first_name} ${athlete.last_name}`.toUpperCase(),
          position: athlete.position,
          team: athlete.team,
        },
        style: {
          background: "#1B3A57",
          border: "#C8A882",
          name_size: 100,
          info_size: 50,
        },
      },
      // Quadrant 1 - Performance metrics
      {
        id: "performance_quad",
        type: "metric_group",
        position: { x: 0.25, y: 0.4 },
        metrics: [
          { label: "READY", value: biometrics.readiness?.score || 0 },
          { label: "POWER", value: biometrics.power?.score || 0 },
        ],
      },
      // Quadrant 2 - NIL Value
      {
        id: "nil_quad",
        type: "value_display",
        position: { x: 0.75, y: 0.4 },
        value: valuation ? parseFloat(valuation.true_value) : 0,
        label: "NIL VALUE",
      },
      // Quadrant 3 - Fatigue/Recovery
      {
        id: "health_quad",
        type: "metric_group",
        position: { x: 0.25, y: 0.75 },
        metrics: [
          { label: "FATIGUE", value: biometrics.fatigue?.score || 0 },
          { label: "RECOVER", value: biometrics.recovery?.score || 0 },
        ],
      },
      // Quadrant 4 - Mispricing/Momentum
      {
        id: "momentum_quad",
        type: "status_display",
        position: { x: 0.75, y: 0.75 },
        status: mispricingEvent ? "MOMENTUM ACTIVE" : "MONITORING",
        color: mispricingEvent ? "#FFD700" : "#666666",
      },
    ],
    animation: {
      fade_in: 500,
      hold: 12000,
      fade_out: 500,
    },
  };
}

// ================================================================================
// STADIUM FORMATTING
// ================================================================================
function applyStadiumFormatting({
  content,
  display_type,
  resolution,
  lighting_conditions,
}) {
  return {
    ...content,
    format: {
      display_type,
      resolution,
      aspect_ratio: calculateAspectRatio(resolution),
      safe_zones: getStadiumSafeZones(display_type),
      canvas_background: "#000000", // Always black for max contrast
    },
  };
}

// ================================================================================
// STADIUM ENHANCEMENTS (Extreme contrast for long-distance viewing)
// ================================================================================
function applyStadiumEnhancements({
  content,
  lighting_conditions,
  distance_feet,
}) {
  const enhancements = {
    contrast_multiplier: 2.0, // Double all contrast
    saturation_boost: 1.8, // Hyper-saturate colors
    outline_width_multiplier: 3.0, // Triple-thick outlines
    text_shadow_depth: 20, // Deep shadows for legibility
    glow_intensity_multiplier: 2.5, // Amplify glows
    minimum_font_size: 48, // Never smaller than 48px
    stroke_width_minimum: 8, // Thick strokes always
  };

  // Adjust based on lighting
  if (lighting_conditions === "outdoor_day") {
    enhancements.contrast_multiplier = 2.5;
    enhancements.saturation_boost = 2.0;
    enhancements.outline_width_multiplier = 4.0;
  }

  // Adjust based on viewing distance
  if (distance_feet > 200) {
    enhancements.minimum_font_size = 72;
    enhancements.stroke_width_minimum = 12;
  }

  return {
    ...content,
    enhancements,
  };
}

// ================================================================================
// HELPER FUNCTIONS
// ================================================================================
function aggregateBiometrics(readings) {
  const grouped = {};

  readings.forEach((reading) => {
    if (!grouped[reading.cluster]) {
      grouped[reading.cluster] = [];
    }
    grouped[reading.cluster].push(reading);
  });

  const aggregated = {};
  for (const [cluster, clusterReadings] of Object.entries(grouped)) {
    if (clusterReadings.length > 0) {
      const latest = clusterReadings[0];
      aggregated[cluster.toLowerCase().replace(/ /g, "_")] = {
        score: parseFloat(latest.score),
        baseline: latest.baseline ? parseFloat(latest.baseline) : null,
        trend: latest.trend,
      };
    }
  }

  return aggregated;
}

function getStadiumColor(score) {
  if (score >= 85) return "#00FF00"; // Bright green
  if (score >= 70) return "#FFFF00"; // Bright yellow
  if (score >= 50) return "#FFB000"; // Orange
  return "#FF0000"; // Bright red
}

function getInverseStadiumColor(score) {
  if (score <= 30) return "#00FF00"; // Green (low is good)
  if (score <= 50) return "#FFFF00"; // Yellow
  if (score <= 70) return "#FFB000"; // Orange
  return "#FF0000"; // Red (high is bad)
}

function getDisplayResolution(display_resolution, custom_resolution) {
  const presets = {
    "1920x1080": { width: 1920, height: 1080 },
    "3840x2160": { width: 3840, height: 2160 },
    "7680x4320": { width: 7680, height: 4320 },
  };

  if (display_resolution === "custom" && custom_resolution) {
    return custom_resolution;
  }

  return presets[display_resolution] || presets["1920x1080"];
}

function calculateAspectRatio(resolution) {
  const gcd = (a, b) => (b === 0 ? a : gcd(b, a % b));
  const divisor = gcd(resolution.width, resolution.height);
  return `${resolution.width / divisor}:${resolution.height / divisor}`;
}

function getStadiumSafeZones(display_type) {
  const zones = {
    jumbotron: { top: 0.05, bottom: 0.05, left: 0.08, right: 0.08 },
    led_ribbon: { top: 0.1, bottom: 0.1, left: 0.05, right: 0.05 },
    courtside_display: { top: 0.08, bottom: 0.08, left: 0.08, right: 0.08 },
    tunnel_display: { top: 0.06, bottom: 0.06, left: 0.06, right: 0.06 },
  };
  return zones[display_type] || zones.jumbotron;
}

function getViewingDistance(display_type) {
  const distances = {
    jumbotron: 300, // 300 feet average
    led_ribbon: 150, // 150 feet
    courtside_display: 50, // 50 feet
    tunnel_display: 20, // 20 feet
  };
  return distances[display_type] || 100;
}
