import sql from "@/app/api/utils/sql";
import {
  notFoundError,
  validationError,
  internalError,
  successResponse,
} from "@/app/api/utils/errorHandler";

/**
 * Get NIL valuation history for a specific athlete
 * GET /api/nil/athlete/[id]?days=30
 */

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const { searchParams } = new URL(request.url);
    const days = parseInt(searchParams.get("days") || "30");

    // Verify athlete exists
    const [athlete] = await sql`
      SELECT id, first_name, last_name, date_of_birth, nil_tier 
      FROM athletes 
      WHERE id = ${id}
    `;

    if (!athlete) {
      return notFoundError("Athlete", id);
    }

    // Get NIL valuation history
    const valuations = await sql`
      SELECT 
        id,
        true_value,
        market_value,
        gap,
        gap_percentage,
        direction,
        confidence,
        convexity_factor,
        momentum_intensity,
        expected_close_seconds,
        valuation_method,
        calculated_at
      FROM nil_valuations
      WHERE athlete_id = ${id}
        AND calculated_at > NOW() - INTERVAL '${days} days'
      ORDER BY calculated_at ASC
    `;

    // Calculate age-based progression data for youth athletes
    let ageProgression = [];
    if (athlete.date_of_birth) {
      const birthDate = new Date(athlete.date_of_birth);
      const currentAge = Math.floor(
        (Date.now() - birthDate.getTime()) / (365.25 * 24 * 60 * 60 * 1000),
      );

      // Generate model NIL progression
      for (
        let age = Math.max(14, currentAge - 5);
        age <= Math.min(currentAge + 5, 25);
        age++
      ) {
        let modelNIL = 0;
        let marketNIL = 0;

        if (age < 18) {
          // Youth tier - development-focused valuation
          modelNIL = Math.pow(age - 13, 2.5) * 2.5;
          marketNIL = 0; // No market NIL for minors
        } else {
          // Adult tier - market-based valuation
          modelNIL = Math.pow(age - 13, 2.5) * 2.5;
          marketNIL = modelNIL * (0.85 + Math.random() * 0.3); // Market fluctuation
        }

        ageProgression.push({
          age,
          model_nil: Math.round(modelNIL * 100) / 100,
          market_nil: Math.round(marketNIL * 100) / 100,
        });
      }
    }

    // Get latest mispricing events
    const [latestMispricing] = await sql`
      SELECT 
        id,
        event_type,
        gap,
        direction,
        confidence,
        ttl_seconds,
        status,
        detected_at,
        expires_at
      FROM mispricing_events
      WHERE athlete_id = ${id}
      ORDER BY detected_at DESC
      LIMIT 1
    `;

    return successResponse({
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        nil_tier: athlete.nil_tier,
      },
      time_range: {
        days,
        from: new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString(),
        to: new Date().toISOString(),
      },
      valuations: valuations.map((v) => ({
        ...v,
        true_value: parseFloat(v.true_value),
        market_value: parseFloat(v.market_value),
        gap: parseFloat(v.gap),
        gap_percentage: parseFloat(v.gap_percentage),
        confidence: parseFloat(v.confidence),
        convexity_factor: v.convexity_factor
          ? parseFloat(v.convexity_factor)
          : null,
        momentum_intensity: v.momentum_intensity
          ? parseFloat(v.momentum_intensity)
          : null,
      })),
      age_progression: ageProgression,
      latest_mispricing: latestMispricing || null,
      summary: {
        total_valuations: valuations.length,
        latest_true_value:
          valuations.length > 0
            ? parseFloat(valuations[valuations.length - 1].true_value)
            : 0,
        latest_market_value:
          valuations.length > 0
            ? parseFloat(valuations[valuations.length - 1].market_value)
            : 0,
        avg_gap:
          valuations.length > 0
            ? valuations.reduce((sum, v) => sum + parseFloat(v.gap), 0) /
              valuations.length
            : 0,
        avg_confidence:
          valuations.length > 0
            ? valuations.reduce((sum, v) => sum + parseFloat(v.confidence), 0) /
              valuations.length
            : 0,
      },
    });
  } catch (error) {
    console.error("NIL valuation error:", error);
    return internalError(error, "fetching NIL valuation data");
  }
}

/**
 * Calculate new NIL valuation for an athlete
 * POST /api/nil/athlete/[id]
 */
export async function POST(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const {
      market_value,
      performance_metrics = {},
      social_metrics = {},
      force_recalculate = false,
    } = body;

    // Verify athlete exists
    const [athlete] = await sql`
      SELECT id, first_name, last_name, nil_tier 
      FROM athletes 
      WHERE id = ${id}
    `;

    if (!athlete) {
      return notFoundError("Athlete", id);
    }

    // Get latest biometric data for true value calculation
    const biometrics = await sql`
      SELECT index_code, score
      FROM biometric_readings
      WHERE athlete_id = ${id}
        AND recorded_at > NOW() - INTERVAL '24 hours'
      ORDER BY recorded_at DESC
      LIMIT 20
    `;

    // Calculate true value based on biometrics + performance
    let baseValue = 50.0; // Starting NIL value

    // Adjust based on biometric scores
    biometrics.forEach((b) => {
      const score = parseFloat(b.score);
      if (b.index_code.includes("Recovery")) baseValue += score * 0.5;
      if (b.index_code.includes("Performance")) baseValue += score * 0.7;
      if (b.index_code.includes("Fatigue")) baseValue -= (100 - score) * 0.3;
    });

    // Adjust for social metrics
    if (social_metrics.engagement_rate) {
      baseValue *= 1 + social_metrics.engagement_rate / 100;
    }

    const true_value = Math.max(10, baseValue);
    const actual_market_value =
      market_value || true_value * (0.9 + Math.random() * 0.2);
    const gap = true_value - actual_market_value;
    const gap_percentage = (gap / true_value) * 100;
    const direction = gap > 0 ? "long" : "short";
    const confidence = Math.min(0.95, 0.6 + (biometrics.length / 20) * 0.35);

    // Insert new valuation
    const [newValuation] = await sql`
      INSERT INTO nil_valuations (
        athlete_id,
        true_value,
        market_value,
        gap,
        gap_percentage,
        direction,
        confidence,
        valuation_method,
        calculated_at
      ) VALUES (
        ${id},
        ${true_value},
        ${actual_market_value},
        ${gap},
        ${gap_percentage},
        ${direction},
        ${confidence},
        'BIM-APES ML v2.0',
        NOW()
      )
      RETURNING *
    `;

    // If gap is significant, create mispricing event
    if (Math.abs(gap) > 5 && confidence > 0.7) {
      await sql`
        INSERT INTO mispricing_events (
          athlete_id,
          event_type,
          gap,
          direction,
          confidence,
          ttl_seconds,
          status,
          detected_at,
          expires_at
        ) VALUES (
          ${id},
          ${Math.abs(gap) > 15 ? "major_mispricing" : "minor_mispricing"},
          ${Math.abs(gap)},
          ${direction},
          ${confidence},
          ${Math.floor(3600 + Math.random() * 3600)},
          'active',
          NOW(),
          NOW() + INTERVAL '2 hours'
        )
      `;
    }

    return successResponse({
      valuation: {
        ...newValuation,
        true_value: parseFloat(newValuation.true_value),
        market_value: parseFloat(newValuation.market_value),
        gap: parseFloat(newValuation.gap),
        gap_percentage: parseFloat(newValuation.gap_percentage),
        confidence: parseFloat(newValuation.confidence),
      },
      message: "NIL valuation calculated successfully",
    });
  } catch (error) {
    console.error("NIL calculation error:", error);
    return internalError(error, "calculating NIL valuation");
  }
}
