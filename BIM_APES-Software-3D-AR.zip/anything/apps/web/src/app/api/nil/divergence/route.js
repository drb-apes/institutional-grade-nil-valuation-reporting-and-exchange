import sql from "@/app/api/utils/sql";

/**
 * NIL Divergence Engine
 * Calculates Model NIL Score vs Market NIL Score
 * and the divergence between them (Bull / Sideways / Bear)
 */

function getSentiment(score) {
  if (score >= 65) return { label: "Bull", color: "#10B981", emoji: "📈" };
  if (score >= 40) return { label: "Sideways", color: "#F59E0B", emoji: "➡️" };
  return { label: "Bear", color: "#EF4444", emoji: "📉" };
}

function calcModelNILScore(athlete, biometricReadings, sessions) {
  // Performance-based: biometrics, session consistency, recovery
  const readings = biometricReadings.filter((r) => r.athlete_id === athlete.id);
  const athleteSessions = sessions.filter((s) => s.athlete_id === athlete.id);

  // Biometric health score (50% weight)
  const avgScore = readings.length
    ? readings.reduce((s, r) => s + parseFloat(r.score || 50), 0) /
      readings.length
    : 50;

  // Session consistency (30% weight)
  const sessionScore = Math.min(100, athleteSessions.length * 10);

  // NIL tier premium (20% weight)
  const tierPremium =
    athlete.nil_tier === "Tier I"
      ? 90
      : athlete.nil_tier === "Tier II"
        ? 65
        : 40;

  const modelScore = avgScore * 0.5 + sessionScore * 0.3 + tierPremium * 0.2;
  return Math.min(100, Math.max(0, modelScore));
}

function calcMarketNILScore(athlete, valuations, mispricingEvents) {
  // Market-based: social momentum, market demand, sponsorship activity
  const latestVal = valuations.find((v) => v.athlete_id === athlete.id);
  const activeMispricing = mispricingEvents.filter(
    (m) => m.athlete_id === athlete.id && m.status === "active",
  );

  // Market value momentum (40%)
  const marketMomentum = latestVal
    ? Math.min(
        100,
        Math.max(0, 50 + parseFloat(latestVal.gap_percentage || 0) * 2),
      )
    : 50;

  // Confidence level (30%)
  const confidence = latestVal
    ? parseFloat(latestVal.confidence || 0.5) * 100
    : 50;

  // Mispricing activity / hype factor (30%)
  const hypeFactor = Math.min(100, 40 + activeMispricing.length * 20);

  const marketScore =
    marketMomentum * 0.4 + confidence * 0.3 + hypeFactor * 0.3;
  return Math.min(100, Math.max(0, marketScore));
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get("limit") || "20");

  try {
    const [athletes, biometrics, sessions, valuations, mispricingEvents] =
      await Promise.all([
        sql`SELECT * FROM athletes WHERE coalition_status = 'Active' ORDER BY created_at DESC LIMIT ${limit}`,
        sql`SELECT athlete_id, index_code, score FROM biometric_readings WHERE recorded_at > NOW() - INTERVAL '48 hours'`,
        sql`SELECT athlete_id, session_type, performance_score FROM performance_sessions WHERE started_at > NOW() - INTERVAL '7 days'`,
        sql`SELECT * FROM nil_valuations WHERE calculated_at > NOW() - INTERVAL '48 hours' ORDER BY calculated_at DESC`,
        sql`SELECT * FROM mispricing_events WHERE status = 'active'`,
      ]);

    const scores = athletes.map((athlete) => {
      const modelScore = calcModelNILScore(athlete, biometrics, sessions);
      const marketScore = calcMarketNILScore(
        athlete,
        valuations,
        mispricingEvents,
      );
      const divergence = marketScore - modelScore;

      const modelSentiment = getSentiment(modelScore);
      const marketSentiment = getSentiment(marketScore);

      // Divergence direction: overvalued (market > model) vs undervalued
      const divergenceType =
        divergence > 10
          ? "overvalued"
          : divergence < -10
            ? "undervalued"
            : "aligned";

      const tradingSignal =
        divergence > 15
          ? "SELL"
          : divergence < -15
            ? "BUY"
            : divergence > 8
              ? "SHORT"
              : divergence < -8
                ? "LONG"
                : "HOLD";

      return {
        athlete_id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        sport: athlete.sport,
        team: athlete.team,
        nil_tier: athlete.nil_tier,
        model_nil: {
          score: Math.round(modelScore * 10) / 10,
          sentiment: modelSentiment,
          inputs: {
            biometric_health: Math.round(
              biometrics
                .filter((r) => r.athlete_id === athlete.id)
                .reduce((s, r) => s + parseFloat(r.score || 50), 0) /
                Math.max(
                  1,
                  biometrics.filter((r) => r.athlete_id === athlete.id).length,
                ),
            ),
            session_count: sessions.filter((s) => s.athlete_id === athlete.id)
              .length,
            tier_premium: athlete.nil_tier,
          },
        },
        market_nil: {
          score: Math.round(marketScore * 10) / 10,
          sentiment: marketSentiment,
          inputs: {
            market_momentum:
              valuations.find((v) => v.athlete_id === athlete.id)
                ?.gap_percentage || 0,
            confidence:
              valuations.find((v) => v.athlete_id === athlete.id)?.confidence ||
              0.5,
            active_events: mispricingEvents.filter(
              (m) => m.athlete_id === athlete.id && m.status === "active",
            ).length,
          },
        },
        divergence: {
          value: Math.round(divergence * 10) / 10,
          type: divergenceType,
          trading_signal: tradingSignal,
          magnitude:
            Math.abs(divergence) > 20
              ? "high"
              : Math.abs(divergence) > 10
                ? "medium"
                : "low",
        },
      };
    });

    // Aggregate market sentiment
    const bullCount = scores.filter(
      (s) => s.model_nil.sentiment.label === "Bull",
    ).length;
    const bearCount = scores.filter(
      (s) => s.model_nil.sentiment.label === "Bear",
    ).length;
    const overallSentiment =
      bullCount > bearCount
        ? "Bull Market"
        : bearCount > bullCount
          ? "Bear Market"
          : "Sideways";

    // Top divergence opportunities
    const topOpportunities = scores
      .filter((s) => Math.abs(s.divergence.value) > 10)
      .sort(
        (a, b) => Math.abs(b.divergence.value) - Math.abs(a.divergence.value),
      )
      .slice(0, 5);

    return Response.json({
      success: true,
      summary: {
        total_athletes: scores.length,
        bull_count: bullCount,
        bear_count: bearCount,
        sideways_count: scores.filter(
          (s) => s.model_nil.sentiment.label === "Sideways",
        ).length,
        overall_market: overallSentiment,
        avg_model_score: Math.round(
          scores.reduce((s, a) => s + a.model_nil.score, 0) /
            Math.max(1, scores.length),
        ),
        avg_market_score: Math.round(
          scores.reduce((s, a) => s + a.market_nil.score, 0) /
            Math.max(1, scores.length),
        ),
        top_opportunities: topOpportunities,
        buy_signals: scores.filter(
          (s) =>
            s.divergence.trading_signal === "BUY" ||
            s.divergence.trading_signal === "LONG",
        ).length,
        sell_signals: scores.filter(
          (s) =>
            s.divergence.trading_signal === "SELL" ||
            s.divergence.trading_signal === "SHORT",
        ).length,
      },
      scores,
      data_sources: {
        wearables: { status: "connected", records: biometrics.length },
        team_performance: { status: "connected", records: sessions.length },
        youtube_social: {
          status: "simulated",
          records: Math.floor(Math.random() * 5000) + 1000,
        },
        merch_tickets: {
          status: "simulated",
          records: Math.floor(Math.random() * 1200) + 200,
        },
      },
    });
  } catch (error) {
    console.error("NIL Divergence Engine error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  // Calculate divergence for a specific athlete
  const body = await request.json();
  const { athlete_id } = body;

  if (!athlete_id)
    return Response.json(
      { success: false, error: "athlete_id required" },
      { status: 400 },
    );

  try {
    const [[athlete], biometrics, sessions, valuations, mispricingEvents] =
      await Promise.all([
        sql`SELECT * FROM athletes WHERE id = ${athlete_id}`,
        sql`SELECT athlete_id, index_code, score FROM biometric_readings WHERE athlete_id = ${athlete_id} AND recorded_at > NOW() - INTERVAL '48 hours'`,
        sql`SELECT * FROM performance_sessions WHERE athlete_id = ${athlete_id} AND started_at > NOW() - INTERVAL '7 days'`,
        sql`SELECT * FROM nil_valuations WHERE athlete_id = ${athlete_id} ORDER BY calculated_at DESC LIMIT 1`,
        sql`SELECT * FROM mispricing_events WHERE athlete_id = ${athlete_id} AND status = 'active'`,
      ]);

    if (!athlete)
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 404 },
      );

    const modelScore = calcModelNILScore(athlete, biometrics, sessions);
    const marketScore = calcMarketNILScore(
      athlete,
      valuations,
      mispricingEvents,
    );
    const divergence = marketScore - modelScore;

    return Response.json({
      success: true,
      athlete_id,
      name: `${athlete.first_name} ${athlete.last_name}`,
      model_nil: { score: modelScore, sentiment: getSentiment(modelScore) },
      market_nil: { score: marketScore, sentiment: getSentiment(marketScore) },
      divergence: {
        value: divergence,
        type:
          divergence > 10
            ? "overvalued"
            : divergence < -10
              ? "undervalued"
              : "aligned",
        trading_signal:
          divergence > 15
            ? "SELL"
            : divergence < -15
              ? "BUY"
              : divergence > 8
                ? "SHORT"
                : divergence < -8
                  ? "LONG"
                  : "HOLD",
      },
    });
  } catch (error) {
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
