/**
 * XR Broadcast Control API
 * Manages stadium display content and AR overlay selection
 */

import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      action, // 'push', 'clear', 'update'
      athlete_id,
      display_type = "jumbotron", // 'jumbotron', 'lower_third', 'sideline'
      content_type = "live_metrics", // 'live_metrics', 'nil_value', 'comparison', 'highlight'
      duration_seconds = 10,
      priority = "normal", // 'low', 'normal', 'high', 'critical'
    } = body;

    if (!action) {
      return Response.json({ error: "action required" }, { status: 400 });
    }

    if (action === "push" && !athlete_id) {
      return Response.json(
        { error: "athlete_id required for push action" },
        { status: 400 },
      );
    }

    // Get athlete data if pushing content
    let broadcastContent = null;
    if (action === "push") {
      const [athlete] = await sql`
        SELECT id, first_name, last_name, sport, position, team, nil_tier
        FROM athletes
        WHERE id = ${athlete_id}
      `;

      if (!athlete) {
        return Response.json({ error: "Athlete not found" }, { status: 404 });
      }

      // Get latest universal frame
      const universalFrameResponse = await fetch(
        `${process.env.NEXT_PUBLIC_CREATE_APP_URL || ""}/api/ar/universal-frame`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ athlete_id, time_window_minutes: 5 }),
        },
      );

      const { universal_frame } = await universalFrameResponse.json();

      broadcastContent = {
        broadcast_id: `bc_${Date.now()}_${athlete_id}`,
        action,
        athlete: {
          id: athlete.id,
          name: `${athlete.first_name} ${athlete.last_name}`,
          sport: athlete.sport,
          position: athlete.position,
          team: athlete.team,
          nil_tier: athlete.nil_tier,
        },
        display_type,
        content_type,
        duration_seconds,
        priority,
        universal_frame,
        pushed_at: new Date().toISOString(),
        expires_at: new Date(
          Date.now() + duration_seconds * 1000,
        ).toISOString(),
      };
    }

    return Response.json({
      success: true,
      action,
      broadcast_content: broadcastContent,
      message:
        action === "push"
          ? `Content pushed to ${display_type}`
          : action === "clear"
            ? "Display cleared"
            : "Display updated",
    });
  } catch (error) {
    console.error("Broadcast control error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const display_type = searchParams.get("display_type");

    // Return current broadcast state
    // In production, this would query a real-time state store (Redis/DynamoDB)

    return Response.json({
      success: true,
      displays: {
        jumbotron: {
          active: false,
          content: null,
          last_updated: null,
        },
        lower_third: {
          active: false,
          content: null,
          last_updated: null,
        },
        sideline: {
          active: false,
          content: null,
          last_updated: null,
        },
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Broadcast control GET error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
