/**
 * XR Universal Frame Stream API
 * Real-time streaming endpoint for VR/AR athlete visualization
 * Provides SSI/CIS/ARC data streams + athlete positions
 */

import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sessionId = searchParams.get("session_id");
  const athleteIds = searchParams.get("athlete_ids")?.split(",") || [];
  const updateHz = parseInt(searchParams.get("hz") || "30");

  if (!sessionId) {
    return Response.json({ error: "session_id required" }, { status: 400 });
  }

  // Create SSE stream
  const encoder = new TextEncoder();
  let frameCount = 0;
  const streamInterval = 1000 / updateHz;

  const stream = new ReadableStream({
    async start(controller) {
      const sendFrame = async () => {
        try {
          // Fetch latest biometric data for all athletes in session
          const athleteData = await Promise.all(
            athleteIds.map(async (athleteId) => {
              // Get latest biometric readings
              const readings = await sql`
                SELECT 
                  br.index_code,
                  br.score,
                  br.baseline,
                  br.trend,
                  br.recorded_at,
                  bid.index_name,
                  bid.domain,
                  bid.cluster
                FROM biometric_readings br
                JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
                WHERE br.athlete_id = ${athleteId}
                  AND br.recorded_at >= NOW() - INTERVAL '5 minutes'
                ORDER BY br.recorded_at DESC
                LIMIT 50
              `;

              // Get athlete info
              const [athlete] = await sql`
                SELECT id, first_name, last_name, sport, position, team, nil_tier
                FROM athletes
                WHERE id = ${athleteId}
              `;

              // Compute SSI/CIS/ARC scores
              const metrics = computeMetrics(readings);

              return {
                athlete_id: athleteId,
                name: athlete
                  ? `${athlete.first_name} ${athlete.last_name}`
                  : "Unknown",
                sport: athlete?.sport,
                position: athlete?.position,
                team: athlete?.team,
                nil_tier: athlete?.nil_tier,
                metrics,
                position_3d: generateMockPosition(athleteId, frameCount), // Mock spatial data
                timestamp: new Date().toISOString(),
              };
            }),
          );

          const frame = {
            type: "xr_frame",
            session_id: sessionId,
            frame_number: frameCount++,
            timestamp: new Date().toISOString(),
            update_hz: updateHz,
            athletes: athleteData,
          };

          const data = `data: ${JSON.stringify(frame)}\n\n`;
          controller.enqueue(encoder.encode(data));
        } catch (error) {
          console.error("XR Stream error:", error);
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                type: "error",
                error: error.message,
              })}\n\n`,
            ),
          );
        }
      };

      // Send initial connection frame
      controller.enqueue(
        encoder.encode(
          `data: ${JSON.stringify({
            type: "connection",
            session_id: sessionId,
            connected_at: new Date().toISOString(),
            update_hz: updateHz,
            athlete_count: athleteIds.length,
          })}\n\n`,
        ),
      );

      // Start streaming
      const intervalId = setInterval(sendFrame, streamInterval);

      // Cleanup after 5 minutes or on abort
      const timeout = setTimeout(
        () => {
          clearInterval(intervalId);
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                type: "stream_end",
                total_frames: frameCount,
                closed_at: new Date().toISOString(),
              })}\n\n`,
            ),
          );
          controller.close();
        },
        5 * 60 * 1000,
      );

      // Handle client disconnect
      request.signal.addEventListener("abort", () => {
        clearInterval(intervalId);
        clearTimeout(timeout);
        controller.close();
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}

function computeMetrics(readings) {
  // Compute SSI (Structural Stability Index)
  const structuralIndices = readings.filter(
    (r) =>
      r.domain === "Biomechanical" ||
      r.cluster.includes("Joint") ||
      r.cluster.includes("Muscle"),
  );
  const ssi =
    structuralIndices.length > 0
      ? structuralIndices.reduce((sum, r) => sum + (r.score || 50), 0) /
        structuralIndices.length
      : 75;

  // Compute CIS (Cognitive Intelligence Score)
  const cognitiveIndices = readings.filter(
    (r) => r.domain === "Cognitive & Emotional",
  );
  const cis =
    cognitiveIndices.length > 0
      ? cognitiveIndices.reduce((sum, r) => sum + (r.score || 50), 0) /
        cognitiveIndices.length
      : 72;

  // Compute ARC (Adaptive Recovery Capacity)
  const recoveryIndices = readings.filter(
    (r) => r.cluster.includes("Recovery") || r.cluster.includes("Fatigue"),
  );
  const arc =
    recoveryIndices.length > 0
      ? recoveryIndices.reduce((sum, r) => sum + (r.score || 50), 0) /
        recoveryIndices.length
      : 68;

  // Compute detailed metrics
  const stress = readings.find((r) => r.index_code === "SRi")?.score || 0.5;
  const fatigue = readings.find((r) => r.index_code === "FAi")?.score || 0.3;
  const recovery = readings.find((r) => r.index_code === "RRi")?.score || 0.7;

  return {
    ssi: Math.round(ssi),
    cis: Math.round(cis),
    arc: Math.round(arc),
    stress: parseFloat(stress.toFixed(2)),
    fatigue: parseFloat(fatigue.toFixed(2)),
    recovery: parseFloat(recovery.toFixed(2)),
    readings_count: readings.length,
  };
}

function generateMockPosition(athleteId, frameCount) {
  // Generate mock 3D position data for VR visualization
  // In production, this would come from motion capture or GPS tracking
  const hash = athleteId
    .split("")
    .reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const time = frameCount * 0.1;

  return {
    x: Math.sin(time + hash) * 10,
    y: 1.8, // average athlete height
    z: Math.cos(time + hash) * 10,
    rotation: {
      x: 0,
      y: (time + hash) % (Math.PI * 2),
      z: 0,
    },
    velocity: {
      x: Math.cos(time + hash) * 2,
      y: 0,
      z: -Math.sin(time + hash) * 2,
    },
  };
}
