/**
 * Multi-Athlete Spatial Intelligence API
 * Provides comparative spatial analytics for VR visualization
 */

import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_ids = [],
      session_id,
      analysis_type = "comparative", // 'comparative', 'tactical', 'formation'
      sport,
      time_window_minutes = 5,
    } = body;

    if (!athlete_ids.length) {
      return Response.json(
        { error: "athlete_ids array required" },
        { status: 400 },
      );
    }

    // Fetch all athletes
    const athletes = await sql`
      SELECT id, first_name, last_name, sport, position, team, nil_tier
      FROM athletes
      WHERE id = ANY(${athlete_ids})
    `;

    // Fetch biometric data for all athletes
    const athleteAnalytics = await Promise.all(
      athletes.map(async (athlete) => {
        const readings = await sql`
          SELECT 
            br.index_code,
            br.score,
            br.baseline,
            br.trend,
            br.recorded_at,
            bid.index_name,
            bid.domain,
            bid.cluster
          FROM biometric_readings br
          JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
          WHERE br.athlete_id = ${athlete.id}
            AND br.recorded_at >= NOW() - INTERVAL '${time_window_minutes} minutes'
          ORDER BY br.recorded_at DESC
        `;

        // Compute metrics
        const ssi = computeIndexScore(readings, "Biomechanical");
        const cis = computeIndexScore(readings, "Cognitive & Emotional");
        const arc = computeRecoveryScore(readings);

        return {
          athlete: {
            id: athlete.id,
            name: `${athlete.first_name} ${athlete.last_name}`,
            sport: athlete.sport,
            position: athlete.position,
            team: athlete.team,
            nil_tier: athlete.nil_tier,
          },
          metrics: {
            ssi,
            cis,
            arc,
            readings_count: readings.length,
          },
          spatial_position: generateSpatialPosition(
            athlete.id,
            athlete.position,
          ),
          performance_trend: calculateTrend(readings),
          readiness_score: (ssi * 0.4 + cis * 0.3 + arc * 0.3).toFixed(1),
        };
      }),
    );

    // Compute comparative insights
    const comparativeInsights = {
      average_ssi: average(athleteAnalytics.map((a) => a.metrics.ssi)),
      average_cis: average(athleteAnalytics.map((a) => a.metrics.cis)),
      average_arc: average(athleteAnalytics.map((a) => a.metrics.arc)),
      top_performer: athleteAnalytics.reduce((max, a) =>
        parseFloat(a.readiness_score) > parseFloat(max.readiness_score)
          ? a
          : max,
      ),
      fatigue_alert_count: athleteAnalytics.filter((a) => a.metrics.arc < 50)
        .length,
    };

    // Generate tactical formation (sport-specific)
    const formation = generateFormation(athleteAnalytics, sport);

    return Response.json({
      success: true,
      session_id,
      analysis_type,
      sport,
      athlete_count: athletes.length,
      athletes: athleteAnalytics,
      comparative_insights: comparativeInsights,
      formation,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Multi-athlete spatial error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function computeIndexScore(readings, domain) {
  const filtered = readings.filter((r) => r.domain === domain);
  if (!filtered.length) return 75;
  return Math.round(
    filtered.reduce((sum, r) => sum + (r.score || 50), 0) / filtered.length,
  );
}

function computeRecoveryScore(readings) {
  const recovery = readings.filter(
    (r) => r.cluster?.includes("Recovery") || r.cluster?.includes("Fatigue"),
  );
  if (!recovery.length) return 68;
  return Math.round(
    recovery.reduce((sum, r) => sum + (r.score || 50), 0) / recovery.length,
  );
}

function calculateTrend(readings) {
  if (readings.length < 2) return "stable";
  const recent = readings.slice(0, Math.floor(readings.length / 2));
  const older = readings.slice(Math.floor(readings.length / 2));
  const recentAvg =
    recent.reduce((sum, r) => sum + (r.score || 50), 0) / recent.length;
  const olderAvg =
    older.reduce((sum, r) => sum + (r.score || 50), 0) / older.length;
  const change = ((recentAvg - olderAvg) / olderAvg) * 100;
  return change > 5 ? "improving" : change < -5 ? "declining" : "stable";
}

function average(arr) {
  return arr.length
    ? (arr.reduce((sum, v) => sum + v, 0) / arr.length).toFixed(1)
    : 0;
}

function generateSpatialPosition(athleteId, position) {
  // Mock spatial positioning for VR visualization
  // In production, use real motion capture/GPS data
  const hash = athleteId
    .split("")
    .reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const positionMap = {
    QB: { x: 0, z: -5 },
    RB: { x: -2, z: -7 },
    WR: { x: -10, z: 0 },
    TE: { x: 5, z: -2 },
    default: { x: (hash % 20) - 10, z: (hash % 20) - 10 },
  };

  const base = positionMap[position] || positionMap.default;

  return {
    x: base.x,
    y: 0,
    z: base.z,
    rotation: { x: 0, y: 0, z: 0 },
  };
}

function generateFormation(athletes, sport) {
  // Generate tactical formation based on sport
  if (sport === "American Football") {
    return {
      formation_type: "I-Formation",
      positions: athletes.map((a) => ({
        athlete_id: a.athlete.id,
        name: a.athlete.name,
        position: a.athlete.position,
        coordinates: a.spatial_position,
      })),
    };
  }

  // Default formation
  return {
    formation_type: "Standard",
    positions: athletes.map((a) => ({
      athlete_id: a.athlete.id,
      name: a.athlete.name,
      coordinates: a.spatial_position,
    })),
  };
}
