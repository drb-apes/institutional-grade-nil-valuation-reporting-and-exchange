import sql from "@/app/api/utils/sql";
import crypto from "crypto";

/**
 * POST /api/certificates/issue
 * Issues a biometric index certificate for an athlete
 * Generates blockchain hash and coalition metadata
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      certificate_type = "Tier I: Elite Recovery",
      coalition_partner,
      utility_mapping = {},
    } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Verify athlete exists and has consent
    const athleteRows = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteRows.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 404 },
      );
    }

    const athlete = athleteRows[0];

    if (!athlete.consent_biometric || !athlete.consent_nil) {
      return Response.json(
        {
          success: false,
          error: "Athlete consent required for certificate issuance",
        },
        { status: 403 },
      );
    }

    // Generate serial number and blockchain hash
    const serial_number = `BLEDSOE-${Date.now()}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
    const blockchain_hash = crypto
      .createHash("sha256")
      .update(`${athlete_id}${serial_number}${certificate_type}${Date.now()}`)
      .digest("hex");

    // Insert certificate
    const certificateRows = await sql`
      INSERT INTO coalition_certificates (
        athlete_id,
        certificate_type,
        serial_number,
        blockchain_hash,
        coalition_partner,
        utility_mapping,
        issued_at,
        status
      ) VALUES (
        ${athlete_id},
        ${certificate_type},
        ${serial_number},
        ${blockchain_hash},
        ${coalition_partner || null},
        ${JSON.stringify(utility_mapping)},
        NOW(),
        'active'
      )
      RETURNING *
    `;

    const certificate = certificateRows[0];

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'coalition_certificate',
        ${certificate.id},
        'issue',
        'BIM-APES System',
        ${JSON.stringify({
          athlete_id,
          certificate_type,
          serial_number,
          coalition_partner,
        })}
      )
    `;

    return Response.json({
      success: true,
      certificate,
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        sport: athlete.sport,
        nil_tier: athlete.nil_tier,
      },
      blockchain_verification_url: `https://blockchain.bim-apes.com/verify/${blockchain_hash}`,
    });
  } catch (error) {
    console.error("Certificate issuance error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/certificates/issue?athlete_id=...
 * List certificates for an athlete
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");
    const status = searchParams.get("status") || "active";

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    const certificates = await sql`
      SELECT 
        c.*,
        a.first_name,
        a.last_name,
        a.sport,
        a.nil_tier
      FROM coalition_certificates c
      JOIN athletes a ON c.athlete_id = a.id
      WHERE c.athlete_id = ${athlete_id}
        AND c.status = ${status}
      ORDER BY c.issued_at DESC
    `;

    return Response.json({
      success: true,
      count: certificates.length,
      certificates,
    });
  } catch (error) {
    console.error("Certificate list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
