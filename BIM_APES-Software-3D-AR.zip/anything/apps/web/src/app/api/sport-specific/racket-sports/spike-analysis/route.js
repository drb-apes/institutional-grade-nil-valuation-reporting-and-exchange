function calculateShotQuality(sessions) {
  return {
    score: 82 + Math.random() * 15,
    accuracy: 0.78 + Math.random() * 0.18,
    power: 75 + Math.random() * 20,
    placement: 0.8 + Math.random() * 0.15,
    variety: {
      forehand: 0.42,
      backhand: 0.38,
      serve: 0.15,
      volley: 0.05,
    },
    unforcedErrors: Math.floor(8 + Math.random() * 12),
  };
}
