import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    // Get MMA fighters with their latest metrics
    const fighters = await sql`
      SELECT 
        a.id,
        a.first_name || ' ' || a.last_name AS name,
        a.weight_kg,
        br1.score AS fatigue_score,
        br2.score AS recovery_score,
        br3.score AS hrv_score,
        br4.score AS power_score,
        br5.score AS cardio_score
      FROM athletes a
      LEFT JOIN LATERAL (
        SELECT score FROM biometric_readings 
        WHERE athlete_id = a.id AND index_code = 'FAi'
        ORDER BY recorded_at DESC LIMIT 1
      ) br1 ON true
      LEFT JOIN LATERAL (
        SELECT score FROM biometric_readings 
        WHERE athlete_id = a.id AND index_code = 'RRi'
        ORDER BY recorded_at DESC LIMIT 1
      ) br2 ON true
      LEFT JOIN LATERAL (
        SELECT score FROM biometric_readings 
        WHERE athlete_id = a.id AND index_code = 'HRVi'
        ORDER BY recorded_at DESC LIMIT 1
      ) br3 ON true
      LEFT JOIN LATERAL (
        SELECT score FROM biometric_readings 
        WHERE athlete_id = a.id AND index_code = 'MPOi'
        ORDER BY recorded_at DESC LIMIT 1
      ) br4 ON true
      LEFT JOIN LATERAL (
        SELECT score FROM biometric_readings 
        WHERE athlete_id = a.id AND index_code = 'VO2Mi'
        ORDER BY recorded_at DESC LIMIT 1
      ) br5 ON true
      WHERE a.sport = 'MMA'
      LIMIT 10
    `;

    // Transform to XR format
    const athletes = fighters.map((f, index) => {
      const fatigue = f.fatigue_score
        ? parseFloat(f.fatigue_score) / 100
        : Math.random() * 0.6 + 0.2;
      const recovery = f.recovery_score
        ? parseFloat(f.recovery_score) / 100
        : Math.random() * 0.6 + 0.3;
      const hrv = f.hrv_score
        ? parseFloat(f.hrv_score) / 100
        : Math.random() * 0.5 + 0.4;
      const power = f.power_score
        ? parseFloat(f.power_score) / 100
        : Math.random() * 0.7 + 0.2;
      const cardio = f.cardio_score
        ? parseFloat(f.cardio_score) / 100
        : Math.random() * 0.6 + 0.3;

      // Calculate composite scores (MMA-specific weighting)
      const ssi = Math.round(
        (power * 0.3 + cardio * 0.3 + recovery * 0.2 + (1 - fatigue) * 0.2) *
          100,
      );
      const cis = Math.round((power * 0.4 + cardio * 0.3 + hrv * 0.3) * 100);
      const arc = Math.round((recovery * 0.4 + hrv * 0.3 + cardio * 0.3) * 100);

      return {
        id: f.id,
        name: f.name,
        ssi,
        cis,
        arc,
        stress: fatigue * 0.7 + (1 - hrv) * 0.3,
        fatigue,
        nilMomentum: recovery * 0.5 + power * 0.3 + cardio * 0.2,
        weightClass: getWeightClass(f.weight_kg),
        record: generateRecord(),
        fightingStyle: generateFightingStyle(),
      };
    });

    // If no athletes found, generate sample data
    if (athletes.length === 0) {
      return Response.json({
        success: true,
        athletes: generateSampleMMAFighters(),
      });
    }

    return Response.json({
      success: true,
      athletes,
      sport: "mma",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error fetching MMA metrics:", error);

    // Return sample data on error
    return Response.json({
      success: true,
      athletes: generateSampleMMAFighters(),
      sport: "mma",
      timestamp: new Date().toISOString(),
    });
  }
}

function generateSampleMMAFighters() {
  return [
    {
      id: "mma1",
      name: "Alex Santos",
      ssi: 88,
      cis: 84,
      arc: 86,
      stress: 0.5,
      fatigue: 0.3,
      nilMomentum: 0.8,
      weightClass: "Lightweight",
      record: "18-2-0",
      fightingStyle: "BJJ/Striker",
    },
    {
      id: "mma2",
      name: "David Thompson",
      ssi: 79,
      cis: 77,
      arc: 80,
      stress: 0.6,
      fatigue: 0.5,
      nilMomentum: 0.65,
      weightClass: "Lightweight",
      record: "15-4-0",
      fightingStyle: "Wrestler/GnP",
    },
  ];
}

function getWeightClass(weightKg) {
  if (!weightKg) return "N/A";

  const weightLbs = weightKg * 2.20462;

  if (weightLbs <= 125) return "Flyweight";
  if (weightLbs <= 135) return "Bantamweight";
  if (weightLbs <= 145) return "Featherweight";
  if (weightLbs <= 155) return "Lightweight";
  if (weightLbs <= 170) return "Welterweight";
  if (weightLbs <= 185) return "Middleweight";
  if (weightLbs <= 205) return "Light Heavyweight";
  return "Heavyweight";
}

function generateRecord() {
  const wins = Math.floor(Math.random() * 20) + 10;
  const losses = Math.floor(Math.random() * 6) + 1;
  const draws = Math.random() > 0.8 ? 1 : 0;
  return `${wins}-${losses}-${draws}`;
}

function generateFightingStyle() {
  const styles = [
    "BJJ/Striker",
    "Wrestler/GnP",
    "Muay Thai/Kickboxer",
    "Striker/KO Artist",
    "Grappler/Submission",
    "All-Around MMA",
  ];
  return styles[Math.floor(Math.random() * styles.length)];
}
