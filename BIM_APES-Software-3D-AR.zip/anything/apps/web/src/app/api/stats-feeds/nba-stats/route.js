import sql from "@/app/api/utils/sql";

/**
 * POST /api/stats-feeds/nba-stats
 * NBA Stats live feed integration
 * Real-time player stats, play-by-play, advanced metrics
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      game_id,
      player_id = null,
      team_id = null,
      stat_type, // 'box_score', 'advanced_metrics', 'tracking_data', 'play_by_play'
      data_payload,
      timestamp = new Date().toISOString(),
    } = body;

    if (!game_id || !stat_type || !data_payload) {
      return Response.json(
        {
          success: false,
          error: "game_id, stat_type, and data_payload are required",
        },
        { status: 400 },
      );
    }

    // Process based on stat type
    let processedData;

    switch (stat_type) {
      case "box_score":
        processedData = await processBoxScore(player_id, data_payload);
        break;
      case "advanced_metrics":
        processedData = await processAdvancedMetrics(player_id, data_payload);
        break;
      case "tracking_data":
        processedData = await processTrackingData(player_id, data_payload);
        break;
      case "play_by_play":
        processedData = await processPlayByPlay(game_id, data_payload);
        break;
      default:
        return Response.json(
          { success: false, error: "Invalid stat_type" },
          { status: 400 },
        );
    }

    // Log ingestion
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'nba_stats_feed',
        ${game_id},
        ${stat_type},
        'nba_stats_api',
        ${JSON.stringify({ player_id, team_id, data_summary: processedData.summary })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      game_id,
      player_id,
      stat_type,
      processed_data: processedData,
      timestamp,
    });
  } catch (error) {
    console.error("NBA Stats error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/stats-feeds/nba-stats
 * Get NBA stats feed history
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const game_id = searchParams.get("game_id");
    const player_id = searchParams.get("player_id");
    const limit = parseInt(searchParams.get("limit") || "100");

    let statsHistory = [];

    if (game_id) {
      statsHistory = await sql`
        SELECT * FROM audit_logs
        WHERE entity_type = 'nba_stats_feed'
          AND entity_id = ${game_id}
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    } else if (player_id) {
      statsHistory = await sql`
        SELECT * FROM audit_logs
        WHERE entity_type = 'nba_stats_feed'
          AND details->>'player_id' = ${player_id}
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    }

    return Response.json({
      success: true,
      game_id,
      player_id,
      stats_history: statsHistory,
    });
  } catch (error) {
    console.error("NBA stats fetch error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === NBA STAT PROCESSORS ===

async function processBoxScore(playerId, boxScoreData) {
  const stats = {
    // Basic Stats
    minutes_played: boxScoreData.minutes || 0,
    points: boxScoreData.points || 0,
    rebounds: boxScoreData.rebounds || 0,
    assists: boxScoreData.assists || 0,
    steals: boxScoreData.steals || 0,
    blocks: boxScoreData.blocks || 0,
    turnovers: boxScoreData.turnovers || 0,

    // Shooting
    field_goals_made: boxScoreData.fgm || 0,
    field_goals_attempted: boxScoreData.fga || 0,
    field_goal_percentage: boxScoreData.fg_pct || 0,
    three_pointers_made: boxScoreData.fg3m || 0,
    three_pointers_attempted: boxScoreData.fg3a || 0,
    three_point_percentage: boxScoreData.fg3_pct || 0,
    free_throws_made: boxScoreData.ftm || 0,
    free_throws_attempted: boxScoreData.fta || 0,
    free_throw_percentage: boxScoreData.ft_pct || 0,

    // Plus/Minus
    plus_minus: boxScoreData.plus_minus || 0,
  };

  // Calculate efficiency metrics
  const efficiency = calculatePlayerEfficiency(stats);
  const shootingProfile = analyzeShootingProfile(stats);

  return {
    box_score: stats,
    efficiency,
    shooting_profile: shootingProfile,
    summary: `${stats.points}pts ${stats.rebounds}reb ${stats.assists}ast`,
  };
}

async function processAdvancedMetrics(playerId, metricsData) {
  const advanced = {
    // Usage & Pace
    usage_rate: metricsData.usage_rate || 0,
    pace: metricsData.pace || 0,
    possessions: metricsData.possessions || 0,

    // Efficiency
    true_shooting_pct: metricsData.ts_pct || 0,
    effective_fg_pct: metricsData.efg_pct || 0,
    player_efficiency_rating: metricsData.per || 0,

    // Impact
    offensive_rating: metricsData.off_rtg || 0,
    defensive_rating: metricsData.def_rtg || 0,
    net_rating: metricsData.net_rtg || 0,

    // Advanced
    assist_percentage: metricsData.ast_pct || 0,
    rebound_percentage: metricsData.reb_pct || 0,
    turnover_percentage: metricsData.tov_pct || 0,
    steal_percentage: metricsData.stl_pct || 0,
    block_percentage: metricsData.blk_pct || 0,

    // Win Shares
    offensive_win_shares: metricsData.ows || 0,
    defensive_win_shares: metricsData.dws || 0,
    win_shares: metricsData.ws || 0,
    win_shares_per_48: metricsData.ws_48 || 0,
  };

  // Store as biometric indices
  if (playerId) {
    await storeNBABiometrics(playerId, {
      usage_rate: advanced.usage_rate,
      efficiency: advanced.player_efficiency_rating,
      offensive_impact: advanced.offensive_rating,
      defensive_impact: advanced.defensive_rating,
    });
  }

  return {
    advanced_metrics: advanced,
    impact_score: calculateImpactScore(advanced),
    summary: `${advanced.player_efficiency_rating.toFixed(1)} PER, ${advanced.net_rating > 0 ? "+" : ""}${advanced.net_rating.toFixed(1)} Net Rating`,
  };
}

async function processTrackingData(playerId, trackingData) {
  const tracking = {
    // Speed & Distance
    distance_miles: trackingData.distance_miles || 0,
    average_speed_mph: trackingData.avg_speed_mph || 0,
    max_speed_mph: trackingData.max_speed_mph || 0,

    // Defensive Metrics
    contests: trackingData.contests || 0,
    deflections: trackingData.deflections || 0,
    charges_drawn: trackingData.charges_drawn || 0,

    // Offensive Metrics
    touches: trackingData.touches || 0,
    time_of_possession_seconds: trackingData.time_of_possession || 0,
    drives: trackingData.drives || 0,
    paint_touches: trackingData.paint_touches || 0,

    // Catch & Shoot
    catch_and_shoot_attempts: trackingData.catch_shoot_att || 0,
    catch_and_shoot_made: trackingData.catch_shoot_made || 0,
    catch_and_shoot_pct: trackingData.catch_shoot_pct || 0,

    // Pull-up Shots
    pull_up_attempts: trackingData.pull_up_att || 0,
    pull_up_made: trackingData.pull_up_made || 0,
    pull_up_pct: trackingData.pull_up_pct || 0,
  };

  // Convert to biometric indices
  const biometricIndices = {
    movement_efficiency: calculateMovementEfficiency(tracking),
    defensive_intensity: calculateDefensiveIntensity(tracking),
    offensive_aggression: calculateOffensiveAggression(tracking),
  };

  if (playerId) {
    await storeNBABiometrics(playerId, biometricIndices);
  }

  return {
    tracking_data: tracking,
    biometric_indices: biometricIndices,
    summary: `${tracking.distance_miles.toFixed(1)} miles, ${tracking.average_speed_mph.toFixed(1)} mph avg`,
  };
}

async function processPlayByPlay(gameId, playData) {
  const play = {
    event_id: playData.eventId,
    period: playData.period,
    clock: playData.clock,
    event_type: playData.eventType, // 'shot', 'turnover', 'foul', 'rebound', 'substitution'
    player_id: playData.playerId,
    team_id: playData.teamId,
    result: playData.result,
    shot_type: playData.shotType,
    shot_distance: playData.shotDistance,
    defender_distance: playData.defenderDistance,
  };

  // Analyze play context
  const playContext = analyzePlayContext(play);

  return {
    play_details: play,
    context: playContext,
    summary: `${play.event_type} - ${play.result}`,
  };
}

// === CALCULATION FUNCTIONS ===

function calculatePlayerEfficiency(stats) {
  // NBA Player Efficiency Rating (simplified)
  const per =
    (stats.points +
      stats.rebounds +
      stats.assists +
      stats.steals +
      stats.blocks -
      (stats.field_goals_attempted - stats.field_goals_made) -
      (stats.free_throws_attempted - stats.free_throws_made) -
      stats.turnovers) /
    (stats.minutes_played || 1);

  return {
    player_efficiency_rating: per,
    points_per_minute: stats.points / (stats.minutes_played || 1),
    usage_rate_estimate:
      (stats.field_goals_attempted +
        0.44 * stats.free_throws_attempted +
        stats.turnovers) /
      (stats.minutes_played || 1),
  };
}

function analyzeShootingProfile(stats) {
  return {
    scoring_efficiency: calculateTrueShootingPercentage(stats),
    shot_selection: {
      two_point_rate:
        (stats.field_goals_attempted - stats.three_pointers_attempted) /
        (stats.field_goals_attempted || 1),
      three_point_rate:
        stats.three_pointers_attempted / (stats.field_goals_attempted || 1),
      free_throw_rate:
        stats.free_throws_attempted / (stats.field_goals_attempted || 1),
    },
    hot_zones: identifyHotZones(stats),
  };
}

function calculateTrueShootingPercentage(stats) {
  const tsa = stats.field_goals_attempted + 0.44 * stats.free_throws_attempted;
  if (tsa === 0) return 0;
  return stats.points / (2 * tsa);
}

function identifyHotZones(stats) {
  // Simplified hot zone identification
  return {
    paint: stats.field_goal_percentage > 0.55 ? "hot" : "cold",
    mid_range: stats.field_goal_percentage > 0.45 ? "warm" : "cold",
    three_point: stats.three_point_percentage > 0.38 ? "hot" : "cold",
    free_throw: stats.free_throw_percentage > 0.8 ? "hot" : "warm",
  };
}

function calculateImpactScore(advanced) {
  // Composite impact score
  const offensiveImpact = advanced.offensive_rating / 110; // Normalize to league average
  const defensiveImpact = 110 / (advanced.defensive_rating || 110); // Lower is better
  const usageWeight = Math.min(1, advanced.usage_rate / 30);

  return (
    (offensiveImpact * 0.4 + defensiveImpact * 0.4 + usageWeight * 0.2) * 100
  );
}

function calculateMovementEfficiency(tracking) {
  const distancePerTouch = tracking.distance_miles / (tracking.touches || 1);
  const speedConsistency =
    tracking.average_speed_mph / (tracking.max_speed_mph || 1);

  return (1 - distancePerTouch) * 0.5 + speedConsistency * 0.5;
}

function calculateDefensiveIntensity(tracking) {
  const contestRate = tracking.contests / (tracking.distance_miles || 1);
  const deflectionRate = tracking.deflections / (tracking.distance_miles || 1);

  return (contestRate * 0.6 + deflectionRate * 0.4) * 100;
}

function calculateOffensiveAggression(tracking) {
  const driveRate = tracking.drives / (tracking.touches || 1);
  const paintRate = tracking.paint_touches / (tracking.touches || 1);

  return driveRate * 0.5 + paintRate * 0.5;
}

function analyzePlayContext(play) {
  return {
    shot_quality:
      play.defender_distance > 4
        ? "open"
        : play.defender_distance > 2
          ? "contested"
          : "heavily_contested",
    shot_location:
      play.shot_distance < 5
        ? "paint"
        : play.shot_distance < 16
          ? "mid_range"
          : "three_point",
    game_situation: determineSituation(play),
  };
}

function determineSituation(play) {
  if (play.period >= 4 && play.clock < 300) return "clutch";
  if (play.period === 1) return "opening";
  return "regular";
}

async function storeNBABiometrics(playerId, biometricData) {
  for (const [key, value] of Object.entries(biometricData)) {
    const indexCode = mapNBAMetricToIndex(key);
    if (indexCode && value !== null && value !== undefined) {
      await sql`
        INSERT INTO biometric_readings (
          athlete_id,
          index_code,
          score,
          context,
          recorded_at
        ) VALUES (
          ${playerId},
          ${indexCode},
          ${typeof value === "number" ? value : 0},
          'nba_stats',
          NOW()
        )
      `;
    }
  }
}

function mapNBAMetricToIndex(metricKey) {
  const mapping = {
    usage_rate: "URi",
    efficiency: "PERi",
    offensive_impact: "ORi",
    defensive_impact: "DRi",
    movement_efficiency: "MEi",
    defensive_intensity: "DIi",
    offensive_aggression: "OAi",
  };
  return mapping[metricKey] || null;
}
