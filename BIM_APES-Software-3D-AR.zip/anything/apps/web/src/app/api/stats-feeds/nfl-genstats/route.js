import sql from "@/app/api/utils/sql";

/**
 * POST /api/stats-feeds/nfl-genstats
 * NFL GenStats live feed integration
 * Real-time player stats, play-by-play, and injury reports
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      game_id,
      player_id = null,
      team_id = null,
      stat_type, // 'play_by_play', 'player_stats', 'injury_report', 'live_tracking'
      data_payload,
      timestamp = new Date().toISOString(),
    } = body;

    if (!game_id || !stat_type || !data_payload) {
      return Response.json(
        {
          success: false,
          error: "game_id, stat_type, and data_payload are required",
        },
        { status: 400 },
      );
    }

    // Process based on stat type
    let processedData;
    let athleteId = null;

    switch (stat_type) {
      case "play_by_play":
        processedData = await processPlayByPlay(game_id, data_payload);
        break;
      case "player_stats":
        processedData = await processPlayerStats(player_id, data_payload);
        athleteId = player_id;
        break;
      case "injury_report":
        processedData = await processInjuryReport(player_id, data_payload);
        athleteId = player_id;
        break;
      case "live_tracking":
        processedData = await processLiveTracking(player_id, data_payload);
        athleteId = player_id;
        break;
      default:
        return Response.json(
          { success: false, error: "Invalid stat_type" },
          { status: 400 },
        );
    }

    // Log ingestion
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'nfl_stats_feed',
        ${game_id},
        ${stat_type},
        'nfl_genstats',
        ${JSON.stringify({ player_id, team_id, data_summary: processedData.summary })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      game_id,
      player_id,
      stat_type,
      processed_data: processedData,
      timestamp,
    });
  } catch (error) {
    console.error("NFL GenStats error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/stats-feeds/nfl-genstats
 * Get NFL stats feed history
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const game_id = searchParams.get("game_id");
    const player_id = searchParams.get("player_id");
    const limit = parseInt(searchParams.get("limit") || "100");

    let statsHistory = [];

    if (game_id) {
      statsHistory = await sql`
        SELECT * FROM audit_logs
        WHERE entity_type = 'nfl_stats_feed'
          AND entity_id = ${game_id}
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    } else if (player_id) {
      statsHistory = await sql`
        SELECT * FROM audit_logs
        WHERE entity_type = 'nfl_stats_feed'
          AND details->>'player_id' = ${player_id}
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    }

    return Response.json({
      success: true,
      game_id,
      player_id,
      stats_history: statsHistory,
    });
  } catch (error) {
    console.error("NFL stats fetch error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === NFL STAT PROCESSORS ===

async function processPlayByPlay(gameId, playData) {
  // Play-by-play processor
  const play = {
    play_id: playData.playId,
    quarter: playData.quarter,
    time_remaining: playData.timeRemaining,
    down: playData.down,
    distance: playData.distance,
    yard_line: playData.yardLine,
    play_type: playData.playType, // 'pass', 'rush', 'punt', 'kick', 'turnover'
    result: playData.result,
    yards_gained: playData.yardsGained,
    players_involved: playData.players || [],
  };

  // Extract player performance from play
  const playerMetrics = [];

  for (const player of play.players_involved) {
    if (player.athleteId) {
      const metrics = extractPlayerMetricsFromPlay(player, play);
      playerMetrics.push(metrics);

      // Store as biometric readings if applicable
      if (metrics.biometric_impact) {
        await storeNFLBiometrics(
          player.athleteId,
          metrics.biometric_impact,
          gameId,
        );
      }
    }
  }

  return {
    play_summary: play,
    player_metrics: playerMetrics,
    summary: `${play.play_type} - ${play.yards_gained} yards`,
  };
}

async function processPlayerStats(playerId, statsData) {
  const stats = {
    // Passing
    completions: statsData.completions || 0,
    attempts: statsData.attempts || 0,
    passing_yards: statsData.passingYards || 0,
    touchdowns: statsData.touchdowns || 0,
    interceptions: statsData.interceptions || 0,
    passer_rating: statsData.passerRating || 0,

    // Rushing
    carries: statsData.carries || 0,
    rushing_yards: statsData.rushingYards || 0,
    rushing_touchdowns: statsData.rushingTouchdowns || 0,
    yards_per_carry: statsData.yardsPerCarry || 0,

    // Receiving
    receptions: statsData.receptions || 0,
    receiving_yards: statsData.receivingYards || 0,
    receiving_touchdowns: statsData.receivingTouchdowns || 0,
    targets: statsData.targets || 0,

    // Defense
    tackles: statsData.tackles || 0,
    sacks: statsData.sacks || 0,
    interceptions_def: statsData.interceptionsDefense || 0,
    forced_fumbles: statsData.forcedFumbles || 0,
  };

  // Calculate consistency score
  const consistencyScore = calculateNFLConsistency(
    stats,
    statsData.previousGames || [],
  );

  return {
    stats,
    consistency_score: consistencyScore,
    performance_trend: calculatePerformanceTrend(statsData.previousGames || []),
    summary: `${stats.passing_yards + stats.rushing_yards + stats.receiving_yards} total yards`,
  };
}

async function processInjuryReport(playerId, injuryData) {
  const injury = {
    injury_status: injuryData.status, // 'OUT', 'DOUBTFUL', 'QUESTIONABLE', 'PROBABLE', 'HEALTHY'
    injury_type: injuryData.injuryType,
    body_part: injuryData.bodyPart,
    severity: injuryData.severity || "unknown",
    expected_return_date: injuryData.expectedReturn,
    game_status: injuryData.gameStatus, // 'active', 'inactive', 'IR'
  };

  // Map to biometric risk indices
  const riskScore = mapInjuryToRiskScore(injury);

  if (playerId) {
    await sql`
      INSERT INTO biometric_readings (
        athlete_id,
        index_code,
        score,
        context,
        recorded_at
      ) VALUES (
        ${playerId},
        'IRi',
        ${riskScore},
        'nfl_injury_report',
        NOW()
      )
    `;
  }

  return {
    injury_details: injury,
    risk_score: riskScore,
    summary: `${injury.injury_status} - ${injury.body_part}`,
  };
}

async function processLiveTracking(playerId, trackingData) {
  // Next Gen Stats live tracking data
  const tracking = {
    speed_mph: trackingData.speedMph || 0,
    acceleration: trackingData.acceleration || 0,
    distance_traveled: trackingData.distanceTraveled || 0,
    max_speed_play: trackingData.maxSpeed || 0,
    separation_yards: trackingData.separationYards || 0,
    route_efficiency: trackingData.routeEfficiency || 0,
    burst_events: trackingData.burstEvents || 0,
  };

  // Convert to biometric indices
  const biometricIndices = {
    sprint_speed_index: Math.min(100, (tracking.speed_mph / 22) * 100),
    acceleration_index: Math.min(100, (tracking.acceleration / 4) * 100),
    movement_efficiency: tracking.route_efficiency * 100,
    explosive_bursts: tracking.burst_events,
  };

  if (playerId) {
    await storeNFLBiometrics(playerId, biometricIndices, trackingData.gameId);
  }

  return {
    tracking_data: tracking,
    biometric_indices: biometricIndices,
    summary: `${tracking.speed_mph.toFixed(1)} mph max speed`,
  };
}

// === HELPER FUNCTIONS ===

function extractPlayerMetricsFromPlay(player, play) {
  const metrics = {
    player_id: player.athleteId,
    role: player.role, // 'passer', 'rusher', 'receiver', 'tackler'
    contribution: player.contribution || "neutral",
    biometric_impact: null,
  };

  // Estimate biometric impact based on play
  if (player.role === "rusher" || player.role === "receiver") {
    metrics.biometric_impact = {
      explosive_effort: play.yards_gained > 10 ? 0.8 : 0.5,
      contact_intensity: play.result.includes("tackle") ? 0.7 : 0.3,
    };
  }

  return metrics;
}

async function storeNFLBiometrics(playerId, biometricData, gameId) {
  for (const [key, value] of Object.entries(biometricData)) {
    const indexCode = mapNFLMetricToIndex(key);
    if (indexCode) {
      await sql`
        INSERT INTO biometric_readings (
          athlete_id,
          index_code,
          score,
          context,
          recorded_at
        ) VALUES (
          ${playerId},
          ${indexCode},
          ${value},
          'nfl_genstats',
          NOW()
        )
      `;
    }
  }
}

function mapNFLMetricToIndex(metricKey) {
  const mapping = {
    explosive_effort: "EEi",
    contact_intensity: "CIi",
    sprint_speed_index: "SSi",
    acceleration_index: "ACi",
    movement_efficiency: "MEi",
  };
  return mapping[metricKey] || null;
}

function calculateNFLConsistency(currentStats, previousGames) {
  if (previousGames.length === 0) return 0.75;

  const totalYards =
    currentStats.passing_yards +
    currentStats.rushing_yards +
    currentStats.receiving_yards;
  const previousYards = previousGames.map((g) => g.totalYards || 0);

  const avgYards =
    previousYards.reduce((sum, y) => sum + y, 0) / previousYards.length;
  const variance =
    previousYards.reduce((sum, y) => sum + Math.pow(y - avgYards, 2), 0) /
    previousYards.length;
  const stdDev = Math.sqrt(variance);

  // Lower std dev = higher consistency
  const consistencyScore = Math.max(0, 1 - stdDev / avgYards);
  return consistencyScore;
}

function calculatePerformanceTrend(previousGames) {
  if (previousGames.length < 3) return "neutral";

  const recent = previousGames.slice(0, 3);
  const older = previousGames.slice(3, 6);

  const recentAvg =
    recent.reduce((sum, g) => sum + (g.totalYards || 0), 0) / recent.length;
  const olderAvg =
    older.length > 0
      ? older.reduce((sum, g) => sum + (g.totalYards || 0), 0) / older.length
      : recentAvg;

  const trendPercent = ((recentAvg - olderAvg) / olderAvg) * 100;

  if (trendPercent > 10) return "improving";
  if (trendPercent < -10) return "declining";
  return "stable";
}

function mapInjuryToRiskScore(injury) {
  const statusScores = {
    OUT: 100,
    DOUBTFUL: 80,
    QUESTIONABLE: 50,
    PROBABLE: 20,
    HEALTHY: 0,
  };

  const severityMultiplier = {
    severe: 1.2,
    moderate: 1.0,
    mild: 0.8,
    unknown: 1.0,
  };

  const baseScore = statusScores[injury.injury_status] || 50;
  const multiplier = severityMultiplier[injury.severity] || 1.0;

  return Math.min(100, baseScore * multiplier);
}
