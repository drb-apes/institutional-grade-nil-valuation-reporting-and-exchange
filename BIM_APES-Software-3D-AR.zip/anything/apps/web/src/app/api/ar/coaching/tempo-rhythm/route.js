import sql from "@/app/api/utils/sql";

/**
 * POST /api/ar/coaching/tempo-rhythm
 * Method 20: Tempo & Rhythm Analysis Engine
 * Real-time cadence, rhythm, and movement tempo analysis for performance optimization
 */
export async function POST(request) {
  try {
    const { athlete_id, session_id, sport_context } = await request.json();

    if (!athlete_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id is required",
        },
        { status: 400 },
      );
    }

    // Get athlete
    const athletes = await sql`
      SELECT id, first_name, last_name, sport, position
      FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json(
        {
          success: false,
          error: "Athlete not found",
        },
        { status: 404 },
      );
    }

    const athlete = athletes[0];

    // Get real-time biometric data (last 5 minutes for rhythm analysis)
    const recentReadings = await sql`
      SELECT index_code, score, baseline, trend, recorded_at
      FROM biometric_readings
      WHERE athlete_id = ${athlete_id}
        AND recorded_at > NOW() - INTERVAL '5 minutes'
      ORDER BY recorded_at ASC
    `;

    // Analyze rhythm patterns
    const rhythmAnalysis = analyzeRhythmPatterns(recentReadings);

    // Calculate tempo metrics
    const tempoMetrics = calculateTempoMetrics(recentReadings, athlete.sport);

    // Generate sport-specific rhythm guidance
    const rhythmGuidance = generateRhythmGuidance(tempoMetrics, athlete.sport);

    // Build AR overlay for tempo/rhythm
    const tempoOverlay = {
      timestamp: new Date().toISOString(),
      athlete_id,
      session_id,
      sport: athlete.sport,

      // Core rhythm metrics
      rhythm: {
        cadence: rhythmAnalysis.cadence,
        consistency: rhythmAnalysis.consistency,
        variability: rhythmAnalysis.variability,
        pattern: rhythmAnalysis.pattern,
        quality: rhythmAnalysis.quality,
      },

      // Tempo analysis
      tempo: {
        current: tempoMetrics.currentTempo,
        optimal: tempoMetrics.optimalTempo,
        deviation: tempoMetrics.deviation,
        trend: tempoMetrics.trend,
        adjustmentNeeded: tempoMetrics.adjustmentNeeded,
      },

      // Movement rhythm
      movement: {
        strideRate: tempoMetrics.strideRate,
        breathingCadence: tempoMetrics.breathingCadence,
        powerCadence: tempoMetrics.powerCadence,
        synchronization: tempoMetrics.synchronization,
      },

      // Visual overlay elements
      overlayElements: {
        metronome: generateMetronomeOverlay(tempoMetrics),
        rhythmBar: generateRhythmBar(rhythmAnalysis),
        paceIndicator: generatePaceIndicator(tempoMetrics),
        breathingCue: generateBreathingCue(tempoMetrics),
        cadenceZones: generateCadenceZones(tempoMetrics, athlete.sport),
      },

      // Real-time guidance
      guidance: rhythmGuidance,

      // Alerts
      alerts: generateTempoAlerts(tempoMetrics, rhythmAnalysis),

      // Performance impact
      impact: {
        efficiency: calculateEfficiencyImpact(tempoMetrics, rhythmAnalysis),
        fatigueRisk: calculateFatigueRisk(tempoMetrics),
        formStability: calculateFormStability(rhythmAnalysis),
      },
    };

    return Response.json({
      success: true,
      method: 20,
      methodName: "Tempo & Rhythm Analysis",
      overlay: tempoOverlay,
      rawData: {
        readingsAnalyzed: recentReadings.length,
        timeWindow: "5 minutes",
        sport: athlete.sport,
      },
    });
  } catch (error) {
    console.error("Tempo rhythm error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function analyzeRhythmPatterns(readings) {
  if (readings.length < 5) {
    return {
      cadence: 0,
      consistency: 0,
      variability: 0,
      pattern: "insufficient_data",
      quality: 0,
    };
  }

  // Extract heart rate readings for rhythm analysis
  const hrReadings = readings.filter((r) => r.index_code === "RHRi");

  if (hrReadings.length < 3) {
    return {
      cadence: 0,
      consistency: 50,
      variability: 0,
      pattern: "steady",
      quality: 50,
    };
  }

  // Calculate time intervals between readings
  const intervals = [];
  for (let i = 1; i < hrReadings.length; i++) {
    const timeDiff =
      (new Date(hrReadings[i].recorded_at) -
        new Date(hrReadings[i - 1].recorded_at)) /
      1000;
    intervals.push(timeDiff);
  }

  // Calculate cadence (readings per minute)
  const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
  const cadence = avgInterval > 0 ? 60 / avgInterval : 0;

  // Calculate consistency (lower variance = higher consistency)
  const variance = calculateVariance(intervals);
  const consistency = Math.max(0, 100 - variance * 10);

  // Calculate variability in HR values
  const hrValues = hrReadings.map((r) => parseFloat(r.score));
  const hrVariability = calculateVariance(hrValues);

  // Determine pattern
  let pattern = "steady";
  if (variance > 20) pattern = "erratic";
  else if (variance > 10) pattern = "variable";
  else if (variance < 3) pattern = "locked";

  // Overall quality score
  const quality =
    consistency * 0.6 + (100 - Math.min(100, hrVariability * 2)) * 0.4;

  return {
    cadence: Math.round(cadence),
    consistency: Math.round(consistency),
    variability: Math.round(hrVariability),
    pattern,
    quality: Math.round(quality),
  };
}

function calculateTempoMetrics(readings, sport) {
  const latestReadings = {};
  readings.forEach((r) => {
    if (!latestReadings[r.index_code]) {
      latestReadings[r.index_code] = r;
    }
  });

  const hr = parseFloat(latestReadings.RHRi?.score || 70);
  const hrv = parseFloat(latestReadings.HRVi?.score || 50);
  const rr = parseFloat(latestReadings.RRi?.score || 16);

  // Sport-specific optimal tempo ranges
  const optimalRanges = {
    Basketball: { min: 150, max: 175, strideRate: 180 },
    Rugby: { min: 145, max: 170, strideRate: 170 },
    Soccer: { min: 140, max: 165, strideRate: 175 },
    Wrestling: { min: 155, max: 180, strideRate: 160 },
    Tennis: { min: 135, max: 160, strideRate: 165 },
    "American Football": { min: 150, max: 175, strideRate: 175 },
  };

  const optimal = optimalRanges[sport] || {
    min: 140,
    max: 170,
    strideRate: 170,
  };
  const optimalTempo = (optimal.min + optimal.max) / 2;
  const deviation = hr - optimalTempo;

  // Estimate stride rate (steps per minute) from HR and sport
  const strideRate = optimal.strideRate + (hr - optimalTempo) * 0.5;

  // Breathing cadence (breaths per minute)
  const breathingCadence = rr;

  // Power cadence (effort cycles per minute) - estimated from HRV
  const powerCadence = Math.max(0, 100 - hrv);

  // Synchronization score (how well rhythm metrics align)
  const synchronization = calculateSynchronization(
    hr,
    strideRate,
    breathingCadence,
  );

  // Trend analysis
  const hrReadings = readings
    .filter((r) => r.index_code === "RHRi")
    .map((r) => parseFloat(r.score));
  let trend = "stable";
  if (hrReadings.length >= 3) {
    const recent = hrReadings.slice(-3);
    if (recent[2] > recent[1] && recent[1] > recent[0]) trend = "increasing";
    else if (recent[2] < recent[1] && recent[1] < recent[0])
      trend = "decreasing";
  }

  const adjustmentNeeded =
    Math.abs(deviation) > 10
      ? deviation > 0
        ? "decrease"
        : "increase"
      : "none";

  return {
    currentTempo: Math.round(hr),
    optimalTempo: Math.round(optimalTempo),
    deviation: Math.round(deviation),
    trend,
    adjustmentNeeded,
    strideRate: Math.round(strideRate),
    breathingCadence: Math.round(breathingCadence),
    powerCadence: Math.round(powerCadence),
    synchronization: Math.round(synchronization),
  };
}

function generateRhythmGuidance(metrics, sport) {
  const guidance = [];

  if (metrics.adjustmentNeeded === "decrease") {
    guidance.push({
      priority: "high",
      category: "tempo",
      message: `Reduce tempo by ${Math.abs(metrics.deviation)} BPM`,
      action: "Slow pace gradually",
    });
  } else if (metrics.adjustmentNeeded === "increase") {
    guidance.push({
      priority: "medium",
      category: "tempo",
      message: `Increase tempo by ${Math.abs(metrics.deviation)} BPM`,
      action: "Pick up pace gradually",
    });
  }

  if (metrics.synchronization < 70) {
    guidance.push({
      priority: "medium",
      category: "rhythm",
      message: "Movement rhythm not synchronized",
      action: "Focus on breathing-stride coordination",
    });
  }

  if (metrics.breathingCadence > 25) {
    guidance.push({
      priority: "high",
      category: "breathing",
      message: "Breathing rate elevated",
      action: "Deepen breaths, reduce cadence",
    });
  }

  return guidance;
}

function generateMetronomeOverlay(metrics) {
  return {
    targetBPM: metrics.optimalTempo,
    currentBPM: metrics.currentTempo,
    visual: {
      pulseRate: metrics.currentTempo / 60, // pulses per second
      color:
        Math.abs(metrics.deviation) > 10
          ? "red"
          : Math.abs(metrics.deviation) > 5
            ? "yellow"
            : "green",
      intensity: Math.min(100, Math.abs(metrics.deviation) * 5),
    },
    audio: {
      enabled: true,
      frequency: metrics.optimalTempo,
    },
  };
}

function generateRhythmBar(analysis) {
  return {
    value: analysis.consistency,
    color:
      analysis.quality > 75
        ? "green"
        : analysis.quality > 50
          ? "yellow"
          : "red",
    label: `${analysis.pattern} rhythm`,
    quality: analysis.quality,
  };
}

function generatePaceIndicator(metrics) {
  return {
    current: metrics.currentTempo,
    target: metrics.optimalTempo,
    range: {
      min: metrics.optimalTempo - 10,
      max: metrics.optimalTempo + 10,
    },
    status: metrics.adjustmentNeeded === "none" ? "optimal" : "adjust",
  };
}

function generateBreathingCue(metrics) {
  const ratio = metrics.strideRate / metrics.breathingCadence;
  let pattern = "3:1"; // default breathing pattern

  if (ratio > 6) pattern = "4:1";
  else if (ratio > 4) pattern = "3:1";
  else if (ratio > 2) pattern = "2:1";

  return {
    currentRate: metrics.breathingCadence,
    recommendedPattern: pattern,
    cue: `Inhale for ${pattern.split(":")[0]} strides, exhale for ${pattern.split(":")[1]} stride`,
  };
}

function generateCadenceZones(metrics, sport) {
  return {
    recovery: { min: 100, max: 130, color: "blue" },
    aerobic: { min: 130, max: 150, color: "green" },
    tempo: { min: 150, max: 170, color: "yellow" },
    threshold: { min: 170, max: 185, color: "orange" },
    max: { min: 185, max: 200, color: "red" },
    current: metrics.currentTempo,
  };
}

function generateTempoAlerts(tempoMetrics, rhythmAnalysis) {
  const alerts = [];

  if (Math.abs(tempoMetrics.deviation) > 15) {
    alerts.push({
      level: "warning",
      type: "tempo",
      message: `Tempo ${tempoMetrics.deviation > 0 ? "too high" : "too low"}`,
      recommendation: `Adjust by ${Math.abs(tempoMetrics.deviation)} BPM`,
    });
  }

  if (rhythmAnalysis.consistency < 50) {
    alerts.push({
      level: "info",
      type: "rhythm",
      message: "Rhythm inconsistent",
      recommendation: "Focus on maintaining steady cadence",
    });
  }

  if (tempoMetrics.synchronization < 60) {
    alerts.push({
      level: "warning",
      type: "synchronization",
      message: "Movement not synchronized",
      recommendation: "Coordinate breathing with stride",
    });
  }

  return alerts;
}

function calculateEfficiencyImpact(tempoMetrics, rhythmAnalysis) {
  const tempoEfficiency = Math.max(
    0,
    100 - Math.abs(tempoMetrics.deviation) * 2,
  );
  const rhythmEfficiency = rhythmAnalysis.quality;
  const syncEfficiency = tempoMetrics.synchronization;

  return Math.round(
    tempoEfficiency * 0.4 + rhythmEfficiency * 0.3 + syncEfficiency * 0.3,
  );
}

function calculateFatigueRisk(metrics) {
  const highTempo = metrics.currentTempo > metrics.optimalTempo + 15 ? 30 : 0;
  const poorSync = metrics.synchronization < 60 ? 20 : 0;
  const irregularBreathing = metrics.breathingCadence > 25 ? 25 : 0;

  return Math.min(100, highTempo + poorSync + irregularBreathing);
}

function calculateFormStability(rhythmAnalysis) {
  return Math.round(
    rhythmAnalysis.consistency * 0.6 + rhythmAnalysis.quality * 0.4,
  );
}

function calculateVariance(arr) {
  if (arr.length === 0) return 0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  const squaredDiffs = arr.map((x) => Math.pow(x - mean, 2));
  return Math.sqrt(squaredDiffs.reduce((a, b) => a + b, 0) / arr.length);
}

function calculateSynchronization(hr, strideRate, breathingRate) {
  // Ideal ratios for synchronization
  const idealStrideHRRatio = 2.5; // strides per heartbeat
  const idealStrideBreathRatio = 4; // strides per breath

  const actualStrideHRRatio = strideRate / hr;
  const actualStrideBreathRatio = strideRate / breathingRate;

  const strideHRSync =
    100 - Math.abs(actualStrideHRRatio - idealStrideHRRatio) * 20;
  const strideBreathSync =
    100 - Math.abs(actualStrideBreathRatio - idealStrideBreathRatio) * 15;

  return Math.max(0, strideHRSync * 0.5 + strideBreathSync * 0.5);
}
