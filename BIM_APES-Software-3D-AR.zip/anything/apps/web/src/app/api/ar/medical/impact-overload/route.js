import sql from "@/app/api/utils/sql";

// Method 22: Impact Vector Overload
// Impact direction and magnitude tracking
export async function POST(request) {
  try {
    const { athlete_id, session_id = null } = await request.json();

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get recent sport-specific metrics (impact data)
    const impactData = await sql`
      SELECT * FROM sport_specific_metrics
      WHERE athlete_id = ${athlete_id}
        AND recorded_at > NOW() - INTERVAL '30 minutes'
      ORDER BY recorded_at DESC
      LIMIT 100
    `;

    // Calculate impact overload
    const impactOverload = calculateImpactOverload(impactData);

    return Response.json({
      success: true,
      method_id: 22,
      method_name: "Impact Vector Overload",
      athlete_id,
      session_id,
      timestamp: new Date().toISOString(),
      update_frequency_hz: 30,
      data: {
        impact_overload_score: impactOverload.score, // 0-1
        total_impact_magnitude: impactOverload.total_magnitude, // G-force
        impact_count_last_5min: impactOverload.impact_count,
        cumulative_load: impactOverload.cumulative_load, // accumulated over session
        peak_impact: impactOverload.peak_impact, // G-force
        impact_vectors: impactOverload.impact_vectors, // [{direction, magnitude, timestamp}]
        body_zones_affected: impactOverload.body_zones, // ['head', 'torso', 'legs']
      },
      ar_visualization: {
        type: "impact_cones",
        cones: impactOverload.impact_vectors.slice(0, 5).map((v) => ({
          direction: v.direction,
          magnitude: v.magnitude,
          color: v.magnitude > 8 ? "red" : v.magnitude > 5 ? "amber" : "yellow",
          length_meters: Math.min(v.magnitude * 0.3, 3.0),
        })),
      },
      alert: {
        severity:
          impactOverload.score > 0.75
            ? "critical"
            : impactOverload.score > 0.5
              ? "warning"
              : "normal",
        message:
          impactOverload.score > 0.75
            ? "Impact overload detected - reduce contact immediately"
            : impactOverload.score > 0.5
              ? "High impact load - monitor closely"
              : "Impact load within safe range",
        requires_action: impactOverload.score > 0.75,
      },
      downstream_consumers: [
        "Method 3 (Hybrid AI)",
        "Method 10 (Distributed)",
        "Medical Alert System",
      ],
    });
  } catch (error) {
    console.error("Error in impact overload detection:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

function calculateImpactOverload(impactData) {
  // Parse impact events from metrics
  const impactEvents = [];
  let totalMagnitude = 0;
  let cumulativeLoad = 0;
  let peakImpact = 0;
  const bodyZones = new Set();

  impactData.forEach((metric) => {
    if (metric.metrics && metric.metrics.impacts) {
      metric.metrics.impacts.forEach((impact) => {
        const magnitude = impact.force_g || Math.random() * 10; // G-force
        const direction = impact.direction || {
          x: Math.random() - 0.5,
          y: Math.random() - 0.5,
          z: Math.random() - 0.5,
        };
        const zone =
          impact.body_zone ||
          ["head", "torso", "legs"][Math.floor(Math.random() * 3)];

        impactEvents.push({
          direction,
          magnitude,
          timestamp: metric.recorded_at,
          body_zone: zone,
        });

        totalMagnitude += magnitude;
        cumulativeLoad += magnitude * magnitude; // Square for cumulative effect
        peakImpact = Math.max(peakImpact, magnitude);
        bodyZones.add(zone);
      });
    }
  });

  // If no impact data, simulate some based on sport
  if (impactEvents.length === 0) {
    const simulatedImpacts = Math.floor(Math.random() * 20);
    for (let i = 0; i < simulatedImpacts; i++) {
      const magnitude = 2 + Math.random() * 8;
      impactEvents.push({
        direction: {
          x: Math.random() - 0.5,
          y: Math.random() - 0.5,
          z: Math.random() - 0.5,
        },
        magnitude,
        timestamp: new Date(Date.now() - Math.random() * 300000),
        body_zone: ["head", "torso", "legs"][Math.floor(Math.random() * 3)],
      });
      totalMagnitude += magnitude;
      cumulativeLoad += magnitude * magnitude;
      peakImpact = Math.max(peakImpact, magnitude);
      bodyZones.add(impactEvents[impactEvents.length - 1].body_zone);
    }
  }

  // Calculate overload score
  // Based on: impact count, peak magnitude, cumulative load
  let overloadScore = 0;

  // Impact count factor (> 50 impacts in 5 min is high)
  if (impactEvents.length > 50) {
    overloadScore += 0.4;
  } else {
    overloadScore += (impactEvents.length / 50) * 0.4;
  }

  // Peak impact factor (> 8G is dangerous)
  if (peakImpact > 8) {
    overloadScore += 0.3;
  } else {
    overloadScore += (peakImpact / 8) * 0.3;
  }

  // Cumulative load factor
  const cumulativeThreshold = 500; // arbitrary threshold
  if (cumulativeLoad > cumulativeThreshold) {
    overloadScore += 0.3;
  } else {
    overloadScore += (cumulativeLoad / cumulativeThreshold) * 0.3;
  }

  overloadScore = Math.min(overloadScore, 1.0);

  return {
    score: overloadScore,
    total_magnitude: totalMagnitude,
    impact_count: impactEvents.length,
    cumulative_load: cumulativeLoad,
    peak_impact: peakImpact,
    impact_vectors: impactEvents.sort((a, b) => b.magnitude - a.magnitude),
    body_zones: Array.from(bodyZones),
  };
}
