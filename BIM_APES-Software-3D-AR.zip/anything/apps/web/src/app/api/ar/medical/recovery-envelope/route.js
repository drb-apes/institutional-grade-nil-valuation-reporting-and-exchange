import sql from "@/app/api/utils/sql";

// Method 24: Spatial Recovery Envelope
// Return-to-baseline recovery shell
export async function POST(request) {
  try {
    const { athlete_id, session_id = null } = await request.json();

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get recent biometric readings for recovery tracking
    const readings = await sql`
      SELECT br.*, bid.domain, bid.cluster, bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > NOW() - INTERVAL '24 hours'
      ORDER BY br.recorded_at DESC
    `;

    // Calculate recovery envelope
    const recoveryEnvelope = calculateRecoveryEnvelope(readings);

    return Response.json({
      success: true,
      method_id: 24,
      method_name: "Spatial Recovery Envelope",
      athlete_id,
      session_id,
      timestamp: new Date().toISOString(),
      update_frequency_hz: 5, // Lower frequency for recovery monitoring
      data: {
        recovery_progress: recoveryEnvelope.progress, // 0-1 (1 = fully recovered)
        baseline_metrics: recoveryEnvelope.baseline_metrics,
        current_metrics: recoveryEnvelope.current_metrics,
        envelope_breach: recoveryEnvelope.envelope_breach, // boolean
        breached_metrics: recoveryEnvelope.breached_metrics, // ['HRV', 'sleep_quality']
        estimated_time_to_baseline_hours: recoveryEnvelope.time_to_baseline,
        recovery_velocity: recoveryEnvelope.recovery_velocity, // rate of recovery (0-1 per hour)
        recovery_phase: recoveryEnvelope.phase, // 'acute', 'repair', 'remodeling', 'complete'
      },
      ar_visualization: {
        type: "recovery_shell",
        shell: {
          color:
            recoveryEnvelope.progress > 0.8
              ? "green"
              : recoveryEnvelope.progress > 0.5
                ? "yellow"
                : "red",
          opacity: 0.3 + recoveryEnvelope.progress * 0.4,
          radius_meters: 1.5,
          segments: recoveryEnvelope.segment_health.map((seg) => ({
            name: seg.name,
            health: seg.health, // 0-1
            color:
              seg.health > 0.8 ? "green" : seg.health > 0.5 ? "yellow" : "red",
          })),
        },
      },
      alert: {
        severity: recoveryEnvelope.envelope_breach ? "warning" : "normal",
        message: recoveryEnvelope.envelope_breach
          ? `Recovery envelope breached: ${recoveryEnvelope.breached_metrics.join(", ")}`
          : recoveryEnvelope.progress > 0.8
            ? "Recovery on track - cleared for normal training"
            : "Recovery in progress - monitor closely",
        requires_action:
          recoveryEnvelope.envelope_breach && recoveryEnvelope.progress < 0.5,
      },
      downstream_consumers: [
        "Method 3 (Hybrid AI)",
        "Method 10 (Distributed)",
        "Medical Alert System",
      ],
    });
  } catch (error) {
    console.error("Error in recovery envelope calculation:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

function calculateRecoveryEnvelope(readings) {
  // Define key recovery metrics
  const metrics = ["HRVi", "FAi", "RRi", "HYi", "SQi"];

  const baselineMetrics = {};
  const currentMetrics = {};
  const breachedMetrics = [];
  let totalProgress = 0;
  let metricsChecked = 0;

  metrics.forEach((metricCode) => {
    const metricReadings = readings.filter((r) => r.index_code === metricCode);

    if (metricReadings.length > 0) {
      metricsChecked++;
      const latest = metricReadings[0];
      const baseline = latest.baseline || latest.score;

      baselineMetrics[metricCode] = baseline;
      currentMetrics[metricCode] = latest.score;

      // Calculate recovery progress for this metric
      const ratio = latest.score / baseline;

      // For fatigue index, lower is better (inverse)
      const progress =
        metricCode === "FAi"
          ? Math.max(0, 1 - latest.score / 100)
          : Math.min(ratio, 1);

      totalProgress += progress;

      // Check if breached (< 80% of baseline, except for FAi)
      if (metricCode === "FAi") {
        if (latest.score > 60) {
          // High fatigue = breach
          breachedMetrics.push(metricCode);
        }
      } else {
        if (ratio < 0.8) {
          breachedMetrics.push(metricCode);
        }
      }
    }
  });

  // Calculate overall recovery progress
  const overallProgress =
    metricsChecked > 0 ? totalProgress / metricsChecked : 0;

  // Estimate time to baseline
  const recoveryVelocity = Math.max(0.05, overallProgress * 0.2); // % per hour
  const remainingProgress = Math.max(0, 1 - overallProgress);
  const timeToBaseline = remainingProgress / recoveryVelocity;

  // Determine recovery phase
  let phase = "complete";
  if (overallProgress < 0.3) {
    phase = "acute"; // Still in acute stress
  } else if (overallProgress < 0.6) {
    phase = "repair"; // Early recovery
  } else if (overallProgress < 0.9) {
    phase = "remodeling"; // Late recovery
  }

  // Generate segment health for AR visualization
  const segmentHealth = [
    {
      name: "cardiovascular",
      health: currentMetrics["HRVi"]
        ? currentMetrics["HRVi"] / baselineMetrics["HRVi"]
        : 0.8,
    },
    {
      name: "muscular",
      health: currentMetrics["FAi"] ? 1 - currentMetrics["FAi"] / 100 : 0.8,
    },
    {
      name: "nervous_system",
      health: currentMetrics["RRi"]
        ? currentMetrics["RRi"] / baselineMetrics["RRi"]
        : 0.8,
    },
    {
      name: "hydration",
      health: currentMetrics["HYi"] ? currentMetrics["HYi"] / 100 : 0.8,
    },
    {
      name: "sleep",
      health: currentMetrics["SQi"] ? currentMetrics["SQi"] / 100 : 0.8,
    },
  ];

  return {
    progress: overallProgress,
    baseline_metrics: baselineMetrics,
    current_metrics: currentMetrics,
    envelope_breach: breachedMetrics.length > 0,
    breached_metrics: breachedMetrics,
    time_to_baseline: timeToBaseline,
    recovery_velocity: recoveryVelocity,
    phase: phase,
    segment_health: segmentHealth,
  };
}
