import sql from "@/app/api/utils/sql";

// Method 21: Spatial Collapse Prediction
// Collapse-risk vectors and balance instability
export async function POST(request) {
  try {
    const { athlete_id, session_id = null } = await request.json();

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get recent biometric readings
    const readings = await sql`
      SELECT br.*, bid.domain, bid.cluster, bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > NOW() - INTERVAL '30 minutes'
      ORDER BY br.recorded_at DESC
    `;

    // Calculate collapse risk score
    const collapseRisk = calculateCollapseRisk(readings);

    return Response.json({
      success: true,
      method_id: 21,
      method_name: "Spatial Collapse Prediction",
      athlete_id,
      session_id,
      timestamp: new Date().toISOString(),
      update_frequency_hz: 30,
      data: {
        collapse_risk_score: collapseRisk.score, // 0-1
        balance_stability: collapseRisk.balance_stability, // 0-1
        drift_vectors: collapseRisk.drift_vectors, // {x, y, z}
        center_of_mass_offset: collapseRisk.center_of_mass_offset, // meters
        prediction_confidence: collapseRisk.confidence, // 0-1
        time_to_collapse_seconds: collapseRisk.time_to_collapse, // seconds or null
      },
      ar_visualization: {
        type: "risk_halo",
        color:
          collapseRisk.score > 0.75
            ? "red"
            : collapseRisk.score > 0.5
              ? "amber"
              : "green",
        intensity: collapseRisk.score,
        pulse_rate_hz: Math.min(collapseRisk.score * 5, 3),
        radius_meters: 2.0,
      },
      alert: {
        severity:
          collapseRisk.score > 0.75
            ? "critical"
            : collapseRisk.score > 0.5
              ? "warning"
              : "normal",
        message:
          collapseRisk.score > 0.75
            ? "Immediate rest required - collapse risk critical"
            : collapseRisk.score > 0.5
              ? "Monitor closely - balance instability detected"
              : "Normal balance and stability",
        requires_action: collapseRisk.score > 0.75,
      },
      downstream_consumers: [
        "Method 3 (Hybrid AI)",
        "Method 10 (Distributed)",
        "Medical Alert System",
      ],
    });
  } catch (error) {
    console.error("Error in collapse prediction:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

function calculateCollapseRisk(readings) {
  // Find relevant biometric indices
  const fatigueIndex = readings.find((r) => r.index_code === "FAi");
  const hrvIndex = readings.find((r) => r.index_code === "HRVi");
  const hydrationIndex = readings.find((r) => r.index_code === "HYi");

  // Calculate base risk score
  let riskScore = 0;
  let confidence = 0.8;

  if (fatigueIndex) {
    // High fatigue = high risk
    riskScore += (fatigueIndex.score / 100) * 0.4;
  }

  if (hrvIndex && hrvIndex.baseline) {
    // Low HRV relative to baseline = high risk
    const hrvRatio = hrvIndex.score / hrvIndex.baseline;
    if (hrvRatio < 0.8) {
      riskScore += (1 - hrvRatio) * 0.3;
    }
  }

  if (hydrationIndex) {
    // Dehydration = high risk
    if (hydrationIndex.score < 60) {
      riskScore += (1 - hydrationIndex.score / 100) * 0.3;
    }
  }

  // Cap at 1.0
  riskScore = Math.min(riskScore, 1.0);

  // Calculate balance stability (inverse of risk)
  const balanceStability = Math.max(1 - riskScore, 0);

  // Generate drift vectors (simulated - in production would come from IMU sensors)
  const driftVectors = {
    x: (Math.random() - 0.5) * riskScore * 0.5, // meters
    y: (Math.random() - 0.5) * riskScore * 0.5,
    z: (Math.random() - 0.5) * riskScore * 0.3,
  };

  // Calculate center of mass offset
  const centerOfMassOffset = Math.sqrt(
    driftVectors.x ** 2 + driftVectors.y ** 2,
  );

  // Estimate time to collapse if risk is high
  let timeToCollapse = null;
  if (riskScore > 0.75) {
    // Higher risk = less time
    timeToCollapse = Math.max(30, (1 - riskScore) * 300); // 30-300 seconds
  }

  return {
    score: riskScore,
    balance_stability: balanceStability,
    drift_vectors: driftVectors,
    center_of_mass_offset: centerOfMassOffset,
    confidence: confidence,
    time_to_collapse: timeToCollapse,
  };
}
