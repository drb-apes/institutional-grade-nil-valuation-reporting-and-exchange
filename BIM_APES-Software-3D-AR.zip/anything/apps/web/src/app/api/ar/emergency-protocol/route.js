import sql from "@/app/api/utils/sql";

/**
 * POST /api/ar/emergency-protocol
 * 3-Minute Emergency Recovery Protocol
 * Handles: Overlay Drift, Freeze, Data Drop, Auto-Trigger Malfunction, Full System Stall
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      failure_type, // 'overlay_drift', 'overlay_freeze', 'data_drop', 'auto_trigger_malfunction', 'full_system_stall'
      athlete_ids = [],
      event_id = null,
      timestamp = new Date().toISOString(),
    } = body;

    if (!failure_type) {
      return Response.json(
        { success: false, error: "failure_type is required" },
        { status: 400 },
      );
    }

    const protocol = generateEmergencyProtocol(failure_type, athlete_ids);

    // Log emergency event
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'emergency_protocol',
        ${event_id || "system"},
        ${failure_type},
        'ar_emergency_system',
        ${JSON.stringify({ protocol, athlete_ids })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      failure_type,
      protocol,
      timeline: generateTimeline(failure_type),
      communication_blast: generateCommunicationBlast(failure_type),
      verification_checklist: generateVerificationChecklist(athlete_ids),
      timestamp,
    });
  } catch (error) {
    console.error("Emergency protocol error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/ar/emergency-protocol/status
 * Check current system status
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const event_id = searchParams.get("event_id");

    // Get recent emergency events
    const recentEvents = await sql`
      SELECT * FROM audit_logs
      WHERE entity_type = 'emergency_protocol'
        ${event_id ? sql`AND entity_id = ${event_id}` : sql``}
      ORDER BY created_at DESC
      LIMIT 20
    `;

    // System health metrics
    const systemStatus = {
      ar_engine_status: "nominal", // Would check real AR engine health
      overlay_tracking: "stable",
      sensor_ingestion: "active",
      auto_trigger_mode: "enabled",
      last_failure: recentEvents[0] || null,
    };

    return Response.json({
      success: true,
      system_status: systemStatus,
      recent_events: recentEvents,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Emergency status check error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === PROTOCOL GENERATORS ===

function generateEmergencyProtocol(failureType, athleteIds) {
  const protocols = {
    overlay_drift: {
      diagnosis: "Spatial anchors misaligned",
      immediate_actions: [
        "Check anchor stability for primary players",
        "Check camera feed integrity",
        "Check network stability",
        "Verify court/field calibration points",
      ],
      rapid_restore: [
        "Re-anchor primary players (A → B → C → D)",
        "Re-calibrate camera positions",
        "Sync timestamps with game clock",
        "Test overlay tracking on one player before full restore",
      ],
      fallback: "Switch to 2D overlay mode if 3D anchoring fails",
    },
    overlay_freeze: {
      diagnosis: "AR layer stopped updating",
      immediate_actions: [
        "Check AR engine process status",
        "Check GPU utilization",
        "Check rendering pipeline",
        "Verify frame rate stability",
      ],
      rapid_restore: [
        "Restart AR rendering thread",
        "Flush overlay buffer",
        "Re-initialize graphics pipeline",
        "Load minimal overlay set first",
      ],
      fallback:
        "AR-Lite Mode: stress halos, fatigue rings, landing-force markers only",
    },
    data_drop: {
      diagnosis: "Wearables, Tobii, Muse, or camera feed interruption",
      immediate_actions: [
        "Check sensor connection status",
        "Check network connectivity",
        "Check data ingestion timestamps",
        "Identify which sensor(s) dropped",
      ],
      rapid_restore: [
        "Re-initialize sensor ingestion",
        "Confirm timestamps align with game clock",
        "Validate data quality post-restore",
        "Use last-known-good values for missing data",
      ],
      fallback: "Manual-only mode with cached biometric baselines",
    },
    auto_trigger_malfunction: {
      diagnosis:
        "Overlays firing incorrectly (false positives or missed triggers)",
      immediate_actions: [
        "Check auto-trigger threshold pane",
        "Review recent trigger events",
        "Identify false positive patterns",
        "Check narrative alignment rules",
      ],
      rapid_restore: [
        "Disable auto-trigger",
        "Switch to manual-only mode",
        "Re-tune thresholds based on recent data",
        "Re-enable auto-trigger after stabilization test",
      ],
      fallback: "Manual activation panel only until thresholds recalibrated",
    },
    full_system_stall: {
      diagnosis: "AR engine unresponsive",
      immediate_actions: [
        "Hard-reset AR engine",
        "Check system resource utilization",
        "Check critical service dependencies",
        "Verify database connectivity",
      ],
      rapid_restore: [
        "Load emergency 'minimal overlay mode'",
        "Prioritize: 1) Stress halos, 2) Fatigue rings, 3) Landing-force markers",
        "Restore services in order: sensors → overlays → auto-triggers",
        "Full system verification before resuming normal ops",
      ],
      fallback:
        "Zero overlay mode - raw video feed only until stability confirmed",
    },
  };

  return (
    protocols[failureType] || {
      diagnosis: "Unknown failure type",
      immediate_actions: ["Contact system administrator"],
      rapid_restore: ["Follow general recovery protocol"],
      fallback: "Manual operations only",
    }
  );
}

function generateTimeline(failureType) {
  return {
    "0:00-0:30": {
      phase: "DIAGNOSE THE FAILURE",
      actions: [
        "Identify failure type",
        "Check system logs",
        "Assess impact scope",
        "Determine priority overlays",
      ],
    },
    "0:30-1:30": {
      phase: "IMMEDIATE ACTIONS & RAPID RESTORE",
      actions: [
        "Execute immediate diagnostic checks",
        "Begin rapid restore procedure",
        "Switch to fallback mode if needed",
        "Monitor restoration progress",
      ],
    },
    "1:30-2:30": {
      phase: "COMMUNICATION BLAST",
      actions: [
        "Notify all departments",
        "Provide status updates",
        "Confirm critical overlays active",
        "Update stakeholder dashboards",
      ],
    },
    "2:30-3:00": {
      phase: "VERIFY & LOCK",
      actions: [
        "Final system checks",
        "Verify overlay tracking accuracy",
        "Confirm auto-triggers (if re-enabled)",
        "Return to full operations or maintain AR-Lite",
      ],
    },
  };
}

function generateCommunicationBlast(failureType) {
  return {
    coaching: {
      message: "AR layer restored — manual mode active",
      priority: "high",
      channels: ["dashboard", "in-ear", "sideline_tablet"],
    },
    medical: {
      message: "Biomech alerts stable — risk monitoring live",
      priority: "high",
      channels: ["medical_dashboard", "emergency_tablet"],
    },
    media: {
      message: "Overlays safe — NIL/sponsor triggers back online",
      priority: "medium",
      channels: ["broadcast_control", "social_media_team"],
    },
    analytics: {
      message: "Data ingestion normalized — continue tagging",
      priority: "medium",
      channels: ["analytics_dashboard", "tagging_console"],
    },
    sponsors: {
      message:
        failureType === "auto_trigger_malfunction"
          ? "Sponsor activations paused — manual approval required"
          : "Sponsor overlays operational — activations proceeding",
      priority: "medium",
      channels: ["sponsor_dashboard", "activation_console"],
    },
  };
}

function generateVerificationChecklist(athleteIds) {
  return {
    overlay_tracking: [
      "Confirm overlays track primary player deceleration + torque",
      "Confirm secondary player rim-pressure overlays responsive",
      "Confirm big player verticality + landing markers accurate",
      "Confirm corner-spacing players remain uncluttered",
    ],
    auto_triggers: [
      "Test auto-trigger on known event (if re-enabled)",
      "Verify thresholds behave correctly",
      "Check false positive rate",
      "Confirm narrative alignment",
    ],
    data_quality: [
      "Verify sensor timestamps align with game clock",
      "Check data ingestion rate stability",
      "Validate biometric readings within expected ranges",
      "Confirm no data gaps in critical indices",
    ],
    system_stability: [
      "AR engine frame rate stable (>30 FPS)",
      "GPU utilization within normal range",
      "Network latency acceptable (<50ms)",
      "No memory leaks or resource exhaustion",
    ],
  };
}
