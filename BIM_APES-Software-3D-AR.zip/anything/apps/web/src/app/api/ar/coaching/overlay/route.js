import sql from "@/app/api/utils/sql";

/**
 * POST /api/ar/coaching/overlay
 * Method 19: Coaching AR Overlay Engine
 * Generates real-time coaching overlays for live performance optimization
 */
export async function POST(request) {
  try {
    const {
      athlete_id,
      session_id,
      overlay_type = "all",
    } = await request.json();

    if (!athlete_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id is required",
        },
        { status: 400 },
      );
    }

    // Get athlete data
    const athletes = await sql`
      SELECT id, first_name, last_name, sport, position, team
      FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json(
        {
          success: false,
          error: "Athlete not found",
        },
        { status: 404 },
      );
    }

    const athlete = athletes[0];

    // Get recent biometric data (last 10 minutes for real-time coaching)
    const recentReadings = await sql`
      SELECT index_code, score, baseline, trend, recorded_at
      FROM biometric_readings
      WHERE athlete_id = ${athlete_id}
        AND recorded_at > NOW() - INTERVAL '10 minutes'
      ORDER BY recorded_at DESC
    `;

    // Get current session data
    let currentSession = null;
    if (session_id) {
      const sessions = await sql`
        SELECT id, session_type, sport, intensity, performance_score, started_at
        FROM performance_sessions
        WHERE id = ${session_id} AND athlete_id = ${athlete_id}
      `;
      currentSession = sessions[0] || null;
    }

    // Calculate real-time coaching metrics
    const metrics = calculateCoachingMetrics(
      recentReadings,
      currentSession,
      athlete,
    );

    // Generate overlay elements
    const overlays = {
      performanceZone: generatePerformanceZoneOverlay(metrics),
      techniqueCorrections: generateTechniqueOverlay(metrics, athlete.sport),
      paceGuidance: generatePaceOverlay(metrics),
      fatigueWarnings: generateFatigueOverlay(metrics),
      formCues: generateFormCuesOverlay(metrics, athlete.sport),
      intensityAdjustments: generateIntensityOverlay(metrics),
    };

    // Generate unified coaching overlay
    const unifiedOverlay = {
      timestamp: new Date().toISOString(),
      athlete_id,
      session_id,
      sport: athlete.sport,
      position: athlete.position,

      // Real-time coaching guidance
      primaryGuidance: overlays.performanceZone.guidance,
      secondaryGuidance: overlays.techniqueCorrections.cues.slice(0, 2),

      // Visual overlay elements
      overlayElements: {
        zoneIndicator: overlays.performanceZone.zoneIndicator,
        techniqueCues: overlays.techniqueCorrections.cues,
        paceMetronome: overlays.paceGuidance.metronome,
        fatigueAlerts: overlays.fatigueWarnings.alerts,
        formCorrections: overlays.formCues.corrections,
        intensityBar: overlays.intensityAdjustments.bar,
      },

      // Coach dashboard data
      metrics: {
        currentZone: metrics.performanceZone,
        heartRateZone: metrics.hrZone,
        powerOutput: metrics.powerOutput,
        techniqueScore: metrics.techniqueScore,
        fatigueLevel: metrics.fatigueLevel,
        formQuality: metrics.formQuality,
      },

      // Recommendations
      recommendations: generateRecommendations(metrics, athlete.sport),

      // Alert level
      alertLevel: determineAlertLevel(metrics),
    };

    return Response.json({
      success: true,
      method: 19,
      methodName: "Coaching AR Overlay",
      overlay: unifiedOverlay,
      rawMetrics: metrics,
      biometricCount: recentReadings.length,
    });
  } catch (error) {
    console.error("Coaching overlay error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function calculateCoachingMetrics(readings, session, athlete) {
  const latestReadings = {};

  // Get most recent value for each index
  readings.forEach((r) => {
    if (!latestReadings[r.index_code]) {
      latestReadings[r.index_code] = r;
    }
  });

  const hr = latestReadings.RHRi?.score || 70;
  const hrv = latestReadings.HRVi?.score || 50;
  const vo2 = latestReadings.SpO2i?.score || 95;

  // Calculate HR zones (% of max HR, assuming max = 220 - age estimate of 25)
  const maxHR = 195;
  const hrPercent = (hr / maxHR) * 100;

  let performanceZone = "recovery";
  let hrZone = 1;

  if (hrPercent > 90) {
    performanceZone = "max";
    hrZone = 5;
  } else if (hrPercent > 80) {
    performanceZone = "anaerobic";
    hrZone = 4;
  } else if (hrPercent > 70) {
    performanceZone = "tempo";
    hrZone = 3;
  } else if (hrPercent > 60) {
    performanceZone = "aerobic";
    hrZone = 2;
  }

  // Power output estimation
  const powerOutput = Math.max(0, (hrPercent - 50) * 5 + (vo2 - 90) * 10);

  // Technique score (HRV as proxy for efficiency)
  const techniqueScore = Math.min(100, hrv * 1.2);

  // Fatigue level (inverse of HRV)
  const fatigueLevel = Math.max(0, 100 - hrv);

  // Form quality (combination of metrics)
  const formQuality = techniqueScore * 0.6 + (100 - fatigueLevel) * 0.4;

  return {
    performanceZone,
    hrZone,
    heartRate: hr,
    heartRatePercent: hrPercent,
    hrv,
    vo2,
    powerOutput,
    techniqueScore,
    fatigueLevel,
    formQuality,
    intensity: session?.intensity || "Medium",
  };
}

function generatePerformanceZoneOverlay(metrics) {
  const zoneColors = {
    recovery: "#4CAF50",
    aerobic: "#2196F3",
    tempo: "#FF9800",
    anaerobic: "#FF5722",
    max: "#D32F2F",
  };

  return {
    guidance: `Zone ${metrics.hrZone}: ${metrics.performanceZone.toUpperCase()}`,
    zoneIndicator: {
      color: zoneColors[metrics.performanceZone],
      intensity: metrics.heartRatePercent,
      label: metrics.performanceZone,
      recommendation: getZoneRecommendation(metrics.performanceZone),
    },
  };
}

function generateTechniqueOverlay(metrics, sport) {
  const cues = [];

  if (metrics.techniqueScore < 70) {
    cues.push({
      type: "form",
      priority: "high",
      message: "Focus on technique - efficiency dropping",
      indicator: "red",
    });
  }

  if (metrics.heartRate > 160 && metrics.hrv < 40) {
    cues.push({
      type: "pacing",
      priority: "medium",
      message: "Consider slowing pace to maintain form",
      indicator: "yellow",
    });
  }

  return { cues };
}

function generatePaceOverlay(metrics) {
  const targetHR = getTargetHRForZone(metrics.performanceZone);
  const deviation = metrics.heartRate - targetHR;

  return {
    metronome: {
      targetPace: targetHR,
      currentPace: metrics.heartRate,
      deviation,
      guidance:
        deviation > 10
          ? "Slow down"
          : deviation < -10
            ? "Speed up"
            : "Maintain pace",
    },
  };
}

function generateFatigueOverlay(metrics) {
  const alerts = [];

  if (metrics.fatigueLevel > 70) {
    alerts.push({
      level: "critical",
      message: "High fatigue detected - consider recovery interval",
      action: "reduce intensity",
    });
  } else if (metrics.fatigueLevel > 50) {
    alerts.push({
      level: "warning",
      message: "Moderate fatigue - monitor form closely",
      action: "maintain awareness",
    });
  }

  return { alerts };
}

function generateFormCuesOverlay(metrics, sport) {
  const corrections = [];

  if (metrics.formQuality < 70) {
    corrections.push({
      bodyPart: "posture",
      issue: "efficiency declining",
      correction: "Check posture and breathing rhythm",
    });
  }

  return { corrections };
}

function generateIntensityOverlay(metrics) {
  return {
    bar: {
      current: metrics.powerOutput,
      max: 500,
      zone: metrics.performanceZone,
      color:
        metrics.powerOutput > 400
          ? "red"
          : metrics.powerOutput > 250
            ? "orange"
            : "green",
    },
  };
}

function generateRecommendations(metrics, sport) {
  const recommendations = [];

  if (metrics.fatigueLevel > 60 && metrics.performanceZone === "max") {
    recommendations.push({
      priority: 1,
      category: "safety",
      message: "Reduce intensity to prevent overexertion",
      action: "Drop to tempo zone for 2-3 minutes",
    });
  }

  if (metrics.techniqueScore < 75) {
    recommendations.push({
      priority: 2,
      category: "technique",
      message: "Technique degrading under load",
      action: "Focus on form over speed",
    });
  }

  if (metrics.hrv < 45 && metrics.heartRate > 150) {
    recommendations.push({
      priority: 2,
      category: "recovery",
      message: "Stress indicators elevated",
      action: "Consider active recovery interval",
    });
  }

  return recommendations;
}

function determineAlertLevel(metrics) {
  if (metrics.fatigueLevel > 80 || metrics.formQuality < 50) return "critical";
  if (metrics.fatigueLevel > 60 || metrics.techniqueScore < 70)
    return "warning";
  return "normal";
}

function getZoneRecommendation(zone) {
  const recommendations = {
    recovery: "Light activity - focus on form",
    aerobic: "Sustainable pace - build endurance",
    tempo: "Comfortably hard - maintain technique",
    anaerobic: "High intensity - short intervals",
    max: "Maximum effort - brief bursts only",
  };
  return recommendations[zone] || "Maintain current effort";
}

function getTargetHRForZone(zone) {
  const targets = {
    recovery: 110,
    aerobic: 130,
    tempo: 150,
    anaerobic: 170,
    max: 185,
  };
  return targets[zone] || 140;
}
