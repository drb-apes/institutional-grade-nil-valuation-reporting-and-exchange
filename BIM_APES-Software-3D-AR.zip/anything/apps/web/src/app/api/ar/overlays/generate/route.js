import sql from "@/app/api/utils/sql";

/**
 * POST /api/ar/overlays/generate
 * Generates AR biomechanical overlays for real-time visualization
 * Supports 10+ overlay types across stress, fatigue, recovery, and performance
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      overlay_types = ["all"],
      session_id = null,
      timestamp = new Date().toISOString(),
    } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Fetch athlete data
    const athleteRows = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteRows.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 404 },
      );
    }

    const athlete = athleteRows[0];

    // Fetch recent biometric readings (last 2 hours)
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
    const biometricReadings = await sql`
      SELECT br.*, bid.domain, bid.cluster, bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > ${twoHoursAgo}
      ORDER BY br.recorded_at DESC
    `;

    // Generate overlays
    const overlays = {};
    const requestedTypes = overlay_types.includes("all")
      ? [
          "stress",
          "fatigue",
          "recovery",
          "power",
          "movement",
          "tactical",
          "injury_risk",
          "performance",
          "biomechanical",
          "neuromuscular",
        ]
      : overlay_types;

    if (requestedTypes.includes("stress")) {
      overlays.stress = generateStressOverlay(biometricReadings, athlete);
    }

    if (requestedTypes.includes("fatigue")) {
      overlays.fatigue = await generateFatigueOverlay(
        athlete_id,
        biometricReadings,
      );
    }

    if (requestedTypes.includes("recovery")) {
      overlays.recovery = generateRecoveryOverlay(biometricReadings);
    }

    if (requestedTypes.includes("power")) {
      overlays.power = generatePowerOverlay(biometricReadings, athlete);
    }

    if (requestedTypes.includes("movement")) {
      overlays.movement = generateMovementOverlay(biometricReadings, athlete);
    }

    if (requestedTypes.includes("tactical")) {
      overlays.tactical = generateTacticalOverlay(biometricReadings, athlete);
    }

    if (requestedTypes.includes("injury_risk")) {
      overlays.injury_risk = generateInjuryRiskOverlay(biometricReadings);
    }

    if (requestedTypes.includes("performance")) {
      overlays.performance = generatePerformanceOverlay(biometricReadings);
    }

    if (requestedTypes.includes("biomechanical")) {
      overlays.biomechanical = generateBiomechanicalOverlay(
        biometricReadings,
        athlete,
      );
    }

    if (requestedTypes.includes("neuromuscular")) {
      overlays.neuromuscular = generateNeuromuscularOverlay(biometricReadings);
    }

    return Response.json({
      success: true,
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        sport: athlete.sport,
      },
      timestamp,
      overlays,
      data_quality: {
        readings_count: biometricReadings.length,
        time_window_hours: 2,
      },
    });
  } catch (error) {
    console.error("AR overlay generation error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === OVERLAY GENERATORS ===

function generateStressOverlay(readings, athlete) {
  const hrvReading = readings.find((r) => r.index_code === "HRVi");
  const cortisol = readings.find((r) => r.index_code === "CLi");

  return {
    type: "stress",
    visualization: "stress_cones",
    elements: [
      {
        id: "joint_stress_shoulders",
        type: "stress_cone",
        joint: "shoulders",
        position: { x: 0, y: 1.4, z: 0 },
        intensity: cortisol ? cortisol.score : 0.35,
        color: "#FF6B6B",
        opacity: 0.7,
        animation: "pulse",
      },
      {
        id: "joint_stress_knees",
        type: "stress_cone",
        joint: "knees",
        position: { x: 0, y: 0.5, z: 0 },
        intensity: 0.42,
        color: "#FFA500",
        opacity: 0.6,
        animation: "pulse",
      },
      {
        id: "hrv_stress_halo",
        type: "redline_ring",
        position: { x: 0, y: 1.7, z: 0 },
        radius: 0.3,
        thickness: 0.05,
        stress_level: hrvReading ? (100 - hrvReading.score) / 100 : 0.4,
        color: "#E53935",
        animation: "rotate",
      },
    ],
    metrics: {
      overall_stress: cortisol ? cortisol.score : 0.38,
      hrv_stress: hrvReading ? (100 - hrvReading.score) / 100 : 0.4,
      joint_load_asymmetry: 0.15,
    },
  };
}

async function generateFatigueOverlay(athlete_id, readings) {
  const fatigueIndex = readings.find((r) => r.index_code === "FAi");

  return {
    type: "fatigue",
    visualization: "fatigue_halo",
    elements: [
      {
        id: "fatigue_halo",
        type: "gradient_halo",
        position: { x: 0, y: 1, z: 0 },
        radius: 0.5,
        intensity: fatigueIndex ? fatigueIndex.score / 100 : 0.45,
        color_start: "#4CAF50",
        color_end: "#FF5252",
        opacity: 0.5,
        animation: "breathe",
      },
      {
        id: "stride_ghost_trail",
        type: "ghost_trail",
        body_part: "legs",
        trail_length: 0.8,
        opacity: 0.3,
        color: "#64B5F6",
        positions: [
          { x: -0.2, y: 0.3, z: 0 },
          { x: -0.15, y: 0.2, z: -0.1 },
          { x: -0.1, y: 0.1, z: -0.2 },
        ],
      },
      {
        id: "energy_depletion_bar",
        type: "vertical_bar",
        position: { x: 0.6, y: 1, z: 0 },
        height: 1.5,
        fill_percentage: fatigueIndex ? 100 - fatigueIndex.score : 55,
        color: "#FFC107",
        label: "Energy Reserve",
      },
    ],
    metrics: {
      fatigue_score: fatigueIndex ? fatigueIndex.score : 45,
      acute_fatigue: 0.52,
      chronic_fatigue: 0.38,
      residual_fatigue: 0.22,
    },
  };
}

function generateRecoveryOverlay(readings) {
  const recoveryIndex = readings.find((r) => r.index_code === "RRi");
  const hrvReading = readings.find((r) => r.index_code === "HRVi");

  return {
    type: "recovery",
    visualization: "recovery_rings",
    elements: [
      {
        id: "recovery_ring_inner",
        type: "concentric_ring",
        position: { x: 0, y: 1, z: 0 },
        radius: 0.3,
        thickness: 0.04,
        completion: recoveryIndex ? recoveryIndex.score / 100 : 0.72,
        color: "#4CAF50",
        animation: "fill_clockwise",
      },
      {
        id: "recovery_ring_middle",
        type: "concentric_ring",
        position: { x: 0, y: 1, z: 0 },
        radius: 0.4,
        thickness: 0.03,
        completion: hrvReading ? hrvReading.score / 100 : 0.65,
        color: "#66BB6A",
        animation: "fill_clockwise",
        delay: 0.2,
      },
      {
        id: "tissue_repair_heatmap",
        type: "body_heatmap",
        body_regions: [
          { region: "shoulders", repair_level: 0.78, color: "#81C784" },
          { region: "core", repair_level: 0.85, color: "#66BB6A" },
          { region: "legs", repair_level: 0.62, color: "#AED581" },
        ],
      },
    ],
    metrics: {
      recovery_score: recoveryIndex ? recoveryIndex.score : 72,
      hrv_recovery: hrvReading ? hrvReading.score : 65,
      tissue_repair_index: 0.75,
      recovery_velocity: 0.12,
    },
  };
}

function generatePowerOverlay(readings, athlete) {
  return {
    type: "power",
    visualization: "force_vectors",
    elements: [
      {
        id: "explosive_power_burst",
        type: "vector_arrow",
        origin: { x: 0, y: 0.8, z: 0 },
        direction: { x: 0, y: 1, z: 0 },
        magnitude: 0.85,
        color: "#FF6F00",
        width: 0.1,
        animation: "pulse_surge",
      },
      {
        id: "power_output_graph",
        type: "radial_graph",
        position: { x: 0.7, y: 1.2, z: 0 },
        metrics: [
          { label: "Peak Power", value: 0.92, angle: 0 },
          { label: "Sustained", value: 0.78, angle: 60 },
          { label: "Explosive", value: 0.88, angle: 120 },
          { label: "Endurance", value: 0.65, angle: 180 },
        ],
        color: "#FF9800",
      },
      {
        id: "force_platform_visualization",
        type: "ground_reaction_force",
        foot_left: { force: 850, position: { x: -0.1, y: 0, z: 0 } },
        foot_right: { force: 920, position: { x: 0.1, y: 0, z: 0 } },
        color: "#F44336",
        show_asymmetry: true,
      },
    ],
    metrics: {
      peak_power_watts: 1250,
      power_to_weight_ratio: athlete.weight_kg
        ? 1250 / athlete.weight_kg
        : 15.6,
      explosive_strength_index: 0.88,
      force_asymmetry: 0.08,
    },
  };
}

function generateMovementOverlay(readings, athlete) {
  return {
    type: "movement",
    visualization: "kinematic_analysis",
    elements: [
      {
        id: "movement_efficiency_trail",
        type: "motion_trail",
        body_part: "center_of_mass",
        trail_points: [
          { x: 0, y: 1, z: 0, t: 0 },
          { x: 0.1, y: 1.05, z: 0.1, t: 0.1 },
          { x: 0.2, y: 1.1, z: 0.2, t: 0.2 },
        ],
        color: "#2196F3",
        opacity: 0.6,
      },
      {
        id: "joint_angle_overlay",
        type: "angle_arc",
        joint: "knee",
        angle_current: 145,
        angle_optimal: 150,
        position: { x: 0, y: 0.5, z: 0 },
        color: "#00BCD4",
      },
      {
        id: "stride_length_indicator",
        type: "distance_marker",
        start: { x: -0.5, y: 0, z: 0 },
        end: { x: 0.5, y: 0, z: 0 },
        distance_meters: 2.1,
        color: "#009688",
      },
    ],
    metrics: {
      movement_efficiency: 0.82,
      stride_length_avg: 2.1,
      cadence: 180,
      vertical_oscillation: 0.085,
    },
  };
}

function generateTacticalOverlay(readings, athlete) {
  return {
    type: "tactical",
    visualization: "tactical_positioning",
    elements: [
      {
        id: "positioning_heatmap",
        type: "heatmap_zone",
        sport: athlete.sport,
        zones: [
          { zone: "attack", coverage: 0.65, color: "#FF5722" },
          { zone: "midfield", coverage: 0.78, color: "#FF9800" },
          { zone: "defense", coverage: 0.52, color: "#FFC107" },
        ],
      },
      {
        id: "decision_making_indicator",
        type: "neural_pathway",
        reaction_time_ms: 285,
        decision_quality: 0.76,
        color: "#9C27B0",
      },
      {
        id: "spacing_efficiency_grid",
        type: "spatial_grid",
        optimal_spacing: 3.5,
        current_spacing: 3.2,
        teammates: 4,
        color: "#673AB7",
      },
    ],
    metrics: {
      tactical_awareness: 0.81,
      positioning_score: 0.76,
      decision_speed_ms: 285,
      spatial_awareness: 0.73,
    },
  };
}

function generateInjuryRiskOverlay(readings) {
  return {
    type: "injury_risk",
    visualization: "risk_indicators",
    elements: [
      {
        id: "injury_risk_zones",
        type: "body_risk_map",
        regions: [
          { region: "left_knee", risk_level: 0.42, color: "#FFA726" },
          { region: "right_ankle", risk_level: 0.28, color: "#FFB74D" },
          { region: "lower_back", risk_level: 0.35, color: "#FFCC80" },
        ],
      },
      {
        id: "asymmetry_warning",
        type: "balance_scale",
        left_side: 0.48,
        right_side: 0.52,
        threshold: 0.1,
        color: "#FF6F00",
      },
      {
        id: "overload_alert",
        type: "warning_indicator",
        position: { x: 0, y: 1.8, z: 0 },
        severity: "moderate",
        message: "Elevated knee stress",
        color: "#FF9800",
        animation: "blink",
      },
    ],
    metrics: {
      overall_injury_risk: 0.35,
      asymmetry_index: 0.08,
      overload_score: 0.42,
      tissue_stress: 0.38,
    },
  };
}

function generatePerformanceOverlay(readings) {
  return {
    type: "performance",
    visualization: "performance_metrics",
    elements: [
      {
        id: "performance_radar",
        type: "radar_chart",
        position: { x: -0.7, y: 1.2, z: 0 },
        metrics: [
          { label: "Speed", value: 0.88 },
          { label: "Strength", value: 0.82 },
          { label: "Endurance", value: 0.75 },
          { label: "Agility", value: 0.91 },
          { label: "Power", value: 0.85 },
          { label: "Technique", value: 0.79 },
        ],
        color: "#3F51B5",
      },
      {
        id: "readiness_gauge",
        type: "circular_gauge",
        position: { x: 0.7, y: 1.2, z: 0 },
        value: 0.83,
        min: 0,
        max: 1,
        color: "#4CAF50",
        label: "Readiness",
      },
    ],
    metrics: {
      overall_performance: 0.83,
      readiness_score: 0.83,
      consistency_index: 0.76,
    },
  };
}

function generateBiomechanicalOverlay(readings, athlete) {
  return {
    type: "biomechanical",
    visualization: "biomech_skeleton",
    elements: [
      {
        id: "skeletal_overlay",
        type: "skeleton_wireframe",
        joints: [
          { name: "ankle", position: { x: 0, y: 0.1, z: 0 }, stress: 0.35 },
          { name: "knee", position: { x: 0, y: 0.5, z: 0 }, stress: 0.42 },
          { name: "hip", position: { x: 0, y: 1, z: 0 }, stress: 0.28 },
          { name: "shoulder", position: { x: 0, y: 1.4, z: 0 }, stress: 0.38 },
        ],
        color: "#00BCD4",
      },
      {
        id: "muscle_activation_map",
        type: "muscle_heatmap",
        muscles: [
          { name: "quadriceps", activation: 0.78, color: "#FF5722" },
          { name: "hamstrings", activation: 0.65, color: "#FF9800" },
          { name: "glutes", activation: 0.82, color: "#FF5722" },
          { name: "calves", activation: 0.58, color: "#FFC107" },
        ],
      },
      {
        id: "joint_load_vectors",
        type: "force_vectors",
        vectors: [
          { joint: "knee", force: 1200, direction: { x: 0, y: -1, z: 0 } },
          { joint: "ankle", force: 980, direction: { x: 0, y: -1, z: 0 } },
        ],
        color: "#F44336",
      },
    ],
    metrics: {
      joint_load_index: 0.42,
      muscle_balance: 0.76,
      kinetic_chain_efficiency: 0.81,
    },
  };
}

function generateNeuromuscularOverlay(readings) {
  return {
    type: "neuromuscular",
    visualization: "neural_activation",
    elements: [
      {
        id: "reaction_time_indicator",
        type: "neural_pulse",
        origin: { x: 0, y: 1.7, z: 0 },
        targets: [
          { x: 0, y: 1.4, z: 0 },
          { x: -0.3, y: 1, z: 0 },
          { x: 0.3, y: 1, z: 0 },
        ],
        speed_ms: 145,
        color: "#E91E63",
      },
      {
        id: "motor_unit_recruitment",
        type: "activation_graph",
        position: { x: 0.7, y: 1, z: 0 },
        recruitment_percentage: 0.85,
        color: "#9C27B0",
      },
      {
        id: "neuromuscular_fatigue",
        type: "decay_curve",
        position: { x: -0.7, y: 1, z: 0 },
        fatigue_rate: 0.15,
        color: "#FF6F00",
      },
    ],
    metrics: {
      reaction_time_ms: 145,
      motor_unit_recruitment: 0.85,
      neuromuscular_efficiency: 0.82,
      central_fatigue: 0.22,
    },
  };
}
