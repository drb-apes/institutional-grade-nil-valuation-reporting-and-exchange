import sql from "@/app/api/utils/sql";

/**
 * POST /api/ar/overlay-control
 * Manual activation panel for AR overlays
 * Supports: auto-trigger override, manual activation, overlay depth/scale/anchor
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      action, // 'enable', 'disable', 'trigger', 'configure'
      overlay_type, // 'stress', 'fatigue', 'recovery', 'power', etc.
      athlete_id,
      configuration = {},
      auto_trigger_enabled = true,
      timestamp = new Date().toISOString(),
    } = body;

    if (!action) {
      return Response.json(
        { success: false, error: "action is required" },
        { status: 400 },
      );
    }

    let result;

    switch (action) {
      case "trigger":
        result = await triggerOverlay(athlete_id, overlay_type, configuration);
        break;
      case "enable":
        result = await enableAutoTrigger(overlay_type, configuration);
        break;
      case "disable":
        result = await disableAutoTrigger(overlay_type);
        break;
      case "configure":
        result = await configureOverlay(overlay_type, configuration);
        break;
      default:
        return Response.json(
          { success: false, error: "Invalid action" },
          { status: 400 },
        );
    }

    // Log activation
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'ar_overlay_control',
        ${athlete_id || "system"},
        ${action},
        'manual_operator',
        ${JSON.stringify({ overlay_type, configuration, result })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      action,
      overlay_type,
      athlete_id,
      result,
      timestamp,
    });
  } catch (error) {
    console.error("Overlay control error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/ar/overlay-control/status
 * Get current overlay control status
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");

    // Get active overlays
    const activeOverlays = {
      stress: { enabled: true, auto_trigger: true, threshold: 0.7 },
      fatigue: { enabled: true, auto_trigger: true, threshold: 0.65 },
      recovery: { enabled: true, auto_trigger: false },
      power: { enabled: false, auto_trigger: false },
      injury_risk: { enabled: true, auto_trigger: true, threshold: 0.4 },
      nil_momentum: { enabled: true, auto_trigger: true },
      sponsor_activation: { enabled: true, auto_trigger: false },
    };

    // Get recent activations
    const recentActivations = await sql`
      SELECT * FROM audit_logs
      WHERE entity_type = 'ar_overlay_control'
        ${athlete_id ? sql`AND entity_id = ${athlete_id}` : sql``}
      ORDER BY created_at DESC
      LIMIT 50
    `;

    return Response.json({
      success: true,
      active_overlays: activeOverlays,
      recent_activations: recentActivations,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Overlay status check error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === OVERLAY CONTROL FUNCTIONS ===

async function triggerOverlay(athleteId, overlayType, config) {
  if (!athleteId) {
    throw new Error("athlete_id required for trigger action");
  }

  // Get athlete data
  const athletes = await sql`
    SELECT * FROM athletes WHERE id = ${athleteId}
  `;

  if (athletes.length === 0) {
    throw new Error("Athlete not found");
  }

  // Get recent biometric readings
  const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
  const readings = await sql`
    SELECT br.*, bid.domain, bid.cluster, bid.index_name
    FROM biometric_readings br
    JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
    WHERE br.athlete_id = ${athleteId}
      AND br.recorded_at > ${twoHoursAgo}
    ORDER BY br.recorded_at DESC
  `;

  // Generate overlay with configuration
  const overlay = generateConfiguredOverlay(overlayType, readings, config);

  return {
    status: "triggered",
    athlete_id: athleteId,
    overlay_type: overlayType,
    overlay_data: overlay,
    configuration: config,
  };
}

async function enableAutoTrigger(overlayType, config) {
  return {
    status: "enabled",
    overlay_type: overlayType,
    auto_trigger: true,
    threshold: config.threshold || getDefaultThreshold(overlayType),
    false_positive_protection: config.false_positive_protection !== false,
    narrative_alignment: config.narrative_alignment !== false,
  };
}

async function disableAutoTrigger(overlayType) {
  return {
    status: "disabled",
    overlay_type: overlayType,
    auto_trigger: false,
    reason: "Manual override",
  };
}

async function configureOverlay(overlayType, config) {
  const validatedConfig = {
    depth: config.depth || 0, // z-index for overlay layering
    scale: config.scale || 1.0, // size multiplier
    anchor: config.anchor || "center", // 'center', 'top', 'bottom', 'dynamic'
    opacity: config.opacity || 0.7,
    animation_speed: config.animation_speed || 1.0,
    color_override: config.color_override || null,
    threshold: config.threshold || getDefaultThreshold(overlayType),
  };

  return {
    status: "configured",
    overlay_type: overlayType,
    configuration: validatedConfig,
  };
}

function generateConfiguredOverlay(overlayType, readings, config) {
  const baseOverlay = generateBaseOverlay(overlayType, readings);

  // Apply configuration
  return {
    ...baseOverlay,
    depth: config.depth || 0,
    scale: config.scale || 1.0,
    anchor: config.anchor || "center",
    opacity: config.opacity || 0.7,
    animation_speed: config.animation_speed || 1.0,
    color_override: config.color_override,
  };
}

function generateBaseOverlay(overlayType, readings) {
  const overlayGenerators = {
    stress: generateStressOverlay,
    fatigue: generateFatigueOverlay,
    recovery: generateRecoveryOverlay,
    power: generatePowerOverlay,
    injury_risk: generateInjuryRiskOverlay,
    nil_momentum: generateNILMomentumOverlay,
    sponsor_activation: generateSponsorOverlay,
  };

  const generator = overlayGenerators[overlayType];
  if (!generator) {
    throw new Error(`Unknown overlay type: ${overlayType}`);
  }

  return generator(readings);
}

function generateStressOverlay(readings) {
  const cortisol = readings.find((r) => r.index_code === "CLi");
  return {
    type: "stress",
    elements: [
      {
        type: "stress_cone",
        intensity: cortisol ? cortisol.score : 0.35,
        color: "#FF6B6B",
        position: { x: 0, y: 1.4, z: 0 },
      },
    ],
    metrics: {
      stress_level: cortisol ? cortisol.score : 0.35,
    },
  };
}

function generateFatigueOverlay(readings) {
  const fatigue = readings.find((r) => r.index_code === "FAi");
  return {
    type: "fatigue",
    elements: [
      {
        type: "gradient_halo",
        intensity: fatigue ? fatigue.score / 100 : 0.45,
        color_start: "#4CAF50",
        color_end: "#FF5252",
      },
    ],
    metrics: {
      fatigue_score: fatigue ? fatigue.score : 45,
    },
  };
}

function generateRecoveryOverlay(readings) {
  const recovery = readings.find((r) => r.index_code === "RRi");
  return {
    type: "recovery",
    elements: [
      {
        type: "concentric_ring",
        completion: recovery ? recovery.score / 100 : 0.72,
        color: "#4CAF50",
      },
    ],
    metrics: {
      recovery_score: recovery ? recovery.score : 72,
    },
  };
}

function generatePowerOverlay(readings) {
  return {
    type: "power",
    elements: [
      {
        type: "vector_arrow",
        magnitude: 0.85,
        color: "#FF6F00",
      },
    ],
    metrics: {
      peak_power: 1250,
    },
  };
}

function generateInjuryRiskOverlay(readings) {
  return {
    type: "injury_risk",
    elements: [
      {
        type: "body_risk_map",
        regions: [
          { region: "left_knee", risk_level: 0.42, color: "#FFA726" },
          { region: "right_ankle", risk_level: 0.28, color: "#FFB74D" },
        ],
      },
    ],
    metrics: {
      overall_injury_risk: 0.35,
    },
  };
}

function generateNILMomentumOverlay(readings) {
  return {
    type: "nil_momentum",
    elements: [
      {
        type: "momentum_arrow",
        intensity: 0.82,
        direction: "upward",
        color: "#FFD700",
      },
    ],
    metrics: {
      nil_momentum_score: 0.82,
      engagement_velocity: 0.15,
    },
  };
}

function generateSponsorOverlay(readings) {
  return {
    type: "sponsor_activation",
    elements: [
      {
        type: "sponsor_badge",
        logo_url: "/sponsors/default-logo.png",
        activation_text: "Powered by Sponsor",
        display_duration_ms: 5000,
      },
    ],
    metrics: {
      activation_readiness: 1.0,
    },
  };
}

function getDefaultThreshold(overlayType) {
  const thresholds = {
    stress: 0.7,
    fatigue: 0.65,
    recovery: 0.5,
    power: 0.8,
    injury_risk: 0.4,
    nil_momentum: 0.75,
    sponsor_activation: 0.9,
  };
  return thresholds[overlayType] || 0.7;
}
