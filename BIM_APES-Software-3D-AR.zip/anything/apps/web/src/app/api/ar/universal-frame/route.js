import sql from "@/app/api/utils/sql";

/**
 * POST /api/ar/universal-frame
 * Generates the complete Universal AR Frame with SSI, CIS, ARC, and Exit Score
 * This is the flagship BIM-APES AR overlay combining all trading and biometric intelligence
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      include_metrics = ["ssi", "cis", "arc", "exit_score", "all"],
      time_window_minutes = 60,
      output_format = "json",
    } = body;

    if (!athlete_id) {
      return Response.json(
        { error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Fetch athlete data
    const athleteResult = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteResult.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteResult[0];

    // Fetch latest biometric readings
    const timeWindowStart = new Date(
      Date.now() - time_window_minutes * 60 * 1000,
    ).toISOString();

    const readings = await sql`
      SELECT br.*, bid.domain, bid.cluster, bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > ${timeWindowStart}
      ORDER BY br.recorded_at DESC
    `;

    // Fetch latest NIL valuation
    const valuationResult = await sql`
      SELECT * FROM nil_valuations
      WHERE athlete_id = ${athlete_id}
      ORDER BY calculated_at DESC
      LIMIT 1
    `;

    const valuation = valuationResult.length > 0 ? valuationResult[0] : null;

    // Fetch active mispricing events
    const mispricingResult = await sql`
      SELECT * FROM mispricing_events
      WHERE athlete_id = ${athlete_id}
        AND status = 'active'
        AND expires_at > NOW()
      ORDER BY detected_at DESC
      LIMIT 5
    `;

    // Fetch active trading positions
    const positionsResult = await sql`
      SELECT * FROM trading_positions
      WHERE athlete_id = ${athlete_id}
        AND status = 'open'
      ORDER BY opened_at DESC
      LIMIT 10
    `;

    // Calculate SSI (Scalping Signal Index)
    const ssi = calculateSSI(readings, valuation, mispricingResult);

    // Calculate CIS (Convexity Index Score)
    const cis = calculateCIS(readings, valuation);

    // Calculate ARC (Arbitrage Readiness Coefficient)
    const arc = calculateARC(valuation, mispricingResult, readings);

    // Calculate Exit Score
    const exitScore = calculateExitScore(
      positionsResult,
      valuation,
      readings,
      mispricingResult,
    );

    // Build universal frame overlay
    const universalFrame = {
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        sport: athlete.sport,
        position: athlete.position,
        team: athlete.team,
        nil_tier: athlete.nil_tier,
      },
      timestamp: new Date().toISOString(),
      metrics: {
        ssi,
        cis,
        arc,
        exit_score: exitScore,
      },
      valuation: valuation
        ? {
            true_value: parseFloat(valuation.true_value),
            market_value: parseFloat(valuation.market_value),
            gap: parseFloat(valuation.gap),
            gap_percentage: parseFloat(valuation.gap_percentage),
            direction: valuation.direction,
            confidence: parseFloat(valuation.confidence),
            convexity_factor: parseFloat(valuation.convexity_factor),
            momentum_intensity: parseFloat(valuation.momentum_intensity),
          }
        : null,
      overlays: generateUniversalOverlays({
        ssi,
        cis,
        arc,
        exitScore,
        valuation,
        readings,
        mispricingEvents: mispricingResult,
        positions: positionsResult,
      }),
      metadata: {
        readings_count: readings.length,
        time_window_minutes,
        mispricing_events: mispricingResult.length,
        open_positions: positionsResult.length,
        generated_at: new Date().toISOString(),
      },
    };

    return Response.json({
      success: true,
      universal_frame: universalFrame,
    });
  } catch (error) {
    console.error("Universal frame generation error:", error);
    return Response.json(
      { error: "Failed to generate universal frame", details: error.message },
      { status: 500 },
    );
  }
}

// ================================================================================
// SSI (SCALPING SIGNAL INDEX) CALCULATION
// ================================================================================
function calculateSSI(readings, valuation, mispricingEvents) {
  // SSI measures short-term momentum burst potential
  // Components:
  // 1. Momentum intensity (from NIL valuation)
  // 2. Biometric volatility (rapid changes in performance)
  // 3. Scalping event presence
  // 4. Time decay (TTL urgency)

  let ssiScore = 0;
  let ssiSignal = "neutral";
  let ssiConfidence = 0;
  let components = {};

  // Component 1: Momentum intensity (0-40 points)
  const momentumIntensity = valuation
    ? parseFloat(valuation.momentum_intensity)
    : 0;
  const momentumComponent = momentumIntensity * 40;
  components.momentum = momentumComponent;

  // Component 2: Biometric volatility (0-30 points)
  const volatilityComponent = calculateBiometricVolatility(readings) * 30;
  components.volatility = volatilityComponent;

  // Component 3: Scalping event multiplier (0-20 points)
  const scalpingEvents = mispricingEvents.filter(
    (e) => e.event_type === "scalping",
  );
  const eventComponent =
    scalpingEvents.length > 0 ? Math.min(scalpingEvents.length * 10, 20) : 0;
  components.scalping_events = eventComponent;

  // Component 4: TTL urgency (0-10 points)
  const ttlUrgency =
    scalpingEvents.length > 0
      ? calculateTTLUrgency(scalpingEvents[0].ttl_seconds)
      : 0;
  components.ttl_urgency = ttlUrgency;

  // Total SSI score (0-100)
  ssiScore =
    momentumComponent + volatilityComponent + eventComponent + ttlUrgency;

  // Determine signal
  if (ssiScore >= 75) {
    ssiSignal = "strong_scalp";
    ssiConfidence = 0.85 + (ssiScore - 75) / 100;
  } else if (ssiScore >= 50) {
    ssiSignal = "scalp_ready";
    ssiConfidence = 0.6 + (ssiScore - 50) / 100;
  } else if (ssiScore >= 30) {
    ssiSignal = "weak_scalp";
    ssiConfidence = 0.3 + (ssiScore - 30) / 100;
  } else {
    ssiSignal = "no_scalp";
    ssiConfidence = ssiScore / 100;
  }

  return {
    score: parseFloat(ssiScore.toFixed(2)),
    signal: ssiSignal,
    confidence: parseFloat(ssiConfidence.toFixed(3)),
    components,
    interpretation:
      ssiScore >= 75
        ? "Immediate scalp opportunity detected"
        : ssiScore >= 50
          ? "Scalping window active, monitor closely"
          : ssiScore >= 30
            ? "Weak scalping signal, wait for confirmation"
            : "No scalping opportunity",
    recommended_action:
      ssiScore >= 75
        ? "Enter scalp position immediately"
        : ssiScore >= 50
          ? "Prepare for scalp entry"
          : "Wait",
  };
}

// ================================================================================
// CIS (CONVEXITY INDEX SCORE) CALCULATION
// ================================================================================
function calculateCIS(readings, valuation) {
  // CIS measures non-linear upside capture potential
  // Components:
  // 1. Convexity factor (from NIL valuation)
  // 2. Performance acceleration (biometric improvement rate)
  // 3. Upside asymmetry (gap direction and magnitude)
  // 4. Sponsor activation potential

  let cisScore = 0;
  let cisSignal = "neutral";
  let components = {};

  // Component 1: Convexity factor (0-40 points)
  const convexityFactor = valuation
    ? parseFloat(valuation.convexity_factor)
    : 0;
  const convexityComponent = convexityFactor * 40;
  components.convexity_factor = convexityComponent;

  // Component 2: Performance acceleration (0-30 points)
  const accelerationComponent = calculatePerformanceAcceleration(readings) * 30;
  components.acceleration = accelerationComponent;

  // Component 3: Upside asymmetry (0-20 points)
  const asymmetryComponent = valuation
    ? calculateUpsideAsymmetry(
        parseFloat(valuation.gap_percentage),
        valuation.direction,
      )
    : 0;
  components.asymmetry = asymmetryComponent;

  // Component 4: Sponsor activation potential (0-10 points)
  const sponsorComponent = calculateSponsorActivationPotential(readings);
  components.sponsor_potential = sponsorComponent;

  // Total CIS score (0-100)
  cisScore =
    convexityComponent +
    accelerationComponent +
    asymmetryComponent +
    sponsorComponent;

  // Determine signal
  if (cisScore >= 80) {
    cisSignal = "high_convexity";
  } else if (cisScore >= 60) {
    cisSignal = "moderate_convexity";
  } else if (cisScore >= 40) {
    cisSignal = "low_convexity";
  } else {
    cisSignal = "linear";
  }

  return {
    score: parseFloat(cisScore.toFixed(2)),
    signal: cisSignal,
    components,
    convexity_factor: convexityFactor,
    interpretation:
      cisScore >= 80
        ? "Exceptional convex upside potential"
        : cisScore >= 60
          ? "Moderate convex upside available"
          : cisScore >= 40
            ? "Limited convexity, mostly linear"
            : "Linear payoff structure",
    recommended_action:
      cisScore >= 80
        ? "Maximize position size for convex capture"
        : cisScore >= 60
          ? "Allocate moderate capital"
          : "Standard position sizing",
  };
}

// ================================================================================
// ARC (ARBITRAGE READINESS COEFFICIENT) CALCULATION
// ================================================================================
function calculateARC(valuation, mispricingEvents, readings) {
  // ARC measures spread exploitation readiness
  // Components:
  // 1. Spread magnitude (gap size)
  // 2. Spread stability (confidence in gap)
  // 3. Expected close time (liquidity / TTL)
  // 4. Arbitrage event presence

  let arcScore = 0;
  let arcSignal = "neutral";
  let components = {};

  // Component 1: Spread magnitude (0-40 points)
  const gapPercentage = valuation
    ? Math.abs(parseFloat(valuation.gap_percentage))
    : 0;
  const spreadComponent = Math.min((gapPercentage / 20) * 40, 40);
  components.spread_magnitude = spreadComponent;

  // Component 2: Spread stability (0-30 points)
  const confidence = valuation ? parseFloat(valuation.confidence) : 0;
  const stabilityComponent = confidence * 30;
  components.spread_stability = stabilityComponent;

  // Component 3: Expected close time (0-20 points)
  const expectedCloseSeconds = valuation
    ? valuation.expected_close_seconds || 1800
    : 1800;
  const timeComponent = calculateCloseTimeScore(expectedCloseSeconds);
  components.close_time = timeComponent;

  // Component 4: Arbitrage event presence (0-10 points)
  const arbEvents = mispricingEvents.filter(
    (e) => e.event_type === "arbitrage",
  );
  const eventComponent = arbEvents.length > 0 ? 10 : 0;
  components.arb_events = eventComponent;

  // Total ARC score (0-100)
  arcScore =
    spreadComponent + stabilityComponent + timeComponent + eventComponent;

  // Determine signal
  if (arcScore >= 75) {
    arcSignal = "strong_arb";
  } else if (arcScore >= 50) {
    arcSignal = "arb_ready";
  } else if (arcScore >= 30) {
    arcSignal = "weak_arb";
  } else {
    arcSignal = "no_arb";
  }

  return {
    score: parseFloat(arcScore.toFixed(2)),
    signal: arcSignal,
    components,
    spread_percentage: gapPercentage,
    confidence,
    expected_close_minutes: Math.round(expectedCloseSeconds / 60),
    interpretation:
      arcScore >= 75
        ? "Prime arbitrage window open"
        : arcScore >= 50
          ? "Arbitrage opportunity available"
          : arcScore >= 30
            ? "Marginal arbitrage spread"
            : "No arbitrage opportunity",
    recommended_action:
      arcScore >= 75
        ? "Execute arbitrage immediately"
        : arcScore >= 50
          ? "Consider arbitrage entry"
          : "Wait for better spread",
  };
}

// ================================================================================
// EXIT SCORE CALCULATION
// ================================================================================
function calculateExitScore(positions, valuation, readings, mispricingEvents) {
  // Exit Score determines optimal position exit timing
  // Components:
  // 1. Position P&L status
  // 2. Spread closing velocity
  // 3. Biometric fatigue indicators
  // 4. TTL expiration proximity

  if (positions.length === 0) {
    return {
      score: 0,
      signal: "no_positions",
      components: {},
      interpretation: "No open positions",
      recommended_action: "N/A",
    };
  }

  let exitScore = 0;
  let exitSignal = "hold";
  let components = {};

  // Component 1: P&L status (0-40 points)
  const plComponent = calculatePLComponent(positions);
  components.pl_status = plComponent;

  // Component 2: Spread closing velocity (0-30 points)
  const closingComponent = valuation
    ? calculateSpreadClosingVelocity(
        parseFloat(valuation.gap),
        parseFloat(valuation.gap_percentage),
      )
    : 0;
  components.closing_velocity = closingComponent;

  // Component 3: Biometric fatigue (0-20 points)
  const fatigueComponent = calculateFatigueExitPressure(readings);
  components.fatigue_pressure = fatigueComponent;

  // Component 4: TTL expiration proximity (0-10 points)
  const ttlComponent =
    mispricingEvents.length > 0
      ? calculateTTLExitPressure(mispricingEvents[0].ttl_seconds)
      : 0;
  components.ttl_pressure = ttlComponent;

  // Total Exit Score (0-100)
  exitScore = plComponent + closingComponent + fatigueComponent + ttlComponent;

  // Determine signal
  if (exitScore >= 75) {
    exitSignal = "exit_now";
  } else if (exitScore >= 50) {
    exitSignal = "prepare_exit";
  } else if (exitScore >= 30) {
    exitSignal = "monitor";
  } else {
    exitSignal = "hold";
  }

  return {
    score: parseFloat(exitScore.toFixed(2)),
    signal: exitSignal,
    components,
    open_positions: positions.length,
    interpretation:
      exitScore >= 75
        ? "Exit positions immediately"
        : exitScore >= 50
          ? "Prepare to exit, conditions deteriorating"
          : exitScore >= 30
            ? "Monitor closely, no immediate exit needed"
            : "Hold positions, conditions stable",
    recommended_action:
      exitScore >= 75
        ? "Close all positions"
        : exitScore >= 50
          ? "Tighten stops, prepare exit"
          : "Continue holding",
  };
}

// ================================================================================
// OVERLAY GENERATION
// ================================================================================
function generateUniversalOverlays({
  ssi,
  cis,
  arc,
  exitScore,
  valuation,
  readings,
  mispricingEvents,
  positions,
}) {
  const overlays = [];

  // SSI Overlay (Top Left)
  overlays.push({
    id: "ssi_indicator",
    type: "metric_card",
    position: { x: 0.05, y: 0.05 },
    metric: {
      label: "SSI",
      value: ssi.score,
      signal: ssi.signal,
      color: "#FF6F00",
      trend: ssi.signal === "strong_scalp" ? "up" : "flat",
    },
    visual: {
      glow: ssi.score >= 75,
      pulse_rate: ssi.score >= 75 ? 1.5 : 0,
    },
  });

  // CIS Overlay (Top Right)
  overlays.push({
    id: "cis_indicator",
    type: "metric_card",
    position: { x: 0.85, y: 0.05 },
    metric: {
      label: "CIS",
      value: cis.score,
      signal: cis.signal,
      color: "#C8A882",
      convexity_factor: cis.convexity_factor,
    },
    visual: {
      halo: cis.score >= 80,
      halo_color: "#FFD700",
    },
  });

  // ARC Overlay (Bottom Left)
  overlays.push({
    id: "arc_indicator",
    type: "metric_card",
    position: { x: 0.05, y: 0.85 },
    metric: {
      label: "ARC",
      value: arc.score,
      signal: arc.signal,
      color: "#2196F3",
      spread_percentage: arc.spread_percentage,
    },
    visual: {
      border_pulse: arc.score >= 75,
    },
  });

  // Exit Score Overlay (Bottom Right)
  overlays.push({
    id: "exit_score_indicator",
    type: "metric_card",
    position: { x: 0.85, y: 0.85 },
    metric: {
      label: "Exit",
      value: exitScore.score,
      signal: exitScore.signal,
      color: "#F44336",
      positions_count: positions.length,
    },
    visual: {
      alert: exitScore.score >= 75,
      warning: exitScore.score >= 50,
    },
  });

  // Value Bar (Center Top)
  if (valuation) {
    overlays.push({
      id: "value_bar",
      type: "value_comparison",
      position: { x: 0.5, y: 0.1 },
      data: {
        true_value: parseFloat(valuation.true_value),
        market_value: parseFloat(valuation.market_value),
        gap: parseFloat(valuation.gap),
        direction: valuation.direction,
      },
      visual: {
        bar_width: 0.4,
        color_gradient: true,
      },
    });
  }

  // Spread Ring (Center)
  if (valuation && Math.abs(parseFloat(valuation.gap_percentage)) > 5) {
    overlays.push({
      id: "spread_ring",
      type: "concentric_ring",
      position: { x: 0.5, y: 0.5 },
      data: {
        gap_percentage: Math.abs(parseFloat(valuation.gap_percentage)),
        direction: valuation.direction,
      },
      visual: {
        radius: 0.2,
        thickness: Math.min(
          Math.abs(parseFloat(valuation.gap_percentage)) / 100,
          0.05,
        ),
        color: valuation.direction === "long" ? "#4CAF50" : "#FF9800",
        pulse: true,
      },
    });
  }

  // Convexity Halo (Center, if CIS > 80)
  if (cis.score >= 80) {
    overlays.push({
      id: "convexity_halo",
      type: "radial_glow",
      position: { x: 0.5, y: 0.5 },
      visual: {
        radius: 0.35,
        color: "#FFD700",
        intensity: (cis.score - 80) / 20,
        pulse_rate: 0.8,
      },
    });
  }

  // Momentum Vector (if momentum_intensity > 0.7)
  if (valuation && parseFloat(valuation.momentum_intensity) > 0.7) {
    overlays.push({
      id: "momentum_vector",
      type: "directional_arrow",
      position: { x: 0.5, y: 0.65 },
      data: {
        direction: valuation.direction === "long" ? "up" : "down",
        intensity: parseFloat(valuation.momentum_intensity),
      },
      visual: {
        size: 0.1,
        color: "#9C27B0",
        animation: "surge",
      },
    });
  }

  // Mispricing Alerts (if active events)
  if (mispricingEvents.length > 0) {
    overlays.push({
      id: "mispricing_alerts",
      type: "alert_banner",
      position: { x: 0.5, y: 0.15 },
      data: {
        events: mispricingEvents.slice(0, 3).map((e) => ({
          type: e.event_type,
          gap: parseFloat(e.gap),
          ttl_seconds: e.ttl_seconds,
        })),
      },
      visual: {
        border_color: "#C8A882",
        glow: true,
      },
    });
  }

  return overlays;
}

// ================================================================================
// HELPER FUNCTIONS
// ================================================================================
function calculateBiometricVolatility(readings) {
  // Measures rapid changes in key biometric indices
  if (readings.length < 2) return 0;

  const powerReadings = readings.filter((r) => r.index_code === "PWRi");
  const speedReadings = readings.filter((r) => r.index_code === "SPDi");

  let volatility = 0;
  let count = 0;

  if (powerReadings.length >= 2) {
    const powerChange = Math.abs(
      parseFloat(powerReadings[0].score) - parseFloat(powerReadings[1].score),
    );
    volatility += powerChange / 100;
    count++;
  }

  if (speedReadings.length >= 2) {
    const speedChange = Math.abs(
      parseFloat(speedReadings[0].score) - parseFloat(speedReadings[1].score),
    );
    volatility += speedChange / 100;
    count++;
  }

  return count > 0 ? volatility / count : 0;
}

function calculateTTLUrgency(ttlSeconds) {
  // Converts TTL to urgency score (0-10)
  // < 5 min = 10 points, 5-10 min = 7 points, 10-30 min = 4 points, > 30 min = 1 point
  if (ttlSeconds < 300) return 10;
  if (ttlSeconds < 600) return 7;
  if (ttlSeconds < 1800) return 4;
  return 1;
}

function calculatePerformanceAcceleration(readings) {
  // Measures rate of improvement across biometric indices
  if (readings.length < 3) return 0;

  const trendingUp = readings.filter((r) => r.trend === "improving").length;
  return Math.min(trendingUp / readings.length, 1);
}

function calculateUpsideAsymmetry(gapPercentage, direction) {
  // Scores asymmetric upside potential
  const absGap = Math.abs(gapPercentage);

  if (direction === "long" && gapPercentage > 0) {
    return Math.min((absGap / 20) * 20, 20);
  } else if (direction === "short" && gapPercentage < 0) {
    return Math.min((absGap / 20) * 20, 20);
  }

  return 0;
}

function calculateSponsorActivationPotential(readings) {
  // Estimates sponsor activation likelihood based on performance
  const powerReading = readings.find((r) => r.index_code === "PWRi");
  const speedReading = readings.find((r) => r.index_code === "SPDi");

  let potential = 0;

  if (powerReading && parseFloat(powerReading.score) > 85) potential += 5;
  if (speedReading && parseFloat(speedReading.score) > 85) potential += 5;

  return potential;
}

function calculateCloseTimeScore(expectedCloseSeconds) {
  // Faster close = higher score
  // < 30 min = 20 points, 30-60 min = 15 points, 1-2 hr = 10 points, > 2 hr = 5 points
  if (expectedCloseSeconds < 1800) return 20;
  if (expectedCloseSeconds < 3600) return 15;
  if (expectedCloseSeconds < 7200) return 10;
  return 5;
}

function calculatePLComponent(positions) {
  // Scores based on position profitability
  let avgPL = 0;
  let count = 0;

  positions.forEach((p) => {
    if (p.pnl !== null) {
      avgPL += parseFloat(p.pnl);
      count++;
    }
  });

  if (count === 0) return 20; // Neutral if no P&L data

  avgPL = avgPL / count;

  // Positive P&L = lower exit pressure (0-20 points)
  // Negative P&L = higher exit pressure (20-40 points)
  if (avgPL > 0) {
    return Math.max(0, 20 - avgPL * 2);
  } else {
    return Math.min(40, 20 + Math.abs(avgPL) * 2);
  }
}

function calculateSpreadClosingVelocity(gap, gapPercentage) {
  // Estimates how fast the spread is closing
  // Rapid close = high exit pressure
  const absGap = Math.abs(gap);
  const absGapPct = Math.abs(gapPercentage);

  if (absGapPct < 2) return 30; // Spread nearly closed
  if (absGapPct < 5) return 20; // Spread closing
  if (absGapPct < 10) return 10; // Spread stable
  return 0; // Spread wide
}

function calculateFatigueExitPressure(readings) {
  // High fatigue = higher exit pressure
  const fatigueReading = readings.find((r) => r.index_code === "FAi");

  if (!fatigueReading) return 5; // Default moderate pressure

  const fatigueScore = parseFloat(fatigueReading.score);

  if (fatigueScore > 75) return 20;
  if (fatigueScore > 60) return 15;
  if (fatigueScore > 40) return 10;
  return 5;
}

function calculateTTLExitPressure(ttlSeconds) {
  // TTL approaching expiration = higher exit pressure
  if (ttlSeconds < 300) return 10; // < 5 min
  if (ttlSeconds < 600) return 7; // < 10 min
  if (ttlSeconds < 1800) return 4; // < 30 min
  return 1;
}
