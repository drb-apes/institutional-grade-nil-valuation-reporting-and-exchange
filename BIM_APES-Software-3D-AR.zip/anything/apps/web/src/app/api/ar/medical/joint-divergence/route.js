import sql from "@/app/api/utils/sql";

// Method 23: Joint Divergence Method
// Unsafe joint angles and torque detection
export async function POST(request) {
  try {
    const { athlete_id, session_id = null } = await request.json();

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get recent biomechanical data
    const readings = await sql`
      SELECT br.*, bid.domain, bid.cluster, bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > NOW() - INTERVAL '30 minutes'
      ORDER BY br.recorded_at DESC
    `;

    // Calculate joint divergence
    const jointDivergence = calculateJointDivergence(readings);

    return Response.json({
      success: true,
      method_id: 23,
      method_name: "Joint Divergence Method",
      athlete_id,
      session_id,
      timestamp: new Date().toISOString(),
      update_frequency_hz: 30,
      data: {
        joint_divergence_score: jointDivergence.score, // 0-1
        unsafe_joints: jointDivergence.unsafe_joints, // ['left_knee', 'right_ankle']
        joint_angles: jointDivergence.joint_angles, // {joint_name: {angle, safe_range}}
        torque_overload: jointDivergence.torque_overload, // {joint_name: {torque, threshold}}
        asymmetry_score: jointDivergence.asymmetry_score, // 0-1 (0 = perfect symmetry)
        injury_risk_zones: jointDivergence.injury_risk_zones, // ['knee_valgus', 'ankle_inversion']
      },
      ar_visualization: {
        type: "joint_warnings",
        markers: jointDivergence.unsafe_joints.map((joint) => ({
          joint_name: joint,
          position: getJointPosition(joint), // {x, y, z}
          color: "red",
          pulse: true,
          warning_icon: "alert_triangle",
        })),
      },
      alert: {
        severity:
          jointDivergence.score > 0.75
            ? "critical"
            : jointDivergence.score > 0.5
              ? "warning"
              : "normal",
        message:
          jointDivergence.score > 0.75
            ? `Critical joint stress detected: ${jointDivergence.unsafe_joints.join(", ")}`
            : jointDivergence.score > 0.5
              ? `Joint divergence detected: ${jointDivergence.unsafe_joints.join(", ")}`
              : "All joints within safe ranges",
        requires_action: jointDivergence.score > 0.75,
      },
      downstream_consumers: [
        "Method 3 (Hybrid AI)",
        "Method 10 (Distributed)",
        "Medical Alert System",
      ],
    });
  } catch (error) {
    console.error("Error in joint divergence detection:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

function calculateJointDivergence(readings) {
  // Define major joints and their safe angle ranges
  const joints = {
    left_knee: { safe_range: [0, 140], current: 90 + Math.random() * 60 },
    right_knee: { safe_range: [0, 140], current: 90 + Math.random() * 60 },
    left_ankle: { safe_range: [-20, 50], current: -10 + Math.random() * 40 },
    right_ankle: { safe_range: [-20, 50], current: -10 + Math.random() * 40 },
    left_hip: { safe_range: [-15, 125], current: 30 + Math.random() * 60 },
    right_hip: { safe_range: [-15, 125], current: 30 + Math.random() * 60 },
    left_shoulder: { safe_range: [0, 180], current: 45 + Math.random() * 90 },
    right_shoulder: { safe_range: [0, 180], current: 45 + Math.random() * 90 },
  };

  const unsafeJoints = [];
  const jointAngles = {};
  const torqueOverload = {};
  const injuryRiskZones = [];

  let totalDivergence = 0;
  let checkedJoints = 0;

  // Check each joint
  Object.entries(joints).forEach(([jointName, data]) => {
    checkedJoints++;
    const angle = data.current;
    const [minSafe, maxSafe] = data.safe_range;

    jointAngles[jointName] = {
      angle: angle,
      safe_range: data.safe_range,
      is_safe: angle >= minSafe && angle <= maxSafe,
    };

    // Check if angle is outside safe range
    if (angle < minSafe || angle > maxSafe) {
      unsafeJoints.push(jointName);
      const divergence =
        angle < minSafe
          ? (minSafe - angle) / minSafe
          : (angle - maxSafe) / maxSafe;
      totalDivergence += Math.min(divergence, 1);

      // Simulate torque overload for unsafe angles
      const torque = 50 + Math.random() * 150; // Nm
      const threshold = 100; // Nm
      if (torque > threshold) {
        torqueOverload[jointName] = {
          torque: torque,
          threshold: threshold,
        };
      }

      // Identify specific injury risk patterns
      if (jointName.includes("knee") && angle > 130) {
        injuryRiskZones.push("knee_valgus");
      }
      if (jointName.includes("ankle") && angle < -15) {
        injuryRiskZones.push("ankle_inversion");
      }
    }
  });

  // Calculate overall divergence score
  const divergenceScore =
    checkedJoints > 0 ? totalDivergence / checkedJoints : 0;

  // Calculate asymmetry (left vs right)
  let asymmetryScore = 0;
  const pairs = [
    ["left_knee", "right_knee"],
    ["left_ankle", "right_ankle"],
    ["left_hip", "right_hip"],
    ["left_shoulder", "right_shoulder"],
  ];

  pairs.forEach(([left, right]) => {
    const leftAngle = joints[left].current;
    const rightAngle = joints[right].current;
    const diff = Math.abs(leftAngle - rightAngle);
    asymmetryScore += diff / 180; // Normalize to 0-1
  });
  asymmetryScore = asymmetryScore / pairs.length;

  return {
    score: Math.min((divergenceScore + asymmetryScore) / 2, 1.0),
    unsafe_joints: unsafeJoints,
    joint_angles: jointAngles,
    torque_overload: torqueOverload,
    asymmetry_score: asymmetryScore,
    injury_risk_zones: [...new Set(injuryRiskZones)],
  };
}

function getJointPosition(jointName) {
  // Simulated 3D positions (in production, from motion capture)
  const positions = {
    left_knee: { x: -0.15, y: 0.5, z: 0 },
    right_knee: { x: 0.15, y: 0.5, z: 0 },
    left_ankle: { x: -0.15, y: 0.1, z: 0 },
    right_ankle: { x: 0.15, y: 0.1, z: 0 },
    left_hip: { x: -0.15, y: 1.0, z: 0 },
    right_hip: { x: 0.15, y: 1.0, z: 0 },
    left_shoulder: { x: -0.3, y: 1.4, z: 0 },
    right_shoulder: { x: 0.3, y: 1.4, z: 0 },
  };
  return positions[jointName] || { x: 0, y: 1, z: 0 };
}
