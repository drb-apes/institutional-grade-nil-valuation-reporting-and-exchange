/**
 * BIM-APES API Error Standardization
 * Provides consistent error responses across all API endpoints
 */

/**
 * Standard error response structure
 * @typedef {Object} ErrorResponse
 * @property {boolean} success - Always false for errors
 * @property {string} error - Error type/category
 * @property {string} message - Human-readable error message
 * @property {Object} [details] - Additional error context
 * @property {number} timestamp - Error timestamp
 */

/**
 * Error types for consistent categorization
 */
export const ErrorTypes = {
  VALIDATION_ERROR: "VALIDATION_ERROR",
  NOT_FOUND: "NOT_FOUND",
  UNAUTHORIZED: "UNAUTHORIZED",
  FORBIDDEN: "FORBIDDEN",
  DATABASE_ERROR: "DATABASE_ERROR",
  EXTERNAL_API_ERROR: "EXTERNAL_API_ERROR",
  INTERNAL_ERROR: "INTERNAL_ERROR",
  RATE_LIMIT_EXCEEDED: "RATE_LIMIT_EXCEEDED",
  INVALID_REQUEST: "INVALID_REQUEST",
};

/**
 * HTTP status codes for each error type
 */
const StatusCodes = {
  [ErrorTypes.VALIDATION_ERROR]: 400,
  [ErrorTypes.NOT_FOUND]: 404,
  [ErrorTypes.UNAUTHORIZED]: 401,
  [ErrorTypes.FORBIDDEN]: 403,
  [ErrorTypes.DATABASE_ERROR]: 500,
  [ErrorTypes.EXTERNAL_API_ERROR]: 502,
  [ErrorTypes.INTERNAL_ERROR]: 500,
  [ErrorTypes.RATE_LIMIT_EXCEEDED]: 429,
  [ErrorTypes.INVALID_REQUEST]: 400,
};

/**
 * Creates a standardized error response
 * @param {string} errorType - Error type from ErrorTypes
 * @param {string} message - Human-readable error message
 * @param {Object} [details] - Additional error context
 * @returns {Response} JSON response with standard error format
 */
export function createErrorResponse(errorType, message, details = null) {
  const statusCode = StatusCodes[errorType] || 500;

  const errorResponse = {
    success: false,
    error: errorType,
    message,
    timestamp: new Date().toISOString(),
  };

  // Only include details if provided
  if (details) {
    errorResponse.details = details;
  }

  return Response.json(errorResponse, { status: statusCode });
}

/**
 * Handles validation errors
 * @param {string} message - Validation error message
 * @param {Object} [fields] - Field-specific validation errors
 * @returns {Response} Validation error response
 */
export function validationError(message, fields = null) {
  return createErrorResponse(
    ErrorTypes.VALIDATION_ERROR,
    message,
    fields ? { fields } : null,
  );
}

/**
 * Handles not found errors
 * @param {string} resource - Resource type that wasn't found
 * @param {string} [identifier] - Resource identifier
 * @returns {Response} Not found error response
 */
export function notFoundError(resource, identifier = null) {
  const message = identifier
    ? `${resource} with identifier '${identifier}' not found`
    : `${resource} not found`;

  return createErrorResponse(ErrorTypes.NOT_FOUND, message);
}

/**
 * Handles database errors
 * @param {Error} error - Original database error
 * @param {string} [context] - Operation context
 * @returns {Response} Database error response
 */
export function databaseError(error, context = null) {
  console.error("Database error:", error);

  const message = context
    ? `Database error during ${context}`
    : "A database error occurred";

  return createErrorResponse(
    ErrorTypes.DATABASE_ERROR,
    message,
    process.env.NODE_ENV === "development"
      ? { originalError: error.message }
      : null,
  );
}

/**
 * Handles unauthorized access
 * @param {string} [message] - Custom unauthorized message
 * @returns {Response} Unauthorized error response
 */
export function unauthorizedError(message = "Authentication required") {
  return createErrorResponse(ErrorTypes.UNAUTHORIZED, message);
}

/**
 * Handles forbidden access
 * @param {string} [message] - Custom forbidden message
 * @returns {Response} Forbidden error response
 */
export function forbiddenError(message = "Access forbidden") {
  return createErrorResponse(ErrorTypes.FORBIDDEN, message);
}

/**
 * Handles external API errors
 * @param {string} service - External service name
 * @param {Error} [error] - Original error
 * @returns {Response} External API error response
 */
export function externalApiError(service, error = null) {
  console.error(`External API error (${service}):`, error);

  return createErrorResponse(
    ErrorTypes.EXTERNAL_API_ERROR,
    `Error communicating with ${service}`,
    process.env.NODE_ENV === "development" && error
      ? { originalError: error.message }
      : null,
  );
}

/**
 * Handles internal server errors
 * @param {Error} error - Original error
 * @param {string} [context] - Operation context
 * @returns {Response} Internal server error response
 */
export function internalError(error, context = null) {
  console.error("Internal error:", error);

  const message = context
    ? `Internal error during ${context}`
    : "An internal server error occurred";

  return createErrorResponse(
    ErrorTypes.INTERNAL_ERROR,
    message,
    process.env.NODE_ENV === "development"
      ? { originalError: error.message, stack: error.stack }
      : null,
  );
}

/**
 * Wraps an async API handler with error handling
 * @param {Function} handler - Async handler function
 * @returns {Function} Wrapped handler with error handling
 */
export function withErrorHandling(handler) {
  return async (request, context) => {
    try {
      return await handler(request, context);
    } catch (error) {
      // Check if it's already a Response (error already handled)
      if (error instanceof Response) {
        return error;
      }

      // Handle unexpected errors
      return internalError(error, "request processing");
    }
  };
}

/**
 * Creates a success response
 * @param {Object} data - Response data
 * @param {string} [message] - Optional success message
 * @returns {Response} Success response
 */
export function successResponse(data, message = null) {
  const response = {
    success: true,
    ...data,
  };

  if (message) {
    response.message = message;
  }

  return Response.json(response);
}
