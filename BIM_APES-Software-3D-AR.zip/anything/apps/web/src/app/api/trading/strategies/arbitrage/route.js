import sql from "@/app/api/utils/sql";

/**
 * POST /api/trading/strategies/arbitrage
 * Detects and executes arbitrage opportunities across athlete NIL spreads
 * Based on PhysioBioFin arbitrage logic
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      min_spread_percentage = 5,
      max_spread_percentage = 50,
      min_confidence = 0.7,
      athlete_ids = null,
      auto_execute = false,
      position_size_default = 1000,
    } = body;

    // Find arbitrage opportunities
    const opportunities = await detectArbitrageOpportunities({
      min_spread_percentage,
      max_spread_percentage,
      min_confidence,
      athlete_ids,
    });

    const results = {
      success: true,
      timestamp: new Date().toISOString(),
      opportunities_found: opportunities.length,
      opportunities,
      executed_positions: [],
    };

    // Auto-execute if requested
    if (auto_execute && opportunities.length > 0) {
      for (const opp of opportunities.slice(0, 5)) {
        // Limit to top 5
        const position = await executeArbitragePosition({
          athlete_id: opp.athlete_id,
          mispricing_event_id: opp.mispricing_event_id,
          direction: opp.direction,
          entry_price: opp.entry_price,
          expected_exit: opp.expected_exit,
          size: position_size_default,
          spread_percentage: opp.spread_percentage,
        });

        results.executed_positions.push(position);
      }
    }

    return Response.json(results);
  } catch (error) {
    console.error("Arbitrage strategy error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/trading/strategies/arbitrage
 * List active arbitrage positions
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "open";
    const athlete_id = searchParams.get("athlete_id");

    let query = sql`
      SELECT 
        tp.*,
        a.first_name,
        a.last_name,
        a.sport,
        me.gap,
        me.confidence
      FROM trading_positions tp
      JOIN athletes a ON tp.athlete_id = a.id
      LEFT JOIN mispricing_events me ON tp.mispricing_event_id = me.id
      WHERE tp.strategy = 'arbitrage'
        AND tp.status = ${status}
    `;

    if (athlete_id) {
      query = sql`
        SELECT 
          tp.*,
          a.first_name,
          a.last_name,
          a.sport,
          me.gap,
          me.confidence
        FROM trading_positions tp
        JOIN athletes a ON tp.athlete_id = a.id
        LEFT JOIN mispricing_events me ON tp.mispricing_event_id = me.id
        WHERE tp.strategy = 'arbitrage'
          AND tp.status = ${status}
          AND tp.athlete_id = ${athlete_id}
      `;
    }

    const positions = await query;

    return Response.json({
      success: true,
      count: positions.length,
      positions,
    });
  } catch (error) {
    console.error("Arbitrage list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HELPER FUNCTIONS ===

async function detectArbitrageOpportunities(params) {
  const {
    min_spread_percentage,
    max_spread_percentage,
    min_confidence,
    athlete_ids,
  } = params;

  let query;

  if (athlete_ids && athlete_ids.length > 0) {
    query = sql`
      SELECT 
        nv.*,
        a.first_name,
        a.last_name,
        a.sport,
        a.nil_tier,
        me.id as mispricing_event_id,
        me.event_type,
        me.ttl_seconds
      FROM nil_valuations nv
      JOIN athletes a ON nv.athlete_id = a.id
      LEFT JOIN mispricing_events me ON me.athlete_id = nv.athlete_id 
        AND me.status = 'active'
        AND me.expires_at > NOW()
      WHERE a.consent_trading = true
        AND ABS(nv.gap_percentage) >= ${min_spread_percentage}
        AND ABS(nv.gap_percentage) <= ${max_spread_percentage}
        AND nv.confidence >= ${min_confidence}
        AND nv.calculated_at > NOW() - INTERVAL '1 hour'
        AND nv.athlete_id = ANY(${athlete_ids})
      ORDER BY ABS(nv.gap) DESC
      LIMIT 20
    `;
  } else {
    query = sql`
      SELECT 
        nv.*,
        a.first_name,
        a.last_name,
        a.sport,
        a.nil_tier,
        me.id as mispricing_event_id,
        me.event_type,
        me.ttl_seconds
      FROM nil_valuations nv
      JOIN athletes a ON nv.athlete_id = a.id
      LEFT JOIN mispricing_events me ON me.athlete_id = nv.athlete_id 
        AND me.status = 'active'
        AND me.expires_at > NOW()
      WHERE a.consent_trading = true
        AND ABS(nv.gap_percentage) >= ${min_spread_percentage}
        AND ABS(nv.gap_percentage) <= ${max_spread_percentage}
        AND nv.confidence >= ${min_confidence}
        AND nv.calculated_at > NOW() - INTERVAL '1 hour'
      ORDER BY ABS(nv.gap) DESC
      LIMIT 20
    `;
  }

  const valuations = await query;

  return valuations.map((v) => ({
    athlete_id: v.athlete_id,
    athlete_name: `${v.first_name} ${v.last_name}`,
    sport: v.sport,
    nil_tier: v.nil_tier,
    mispricing_event_id: v.mispricing_event_id,
    direction: v.direction,
    true_value: parseFloat(v.true_value),
    market_value: parseFloat(v.market_value),
    spread: parseFloat(v.gap),
    spread_percentage: parseFloat(v.gap_percentage),
    confidence: parseFloat(v.confidence),
    entry_price:
      v.direction === "long"
        ? parseFloat(v.market_value)
        : parseFloat(v.true_value),
    expected_exit:
      v.direction === "long"
        ? parseFloat(v.true_value)
        : parseFloat(v.market_value),
    expected_profit: Math.abs(parseFloat(v.gap)),
    ttl_seconds: v.ttl_seconds || v.expected_close_seconds,
    strategy_type: "spread_arbitrage",
  }));
}

async function executeArbitragePosition(params) {
  const {
    athlete_id,
    mispricing_event_id,
    direction,
    entry_price,
    expected_exit,
    size,
    spread_percentage,
  } = params;

  // Calculate stop loss and take profit
  const stop_loss =
    direction === "long"
      ? entry_price * 0.95 // 5% stop loss
      : entry_price * 1.05;

  const take_profit = expected_exit;

  // Insert trading position
  const positionRows = await sql`
    INSERT INTO trading_positions (
      athlete_id,
      mispricing_event_id,
      position_type,
      strategy,
      entry_price,
      size,
      stop_loss,
      take_profit,
      trailing_stop,
      status,
      opened_at
    ) VALUES (
      ${athlete_id},
      ${mispricing_event_id},
      ${direction},
      'arbitrage',
      ${entry_price},
      ${size},
      ${stop_loss},
      ${take_profit},
      false,
      'open',
      NOW()
    )
    RETURNING *
  `;

  const position = positionRows[0];

  // Audit log
  await sql`
    INSERT INTO audit_logs (
      entity_type,
      entity_id,
      action,
      actor,
      details
    ) VALUES (
      'trading_position',
      ${position.id},
      'open_arbitrage',
      'BIM-APES Trading Engine',
      ${JSON.stringify({
        athlete_id,
        direction,
        entry_price,
        size,
        spread_percentage,
      })}
    )
  `;

  return position;
}
