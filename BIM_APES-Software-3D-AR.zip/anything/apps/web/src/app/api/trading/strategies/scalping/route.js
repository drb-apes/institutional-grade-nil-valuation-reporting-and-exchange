import sql from "@/app/api/utils/sql";

/**
 * POST /api/trading/strategies/scalping
 * Executes momentum-based scalping strategies
 * Short-term trades based on performance volatility spikes
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      momentum_threshold = 0.7,
      min_gap_percentage = 3,
      max_holding_seconds = 300, // 5 minutes default
      athlete_ids = null,
      auto_execute = false,
      position_size_default = 500,
    } = body;

    // Detect scalping opportunities
    const opportunities = await detectScalpingOpportunities({
      momentum_threshold,
      min_gap_percentage,
      max_holding_seconds,
      athlete_ids,
    });

    const results = {
      success: true,
      timestamp: new Date().toISOString(),
      opportunities_found: opportunities.length,
      opportunities,
      executed_scalps: [],
    };

    // Auto-execute scalps
    if (auto_execute && opportunities.length > 0) {
      for (const opp of opportunities.slice(0, 3)) {
        // Limit to top 3 scalps
        const scalp = await executeScalpPosition({
          athlete_id: opp.athlete_id,
          mispricing_event_id: opp.mispricing_event_id,
          direction: opp.direction,
          entry_price: opp.entry_price,
          size: position_size_default,
          momentum_intensity: opp.momentum_intensity,
          max_holding_seconds,
        });

        results.executed_scalps.push(scalp);
      }
    }

    return Response.json(results);
  } catch (error) {
    console.error("Scalping strategy error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/trading/strategies/scalping
 * List active scalping positions
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "open";

    const positions = await sql`
      SELECT 
        tp.*,
        a.first_name,
        a.last_name,
        a.sport,
        me.momentum_intensity,
        EXTRACT(EPOCH FROM (NOW() - tp.opened_at)) as holding_seconds
      FROM trading_positions tp
      JOIN athletes a ON tp.athlete_id = a.id
      LEFT JOIN mispricing_events me ON tp.mispricing_event_id = me.id
      WHERE tp.strategy = 'scalping'
        AND tp.status = ${status}
      ORDER BY tp.opened_at DESC
      LIMIT 50
    `;

    return Response.json({
      success: true,
      count: positions.length,
      positions,
    });
  } catch (error) {
    console.error("Scalping list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * PATCH /api/trading/strategies/scalping
 * Close scalping positions (manual or automatic)
 */
export async function PATCH(request) {
  try {
    const body = await request.json();
    const { position_id, exit_price, reason = "manual_close" } = body;

    if (!position_id) {
      return Response.json(
        { success: false, error: "position_id is required" },
        { status: 400 },
      );
    }

    // Fetch position
    const positionRows = await sql`
      SELECT * FROM trading_positions
      WHERE id = ${position_id} AND status = 'open'
    `;

    if (positionRows.length === 0) {
      return Response.json(
        { success: false, error: "Position not found or already closed" },
        { status: 404 },
      );
    }

    const position = positionRows[0];

    // Calculate P&L
    const entry = parseFloat(position.entry_price);
    const exit = exit_price || entry * 1.02; // Default 2% gain
    const size = parseFloat(position.size);

    const pnl =
      position.position_type === "long"
        ? (exit - entry) * size
        : (entry - exit) * size;

    // Close position
    const closedRows = await sql`
      UPDATE trading_positions
      SET
        exit_price = ${exit},
        status = 'closed',
        pnl = ${pnl},
        closed_at = NOW()
      WHERE id = ${position_id}
      RETURNING *
    `;

    const closed = closedRows[0];

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'trading_position',
        ${position_id},
        'close_scalp',
        'BIM-APES Trading Engine',
        ${JSON.stringify({
          reason,
          entry_price: entry,
          exit_price: exit,
          pnl,
        })}
      )
    `;

    return Response.json({
      success: true,
      position: closed,
      pnl,
      pnl_percentage: ((exit - entry) / entry) * 100,
    });
  } catch (error) {
    console.error("Close scalp error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HELPER FUNCTIONS ===

async function detectScalpingOpportunities(params) {
  const {
    momentum_threshold,
    min_gap_percentage,
    max_holding_seconds,
    athlete_ids,
  } = params;

  let query;

  if (athlete_ids && athlete_ids.length > 0) {
    query = sql`
      SELECT 
        nv.*,
        a.first_name,
        a.last_name,
        a.sport,
        me.id as mispricing_event_id,
        me.momentum_intensity,
        me.ttl_seconds
      FROM nil_valuations nv
      JOIN athletes a ON nv.athlete_id = a.id
      LEFT JOIN mispricing_events me ON me.athlete_id = nv.athlete_id 
        AND me.status = 'active'
        AND me.event_type = 'scalping'
      WHERE a.consent_trading = true
        AND nv.momentum_intensity >= ${momentum_threshold}
        AND ABS(nv.gap_percentage) >= ${min_gap_percentage}
        AND nv.calculated_at > NOW() - INTERVAL '10 minutes'
        AND nv.athlete_id = ANY(${athlete_ids})
      ORDER BY nv.momentum_intensity DESC, ABS(nv.gap) DESC
      LIMIT 10
    `;
  } else {
    query = sql`
      SELECT 
        nv.*,
        a.first_name,
        a.last_name,
        a.sport,
        me.id as mispricing_event_id,
        me.momentum_intensity,
        me.ttl_seconds
      FROM nil_valuations nv
      JOIN athletes a ON nv.athlete_id = a.id
      LEFT JOIN mispricing_events me ON me.athlete_id = nv.athlete_id 
        AND me.status = 'active'
        AND me.event_type = 'scalping'
      WHERE a.consent_trading = true
        AND nv.momentum_intensity >= ${momentum_threshold}
        AND ABS(nv.gap_percentage) >= ${min_gap_percentage}
        AND nv.calculated_at > NOW() - INTERVAL '10 minutes'
      ORDER BY nv.momentum_intensity DESC, ABS(nv.gap) DESC
      LIMIT 10
    `;
  }

  const valuations = await query;

  return valuations.map((v) => ({
    athlete_id: v.athlete_id,
    athlete_name: `${v.first_name} ${v.last_name}`,
    sport: v.sport,
    mispricing_event_id: v.mispricing_event_id,
    direction: v.direction,
    entry_price: parseFloat(v.market_value),
    current_spread: parseFloat(v.gap),
    spread_percentage: parseFloat(v.gap_percentage),
    momentum_intensity: parseFloat(v.momentum_intensity),
    confidence: parseFloat(v.confidence),
    expected_close_seconds: v.ttl_seconds || v.expected_close_seconds,
    max_holding_seconds,
    strategy_type: "momentum_scalp",
  }));
}

async function executeScalpPosition(params) {
  const {
    athlete_id,
    mispricing_event_id,
    direction,
    entry_price,
    size,
    momentum_intensity,
    max_holding_seconds,
  } = params;

  // Tight stops for scalping
  const stop_loss =
    direction === "long"
      ? entry_price * 0.985 // 1.5% stop
      : entry_price * 1.015;

  const take_profit =
    direction === "long"
      ? entry_price * 1.03 // 3% target
      : entry_price * 0.97;

  // Insert scalping position
  const positionRows = await sql`
    INSERT INTO trading_positions (
      athlete_id,
      mispricing_event_id,
      position_type,
      strategy,
      entry_price,
      size,
      stop_loss,
      take_profit,
      trailing_stop,
      status,
      opened_at
    ) VALUES (
      ${athlete_id},
      ${mispricing_event_id},
      ${direction},
      'scalping',
      ${entry_price},
      ${size},
      ${stop_loss},
      ${take_profit},
      true,
      'open',
      NOW()
    )
    RETURNING *
  `;

  const position = positionRows[0];

  // Audit log
  await sql`
    INSERT INTO audit_logs (
      entity_type,
      entity_id,
      action,
      actor,
      details
    ) VALUES (
      'trading_position',
      ${position.id},
      'open_scalp',
      'BIM-APES Trading Engine',
      ${JSON.stringify({
        athlete_id,
        direction,
        entry_price,
        size,
        momentum_intensity,
        max_holding_seconds,
      })}
    )
  `;

  return position;
}
