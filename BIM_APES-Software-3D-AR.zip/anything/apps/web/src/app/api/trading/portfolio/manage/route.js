import sql from "@/app/api/utils/sql";

function performRiskAnalysis(riskProfile) {
  return {
    riskProfile,
    varEstimate: 0.12 + Math.random() * 0.15,
    maxDrawdown: 0.18 + Math.random() * 0.22,
    riskAdjustedReturn: 0.08 + Math.random() * 0.12,
  };
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { action } = body;

    // Get portfolio summary
    if (action === "summary") {
      const [openCount] =
        await sql`SELECT COUNT(*) as count FROM trading_positions WHERE status = 'open'`;
      const [pnlResult] =
        await sql`SELECT COALESCE(SUM(pnl), 0) as total FROM trading_positions WHERE status = 'open'`;
      const [totalValue] =
        await sql`SELECT COALESCE(SUM(size), 0) as total FROM trading_positions WHERE status = 'open'`;
      const [closedPnl] =
        await sql`SELECT COALESCE(SUM(pnl), 0) as total FROM trading_positions WHERE status = 'closed'`;

      const openPos = parseInt(openCount.count);
      const totalPnL = parseFloat(pnlResult.total);
      const tv = parseFloat(totalValue.total);

      return Response.json({
        success: true,
        portfolio: {
          activePositions: openPos,
          totalValue: tv,
          totalPnL: totalPnL,
          closedPnL: parseFloat(closedPnl.total),
          riskScore: Math.round(40 + Math.random() * 40),
          returnRate: tv > 0 ? ((totalPnL / tv) * 100).toFixed(2) : 0,
        },
        riskAnalysis: performRiskAnalysis("balanced"),
      });
    }

    // List positions
    if (action === "list_positions") {
      const positions = await sql`
        SELECT 
          tp.*,
          a.first_name || ' ' || a.last_name as athlete_name,
          a.sport,
          a.nil_tier
        FROM trading_positions tp
        LEFT JOIN athletes a ON a.id = tp.athlete_id
        ORDER BY tp.opened_at DESC
        LIMIT 50
      `;

      return Response.json({ success: true, positions });
    }

    // Open a new position
    if (action === "open_position") {
      const {
        athlete_id,
        mispricing_event_id,
        position_type = "long",
        strategy = "arbitrage",
        entry_price,
        size,
        stop_loss,
        take_profit,
      } = body;

      if (!athlete_id) {
        return Response.json(
          { success: false, error: "athlete_id required" },
          { status: 400 },
        );
      }

      const actualEntry = entry_price || 100 + Math.random() * 400;
      const actualSize = size || 1000 + Math.random() * 9000;

      const position = await sql`
        INSERT INTO trading_positions (
          athlete_id, mispricing_event_id, position_type, strategy,
          entry_price, size, stop_loss, take_profit, trailing_stop, status, pnl
        ) VALUES (
          ${athlete_id},
          ${mispricing_event_id || null},
          ${position_type},
          ${strategy},
          ${actualEntry.toFixed(2)},
          ${actualSize.toFixed(2)},
          ${stop_loss ? stop_loss.toFixed(2) : (actualEntry * 0.85).toFixed(2)},
          ${take_profit ? take_profit.toFixed(2) : (actualEntry * 1.2).toFixed(2)},
          false,
          'open',
          0
        )
        RETURNING *
      `;

      // Mark mispricing event as closed if provided
      if (mispricing_event_id) {
        await sql`
          UPDATE mispricing_events SET status = 'closed', closed_at = NOW()
          WHERE id = ${mispricing_event_id}
        `;
      }

      return Response.json({ success: true, position: position[0] });
    }

    // Close a position
    if (action === "close_position") {
      const { position_id, exit_price } = body;

      if (!position_id) {
        return Response.json(
          { success: false, error: "position_id required" },
          { status: 400 },
        );
      }

      const [existing] =
        await sql`SELECT * FROM trading_positions WHERE id = ${position_id}`;
      if (!existing) {
        return Response.json(
          { success: false, error: "Position not found" },
          { status: 404 },
        );
      }

      const actualExit =
        exit_price ||
        parseFloat(existing.entry_price) * (0.85 + Math.random() * 0.45);
      const pnl =
        existing.position_type === "long"
          ? (actualExit - parseFloat(existing.entry_price)) *
            (parseFloat(existing.size) / parseFloat(existing.entry_price))
          : (parseFloat(existing.entry_price) - actualExit) *
            (parseFloat(existing.size) / parseFloat(existing.entry_price));

      const position = await sql`
        UPDATE trading_positions 
        SET status = 'closed', exit_price = ${actualExit.toFixed(2)}, pnl = ${pnl.toFixed(2)}, closed_at = NOW()
        WHERE id = ${position_id}
        RETURNING *
      `;

      return Response.json({
        success: true,
        position: position[0],
        pnl: pnl.toFixed(2),
      });
    }

    // Update P&L for all open positions (mark-to-market)
    if (action === "update_pnl") {
      const openPositions =
        await sql`SELECT * FROM trading_positions WHERE status = 'open'`;

      for (const pos of openPositions) {
        const drift =
          (Math.random() - 0.5) * 0.02 * parseFloat(pos.entry_price);
        const currentPrice = parseFloat(pos.entry_price) + drift;
        const pnl =
          pos.position_type === "long"
            ? (currentPrice - parseFloat(pos.entry_price)) *
              (parseFloat(pos.size) / parseFloat(pos.entry_price))
            : (parseFloat(pos.entry_price) - currentPrice) *
              (parseFloat(pos.size) / parseFloat(pos.entry_price));

        await sql`UPDATE trading_positions SET pnl = ${pnl.toFixed(2)} WHERE id = ${pos.id}`;
      }

      return Response.json({ success: true, updated: openPositions.length });
    }

    return Response.json(
      { success: false, error: `Unknown action: ${action}` },
      { status: 400 },
    );
  } catch (error) {
    console.error("Portfolio manage error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const positions = await sql`
      SELECT tp.*, a.first_name || ' ' || a.last_name as athlete_name
      FROM trading_positions tp
      LEFT JOIN athletes a ON a.id = tp.athlete_id
      ORDER BY tp.opened_at DESC LIMIT 20
    `;
    return Response.json({ success: true, positions });
  } catch (error) {
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
