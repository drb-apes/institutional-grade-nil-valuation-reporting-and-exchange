import sql from "@/app/api/utils/sql";

/**
 * POST /api/trading/strategies/hedge
 * Creates hedging positions to protect portfolio value
 * Portfolio-level risk management
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      portfolio_id = null,
      athlete_ids = [],
      hedge_ratio = 0.5, // Hedge 50% of exposure by default
      hedge_type = "portfolio", // 'portfolio' | 'athlete' | 'sector'
      sector = null, // 'sport' value for sector hedge
      auto_execute = false,
    } = body;

    // Analyze portfolio risk exposure
    const exposure = await analyzePortfolioExposure({
      portfolio_id,
      athlete_ids,
      sector,
    });

    // Generate hedge recommendations
    const hedge_recommendations = generateHedgeRecommendations({
      exposure,
      hedge_ratio,
      hedge_type,
    });

    const results = {
      success: true,
      timestamp: new Date().toISOString(),
      exposure_analysis: exposure,
      hedge_recommendations,
      executed_hedges: [],
    };

    // Auto-execute hedges
    if (auto_execute && hedge_recommendations.length > 0) {
      for (const hedge of hedge_recommendations) {
        const position = await executeHedgePosition(hedge);
        results.executed_hedges.push(position);
      }
    }

    return Response.json(results);
  } catch (error) {
    console.error("Hedge strategy error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/trading/strategies/hedge
 * List active hedge positions
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "open";

    const positions = await sql`
      SELECT 
        tp.*,
        a.first_name,
        a.last_name,
        a.sport,
        a.nil_tier
      FROM trading_positions tp
      JOIN athletes a ON tp.athlete_id = a.id
      WHERE tp.strategy = 'hedge'
        AND tp.status = ${status}
      ORDER BY tp.opened_at DESC
      LIMIT 100
    `;

    // Calculate total hedge value
    const total_hedge_value = positions.reduce(
      (sum, p) => sum + parseFloat(p.entry_price) * parseFloat(p.size),
      0,
    );

    return Response.json({
      success: true,
      count: positions.length,
      total_hedge_value,
      positions,
    });
  } catch (error) {
    console.error("Hedge list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HELPER FUNCTIONS ===

async function analyzePortfolioExposure(params) {
  const { portfolio_id, athlete_ids, sector } = params;

  let positions;

  if (portfolio_id) {
    // Fetch portfolio positions (assumes portfolio system exists)
    positions = await sql`
      SELECT 
        tp.*,
        a.sport,
        a.nil_tier,
        nv.true_value,
        nv.market_value,
        nv.gap
      FROM trading_positions tp
      JOIN athletes a ON tp.athlete_id = a.id
      LEFT JOIN LATERAL (
        SELECT * FROM nil_valuations
        WHERE athlete_id = tp.athlete_id
        ORDER BY calculated_at DESC
        LIMIT 1
      ) nv ON true
      WHERE tp.status = 'open'
        AND tp.strategy != 'hedge'
    `;
  } else if (athlete_ids && athlete_ids.length > 0) {
    positions = await sql`
      SELECT 
        tp.*,
        a.sport,
        a.nil_tier,
        nv.true_value,
        nv.market_value,
        nv.gap
      FROM trading_positions tp
      JOIN athletes a ON tp.athlete_id = a.id
      LEFT JOIN LATERAL (
        SELECT * FROM nil_valuations
        WHERE athlete_id = tp.athlete_id
        ORDER BY calculated_at DESC
        LIMIT 1
      ) nv ON true
      WHERE tp.status = 'open'
        AND tp.strategy != 'hedge'
        AND tp.athlete_id = ANY(${athlete_ids})
    `;
  } else if (sector) {
    positions = await sql`
      SELECT 
        tp.*,
        a.sport,
        a.nil_tier,
        nv.true_value,
        nv.market_value,
        nv.gap
      FROM trading_positions tp
      JOIN athletes a ON tp.athlete_id = a.id
      LEFT JOIN LATERAL (
        SELECT * FROM nil_valuations
        WHERE athlete_id = tp.athlete_id
        ORDER BY calculated_at DESC
        LIMIT 1
      ) nv ON true
      WHERE tp.status = 'open'
        AND tp.strategy != 'hedge'
        AND a.sport = ${sector}
    `;
  } else {
    positions = [];
  }

  // Calculate exposure metrics
  const total_exposure = positions.reduce(
    (sum, p) => sum + parseFloat(p.entry_price) * parseFloat(p.size),
    0,
  );

  const long_exposure = positions
    .filter((p) => p.position_type === "long")
    .reduce(
      (sum, p) => sum + parseFloat(p.entry_price) * parseFloat(p.size),
      0,
    );

  const short_exposure = positions
    .filter((p) => p.position_type === "short")
    .reduce(
      (sum, p) => sum + parseFloat(p.entry_price) * parseFloat(p.size),
      0,
    );

  const net_exposure = long_exposure - short_exposure;

  // Sport concentration
  const sport_exposure = {};
  positions.forEach((p) => {
    const sport = p.sport || "Unknown";
    const value = parseFloat(p.entry_price) * parseFloat(p.size);
    sport_exposure[sport] = (sport_exposure[sport] || 0) + value;
  });

  // Calculate Herfindahl-Hirschman Index (HHI) for concentration
  const total = Object.values(sport_exposure).reduce(
    (sum, val) => sum + val,
    0,
  );
  const hhi = Object.values(sport_exposure).reduce((sum, val) => {
    const share = total > 0 ? val / total : 0;
    return sum + share * share;
  }, 0);

  return {
    total_exposure,
    long_exposure,
    short_exposure,
    net_exposure,
    net_exposure_percentage:
      total_exposure > 0 ? (net_exposure / total_exposure) * 100 : 0,
    sport_exposure,
    concentration_hhi: hhi,
    position_count: positions.length,
    positions_needing_hedge: positions.filter((p) => p.position_type === "long")
      .length,
  };
}

function generateHedgeRecommendations(params) {
  const { exposure, hedge_ratio, hedge_type } = params;

  const recommendations = [];

  if (hedge_type === "portfolio") {
    // Portfolio-level hedge
    const hedge_amount = exposure.net_exposure * hedge_ratio;

    if (hedge_amount > 0) {
      recommendations.push({
        hedge_type: "portfolio",
        direction: "short",
        notional_value: hedge_amount,
        hedge_ratio,
        rationale: `Hedge ${(hedge_ratio * 100).toFixed(0)}% of net long exposure`,
      });
    }
  }

  if (hedge_type === "sector") {
    // Sport-specific hedges
    Object.entries(exposure.sport_exposure).forEach(([sport, value]) => {
      const hedge_amount = value * hedge_ratio;

      recommendations.push({
        hedge_type: "sector",
        sector: sport,
        direction: "short",
        notional_value: hedge_amount,
        hedge_ratio,
        rationale: `Hedge ${(hedge_ratio * 100).toFixed(0)}% of ${sport} exposure`,
      });
    });
  }

  return recommendations;
}

async function executeHedgePosition(hedge) {
  const { hedge_type, direction, notional_value, sector = null } = hedge;

  // Find suitable athlete for hedge (inverse position)
  let athleteRows;

  if (sector) {
    athleteRows = await sql`
      SELECT a.id, nv.market_value
      FROM athletes a
      LEFT JOIN LATERAL (
        SELECT * FROM nil_valuations
        WHERE athlete_id = a.id
        ORDER BY calculated_at DESC
        LIMIT 1
      ) nv ON true
      WHERE a.sport = ${sector}
        AND a.consent_trading = true
      ORDER BY RANDOM()
      LIMIT 1
    `;
  } else {
    athleteRows = await sql`
      SELECT a.id, nv.market_value
      FROM athletes a
      LEFT JOIN LATERAL (
        SELECT * FROM nil_valuations
        WHERE athlete_id = a.id
        ORDER BY calculated_at DESC
        LIMIT 1
      ) nv ON true
      WHERE a.consent_trading = true
      ORDER BY RANDOM()
      LIMIT 1
    `;
  }

  if (athleteRows.length === 0) {
    throw new Error("No suitable athletes found for hedge");
  }

  const athlete = athleteRows[0];
  const entry_price = parseFloat(athlete.market_value) || 100;
  const size = notional_value / entry_price;

  // Insert hedge position
  const positionRows = await sql`
    INSERT INTO trading_positions (
      athlete_id,
      position_type,
      strategy,
      entry_price,
      size,
      trailing_stop,
      status,
      opened_at
    ) VALUES (
      ${athlete.id},
      ${direction},
      'hedge',
      ${entry_price},
      ${size},
      false,
      'open',
      NOW()
    )
    RETURNING *
  `;

  const position = positionRows[0];

  // Audit log
  await sql`
    INSERT INTO audit_logs (
      entity_type,
      entity_id,
      action,
      actor,
      details
    ) VALUES (
      'trading_position',
      ${position.id},
      'open_hedge',
      'BIM-APES Trading Engine',
      ${JSON.stringify({
        hedge_type,
        notional_value,
        sector,
      })}
    )
  `;

  return position;
}
