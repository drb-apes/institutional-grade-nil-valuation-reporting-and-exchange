import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json().catch(() => ({}));
    const {
      min_gap_percentage = 5,
      min_confidence = 0.7,
      event_types = ["arbitrage", "scalping", "hedge"],
    } = body;

    // Get recent NIL valuations with significant gaps
    const mispricings = await sql`
      SELECT 
        nv.*,
        a.first_name,
        a.last_name,
        a.sport,
        a.nil_tier,
        a.consent_trading
      FROM nil_valuations nv
      JOIN athletes a ON nv.athlete_id = a.id
      WHERE ABS(nv.gap_percentage) >= ${min_gap_percentage}
      AND nv.confidence >= ${min_confidence}
      AND a.consent_trading = true
      AND nv.calculated_at > NOW() - INTERVAL '1 hour'
      ORDER BY ABS(nv.gap_percentage) DESC
      LIMIT 50
    `;

    const events = [];

    for (const mp of mispricings) {
      let eventType = "arbitrage";
      let ttlSeconds = mp.expected_close_seconds || 1800;

      if (Math.abs(mp.gap_percentage) > 15 && mp.momentum_intensity > 0.7) {
        eventType = "scalping";
        ttlSeconds = 300;
      } else if (mp.convexity_factor > 0.6) {
        eventType = "hedge";
        ttlSeconds = 3600;
      }

      if (!event_types.includes(eventType)) continue;

      const existing = await sql`
        SELECT id FROM mispricing_events
        WHERE athlete_id = ${mp.athlete_id}
        AND status = 'active'
        AND expires_at > NOW()
      `;

      if (existing.length > 0) continue;

      // Fix: use INTERVAL '1 second' * ttlSeconds instead of string interpolation
      const event = await sql`
        INSERT INTO mispricing_events (
          athlete_id,
          event_type,
          gap,
          direction,
          confidence,
          ttl_seconds,
          expires_at
        ) VALUES (
          ${mp.athlete_id},
          ${eventType},
          ${mp.gap},
          ${mp.direction},
          ${mp.confidence},
          ${ttlSeconds},
          NOW() + (INTERVAL '1 second' * ${ttlSeconds})
        )
        RETURNING *
      `;

      events.push({
        ...event[0],
        athlete: {
          name: `${mp.first_name} ${mp.last_name}`,
          sport: mp.sport,
          nil_tier: mp.nil_tier,
        },
        valuation: {
          true_value: mp.true_value,
          market_value: mp.market_value,
          gap_percentage: mp.gap_percentage,
        },
      });
    }

    // Also get existing active events
    const activeEvents = await sql`
      SELECT 
        me.*,
        a.first_name || ' ' || a.last_name as athlete_name
      FROM mispricing_events me
      JOIN athletes a ON me.athlete_id = a.id
      WHERE me.status = 'active'
      AND me.expires_at > NOW()
      ORDER BY me.detected_at DESC
      LIMIT 20
    `;

    // Portfolio summary
    const [posCount] =
      await sql`SELECT COUNT(*) as count FROM trading_positions WHERE status = 'open'`;
    const [pnlSum] =
      await sql`SELECT COALESCE(SUM(pnl), 0) as total FROM trading_positions WHERE status = 'open'`;

    return Response.json({
      success: true,
      events_detected: events.length,
      events: [
        ...events,
        ...activeEvents.filter((ae) => !events.find((e) => e.id === ae.id)),
      ],
      portfolio_summary: {
        open_positions: parseInt(posCount.count),
        total_pnl: parseFloat(pnlSum.total),
      },
    });
  } catch (error) {
    console.error("Error detecting mispricing events:", error);
    return Response.json(
      {
        success: false,
        error: "Failed to detect mispricing events",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const event_type = searchParams.get("event_type");
    const athlete_id = searchParams.get("athlete_id");

    let query = `
      SELECT me.*, a.first_name, a.last_name, a.sport, a.nil_tier
      FROM mispricing_events me
      JOIN athletes a ON me.athlete_id = a.id
      WHERE me.status = 'active' AND me.expires_at > NOW()
    `;
    const params = [];
    let paramIndex = 1;

    if (event_type) {
      query += ` AND me.event_type = $${paramIndex}`;
      params.push(event_type);
      paramIndex++;
    }
    if (athlete_id) {
      query += ` AND me.athlete_id = $${paramIndex}`;
      params.push(athlete_id);
      paramIndex++;
    }
    query += ` ORDER BY ABS(me.gap) DESC LIMIT 100`;

    const events = await sql(query, params);

    return Response.json({ success: true, count: events.length, events });
  } catch (error) {
    console.error("Error fetching mispricing events:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
