import sql from "@/app/api/utils/sql";

/**
 * POST /api/coalition/activate
 * Activates coalition partnership and utility mapping
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      certificate_id,
      coalition_partner,
      utility_rights = [],
      engagement_score_initial = 0,
    } = body;

    if (!certificate_id || !coalition_partner) {
      return Response.json(
        {
          success: false,
          error: "certificate_id and coalition_partner are required",
        },
        { status: 400 },
      );
    }

    // Verify certificate exists and is active
    const certRows = await sql`
      SELECT c.*, a.first_name, a.last_name, a.sport
      FROM coalition_certificates c
      JOIN athletes a ON c.athlete_id = a.id
      WHERE c.id = ${certificate_id} AND c.status = 'active'
    `;

    if (certRows.length === 0) {
      return Response.json(
        { success: false, error: "Certificate not found or inactive" },
        { status: 404 },
      );
    }

    const certificate = certRows[0];

    // Build utility mapping
    const utility_mapping = {
      coalition_partner,
      engagement_score: engagement_score_initial,
      rights: utility_rights,
      activated_at: new Date().toISOString(),
      ...certificate.utility_mapping,
    };

    // Update certificate with coalition activation
    const updatedRows = await sql`
      UPDATE coalition_certificates
      SET
        coalition_partner = ${coalition_partner},
        utility_mapping = ${JSON.stringify(utility_mapping)},
        updated_at = NOW()
      WHERE id = ${certificate_id}
      RETURNING *
    `;

    const updated = updatedRows[0];

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'coalition_activation',
        ${certificate_id},
        'activate',
        ${coalition_partner},
        ${JSON.stringify({
          utility_rights,
          engagement_score_initial,
        })}
      )
    `;

    return Response.json({
      success: true,
      message: "Coalition activated successfully",
      certificate: updated,
      athlete: {
        name: `${certificate.first_name} ${certificate.last_name}`,
        sport: certificate.sport,
      },
      activation: {
        partner: coalition_partner,
        rights: utility_rights,
        engagement_score: engagement_score_initial,
      },
    });
  } catch (error) {
    console.error("Coalition activation error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/coalition/activate?partner=...
 * List coalition activations by partner
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const partner = searchParams.get("partner");

    let query;
    if (partner) {
      query = sql`
        SELECT 
          c.*,
          a.first_name,
          a.last_name,
          a.sport,
          a.nil_tier
        FROM coalition_certificates c
        JOIN athletes a ON c.athlete_id = a.id
        WHERE c.coalition_partner = ${partner}
          AND c.status = 'active'
        ORDER BY c.issued_at DESC
      `;
    } else {
      query = sql`
        SELECT 
          c.*,
          a.first_name,
          a.last_name,
          a.sport,
          a.nil_tier
        FROM coalition_certificates c
        JOIN athletes a ON c.athlete_id = a.id
        WHERE c.coalition_partner IS NOT NULL
          AND c.status = 'active'
        ORDER BY c.issued_at DESC
      `;
    }

    const activations = await query;

    return Response.json({
      success: true,
      count: activations.length,
      activations,
    });
  } catch (error) {
    console.error("Coalition list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
