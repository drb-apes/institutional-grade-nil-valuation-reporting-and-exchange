import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Revenue & Licensing API
 * Handles per-team, per-event, per-broadcast, and creator economy pricing
 * Supports: Sports, Music, Film, Creator Economy
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      action, // "calculate_pricing" | "generate_license" | "activate_sponsor"
      entity_type, // "team" | "event" | "broadcast_partner" | "creator"
      entity_id,
      industry, // "sports" | "music" | "film" | "creator_economy"
      license_type, // "season" | "single_event" | "broadcast_rights" | "sponsor_activation"
      duration_months,
      athlete_count,
      sponsor_name,
    } = body;

    if (!action || !entity_type || !industry) {
      return Response.json(
        { error: "Missing required fields: action, entity_type, industry" },
        { status: 400 },
      );
    }

    let result = {};

    switch (action) {
      case "calculate_pricing":
        result = await calculatePricing({
          entity_type,
          entity_id,
          industry,
          license_type,
          duration_months,
          athlete_count,
        });
        break;

      case "generate_license":
        result = await generateLicense({
          entity_type,
          entity_id,
          industry,
          license_type,
          duration_months,
        });
        break;

      case "activate_sponsor":
        result = await activateSponsor({
          entity_id,
          sponsor_name,
          industry,
        });
        break;

      default:
        return Response.json(
          { error: `Unknown action: ${action}` },
          { status: 400 },
        );
    }

    return Response.json({
      success: true,
      action,
      entity_type,
      industry,
      result,
    });
  } catch (error) {
    console.error("Revenue licensing error:", error);
    return Response.json(
      { error: "Revenue licensing failed", details: error.message },
      { status: 500 },
    );
  }
}

// ================================================================================
// CALCULATE PRICING
// ================================================================================
async function calculatePricing({
  entity_type,
  entity_id,
  industry,
  license_type,
  duration_months = 12,
  athlete_count = 1,
}) {
  const basePricing = getBasePricing(industry, license_type);
  const volumeMultiplier = getVolumeMultiplier(athlete_count);
  const durationMultiplier = getDurationMultiplier(duration_months);
  const industryModifier = getIndustryModifier(industry);

  const basePrice = basePricing.base_price;
  const finalPrice =
    basePrice * volumeMultiplier * durationMultiplier * industryModifier;

  return {
    entity_type,
    industry,
    license_type,
    pricing: {
      base_price: Math.round(basePrice),
      volume_multiplier: volumeMultiplier,
      duration_multiplier: durationMultiplier,
      industry_modifier: industryModifier,
      final_price: Math.round(finalPrice),
      currency: "USD",
      billing_cycle: duration_months >= 12 ? "annual" : "monthly",
    },
    breakdown: {
      per_athlete_cost: Math.round(finalPrice / athlete_count),
      per_month_cost: Math.round(finalPrice / duration_months),
      setup_fee: basePricing.setup_fee,
      api_credits_included: basePricing.api_credits,
    },
    includes: basePricing.includes,
  };
}

// ================================================================================
// GENERATE LICENSE
// ================================================================================
async function generateLicense({
  entity_type,
  entity_id,
  industry,
  license_type,
  duration_months = 12,
}) {
  const licenseId = `LIC-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  const startDate = new Date();
  const endDate = new Date();
  endDate.setMonth(endDate.getMonth() + duration_months);

  const license = {
    license_id: licenseId,
    entity_type,
    entity_id,
    industry,
    license_type,
    status: "active",
    start_date: startDate.toISOString(),
    end_date: endDate.toISOString(),
    duration_months,
    api_access: {
      ar_overlays: true,
      broadcast_packages: true,
      nil_valuation: true,
      biometric_intelligence: true,
      trading_strategies: license_type !== "single_event",
    },
    usage_limits: getLicenseUsageLimits(license_type, industry),
    support_tier: license_type === "broadcast_rights" ? "premium" : "standard",
  };

  // In production, save to database
  // await sql`INSERT INTO licenses ...`

  return license;
}

// ================================================================================
// ACTIVATE SPONSOR
// ================================================================================
async function activateSponsor({ entity_id, sponsor_name, industry }) {
  const activation = {
    activation_id: `ACT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    entity_id,
    sponsor_name,
    industry,
    activated_at: new Date().toISOString(),
    features: {
      nil_momentum_windows: true,
      gold_glow_activation: true,
      brand_fit_indicators: true,
      sponsor_badges: true,
      real_time_roi_tracking: true,
    },
    branding: {
      logo_url: `/sponsors/${sponsor_name.toLowerCase().replace(/\s+/g, "-")}-logo.png`,
      primary_color: getSponsorBrandColor(sponsor_name),
      activation_phrase: `Powered by ${sponsor_name}`,
    },
    performance_tracking: {
      impressions: 0,
      engagement_rate: 0,
      conversion_events: 0,
      roi_multiplier: 0,
    },
  };

  return activation;
}

// ================================================================================
// PRICING MODELS
// ================================================================================
function getBasePricing(industry, license_type) {
  const pricingMatrix = {
    sports: {
      season: {
        base_price: 150000,
        setup_fee: 5000,
        api_credits: 100000,
        includes: [
          "Full AR overlay suite",
          "Broadcast packages (ESPN, TNT, Amazon, Apple)",
          "NIL valuation engine",
          "Trading strategies",
          "Wearable integrations",
          "Medical alerts",
          "Coach dashboards",
        ],
      },
      single_event: {
        base_price: 8000,
        setup_fee: 500,
        api_credits: 5000,
        includes: [
          "Event-specific AR overlays",
          "Broadcast packages",
          "NIL valuation snapshot",
          "Performance trends",
        ],
      },
      broadcast_rights: {
        base_price: 500000,
        setup_fee: 25000,
        api_credits: 500000,
        includes: [
          "Unlimited AR overlays",
          "Custom broadcast integrations",
          "Multi-league support",
          "Real-time NIL tracking",
          "Sponsor activation tools",
          "Premium support",
          "Custom branding",
        ],
      },
      sponsor_activation: {
        base_price: 50000,
        setup_fee: 2500,
        api_credits: 25000,
        includes: [
          "NIL momentum windows",
          "Gold glow activation moments",
          "Brand fit indicators",
          "ROI tracking dashboards",
          "Custom sponsor overlays",
        ],
      },
    },
    music: {
      season: {
        base_price: 120000,
        setup_fee: 4000,
        api_credits: 80000,
        includes: [
          "Concert performance AR overlays",
          "NIL valuation for artists",
          "Tour optimization",
          "Fan engagement metrics",
          "Sponsor activations",
        ],
      },
      single_event: {
        base_price: 6000,
        setup_fee: 400,
        api_credits: 4000,
        includes: [
          "Concert-specific overlays",
          "Real-time performance metrics",
          "Fan engagement tracking",
        ],
      },
      broadcast_rights: {
        base_price: 400000,
        setup_fee: 20000,
        api_credits: 400000,
        includes: [
          "Live concert AR packages",
          "Streaming platform integrations",
          "Artist NIL tracking",
          "Sponsor activation tools",
        ],
      },
      sponsor_activation: {
        base_price: 40000,
        setup_fee: 2000,
        api_credits: 20000,
        includes: [
          "Artist momentum windows",
          "Brand alignment scoring",
          "Campaign ROI tracking",
        ],
      },
    },
    film: {
      season: {
        base_price: 200000,
        setup_fee: 8000,
        api_credits: 150000,
        includes: [
          "Studio performance tracking",
          "Actor NIL valuation",
          "Production optimization",
          "Talent discovery engine",
        ],
      },
      single_event: {
        base_price: 10000,
        setup_fee: 600,
        api_credits: 6000,
        includes: [
          "Premiere event overlays",
          "Talent performance metrics",
          "ROI projections",
        ],
      },
      broadcast_rights: {
        base_price: 600000,
        setup_fee: 30000,
        api_credits: 600000,
        includes: [
          "Full studio integration",
          "Multi-platform NIL tracking",
          "Talent portfolio management",
          "Brand partnership tools",
        ],
      },
      sponsor_activation: {
        base_price: 60000,
        setup_fee: 3000,
        api_credits: 30000,
        includes: [
          "Actor brand fit scoring",
          "Campaign performance tracking",
          "Talent momentum windows",
        ],
      },
    },
    creator_economy: {
      season: {
        base_price: 50000,
        setup_fee: 2000,
        api_credits: 40000,
        includes: [
          "Creator NIL valuation",
          "Content performance tracking",
          "Brand partnership matching",
          "Revenue optimization",
        ],
      },
      single_event: {
        base_price: 3000,
        setup_fee: 200,
        api_credits: 2000,
        includes: [
          "Event-specific tracking",
          "Engagement metrics",
          "Sponsor activations",
        ],
      },
      broadcast_rights: {
        base_price: 150000,
        setup_fee: 7500,
        api_credits: 150000,
        includes: [
          "Multi-platform integration",
          "Creator portfolio management",
          "Brand deal optimization",
          "Revenue forecasting",
        ],
      },
      sponsor_activation: {
        base_price: 20000,
        setup_fee: 1000,
        api_credits: 10000,
        includes: [
          "Creator-brand alignment",
          "Campaign ROI tracking",
          "Audience insights",
        ],
      },
    },
  };

  return (
    pricingMatrix[industry]?.[license_type] || pricingMatrix.sports.single_event
  );
}

function getVolumeMultiplier(athlete_count) {
  if (athlete_count <= 5) return 1.0;
  if (athlete_count <= 15) return 0.9; // 10% discount
  if (athlete_count <= 30) return 0.85; // 15% discount
  if (athlete_count <= 50) return 0.8; // 20% discount
  return 0.75; // 25% discount for 50+
}

function getDurationMultiplier(duration_months) {
  if (duration_months >= 24) return 0.8; // 20% discount for 2-year
  if (duration_months >= 12) return 0.9; // 10% discount for annual
  if (duration_months >= 6) return 0.95; // 5% discount for 6-month
  return 1.0; // Full price for shorter terms
}

function getIndustryModifier(industry) {
  const modifiers = {
    sports: 1.0,
    music: 0.9,
    film: 1.2,
    creator_economy: 0.7,
  };
  return modifiers[industry] || 1.0;
}

function getLicenseUsageLimits(license_type, industry) {
  const limits = {
    season: {
      api_calls_per_month: 100000,
      athletes_tracked: 50,
      concurrent_events: 10,
      data_retention_months: 24,
    },
    single_event: {
      api_calls_per_month: 5000,
      athletes_tracked: 10,
      concurrent_events: 1,
      data_retention_months: 3,
    },
    broadcast_rights: {
      api_calls_per_month: 1000000,
      athletes_tracked: 500,
      concurrent_events: 100,
      data_retention_months: 60,
    },
    sponsor_activation: {
      api_calls_per_month: 50000,
      athletes_tracked: 30,
      concurrent_events: 20,
      data_retention_months: 12,
    },
  };

  return limits[license_type] || limits.single_event;
}

function getSponsorBrandColor(sponsor_name) {
  const brandColors = {
    Nike: "#FF6B00",
    Adidas: "#000000",
    Gatorade: "#FF6900",
    Beats: "#000000",
    "Red Bull": "#E20A17",
    Puma: "#000000",
    "Under Armour": "#1D1D1D",
  };
  return brandColors[sponsor_name] || "#000000";
}

// ================================================================================
// GET ENDPOINT - Retrieve pricing info without body
// ================================================================================
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const industry = searchParams.get("industry") || "sports";
    const license_type = searchParams.get("license_type") || "single_event";

    const pricing = getBasePricing(industry, license_type);

    return Response.json({
      success: true,
      industry,
      license_type,
      pricing,
      supported_industries: ["sports", "music", "film", "creator_economy"],
      supported_license_types: [
        "season",
        "single_event",
        "broadcast_rights",
        "sponsor_activation",
      ],
    });
  } catch (error) {
    console.error("Revenue pricing info error:", error);
    return Response.json(
      { error: "Failed to retrieve pricing", details: error.message },
      { status: 500 },
    );
  }
}
