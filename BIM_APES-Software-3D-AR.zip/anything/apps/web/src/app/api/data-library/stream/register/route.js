/**
 * POST /api/data-library/stream/register
 * Register a private live stream endpoint for real-time data consumption
 * Creates unique streaming channels for players, teams, medical staff, and coaches
 */
export async function POST(request) {
  try {
    const {
      user_role,
      user_id,
      stream_type,
      athlete_id,
      team_id,
      frequency_hz = 30, // Default 30 Hz streaming
      data_filters = [],
    } = await request.json();

    if (!user_role || !user_id || !stream_type) {
      return Response.json(
        {
          success: false,
          error: "user_role, user_id, and stream_type are required",
        },
        { status: 400 },
      );
    }

    // Validate access permissions for streaming
    const streamAccess = validateStreamAccess(
      user_role,
      stream_type,
      user_id,
      athlete_id,
      team_id,
    );

    if (!streamAccess.allowed) {
      return Response.json(
        {
          success: false,
          error: "Stream access denied",
          reason: streamAccess.reason,
        },
        { status: 403 },
      );
    }

    // Generate unique stream ID
    const streamId = generateStreamId(user_role, user_id, stream_type);

    // Create private endpoint URL
    const streamEndpoint = createPrivateEndpoint(streamId, user_role);

    // Register stream in active streams registry
    const streamRegistration = {
      stream_id: streamId,
      user_role,
      user_id,
      stream_type,
      athlete_id,
      team_id,
      frequency_hz,
      data_filters,
      endpoint: streamEndpoint,
      websocket_url: `wss://${process.env.NEXT_PUBLIC_CREATE_APP_URL || "localhost:3000"}/api/data-library/stream/ws/${streamId}`,
      http_stream_url: `${process.env.NEXT_PUBLIC_CREATE_APP_URL || "http://localhost:3000"}/api/data-library/stream/http/${streamId}`,
      status: "active",
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hour expiry
    };

    // Store registration (in production, use Redis or DynamoDB)
    await storeStreamRegistration(streamRegistration);

    // Generate access token for authentication
    const accessToken = generateAccessToken(streamRegistration);

    return Response.json({
      success: true,
      stream: {
        stream_id: streamId,
        websocket_url: streamRegistration.websocket_url,
        http_stream_url: streamRegistration.http_stream_url,
        access_token: accessToken,
        frequency_hz,
        data_type: stream_type,
        expires_at: streamRegistration.expires_at,
      },
      connection_instructions: {
        websocket: {
          url: streamRegistration.websocket_url,
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "X-Stream-ID": streamId,
          },
          example: `new WebSocket('${streamRegistration.websocket_url}', { headers: { 'Authorization': 'Bearer ${accessToken}' } })`,
        },
        http_sse: {
          url: streamRegistration.http_stream_url,
          headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: "text/event-stream",
          },
          example: `new EventSource('${streamRegistration.http_stream_url}', { headers: { 'Authorization': 'Bearer ${accessToken}' } })`,
        },
      },
      usage_notes: [
        "WebSocket recommended for 30-60 Hz real-time data",
        "HTTP SSE recommended for lower frequency updates (1-10 Hz)",
        "Stream automatically expires after 24 hours",
        "Reconnect logic recommended for production use",
      ],
    });
  } catch (error) {
    console.error("Stream registration error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

function validateStreamAccess(role, streamType, userId, athleteId, teamId) {
  // Stream access matrix (more restrictive than S3 pull)
  const streamAccessMatrix = {
    player: {
      allowed: ["biometric_realtime", "performance_live"],
      condition: (athleteId) => athleteId === userId,
      level: "self",
    },
    coach: {
      allowed: [
        "biometric_realtime",
        "performance_live",
        "team_session_live",
        "ar_overlay_live",
      ],
      condition: (teamId) => true,
      level: "team",
    },
    medical_staff: {
      allowed: [
        "biometric_realtime",
        "medical_alerts_live",
        "ar_medical_live",
        "recovery_live",
      ],
      condition: () => true,
      level: "medical",
    },
    team_admin: {
      allowed: ["all_streams"],
      condition: () => true,
      level: "admin",
    },
    broadcast: {
      allowed: ["ar_broadcast_feed", "stadium_feed", "highlights_live"],
      condition: () => true,
      level: "broadcast",
    },
  };

  const roleAccess = streamAccessMatrix[role];

  if (!roleAccess) {
    return { allowed: false, reason: "Invalid role for streaming" };
  }

  if (
    !roleAccess.allowed.includes("all_streams") &&
    !roleAccess.allowed.includes(streamType)
  ) {
    return {
      allowed: false,
      reason: `Role ${role} cannot stream ${streamType}`,
    };
  }

  if (!roleAccess.condition(athleteId || teamId)) {
    return { allowed: false, reason: "Stream access condition not met" };
  }

  return { allowed: true, level: roleAccess.level };
}

function generateStreamId(role, userId, streamType) {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(7);
  return `stream-${role}-${userId}-${streamType}-${timestamp}-${random}`;
}

function createPrivateEndpoint(streamId, role) {
  // In production, this would be a dedicated streaming server
  return `/api/data-library/stream/consume/${streamId}`;
}

async function storeStreamRegistration(registration) {
  // In production: Redis.set(`stream:${registration.stream_id}`, JSON.stringify(registration), 'EX', 86400)
  console.log("[STREAM REGISTERED]", registration.stream_id);
}

function generateAccessToken(streamRegistration) {
  // In production: Use JWT with proper signing
  const tokenPayload = {
    stream_id: streamRegistration.stream_id,
    user_role: streamRegistration.user_role,
    user_id: streamRegistration.user_id,
    expires_at: streamRegistration.expires_at,
  };

  // Simple base64 encoding for demo (use proper JWT in production)
  return Buffer.from(JSON.stringify(tokenPayload)).toString("base64");
}

/**
 * GET /api/data-library/stream/register
 * List active streams for a user
 */
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("user_id");
  const userRole = searchParams.get("user_role");

  if (!userId || !userRole) {
    return Response.json(
      {
        success: false,
        error: "user_id and user_role are required",
      },
      { status: 400 },
    );
  }

  // Get active streams for user (from Redis/DB in production)
  const activeStreams = await getActiveStreams(userId, userRole);

  return Response.json({
    success: true,
    active_streams: activeStreams,
    stream_count: activeStreams.length,
  });
}

async function getActiveStreams(userId, userRole) {
  // Simulated active streams
  return [
    {
      stream_id: `stream-${userRole}-${userId}-example-1`,
      stream_type: "biometric_realtime",
      status: "active",
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    },
  ];
}

/**
 * DELETE /api/data-library/stream/register
 * Deregister/close a stream
 */
export async function DELETE(request) {
  const { stream_id } = await request.json();

  if (!stream_id) {
    return Response.json(
      {
        success: false,
        error: "stream_id is required",
      },
      { status: 400 },
    );
  }

  // Remove stream registration (from Redis/DB in production)
  await removeStreamRegistration(stream_id);

  return Response.json({
    success: true,
    message: `Stream ${stream_id} closed`,
    closed_at: new Date().toISOString(),
  });
}

async function removeStreamRegistration(streamId) {
  // In production: Redis.del(`stream:${streamId}`)
  console.log("[STREAM CLOSED]", streamId);
}
