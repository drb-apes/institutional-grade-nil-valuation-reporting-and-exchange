/**
 * WebSocket endpoint for real-time streaming
 * URL: ws://domain/api/data-library/stream/ws/{streamId}
 *
 * Note: Next.js doesn't natively support WebSocket routes in the App Router.
 * This file documents the WebSocket protocol and serves as a fallback HTTP streaming endpoint.
 *
 * For production WebSocket support, use:
 * 1. Custom Node.js server with ws library
 * 2. AWS API Gateway WebSocket APIs
 * 3. Pusher/Ably/Socket.io managed services
 */

/**
 * GET /api/data-library/stream/ws/[streamId]
 * HTTP streaming fallback using Server-Sent Events (SSE)
 */
export async function GET(request, { params }) {
  const { streamId } = params;

  // Validate stream access token from headers
  const authHeader = request.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return Response.json(
      {
        success: false,
        error: "Missing or invalid authorization token",
      },
      { status: 401 },
    );
  }

  const token = authHeader.substring(7);
  const streamAuth = validateStreamToken(token, streamId);

  if (!streamAuth.valid) {
    return Response.json(
      {
        success: false,
        error: "Invalid stream token",
      },
      { status: 403 },
    );
  }

  // Create Server-Sent Events stream
  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();

      // Send initial connection message
      controller.enqueue(
        encoder.encode(
          `data: ${JSON.stringify({
            type: "connection",
            stream_id: streamId,
            connected_at: new Date().toISOString(),
            frequency_hz: 30,
          })}\n\n`,
        ),
      );

      // Simulate real-time data streaming at 30 Hz (every ~33ms)
      let frameCount = 0;
      const intervalId = setInterval(() => {
        frameCount++;

        const frame = generateStreamFrame(streamAuth.stream_type, frameCount);

        try {
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify(frame)}\n\n`),
          );
        } catch (error) {
          clearInterval(intervalId);
          controller.close();
        }

        // Auto-close after 1000 frames (~33 seconds for demo)
        if (frameCount >= 1000) {
          clearInterval(intervalId);
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                type: "stream_end",
                total_frames: frameCount,
                closed_at: new Date().toISOString(),
              })}\n\n`,
            ),
          );
          controller.close();
        }
      }, 33); // ~30 Hz

      // Cleanup on client disconnect
      request.signal.addEventListener("abort", () => {
        clearInterval(intervalId);
        controller.close();
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no", // Disable nginx buffering
    },
  });
}

function validateStreamToken(token, streamId) {
  try {
    // In production: Verify JWT signature
    const payload = JSON.parse(Buffer.from(token, "base64").toString());

    // Check if token matches stream_id
    if (payload.stream_id !== streamId) {
      return { valid: false, reason: "Token/Stream ID mismatch" };
    }

    // Check expiry
    if (new Date(payload.expires_at) < new Date()) {
      return { valid: false, reason: "Token expired" };
    }

    return {
      valid: true,
      user_role: payload.user_role,
      user_id: payload.user_id,
      stream_type: extractStreamType(streamId),
    };
  } catch (error) {
    return { valid: false, reason: "Token decode error" };
  }
}

function extractStreamType(streamId) {
  // Extract stream type from stream_id format: stream-{role}-{userId}-{streamType}-{timestamp}-{random}
  const parts = streamId.split("-");
  return parts[3] || "biometric_realtime";
}

function generateStreamFrame(streamType, frameCount) {
  const timestamp = new Date().toISOString();

  switch (streamType) {
    case "biometric_realtime":
      return {
        type: "biometric_frame",
        frame: frameCount,
        timestamp,
        data: {
          heart_rate: 60 + Math.sin(frameCount / 30) * 20 + Math.random() * 5,
          hrv: 50 + Math.cos(frameCount / 40) * 15 + Math.random() * 3,
          spo2: 96 + Math.random() * 3,
          respiratory_rate: 14 + Math.sin(frameCount / 50) * 2,
          skin_temperature: 36.5 + Math.random() * 0.5,
        },
      };

    case "performance_live":
      return {
        type: "performance_frame",
        frame: frameCount,
        timestamp,
        data: {
          speed_mph: Math.max(0, 10 + Math.sin(frameCount / 20) * 8),
          acceleration_g: Math.random() * 3,
          power_output_watts: 200 + Math.random() * 150,
          cadence_rpm: 80 + Math.random() * 20,
          stride_length_m: 1.5 + Math.random() * 0.5,
        },
      };

    case "ar_medical_live":
      return {
        type: "ar_medical_frame",
        frame: frameCount,
        timestamp,
        data: {
          collapse_risk_score: Math.random() * 100,
          joint_stress_left_knee: Math.random() * 100,
          joint_stress_right_knee: Math.random() * 100,
          impact_load_cumulative: frameCount * 0.5,
          recovery_envelope_status: Math.random() > 0.8 ? "warning" : "normal",
        },
      };

    case "team_session_live":
      return {
        type: "team_session_frame",
        frame: frameCount,
        timestamp,
        data: {
          active_players: 11,
          avg_heart_rate: 145 + Math.random() * 20,
          avg_speed: 12 + Math.random() * 5,
          formation: "4-3-3",
          possession_percentage: 45 + Math.random() * 10,
        },
      };

    default:
      return {
        type: "generic_frame",
        frame: frameCount,
        timestamp,
        data: { value: Math.random() * 100 },
      };
  }
}
