import sql from "@/app/api/utils/sql";

/**
 * BIM-APES Broadcast AR Package API
 * Generates broadcast-ready AR overlays for ESPN, TNT, Amazon Prime, Apple Sports
 * Supports league integrations: NBA, NFL, UFC, MLS, NHL, NCAA
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      broadcast_partner, // "ESPN" | "TNT" | "Amazon Prime" | "Apple Sports"
      league, // "NBA" | "NFL" | "UFC" | "MLS" | "NHL" | "NCAA"
      package_type, // "coach_view" | "medical_alerts" | "rotation_optimizer" | "performance_trends" | "sponsor_activation"
      output_format, // "1080p" | "4K" | "HDR" | "stadium_display"
      lighting_conditions, // "bright_arena" | "dim_arena" | "outdoor_day" | "outdoor_night"
    } = body;

    if (!athlete_id || !broadcast_partner || !package_type) {
      return Response.json(
        {
          error:
            "Missing required fields: athlete_id, broadcast_partner, package_type",
        },
        { status: 400 },
      );
    }

    // Get athlete data
    const athleteResult = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteResult.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athleteResult[0];

    // Get latest biometric readings
    const readings = await sql`
      SELECT 
        br.index_code,
        br.score,
        br.baseline,
        br.trend,
        br.recorded_at,
        bid.index_name,
        bid.cluster
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
      ORDER BY br.recorded_at DESC
      LIMIT 50
    `;

    // Get latest NIL valuation
    const valuationResult = await sql`
      SELECT * FROM nil_valuations
      WHERE athlete_id = ${athlete_id}
      ORDER BY calculated_at DESC
      LIMIT 1
    `;

    const valuation = valuationResult.length > 0 ? valuationResult[0] : null;

    // Get active mispricing events
    const mispricingResult = await sql`
      SELECT * FROM mispricing_events
      WHERE athlete_id = ${athlete_id}
        AND status = 'active'
        AND expires_at > NOW()
      ORDER BY detected_at DESC
      LIMIT 5
    `;

    // Generate package based on type
    let arPackage = {};

    switch (package_type) {
      case "coach_view":
        arPackage = generateCoachComparisonView({
          athlete,
          readings,
          valuation,
          league,
          lighting_conditions,
        });
        break;

      case "medical_alerts":
        arPackage = generateMedicalStaffAlerts({
          athlete,
          readings,
          league,
          lighting_conditions,
        });
        break;

      case "rotation_optimizer":
        arPackage = generateRotationOptimizer({
          athlete,
          readings,
          valuation,
          league,
          lighting_conditions,
        });
        break;

      case "performance_trends":
        arPackage = generatePerformanceTrendPackage({
          athlete,
          readings,
          valuation,
          league,
          lighting_conditions,
        });
        break;

      case "sponsor_activation":
        arPackage = generateSponsorActivationAR({
          athlete,
          readings,
          valuation,
          mispricingEvents: mispricingResult,
          league,
          lighting_conditions,
        });
        break;

      default:
        return Response.json(
          { error: `Unknown package_type: ${package_type}` },
          { status: 400 },
        );
    }

    // Apply broadcast partner formatting
    const formattedPackage = formatForBroadcastPartner({
      arPackage,
      broadcast_partner,
      output_format,
    });

    // Apply lighting adaptation
    const adaptedPackage = adaptToLightingConditions({
      package: formattedPackage,
      lighting_conditions,
    });

    return Response.json({
      success: true,
      athlete_id,
      athlete_name: `${athlete.first_name} ${athlete.last_name}`,
      broadcast_partner,
      league,
      package_type,
      output_format,
      lighting_conditions,
      ar_package: adaptedPackage,
      metadata: {
        generated_at: new Date().toISOString(),
        readings_count: readings.length,
        has_valuation: !!valuation,
        mispricing_events: mispricingResult.length,
      },
    });
  } catch (error) {
    console.error("Broadcast AR package generation error:", error);
    return Response.json(
      { error: "Failed to generate AR package", details: error.message },
      { status: 500 },
    );
  }
}

// ================================================================================
// COACH COMPARISON VIEW
// ================================================================================
function generateCoachComparisonView({
  athlete,
  readings,
  valuation,
  league,
  lighting_conditions,
}) {
  const biometrics = aggregateBiometrics(readings);

  return {
    package_type: "coach_comparison_view",
    league,
    athlete: {
      id: athlete.id,
      name: `${athlete.first_name} ${athlete.last_name}`,
      position: athlete.position,
      team: athlete.team,
    },
    overlays: [
      {
        id: "performance_snapshot",
        type: "multi_metric_display",
        position: { x: 0.1, y: 0.1 },
        metrics: [
          {
            label: "Readiness",
            value: biometrics.readiness?.score || 0,
            color: getMetricColor(biometrics.readiness?.score || 0),
            trend: biometrics.readiness?.trend || "stable",
          },
          {
            label: "Fatigue",
            value: biometrics.fatigue?.score || 0,
            color: getInverseMetricColor(biometrics.fatigue?.score || 0),
            trend: biometrics.fatigue?.trend || "stable",
          },
          {
            label: "Recovery",
            value: biometrics.recovery?.score || 0,
            color: getMetricColor(biometrics.recovery?.score || 0),
            trend: biometrics.recovery?.trend || "stable",
          },
        ],
      },
      {
        id: "comparison_matrix",
        type: "side_by_side_comparison",
        position: { x: 0.5, y: 0.1 },
        data: {
          current_session: {
            label: "Current",
            readiness: biometrics.readiness?.score || 0,
            power: biometrics.power?.score || 0,
            speed: biometrics.speed?.score || 0,
          },
          baseline: {
            label: "Season Avg",
            readiness: biometrics.readiness?.baseline || 0,
            power: biometrics.power?.baseline || 0,
            speed: biometrics.speed?.baseline || 0,
          },
        },
      },
      {
        id: "substitution_recommendation",
        type: "decision_support",
        position: { x: 0.1, y: 0.7 },
        recommendation: generateSubstitutionRecommendation(biometrics),
        confidence: 0.85,
      },
    ],
    timing: {
      fade_in_ms: 300,
      display_duration_ms: 8000,
      fade_out_ms: 200,
    },
  };
}

// ================================================================================
// MEDICAL STAFF ALERTS
// ================================================================================
function generateMedicalStaffAlerts({
  athlete,
  readings,
  league,
  lighting_conditions,
}) {
  const biometrics = aggregateBiometrics(readings);
  const alerts = generateHealthAlerts(biometrics, athlete);

  return {
    package_type: "medical_staff_alerts",
    league,
    athlete: {
      id: athlete.id,
      name: `${athlete.first_name} ${athlete.last_name}`,
      position: athlete.position,
    },
    overlays: [
      {
        id: "health_status_banner",
        type: "alert_banner",
        position: { x: 0.5, y: 0.05 },
        severity: alerts.length > 0 ? alerts[0].severity : "normal",
        message: alerts.length > 0 ? alerts[0].message : "All systems normal",
      },
      {
        id: "injury_risk_heatmap",
        type: "body_heatmap",
        position: { x: 0.15, y: 0.2 },
        zones: generateInjuryRiskZones(biometrics),
      },
      {
        id: "vitals_monitor",
        type: "real_time_vitals",
        position: { x: 0.6, y: 0.2 },
        vitals: {
          heart_rate: biometrics.heart_rate?.score || 0,
          hrv: biometrics.hrv?.score || 0,
          respiratory_rate: biometrics.respiratory_rate?.score || 0,
          core_temp: biometrics.core_temp?.score || 98.6,
        },
      },
      {
        id: "alert_list",
        type: "scrolling_alerts",
        position: { x: 0.1, y: 0.75 },
        alerts: alerts.slice(0, 3),
      },
    ],
    timing: {
      fade_in_ms: 200,
      display_duration_ms: 12000,
      fade_out_ms: 200,
    },
    emergency_override: alerts.some((a) => a.severity === "critical"),
  };
}

// ================================================================================
// ROTATION OPTIMIZER
// ================================================================================
function generateRotationOptimizer({
  athlete,
  readings,
  valuation,
  league,
  lighting_conditions,
}) {
  const biometrics = aggregateBiometrics(readings);

  return {
    package_type: "rotation_optimizer",
    league,
    athlete: {
      id: athlete.id,
      name: `${athlete.first_name} ${athlete.last_name}`,
      position: athlete.position,
      minutes_played: 28, // Mock data - would come from game stats API
      recommended_minutes: calculateOptimalMinutes(biometrics),
    },
    overlays: [
      {
        id: "fatigue_curve",
        type: "trend_line_graph",
        position: { x: 0.1, y: 0.15 },
        data_points: generateFatigueCurve(biometrics),
        threshold_line: 0.7,
        current_position: 28,
      },
      {
        id: "rest_recommendation",
        type: "decision_card",
        position: { x: 0.55, y: 0.15 },
        recommendation: {
          action: biometrics.fatigue?.score > 0.7 ? "Rest Now" : "Continue",
          rationale:
            biometrics.fatigue?.score > 0.7
              ? "Fatigue exceeds safe threshold"
              : "Within optimal performance window",
          suggested_rest_minutes: biometrics.fatigue?.score > 0.7 ? 8 : 0,
        },
      },
      {
        id: "replacement_suggestions",
        type: "roster_list",
        position: { x: 0.1, y: 0.65 },
        suggestions: [
          { player: "Backup #12", readiness: 0.92, compatibility: 0.88 },
          { player: "Backup #24", readiness: 0.87, compatibility: 0.82 },
        ],
      },
    ],
    timing: {
      fade_in_ms: 250,
      display_duration_ms: 10000,
      fade_out_ms: 200,
    },
  };
}

// ================================================================================
// PERFORMANCE TRENDS PACKAGE
// ================================================================================
function generatePerformanceTrendPackage({
  athlete,
  readings,
  valuation,
  league,
  lighting_conditions,
}) {
  const biometrics = aggregateBiometrics(readings);

  return {
    package_type: "performance_trends",
    league,
    athlete: {
      id: athlete.id,
      name: `${athlete.first_name} ${athlete.last_name}`,
      position: athlete.position,
      nil_value: valuation ? parseFloat(valuation.true_value) : null,
    },
    overlays: [
      {
        id: "performance_timeline",
        type: "multi_line_chart",
        position: { x: 0.1, y: 0.1 },
        lines: [
          {
            label: "Power Output",
            color: "#3B82F6",
            data_points: generateTrendPoints(readings, "power"),
          },
          {
            label: "Speed Index",
            color: "#10B981",
            data_points: generateTrendPoints(readings, "speed"),
          },
          {
            label: "Endurance",
            color: "#F59E0B",
            data_points: generateTrendPoints(readings, "endurance"),
          },
        ],
      },
      {
        id: "momentum_indicator",
        type: "momentum_arrow",
        position: { x: 0.7, y: 0.15 },
        direction:
          biometrics.trend === "improving"
            ? "up"
            : biometrics.trend === "declining"
              ? "down"
              : "flat",
        intensity: 0.8,
      },
      {
        id: "nil_value_display",
        type: "value_card",
        position: { x: 0.7, y: 0.4 },
        value: valuation ? parseFloat(valuation.true_value) : 0,
        change_percentage: valuation ? parseFloat(valuation.gap_percentage) : 0,
        change_direction: valuation ? valuation.direction : "neutral",
      },
    ],
    timing: {
      fade_in_ms: 350,
      display_duration_ms: 15000,
      fade_out_ms: 250,
    },
  };
}

// ================================================================================
// SPONSOR ACTIVATION AR (Nike, Adidas, Gatorade, Beats)
// ================================================================================
function generateSponsorActivationAR({
  athlete,
  readings,
  valuation,
  mispricingEvents,
  league,
  lighting_conditions,
}) {
  const biometrics = aggregateBiometrics(readings);
  const nilMomentumWindows = mispricingEvents.map((event) => ({
    event_id: event.id,
    gap: parseFloat(event.gap),
    direction: event.direction,
    ttl_seconds: event.ttl_seconds,
    confidence: parseFloat(event.confidence),
  }));

  return {
    package_type: "sponsor_activation",
    league,
    athlete: {
      id: athlete.id,
      name: `${athlete.first_name} ${athlete.last_name}`,
      position: athlete.position,
      team: athlete.team,
    },
    overlays: [
      {
        id: "nil_momentum_window",
        type: "mispricing_alert",
        position: { x: 0.5, y: 0.1 },
        display: nilMomentumWindows.length > 0,
        data: nilMomentumWindows.length > 0 ? nilMomentumWindows[0] : null,
        visual: {
          border_color: "#C8A882", // Gold
          pulse_rate: 1.5,
          glow_intensity: 0.9,
        },
      },
      {
        id: "gold_glow_activation",
        type: "performance_highlight",
        position: { x: 0.5, y: 0.5 },
        trigger: biometrics.power?.score > 90 || biometrics.speed?.score > 90,
        visual: {
          glow_color: "#FFD700", // Gold
          particle_effects: true,
          duration_ms: 3000,
        },
      },
      {
        id: "brand_fit_indicator",
        type: "brand_alignment_meter",
        position: { x: 0.8, y: 0.3 },
        brands: [
          { name: "Nike", fit_score: 0.92, active: true },
          { name: "Gatorade", fit_score: 0.88, active: true },
          { name: "Beats", fit_score: 0.85, active: false },
        ],
      },
      {
        id: "activation_moment_badge",
        type: "sponsor_badge",
        position: { x: 0.1, y: 0.85 },
        sponsor_logo_url: "/sponsors/nike-logo.png", // Example
        activation_text: "Powered by Nike",
        display_duration_ms: 5000,
      },
    ],
    timing: {
      fade_in_ms: 200,
      display_duration_ms: 8000,
      fade_out_ms: 200,
    },
    activation_triggers: {
      performance_spike: biometrics.power?.score > 90,
      nil_window_active: nilMomentumWindows.length > 0,
      brand_fit_threshold_met: true,
    },
  };
}

// ================================================================================
// BROADCAST PARTNER FORMATTING
// ================================================================================
function formatForBroadcastPartner({
  arPackage,
  broadcast_partner,
  output_format,
}) {
  const formats = {
    ESPN: {
      aspect_ratio: "16:9",
      safe_zone_margin: 0.05,
      font_family: "ESPN Sans",
      color_scheme: "espn_red",
    },
    TNT: {
      aspect_ratio: "16:9",
      safe_zone_margin: 0.04,
      font_family: "TNT Sans",
      color_scheme: "tnt_blue",
    },
    "Amazon Prime": {
      aspect_ratio: "16:9",
      safe_zone_margin: 0.06,
      font_family: "Amazon Ember",
      color_scheme: "amazon_orange",
    },
    "Apple Sports": {
      aspect_ratio: "16:9",
      safe_zone_margin: 0.05,
      font_family: "SF Pro",
      color_scheme: "apple_white",
    },
  };

  const partnerFormat = formats[broadcast_partner] || formats["ESPN"];

  return {
    ...arPackage,
    broadcast_format: {
      partner: broadcast_partner,
      ...partnerFormat,
      resolution:
        output_format === "4K"
          ? "3840x2160"
          : output_format === "HDR"
            ? "3840x2160_HDR"
            : "1920x1080",
    },
  };
}

// ================================================================================
// LIGHTING ADAPTATION
// ================================================================================
function adaptToLightingConditions({
  package: arPackage,
  lighting_conditions,
}) {
  const adaptations = {
    bright_arena: {
      contrast_boost: 1.3,
      saturation: 1.2,
      outline_width: 3,
      shadow_opacity: 0.7,
    },
    dim_arena: {
      contrast_boost: 1.5,
      saturation: 1.4,
      outline_width: 4,
      shadow_opacity: 0.9,
    },
    outdoor_day: {
      contrast_boost: 1.6,
      saturation: 1.1,
      outline_width: 5,
      shadow_opacity: 0.95,
    },
    outdoor_night: {
      contrast_boost: 1.4,
      saturation: 1.3,
      outline_width: 3,
      shadow_opacity: 0.8,
    },
  };

  const adaptation =
    adaptations[lighting_conditions] || adaptations["bright_arena"];

  return {
    ...arPackage,
    lighting_adaptation: {
      conditions: lighting_conditions,
      ...adaptation,
    },
  };
}

// ================================================================================
// HELPER FUNCTIONS
// ================================================================================
function aggregateBiometrics(readings) {
  const grouped = {};

  readings.forEach((reading) => {
    if (!grouped[reading.cluster]) {
      grouped[reading.cluster] = [];
    }
    grouped[reading.cluster].push(reading);
  });

  const aggregated = {};
  for (const [cluster, clusterReadings] of Object.entries(grouped)) {
    if (clusterReadings.length > 0) {
      const latest = clusterReadings[0];
      aggregated[cluster.toLowerCase().replace(/ /g, "_")] = {
        score: parseFloat(latest.score),
        baseline: latest.baseline ? parseFloat(latest.baseline) : null,
        trend: latest.trend,
      };
    }
  }

  return aggregated;
}

function getMetricColor(score) {
  if (score >= 80) return "#10B981"; // Green
  if (score >= 60) return "#F59E0B"; // Yellow
  return "#EF4444"; // Red
}

function getInverseMetricColor(score) {
  if (score <= 30) return "#10B981"; // Green (low fatigue is good)
  if (score <= 60) return "#F59E0B"; // Yellow
  return "#EF4444"; // Red (high fatigue is bad)
}

function generateSubstitutionRecommendation(biometrics) {
  const fatigueScore = biometrics.fatigue?.score || 0;
  const readinessScore = biometrics.readiness?.score || 0;

  if (fatigueScore > 75 || readinessScore < 40) {
    return {
      action: "Substitute immediately",
      reason: "High fatigue and low readiness detected",
      urgency: "critical",
    };
  } else if (fatigueScore > 60 || readinessScore < 60) {
    return {
      action: "Consider substitution",
      reason: "Declining performance indicators",
      urgency: "warning",
    };
  }

  return {
    action: "Continue play",
    reason: "Optimal performance window",
    urgency: "normal",
  };
}

function generateHealthAlerts(biometrics, athlete) {
  const alerts = [];

  if (biometrics.fatigue?.score > 75) {
    alerts.push({
      severity: "critical",
      type: "fatigue",
      message: "Critical fatigue level detected",
      recommendation: "Immediate rest required",
    });
  }

  if (biometrics.recovery?.score < 40) {
    alerts.push({
      severity: "warning",
      type: "recovery",
      message: "Suboptimal recovery status",
      recommendation: "Monitor closely, reduce intensity",
    });
  }

  if (biometrics.hrv?.score < 50) {
    alerts.push({
      severity: "warning",
      type: "hrv",
      message: "Low heart rate variability",
      recommendation: "Check stress and recovery protocols",
    });
  }

  return alerts;
}

function generateInjuryRiskZones(biometrics) {
  return [
    { zone: "left_knee", risk_level: 0.3, color: "#10B981" },
    { zone: "right_knee", risk_level: 0.4, color: "#F59E0B" },
    { zone: "left_ankle", risk_level: 0.2, color: "#10B981" },
    { zone: "right_ankle", risk_level: 0.6, color: "#EF4444" },
    { zone: "lower_back", risk_level: 0.5, color: "#F59E0B" },
  ];
}

function calculateOptimalMinutes(biometrics) {
  const fatigueScore = biometrics.fatigue?.score || 0;
  const readinessScore = biometrics.readiness?.score || 100;

  // Simple algorithm: reduce minutes if fatigue is high or readiness is low
  const baseMinutes = 36;
  const fatigueReduction = (fatigueScore / 100) * 12; // Up to 12 minutes reduction
  const readinessBonus = ((readinessScore - 50) / 100) * 6; // Up to 6 minutes bonus

  return Math.max(
    20,
    Math.min(40, baseMinutes - fatigueReduction + readinessBonus),
  );
}

function generateFatigueCurve(biometrics) {
  // Mock data - would come from real-time tracking
  return [
    { minute: 0, fatigue: 0.1 },
    { minute: 8, fatigue: 0.25 },
    { minute: 16, fatigue: 0.42 },
    { minute: 24, fatigue: 0.58 },
    { minute: 28, fatigue: biometrics.fatigue?.score / 100 || 0.65 },
  ];
}

function generateTrendPoints(readings, metric_type) {
  // Mock data - would extract from historical readings
  const now = Date.now();
  return [
    { timestamp: now - 7 * 24 * 60 * 60 * 1000, value: 75 },
    { timestamp: now - 5 * 24 * 60 * 60 * 1000, value: 78 },
    { timestamp: now - 3 * 24 * 60 * 60 * 1000, value: 82 },
    { timestamp: now - 1 * 24 * 60 * 60 * 1000, value: 85 },
    { timestamp: now, value: 88 },
  ];
}
