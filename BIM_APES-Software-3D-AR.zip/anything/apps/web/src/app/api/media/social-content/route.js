import sql from "@/app/api/utils/sql";

/**
 * POST /api/media/social-content
 * Social media content generation for highlights
 * Creates platform-optimized content with AR overlays, captions, hashtags
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      highlight_id = null,
      highlight_data,
      platforms = ["instagram", "tiktok", "twitter", "youtube"], // Target platforms
      include_nil_data = false,
      include_sponsor_overlay = false,
      timestamp = new Date().toISOString(),
    } = body;

    if (!athlete_id || !highlight_data) {
      return Response.json(
        { success: false, error: "athlete_id and highlight_data are required" },
        { status: 400 },
      );
    }

    // Get athlete data
    const athletes = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 400 },
      );
    }

    const athlete = athletes[0];

    // Get NIL valuation if needed
    let nilValuation = null;
    if (include_nil_data) {
      const nilData = await sql`
        SELECT * FROM nil_valuations
        WHERE athlete_id = ${athlete_id}
        ORDER BY calculated_at DESC
        LIMIT 1
      `;
      nilValuation = nilData[0] || null;
    }

    // Get active sponsor campaigns if needed
    let sponsorCampaign = null;
    if (include_sponsor_overlay) {
      const campaigns = await sql`
        SELECT * FROM sponsor_campaigns
        WHERE status = 'active'
        ORDER BY created_at DESC
        LIMIT 1
      `;
      sponsorCampaign = campaigns[0] || null;
    }

    // Generate platform-specific content
    const content = generateSocialContent(
      athlete,
      highlight_data,
      platforms,
      nilValuation,
      sponsorCampaign,
    );

    // Log generation
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'social_content_generation',
        ${athlete_id},
        'generate_content',
        'social_content_engine',
        ${JSON.stringify({ platforms, highlight_type: highlight_data.type })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      athlete_id,
      athlete_name: `${athlete.first_name} ${athlete.last_name}`,
      content,
      platforms,
      timestamp,
    });
  } catch (error) {
    console.error("Social content generation error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === CONTENT GENERATION ENGINE ===

function generateSocialContent(
  athlete,
  highlightData,
  platforms,
  nilValuation,
  sponsorCampaign,
) {
  const content = {};

  platforms.forEach((platform) => {
    content[platform] = generatePlatformContent(
      platform,
      athlete,
      highlightData,
      nilValuation,
      sponsorCampaign,
    );
  });

  return content;
}

function generatePlatformContent(
  platform,
  athlete,
  highlight,
  nilValuation,
  sponsor,
) {
  const athleteName = `${athlete.first_name} ${athlete.last_name}`;
  const sport = athlete.sport;

  // Generate base caption
  let caption = generateCaption(athleteName, sport, highlight, nilValuation);

  // Add sponsor overlay if present
  if (sponsor) {
    caption += `\n\n${sponsor.activation_text || `Powered by ${sponsor.sponsor_name}`}`;
  }

  // Generate hashtags
  const hashtags = generateHashtags(sport, highlight, nilValuation, sponsor);

  // Platform-specific formatting
  const platformContent = {
    instagram: {
      caption: caption,
      hashtags: hashtags.slice(0, 30).join(" "), // Instagram limit
      aspect_ratio: "4:5", // Portrait
      duration_seconds: Math.min(highlight.duration_seconds, 60),
      overlay_style: "vibrant",
      music_recommendation: getMusicRecommendation(highlight.type),
      story_format: {
        caption: shortenCaption(caption, 100),
        stickers: ["poll", "quiz", "countdown"],
      },
      reels_format: {
        caption: caption,
        trending_audio: true,
        cover_frame_time: highlight.start_time + 2,
      },
    },
    tiktok: {
      caption: shortenCaption(caption, 150),
      hashtags: hashtags.slice(0, 10).join(" "),
      aspect_ratio: "9:16", // Vertical
      duration_seconds: Math.min(highlight.duration_seconds, 60),
      overlay_style: "dynamic",
      trending_sounds: true,
      effects: ["speed_ramp", "transition", "text_overlay"],
    },
    twitter: {
      caption: shortenCaption(
        caption,
        280 - hashtags.slice(0, 3).join(" ").length - 10,
      ),
      hashtags: hashtags.slice(0, 3).join(" "),
      aspect_ratio: "16:9", // Landscape
      duration_seconds: Math.min(highlight.duration_seconds, 140),
      overlay_style: "clean",
      thread_mode: caption.length > 280,
    },
    youtube: {
      title: generateYouTubeTitle(athleteName, highlight),
      description: generateYouTubeDescription(
        athleteName,
        sport,
        highlight,
        nilValuation,
        sponsor,
      ),
      hashtags: hashtags.slice(0, 15).join(" "),
      aspect_ratio: "16:9",
      duration_seconds: highlight.duration_seconds,
      overlay_style: "professional",
      thumbnail_timestamp: highlight.start_time + 3,
      shorts_format: {
        title: shortenCaption(
          generateYouTubeTitle(athleteName, highlight),
          100,
        ),
        aspect_ratio: "9:16",
        duration_seconds: Math.min(highlight.duration_seconds, 60),
      },
    },
  };

  // Add AR overlay specifications
  platformContent[platform].ar_overlays =
    highlight.ar_overlay_suggestions || [];
  platformContent[platform].highlight_metadata = {
    type: highlight.type,
    priority_score: highlight.priority_score,
    tags: highlight.tags,
  };

  return platformContent[platform];
}

function generateCaption(athleteName, sport, highlight, nilValuation) {
  const captionTemplates = {
    power_burst: `🔥 ${athleteName} unleashing POWER! ${highlight.description}`,
    speed_burst: `⚡ ${athleteName} with ELITE SPEED! ${highlight.description}`,
    nil_value_surge: `📈 ${athleteName}'s value SURGING! ${highlight.description}`,
    grit_moment: `💪 ${athleteName} showing CLUTCH performance! ${highlight.description}`,
    emotional_high: `🎉 ${athleteName} CELEBRATION MODE! ${highlight.description}`,
    recovery_resilience: `🔄 ${athleteName} recovery game on point! ${highlight.description}`,
    sponsor_hydration_moment: `💧 ${athleteName} staying locked in! ${highlight.description}`,
    sponsor_gear_performance: `👟 ${athleteName} at peak performance! ${highlight.description}`,
  };

  let caption =
    captionTemplates[highlight.type] ||
    `${athleteName} highlight: ${highlight.description}`;

  // Add NIL context if available
  if (nilValuation && nilValuation.gap_percentage > 10) {
    caption += `\n\n💰 NIL Market Alert: ${nilValuation.gap_percentage.toFixed(0)}% value opportunity`;
  }

  return caption;
}

function generateHashtags(sport, highlight, nilValuation, sponsor) {
  const hashtags = ["#BIMAPES", `#${sport.replace(/\s+/g, "")}`];

  // Highlight type hashtags
  if (highlight.tags) {
    highlight.tags.forEach((tag) => {
      hashtags.push(`#${tag.replace(/\s+/g, "")}`);
    });
  }

  // Performance hashtags
  if (highlight.type.includes("power")) {
    hashtags.push("#PowerPerformance", "#Strength", "#Explosive");
  }
  if (highlight.type.includes("speed")) {
    hashtags.push("#Speed", "#Fast", "#EliteAthlete");
  }
  if (highlight.type.includes("recovery")) {
    hashtags.push("#Recovery", "#Training", "#Fitness");
  }

  // NIL hashtags
  if (nilValuation) {
    hashtags.push("#NIL", "#AthleteValue", "#SportsBusiness");
  }

  // Sponsor hashtags
  if (sponsor) {
    const sponsorTag = sponsor.sponsor_name.replace(/\s+/g, "");
    hashtags.push(`#${sponsorTag}`, "#Sponsored");
  }

  // General sports hashtags
  hashtags.push(
    "#Sports",
    "#Athlete",
    "#Performance",
    "#HighlightReel",
    "#SportsScience",
  );

  return hashtags;
}

function getMusicRecommendation(highlightType) {
  const musicMap = {
    power_burst: "High-energy hip-hop or electronic",
    speed_burst: "Fast-tempo electronic or rock",
    nil_value_surge: "Motivational hip-hop",
    grit_moment: "Intense orchestral or dramatic",
    emotional_high: "Upbeat pop or celebratory",
    recovery_resilience: "Inspirational or ambient",
  };

  return musicMap[highlightType] || "Trending sports music";
}

function shortenCaption(caption, maxLength) {
  if (caption.length <= maxLength) return caption;
  return caption.substring(0, maxLength - 3) + "...";
}

function generateYouTubeTitle(athleteName, highlight) {
  const titleTemplates = {
    power_burst: `${athleteName} - INSANE Power Display! 🔥`,
    speed_burst: `${athleteName} - Elite Speed Showcase ⚡`,
    nil_value_surge: `${athleteName} - NIL Value SURGING 📈`,
    grit_moment: `${athleteName} - CLUTCH Performance Under Pressure 💪`,
    emotional_high: `${athleteName} - Epic Celebration Moment! 🎉`,
    recovery_resilience: `${athleteName} - Exceptional Recovery 🔄`,
    sponsor_hydration_moment: `${athleteName} - Peak Performance Mode 💧`,
    sponsor_gear_performance: `${athleteName} - Dominating Performance 👟`,
  };

  return (
    titleTemplates[highlight.type] ||
    `${athleteName} - ${highlight.description}`
  );
}

function generateYouTubeDescription(
  athleteName,
  sport,
  highlight,
  nilValuation,
  sponsor,
) {
  let description = `Watch ${athleteName} in action!\n\n`;
  description += `${highlight.description}\n\n`;

  if (highlight.metrics) {
    description += `📊 Performance Metrics:\n`;
    Object.entries(highlight.metrics).forEach(([key, value]) => {
      description += `• ${key.replace(/_/g, " ")}: ${typeof value === "number" ? value.toFixed(1) : value}\n`;
    });
    description += "\n";
  }

  if (nilValuation) {
    description += `💰 NIL Insights:\n`;
    description += `• Market Value: $${nilValuation.market_value.toLocaleString()}\n`;
    description += `• True Value: $${nilValuation.true_value.toLocaleString()}\n`;
    description += `• Value Gap: ${nilValuation.gap_percentage.toFixed(1)}%\n\n`;
  }

  if (sponsor) {
    description += `Powered by ${sponsor.sponsor_name}\n\n`;
  }

  description += `🏆 About BIM-APES:\n`;
  description += `Advanced biometric intelligence and NIL valuation platform for athletes.\n\n`;

  description += `#${sport.replace(/\s+/g, "")} #BIMAPES #Performance #NIL`;

  return description;
}
