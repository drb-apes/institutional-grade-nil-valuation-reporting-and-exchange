import sql from "@/app/api/utils/sql";

/**
 * POST /api/media/auto-highlight
 * Automatic highlight generation engine
 * Detects NIL momentum, spike moments, sponsor resonance
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      game_id = null,
      session_id = null,
      video_duration_seconds,
      analysis_mode = "full", // 'full', 'nil_only', 'sponsor_only', 'performance_only'
      timestamp = new Date().toISOString(),
    } = body;

    if (!athlete_id || !video_duration_seconds) {
      return Response.json(
        {
          success: false,
          error: "athlete_id and video_duration_seconds are required",
        },
        { status: 400 },
      );
    }

    // Get athlete data
    const athletes = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 400 },
      );
    }

    const athlete = athletes[0];

    // Get recent biometric readings
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const readings = await sql`
      SELECT br.*, bid.domain, bid.cluster, bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > ${oneHourAgo}
      ORDER BY br.recorded_at DESC
    `;

    // Get NIL valuation
    const nilValuations = await sql`
      SELECT * FROM nil_valuations
      WHERE athlete_id = ${athlete_id}
      ORDER BY calculated_at DESC
      LIMIT 1
    `;

    // Get sponsor campaigns
    const activeCampaigns = await sql`
      SELECT * FROM sponsor_campaigns
      WHERE status = 'active'
        AND campaign_start <= NOW()
        AND campaign_end >= NOW()
      ORDER BY created_at DESC
      LIMIT 10
    `;

    // Generate highlights based on analysis mode
    const highlights = await generateHighlights(
      athlete,
      readings,
      nilValuations[0],
      activeCampaigns,
      video_duration_seconds,
      analysis_mode,
    );

    // Log generation
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'auto_highlight_generation',
        ${athlete_id},
        'generate_highlights',
        'auto_highlight_engine',
        ${JSON.stringify({ highlights_count: highlights.length, analysis_mode })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      athlete_id,
      athlete_name: `${athlete.first_name} ${athlete.last_name}`,
      highlights,
      highlight_count: highlights.length,
      total_highlight_duration: highlights.reduce(
        (sum, h) => sum + h.duration_seconds,
        0,
      ),
      analysis_mode,
      timestamp,
    });
  } catch (error) {
    console.error("Auto highlight error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/media/auto-highlight
 * Get highlight generation history
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");
    const limit = parseInt(searchParams.get("limit") || "50");

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    const history = await sql`
      SELECT * FROM audit_logs
      WHERE entity_type = 'auto_highlight_generation'
        AND entity_id = ${athlete_id}
      ORDER BY created_at DESC
      LIMIT ${limit}
    `;

    return Response.json({
      success: true,
      athlete_id,
      history,
    });
  } catch (error) {
    console.error("Highlight history error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HIGHLIGHT GENERATION ENGINE ===

async function generateHighlights(
  athlete,
  readings,
  nilValuation,
  campaigns,
  videoDuration,
  mode,
) {
  const highlights = [];

  // Performance spike moments
  if (mode === "full" || mode === "performance_only") {
    const performanceHighlights = detectPerformanceSpikes(
      readings,
      videoDuration,
    );
    highlights.push(...performanceHighlights);
  }

  // NIL momentum moments
  if (mode === "full" || mode === "nil_only") {
    const nilHighlights = detectNILMomentum(
      nilValuation,
      readings,
      videoDuration,
    );
    highlights.push(...nilHighlights);
  }

  // Sponsor resonance moments
  if (mode === "full" || mode === "sponsor_only") {
    const sponsorHighlights = detectSponsorResonance(
      campaigns,
      readings,
      videoDuration,
    );
    highlights.push(...sponsorHighlights);
  }

  // Emotional engagement moments
  if (mode === "full") {
    const emotionalHighlights = detectEmotionalEngagement(
      readings,
      videoDuration,
    );
    highlights.push(...emotionalHighlights);
  }

  // Sort by priority score
  highlights.sort((a, b) => b.priority_score - a.priority_score);

  // Add AR overlay suggestions
  highlights.forEach((highlight) => {
    highlight.ar_overlay_suggestions = suggestAROverlays(highlight);
  });

  return highlights;
}

function detectPerformanceSpikes(readings, videoDuration) {
  const highlights = [];

  // Power bursts
  const powerReadings = readings.filter(
    (r) => r.index_code === "MPOi" || r.index_code === "EPi",
  );
  powerReadings.forEach((reading, idx) => {
    if (reading.score > 85) {
      highlights.push({
        type: "power_burst",
        start_time: (idx / powerReadings.length) * videoDuration,
        duration_seconds: 8,
        priority_score: 0.85,
        description: `Peak power output: ${reading.score.toFixed(0)}%`,
        metrics: {
          power_score: reading.score,
          index_code: reading.index_code,
        },
        tags: ["performance", "power", "athleticism"],
      });
    }
  });

  // Speed bursts
  const speedReadings = readings.filter((r) => r.index_code === "SSi");
  speedReadings.forEach((reading, idx) => {
    if (reading.score > 90) {
      highlights.push({
        type: "speed_burst",
        start_time: (idx / speedReadings.length) * videoDuration,
        duration_seconds: 6,
        priority_score: 0.82,
        description: `Elite speed: ${reading.score.toFixed(0)}%`,
        metrics: {
          speed_score: reading.score,
        },
        tags: ["performance", "speed", "explosive"],
      });
    }
  });

  // Recovery resilience
  const recoveryReadings = readings.filter((r) => r.index_code === "RRi");
  recoveryReadings.forEach((reading, idx) => {
    if (reading.score > 88 && reading.trend === "improving") {
      highlights.push({
        type: "recovery_resilience",
        start_time: (idx / recoveryReadings.length) * videoDuration,
        duration_seconds: 10,
        priority_score: 0.75,
        description: `Exceptional recovery: ${reading.score.toFixed(0)}%`,
        metrics: {
          recovery_score: reading.score,
          trend: reading.trend,
        },
        tags: ["performance", "resilience", "endurance"],
      });
    }
  });

  return highlights;
}

function detectNILMomentum(nilValuation, readings, videoDuration) {
  const highlights = [];

  if (!nilValuation) return highlights;

  // NIL value surge
  if (nilValuation.gap_percentage > 15 && nilValuation.direction === "long") {
    highlights.push({
      type: "nil_value_surge",
      start_time: videoDuration * 0.25, // Mid-game surge
      duration_seconds: 12,
      priority_score: 0.92,
      description: `NIL value up ${nilValuation.gap_percentage.toFixed(1)}% - market undervaluing talent`,
      metrics: {
        true_value: nilValuation.true_value,
        market_value: nilValuation.market_value,
        gap: nilValuation.gap,
        gap_percentage: nilValuation.gap_percentage,
        confidence: nilValuation.confidence,
      },
      tags: ["nil", "momentum", "valuation", "opportunity"],
    });
  }

  // Momentum intensity spike
  if (nilValuation.momentum_intensity > 0.85) {
    highlights.push({
      type: "momentum_spike",
      start_time: videoDuration * 0.6, // Late-game momentum
      duration_seconds: 10,
      priority_score: 0.88,
      description: `Peak momentum intensity: ${(nilValuation.momentum_intensity * 100).toFixed(0)}%`,
      metrics: {
        momentum_intensity: nilValuation.momentum_intensity,
        convexity_factor: nilValuation.convexity_factor,
      },
      tags: ["nil", "momentum", "engagement"],
    });
  }

  return highlights;
}

function detectSponsorResonance(campaigns, readings, videoDuration) {
  const highlights = [];

  campaigns.forEach((campaign, idx) => {
    // Hydration sponsor moment (if campaign type matches)
    if (
      campaign.campaign_type.includes("hydration") ||
      campaign.sponsor_name.toLowerCase().includes("gatorade")
    ) {
      highlights.push({
        type: "sponsor_hydration_moment",
        start_time: (idx / campaigns.length) * videoDuration,
        duration_seconds: 8,
        priority_score: 0.78,
        description: `${campaign.sponsor_name} - Optimal hydration performance`,
        sponsor: {
          name: campaign.sponsor_name,
          logo_url: campaign.logo_url,
          activation_text: campaign.activation_text,
        },
        tags: ["sponsor", "activation", "branded_content"],
      });
    }

    // Performance gear sponsor moment
    if (
      campaign.campaign_type.includes("gear") ||
      campaign.sponsor_name.toLowerCase().includes("nike")
    ) {
      highlights.push({
        type: "sponsor_gear_performance",
        start_time: (idx / campaigns.length) * videoDuration + 15,
        duration_seconds: 10,
        priority_score: 0.8,
        description: `${campaign.sponsor_name} - Peak performance showcase`,
        sponsor: {
          name: campaign.sponsor_name,
          logo_url: campaign.logo_url,
          activation_text: campaign.activation_text,
        },
        tags: ["sponsor", "activation", "performance_gear"],
      });
    }
  });

  return highlights;
}

function detectEmotionalEngagement(readings, videoDuration) {
  const highlights = [];

  // Joy moments
  const joyReadings = readings.filter((r) => r.index_code === "BJi");
  joyReadings.forEach((reading, idx) => {
    if (reading.score > 80) {
      highlights.push({
        type: "emotional_high",
        start_time: (idx / joyReadings.length) * videoDuration,
        duration_seconds: 7,
        priority_score: 0.72,
        description: `Celebration moment - high engagement potential`,
        metrics: {
          joy_score: reading.score,
        },
        tags: ["emotional", "celebration", "fan_engagement"],
      });
    }
  });

  // Grit moments (stress + resilience)
  const stressReadings = readings.filter((r) => r.index_code === "SRi");
  const resilienceReadings = readings.filter((r) => r.index_code === "ERi");

  if (stressReadings.length > 0 && resilienceReadings.length > 0) {
    stressReadings.forEach((stress, idx) => {
      const resilience = resilienceReadings[idx];
      if (stress.score > 70 && resilience && resilience.score > 75) {
        highlights.push({
          type: "grit_moment",
          start_time: (idx / stressReadings.length) * videoDuration,
          duration_seconds: 12,
          priority_score: 0.86,
          description: `Clutch performance under pressure`,
          metrics: {
            stress_level: stress.score,
            resilience_score: resilience.score,
          },
          tags: ["emotional", "clutch", "resilience", "storytelling"],
        });
      }
    });
  }

  return highlights;
}

function suggestAROverlays(highlight) {
  const overlays = [];

  switch (highlight.type) {
    case "power_burst":
      overlays.push(
        "power_vector_overlay",
        "force_heatmap",
        "muscle_activation_visual",
      );
      break;
    case "speed_burst":
      overlays.push("speed_trail", "velocity_arrow", "acceleration_graph");
      break;
    case "nil_value_surge":
      overlays.push(
        "nil_momentum_arrow",
        "valuation_comparison",
        "market_gap_indicator",
      );
      break;
    case "sponsor_hydration_moment":
    case "sponsor_gear_performance":
      overlays.push(
        "sponsor_badge",
        "branded_performance_metric",
        "product_highlight",
      );
      break;
    case "grit_moment":
      overlays.push("stress_cone", "resilience_ring", "heart_rate_graph");
      break;
    case "emotional_high":
      overlays.push(
        "celebration_burst",
        "fan_engagement_meter",
        "social_share_prompt",
      );
      break;
    default:
      overlays.push("generic_performance_overlay");
  }

  return overlays;
}
