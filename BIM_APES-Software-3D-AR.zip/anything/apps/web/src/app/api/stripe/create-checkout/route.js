import {
  internalError,
  validationError,
  successResponse,
} from "@/app/api/utils/errorHandler";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      tier,
      billingPeriod,
      organizationName,
      contactEmail,
      studentCount,
    } = body;

    // Validate required fields
    if (!tier || !billingPeriod) {
      return validationError("Missing required fields: tier and billingPeriod");
    }

    // Pricing tiers
    const pricing = {
      school: { monthly: 29900, annual: 299000 },
      district: { monthly: 99900, annual: 999000 },
      regional: { monthly: 249900, annual: 2499000 },
      statewide: { monthly: 499900, annual: 4999000 },
    };

    const tierNames = {
      school: "School License",
      district: "District License",
      regional: "Regional License",
      statewide: "Statewide License",
    };

    if (!pricing[tier] || !pricing[tier][billingPeriod]) {
      return validationError("Invalid tier or billing period");
    }

    const amount = pricing[tier][billingPeriod];
    const tierName = tierNames[tier];

    // If Stripe is configured, create real session
    if (
      process.env.STRIPE_SECRET_KEY &&
      process.env.STRIPE_SECRET_KEY !== "sk_test_placeholder"
    ) {
      const Stripe = (await import("stripe")).default;
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: `BIM-APES ${tierName}`,
                description: `${billingPeriod === "monthly" ? "Monthly" : "Annual"} subscription for ${studentCount || "unlimited"} student athletes`,
              },
              unit_amount: amount,
              recurring:
                billingPeriod === "monthly"
                  ? {
                      interval: "month",
                    }
                  : {
                      interval: "year",
                    },
            },
            quantity: 1,
          },
        ],
        mode: "subscription",
        success_url: `${process.env.NEXT_PUBLIC_CREATE_APP_URL || "http://localhost:3000"}/demo/launch-dashboard?success=true&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.NEXT_PUBLIC_CREATE_APP_URL || "http://localhost:3000"}/demo/launch-dashboard?canceled=true`,
        customer_email: contactEmail,
        metadata: {
          tier,
          billingPeriod,
          organizationName: organizationName || "",
          studentCount: studentCount || "0",
        },
      });

      // Store order in database
      try {
        await sql`
          INSERT INTO sponsor_campaigns (
            sponsor_name,
            campaign_name,
            campaign_type,
            pricing_model,
            flat_fee_amount,
            campaign_start,
            campaign_end,
            status,
            activation_text
          ) VALUES (
            ${organizationName || "Direct License Purchase"},
            ${`${tierName} - ${billingPeriod}`},
            'licensing',
            ${billingPeriod === "monthly" ? "monthly_subscription" : "annual_subscription"},
            ${amount / 100},
            NOW(),
            NOW() + INTERVAL '90 days',
            'pending_payment',
            ${JSON.stringify({ stripeSessionId: session.id, email: contactEmail })}
          )
        `;
      } catch (dbError) {
        console.error("Database insert error:", dbError);
        // Continue even if DB insert fails - payment is more important
      }

      return successResponse({
        checkoutUrl: session.url,
        sessionId: session.id,
        amount: amount / 100,
        tier: tierName,
        billingPeriod,
      });
    }

    // Demo mode fallback when Stripe is not configured
    const demoSessionId = `cs_demo_${Date.now()}_${tier}_${billingPeriod}`;

    // Store demo order
    try {
      await sql`
        INSERT INTO sponsor_campaigns (
          sponsor_name,
          campaign_name,
          campaign_type,
          pricing_model,
          flat_fee_amount,
          campaign_start,
          campaign_end,
          status,
          activation_text
        ) VALUES (
          ${organizationName || "Demo License Purchase"},
          ${`${tierName} - ${billingPeriod} (DEMO)`},
          'licensing',
          ${billingPeriod === "monthly" ? "monthly_subscription" : "annual_subscription"},
          ${amount / 100},
          NOW(),
          NOW() + INTERVAL '90 days',
          'demo_active',
          ${JSON.stringify({ demoSessionId, email: contactEmail, studentCount })}
        )
      `;
    } catch (dbError) {
      console.error("Database insert error:", dbError);
    }

    return successResponse({
      checkoutUrl: `/demo/launch-dashboard?success=true&session_id=${demoSessionId}&demo=true`,
      sessionId: demoSessionId,
      amount: amount / 100,
      tier: tierName,
      billingPeriod,
      demo: true,
    });
  } catch (error) {
    console.error("Stripe checkout error:", error);
    return internalError(error, "checkout session creation");
  }
}
