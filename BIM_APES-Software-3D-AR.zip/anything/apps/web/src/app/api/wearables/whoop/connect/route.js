import sql from "@/app/api/utils/sql";

/**
 * POST /api/wearables/whoop/connect
 * Initiates Whoop OAuth connection for an athlete
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      redirect_uri = `${process.env.NEXT_PUBLIC_CREATE_APP_URL}/wearables/callback`,
    } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Verify athlete exists
    const athleteRows = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteRows.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 404 },
      );
    }

    // Generate OAuth state for security
    const state = `${athlete_id}-${Date.now()}-${Math.random().toString(36).substring(7)}`;

    // Whoop OAuth authorization URL
    const authUrl = new URL("https://api.prod.whoop.com/oauth/oauth2/auth");
    authUrl.searchParams.append(
      "client_id",
      process.env.WHOOP_CLIENT_ID || "demo_client_id",
    );
    authUrl.searchParams.append("response_type", "code");
    authUrl.searchParams.append("redirect_uri", redirect_uri);
    authUrl.searchParams.append("state", state);
    authUrl.searchParams.append(
      "scope",
      "read:recovery read:cycles read:sleep read:workout read:profile",
    );

    return Response.json({
      success: true,
      authorization_url: authUrl.toString(),
      state,
      provider: "whoop",
      athlete_id,
    });
  } catch (error) {
    console.error("Whoop connect error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/wearables/whoop/connect?code=...&state=...
 * OAuth callback handler for Whoop
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get("code");
    const state = searchParams.get("state");

    if (!code || !state) {
      return Response.json(
        { success: false, error: "Missing OAuth code or state" },
        { status: 400 },
      );
    }

    // Extract athlete_id from state
    const athlete_id = state.split("-")[0];

    // Exchange code for access token
    const tokenResponse = await fetch(
      "https://api.prod.whoop.com/oauth/oauth2/token",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          client_id: process.env.WHOOP_CLIENT_ID || "demo_client_id",
          client_secret: process.env.WHOOP_CLIENT_SECRET || "demo_secret",
          redirect_uri: `${process.env.NEXT_PUBLIC_CREATE_APP_URL}/wearables/callback`,
        }),
      },
    );

    if (!tokenResponse.ok) {
      throw new Error("Failed to exchange OAuth code for token");
    }

    const tokenData = await tokenResponse.json();

    // Store connection in database (using compliance table for now)
    await sql`
      INSERT INTO compliance_checks (
        athlete_id,
        check_type,
        status,
        details,
        checked_by
      ) VALUES (
        ${athlete_id},
        'whoop_connected',
        'active',
        ${JSON.stringify({
          access_token: tokenData.access_token,
          refresh_token: tokenData.refresh_token,
          expires_at: new Date(
            Date.now() + tokenData.expires_in * 1000,
          ).toISOString(),
          scope: tokenData.scope,
        })},
        'BIM-APES Wearables'
      )
      ON CONFLICT (id) DO UPDATE SET
        status = 'active',
        details = EXCLUDED.details,
        checked_at = NOW()
    `;

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'wearable_connection',
        ${athlete_id},
        'whoop_connect',
        'BIM-APES Wearables',
        ${JSON.stringify({ provider: "whoop", scope: tokenData.scope })}
      )
    `;

    return Response.json({
      success: true,
      message: "Whoop connected successfully",
      athlete_id,
      provider: "whoop",
      connected_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Whoop OAuth callback error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
