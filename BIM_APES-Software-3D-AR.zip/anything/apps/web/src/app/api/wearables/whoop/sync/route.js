import sql from "@/app/api/utils/sql";

/**
 * POST /api/wearables/whoop/sync
 * Syncs biometric data from Whoop for an athlete
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const { athlete_id, data_types = ["recovery", "sleep", "workout"] } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get Whoop connection details
    const connectionRows = await sql`
      SELECT details
      FROM compliance_checks
      WHERE athlete_id = ${athlete_id}
        AND check_type = 'whoop_connected'
        AND status = 'active'
      ORDER BY checked_at DESC
      LIMIT 1
    `;

    if (connectionRows.length === 0) {
      return Response.json(
        { success: false, error: "Whoop not connected for this athlete" },
        { status: 404 },
      );
    }

    const connection = connectionRows[0].details;
    const access_token = connection.access_token;

    const synced_data = [];
    const readings_inserted = [];

    // Sync Recovery Data
    if (data_types.includes("recovery")) {
      const recoveryData = await fetchWhoopRecovery(access_token);

      if (recoveryData && recoveryData.length > 0) {
        const latest = recoveryData[0];

        // Insert HRV reading
        if (latest.score?.hrv_rmssd_milli) {
          const hrvReading = await sql`
            INSERT INTO biometric_readings (
              athlete_id,
              index_code,
              score,
              context,
              recorded_at
            ) VALUES (
              ${athlete_id},
              'HRVi',
              ${latest.score.hrv_rmssd_milli / 10},
              'whoop_sync',
              ${latest.created_at}
            )
            RETURNING *
          `;
          readings_inserted.push(hrvReading[0]);
        }

        // Insert Recovery Score
        if (latest.score?.recovery_score) {
          const recoveryReading = await sql`
            INSERT INTO biometric_readings (
              athlete_id,
              index_code,
              score,
              context,
              recorded_at
            ) VALUES (
              ${athlete_id},
              'RRi',
              ${latest.score.recovery_score},
              'whoop_sync',
              ${latest.created_at}
            )
            RETURNING *
          `;
          readings_inserted.push(recoveryReading[0]);
        }

        synced_data.push({ type: "recovery", count: recoveryData.length });
      }
    }

    // Sync Sleep Data
    if (data_types.includes("sleep")) {
      const sleepData = await fetchWhoopSleep(access_token);

      if (sleepData && sleepData.length > 0) {
        const latest = sleepData[0];

        // Insert Sleep Quality
        if (latest.score?.sleep_performance_percentage) {
          const sleepReading = await sql`
            INSERT INTO biometric_readings (
              athlete_id,
              index_code,
              score,
              context,
              recorded_at
            ) VALUES (
              ${athlete_id},
              'SQi',
              ${latest.score.sleep_performance_percentage},
              'whoop_sync',
              ${latest.created_at}
            )
            RETURNING *
          `;
          readings_inserted.push(sleepReading[0]);
        }

        synced_data.push({ type: "sleep", count: sleepData.length });
      }
    }

    // Sync Workout Data
    if (data_types.includes("workout")) {
      const workoutData = await fetchWhoopWorkout(access_token);

      if (workoutData && workoutData.length > 0) {
        synced_data.push({ type: "workout", count: workoutData.length });
      }
    }

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'wearable_sync',
        ${athlete_id},
        'whoop_sync',
        'BIM-APES Wearables',
        ${JSON.stringify({ data_types, synced_data })}
      )
    `;

    return Response.json({
      success: true,
      athlete_id,
      provider: "whoop",
      synced_data,
      readings_inserted: readings_inserted.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Whoop sync error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HELPER FUNCTIONS ===

async function fetchWhoopRecovery(access_token) {
  try {
    const response = await fetch(
      "https://api.prod.whoop.com/developer/v1/recovery",
      {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
      },
    );

    if (!response.ok) {
      console.error("Whoop recovery fetch failed:", response.statusText);
      return [];
    }

    const data = await response.json();
    return data.records || [];
  } catch (error) {
    console.error("Whoop recovery fetch error:", error);
    return [];
  }
}

async function fetchWhoopSleep(access_token) {
  try {
    const response = await fetch(
      "https://api.prod.whoop.com/developer/v1/activity/sleep",
      {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
      },
    );

    if (!response.ok) {
      console.error("Whoop sleep fetch failed:", response.statusText);
      return [];
    }

    const data = await response.json();
    return data.records || [];
  } catch (error) {
    console.error("Whoop sleep fetch error:", error);
    return [];
  }
}

async function fetchWhoopWorkout(access_token) {
  try {
    const response = await fetch(
      "https://api.prod.whoop.com/developer/v1/activity/workout",
      {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
      },
    );

    if (!response.ok) {
      console.error("Whoop workout fetch failed:", response.statusText);
      return [];
    }

    const data = await response.json();
    return data.records || [];
  } catch (error) {
    console.error("Whoop workout fetch error:", error);
    return [];
  }
}
