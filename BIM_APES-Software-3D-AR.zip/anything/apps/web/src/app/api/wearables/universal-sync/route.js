import sql from "@/app/api/utils/sql";

/**
 * POST /api/wearables/universal-sync
 * Universal wearable data sync endpoint
 * Supports: Whoop, Apple Watch, Garmin, Polar, Catapult, STATSports
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      device_type, // 'whoop', 'apple_watch', 'garmin', 'polar', 'catapult', 'stats sports'
      data_payload,
      sync_timestamp = new Date().toISOString(),
    } = body;

    if (!athlete_id || !device_type || !data_payload) {
      return Response.json(
        {
          success: false,
          error: "athlete_id, device_type, and data_payload are required",
        },
        { status: 400 },
      );
    }

    // Normalize data based on device type
    const normalizedData = normalizeWearableData(device_type, data_payload);

    // Store biometric readings
    const readings = await storeBiometricReadings(
      athlete_id,
      normalizedData,
      device_type,
    );

    // Log sync event
    await sql`
      INSERT INTO audit_logs (entity_type, entity_id, action, actor, details, created_at)
      VALUES (
        'wearable_sync',
        ${athlete_id},
        'data_ingestion',
        ${device_type},
        ${JSON.stringify({ readings_count: readings.length, sync_timestamp })},
        NOW()
      )
    `;

    return Response.json({
      success: true,
      athlete_id,
      device_type,
      readings_stored: readings.length,
      normalized_metrics: Object.keys(normalizedData),
      sync_timestamp,
    });
  } catch (error) {
    console.error("Wearable sync error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/wearables/universal-sync/history
 * Get sync history for athlete
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");
    const device_type = searchParams.get("device_type");
    const limit = parseInt(searchParams.get("limit") || "50");

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    const syncHistory = await sql`
      SELECT * FROM audit_logs
      WHERE entity_type = 'wearable_sync'
        AND entity_id = ${athlete_id}
        ${device_type ? sql`AND actor = ${device_type}` : sql``}
      ORDER BY created_at DESC
      LIMIT ${limit}
    `;

    return Response.json({
      success: true,
      athlete_id,
      device_type,
      sync_history: syncHistory,
      total_syncs: syncHistory.length,
    });
  } catch (error) {
    console.error("Sync history error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === NORMALIZATION FUNCTIONS ===

function normalizeWearableData(deviceType, payload) {
  const normalizers = {
    whoop: normalizeWhoopData,
    apple_watch: normalizeAppleWatchData,
    garmin: normalizeGarminData,
    polar: normalizePolarData,
    catapult: normalizeCatapultData,
    statssports: normalizeStatsSportsData,
  };

  const normalizer = normalizers[deviceType.toLowerCase().replace(/\s+/g, "_")];
  if (!normalizer) {
    throw new Error(`Unsupported device type: ${deviceType}`);
  }

  return normalizer(payload);
}

function normalizeWhoopData(payload) {
  // Whoop Recovery, Strain, Sleep data
  return {
    HRVi: payload.recovery?.hrv_rmssd || null,
    RRi: payload.recovery?.recovery_score || null,
    FAi: payload.strain?.day_strain || null,
    RHRi: payload.recovery?.resting_heart_rate || null,
    SpO2i: payload.sleep?.spo2_percentage || null,
    sleep_performance: payload.sleep?.sleep_performance_percentage || null,
    respiratory_rate: payload.sleep?.respiratory_rate || null,
  };
}

function normalizeAppleWatchData(payload) {
  // Apple HealthKit data
  return {
    RHRi: payload.resting_heart_rate || null,
    HRVi: payload.heart_rate_variability_sdnn || null,
    SpO2i: payload.oxygen_saturation || null,
    VO2i: payload.vo2_max || null,
    active_energy: payload.active_energy_burned || null,
    exercise_minutes: payload.exercise_time || null,
    steps: payload.step_count || null,
  };
}

function normalizeGarminData(payload) {
  // Garmin Connect data
  return {
    HRVi: payload.hrv_status?.weekly_avg || null,
    RRi: payload.body_battery?.current_value || null,
    FAi: payload.stress?.stress_level_value || null,
    VO2i: payload.vo2max?.current_value || null,
    RHRi: payload.resting_heart_rate || null,
    sleep_score: payload.sleep?.overall_sleep_score || null,
  };
}

function normalizePolarData(payload) {
  // Polar Flow data
  return {
    HRVi: payload.hrv?.rmssd || null,
    RHRi: payload.resting_hr || null,
    training_load: payload.training_load?.current || null,
    recovery_time: payload.recovery?.recovery_time_hours || null,
    orthostatic_test: payload.orthostatic_test?.result || null,
  };
}

function normalizeCatapultData(payload) {
  // Catapult Sports GPS/IMU data
  return {
    player_load: payload.player_load?.total || null,
    high_speed_distance: payload.velocity_band?.high_speed_running || null,
    sprint_distance: payload.velocity_band?.sprint_distance || null,
    acceleration_events: payload.acceleration?.total_efforts || null,
    deceleration_events: payload.deceleration?.total_efforts || null,
    max_velocity: payload.velocity?.max_velocity || null,
    impact_load: payload.impacts?.total_load || null,
  };
}

function normalizeStatsSportsData(payload) {
  // STATSports GPS data
  return {
    total_distance: payload.distance?.total_distance_meters || null,
    high_speed_running: payload.high_speed_running?.distance || null,
    sprint_distance: payload.sprint?.total_distance || null,
    max_speed: payload.velocity?.max_speed_kmh || null,
    accelerations: payload.accelerations?.count || null,
    decelerations: payload.decelerations?.count || null,
    explosive_distance: payload.explosive_distance?.meters || null,
    dynamic_stress_load: payload.dsl?.total || null,
  };
}

async function storeBiometricReadings(athleteId, normalizedData, deviceType) {
  const readings = [];

  for (const [indexCode, score] of Object.entries(normalizedData)) {
    if (score === null) continue;

    // Check if index exists
    const indexDef = await sql`
      SELECT * FROM biometric_index_definitions
      WHERE index_code = ${indexCode}
      LIMIT 1
    `;

    if (indexDef.length === 0) {
      console.warn(`Index ${indexCode} not found in definitions, skipping`);
      continue;
    }

    // Get baseline if exists
    const baseline = await sql`
      SELECT AVG(score) as avg_score
      FROM biometric_readings
      WHERE athlete_id = ${athleteId}
        AND index_code = ${indexCode}
        AND recorded_at > NOW() - INTERVAL '30 days'
    `;

    const baselineValue = baseline[0]?.avg_score || null;
    const trend = calculateTrend(score, baselineValue);

    // Insert reading
    const result = await sql`
      INSERT INTO biometric_readings (
        athlete_id,
        index_code,
        score,
        baseline,
        trend,
        context,
        recorded_at
      ) VALUES (
        ${athleteId},
        ${indexCode},
        ${score},
        ${baselineValue},
        ${trend},
        ${deviceType},
        NOW()
      )
      RETURNING *
    `;

    readings.push(result[0]);
  }

  return readings;
}

function calculateTrend(currentScore, baselineScore) {
  if (!baselineScore) return "neutral";

  const diff = currentScore - baselineScore;
  const percentDiff = (diff / baselineScore) * 100;

  if (percentDiff > 5) return "improving";
  if (percentDiff < -5) return "declining";
  return "stable";
}
