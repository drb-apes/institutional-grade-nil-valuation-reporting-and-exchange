import sql from "@/app/api/utils/sql";

/**
 * POST /api/wearables/garmin/connect
 * Initiates Garmin Connect OAuth connection
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      redirect_uri = `${process.env.NEXT_PUBLIC_CREATE_APP_URL}/wearables/callback`,
    } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Verify athlete exists
    const athleteRows = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteRows.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 404 },
      );
    }

    // Generate OAuth state
    const state = `${athlete_id}-${Date.now()}-${Math.random().toString(36).substring(7)}`;

    // Garmin OAuth URL
    const authUrl = new URL("https://connect.garmin.com/oauthConfirm");
    authUrl.searchParams.append(
      "oauth_consumer_key",
      process.env.GARMIN_CONSUMER_KEY || "demo_key",
    );
    authUrl.searchParams.append("oauth_callback", redirect_uri);

    return Response.json({
      success: true,
      authorization_url: authUrl.toString(),
      state,
      provider: "garmin",
      athlete_id,
      note: "Garmin uses OAuth 1.0a - implement request token flow for production",
    });
  } catch (error) {
    console.error("Garmin connect error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/wearables/garmin/connect?oauth_token=...&oauth_verifier=...
 * OAuth callback for Garmin
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const oauth_token = searchParams.get("oauth_token");
    const oauth_verifier = searchParams.get("oauth_verifier");

    if (!oauth_token || !oauth_verifier) {
      return Response.json(
        { success: false, error: "Missing OAuth parameters" },
        { status: 400 },
      );
    }

    // In production, exchange for access token using OAuth 1.0a flow
    // For now, store placeholder

    return Response.json({
      success: true,
      message: "Garmin OAuth callback received",
      provider: "garmin",
      note: "Production implementation requires OAuth 1.0a token exchange",
    });
  } catch (error) {
    console.error("Garmin callback error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
