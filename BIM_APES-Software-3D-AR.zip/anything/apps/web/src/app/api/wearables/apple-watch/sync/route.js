import sql from "@/app/api/utils/sql";

/**
 * POST /api/wearables/apple-watch/sync
 * Ingests Apple Watch HealthKit data
 * Note: Data must be sent from iOS app using HealthKit framework
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const { athlete_id, healthkit_data = [] } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    if (!healthkit_data || healthkit_data.length === 0) {
      return Response.json(
        { success: false, error: "No HealthKit data provided" },
        { status: 400 },
      );
    }

    const readings_inserted = [];

    for (const sample of healthkit_data) {
      const reading = await processHealthKitSample(athlete_id, sample);
      if (reading) {
        readings_inserted.push(reading);
      }
    }

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'wearable_sync',
        ${athlete_id},
        'apple_watch_sync',
        'BIM-APES Wearables',
        ${JSON.stringify({ samples_count: healthkit_data.length })}
      )
    `;

    return Response.json({
      success: true,
      athlete_id,
      provider: "apple_watch",
      samples_processed: healthkit_data.length,
      readings_inserted: readings_inserted.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Apple Watch sync error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HELPER FUNCTIONS ===

async function processHealthKitSample(athlete_id, sample) {
  const { type, value, unit, start_date, end_date } = sample;

  // Map HealthKit types to BIM-APES index codes
  const typeMapping = {
    HKQuantityTypeIdentifierHeartRate: "RHRi",
    HKQuantityTypeIdentifierHeartRateVariabilitySDNN: "HRVi",
    HKQuantityTypeIdentifierRestingHeartRate: "RHRi",
    HKQuantityTypeIdentifierVO2Max: "VO2Mi",
    HKQuantityTypeIdentifierActiveEnergyBurned: "AEi",
    HKQuantityTypeIdentifierStepCount: "SCi",
    HKQuantityTypeIdentifierDistanceWalkingRunning: "DWRi",
    HKQuantityTypeIdentifierBodyTemperature: "BTi",
    HKQuantityTypeIdentifierOxygenSaturation: "SpO2i",
    HKQuantityTypeIdentifierRespiratoryRate: "RRi",
  };

  const index_code = typeMapping[type];

  if (!index_code) {
    console.log(`Unknown HealthKit type: ${type}`);
    return null;
  }

  // Normalize value
  let normalized_value = parseFloat(value);

  // HRV is typically in milliseconds, convert to normalized score
  if (index_code === "HRVi" && unit === "ms") {
    normalized_value = Math.min(100, normalized_value / 2); // Rough normalization
  }

  // Insert reading
  try {
    const readingRows = await sql`
      INSERT INTO biometric_readings (
        athlete_id,
        index_code,
        score,
        context,
        recorded_at
      ) VALUES (
        ${athlete_id},
        ${index_code},
        ${normalized_value},
        'apple_watch_healthkit',
        ${start_date || new Date().toISOString()}
      )
      RETURNING *
    `;

    return readingRows[0];
  } catch (error) {
    console.error(`Error inserting HealthKit sample for ${type}:`, error);
    return null;
  }
}
