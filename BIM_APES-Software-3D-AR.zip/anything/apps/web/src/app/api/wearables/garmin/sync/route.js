import sql from "@/app/api/utils/sql";

/**
 * POST /api/wearables/garmin/sync
 * Syncs data from Garmin Connect
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const { athlete_id, data_types = ["activities", "dailies", "hrv"] } = body;

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get Garmin connection (placeholder for now)
    const connectionRows = await sql`
      SELECT details
      FROM compliance_checks
      WHERE athlete_id = ${athlete_id}
        AND check_type = 'garmin_connected'
        AND status = 'active'
      ORDER BY checked_at DESC
      LIMIT 1
    `;

    if (connectionRows.length === 0) {
      return Response.json(
        { success: false, error: "Garmin not connected for this athlete" },
        { status: 404 },
      );
    }

    const connection = connectionRows[0].details;
    const access_token = connection.access_token || connection.oauth_token;

    const synced_data = [];
    const readings_inserted = [];

    // Sync Activities
    if (data_types.includes("activities")) {
      const activities = await fetchGarminActivities(access_token);

      if (activities && activities.length > 0) {
        // Process latest activity
        const latest = activities[0];

        // Insert activity metrics as biometric readings
        if (latest.averageHR) {
          const hrReading = await sql`
            INSERT INTO biometric_readings (
              athlete_id,
              index_code,
              score,
              context,
              recorded_at
            ) VALUES (
              ${athlete_id},
              'RHRi',
              ${latest.averageHR},
              'garmin_activity',
              ${latest.startTimeLocal}
            )
            RETURNING *
          `;
          readings_inserted.push(hrReading[0]);
        }

        synced_data.push({ type: "activities", count: activities.length });
      }
    }

    // Sync Daily Summaries
    if (data_types.includes("dailies")) {
      const dailies = await fetchGarminDailies(access_token);

      if (dailies && dailies.length > 0) {
        const latest = dailies[0];

        // Insert step count
        if (latest.steps) {
          const stepsReading = await sql`
            INSERT INTO biometric_readings (
              athlete_id,
              index_code,
              score,
              context,
              recorded_at
            ) VALUES (
              ${athlete_id},
              'SCi',
              ${latest.steps},
              'garmin_daily',
              ${latest.calendarDate}
            )
            RETURNING *
          `;
          readings_inserted.push(stepsReading[0]);
        }

        synced_data.push({ type: "dailies", count: dailies.length });
      }
    }

    // Sync HRV Data
    if (data_types.includes("hrv")) {
      const hrvData = await fetchGarminHRV(access_token);

      if (hrvData && hrvData.length > 0) {
        const latest = hrvData[0];

        if (latest.hrvValue) {
          const hrvReading = await sql`
            INSERT INTO biometric_readings (
              athlete_id,
              index_code,
              score,
              context,
              recorded_at
            ) VALUES (
              ${athlete_id},
              'HRVi',
              ${latest.hrvValue},
              'garmin_hrv',
              ${latest.measurementTimestamp}
            )
            RETURNING *
          `;
          readings_inserted.push(hrvReading[0]);
        }

        synced_data.push({ type: "hrv", count: hrvData.length });
      }
    }

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'wearable_sync',
        ${athlete_id},
        'garmin_sync',
        'BIM-APES Wearables',
        ${JSON.stringify({ data_types, synced_data })}
      )
    `;

    return Response.json({
      success: true,
      athlete_id,
      provider: "garmin",
      synced_data,
      readings_inserted: readings_inserted.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Garmin sync error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// === HELPER FUNCTIONS ===

async function fetchGarminActivities(access_token) {
  try {
    // Placeholder - production would use OAuth-signed request
    console.log(
      "Fetching Garmin activities with token:",
      access_token?.substring(0, 10),
    );

    // Simulated data structure
    return [
      {
        activityId: "123456789",
        activityName: "Running",
        startTimeLocal: new Date().toISOString(),
        distance: 5000,
        duration: 1800,
        averageHR: 145,
        maxHR: 175,
      },
    ];
  } catch (error) {
    console.error("Garmin activities fetch error:", error);
    return [];
  }
}

async function fetchGarminDailies(access_token) {
  try {
    // Placeholder
    return [
      {
        calendarDate: new Date().toISOString().split("T")[0],
        steps: 8542,
        distance: 6234,
        activeTime: 45,
        calories: 2100,
      },
    ];
  } catch (error) {
    console.error("Garmin dailies fetch error:", error);
    return [];
  }
}

async function fetchGarminHRV(access_token) {
  try {
    // Placeholder
    return [
      {
        measurementTimestamp: new Date().toISOString(),
        hrvValue: 65,
        status: "balanced",
      },
    ];
  } catch (error) {
    console.error("Garmin HRV fetch error:", error);
    return [];
  }
}
