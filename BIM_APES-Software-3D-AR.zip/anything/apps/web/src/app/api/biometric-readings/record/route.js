import sql from "@/app/api/utils/sql";

// Record biometric reading for an athlete
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      index_code,
      score,
      baseline,
      trend,
      context,
      session_id,
    } = body;

    // Validate required fields
    if (!athlete_id || !index_code || score === undefined) {
      return Response.json(
        { error: "athlete_id, index_code, and score are required" },
        { status: 400 },
      );
    }

    // Verify athlete exists
    const athletes = await sql`
      SELECT id, consent_biometric FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    if (!athletes[0].consent_biometric) {
      return Response.json(
        { error: "Athlete has not consented to biometric data collection" },
        { status: 403 },
      );
    }

    // Verify index exists
    const indices = await sql`
      SELECT index_code FROM biometric_index_definitions WHERE index_code = ${index_code}
    `;

    if (indices.length === 0) {
      return Response.json({ error: "Invalid index_code" }, { status: 400 });
    }

    // Insert reading
    const reading = await sql`
      INSERT INTO biometric_readings (
        athlete_id,
        index_code,
        score,
        baseline,
        trend,
        context,
        session_id
      ) VALUES (
        ${athlete_id},
        ${index_code},
        ${score},
        ${baseline || null},
        ${trend || null},
        ${context || null},
        ${session_id || null}
      )
      RETURNING *
    `;

    // Log audit trail
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'biometric_reading',
        ${reading[0].id},
        'create',
        'system',
        ${JSON.stringify({ athlete_id, index_code, score })}
      )
    `;

    return Response.json({
      success: true,
      reading: reading[0],
    });
  } catch (error) {
    console.error("Error recording biometric reading:", error);
    return Response.json(
      { error: "Failed to record biometric reading", details: error.message },
      { status: 500 },
    );
  }
}

// Batch record multiple readings
export async function PUT(request) {
  try {
    const body = await request.json();
    const { athlete_id, readings } = body;

    if (!athlete_id || !Array.isArray(readings) || readings.length === 0) {
      return Response.json(
        { error: "athlete_id and readings array are required" },
        { status: 400 },
      );
    }

    // Verify athlete and consent
    const athletes = await sql`
      SELECT id, consent_biometric FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    if (!athletes[0].consent_biometric) {
      return Response.json(
        { error: "Athlete has not consented to biometric data collection" },
        { status: 403 },
      );
    }

    const insertedReadings = [];

    for (const reading of readings) {
      const { index_code, score, baseline, trend, context, session_id } =
        reading;

      if (!index_code || score === undefined) {
        continue; // Skip invalid readings
      }

      const result = await sql`
        INSERT INTO biometric_readings (
          athlete_id,
          index_code,
          score,
          baseline,
          trend,
          context,
          session_id
        ) VALUES (
          ${athlete_id},
          ${index_code},
          ${score},
          ${baseline || null},
          ${trend || null},
          ${context || null},
          ${session_id || null}
        )
        RETURNING *
      `;

      insertedReadings.push(result[0]);
    }

    return Response.json({
      success: true,
      count: insertedReadings.length,
      readings: insertedReadings,
    });
  } catch (error) {
    console.error("Error batch recording biometric readings:", error);
    return Response.json(
      { error: "Failed to batch record readings", details: error.message },
      { status: 500 },
    );
  }
}
