import sql from "@/app/api/utils/sql";

/**
 * POST /api/database/seed-athletes
 * Seeds the database with realistic multi-sport athlete data
 */
export async function POST(request) {
  try {
    const { count = 50 } = await request.json();

    // Realistic athlete data across multiple sports
    const sports = [
      {
        sport: "Basketball",
        positions: [
          "Point Guard",
          "Shooting Guard",
          "Small Forward",
          "Power Forward",
          "Center",
        ],
        teams: ["Lakers", "Warriors", "Celtics", "Heat", "Nets"],
      },
      {
        sport: "Rugby",
        positions: ["Fly-half", "Scrum-half", "Wing", "Fullback", "Prop"],
        teams: [
          "Gloucester Rugby",
          "Bath Rugby",
          "Leicester Tigers",
          "Saracens",
          "Harlequins",
        ],
      },
      {
        sport: "Soccer",
        positions: [
          "Striker",
          "Midfielder",
          "Defender",
          "Goalkeeper",
          "Winger",
        ],
        teams: ["Man United", "Liverpool", "Chelsea", "Arsenal", "Man City"],
      },
      {
        sport: "Wrestling",
        positions: ["Lightweight", "Middleweight", "Heavyweight"],
        teams: ["Team USA", "Team UK", "National Squad"],
      },
      {
        sport: "Tennis",
        positions: ["Singles", "Doubles"],
        teams: ["ATP Tour", "WTA Tour", "ITF"],
      },
      {
        sport: "American Football",
        positions: [
          "Quarterback",
          "Running Back",
          "Wide Receiver",
          "Linebacker",
          "Defensive End",
        ],
        teams: ["Patriots", "49ers", "Chiefs", "Cowboys", "Packers"],
      },
    ];

    const firstNames = [
      "Dashawn",
      "Marcus",
      "Jamal",
      "Tyler",
      "Brandon",
      "Connor",
      "Ethan",
      "Liam",
      "Noah",
      "Oliver",
      "Emma",
      "Sophia",
      "Isabella",
      "Mia",
      "Charlotte",
      "Amelia",
      "Harper",
      "Evelyn",
    ];
    const lastNames = [
      "Smith",
      "Johnson",
      "Williams",
      "Brown",
      "Jones",
      "Garcia",
      "Martinez",
      "Davis",
      "Rodriguez",
      "Wilson",
      "Anderson",
      "Taylor",
      "Thomas",
      "Moore",
      "Jackson",
      "Martin",
      "Lee",
      "Walker",
    ];
    const federations = [
      "NCAA",
      "Premier Rugby",
      "Premier League",
      "USA Wrestling",
      "ATP",
      "NFL",
    ];
    const nilTiers = ["Tier I", "Tier II", "Tier III"];

    const athletes = [];
    const athleteIds = [];

    for (let i = 0; i < count; i++) {
      const sportData = sports[Math.floor(Math.random() * sports.length)];
      const firstName =
        firstNames[Math.floor(Math.random() * firstNames.length)];
      const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const position =
        sportData.positions[
          Math.floor(Math.random() * sportData.positions.length)
        ];
      const team =
        sportData.teams[Math.floor(Math.random() * sportData.teams.length)];
      const federation =
        federations[Math.floor(Math.random() * federations.length)];
      const nilTier = nilTiers[Math.floor(Math.random() * nilTiers.length)];

      // Realistic physical stats
      const height = 160 + Math.random() * 50; // 160-210 cm
      const weight = 60 + Math.random() * 60; // 60-120 kg
      const age = 18 + Math.floor(Math.random() * 15); // 18-32 years
      const birthDate = new Date();
      birthDate.setFullYear(birthDate.getFullYear() - age);

      const result = await sql`
        INSERT INTO athletes (
          first_name, last_name, sport, position, team, federation,
          date_of_birth, height_cm, weight_kg, nil_tier,
          coalition_status, consent_biometric, consent_nil, consent_trading
        ) VALUES (
          ${firstName}, ${lastName}, ${sportData.sport}, ${position}, ${team}, ${federation},
          ${birthDate.toISOString().split("T")[0]}, ${height.toFixed(2)}, ${weight.toFixed(2)}, ${nilTier},
          'Active', ${Math.random() > 0.2}, ${Math.random() > 0.1}, ${Math.random() > 0.3}
        )
        RETURNING id
      `;

      const athleteId = result[0].id;
      athleteIds.push(athleteId);
      athletes.push({
        id: athleteId,
        name: `${firstName} ${lastName}`,
        sport: sportData.sport,
        team,
        nilTier,
      });
    }

    // Seed initial biometric baselines for each athlete
    for (const athleteId of athleteIds) {
      // Fix: compute timestamp in JavaScript instead of using INTERVAL string interpolation
      const hoursAgo = Math.floor(Math.random() * 48);
      const startedAt = new Date(Date.now() - hoursAgo * 60 * 60 * 1000);
      const intensity = ["Low", "Medium", "High"][
        Math.floor(Math.random() * 3)
      ];
      const duration = 60 + Math.floor(Math.random() * 60);
      const perfScore = 70 + Math.random() * 30;

      await sql`
        INSERT INTO performance_sessions (athlete_id, session_type, sport, duration_minutes, intensity, performance_score, started_at)
        VALUES (
          ${athleteId}, 'Training', 'Multi-Sport', ${duration},
          ${intensity}, ${perfScore}, ${startedAt.toISOString()}
        )
      `;
    }

    return Response.json({
      success: true,
      message: `Successfully seeded ${count} athletes`,
      athletes: athletes.slice(0, 10), // Return first 10 for preview
      total: count,
    });
  } catch (error) {
    console.error("Seed athletes error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
