import sql from "@/app/api/utils/sql";

/**
 * POST /api/database/seed-biometrics
 * Seeds realistic biometric readings for existing athletes
 */
export async function POST(request) {
  try {
    const { athlete_id, hours = 48, frequency = 4 } = await request.json();

    // Get athlete or all athletes
    let athletes;
    if (athlete_id) {
      athletes =
        await sql`SELECT id, sport FROM athletes WHERE id = ${athlete_id}`;
    } else {
      athletes = await sql`SELECT id, sport FROM athletes LIMIT 20`;
    }

    if (athletes.length === 0) {
      return Response.json(
        {
          success: false,
          error: "No athletes found. Run seed-athletes first.",
        },
        { status: 400 },
      );
    }

    // Indices to seed - ordered to match biometric_index_definitions
    const indicesToSeed = [
      {
        code: "RHRi",
        baseValue: 65,
        variance: 10,
        domain: "Vital Signals",
        cluster: "Cardiovascular Metrics",
        name: "Resting Heart Rate Index",
        description:
          "Measures baseline resting heart rate and autonomic balance.",
      },
      {
        code: "HRVi",
        baseValue: 75,
        variance: 20,
        domain: "Vital Signals",
        cluster: "Cardiovascular Metrics",
        name: "Heart Rate Variability Index",
        description: "Tracks parasympathetic activity and stress resilience.",
      },
      {
        code: "FAi",
        baseValue: 40,
        variance: 25,
        domain: "Performance",
        cluster: "Fatigue Metrics",
        name: "Fatigue Accumulation Index",
        description: "Tracks cumulative fatigue across training cycles.",
      },
      {
        code: "RRi",
        baseValue: 82,
        variance: 15,
        domain: "Performance",
        cluster: "Recovery Metrics",
        name: "Recovery Rate Index",
        description: "Measures speed and quality of physiological recovery.",
      },
      {
        code: "SpO2i",
        baseValue: 97,
        variance: 2,
        domain: "Vital Signals",
        cluster: "Respiratory Metrics",
        name: "Oxygen Saturation Index",
        description: "Measures oxygen saturation efficiency.",
      },
      {
        code: "CSi",
        baseValue: 0.3,
        variance: 0.2,
        domain: "Vital Signals",
        cluster: "Cardiovascular Metrics",
        name: "Cardiac Stress Index",
        description: "Detects cardiac strain under physical or emotional load.",
      },
      {
        code: "SRi",
        baseValue: 45,
        variance: 20,
        domain: "Cognitive",
        cluster: "Stress & Resilience",
        name: "Stress Reactivity Index",
        description:
          "Measures intensity of physiological and emotional stress reactions.",
      },
      {
        code: "MIi",
        baseValue: 70,
        variance: 15,
        domain: "Performance",
        cluster: "Movement Metrics",
        name: "Movement Intensity Index",
        description: "Tracks movement intensity and physical load.",
      },
    ];

    // Ensure biometric_index_definitions exist for these codes
    for (const idx of indicesToSeed) {
      const existing =
        await sql`SELECT id FROM biometric_index_definitions WHERE index_code = ${idx.code}`;
      if (existing.length === 0) {
        await sql`
          INSERT INTO biometric_index_definitions (domain, cluster, index_name, index_code, description, unit, normal_range_min, normal_range_max)
          VALUES (${idx.domain}, ${idx.cluster}, ${idx.name}, ${idx.code}, ${idx.description}, 'score', 0, 100)
          ON CONFLICT (index_code) DO NOTHING
        `;
      }
    }

    // Get confirmed valid index codes
    const validCodes =
      await sql`SELECT index_code FROM biometric_index_definitions WHERE index_code = ANY(${indicesToSeed.map((i) => i.code)})`;
    const validCodeSet = new Set(validCodes.map((r) => r.index_code));
    const validIndices = indicesToSeed.filter((i) => validCodeSet.has(i.code));

    const totalReadings = [];
    const recordsPerAthlete = Math.min(
      Math.floor((hours * 60) / Math.max(frequency, 15)),
      200,
    ); // cap at 200 per athlete

    for (const athlete of athletes) {
      const baseline = {};
      validIndices.forEach((idx) => {
        baseline[idx.code] =
          idx.baseValue + (Math.random() - 0.5) * idx.variance * 0.3;
      });

      for (let i = 0; i < recordsPerAthlete; i++) {
        const timestamp = new Date();
        timestamp.setMinutes(
          timestamp.getMinutes() - (recordsPerAthlete - i) * frequency,
        );

        for (const idx of validIndices) {
          const timeFactor = i / recordsPerAthlete;
          const fatigueFactor = Math.sin(timeFactor * Math.PI) * 0.1;
          const noise = (Math.random() - 0.5) * idx.variance * 0.15;
          const score = Math.max(
            0,
            Math.min(
              100,
              baseline[idx.code] + fatigueFactor * idx.variance + noise,
            ),
          );
          const trend =
            score > baseline[idx.code]
              ? "increasing"
              : score < baseline[idx.code]
                ? "decreasing"
                : "stable";

          await sql`
            INSERT INTO biometric_readings (athlete_id, index_code, score, baseline, trend, context, recorded_at)
            VALUES (
              ${athlete.id}, ${idx.code}, ${score.toFixed(4)}, ${baseline[idx.code].toFixed(4)},
              ${trend}, 'training', ${timestamp.toISOString()}
            )
          `;

          totalReadings.push({ athlete_id: athlete.id, index_code: idx.code });
        }
      }
    }

    // Also seed NIL valuations for each athlete
    for (const athlete of athletes) {
      const trueValue = 50000 + Math.random() * 450000;
      const marketValue = trueValue * (0.8 + Math.random() * 0.4);
      const gap = trueValue - marketValue;
      const gapPct = (gap / trueValue) * 100;

      await sql`
        INSERT INTO nil_valuations (athlete_id, true_value, market_value, gap, gap_percentage, direction, confidence, convexity_factor, momentum_intensity, expected_close_seconds)
        VALUES (
          ${athlete.id}, ${trueValue.toFixed(2)}, ${marketValue.toFixed(2)},
          ${gap.toFixed(2)}, ${gapPct.toFixed(2)},
          ${gap > 0 ? "long" : "short"}, ${(0.6 + Math.random() * 0.4).toFixed(3)},
          ${(0.3 + Math.random() * 0.6).toFixed(3)}, ${(0.4 + Math.random() * 0.5).toFixed(3)},
          ${Math.floor(900 + Math.random() * 3600)}
        )
      `;
    }

    return Response.json({
      success: true,
      message: `Seeded ${totalReadings.length} biometric readings for ${athletes.length} athletes`,
      count: totalReadings.length,
      athletes: athletes.length,
      indicesUsed: validIndices.length,
    });
  } catch (error) {
    console.error("Seed biometrics error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
