import sql from "@/app/api/utils/sql";
import { internalError, successResponse } from "@/app/api/utils/errorHandler";

/**
 * Seed demo data for 90-day launch dashboard
 * POST /api/demo/seed-data
 */

export async function POST(request) {
  try {
    const body = await request.json();
    const { count = 10, sport = "Basketball" } = body;

    const seededData = {
      athletes: [],
      sessions: [],
      biometrics: [],
      valuations: [],
      campaigns: [],
    };

    // Create demo athletes
    const firstNames = [
      "Sarah",
      "Marcus",
      "Emily",
      "Jordan",
      "Taylor",
      "Alex",
      "Casey",
      "Morgan",
      "Riley",
      "Dakota",
    ];
    const lastNames = [
      "Johnson",
      "Williams",
      "Brown",
      "Davis",
      "Miller",
      "Wilson",
      "Moore",
      "Taylor",
      "Anderson",
      "Thomas",
    ];
    const positions = ["Guard", "Forward", "Center", "Wing", "Point Guard"];
    const teams = [
      "Riverside High",
      "Lincoln Academy",
      "Washington Prep",
      "Jefferson United",
      "Madison Tech",
    ];

    for (let i = 0; i < Math.min(count, 10); i++) {
      const [athlete] = await sql`
        INSERT INTO athletes (
          first_name,
          last_name,
          sport,
          position,
          team,
          date_of_birth,
          height_cm,
          weight_kg,
          nil_tier,
          coalition_status,
          consent_biometric,
          consent_nil,
          consent_trading
        ) VALUES (
          ${firstNames[i]},
          ${lastNames[i]},
          ${sport},
          ${positions[i % positions.length]},
          ${teams[i % teams.length]},
          ${new Date(2006 + (i % 4), i % 12, 1).toISOString().split("T")[0]},
          ${175 + i * 5},
          ${70 + i * 3},
          ${i < 3 ? "Tier I" : i < 7 ? "Tier II" : "Tier III"},
          'Active',
          true,
          true,
          ${i < 5}
        )
        ON CONFLICT (id) DO NOTHING
        RETURNING *
      `;

      if (athlete) {
        seededData.athletes.push(athlete);

        // Create performance sessions for each athlete
        for (let j = 0; j < 5; j++) {
          const [session] = await sql`
            INSERT INTO performance_sessions (
              athlete_id,
              session_type,
              sport,
              duration_minutes,
              intensity,
              performance_score,
              started_at
            ) VALUES (
              ${athlete.id},
              ${["training", "competition", "recovery"][j % 3]},
              ${sport},
              ${60 + j * 15},
              ${["low", "medium", "high"][j % 3]},
              ${75 + Math.random() * 20},
              NOW() - INTERVAL '${j * 2} days'
            )
            RETURNING *
          `;

          if (session) {
            seededData.sessions.push(session);

            // Create biometric readings for each session
            const indices = ["RHRi", "HRVi", "SpO2i", "CLi", "FAi", "RRi"];
            for (const indexCode of indices) {
              const [reading] = await sql`
                INSERT INTO biometric_readings (
                  athlete_id,
                  index_code,
                  score,
                  baseline,
                  trend,
                  context,
                  session_id,
                  recorded_at
                ) VALUES (
                  ${athlete.id},
                  ${indexCode},
                  ${50 + Math.random() * 40},
                  ${60 + Math.random() * 20},
                  ${["stable", "improving", "declining"][Math.floor(Math.random() * 3)]},
                  'training',
                  ${session.id},
                  NOW() - INTERVAL '${j * 2} days'
                )
                RETURNING *
              `;

              if (reading) {
                seededData.biometrics.push(reading);
              }
            }
          }
        }

        // Create NIL valuations
        for (let k = 0; k < 7; k++) {
          const baseValue = 50 + i * 10 + k * 5;
          const marketValue = baseValue * (0.9 + Math.random() * 0.2);
          const gap = baseValue - marketValue;

          const [valuation] = await sql`
            INSERT INTO nil_valuations (
              athlete_id,
              true_value,
              market_value,
              gap,
              gap_percentage,
              direction,
              confidence,
              convexity_factor,
              momentum_intensity,
              expected_close_seconds,
              valuation_method,
              calculated_at
            ) VALUES (
              ${athlete.id},
              ${baseValue},
              ${marketValue},
              ${gap},
              ${(gap / baseValue) * 100},
              ${gap > 0 ? "long" : "short"},
              ${0.7 + Math.random() * 0.25},
              ${Math.random()},
              ${Math.random()},
              ${1800 + Math.floor(Math.random() * 3600)},
              'BIM-APES ML v2.0',
              NOW() - INTERVAL '${k * 4} days'
            )
            RETURNING *
          `;

          if (valuation) {
            seededData.valuations.push(valuation);
          }
        }
      }
    }

    // Create demo sponsor campaigns
    const sponsors = ["Nike", "Gatorade", "Under Armour", "Adidas", "Red Bull"];
    for (let i = 0; i < sponsors.length; i++) {
      const [campaign] = await sql`
        INSERT INTO sponsor_campaigns (
          sponsor_name,
          campaign_name,
          campaign_type,
          pricing_model,
          cpm_rate,
          target_impressions,
          target_engagement_rate,
          campaign_start,
          campaign_end,
          status,
          logo_url
        ) VALUES (
          ${sponsors[i]},
          ${`${sponsors[i]} Youth Athletics Program`},
          'youth_engagement',
          'cpm',
          ${5 + Math.random() * 10},
          ${100000 + i * 50000},
          ${0.05 + Math.random() * 0.03},
          NOW() - INTERVAL '30 days',
          NOW() + INTERVAL '60 days',
          'active',
          ${`/sponsors/${sponsors[i].toLowerCase()}.png`}
        )
        RETURNING *
      `;

      if (campaign) {
        seededData.campaigns.push(campaign);
      }
    }

    return successResponse({
      message: "Demo data seeded successfully",
      summary: {
        athletes: seededData.athletes.length,
        sessions: seededData.sessions.length,
        biometrics: seededData.biometrics.length,
        valuations: seededData.valuations.length,
        campaigns: seededData.campaigns.length,
      },
      data: seededData,
    });
  } catch (error) {
    console.error("Seed data error:", error);
    return internalError(error, "seeding demo data");
  }
}

/**
 * Clear all demo data
 * DELETE /api/demo/seed-data
 */
export async function DELETE(request) {
  try {
    // Delete in reverse order of foreign key dependencies
    await sql`DELETE FROM biometric_readings WHERE context = 'training'`;
    await sql`DELETE FROM nil_valuations WHERE valuation_method = 'BIM-APES ML v2.0'`;
    await sql`DELETE FROM performance_sessions WHERE session_type IN ('training', 'competition', 'recovery')`;
    await sql`DELETE FROM sponsor_campaigns WHERE campaign_type = 'youth_engagement'`;
    await sql`DELETE FROM athletes WHERE coalition_status = 'Active' AND created_at > NOW() - INTERVAL '1 hour'`;

    return successResponse({
      message: "Demo data cleared successfully",
    });
  } catch (error) {
    console.error("Clear data error:", error);
    return internalError(error, "clearing demo data");
  }
}
