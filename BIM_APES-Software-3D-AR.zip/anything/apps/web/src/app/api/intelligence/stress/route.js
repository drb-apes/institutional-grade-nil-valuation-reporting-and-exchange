import sql from "@/app/api/utils/sql";

/**
 * Stress Intelligence Engine
 *
 * Calculates:
 * - Joint torque modeling
 * - Ground-reaction force mapping
 * - Asymmetry detection
 * - HRV stress response
 *
 * AR Overlay: Stress Cones + Redline Rings
 */

export async function POST(request) {
  try {
    const { athlete_id, session_id } = await request.json();

    if (!athlete_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id is required",
        },
        { status: 400 },
      );
    }

    // Get latest biometric readings
    const readings = await sql`
      SELECT 
        br.index_code,
        br.score,
        br.baseline,
        bid.index_name,
        bid.cluster
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND bid.domain = 'Vital Signals'
        AND br.recorded_at > NOW() - INTERVAL '2 hours'
      ORDER BY br.recorded_at DESC
    `;

    // Calculate Stress Intelligence components
    const stressIntelligence = {
      athlete_id,
      timestamp: new Date().toISOString(),

      // Joint Torque Modeling
      jointTorque: {
        leftKnee: calculateTorque(readings, "left_knee"),
        rightKnee: calculateTorque(readings, "right_knee"),
        leftAnkle: calculateTorque(readings, "left_ankle"),
        rightAnkle: calculateTorque(readings, "right_ankle"),
        leftShoulder: calculateTorque(readings, "left_shoulder"),
        rightShoulder: calculateTorque(readings, "right_shoulder"),
        asymmetryScore: 0,
      },

      // Ground-Reaction Force Mapping
      groundReactionForce: {
        leftFoot: calculateGRF(readings, "left"),
        rightFoot: calculateGRF(readings, "right"),
        totalForce: 0,
        forceSymmetry: 0,
      },

      // Asymmetry Detection
      asymmetry: {
        lateral: 0,
        anteriorPosterior: 0,
        rotational: 0,
        overallAsymmetry: 0,
      },

      // HRV Stress Response
      hrvStress: {
        currentHRV: getReading(readings, "HRVi"),
        baselineHRV: getBaseline(readings, "HRVi"),
        stressIndex: 0,
        autonomicBalance: "balanced", // 'balanced', 'sympathetic', 'parasympathetic'
      },

      // Overall Stress Score (0-1)
      overallStressScore: 0,

      // AR Overlay Data
      arOverlay: {
        stressCones: [],
        redlineRings: [],
      },

      // Alerts
      alerts: [],
    };

    // Calculate joint torque asymmetry
    stressIntelligence.jointTorque.asymmetryScore = calculateAsymmetry(
      stressIntelligence.jointTorque,
    );

    // Calculate GRF totals
    stressIntelligence.groundReactionForce.totalForce =
      stressIntelligence.groundReactionForce.leftFoot +
      stressIntelligence.groundReactionForce.rightFoot;

    stressIntelligence.groundReactionForce.forceSymmetry =
      calculateForceSymmetry(
        stressIntelligence.groundReactionForce.leftFoot,
        stressIntelligence.groundReactionForce.rightFoot,
      );

    // Calculate asymmetry scores
    stressIntelligence.asymmetry = calculateFullAsymmetry(stressIntelligence);

    // Calculate HRV stress index
    if (
      stressIntelligence.hrvStress.currentHRV &&
      stressIntelligence.hrvStress.baselineHRV
    ) {
      const hrvRatio =
        stressIntelligence.hrvStress.currentHRV /
        stressIntelligence.hrvStress.baselineHRV;
      stressIntelligence.hrvStress.stressIndex = Math.max(0, 1 - hrvRatio);

      if (hrvRatio < 0.7) {
        stressIntelligence.hrvStress.autonomicBalance = "sympathetic";
      } else if (hrvRatio > 1.2) {
        stressIntelligence.hrvStress.autonomicBalance = "parasympathetic";
      }
    }

    // Calculate overall stress score
    stressIntelligence.overallStressScore =
      calculateOverallStress(stressIntelligence);

    // Generate AR overlay data
    stressIntelligence.arOverlay = generateStressAROverlay(stressIntelligence);

    // Generate alerts
    stressIntelligence.alerts = generateStressAlerts(stressIntelligence);

    return Response.json({
      success: true,
      stressIntelligence,
    });
  } catch (error) {
    console.error("Error calculating stress intelligence:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * Helper Functions
 */

function calculateTorque(readings, joint) {
  // Simulated torque calculation
  // In production, this would use actual biomechanical data
  return Math.random() * 150 + 50; // 50-200 Nm
}

function calculateGRF(readings, side) {
  // Ground reaction force in body weights
  return Math.random() * 1.5 + 1.0; // 1.0-2.5 BW
}

function getReading(readings, code) {
  const reading = readings.find((r) => r.index_code === code);
  return reading ? reading.score : null;
}

function getBaseline(readings, code) {
  const reading = readings.find((r) => r.index_code === code);
  return reading ? reading.baseline : null;
}

function calculateAsymmetry(jointTorque) {
  const leftTotal =
    jointTorque.leftKnee + jointTorque.leftAnkle + jointTorque.leftShoulder;
  const rightTotal =
    jointTorque.rightKnee + jointTorque.rightAnkle + jointTorque.rightShoulder;

  return Math.abs(leftTotal - rightTotal) / Math.max(leftTotal, rightTotal);
}

function calculateForceSymmetry(left, right) {
  return 1 - Math.abs(left - right) / Math.max(left, right);
}

function calculateFullAsymmetry(intelligence) {
  return {
    lateral: intelligence.jointTorque.asymmetryScore,
    anteriorPosterior: Math.random() * 0.3, // Simulated
    rotational: Math.random() * 0.2, // Simulated
    overallAsymmetry:
      intelligence.jointTorque.asymmetryScore * 0.6 + Math.random() * 0.2,
  };
}

function calculateOverallStress(intelligence) {
  let score = 0;
  let factors = 0;

  // Joint torque contribution
  if (intelligence.jointTorque.asymmetryScore > 0.3) {
    score += 0.3;
  } else if (intelligence.jointTorque.asymmetryScore > 0.15) {
    score += 0.15;
  }
  factors++;

  // GRF contribution
  if (intelligence.groundReactionForce.forceSymmetry < 0.8) {
    score += 0.2;
  }
  factors++;

  // Asymmetry contribution
  score += intelligence.asymmetry.overallAsymmetry * 0.3;
  factors++;

  // HRV stress contribution
  score += intelligence.hrvStress.stressIndex * 0.4;
  factors++;

  return Math.min(score, 1.0);
}

function generateStressAROverlay(intelligence) {
  const overlay = {
    stressCones: [],
    redlineRings: [],
  };

  // Stress cones for each major joint
  const joints = [
    {
      name: "left_knee",
      torque: intelligence.jointTorque.leftKnee,
      position: { x: -0.2, y: 0.5, z: 0 },
    },
    {
      name: "right_knee",
      torque: intelligence.jointTorque.rightKnee,
      position: { x: 0.2, y: 0.5, z: 0 },
    },
    {
      name: "left_ankle",
      torque: intelligence.jointTorque.leftAnkle,
      position: { x: -0.2, y: 0.1, z: 0 },
    },
    {
      name: "right_ankle",
      torque: intelligence.jointTorque.rightAnkle,
      position: { x: 0.2, y: 0.1, z: 0 },
    },
    {
      name: "left_shoulder",
      torque: intelligence.jointTorque.leftShoulder,
      position: { x: -0.3, y: 0.9, z: 0 },
    },
    {
      name: "right_shoulder",
      torque: intelligence.jointTorque.rightShoulder,
      position: { x: 0.3, y: 0.9, z: 0 },
    },
  ];

  overlay.stressCones = joints.map((joint) => ({
    joint: joint.name,
    position: joint.position,
    intensity: Math.min(joint.torque / 200, 1.0),
    color:
      joint.torque > 180
        ? "#EF4444"
        : joint.torque > 140
          ? "#F59E0B"
          : "#10B981",
    size: joint.torque / 100,
  }));

  // Redline rings when stress is critical
  if (intelligence.overallStressScore > 0.7) {
    overlay.redlineRings.push({
      type: "critical_stress",
      position: { x: 0, y: 0.6, z: 0 },
      radius: 0.5,
      intensity: intelligence.overallStressScore,
      pulse: true,
    });
  }

  return overlay;
}

function generateStressAlerts(intelligence) {
  const alerts = [];

  if (intelligence.overallStressScore > 0.8) {
    alerts.push({
      severity: "critical",
      type: "high_stress",
      message:
        "Critical stress levels detected - immediate intervention recommended",
      recommendation: "Reduce training load and implement recovery protocol",
    });
  } else if (intelligence.overallStressScore > 0.6) {
    alerts.push({
      severity: "warning",
      type: "elevated_stress",
      message: "Elevated stress levels detected",
      recommendation: "Monitor closely and consider load adjustment",
    });
  }

  if (intelligence.jointTorque.asymmetryScore > 0.3) {
    alerts.push({
      severity: "warning",
      type: "asymmetry",
      message: `Significant joint asymmetry detected (${(intelligence.jointTorque.asymmetryScore * 100).toFixed(0)}%)`,
      recommendation: "Assess for compensatory patterns and injury risk",
    });
  }

  if (intelligence.hrvStress.autonomicBalance === "sympathetic") {
    alerts.push({
      severity: "info",
      type: "sympathetic_dominance",
      message: "Sympathetic nervous system dominance detected",
      recommendation:
        "Increase recovery interventions (sleep, stress management)",
    });
  }

  return alerts;
}
