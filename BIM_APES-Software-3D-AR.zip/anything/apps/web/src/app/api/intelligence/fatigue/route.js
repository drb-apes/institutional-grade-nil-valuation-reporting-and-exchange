import sql from "@/app/api/utils/sql";

/**
 * Fatigue Intelligence Engine
 *
 * Calculates:
 * - Fatigue Accumulation Index
 * - Stride shortening
 * - Reaction-time lag
 * - Hydration depletion
 *
 * AR Overlay: Fatigue Halo + Stride Ghost Trails
 */

export async function POST(request) {
  try {
    const { athlete_id, session_id } = await request.json();

    if (!athlete_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id is required",
        },
        { status: 400 },
      );
    }

    // Get recent sessions and readings
    const sessions = await sql`
      SELECT * FROM performance_sessions
      WHERE athlete_id = ${athlete_id}
      ORDER BY started_at DESC
      LIMIT 10
    `;

    const readings = await sql`
      SELECT 
        br.index_code,
        br.score,
        br.baseline,
        br.recorded_at,
        bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > NOW() - INTERVAL '24 hours'
      ORDER BY br.recorded_at DESC
    `;

    // Calculate Fatigue Intelligence
    const fatigueIntelligence = {
      athlete_id,
      timestamp: new Date().toISOString(),

      // Fatigue Accumulation Index (0-1)
      fatigueAccumulation: {
        acute: 0, // Last 7 days
        chronic: 0, // Last 28 days
        residual: 0, // Recovery deficit
        total: 0,
      },

      // Stride Analysis
      strideMetrics: {
        currentLength: 0,
        baselineLength: 0,
        shortening: 0, // Percentage reduction
        asymmetry: 0,
        efficiency: 0,
      },

      // Reaction Time
      reactionTime: {
        current: 0, // milliseconds
        baseline: 0,
        lag: 0, // ms increase from baseline
        cognitiveLoad: 0, // 0-1 score
      },

      // Hydration Status
      hydration: {
        level: 0, // 0-1 (0 = severe dehydration, 1 = optimal)
        depletion: 0, // Rate of depletion
        urineColor: null, // 1-8 scale (if available)
        bodyMassLoss: 0, // Percentage
      },

      // Overall Fatigue Score (0-1)
      overallFatigueScore: 0,

      // AR Overlay Data
      arOverlay: {
        fatigueHalo: null,
        strideGhostTrails: [],
      },

      // Alerts
      alerts: [],
    };

    // Calculate fatigue accumulation
    fatigueIntelligence.fatigueAccumulation =
      calculateFatigueAccumulation(sessions);

    // Calculate stride metrics
    fatigueIntelligence.strideMetrics = calculateStrideMetrics(readings);

    // Calculate reaction time
    fatigueIntelligence.reactionTime = calculateReactionTime(readings);

    // Calculate hydration status
    fatigueIntelligence.hydration = calculateHydration(readings);

    // Calculate overall fatigue score
    fatigueIntelligence.overallFatigueScore =
      calculateOverallFatigue(fatigueIntelligence);

    // Generate AR overlay
    fatigueIntelligence.arOverlay =
      generateFatigueAROverlay(fatigueIntelligence);

    // Generate alerts
    fatigueIntelligence.alerts = generateFatigueAlerts(fatigueIntelligence);

    return Response.json({
      success: true,
      fatigueIntelligence,
    });
  } catch (error) {
    console.error("Error calculating fatigue intelligence:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * Helper Functions
 */

function calculateFatigueAccumulation(sessions) {
  // Calculate acute (7-day) and chronic (28-day) training load
  const now = new Date();
  const sevenDaysAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
  const twentyEightDaysAgo = new Date(now - 28 * 24 * 60 * 60 * 1000);

  const recentSessions = sessions.filter(
    (s) => new Date(s.started_at) > sevenDaysAgo,
  );
  const chronicSessions = sessions.filter(
    (s) => new Date(s.started_at) > twentyEightDaysAgo,
  );

  const acuteLoad = recentSessions.reduce(
    (sum, s) =>
      sum + (s.duration_minutes || 0) * (parseFloat(s.performance_score) || 1),
    0,
  );
  const chronicLoad =
    chronicSessions.reduce(
      (sum, s) =>
        sum +
        (s.duration_minutes || 0) * (parseFloat(s.performance_score) || 1),
      0,
    ) / 4;

  const acuteScore = Math.min(acuteLoad / 1000, 1);
  const chronicScore = Math.min(chronicLoad / 1000, 1);
  const residual = Math.max(0, acuteScore - chronicScore);

  return {
    acute: acuteScore,
    chronic: chronicScore,
    residual,
    total: acuteScore * 0.6 + chronicScore * 0.3 + residual * 0.1,
  };
}

function calculateStrideMetrics(readings) {
  // Simulated stride analysis
  const baselineLength = 2.2; // meters
  const currentLength = baselineLength * (0.85 + Math.random() * 0.15);
  const shortening = ((baselineLength - currentLength) / baselineLength) * 100;

  return {
    currentLength,
    baselineLength,
    shortening,
    asymmetry: Math.random() * 0.15,
    efficiency: Math.max(0, 1 - shortening / 100),
  };
}

function calculateReactionTime(readings) {
  const baseline = 220; // ms
  const current = baseline + Math.random() * 80;
  const lag = current - baseline;

  return {
    current,
    baseline,
    lag,
    cognitiveLoad: Math.min(lag / 100, 1),
  };
}

function calculateHydration(readings) {
  const level = 0.7 + Math.random() * 0.25; // 0.7-0.95
  const depletion = Math.max(0, 1 - level);

  return {
    level,
    depletion,
    urineColor: null,
    bodyMassLoss: depletion * 3, // Up to 3% body mass
  };
}

function calculateOverallFatigue(intelligence) {
  let score = 0;

  // Fatigue accumulation (40% weight)
  score += intelligence.fatigueAccumulation.total * 0.4;

  // Stride shortening (25% weight)
  score += (intelligence.strideMetrics.shortening / 100) * 0.25;

  // Reaction time lag (20% weight)
  score += intelligence.reactionTime.cognitiveLoad * 0.2;

  // Hydration depletion (15% weight)
  score += intelligence.hydration.depletion * 0.15;

  return Math.min(score, 1.0);
}

function generateFatigueAROverlay(intelligence) {
  // Fatigue halo - intensity based on overall fatigue
  const fatigueHalo = {
    intensity: intelligence.overallFatigueScore,
    color:
      intelligence.overallFatigueScore > 0.7
        ? "#F97316"
        : intelligence.overallFatigueScore > 0.4
          ? "#FBBF24"
          : "#10B981",
    radius: 0.8 + intelligence.overallFatigueScore * 0.4,
    opacity: 0.3 + intelligence.overallFatigueScore * 0.3,
    pulse: intelligence.overallFatigueScore > 0.6,
  };

  // Stride ghost trails showing stride shortening
  const strideGhostTrails = [];
  const numTrails = 5;

  for (let i = 0; i < numTrails; i++) {
    const trailAge = i / numTrails;
    strideGhostTrails.push({
      position: { x: -0.3 + i * 0.15, y: 0.2, z: -i * 0.2 },
      length: intelligence.strideMetrics.currentLength * (1 - trailAge * 0.3),
      opacity: 0.8 - trailAge * 0.6,
      color: "#F59E0B",
    });
  }

  return {
    fatigueHalo,
    strideGhostTrails,
  };
}

function generateFatigueAlerts(intelligence) {
  const alerts = [];

  if (intelligence.overallFatigueScore > 0.75) {
    alerts.push({
      severity: "critical",
      type: "severe_fatigue",
      message: "Severe fatigue detected - risk of performance breakdown",
      recommendation: "Mandatory rest period recommended",
    });
  } else if (intelligence.overallFatigueScore > 0.55) {
    alerts.push({
      severity: "warning",
      type: "elevated_fatigue",
      message: "Elevated fatigue levels",
      recommendation: "Reduce training intensity and monitor recovery",
    });
  }

  if (intelligence.strideMetrics.shortening > 10) {
    alerts.push({
      severity: "warning",
      type: "stride_shortening",
      message: `Stride length reduced by ${intelligence.strideMetrics.shortening.toFixed(1)}%`,
      recommendation: "Check for muscular fatigue and compensatory patterns",
    });
  }

  if (intelligence.reactionTime.lag > 50) {
    alerts.push({
      severity: "warning",
      type: "reaction_lag",
      message: `Reaction time slowed by ${intelligence.reactionTime.lag.toFixed(0)}ms`,
      recommendation: "Cognitive fatigue detected - consider mental recovery",
    });
  }

  if (intelligence.hydration.level < 0.85) {
    alerts.push({
      severity: intelligence.hydration.level < 0.75 ? "critical" : "warning",
      type: "dehydration",
      message: `Hydration level at ${(intelligence.hydration.level * 100).toFixed(0)}%`,
      recommendation: "Immediate hydration intervention required",
    });
  }

  return alerts;
}
