import sql from "@/app/api/utils/sql";

/**
 * Training Intelligence Engine
 *
 * Calculates:
 * - Acute:Chronic Workload Ratio
 * - Velocity loss
 * - Power output
 * - Technique drift
 *
 * AR Overlay: Load Pyramids + Technique Drift Lines
 */

export async function POST(request) {
  try {
    const { athlete_id } = await request.json();

    if (!athlete_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id is required",
        },
        { status: 400 },
      );
    }

    // Get training sessions
    const sessions = await sql`
      SELECT * FROM performance_sessions
      WHERE athlete_id = ${athlete_id}
        AND started_at > NOW() - INTERVAL '28 days'
      ORDER BY started_at DESC
    `;

    const readings = await sql`
      SELECT 
        br.index_code,
        br.score,
        br.baseline,
        br.recorded_at,
        bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > NOW() - INTERVAL '48 hours'
      ORDER BY br.recorded_at DESC
    `;

    const trainingIntelligence = {
      athlete_id,
      timestamp: new Date().toISOString(),

      // Acute:Chronic Workload Ratio (ACWR)
      workloadRatio: {
        acute: 0, // 7-day rolling average
        chronic: 0, // 28-day rolling average
        ratio: 0, // Acute / Chronic
        riskZone: "optimal", // 'low', 'optimal', 'elevated', 'high'
        safeRange: { min: 0.8, max: 1.3 },
      },

      // Velocity Metrics
      velocity: {
        current: 0, // m/s or % of max
        baseline: 0,
        loss: 0, // Percentage loss from baseline
        threshold: 10, // % loss threshold
        fatigueIndicator: false,
      },

      // Power Output
      power: {
        current: 0, // Watts
        peak: 0,
        average: 0,
        powerToWeight: 0, // W/kg
        decline: 0, // % decline in session
        efficiency: 0, // 0-1 score
      },

      // Technique Drift
      techniqueDrift: {
        overall: 0, // 0-1 (0 = perfect, 1 = complete breakdown)
        movementQuality: 0,
        formConsistency: 0,
        compensatoryPatterns: [],
        criticalThreshold: 0.4,
      },

      // Overall Training Load Score
      overallLoadScore: 0,

      // Training Readiness
      trainingReadiness: {
        score: 0, // 0-1
        recommendation: "normal", // 'rest', 'light', 'normal', 'intense'
        targetIntensity: 0, // 0-1
      },

      // AR Overlay Data
      arOverlay: {
        loadPyramids: [],
        techniqueDriftLines: [],
      },

      // Alerts
      alerts: [],
    };

    // Calculate ACWR
    trainingIntelligence.workloadRatio = calculateACWR(sessions);

    // Calculate velocity metrics
    trainingIntelligence.velocity = calculateVelocity(readings, sessions);

    // Calculate power output
    trainingIntelligence.power = calculatePower(readings, sessions);

    // Calculate technique drift
    trainingIntelligence.techniqueDrift = calculateTechniqueDrift(
      readings,
      sessions,
    );

    // Calculate overall load
    trainingIntelligence.overallLoadScore =
      calculateOverallLoad(trainingIntelligence);

    // Calculate training readiness
    trainingIntelligence.trainingReadiness =
      calculateTrainingReadiness(trainingIntelligence);

    // Generate AR overlay
    trainingIntelligence.arOverlay =
      generateTrainingAROverlay(trainingIntelligence);

    // Generate alerts
    trainingIntelligence.alerts = generateTrainingAlerts(trainingIntelligence);

    return Response.json({
      success: true,
      trainingIntelligence,
    });
  } catch (error) {
    console.error("Error calculating training intelligence:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * Helper Functions
 */

function calculateACWR(sessions) {
  const now = new Date();
  const sevenDaysAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
  const twentyEightDaysAgo = new Date(now - 28 * 24 * 60 * 60 * 1000);

  const acuteSessions = sessions.filter(
    (s) => new Date(s.started_at) > sevenDaysAgo,
  );
  const chronicSessions = sessions.filter(
    (s) => new Date(s.started_at) > twentyEightDaysAgo,
  );

  const acuteLoad =
    acuteSessions.reduce(
      (sum, s) =>
        sum +
        (s.duration_minutes || 0) * (parseFloat(s.performance_score) || 1),
      0,
    ) / 7;

  const chronicLoad =
    chronicSessions.reduce(
      (sum, s) =>
        sum +
        (s.duration_minutes || 0) * (parseFloat(s.performance_score) || 1),
      0,
    ) / 28;

  const ratio = chronicLoad > 0 ? acuteLoad / chronicLoad : 0;

  let riskZone = "optimal";
  if (ratio < 0.8) riskZone = "low";
  else if (ratio > 1.5) riskZone = "high";
  else if (ratio > 1.3) riskZone = "elevated";

  return {
    acute: acuteLoad,
    chronic: chronicLoad,
    ratio,
    riskZone,
    safeRange: { min: 0.8, max: 1.3 },
  };
}

function calculateVelocity(readings, sessions) {
  const baseline = 8.5; // m/s (example)
  const current = baseline * (0.92 + Math.random() * 0.12);
  const loss = ((baseline - current) / baseline) * 100;

  return {
    current,
    baseline,
    loss,
    threshold: 10,
    fatigueIndicator: loss > 10,
  };
}

function calculatePower(readings, sessions) {
  const peak = 1200; // Watts
  const current = peak * (0.85 + Math.random() * 0.12);
  const average = current * 0.85;
  const bodyWeight = 75; // kg (example)

  return {
    current,
    peak,
    average,
    powerToWeight: current / bodyWeight,
    decline: ((peak - current) / peak) * 100,
    efficiency: current / peak,
  };
}

function calculateTechniqueDrift(readings, sessions) {
  const movementQuality = 0.7 + Math.random() * 0.25;
  const formConsistency = 0.75 + Math.random() * 0.2;
  const overall = 1 - (movementQuality + formConsistency) / 2;

  const compensatory = [];
  if (overall > 0.3) {
    compensatory.push("Hip drop on right side");
  }
  if (overall > 0.4) {
    compensatory.push("Forward trunk lean");
  }

  return {
    overall,
    movementQuality: 1 - movementQuality,
    formConsistency: 1 - formConsistency,
    compensatoryPatterns: compensatory,
    criticalThreshold: 0.4,
  };
}

function calculateOverallLoad(intelligence) {
  let score = 0;

  // ACWR contribution (40%)
  if (intelligence.workloadRatio.ratio > 1.5) {
    score += 0.4;
  } else if (intelligence.workloadRatio.ratio > 1.3) {
    score += 0.25;
  } else if (intelligence.workloadRatio.ratio < 0.8) {
    score += 0.15;
  } else {
    score += 0.1;
  }

  // Velocity loss (25%)
  score += Math.min(intelligence.velocity.loss / 20, 0.25);

  // Power decline (20%)
  score += Math.min(intelligence.power.decline / 20, 0.2);

  // Technique drift (15%)
  score += intelligence.techniqueDrift.overall * 0.15;

  return Math.min(score, 1);
}

function calculateTrainingReadiness(intelligence) {
  let readiness = 1.0;

  // Reduce for high workload ratio
  if (intelligence.workloadRatio.ratio > 1.3) {
    readiness -= 0.3;
  }

  // Reduce for velocity loss
  readiness -= Math.min(intelligence.velocity.loss / 100, 0.2);

  // Reduce for power decline
  readiness -= Math.min(intelligence.power.decline / 100, 0.2);

  // Reduce for technique drift
  readiness -= intelligence.techniqueDrift.overall * 0.3;

  readiness = Math.max(0, Math.min(readiness, 1));

  let recommendation = "normal";
  if (readiness < 0.4) recommendation = "rest";
  else if (readiness < 0.6) recommendation = "light";
  else if (readiness > 0.85) recommendation = "intense";

  return {
    score: readiness,
    recommendation,
    targetIntensity: readiness,
  };
}

function generateTrainingAROverlay(intelligence) {
  // Load pyramids showing training load distribution
  const loadPyramids = [
    {
      type: "acute_load",
      position: { x: -0.4, y: 0.3, z: 0 },
      height: intelligence.workloadRatio.acute / 100,
      color:
        intelligence.workloadRatio.riskZone === "high"
          ? "#EF4444"
          : intelligence.workloadRatio.riskZone === "elevated"
            ? "#F59E0B"
            : "#10B981",
      label: "7-day",
    },
    {
      type: "chronic_load",
      position: { x: 0, y: 0.3, z: 0 },
      height: intelligence.workloadRatio.chronic / 100,
      color: "#3B82F6",
      label: "28-day",
    },
    {
      type: "readiness",
      position: { x: 0.4, y: 0.3, z: 0 },
      height: intelligence.trainingReadiness.score,
      color:
        intelligence.trainingReadiness.score > 0.7
          ? "#10B981"
          : intelligence.trainingReadiness.score > 0.4
            ? "#FBBF24"
            : "#EF4444",
      label: "Readiness",
    },
  ];

  // Technique drift lines showing form degradation
  const techniqueDriftLines = [];
  const driftPoints = 10;

  for (let i = 0; i < driftPoints; i++) {
    const progression = i / driftPoints;
    const drift = intelligence.techniqueDrift.overall * progression;

    techniqueDriftLines.push({
      position: { x: -0.4 + i * 0.08, y: 0.6, z: 0 },
      deviation: drift * 0.2,
      color: drift > 0.3 ? "#EF4444" : drift > 0.15 ? "#F59E0B" : "#10B981",
      opacity: 0.8 - progression * 0.3,
    });
  }

  return {
    loadPyramids,
    techniqueDriftLines,
  };
}

function generateTrainingAlerts(intelligence) {
  const alerts = [];

  if (intelligence.workloadRatio.riskZone === "high") {
    alerts.push({
      severity: "critical",
      type: "high_workload_ratio",
      message: `ACWR at ${intelligence.workloadRatio.ratio.toFixed(2)} - high injury risk`,
      recommendation: "Reduce training volume immediately",
    });
  } else if (intelligence.workloadRatio.riskZone === "elevated") {
    alerts.push({
      severity: "warning",
      type: "elevated_workload",
      message: `ACWR at ${intelligence.workloadRatio.ratio.toFixed(2)} - approaching danger zone`,
      recommendation: "Monitor closely and consider volume reduction",
    });
  } else if (intelligence.workloadRatio.riskZone === "low") {
    alerts.push({
      severity: "info",
      type: "low_workload",
      message: "Training load may be insufficient for adaptation",
      recommendation: "Consider progressive volume increase",
    });
  }

  if (intelligence.velocity.fatigueIndicator) {
    alerts.push({
      severity: "warning",
      type: "velocity_loss",
      message: `Velocity loss at ${intelligence.velocity.loss.toFixed(1)}% - fatigue detected`,
      recommendation: "End high-intensity work and focus on recovery",
    });
  }

  if (
    intelligence.techniqueDrift.overall >
    intelligence.techniqueDrift.criticalThreshold
  ) {
    alerts.push({
      severity: "critical",
      type: "technique_breakdown",
      message: "Technique breakdown detected",
      recommendation: "Stop training - risk of compensatory injury",
      compensatory: intelligence.techniqueDrift.compensatoryPatterns,
    });
  }

  if (intelligence.trainingReadiness.recommendation === "rest") {
    alerts.push({
      severity: "critical",
      type: "low_readiness",
      message: "Training readiness critically low",
      recommendation: "Full rest day recommended",
    });
  }

  return alerts;
}
