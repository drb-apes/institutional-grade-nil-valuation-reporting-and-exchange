import sql from "@/app/api/utils/sql";

/**
 * Market Intelligence Engine
 *
 * Analyzes biometric data to detect:
 * - Player Bull Market Signals
 * - Player Bear Market Signals
 * - Team-Level Market Trends
 * - NIL Valuation Momentum
 */

export async function POST(request) {
  try {
    const { athlete_id, team_id } = await request.json();

    if (!athlete_id && !team_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id or team_id is required",
        },
        { status: 400 },
      );
    }

    const marketIntelligence = {
      timestamp: new Date().toISOString(),
      athlete_id,
      team_id,

      // Player Market Signals
      playerMarket: {
        trend: "neutral", // 'bull', 'bear', 'neutral'
        confidence: 0, // 0-1
        signals: {
          bull: [],
          bear: [],
        },
        nilMomentum: 0, // -1 to +1
        breakoutProbability: 0, // 0-1
      },

      // Team Market Signals (if team_id provided)
      teamMarket: {
        trend: "neutral",
        confidence: 0,
        rosterFatigue: 0, // 0-1
        recoveryVelocity: 0, // 0-1
        injuryCluster: false,
        substitutionVolatility: 0,
      },

      // NIL Valuation Indicators
      nilIndicators: {
        performanceTrend: 0, // -1 to +1
        consistencyScore: 0, // 0-1
        sponsorConvexity: 0, // 0-1
        marketSentiment: 0, // -1 to +1
      },

      // Trading Recommendations
      tradingSignals: [],

      // Alerts
      alerts: [],
    };

    if (athlete_id) {
      // Get stress, fatigue, and recovery intelligence
      const [stressRes, fatigueRes, recoveryRes] = await Promise.all([
        fetch(new URL("/api/intelligence/stress", request.url), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ athlete_id }),
        }),
        fetch(new URL("/api/intelligence/fatigue", request.url), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ athlete_id }),
        }),
        fetch(new URL("/api/intelligence/recovery", request.url), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ athlete_id }),
        }),
      ]);

      const stress = await stressRes.json();
      const fatigue = await fatigueRes.json();
      const recovery = await recoveryRes.json();

      // Analyze player market
      marketIntelligence.playerMarket = analyzePlayerMarket(
        stress,
        fatigue,
        recovery,
      );
      marketIntelligence.nilIndicators = calculateNILIndicators(
        stress,
        fatigue,
        recovery,
      );
      marketIntelligence.tradingSignals =
        generateTradingSignals(marketIntelligence);
    }

    if (team_id) {
      // Get team-level data
      const teamAthletes = await sql`
        SELECT id FROM athletes WHERE team = ${team_id}
      `;

      // Aggregate team metrics (simplified for demo)
      marketIntelligence.teamMarket = analyzeTeamMarket(teamAthletes);
    }

    // Generate alerts
    marketIntelligence.alerts = generateMarketAlerts(marketIntelligence);

    return Response.json({
      success: true,
      marketIntelligence,
    });
  } catch (error) {
    console.error("Error calculating market intelligence:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * Helper Functions
 */

function analyzePlayerMarket(stress, fatigue, recovery) {
  const bullSignals = [];
  const bearSignals = [];

  // Check recovery indicators (BULL signals)
  if (recovery.success && recovery.recoveryIntelligence) {
    const rec = recovery.recoveryIntelligence;

    if (rec.overallRecoveryScore > 0.75) {
      bullSignals.push({
        type: "rapid_recovery",
        strength: rec.overallRecoveryScore,
        message: "Rapid recovery velocity detected",
      });
    }

    if (rec.recoveryVelocity > 0.7) {
      bullSignals.push({
        type: "recovery_velocity",
        strength: rec.recoveryVelocity,
        message: "High recovery velocity",
      });
    }

    if (rec.sleep.quality > 0.85) {
      bullSignals.push({
        type: "sleep_quality",
        strength: rec.sleep.quality,
        message: "Optimal sleep quality",
      });
    }
  }

  // Check stress indicators (BEAR signals if high)
  if (stress.success && stress.stressIntelligence) {
    const str = stress.stressIntelligence;

    if (str.overallStressScore > 0.7) {
      bearSignals.push({
        type: "elevated_stress",
        strength: str.overallStressScore,
        message: "Stress accumulation detected",
      });
    }

    if (str.jointTorque.asymmetryScore > 0.3) {
      bearSignals.push({
        type: "asymmetry_risk",
        strength: str.jointTorque.asymmetryScore,
        message: "Injury-risk premium from asymmetry",
      });
    }
  }

  // Check fatigue indicators (BEAR signals if high)
  if (fatigue.success && fatigue.fatigueIntelligence) {
    const fat = fatigue.fatigueIntelligence;

    if (fat.overallFatigueScore > 0.6) {
      bearSignals.push({
        type: "fatigue_accumulation",
        strength: fat.overallFatigueScore,
        message: "Fatigue accumulation → NIL decay",
      });
    }

    if (fat.strideMetrics.shortening > 10) {
      bearSignals.push({
        type: "stride_shortening",
        strength: fat.strideMetrics.shortening / 100,
        message: "Performance degradation detected",
      });
    }
  }

  // Determine overall trend
  const bullStrength =
    bullSignals.reduce((sum, s) => sum + s.strength, 0) /
    Math.max(bullSignals.length, 1);
  const bearStrength =
    bearSignals.reduce((sum, s) => sum + s.strength, 0) /
    Math.max(bearSignals.length, 1);

  let trend = "neutral";
  let confidence = 0;

  if (bullStrength > bearStrength + 0.2) {
    trend = "bull";
    confidence = Math.min((bullStrength - bearStrength) / 0.5, 1);
  } else if (bearStrength > bullStrength + 0.2) {
    trend = "bear";
    confidence = Math.min((bearStrength - bullStrength) / 0.5, 1);
  } else {
    confidence = 0.5;
  }

  // Calculate NIL momentum
  const nilMomentum = bullStrength - bearStrength;

  // Calculate breakout probability
  const breakoutProbability =
    trend === "bull" ? Math.min(bullStrength * confidence, 1) : 0;

  return {
    trend,
    confidence,
    signals: {
      bull: bullSignals,
      bear: bearSignals,
    },
    nilMomentum,
    breakoutProbability,
  };
}

function calculateNILIndicators(stress, fatigue, recovery) {
  let performanceTrend = 0;
  let consistencyScore = 0.7; // Default
  let sponsorConvexity = 0.5; // Default

  // Performance trend from recovery and fatigue
  if (recovery.success && fatigue.success) {
    const recScore = recovery.recoveryIntelligence.overallRecoveryScore;
    const fatScore = 1 - fatigue.fatigueIntelligence.overallFatigueScore;
    performanceTrend = ((recScore + fatScore) / 2 - 0.5) * 2; // -1 to +1
  }

  // Consistency from stress variability
  if (stress.success) {
    const stressVar = stress.stressIntelligence.overallStressScore;
    consistencyScore = 1 - stressVar * 0.5;
  }

  // Sponsor convexity from recovery velocity and low stress
  if (recovery.success && stress.success) {
    const recVel = recovery.recoveryIntelligence.recoveryVelocity;
    const lowStress = 1 - stress.stressIntelligence.overallStressScore;
    sponsorConvexity = recVel * 0.6 + lowStress * 0.4;
  }

  const marketSentiment = performanceTrend;

  return {
    performanceTrend,
    consistencyScore,
    sponsorConvexity,
    marketSentiment,
  };
}

function generateTradingSignals(intelligence) {
  const signals = [];

  // LONG signals (Bull market)
  if (
    intelligence.playerMarket.trend === "bull" &&
    intelligence.playerMarket.confidence > 0.6
  ) {
    signals.push({
      type: "LONG",
      strategy: "momentum",
      confidence: intelligence.playerMarket.confidence,
      reasoning: "High readiness + rapid recovery + low stress",
      entry: "Current NIL valuation",
      target: "+15-25% upside",
      timeframe: "7-14 days",
    });
  }

  // SHORT/HEDGE signals (Bear market)
  if (
    intelligence.playerMarket.trend === "bear" &&
    intelligence.playerMarket.confidence > 0.6
  ) {
    signals.push({
      type: "SHORT",
      strategy: "hedge",
      confidence: intelligence.playerMarket.confidence,
      reasoning: "Rising fatigue + stress accumulation + injury risk",
      entry: "Current NIL valuation",
      target: "Protect against 10-20% downside",
      timeframe: "3-7 days",
    });
  }

  // ARBITRAGE signals (Mispricing detected)
  if (Math.abs(intelligence.nilIndicators.marketSentiment) > 0.4) {
    signals.push({
      type: "ARBITRAGE",
      strategy: "mispricing",
      confidence: Math.abs(intelligence.nilIndicators.marketSentiment),
      reasoning:
        intelligence.nilIndicators.marketSentiment > 0
          ? "Undervalued - biometrics better than market pricing"
          : "Overvalued - biometrics worse than market pricing",
      entry: "Spread exists",
      target: "Gap closure",
      timeframe: "48-72 hours",
    });
  }

  // BREAKOUT signals
  if (intelligence.playerMarket.breakoutProbability > 0.7) {
    signals.push({
      type: "BREAKOUT",
      strategy: "scalping",
      confidence: intelligence.playerMarket.breakoutProbability,
      reasoning: "Optimal performance window + sponsor convexity",
      entry: "Immediate",
      target: "+10-15% spike",
      timeframe: "24-48 hours",
    });
  }

  return signals;
}

function analyzeTeamMarket(teamAthletes) {
  // Simplified team market analysis
  return {
    trend: "neutral",
    confidence: 0.5,
    rosterFatigue: 0.4 + Math.random() * 0.3,
    recoveryVelocity: 0.5 + Math.random() * 0.3,
    injuryCluster: Math.random() > 0.7,
    substitutionVolatility: 0.3 + Math.random() * 0.4,
  };
}

function generateMarketAlerts(intelligence) {
  const alerts = [];

  if (
    intelligence.playerMarket.trend === "bull" &&
    intelligence.playerMarket.confidence > 0.75
  ) {
    alerts.push({
      severity: "info",
      type: "bull_market",
      message: "Strong bull market signals detected",
      recommendation: "Consider LONG position or increased NIL activation",
    });
  }

  if (
    intelligence.playerMarket.trend === "bear" &&
    intelligence.playerMarket.confidence > 0.75
  ) {
    alerts.push({
      severity: "warning",
      type: "bear_market",
      message: "Strong bear market signals detected",
      recommendation: "Consider hedging or reducing NIL exposure",
    });
  }

  if (intelligence.playerMarket.breakoutProbability > 0.8) {
    alerts.push({
      severity: "info",
      type: "breakout_opportunity",
      message: "High breakout probability detected",
      recommendation: "Optimal window for sponsor activation",
    });
  }

  if (intelligence.teamMarket && intelligence.teamMarket.injuryCluster) {
    alerts.push({
      severity: "critical",
      type: "injury_cluster",
      message: "Injury cluster detected at team level",
      recommendation: "Systemic risk - review training protocols",
    });
  }

  return alerts;
}
