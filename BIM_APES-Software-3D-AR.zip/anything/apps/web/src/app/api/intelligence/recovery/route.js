import sql from "@/app/api/utils/sql";

/**
 * Recovery Intelligence Engine
 *
 * Calculates:
 * - Sleep debt
 * - HRV recovery curve
 * - Muscle soreness index
 * - Tissue repair biomarkers
 *
 * AR Overlay: Recovery Rings + Tissue Repair Heatmap
 */

export async function POST(request) {
  try {
    const { athlete_id } = await request.json();

    if (!athlete_id) {
      return Response.json(
        {
          success: false,
          error: "athlete_id is required",
        },
        { status: 400 },
      );
    }

    const readings = await sql`
      SELECT 
        br.index_code,
        br.score,
        br.baseline,
        br.recorded_at,
        bid.index_name
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
        AND br.recorded_at > NOW() - INTERVAL '48 hours'
      ORDER BY br.recorded_at DESC
    `;

    const recoveryIntelligence = {
      athlete_id,
      timestamp: new Date().toISOString(),

      // Sleep Metrics
      sleep: {
        lastNightDuration: 7.5 + Math.random() * 1.5, // hours
        optimalDuration: 8.5,
        debt: 0, // Cumulative hours
        quality: 0.7 + Math.random() * 0.25, // 0-1
        efficiency: 0.8 + Math.random() * 0.15, // 0-1
      },

      // HRV Recovery Curve
      hrvRecovery: {
        current: 0,
        baseline: 0,
        recoveryRate: 0, // % per hour
        timeToBaseline: 0, // hours
        curveSlope: 0, // Positive = recovering, negative = declining
      },

      // Muscle Soreness Index (0-1)
      muscleSoreness: {
        overall: 0,
        quadriceps: 0,
        hamstrings: 0,
        calves: 0,
        glutes: 0,
        shoulders: 0,
        upperBack: 0,
      },

      // Tissue Repair Biomarkers
      tissueRepair: {
        creatineKinase: 0, // U/L (elevated = muscle damage)
        inflammation: 0, // 0-1 score
        repairRate: 0, // 0-1 (higher = faster repair)
        healingPhase: "acute", // 'acute', 'repair', 'remodeling', 'complete'
      },

      // Overall Recovery Score (0-1, higher = better recovery)
      overallRecoveryScore: 0,

      // Recovery Velocity (rate of recovery)
      recoveryVelocity: 0,

      // AR Overlay Data
      arOverlay: {
        recoveryRings: [],
        tissueRepairHeatmap: [],
      },

      // Alerts
      alerts: [],
    };

    // Calculate sleep debt
    recoveryIntelligence.sleep.debt = Math.max(
      0,
      recoveryIntelligence.sleep.optimalDuration -
        recoveryIntelligence.sleep.lastNightDuration,
    );

    // Calculate HRV recovery
    const hrvReading = readings.find((r) => r.index_code === "HRVi");
    if (hrvReading) {
      recoveryIntelligence.hrvRecovery.current = hrvReading.score;
      recoveryIntelligence.hrvRecovery.baseline =
        hrvReading.baseline || hrvReading.score;

      const hrvRatio =
        recoveryIntelligence.hrvRecovery.current /
        recoveryIntelligence.hrvRecovery.baseline;
      recoveryIntelligence.hrvRecovery.recoveryRate = Math.max(
        0,
        (hrvRatio - 0.8) * 10,
      );
      recoveryIntelligence.hrvRecovery.timeToBaseline =
        hrvRatio < 1
          ? (1 - hrvRatio) /
            Math.max(recoveryIntelligence.hrvRecovery.recoveryRate, 0.01)
          : 0;
      recoveryIntelligence.hrvRecovery.curveSlope =
        recoveryIntelligence.hrvRecovery.recoveryRate - 0.5;
    }

    // Calculate muscle soreness (simulated)
    const muscleGroups = [
      "quadriceps",
      "hamstrings",
      "calves",
      "glutes",
      "shoulders",
      "upperBack",
    ];
    muscleGroups.forEach((muscle) => {
      recoveryIntelligence.muscleSoreness[muscle] = Math.random() * 0.6;
    });
    recoveryIntelligence.muscleSoreness.overall =
      muscleGroups.reduce(
        (sum, m) => sum + recoveryIntelligence.muscleSoreness[m],
        0,
      ) / muscleGroups.length;

    // Calculate tissue repair (simulated)
    recoveryIntelligence.tissueRepair.creatineKinase =
      150 + Math.random() * 300; // Normal: 30-200
    recoveryIntelligence.tissueRepair.inflammation = Math.min(
      recoveryIntelligence.tissueRepair.creatineKinase / 500,
      1,
    );
    recoveryIntelligence.tissueRepair.repairRate = 0.5 + Math.random() * 0.4;

    // Determine healing phase
    if (recoveryIntelligence.tissueRepair.inflammation > 0.6) {
      recoveryIntelligence.tissueRepair.healingPhase = "acute";
    } else if (recoveryIntelligence.tissueRepair.inflammation > 0.3) {
      recoveryIntelligence.tissueRepair.healingPhase = "repair";
    } else if (recoveryIntelligence.tissueRepair.repairRate > 0.7) {
      recoveryIntelligence.tissueRepair.healingPhase = "remodeling";
    } else {
      recoveryIntelligence.tissueRepair.healingPhase = "complete";
    }

    // Calculate overall recovery score
    recoveryIntelligence.overallRecoveryScore =
      calculateOverallRecovery(recoveryIntelligence);

    // Calculate recovery velocity
    recoveryIntelligence.recoveryVelocity =
      calculateRecoveryVelocity(recoveryIntelligence);

    // Generate AR overlay
    recoveryIntelligence.arOverlay =
      generateRecoveryAROverlay(recoveryIntelligence);

    // Generate alerts
    recoveryIntelligence.alerts = generateRecoveryAlerts(recoveryIntelligence);

    return Response.json({
      success: true,
      recoveryIntelligence,
    });
  } catch (error) {
    console.error("Error calculating recovery intelligence:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}

/**
 * Helper Functions
 */

function calculateOverallRecovery(intelligence) {
  let score = 1.0; // Start at fully recovered

  // Sleep impact (30% weight)
  const sleepScore = Math.max(0, 1 - intelligence.sleep.debt / 8);
  score -= (1 - sleepScore) * 0.3;

  // HRV recovery impact (30% weight)
  const hrvScore =
    intelligence.hrvRecovery.current /
    Math.max(intelligence.hrvRecovery.baseline, 1);
  score -= (1 - Math.min(hrvScore, 1)) * 0.3;

  // Muscle soreness impact (25% weight)
  score -= intelligence.muscleSoreness.overall * 0.25;

  // Tissue repair impact (15% weight)
  score -= intelligence.tissueRepair.inflammation * 0.15;

  return Math.max(0, Math.min(score, 1));
}

function calculateRecoveryVelocity(intelligence) {
  // Recovery velocity = rate of improvement
  let velocity = 0;

  // HRV recovery rate contribution
  velocity += intelligence.hrvRecovery.recoveryRate * 0.4;

  // Tissue repair rate contribution
  velocity += intelligence.tissueRepair.repairRate * 0.3;

  // Sleep quality contribution
  velocity += intelligence.sleep.quality * 0.2;

  // Inverse of muscle soreness (less soreness = faster recovery)
  velocity += (1 - intelligence.muscleSoreness.overall) * 0.1;

  return Math.min(velocity, 1);
}

function generateRecoveryAROverlay(intelligence) {
  // Recovery rings - concentric rings showing recovery status
  const recoveryRings = [
    {
      type: "outer_recovery",
      radius: 1.0,
      intensity: intelligence.overallRecoveryScore,
      color:
        intelligence.overallRecoveryScore > 0.7
          ? "#10B981"
          : intelligence.overallRecoveryScore > 0.4
            ? "#FBBF24"
            : "#EF4444",
      thickness: 0.05,
      position: { x: 0, y: 0.6, z: 0 },
    },
    {
      type: "hrv_recovery",
      radius: 0.7,
      intensity:
        intelligence.hrvRecovery.current /
        Math.max(intelligence.hrvRecovery.baseline, 1),
      color: "#3B82F6",
      thickness: 0.04,
      position: { x: 0, y: 0.6, z: 0 },
    },
    {
      type: "sleep_recovery",
      radius: 0.4,
      intensity: intelligence.sleep.quality,
      color: "#8B5CF6",
      thickness: 0.03,
      position: { x: 0, y: 0.6, z: 0 },
    },
  ];

  // Tissue repair heatmap - shows muscle group recovery
  const muscleGroups = [
    { name: "quadriceps", position: { x: 0, y: 0.4, z: 0 } },
    { name: "hamstrings", position: { x: 0, y: 0.35, z: -0.1 } },
    { name: "calves", position: { x: 0, y: 0.15, z: 0 } },
    { name: "glutes", position: { x: 0, y: 0.5, z: -0.1 } },
    { name: "shoulders", position: { x: 0, y: 0.85, z: 0 } },
    { name: "upperBack", position: { x: 0, y: 0.75, z: -0.1 } },
  ];

  const tissueRepairHeatmap = muscleGroups.map((muscle) => {
    const soreness = intelligence.muscleSoreness[muscle];
    const recovery = 1 - soreness;

    return {
      muscle: muscle.name,
      position: muscle.position,
      soreness,
      recovery,
      color:
        recovery > 0.7 ? "#10B981" : recovery > 0.4 ? "#FBBF24" : "#EF4444",
      intensity: soreness,
      repairPhase: intelligence.tissueRepair.healingPhase,
    };
  });

  return {
    recoveryRings,
    tissueRepairHeatmap,
  };
}

function generateRecoveryAlerts(intelligence) {
  const alerts = [];

  if (intelligence.overallRecoveryScore < 0.4) {
    alerts.push({
      severity: "critical",
      type: "poor_recovery",
      message: "Poor recovery status detected",
      recommendation:
        "Extended rest period required before next training session",
    });
  } else if (intelligence.overallRecoveryScore < 0.6) {
    alerts.push({
      severity: "warning",
      type: "suboptimal_recovery",
      message: "Suboptimal recovery status",
      recommendation:
        "Reduce training intensity and enhance recovery protocols",
    });
  }

  if (intelligence.sleep.debt > 2) {
    alerts.push({
      severity: "warning",
      type: "sleep_debt",
      message: `Sleep debt accumulated: ${intelligence.sleep.debt.toFixed(1)} hours`,
      recommendation: "Prioritize sleep extension and quality improvement",
    });
  }

  if (intelligence.hrvRecovery.timeToBaseline > 24) {
    alerts.push({
      severity: "warning",
      type: "slow_hrv_recovery",
      message: `HRV recovery estimated at ${intelligence.hrvRecovery.timeToBaseline.toFixed(0)} hours`,
      recommendation: "Delay high-intensity training until HRV normalizes",
    });
  }

  if (intelligence.muscleSoreness.overall > 0.6) {
    alerts.push({
      severity: "warning",
      type: "high_muscle_soreness",
      message: "Elevated muscle soreness across multiple groups",
      recommendation: "Implement active recovery and soft tissue work",
    });
  }

  if (intelligence.tissueRepair.healingPhase === "acute") {
    alerts.push({
      severity: "critical",
      type: "acute_tissue_damage",
      message: "Acute tissue damage phase detected",
      recommendation:
        "Rest and rehabilitation required - avoid loading damaged tissues",
    });
  }

  return alerts;
}
