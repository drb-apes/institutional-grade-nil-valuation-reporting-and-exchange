import sql from "@/app/api/utils/sql";
import {
  validationError,
  internalError,
  successResponse,
} from "@/app/api/utils/errorHandler";

/**
 * Get fan engagement metrics for boost credits and tipping flow
 * GET /api/fan-engagement/metrics?athleteId=xxx&days=30
 */

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athleteId = searchParams.get("athleteId");
    const days = parseInt(searchParams.get("days") || "30");
    const limit = parseInt(searchParams.get("limit") || "10");

    // If specific athlete requested
    if (athleteId) {
      const [athlete] = await sql`
        SELECT id, first_name, last_name 
        FROM athletes 
        WHERE id = ${athleteId}
      `;

      if (!athlete) {
        return validationError("Athlete not found");
      }

      // Get engagement data for this athlete
      const engagementData = await sql`
        SELECT 
          COUNT(*) FILTER (WHERE engagement_type = 'boost') as total_boosts,
          COUNT(*) FILTER (WHERE engagement_type = 'replay') as total_replays,
          COUNT(*) FILTER (WHERE engagement_type = 'share') as total_shares,
          COUNT(*) FILTER (WHERE engagement_type = 'vote') as total_votes,
          COUNT(*) as total_interactions,
          SUM(engagement_value) as total_engagement_value
        FROM sponsor_engagement se
        JOIN sponsor_activations sa ON sa.id = se.activation_id
        WHERE sa.athlete_id = ${athleteId}
          AND se.recorded_at > NOW() - INTERVAL '${days} days'
      `;

      const [metrics] =
        engagementData.length > 0
          ? engagementData
          : [
              {
                total_boosts: 0,
                total_replays: 0,
                total_shares: 0,
                total_votes: 0,
                total_interactions: 0,
                total_engagement_value: 0,
              },
            ];

      // Calculate derived metrics for tipping flow
      const nilMoments = Math.floor(parseInt(metrics.total_boosts) * 0.55);
      const sponsorBonuses = Math.floor(parseInt(metrics.total_boosts) * 0.22);
      const athleteRewards = Math.floor(parseInt(metrics.total_boosts) * 0.34);

      return successResponse({
        athlete: {
          id: athlete.id,
          name: `${athlete.first_name} ${athlete.last_name}`,
        },
        time_range: {
          days,
          from: new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString(),
          to: new Date().toISOString(),
        },
        engagement_summary: {
          total_boosts: parseInt(metrics.total_boosts),
          total_replays: parseInt(metrics.total_replays),
          total_shares: parseInt(metrics.total_shares),
          total_votes: parseInt(metrics.total_votes),
          total_interactions: parseInt(metrics.total_interactions),
          total_value: parseFloat(metrics.total_engagement_value || 0),
        },
        tipping_flow: {
          total_boosts: parseInt(metrics.total_boosts),
          nil_moments: nilMoments,
          sponsor_bonuses: sponsorBonuses,
          athlete_rewards: athleteRewards,
        },
      });
    }

    // Get top athletes by boost count
    const topAthletes = await sql`
      SELECT 
        a.id,
        a.first_name || ' ' || a.last_name as name,
        COUNT(*) FILTER (WHERE se.engagement_type = 'boost') as boost_count,
        COUNT(*) as total_engagements,
        SUM(se.engagement_value) as total_value
      FROM athletes a
      LEFT JOIN sponsor_activations sa ON sa.athlete_id = a.id
      LEFT JOIN sponsor_engagement se ON se.activation_id = sa.id 
        AND se.recorded_at > NOW() - INTERVAL '${days} days'
      WHERE a.coalition_status = 'Active'
      GROUP BY a.id, a.first_name, a.last_name
      HAVING COUNT(*) FILTER (WHERE se.engagement_type = 'boost') > 0
      ORDER BY boost_count DESC
      LIMIT ${limit}
    `;

    // Calculate aggregate tipping flow
    const [aggregateFlow] = await sql`
      SELECT 
        COUNT(*) FILTER (WHERE se.engagement_type = 'boost') as total_boosts,
        COUNT(*) FILTER (WHERE se.engagement_type = 'replay') as total_replays,
        COUNT(*) FILTER (WHERE se.engagement_type = 'share') as total_shares,
        SUM(se.engagement_value) as total_value
      FROM sponsor_engagement se
      WHERE se.recorded_at > NOW() - INTERVAL '${days} days'
    `;

    const totalBoosts = parseInt(aggregateFlow?.total_boosts || 0);
    const nilMoments = Math.floor(totalBoosts * 0.55);
    const sponsorBonuses = Math.floor(totalBoosts * 0.22);
    const athleteRewards = Math.floor(totalBoosts * 0.34);

    return successResponse({
      time_range: {
        days,
        from: new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString(),
        to: new Date().toISOString(),
      },
      top_athletes: topAthletes.map((a) => ({
        id: a.id,
        name: a.name,
        boost_count: parseInt(a.boost_count),
        total_engagements: parseInt(a.total_engagements),
        total_value: parseFloat(a.total_value || 0),
      })),
      aggregate_tipping_flow: {
        total_boosts: totalBoosts,
        nil_moments: nilMoments,
        sponsor_bonuses: sponsorBonuses,
        athlete_rewards: athleteRewards,
      },
      summary: {
        total_athletes: topAthletes.length,
        total_boosts: totalBoosts,
        total_value: parseFloat(aggregateFlow?.total_value || 0),
      },
    });
  } catch (error) {
    console.error("Fan engagement metrics error:", error);
    return internalError(error, "fetching fan engagement metrics");
  }
}

/**
 * Record fan engagement event
 * POST /api/fan-engagement/metrics
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      campaign_id,
      engagement_type,
      engagement_value = 1,
      metadata = {},
    } = body;

    if (!athlete_id || !engagement_type) {
      return validationError(
        "Missing required fields: athlete_id, engagement_type",
      );
    }

    // Create or find activation
    let activationId;
    const [existingActivation] = await sql`
      SELECT id FROM sponsor_activations 
      WHERE athlete_id = ${athlete_id} 
      AND campaign_id = ${campaign_id || null}
      AND activated_at > NOW() - INTERVAL '1 hour'
      LIMIT 1
    `;

    if (existingActivation) {
      activationId = existingActivation.id;
    } else {
      const [newActivation] = await sql`
        INSERT INTO sponsor_activations (
          campaign_id,
          athlete_id,
          activation_type,
          placement,
          activated_at
        ) VALUES (
          ${campaign_id || null},
          ${athlete_id},
          'fan_engagement',
          'web_dashboard',
          NOW()
        )
        RETURNING id
      `;
      activationId = newActivation.id;
    }

    // Record engagement
    const [engagement] = await sql`
      INSERT INTO sponsor_engagement (
        activation_id,
        campaign_id,
        engagement_type,
        engagement_value,
        metadata,
        recorded_at
      ) VALUES (
        ${activationId},
        ${campaign_id || null},
        ${engagement_type},
        ${engagement_value},
        ${JSON.stringify(metadata)},
        NOW()
      )
      RETURNING *
    `;

    return successResponse({
      engagement,
      message: "Engagement recorded successfully",
    });
  } catch (error) {
    console.error("Fan engagement recording error:", error);
    return internalError(error, "recording fan engagement");
  }
}
