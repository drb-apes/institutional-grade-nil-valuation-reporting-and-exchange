import sql from "@/app/api/utils/sql";

/**
 * POST /api/sponsor/seed-campaigns
 * Seed sample sponsor campaigns for demonstration
 */
export async function POST(request) {
  try {
    const campaigns = [];

    // Campaign 1: Nike Speed Index AR Overlay
    const nike = await sql`
      INSERT INTO sponsor_campaigns (
        sponsor_name, campaign_name, campaign_type, pricing_model,
        cpm_rate, target_impressions, target_engagement_rate,
        campaign_start, campaign_end,
        logo_url, activation_text, brand_colors, status
      )
      VALUES (
        'Nike',
        'Speed Index AR Overlay',
        'ar_overlay',
        'cpm',
        25.00,
        2000000,
        0.0500,
        '2026-01-01',
        '2026-12-31',
        '/sponsors/nike-logo.png',
        'Powered by Nike',
        '{"primary": "#000000", "secondary": "#FFFFFF"}'::jsonb,
        'active'
      )
      RETURNING *
    `;
    campaigns.push(nike[0]);

    // Create distribution channels for Nike
    await sql`
      INSERT INTO distribution_channels (
        campaign_id, channel_name, channel_type, revenue_model,
        weight_percentage, license_fee
      )
      VALUES
        (${nike[0].id}, 'ESPN', 'broadcaster', 'license_fee', 40.00, 400000),
        (${nike[0].id}, 'Apple TV+', 'ott_platform', 'revenue_share', 35.00, 350000),
        (${nike[0].id}, 'YouTube Sports', 'digital_channel', 'cpm', 25.00, 225000)
    `;

    // Campaign 2: Gatorade Recovery Challenge
    const gatorade = await sql`
      INSERT INTO sponsor_campaigns (
        sponsor_name, campaign_name, campaign_type, pricing_model,
        flat_fee_amount, target_impressions, target_engagement_rate,
        campaign_start, campaign_end,
        logo_url, activation_text, brand_colors, status
      )
      VALUES (
        'Gatorade',
        'Recovery Challenge',
        'in_game_challenge',
        'flat_fee',
        100000.00,
        1000000,
        0.0700,
        '2026-01-01',
        '2026-06-30',
        '/sponsors/gatorade-logo.png',
        'Fueled by Gatorade',
        '{"primary": "#FF6900", "secondary": "#FFFFFF"}'::jsonb,
        'active'
      )
      RETURNING *
    `;
    campaigns.push(gatorade[0]);

    // Create distribution channels for Gatorade
    await sql`
      INSERT INTO distribution_channels (
        campaign_id, channel_name, channel_type, revenue_model,
        weight_percentage, license_fee
      )
      VALUES
        (${gatorade[0].id}, 'NBC Sports', 'broadcaster', 'license_fee', 45.00, 450000),
        (${gatorade[0].id}, 'Peacock', 'ott_platform', 'revenue_share', 30.00, 300000),
        (${gatorade[0].id}, 'Instagram', 'digital_channel', 'cpm', 25.00, 250000)
    `;

    // Campaign 3: Under Armour Performance Poll
    const underArmour = await sql`
      INSERT INTO sponsor_campaigns (
        sponsor_name, campaign_name, campaign_type, pricing_model,
        cpm_rate, target_impressions, target_engagement_rate,
        campaign_start, campaign_end,
        logo_url, activation_text, brand_colors, status
      )
      VALUES (
        'Under Armour',
        'Performance Poll',
        'branded_poll',
        'cpm',
        18.00,
        500000,
        0.0800,
        '2026-02-01',
        '2026-08-31',
        '/sponsors/underarmour-logo.png',
        'Performance Powered by Under Armour',
        '{"primary": "#000000", "secondary": "#E61E26"}'::jsonb,
        'active'
      )
      RETURNING *
    `;
    campaigns.push(underArmour[0]);

    // Create distribution channels for Under Armour
    await sql`
      INSERT INTO distribution_channels (
        campaign_id, channel_name, channel_type, revenue_model,
        weight_percentage, license_fee
      )
      VALUES
        (${underArmour[0].id}, 'Fox Sports', 'broadcaster', 'license_fee', 40.00, 200000),
        (${underArmour[0].id}, 'Amazon Prime', 'ott_platform', 'revenue_share', 35.00, 175000),
        (${underArmour[0].id}, 'TikTok', 'digital_channel', 'cpm', 25.00, 125000)
    `;

    // Now create sample activations and impressions for Nike campaign
    // Get a few athletes to link
    const athletes = await sql`
      SELECT id FROM athletes LIMIT 3
    `;

    if (athletes.length > 0) {
      for (const athlete of athletes) {
        // Create activation
        const activation = await sql`
          INSERT INTO sponsor_activations (
            campaign_id, athlete_id, activation_type, placement, display_duration_ms
          )
          VALUES (
            ${nike[0].id}, ${athlete.id}, 'ar_overlay', 'jumbotron', 5000
          )
          RETURNING *
        `;

        // Create sample impressions
        const impressionCount = Math.floor(Math.random() * 50000) + 10000;
        const impressionBatch = [];

        for (let i = 0; i < Math.min(impressionCount, 100); i++) {
          impressionBatch.push(`(
            '${activation[0].id}',
            '${nike[0].id}',
            'viewer_${Math.random().toString(36).substring(7)}',
            '${i % 20 === 0 ? "click" : "view"}',
            ${Math.floor(Math.random() * 15000) + 1000},
            'stadium_display',
            NOW() - INTERVAL '${Math.floor(Math.random() * 30)} days'
          )`);
        }

        if (impressionBatch.length > 0) {
          await sql.unsafe(`
            INSERT INTO sponsor_impressions (
              activation_id, campaign_id, viewer_id, impression_type,
              dwell_time_ms, device_type, recorded_at
            )
            VALUES ${impressionBatch.join(",\n")}
          `);
        }

        // Create sample engagement events
        const engagementCount = Math.floor(impressionCount * 0.05);
        const engagementBatch = [];

        for (let i = 0; i < Math.min(engagementCount, 50); i++) {
          engagementBatch.push(`(
            '${activation[0].id}',
            '${nike[0].id}',
            '${i % 3 === 0 ? "conversion" : "click"}',
            ${i % 3 === 0 ? Math.floor(Math.random() * 500) + 50 : "NULL"},
            NOW() - INTERVAL '${Math.floor(Math.random() * 30)} days'
          )`);
        }

        if (engagementBatch.length > 0) {
          await sql.unsafe(`
            INSERT INTO sponsor_engagement (
              activation_id, campaign_id, engagement_type,
              engagement_value, recorded_at
            )
            VALUES ${engagementBatch.join(",\n")}
          `);
        }
      }
    }

    return Response.json({
      success: true,
      message: "Sample campaigns seeded successfully",
      campaigns: campaigns.map((c) => ({
        id: c.id,
        sponsor_name: c.sponsor_name,
        campaign_name: c.campaign_name,
        campaign_type: c.campaign_type,
      })),
      activations_created: athletes.length,
      impressions_seeded: "~100 per activation",
      engagement_events_seeded: "~50 per activation",
    });
  } catch (error) {
    console.error("Campaign seeding error:", error);
    return Response.json(
      { success: false, error: error.message, details: error.stack },
      { status: 500 },
    );
  }
}
