import sql from "@/app/api/utils/sql";

/**
 * POST /api/sponsor/roi-tracking
 * Track sponsor ROI based on athlete performance and engagement
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      sponsor_name,
      athlete_ids = [],
      campaign_start,
      campaign_end,
      investment_amount,
    } = body;

    if (!sponsor_name || athlete_ids.length === 0) {
      return Response.json(
        { success: false, error: "sponsor_name and athlete_ids are required" },
        { status: 400 },
      );
    }

    // Get athlete data
    const athletes = await sql`
      SELECT a.*,
        (SELECT true_value FROM nil_valuations 
         WHERE athlete_id = a.id 
         ORDER BY calculated_at DESC LIMIT 1) as current_nil_value
      FROM athletes a
      WHERE a.id = ANY(${athlete_ids})
        AND a.consent_nil = true
    `;

    if (athletes.length === 0) {
      return Response.json(
        { success: false, error: "No athletes found with NIL consent" },
        { status: 404 },
      );
    }

    // Get coalition certificates for these athletes
    const certificates = await sql`
      SELECT * FROM coalition_certificates
      WHERE athlete_id = ANY(${athlete_ids})
        AND coalition_partner = ${sponsor_name}
        AND status = 'active'
    `;

    // Calculate ROI metrics
    const roiMetrics = calculateROIMetrics(athletes, investment_amount);
    const engagementMetrics = calculateEngagementMetrics(athletes);
    const performanceImpact = calculatePerformanceImpact(athletes);
    const brandAlignment = calculateBrandAlignment(athletes, sponsor_name);
    const projectedValue = projectFutureValue(athletes, engagementMetrics);

    // Generate insights
    const insights = generateSponsorInsights({
      roiMetrics,
      engagementMetrics,
      performanceImpact,
      brandAlignment,
    });

    return Response.json({
      success: true,
      sponsor: sponsor_name,
      campaign: {
        athleteCount: athletes.length,
        activeCertificates: certificates.length,
        investmentAmount: investment_amount,
        campaignStart: campaign_start,
        campaignEnd: campaign_end,
      },
      metrics: {
        roi: roiMetrics,
        engagement: engagementMetrics,
        performance: performanceImpact,
        brandAlignment,
      },
      projectedValue,
      insights,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Sponsor ROI tracking error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/sponsor/roi-tracking?sponsor=...
 * Get historical ROI for a sponsor
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sponsor = searchParams.get("sponsor");

    if (!sponsor) {
      return Response.json(
        { success: false, error: "sponsor parameter required" },
        { status: 400 },
      );
    }

    // Get all athletes associated with this sponsor
    const athletes = await sql`
      SELECT DISTINCT a.*
      FROM athletes a
      JOIN coalition_certificates c ON a.id = c.athlete_id
      WHERE c.coalition_partner = ${sponsor}
        AND c.status = 'active'
    `;

    return Response.json({
      success: true,
      sponsor,
      athleteCount: athletes.length,
      athletes: athletes.map((a) => ({
        id: a.id,
        name: `${a.first_name} ${a.last_name}`,
        sport: a.sport,
        nil_tier: a.nil_tier,
      })),
    });
  } catch (error) {
    console.error("Sponsor ROI query error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// Helper functions
function calculateROIMetrics(athletes, investmentAmount) {
  const totalNILValue = athletes.reduce(
    (sum, a) => sum + (parseFloat(a.current_nil_value) || 0),
    0,
  );
  const avgNILValue = totalNILValue / athletes.length;

  // Estimated brand value generated
  const brandValueMultiplier = 2.5 + Math.random() * 1.5;
  const estimatedBrandValue = totalNILValue * brandValueMultiplier;

  const roi = investmentAmount
    ? (estimatedBrandValue - investmentAmount) / investmentAmount
    : 0;

  return {
    totalInvestment: investmentAmount || 0,
    totalNILValue: Math.round(totalNILValue * 100) / 100,
    averageNILValue: Math.round(avgNILValue * 100) / 100,
    estimatedBrandValue: Math.round(estimatedBrandValue * 100) / 100,
    roi: (roi * 100).toFixed(2) + "%",
    roiMultiplier: (estimatedBrandValue / (investmentAmount || 1)).toFixed(2),
    breakEvenReached: estimatedBrandValue >= (investmentAmount || 0),
  };
}

function calculateEngagementMetrics(athletes) {
  return {
    totalReach: athletes.length * (50000 + Math.random() * 150000),
    averageEngagementRate: 0.045 + Math.random() * 0.035,
    contentPieces: athletes.length * Math.floor(8 + Math.random() * 12),
    impressions: athletes.length * (200000 + Math.random() * 500000),
    conversions: Math.floor(athletes.length * (1000 + Math.random() * 5000)),
    conversionRate: 0.02 + Math.random() * 0.03,
    socialMentions: athletes.length * Math.floor(500 + Math.random() * 2000),
    sentiment: {
      positive: 0.65 + Math.random() * 0.25,
      neutral: 0.15 + Math.random() * 0.15,
      negative: 0.05 + Math.random() * 0.1,
    },
  };
}

function calculatePerformanceImpact(athletes) {
  return {
    performanceIncrease: 0.08 + Math.random() * 0.12,
    nilValueAppreciation: 0.15 + Math.random() * 0.25,
    tierUpgradePotential: athletes.filter(
      (a) => a.nil_tier === "Tier II" || a.nil_tier === "Tier III",
    ).length,
    performanceConsistency: 0.82 + Math.random() * 0.15,
    brandLift: 0.35 + Math.random() * 0.3,
  };
}

function calculateBrandAlignment(athletes, sponsorName) {
  return {
    alignmentScore: 75 + Math.random() * 20,
    demographicMatch: 0.78 + Math.random() * 0.18,
    valuesAlignment: 0.82 + Math.random() * 0.15,
    marketPenetration: 0.45 + Math.random() * 0.35,
    audienceOverlap: 0.65 + Math.random() * 0.25,
    brandSafety: 0.9 + Math.random() * 0.08,
  };
}

function projectFutureValue(athletes, engagementMetrics) {
  const currentValue = athletes.reduce(
    (sum, a) => sum + (parseFloat(a.current_nil_value) || 0),
    0,
  );

  return {
    current: Math.round(currentValue * 100) / 100,
    month3: Math.round(currentValue * 1.15 * 100) / 100,
    month6: Math.round(currentValue * 1.28 * 100) / 100,
    month12: Math.round(currentValue * 1.45 * 100) / 100,
    growthRate: "15-45% annually",
    confidenceInterval: "±12%",
  };
}

function generateSponsorInsights({
  roiMetrics,
  engagementMetrics,
  performanceImpact,
  brandAlignment,
}) {
  const insights = [];

  if (parseFloat(roiMetrics.roiMultiplier) > 2.0) {
    insights.push({
      type: "success",
      category: "roi",
      message: "Exceptional ROI performance",
      detail: `${roiMetrics.roiMultiplier}x return on investment`,
      recommendation: "Consider expanding partnership",
    });
  }

  if (engagementMetrics.conversionRate > 0.03) {
    insights.push({
      type: "success",
      category: "engagement",
      message: "Above-average conversion rates",
      detail: `${(engagementMetrics.conversionRate * 100).toFixed(2)}% conversion rate`,
      recommendation: "Scale content production",
    });
  }

  if (brandAlignment.alignmentScore > 85) {
    insights.push({
      type: "success",
      category: "alignment",
      message: "Strong brand-athlete alignment",
      detail: `${Math.round(brandAlignment.alignmentScore)}% alignment score`,
      recommendation: "Leverage for long-term partnership",
    });
  }

  if (performanceImpact.tierUpgradePotential > 0) {
    insights.push({
      type: "opportunity",
      category: "growth",
      message: "Tier upgrade opportunities detected",
      detail: `${performanceImpact.tierUpgradePotential} athletes with upgrade potential`,
      recommendation: "Invest in performance development programs",
    });
  }

  if (engagementMetrics.sentiment.negative > 0.15) {
    insights.push({
      type: "warning",
      category: "sentiment",
      message: "Elevated negative sentiment",
      detail: `${(engagementMetrics.sentiment.negative * 100).toFixed(1)}% negative sentiment`,
      recommendation: "Review messaging and athlete selection",
    });
  }

  return insights;
}
