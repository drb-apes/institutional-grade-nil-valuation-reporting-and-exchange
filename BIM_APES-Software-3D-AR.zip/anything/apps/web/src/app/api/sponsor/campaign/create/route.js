import sql from "@/app/api/utils/sql";

/**
 * POST /api/sponsor/campaign/create
 * Create a new sponsor campaign with distribution channels
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      sponsor_name,
      campaign_name,
      campaign_type,
      pricing_model,
      cpm_rate,
      flat_fee_amount,
      performance_bonus_rate,
      target_impressions,
      target_engagement_rate,
      campaign_start,
      campaign_end,
      logo_url,
      activation_text,
      brand_colors,
      distribution_channels = [],
    } = body;

    // Validation
    if (!sponsor_name || !campaign_name || !campaign_type || !pricing_model) {
      return Response.json(
        {
          success: false,
          error:
            "sponsor_name, campaign_name, campaign_type, and pricing_model are required",
        },
        { status: 400 },
      );
    }

    if (!campaign_start || !campaign_end) {
      return Response.json(
        {
          success: false,
          error: "campaign_start and campaign_end are required",
        },
        { status: 400 },
      );
    }

    // Create campaign
    const campaignResult = await sql`
      INSERT INTO sponsor_campaigns (
        sponsor_name, campaign_name, campaign_type, pricing_model,
        cpm_rate, flat_fee_amount, performance_bonus_rate,
        target_impressions, target_engagement_rate,
        campaign_start, campaign_end, logo_url, activation_text, brand_colors
      )
      VALUES (
        ${sponsor_name}, ${campaign_name}, ${campaign_type}, ${pricing_model},
        ${cpm_rate || null}, ${flat_fee_amount || null}, ${performance_bonus_rate || null},
        ${target_impressions || null}, ${target_engagement_rate || null},
        ${campaign_start}, ${campaign_end}, ${logo_url || null}, 
        ${activation_text || null}, ${brand_colors ? JSON.stringify(brand_colors) : null}
      )
      RETURNING *
    `;

    const campaign = campaignResult[0];

    // Create distribution channels if provided
    const createdChannels = [];
    if (distribution_channels.length > 0) {
      for (const channel of distribution_channels) {
        const channelResult = await sql`
          INSERT INTO distribution_channels (
            campaign_id, channel_name, channel_type, revenue_model,
            weight_percentage, license_fee, revenue_share_percentage,
            cpm_rate, estimated_impressions, allocated_revenue
          )
          VALUES (
            ${campaign.id}, ${channel.channel_name}, ${channel.channel_type},
            ${channel.revenue_model}, ${channel.weight_percentage},
            ${channel.license_fee || null}, ${channel.revenue_share_percentage || null},
            ${channel.cpm_rate || null}, ${channel.estimated_impressions || null},
            ${channel.allocated_revenue || null}
          )
          RETURNING *
        `;
        createdChannels.push(channelResult[0]);
      }
    }

    return Response.json({
      success: true,
      campaign: {
        ...campaign,
        brand_colors: campaign.brand_colors
          ? JSON.parse(campaign.brand_colors)
          : null,
      },
      distribution_channels: createdChannels,
      message: "Campaign created successfully",
    });
  } catch (error) {
    console.error("Campaign creation error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
