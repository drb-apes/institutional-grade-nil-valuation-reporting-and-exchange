import sql from "@/app/api/utils/sql";

/**
 * POST /api/sponsor/engagement/record
 * Record sponsor engagement events (impressions, clicks, conversions)
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      activation_id,
      campaign_id,
      engagement_type = "impression",
      impression_type,
      dwell_time_ms,
      device_type,
      location,
      viewer_id,
      engagement_value,
      metadata,
    } = body;

    if (!activation_id || !campaign_id) {
      return Response.json(
        { success: false, error: "activation_id and campaign_id are required" },
        { status: 400 },
      );
    }

    // Record impression
    if (engagement_type === "impression") {
      const impressionResult = await sql`
        INSERT INTO sponsor_impressions (
          activation_id, campaign_id, viewer_id, impression_type,
          dwell_time_ms, device_type, location
        )
        VALUES (
          ${activation_id}, ${campaign_id}, ${viewer_id || null},
          ${impression_type || "view"}, ${dwell_time_ms || null},
          ${device_type || null}, ${location ? JSON.stringify(location) : null}
        )
        RETURNING *
      `;

      return Response.json({
        success: true,
        impression: impressionResult[0],
        message: "Impression recorded successfully",
      });
    }

    // Record engagement (click, conversion, etc.)
    const engagementResult = await sql`
      INSERT INTO sponsor_engagement (
        activation_id, campaign_id, engagement_type,
        engagement_value, metadata
      )
      VALUES (
        ${activation_id}, ${campaign_id}, ${engagement_type},
        ${engagement_value || null}, ${metadata ? JSON.stringify(metadata) : null}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      engagement: engagementResult[0],
      message: "Engagement recorded successfully",
    });
  } catch (error) {
    console.error("Engagement recording error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/sponsor/engagement/record?campaign_id=...
 * Get engagement metrics for a campaign
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const campaign_id = searchParams.get("campaign_id");

    if (!campaign_id) {
      return Response.json(
        { success: false, error: "campaign_id parameter required" },
        { status: 400 },
      );
    }

    // Get impression metrics
    const impressionMetrics = await sql`
      SELECT 
        COUNT(*) as total_impressions,
        COUNT(DISTINCT viewer_id) as unique_viewers,
        AVG(dwell_time_ms) as avg_dwell_time_ms,
        COUNT(CASE WHEN impression_type = 'click' THEN 1 END) as total_clicks
      FROM sponsor_impressions
      WHERE campaign_id = ${campaign_id}
    `;

    // Get engagement metrics
    const engagementMetrics = await sql`
      SELECT 
        engagement_type,
        COUNT(*) as count,
        SUM(engagement_value) as total_value
      FROM sponsor_engagement
      WHERE campaign_id = ${campaign_id}
      GROUP BY engagement_type
    `;

    const metrics = impressionMetrics[0];
    const clickThroughRate =
      metrics.total_impressions > 0
        ? (metrics.total_clicks / metrics.total_impressions) * 100
        : 0;

    return Response.json({
      success: true,
      campaign_id,
      impressions: {
        total: parseInt(metrics.total_impressions) || 0,
        unique_viewers: parseInt(metrics.unique_viewers) || 0,
        avg_dwell_time_ms: parseFloat(metrics.avg_dwell_time_ms) || 0,
        total_clicks: parseInt(metrics.total_clicks) || 0,
        click_through_rate: clickThroughRate.toFixed(2) + "%",
      },
      engagement: engagementMetrics.map((e) => ({
        type: e.engagement_type,
        count: parseInt(e.count),
        total_value: parseFloat(e.total_value) || 0,
      })),
    });
  } catch (error) {
    console.error("Engagement retrieval error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
