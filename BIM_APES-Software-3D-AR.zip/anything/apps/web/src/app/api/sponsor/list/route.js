import sql from "@/app/api/utils/sql";

/**
 * GET /api/sponsor/list
 * List all sponsor campaigns with summary metrics
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "active";
    const sponsor_name = searchParams.get("sponsor");

    // Build query
    let query = sql`
      SELECT * FROM sponsor_campaigns
      WHERE status = ${status}
    `;

    if (sponsor_name) {
      query = sql`
        SELECT * FROM sponsor_campaigns
        WHERE status = ${status}
          AND LOWER(sponsor_name) LIKE LOWER(${"%" + sponsor_name + "%"})
      `;
    }

    const campaigns = await query;

    // Get metrics for each campaign
    const campaignsWithMetrics = await Promise.all(
      campaigns.map(async (campaign) => {
        // Get impression count
        const impressions = await sql`
          SELECT COUNT(*) as count FROM sponsor_impressions
          WHERE campaign_id = ${campaign.id}
        `;

        // Get engagement count
        const engagement = await sql`
          SELECT COUNT(*) as count FROM sponsor_engagement
          WHERE campaign_id = ${campaign.id}
        `;

        // Get activation count
        const activations = await sql`
          SELECT COUNT(*) as count FROM sponsor_activations
          WHERE campaign_id = ${campaign.id}
        `;

        const impressionCount = parseInt(impressions[0].count) || 0;
        const engagementCount = parseInt(engagement[0].count) || 0;
        const activationCount = parseInt(activations[0].count) || 0;

        const engagementRate =
          impressionCount > 0
            ? ((engagementCount / impressionCount) * 100).toFixed(2)
            : "0.00";

        return {
          ...campaign,
          brand_colors: campaign.brand_colors
            ? JSON.parse(campaign.brand_colors)
            : null,
          metrics: {
            impressions: impressionCount,
            engagement: engagementCount,
            activations: activationCount,
            engagement_rate: parseFloat(engagementRate),
          },
        };
      }),
    );

    return Response.json({
      success: true,
      campaigns: campaignsWithMetrics,
      count: campaignsWithMetrics.length,
    });
  } catch (error) {
    console.error("Campaign list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
