import sql from "@/app/api/utils/sql";

/**
 * POST /api/sponsor/distribution/allocate
 * Calculate and allocate revenue across distribution channels
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      campaign_id,
      period_start,
      period_end,
      allocation_period = "monthly",
    } = body;

    if (!campaign_id || !period_start || !period_end) {
      return Response.json(
        {
          success: false,
          error: "campaign_id, period_start, and period_end are required",
        },
        { status: 400 },
      );
    }

    // Get campaign details
    const campaignResult = await sql`
      SELECT * FROM sponsor_campaigns WHERE id = ${campaign_id}
    `;

    if (campaignResult.length === 0) {
      return Response.json(
        { success: false, error: "Campaign not found" },
        { status: 404 },
      );
    }

    const campaign = campaignResult[0];

    // Get distribution channels
    const channels = await sql`
      SELECT * FROM distribution_channels
      WHERE campaign_id = ${campaign_id}
      ORDER BY weight_percentage DESC
    `;

    if (channels.length === 0) {
      return Response.json(
        {
          success: false,
          error: "No distribution channels found for campaign",
        },
        { status: 404 },
      );
    }

    // Get metrics for period
    const impressionMetrics = await sql`
      SELECT COUNT(*) as total_impressions
      FROM sponsor_impressions
      WHERE campaign_id = ${campaign_id}
        AND recorded_at >= ${period_start}
        AND recorded_at <= ${period_end}
    `;

    const engagementMetrics = await sql`
      SELECT COUNT(*) as total_engagement
      FROM sponsor_engagement
      WHERE campaign_id = ${campaign_id}
        AND recorded_at >= ${period_start}
        AND recorded_at <= ${period_end}
    `;

    const totalImpressions =
      parseInt(impressionMetrics[0].total_impressions) || 0;
    const totalEngagement =
      parseInt(engagementMetrics[0].total_engagement) || 0;

    // Calculate total campaign revenue
    let totalRevenue = 0;
    if (campaign.pricing_model === "cpm" && campaign.cpm_rate) {
      totalRevenue = (totalImpressions / 1000) * campaign.cpm_rate;
    } else if (
      campaign.pricing_model === "flat_fee" &&
      campaign.flat_fee_amount
    ) {
      totalRevenue = campaign.flat_fee_amount;
    }

    // Calculate performance bonus if applicable
    let performanceBonus = 0;
    if (campaign.performance_bonus_rate && campaign.target_engagement_rate) {
      const actualEngagementRate =
        totalImpressions > 0 ? totalEngagement / totalImpressions : 0;

      if (actualEngagementRate > campaign.target_engagement_rate) {
        performanceBonus = totalRevenue * campaign.performance_bonus_rate;
        totalRevenue += performanceBonus;
      }
    }

    // Allocate revenue to channels based on weights
    const allocations = [];
    for (const channel of channels) {
      const weightDecimal = channel.weight_percentage / 100;
      const allocatedAmount = totalRevenue * weightDecimal;

      // Create allocation record
      const allocationResult = await sql`
        INSERT INTO revenue_allocations (
          campaign_id, channel_id, allocation_period,
          total_impressions, total_engagement, allocated_amount,
          period_start, period_end
        )
        VALUES (
          ${campaign_id}, ${channel.id}, ${allocation_period},
          ${totalImpressions}, ${totalEngagement}, ${allocatedAmount},
          ${period_start}, ${period_end}
        )
        RETURNING *
      `;

      allocations.push({
        channel_name: channel.channel_name,
        channel_type: channel.channel_type,
        weight_percentage: channel.weight_percentage,
        allocated_amount: allocatedAmount,
        allocation_record: allocationResult[0],
      });
    }

    return Response.json({
      success: true,
      campaign: {
        id: campaign.id,
        name: campaign.campaign_name,
        sponsor: campaign.sponsor_name,
      },
      period: {
        start: period_start,
        end: period_end,
        allocation_period,
      },
      metrics: {
        total_impressions: totalImpressions,
        total_engagement: totalEngagement,
        engagement_rate:
          totalImpressions > 0
            ? ((totalEngagement / totalImpressions) * 100).toFixed(2) + "%"
            : "0%",
      },
      revenue: {
        total_revenue: parseFloat(totalRevenue.toFixed(2)),
        performance_bonus: parseFloat(performanceBonus.toFixed(2)),
        base_revenue: parseFloat((totalRevenue - performanceBonus).toFixed(2)),
      },
      allocations: allocations.map((a) => ({
        channel_name: a.channel_name,
        channel_type: a.channel_type,
        weight_percentage: a.weight_percentage,
        allocated_amount: parseFloat(a.allocated_amount.toFixed(2)),
      })),
      message: "Revenue allocated successfully",
    });
  } catch (error) {
    console.error("Revenue allocation error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/sponsor/distribution/allocate?campaign_id=...
 * Get historical allocations for a campaign
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const campaign_id = searchParams.get("campaign_id");

    if (!campaign_id) {
      return Response.json(
        { success: false, error: "campaign_id parameter required" },
        { status: 400 },
      );
    }

    const allocations = await sql`
      SELECT ra.*, dc.channel_name, dc.channel_type, dc.weight_percentage
      FROM revenue_allocations ra
      JOIN distribution_channels dc ON ra.channel_id = dc.id
      WHERE ra.campaign_id = ${campaign_id}
      ORDER BY ra.calculated_at DESC
      LIMIT 50
    `;

    return Response.json({
      success: true,
      campaign_id,
      allocations: allocations.map((a) => ({
        id: a.id,
        channel_name: a.channel_name,
        channel_type: a.channel_type,
        weight_percentage: a.weight_percentage,
        allocation_period: a.allocation_period,
        total_impressions: a.total_impressions,
        total_engagement: a.total_engagement,
        allocated_amount: parseFloat(a.allocated_amount),
        period_start: a.period_start,
        period_end: a.period_end,
        calculated_at: a.calculated_at,
      })),
      count: allocations.length,
    });
  } catch (error) {
    console.error("Allocation retrieval error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
