import sql from "@/app/api/utils/sql";

/**
 * POST /api/sponsor/activation/track
 * Track a sponsor overlay activation (when overlay is shown)
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      campaign_id,
      athlete_id,
      activation_type,
      placement,
      display_duration_ms,
    } = body;

    if (!campaign_id || !activation_type) {
      return Response.json(
        {
          success: false,
          error: "campaign_id and activation_type are required",
        },
        { status: 400 },
      );
    }

    // Verify campaign exists and is active
    const campaignCheck = await sql`
      SELECT id, status FROM sponsor_campaigns
      WHERE id = ${campaign_id}
    `;

    if (campaignCheck.length === 0) {
      return Response.json(
        { success: false, error: "Campaign not found" },
        { status: 404 },
      );
    }

    if (campaignCheck[0].status !== "active") {
      return Response.json(
        { success: false, error: "Campaign is not active" },
        { status: 400 },
      );
    }

    // Create activation record
    const activationResult = await sql`
      INSERT INTO sponsor_activations (
        campaign_id, athlete_id, activation_type, placement, display_duration_ms
      )
      VALUES (
        ${campaign_id}, ${athlete_id || null}, ${activation_type},
        ${placement || null}, ${display_duration_ms || null}
      )
      RETURNING *
    `;

    const activation = activationResult[0];

    return Response.json({
      success: true,
      activation,
      message: "Activation tracked successfully",
    });
  } catch (error) {
    console.error("Activation tracking error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/sponsor/activation/track?campaign_id=...
 * Get activations for a campaign
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const campaign_id = searchParams.get("campaign_id");

    if (!campaign_id) {
      return Response.json(
        { success: false, error: "campaign_id parameter required" },
        { status: 400 },
      );
    }

    const activations = await sql`
      SELECT sa.*, 
        a.first_name, a.last_name, a.sport
      FROM sponsor_activations sa
      LEFT JOIN athletes a ON sa.athlete_id = a.id
      WHERE sa.campaign_id = ${campaign_id}
      ORDER BY sa.activated_at DESC
      LIMIT 100
    `;

    return Response.json({
      success: true,
      campaign_id,
      activations: activations.map((act) => ({
        ...act,
        athlete_name: act.first_name
          ? `${act.first_name} ${act.last_name}`
          : null,
      })),
      count: activations.length,
    });
  } catch (error) {
    console.error("Activation retrieval error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
