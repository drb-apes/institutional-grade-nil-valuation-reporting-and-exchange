import sql from "@/app/api/utils/sql";

/**
 * GET /api/sponsor/campaign/[id]
 * Get campaign details with full analytics
 */
export async function GET(request, { params }) {
  try {
    const { id } = params;

    // Get campaign
    const campaignResult = await sql`
      SELECT * FROM sponsor_campaigns WHERE id = ${id}
    `;

    if (campaignResult.length === 0) {
      return Response.json(
        { success: false, error: "Campaign not found" },
        { status: 404 },
      );
    }

    const campaign = campaignResult[0];

    // Get distribution channels
    const channels = await sql`
      SELECT * FROM distribution_channels
      WHERE campaign_id = ${id}
      ORDER BY weight_percentage DESC
    `;

    // Get total activations
    const activationCount = await sql`
      SELECT COUNT(*) as count FROM sponsor_activations
      WHERE campaign_id = ${id}
    `;

    // Get impression metrics
    const impressionMetrics = await sql`
      SELECT 
        COUNT(*) as total_impressions,
        COUNT(DISTINCT viewer_id) as unique_viewers,
        AVG(dwell_time_ms) as avg_dwell_time_ms,
        COUNT(CASE WHEN impression_type = 'click' THEN 1 END) as total_clicks
      FROM sponsor_impressions
      WHERE campaign_id = ${id}
    `;

    // Get engagement metrics
    const engagementMetrics = await sql`
      SELECT 
        engagement_type,
        COUNT(*) as count,
        SUM(engagement_value) as total_value
      FROM sponsor_engagement
      WHERE campaign_id = ${id}
      GROUP BY engagement_type
    `;

    // Calculate ROI
    const impressions = impressionMetrics[0];
    const totalImpressions = parseInt(impressions.total_impressions) || 0;
    const totalClicks = parseInt(impressions.total_clicks) || 0;
    const engagementRate =
      totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;

    let totalRevenue = 0;
    let activationCost = 0;

    if (campaign.pricing_model === "cpm" && campaign.cpm_rate) {
      activationCost = (totalImpressions / 1000) * campaign.cpm_rate;
      totalRevenue = activationCost;
    } else if (
      campaign.pricing_model === "flat_fee" &&
      campaign.flat_fee_amount
    ) {
      activationCost = campaign.flat_fee_amount;
      totalRevenue = activationCost;
    }

    // Calculate total engagement value
    const totalEngagementValue = engagementMetrics.reduce(
      (sum, e) => sum + (parseFloat(e.total_value) || 0),
      0,
    );

    // Calculate ROI using the formula from the spec
    // ROI = (Incremental Sales + Media Value + Brand Lift - Activation Cost) / Activation Cost
    const incrementalSales = totalEngagementValue;
    const mediaValue = totalImpressions * 0.05; // $0.05 per impression media value
    const brandLift = totalRevenue * 0.3; // 30% brand lift estimate
    const roi =
      activationCost > 0
        ? ((incrementalSales + mediaValue + brandLift - activationCost) /
            activationCost) *
          100
        : 0;

    return Response.json({
      success: true,
      campaign: {
        ...campaign,
        brand_colors: campaign.brand_colors
          ? JSON.parse(campaign.brand_colors)
          : null,
      },
      distribution_channels: channels,
      metrics: {
        activations: parseInt(activationCount[0].count) || 0,
        impressions: {
          total: totalImpressions,
          unique_viewers: parseInt(impressions.unique_viewers) || 0,
          avg_dwell_time_ms: parseFloat(impressions.avg_dwell_time_ms) || 0,
          total_clicks: totalClicks,
        },
        engagement: {
          rate: parseFloat(engagementRate.toFixed(2)),
          by_type: engagementMetrics.map((e) => ({
            type: e.engagement_type,
            count: parseInt(e.count),
            total_value: parseFloat(e.total_value) || 0,
          })),
        },
        roi: {
          activation_cost: parseFloat(activationCost.toFixed(2)),
          incremental_sales: parseFloat(incrementalSales.toFixed(2)),
          media_value: parseFloat(mediaValue.toFixed(2)),
          brand_lift: parseFloat(brandLift.toFixed(2)),
          total_revenue: parseFloat(totalRevenue.toFixed(2)),
          roi_percentage: parseFloat(roi.toFixed(2)),
        },
      },
    });
  } catch (error) {
    console.error("Campaign retrieval error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * PATCH /api/sponsor/campaign/[id]
 * Update campaign details
 */
export async function PATCH(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    const {
      status,
      target_impressions,
      target_engagement_rate,
      logo_url,
      activation_text,
      brand_colors,
    } = body;

    // Build update query dynamically
    const updates = [];
    const values = [];

    if (status !== undefined) {
      updates.push(`status = $${updates.length + 1}`);
      values.push(status);
    }
    if (target_impressions !== undefined) {
      updates.push(`target_impressions = $${updates.length + 1}`);
      values.push(target_impressions);
    }
    if (target_engagement_rate !== undefined) {
      updates.push(`target_engagement_rate = $${updates.length + 1}`);
      values.push(target_engagement_rate);
    }
    if (logo_url !== undefined) {
      updates.push(`logo_url = $${updates.length + 1}`);
      values.push(logo_url);
    }
    if (activation_text !== undefined) {
      updates.push(`activation_text = $${updates.length + 1}`);
      values.push(activation_text);
    }
    if (brand_colors !== undefined) {
      updates.push(`brand_colors = $${updates.length + 1}`);
      values.push(JSON.stringify(brand_colors));
    }

    if (updates.length === 0) {
      return Response.json(
        { success: false, error: "No fields to update" },
        { status: 400 },
      );
    }

    updates.push(`updated_at = NOW()`);
    values.push(id);

    const query = `
      UPDATE sponsor_campaigns 
      SET ${updates.join(", ")}
      WHERE id = $${values.length}
      RETURNING *
    `;

    const result = await sql(query, values);

    if (result.length === 0) {
      return Response.json(
        { success: false, error: "Campaign not found" },
        { status: 404 },
      );
    }

    return Response.json({
      success: true,
      campaign: {
        ...result[0],
        brand_colors: result[0].brand_colors
          ? JSON.parse(result[0].brand_colors)
          : null,
      },
      message: "Campaign updated successfully",
    });
  } catch (error) {
    console.error("Campaign update error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
