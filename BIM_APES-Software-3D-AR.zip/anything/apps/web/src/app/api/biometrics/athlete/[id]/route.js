import sql from "@/app/api/utils/sql";
import {
  notFoundError,
  validationError,
  internalError,
  successResponse,
} from "@/app/api/utils/errorHandler";

/**
 * Get biometric data for a specific athlete
 * Supports filtering by index type and time range
 * GET /api/biometrics/athlete/[id]?days=7&index=RHRi
 */

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const { searchParams } = new URL(request.url);
    const days = parseInt(searchParams.get("days") || "7");
    const indexCode = searchParams.get("index");

    // Verify athlete exists
    const [athlete] =
      await sql`SELECT id, first_name, last_name FROM athletes WHERE id = ${id}`;
    if (!athlete) {
      return notFoundError("Athlete", id);
    }

    // Get biometric readings
    const readings = await sql`
      SELECT 
        br.id,
        br.index_code,
        bid.index_name,
        bid.cluster,
        bid.domain,
        bid.description,
        bid.unit,
        br.score,
        br.baseline,
        br.trend,
        br.context,
        br.recorded_at
      FROM biometric_readings br
      LEFT JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${id}
        AND br.recorded_at > NOW() - INTERVAL '${days} days'
        ${indexCode ? sql`AND br.index_code = ${indexCode}` : sql``}
      ORDER BY br.recorded_at DESC
      LIMIT 1000
    `;

    // Group by index code for summary
    const summary = {};
    readings.forEach((r) => {
      if (!summary[r.index_code]) {
        summary[r.index_code] = {
          index_code: r.index_code,
          index_name: r.index_name,
          cluster: r.cluster,
          domain: r.domain,
          latest_score: r.score,
          latest_trend: r.trend,
          latest_recorded: r.recorded_at,
          count: 0,
          avg_score: 0,
          scores: [],
        };
      }
      summary[r.index_code].count++;
      summary[r.index_code].scores.push(parseFloat(r.score));
    });

    // Calculate averages
    Object.keys(summary).forEach((code) => {
      const scores = summary[code].scores;
      summary[code].avg_score =
        scores.reduce((a, b) => a + b, 0) / scores.length;
      delete summary[code].scores; // Remove raw array for cleaner response
    });

    return successResponse({
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
      },
      time_range: {
        days,
        from: new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString(),
        to: new Date().toISOString(),
      },
      readings: readings.map((r) => ({
        ...r,
        score: parseFloat(r.score),
        baseline: r.baseline ? parseFloat(r.baseline) : null,
      })),
      summary: Object.values(summary),
    });
  } catch (error) {
    console.error("Biometric data error:", error);
    return internalError(error, "fetching biometric data");
  }
}

/**
 * Record new biometric readings for an athlete
 * POST /api/biometrics/athlete/[id]
 */
export async function POST(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const { readings } = body;

    if (!readings || !Array.isArray(readings) || readings.length === 0) {
      return validationError("Missing or invalid readings array");
    }

    // Verify athlete exists
    const [athlete] = await sql`SELECT id FROM athletes WHERE id = ${id}`;
    if (!athlete) {
      return notFoundError("Athlete", id);
    }

    // Insert readings
    const inserted = [];
    for (const reading of readings) {
      const { index_code, score, baseline, trend, context, session_id } =
        reading;

      if (!index_code || score === undefined) {
        continue; // Skip invalid readings
      }

      const [result] = await sql`
        INSERT INTO biometric_readings (
          athlete_id,
          index_code,
          score,
          baseline,
          trend,
          context,
          session_id,
          recorded_at
        ) VALUES (
          ${id},
          ${index_code},
          ${score},
          ${baseline || null},
          ${trend || null},
          ${context || "api_upload"},
          ${session_id || null},
          NOW()
        )
        RETURNING *
      `;

      inserted.push(result);
    }

    return successResponse({
      message: `Successfully recorded ${inserted.length} biometric readings`,
      readings: inserted,
      count: inserted.length,
    });
  } catch (error) {
    console.error("Biometric recording error:", error);
    return internalError(error, "recording biometric data");
  }
}
