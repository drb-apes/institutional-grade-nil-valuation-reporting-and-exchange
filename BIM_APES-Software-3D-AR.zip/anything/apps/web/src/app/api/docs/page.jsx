"use client";

import {
  Database,
  Users,
  TrendingUp,
  Heart,
  DollarSign,
  BarChart3,
  Zap,
} from "lucide-react";

export default function APIDocsPage() {
  const endpoints = [
    {
      category: "Athletes",
      icon: Users,
      color: "#C8A882",
      endpoints: [
        {
          method: "GET",
          path: "/api/athletes",
          description: "List all athletes with filtering",
          params:
            "?sport=Basketball&team=Lincoln&nil_tier=Tier I&limit=50&offset=0",
        },
        {
          method: "POST",
          path: "/api/athletes",
          description: "Create new athlete",
          body: {
            first_name: "John",
            last_name: "Doe",
            sport: "Basketball",
            position: "Guard",
            team: "Lincoln Academy",
          },
        },
        {
          method: "GET",
          path: "/api/athletes/[id]",
          description: "Get athlete details with NIL, biometrics, sessions",
          example: "/api/athletes/123e4567-e89b-12d3-a456-426614174000",
        },
        {
          method: "PATCH",
          path: "/api/athletes/[id]",
          description: "Update athlete",
          body: {
            nil_tier: "Tier II",
            consent_biometric: true,
          },
        },
        {
          method: "DELETE",
          path: "/api/athletes/[id]",
          description: "Soft delete athlete (sets status to Inactive)",
        },
      ],
    },
    {
      category: "Biometrics",
      icon: Heart,
      color: "#D4B896",
      endpoints: [
        {
          method: "GET",
          path: "/api/biometrics/athlete/[id]",
          description: "Get biometric readings for athlete",
          params: "?days=7&index=RHRi",
        },
        {
          method: "POST",
          path: "/api/biometrics/athlete/[id]",
          description: "Record biometric readings",
          body: {
            readings: [
              {
                index_code: "RHRi",
                score: 72.5,
                baseline: 68.0,
                trend: "stable",
              },
              {
                index_code: "HRVi",
                score: 85.2,
                baseline: 80.0,
                trend: "improving",
              },
            ],
          },
        },
      ],
    },
    {
      category: "NIL Valuation",
      icon: TrendingUp,
      color: "#C8A882",
      endpoints: [
        {
          method: "GET",
          path: "/api/nil/athlete/[id]",
          description: "Get NIL valuation history & age progression",
          params: "?days=30",
        },
        {
          method: "POST",
          path: "/api/nil/athlete/[id]",
          description: "Calculate new NIL valuation",
          body: {
            market_value: 125.5,
            performance_metrics: {},
            social_metrics: { engagement_rate: 8.5 },
          },
        },
      ],
    },
    {
      category: "Fan Engagement",
      icon: Zap,
      color: "#E8DCC8",
      endpoints: [
        {
          method: "GET",
          path: "/api/fan-engagement/metrics",
          description: "Get boost credits & tipping flow data",
          params: "?athleteId=xxx&days=30&limit=10",
        },
        {
          method: "POST",
          path: "/api/fan-engagement/metrics",
          description: "Record fan engagement (boost, replay, vote)",
          body: {
            athlete_id: "uuid",
            engagement_type: "boost",
            engagement_value: 1,
            metadata: {},
          },
        },
      ],
    },
    {
      category: "Payments",
      icon: DollarSign,
      color: "#C8A882",
      endpoints: [
        {
          method: "POST",
          path: "/api/stripe/create-checkout",
          description: "Create Stripe checkout session for licensing",
          body: {
            tier: "district",
            billingPeriod: "monthly",
            organizationName: "Lincoln School District",
            contactEmail: "admin@lincoln.edu",
            studentCount: 2500,
          },
        },
      ],
    },
    {
      category: "Dashboard",
      icon: BarChart3,
      color: "#D4B896",
      endpoints: [
        {
          method: "GET",
          path: "/api/dashboard/summary",
          description: "Get dashboard metrics (athletes, events, alerts, NIL)",
        },
      ],
    },
    {
      category: "Demo & Testing",
      icon: Database,
      color: "#C8A882",
      endpoints: [
        {
          method: "POST",
          path: "/api/demo/seed-data",
          description: "Seed demo data (athletes, biometrics, NIL)",
          body: {
            count: 10,
            sport: "Basketball",
          },
        },
        {
          method: "DELETE",
          path: "/api/demo/seed-data",
          description: "Clear all demo data",
        },
      ],
    },
  ];

  const pricingTiers = [
    {
      tier: "school",
      name: "School License",
      monthly: 299,
      annual: 2990,
      students: 500,
    },
    {
      tier: "district",
      name: "District License",
      monthly: 999,
      annual: 9990,
      students: 5000,
      popular: true,
    },
    {
      tier: "regional",
      name: "Regional License",
      monthly: 2499,
      annual: 24990,
      students: 25000,
    },
    {
      tier: "statewide",
      name: "Statewide License",
      monthly: 4999,
      annual: 49990,
      students: "Unlimited",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1B3A57] via-[#152E45] to-[#1B3A57]">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-lg border-b border-[#C8A882]/30">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold text-white mb-3">
            BIM-APES API Documentation
          </h1>
          <p className="text-[#D4B896] text-lg">
            Complete reference for all functional endpoints
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-[#C8A882] text-3xl font-bold mb-2">20+</div>
            <div className="text-white">Functional Endpoints</div>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-[#D4B896] text-3xl font-bold mb-2">5</div>
            <div className="text-white">BiomechFlow Charts</div>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-[#E8DCC8] text-3xl font-bold mb-2">4</div>
            <div className="text-white">Licensing Tiers</div>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="text-[#C8A882] text-3xl font-bold mb-2">Live</div>
            <div className="text-white">Stripe Integration</div>
          </div>
        </div>

        {/* API Endpoints */}
        {endpoints.map((category, idx) => (
          <div key={idx} className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${category.color}40` }}
              >
                <category.icon size={24} style={{ color: category.color }} />
              </div>
              <h2 className="text-2xl font-bold text-white">
                {category.category}
              </h2>
            </div>

            <div className="space-y-3">
              {category.endpoints.map((endpoint, eidx) => (
                <div
                  key={eidx}
                  className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
                >
                  <div className="flex items-start gap-4">
                    <div
                      className={`px-3 py-1 rounded-lg text-xs font-bold ${
                        endpoint.method === "GET"
                          ? "bg-green-500/20 text-green-400"
                          : endpoint.method === "POST"
                            ? "bg-blue-500/20 text-blue-400"
                            : endpoint.method === "PATCH"
                              ? "bg-yellow-500/20 text-yellow-400"
                              : "bg-red-500/20 text-red-400"
                      }`}
                    >
                      {endpoint.method}
                    </div>
                    <div className="flex-1">
                      <div className="text-white font-mono text-sm mb-2">
                        {endpoint.path}
                        {endpoint.params && (
                          <span className="text-[#D4B896]">
                            {endpoint.params}
                          </span>
                        )}
                        {endpoint.example && (
                          <div className="text-[#C8A882] mt-1 text-xs">
                            Example: {endpoint.example}
                          </div>
                        )}
                      </div>
                      <div className="text-[#D4B896] text-sm mb-3">
                        {endpoint.description}
                      </div>
                      {endpoint.body && (
                        <details className="mt-2">
                          <summary className="text-[#C8A882] text-xs cursor-pointer hover:text-[#D4B896]">
                            View Request Body
                          </summary>
                          <pre className="mt-2 p-3 bg-black/30 rounded-lg text-xs text-[#D4B896] overflow-x-auto">
                            {JSON.stringify(endpoint.body, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Pricing Tiers */}
        <div className="mt-12 mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">
            Licensing Tiers
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pricingTiers.map((tier, idx) => (
              <div
                key={idx}
                className={`bg-white/10 backdrop-blur-lg rounded-xl p-6 border ${
                  tier.popular ? "border-[#C8A882]" : "border-white/20"
                } relative`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#C8A882] text-[#1B3A57] rounded-full text-xs font-bold">
                    MOST POPULAR
                  </div>
                )}
                <div className="text-white font-bold mb-4">{tier.name}</div>
                <div className="text-3xl font-bold text-[#C8A882] mb-1">
                  ${tier.monthly}
                  <span className="text-sm text-[#D4B896]">/mo</span>
                </div>
                <div className="text-sm text-[#D4B896] mb-4">
                  ${tier.annual}/yr (save 2 months)
                </div>
                <div className="text-white text-sm">
                  Up to <span className="font-bold">{tier.students}</span>{" "}
                  students
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Demo Links */}
        <div className="bg-gradient-to-br from-[#C8A882]/20 to-[#C8A882]/5 rounded-xl p-8 border border-[#C8A882]/30">
          <h2 className="text-2xl font-bold text-white mb-4">Live Demos</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a
              href="/demo/biomech-capsules"
              className="block bg-white/10 backdrop-blur-lg rounded-lg p-4 border border-white/20 hover:border-[#C8A882] transition-all group"
            >
              <div className="text-white font-semibold group-hover:text-[#C8A882] transition-colors">
                BiomechFlow Capsules
              </div>
              <div className="text-[#D4B896] text-sm mt-1">
                Interactive charts & visualizations
              </div>
            </a>
            <a
              href="/demo/launch-dashboard"
              className="block bg-white/10 backdrop-blur-lg rounded-lg p-4 border border-white/20 hover:border-[#C8A882] transition-all group"
            >
              <div className="text-white font-semibold group-hover:text-[#C8A882] transition-colors">
                90-Day Launch Dashboard
              </div>
              <div className="text-[#D4B896] text-sm mt-1">
                Licensing & payment flow
              </div>
            </a>
            <a
              href="/demo/model-nil-bank"
              className="block bg-white/10 backdrop-blur-lg rounded-lg p-4 border border-white/20 hover:border-[#C8A882] transition-all group"
            >
              <div className="text-white font-semibold group-hover:text-[#C8A882] transition-colors">
                Model NIL Bank
              </div>
              <div className="text-[#D4B896] text-sm mt-1">
                Youth NIL literacy demo
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
