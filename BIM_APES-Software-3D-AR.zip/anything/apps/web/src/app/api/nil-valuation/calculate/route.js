import sql from "@/app/api/utils/sql";

// Calculate NIL valuation for an athlete
// This is the core BIM-APES valuation engine
export async function POST(request) {
  try {
    const body = await request.json();
    const { athlete_id } = body;

    if (!athlete_id) {
      return Response.json(
        { error: "athlete_id is required" },
        { status: 400 },
      );
    }

    // Get athlete data
    const athletes = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athletes.length === 0) {
      return Response.json({ error: "Athlete not found" }, { status: 404 });
    }

    const athlete = athletes[0];

    // Get recent biometric readings
    const biometrics = await sql`
      SELECT br.*, bid.domain, bid.cluster
      FROM biometric_readings br
      JOIN biometric_index_definitions bid ON br.index_code = bid.index_code
      WHERE br.athlete_id = ${athlete_id}
      AND br.recorded_at > NOW() - INTERVAL '7 days'
      ORDER BY br.recorded_at DESC
      LIMIT 100
    `;

    // Get recent performance sessions
    const sessions = await sql`
      SELECT * FROM performance_sessions
      WHERE athlete_id = ${athlete_id}
      AND started_at > NOW() - INTERVAL '30 days'
      ORDER BY started_at DESC
      LIMIT 20
    `;

    // BIM-APES ML Valuation Algorithm
    // This is a simplified version - production would use AWS SageMaker

    // Base value by tier
    const tierValues = {
      "Tier I": 100000,
      "Tier II": 50000,
      "Tier III": 25000,
    };

    let baseValue = tierValues[athlete.nil_tier] || 25000;

    // Performance multiplier (from recent sessions)
    let performanceMultiplier = 1.0;
    if (sessions.length > 0) {
      const avgPerformance =
        sessions.reduce((sum, s) => sum + (s.performance_score || 0), 0) /
        sessions.length;
      performanceMultiplier = 0.8 + (avgPerformance / 100) * 0.4; // 0.8 to 1.2 range
    }

    // Biometric health multiplier
    let biometricMultiplier = 1.0;
    if (biometrics.length > 0) {
      // Calculate average trend (improving = positive, declining = negative)
      const trendScores = biometrics.map((b) => {
        if (b.trend === "improving") return 1;
        if (b.trend === "declining") return -1;
        return 0;
      });
      const avgTrend =
        trendScores.reduce((sum, t) => sum + t, 0) / trendScores.length;
      biometricMultiplier = 1.0 + avgTrend * 0.15; // ±15% based on biometric trends
    }

    // Calculate True Value (TV) - model-based fair value
    const trueValue = baseValue * performanceMultiplier * biometricMultiplier;

    // Market Value (MV) - simulate market pricing with some noise
    const marketNoise = 0.85 + Math.random() * 0.3; // 0.85 to 1.15
    const marketValue = trueValue * marketNoise;

    // Calculate gap and direction
    const gap = trueValue - marketValue;
    const gapPercentage = (gap / marketValue) * 100;
    const direction = gap > 0 ? "long" : "short";

    // Confidence based on data quality
    const dataQuality =
      Math.min(biometrics.length / 50, 1.0) *
      Math.min(sessions.length / 10, 1.0);
    const confidence = 0.6 + dataQuality * 0.35; // 0.6 to 0.95

    // Convexity Factor (upside asymmetry)
    const convexityFactor =
      athlete.nil_tier === "Tier I"
        ? 0.75
        : athlete.nil_tier === "Tier II"
          ? 0.55
          : 0.35;

    // Momentum Intensity
    const recentTrends = biometrics.slice(0, 10);
    const improvingCount = recentTrends.filter(
      (b) => b.trend === "improving",
    ).length;
    const momentumIntensity = improvingCount / Math.max(recentTrends.length, 1);

    // Expected close time (seconds) - based on gap size
    const expectedCloseSeconds =
      Math.abs(gapPercentage) < 5
        ? 300
        : // 5 minutes
          Math.abs(gapPercentage) < 10
          ? 900
          : // 15 minutes
            Math.abs(gapPercentage) < 20
            ? 1800
            : // 30 minutes
              3600; // 1 hour

    // Insert valuation into database
    const valuation = await sql`
      INSERT INTO nil_valuations (
        athlete_id,
        true_value,
        market_value,
        gap,
        gap_percentage,
        direction,
        confidence,
        convexity_factor,
        momentum_intensity,
        expected_close_seconds,
        valuation_method
      ) VALUES (
        ${athlete_id},
        ${trueValue.toFixed(2)},
        ${marketValue.toFixed(2)},
        ${gap.toFixed(2)},
        ${gapPercentage.toFixed(2)},
        ${direction},
        ${confidence.toFixed(3)},
        ${convexityFactor.toFixed(3)},
        ${momentumIntensity.toFixed(3)},
        ${expectedCloseSeconds},
        'BIM-APES ML v1.0'
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      valuation: valuation[0],
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        sport: athlete.sport,
        nil_tier: athlete.nil_tier,
      },
      data_quality: {
        biometric_readings: biometrics.length,
        performance_sessions: sessions.length,
        confidence: confidence.toFixed(3),
      },
    });
  } catch (error) {
    console.error("Error calculating NIL valuation:", error);
    return Response.json(
      { error: "Failed to calculate NIL valuation", details: error.message },
      { status: 500 },
    );
  }
}
