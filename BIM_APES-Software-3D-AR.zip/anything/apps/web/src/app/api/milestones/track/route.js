import sql from "@/app/api/utils/sql";

/**
 * POST /api/milestones/track
 * Track and manage athlete performance milestones
 * Automatically triggers payouts when milestones are achieved
 */
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      athlete_id,
      milestone_type, // 'performance', 'nil_value', 'engagement', 'biometric'
      description,
      target_value,
      payout_amount,
    } = body;

    if (!athlete_id || !milestone_type || !target_value) {
      return Response.json(
        {
          success: false,
          error: "athlete_id, milestone_type, and target_value are required",
        },
        { status: 400 },
      );
    }

    // Verify athlete exists
    const athleteRows = await sql`
      SELECT * FROM athletes WHERE id = ${athlete_id}
    `;

    if (athleteRows.length === 0) {
      return Response.json(
        { success: false, error: "Athlete not found" },
        { status: 404 },
      );
    }

    const athlete = athleteRows[0];

    // Get current progress toward milestone
    const currentValue = await getCurrentMilestoneValue(
      athlete_id,
      milestone_type,
    );

    // Check if milestone is already achieved
    const isAchieved = currentValue >= parseFloat(target_value);

    // Create or update milestone
    const milestoneRows = await sql`
      INSERT INTO nil_milestones (
        athlete_id,
        milestone_type,
        description,
        target_value,
        current_value,
        payout_amount,
        status,
        achieved_at
      ) VALUES (
        ${athlete_id},
        ${milestone_type},
        ${description || `${milestone_type} milestone`},
        ${target_value},
        ${currentValue},
        ${payout_amount || null},
        ${isAchieved ? "achieved" : "pending"},
        ${isAchieved ? new Date() : null}
      )
      RETURNING *
    `;

    const milestone = milestoneRows[0];

    // Audit log
    await sql`
      INSERT INTO audit_logs (
        entity_type,
        entity_id,
        action,
        actor,
        details
      ) VALUES (
        'nil_milestone',
        ${milestone.id},
        'create',
        'BIM-APES System',
        ${JSON.stringify({
          athlete_id,
          milestone_type,
          target_value,
          isAchieved,
        })}
      )
    `;

    return Response.json({
      success: true,
      milestone,
      athlete: {
        id: athlete.id,
        name: `${athlete.first_name} ${athlete.last_name}`,
        sport: athlete.sport,
      },
      progress: {
        current: currentValue,
        target: parseFloat(target_value),
        percentage: Math.min(
          100,
          (currentValue / parseFloat(target_value)) * 100,
        ).toFixed(1),
        isAchieved,
      },
    });
  } catch (error) {
    console.error("Milestone tracking error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * GET /api/milestones/track?athlete_id=...&status=...
 * List milestones for an athlete
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const athlete_id = searchParams.get("athlete_id");
    const status = searchParams.get("status"); // pending, achieved, paid

    if (!athlete_id) {
      return Response.json(
        { success: false, error: "athlete_id is required" },
        { status: 400 },
      );
    }

    let query;
    if (status) {
      query = sql`
        SELECT m.*, a.first_name, a.last_name, a.sport
        FROM nil_milestones m
        JOIN athletes a ON m.athlete_id = a.id
        WHERE m.athlete_id = ${athlete_id}
          AND m.status = ${status}
        ORDER BY m.created_at DESC
      `;
    } else {
      query = sql`
        SELECT m.*, a.first_name, a.last_name, a.sport
        FROM nil_milestones m
        JOIN athletes a ON m.athlete_id = a.id
        WHERE m.athlete_id = ${athlete_id}
        ORDER BY m.created_at DESC
      `;
    }

    const milestones = await query;

    // Calculate summary stats
    const summary = {
      total: milestones.length,
      achieved: milestones.filter(
        (m) => m.status === "achieved" || m.status === "paid",
      ).length,
      pending: milestones.filter((m) => m.status === "pending").length,
      totalPayout: milestones
        .filter((m) => m.status === "paid")
        .reduce((sum, m) => sum + (parseFloat(m.payout_amount) || 0), 0),
    };

    return Response.json({
      success: true,
      athlete_id,
      summary,
      milestones,
    });
  } catch (error) {
    console.error("Milestone list error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

/**
 * PATCH /api/milestones/track
 * Update milestone status or trigger payout
 */
export async function PATCH(request) {
  try {
    const body = await request.json();
    const { milestone_id, action } = body; // action: 'check_progress', 'mark_paid'

    if (!milestone_id || !action) {
      return Response.json(
        { success: false, error: "milestone_id and action are required" },
        { status: 400 },
      );
    }

    // Get milestone
    const milestoneRows = await sql`
      SELECT m.*, a.first_name, a.last_name
      FROM nil_milestones m
      JOIN athletes a ON m.athlete_id = a.id
      WHERE m.id = ${milestone_id}
    `;

    if (milestoneRows.length === 0) {
      return Response.json(
        { success: false, error: "Milestone not found" },
        { status: 404 },
      );
    }

    const milestone = milestoneRows[0];

    if (action === "check_progress") {
      // Re-check current progress
      const currentValue = await getCurrentMilestoneValue(
        milestone.athlete_id,
        milestone.milestone_type,
      );
      const isAchieved = currentValue >= parseFloat(milestone.target_value);

      if (isAchieved && milestone.status === "pending") {
        // Mark as achieved
        const updatedRows = await sql`
          UPDATE nil_milestones
          SET
            current_value = ${currentValue},
            status = 'achieved',
            achieved_at = NOW()
          WHERE id = ${milestone_id}
          RETURNING *
        `;

        return Response.json({
          success: true,
          message: "Milestone achieved!",
          milestone: updatedRows[0],
        });
      } else {
        // Update current progress
        await sql`
          UPDATE nil_milestones
          SET current_value = ${currentValue}
          WHERE id = ${milestone_id}
        `;

        return Response.json({
          success: true,
          message: "Progress updated",
          current: currentValue,
          target: parseFloat(milestone.target_value),
          remaining: parseFloat(milestone.target_value) - currentValue,
        });
      }
    } else if (action === "mark_paid") {
      if (milestone.status !== "achieved") {
        return Response.json(
          {
            success: false,
            error: "Milestone must be achieved before marking as paid",
          },
          { status: 400 },
        );
      }

      const updatedRows = await sql`
        UPDATE nil_milestones
        SET
          status = 'paid',
          paid_at = NOW()
        WHERE id = ${milestone_id}
        RETURNING *
      `;

      // Audit log
      await sql`
        INSERT INTO audit_logs (
          entity_type,
          entity_id,
          action,
          actor,
          details
        ) VALUES (
          'nil_milestone',
          ${milestone_id},
          'payment',
          'BIM-APES System',
          ${JSON.stringify({
            payout_amount: milestone.payout_amount,
            paid_at: new Date(),
          })}
        )
      `;

      return Response.json({
        success: true,
        message: "Payout processed",
        milestone: updatedRows[0],
      });
    }

    return Response.json(
      { success: false, error: "Invalid action" },
      { status: 400 },
    );
  } catch (error) {
    console.error("Milestone update error:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}

// Helper function
async function getCurrentMilestoneValue(athlete_id, milestone_type) {
  switch (milestone_type) {
    case "nil_value": {
      const rows = await sql`
        SELECT true_value FROM nil_valuations
        WHERE athlete_id = ${athlete_id}
        ORDER BY calculated_at DESC
        LIMIT 1
      `;
      return rows.length > 0 ? parseFloat(rows[0].true_value) : 0;
    }

    case "performance": {
      const rows = await sql`
        SELECT AVG(performance_score) as avg_score
        FROM performance_sessions
        WHERE athlete_id = ${athlete_id}
          AND started_at > NOW() - INTERVAL '30 days'
      `;
      return rows.length > 0 ? parseFloat(rows[0].avg_score) || 0 : 0;
    }

    case "biometric": {
      const rows = await sql`
        SELECT AVG(score) as avg_score
        FROM biometric_readings
        WHERE athlete_id = ${athlete_id}
          AND recorded_at > NOW() - INTERVAL '7 days'
      `;
      return rows.length > 0 ? parseFloat(rows[0].avg_score) || 0 : 0;
    }

    case "engagement": {
      // Simulated engagement metric
      return 5000 + Math.random() * 15000;
    }

    default:
      return 0;
  }
}
