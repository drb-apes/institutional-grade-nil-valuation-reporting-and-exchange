import sql from "@/app/api/utils/sql";

/**
 * Dashboard Summary Endpoint
 * Returns aggregated metrics for console dashboard
 */

export async function GET(request) {
  try {
    // Get active athletes count
    const [athletesResult] = await sql`
      SELECT COUNT(*) as count FROM athletes WHERE coalition_status = 'Active'
    `;
    const activeAthletes = parseInt(athletesResult.count);

    // Get critical alerts count (using biometric readings as proxy)
    const [alertsResult] = await sql`
      SELECT COUNT(*) as count FROM biometric_readings 
      WHERE recorded_at > NOW() - INTERVAL '24 hours'
      AND (score < 30 OR score > 90)
    `;
    const criticalAlerts = parseInt(alertsResult.count);

    // Get NIL volume from recent valuations
    const [nilResult] = await sql`
      SELECT COALESCE(SUM(market_value), 0) as total 
      FROM nil_valuations 
      WHERE calculated_at > NOW() - INTERVAL '24 hours'
    `;
    const nilVolume24h = parseFloat(nilResult.total);

    // Get active mispricing events count (proxy for live events)
    const [eventsResult] = await sql`
      SELECT COUNT(*) as count FROM mispricing_events WHERE status = 'active'
    `;
    const liveEvents = parseInt(eventsResult.count);

    // Get recent live events
    const recentEvents = await sql`
      SELECT 
        me.id,
        a.first_name || ' ' || a.last_name as athlete_name,
        a.sport,
        me.event_type as status,
        me.detected_at as time,
        a.team as venue
      FROM mispricing_events me
      JOIN athletes a ON a.id = me.athlete_id
      WHERE me.status = 'active'
      ORDER BY me.detected_at DESC
      LIMIT 5
    `;

    // Get top risk alerts
    const topAlerts = await sql`
      SELECT 
        br.id,
        a.first_name || ' ' || a.last_name as athlete,
        a.team,
        br.index_code as type,
        CASE 
          WHEN br.score < 30 THEN 'high'
          WHEN br.score < 50 THEN 'medium'
          ELSE 'low'
        END as severity,
        br.score as value,
        br.recorded_at as timestamp
      FROM biometric_readings br
      JOIN athletes a ON a.id = br.athlete_id
      WHERE br.recorded_at > NOW() - INTERVAL '24 hours'
      AND (br.score < 50 OR br.score > 90)
      ORDER BY br.recorded_at DESC
      LIMIT 10
    `;

    // Get NIL momentum leaders
    const nilLeaders = await sql`
      SELECT 
        nv.athlete_id as id,
        a.first_name || ' ' || a.last_name as name,
        nv.market_value as value,
        nv.gap as change,
        nv.direction as trend
      FROM nil_valuations nv
      JOIN athletes a ON a.id = nv.athlete_id
      WHERE nv.calculated_at > NOW() - INTERVAL '24 hours'
      ORDER BY ABS(nv.gap) DESC
      LIMIT 5
    `;

    // Get sponsor activation windows
    const sponsorWindows = await sql`
      SELECT 
        cc.coalition_partner as brand,
        a.first_name || ' ' || a.last_name as athlete,
        EXTRACT(EPOCH FROM (cc.expires_at - NOW())) / 3600 as window,
        ROUND(RANDOM() * 100, 1) as roi
      FROM coalition_certificates cc
      JOIN athletes a ON a.id = cc.athlete_id
      WHERE cc.status = 'active' 
      AND cc.expires_at > NOW()
      ORDER BY cc.expires_at ASC
      LIMIT 5
    `;

    return Response.json({
      success: true,
      data: {
        metrics: {
          activeAthletes,
          liveEvents,
          criticalAlerts,
          nilVolume24h: Math.round(nilVolume24h),
        },
        liveEvents: recentEvents.map((e) => ({
          id: e.id,
          name: `${e.athlete_name} - ${e.sport}`,
          status: e.status,
          time: e.time,
          venue: e.venue,
        })),
        topAlerts: topAlerts.map((a) => ({
          id: a.id,
          athlete: a.athlete,
          team: a.team,
          type: a.type,
          severity: a.severity,
          value: a.value,
          timestamp: a.timestamp,
        })),
        nilLeaders: nilLeaders.map((l) => ({
          id: l.id,
          name: l.name,
          value: Math.round(l.value),
          change: l.change,
          trend: l.trend,
        })),
        sponsorWindows: sponsorWindows.map((w) => ({
          brand: w.brand,
          athlete: w.athlete,
          window: Math.round(w.window),
          roi: w.roi,
        })),
      },
    });
  } catch (error) {
    console.error("Dashboard summary error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
