import sql from "@/app/api/utils/sql";

/**
 * Athlete Metrics Endpoint
 * Returns aggregated real-time metrics for athlete list/detail views
 */

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const athleteId = searchParams.get("athlete_id");
  const limit = parseInt(searchParams.get("limit") || "50");
  const offset = parseInt(searchParams.get("offset") || "0");

  try {
    let query;
    let params = [];

    if (athleteId) {
      // Single athlete metrics
      query = sql`
        SELECT 
          a.id,
          a.first_name,
          a.last_name,
          a.team,
          a.sport,
          a.position,
          a.nil_tier,
          a.coalition_status as status,
          
          -- Latest biometrics
          (SELECT score FROM biometric_readings 
           WHERE athlete_id = a.id AND index_code = 'FAi' 
           ORDER BY recorded_at DESC LIMIT 1) as fatigue,
          
          (SELECT score FROM biometric_readings 
           WHERE athlete_id = a.id AND index_code = 'RRi' 
           ORDER BY recorded_at DESC LIMIT 1) as recovery,
          
          (SELECT score FROM biometric_readings 
           WHERE athlete_id = a.id AND index_code = 'HRVi' 
           ORDER BY recorded_at DESC LIMIT 1) as hrv,
          
          -- Latest NIL valuation
          (SELECT market_value FROM nil_valuations 
           WHERE athlete_id = a.id 
           ORDER BY calculated_at DESC LIMIT 1) as nil_value,
          
          (SELECT gap FROM nil_valuations 
           WHERE athlete_id = a.id 
           ORDER BY calculated_at DESC LIMIT 1) as nil_momentum,
          
          -- Risk level
          CASE 
            WHEN EXISTS (
              SELECT 1 FROM biometric_readings 
              WHERE athlete_id = a.id 
              AND recorded_at > NOW() - INTERVAL '24 hours'
              AND score < 30
            ) THEN 'high'
            WHEN EXISTS (
              SELECT 1 FROM biometric_readings 
              WHERE athlete_id = a.id 
              AND recorded_at > NOW() - INTERVAL '24 hours'
              AND score < 50
            ) THEN 'medium'
            ELSE 'low'
          END as risk_level,
          
          -- Last update
          (SELECT MAX(recorded_at) FROM biometric_readings 
           WHERE athlete_id = a.id) as last_updated
          
        FROM athletes a
        WHERE a.id = ${athleteId}
      `;

      const [result] = await query;

      if (!result) {
        return Response.json(
          {
            success: false,
            error: "Athlete not found",
          },
          { status: 404 },
        );
      }

      return Response.json({
        success: true,
        athlete: result,
      });
    } else {
      // Multiple athletes metrics
      query = sql`
        SELECT 
          a.id,
          a.first_name,
          a.last_name,
          a.team,
          a.sport,
          a.coalition_status as status,
          
          -- Latest fatigue
          (SELECT score FROM biometric_readings 
           WHERE athlete_id = a.id AND index_code = 'FAi' 
           ORDER BY recorded_at DESC LIMIT 1) as fatigue,
          
          -- Latest recovery
          (SELECT score FROM biometric_readings 
           WHERE athlete_id = a.id AND index_code = 'RRi' 
           ORDER BY recorded_at DESC LIMIT 1) as recovery,
          
          -- Latest NIL momentum
          (SELECT gap FROM nil_valuations 
           WHERE athlete_id = a.id 
           ORDER BY calculated_at DESC LIMIT 1) as nil_momentum,
          
          -- Risk level
          CASE 
            WHEN EXISTS (
              SELECT 1 FROM biometric_readings 
              WHERE athlete_id = a.id 
              AND recorded_at > NOW() - INTERVAL '24 hours'
              AND score < 30
            ) THEN 'high'
            WHEN EXISTS (
              SELECT 1 FROM biometric_readings 
              WHERE athlete_id = a.id 
              AND recorded_at > NOW() - INTERVAL '24 hours'
              AND score < 50
            ) THEN 'medium'
            ELSE 'low'
          END as risk_level,
          
          (SELECT MAX(recorded_at) FROM biometric_readings 
           WHERE athlete_id = a.id) as last_updated
          
        FROM athletes a
        WHERE a.coalition_status = 'Active'
        ORDER BY a.last_name, a.first_name
        LIMIT ${limit}
        OFFSET ${offset}
      `;

      const athletes = await query;

      const [countResult] = await sql`
        SELECT COUNT(*) as count FROM athletes WHERE coalition_status = 'Active'
      `;

      return Response.json({
        success: true,
        athletes: athletes.map((a) => ({
          id: a.id,
          name: `${a.first_name} ${a.last_name}`,
          team: a.team,
          sport: a.sport,
          status: a.status,
          fatigue: a.fatigue ? Math.round(a.fatigue) : null,
          recovery: a.recovery ? Math.round(a.recovery) : null,
          nilMomentum: a.nil_momentum
            ? `${a.nil_momentum > 0 ? "+" : ""}${Math.round(a.nil_momentum)}%`
            : "N/A",
          riskLevel: a.risk_level,
          lastUpdated: a.last_updated,
        })),
        total: parseInt(countResult.count),
        limit,
        offset,
      });
    }
  } catch (error) {
    console.error("Athlete metrics error:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
