import sql from "@/app/api/utils/sql";
import {
  notFoundError,
  validationError,
  internalError,
  successResponse,
} from "@/app/api/utils/errorHandler";

// Get single athlete by ID with comprehensive data
export async function GET(request, { params }) {
  try {
    const { id } = params;

    const [athlete] = await sql`
      SELECT 
        a.*,
        (
          SELECT json_build_object(
            'current_value', nv.market_value,
            'true_value', nv.true_value,
            'gap', nv.gap,
            'gap_percentage', nv.gap_percentage,
            'direction', nv.direction,
            'confidence', nv.confidence,
            'calculated_at', nv.calculated_at
          )
          FROM nil_valuations nv
          WHERE nv.athlete_id = a.id
          ORDER BY nv.calculated_at DESC
          LIMIT 1
        ) as nil_data,
        (
          SELECT json_agg(
            json_build_object(
              'index_code', br.index_code,
              'score', br.score,
              'baseline', br.baseline,
              'trend', br.trend,
              'recorded_at', br.recorded_at
            )
          )
          FROM (
            SELECT DISTINCT ON (br.index_code) 
              br.index_code,
              br.score,
              br.baseline,
              br.trend,
              br.recorded_at
            FROM biometric_readings br
            WHERE br.athlete_id = a.id
            AND br.recorded_at > NOW() - INTERVAL '7 days'
            ORDER BY br.index_code, br.recorded_at DESC
          ) br
        ) as recent_biometrics,
        (
          SELECT json_agg(
            json_build_object(
              'session_id', ps.id,
              'session_type', ps.session_type,
              'sport', ps.sport,
              'duration_minutes', ps.duration_minutes,
              'performance_score', ps.performance_score,
              'started_at', ps.started_at
            )
          )
          FROM (
            SELECT *
            FROM performance_sessions ps
            WHERE ps.athlete_id = a.id
            ORDER BY ps.started_at DESC
            LIMIT 10
          ) ps
        ) as recent_sessions,
        (
          SELECT COUNT(*)
          FROM coalition_certificates cc
          WHERE cc.athlete_id = a.id
          AND cc.status = 'active'
        ) as active_certificates_count
      FROM athletes a
      WHERE a.id = ${id}
    `;

    if (!athlete) {
      return notFoundError("Athlete", id);
    }

    return successResponse({
      athlete: {
        ...athlete,
        nil_data: athlete.nil_data || null,
        recent_biometrics: athlete.recent_biometrics || [],
        recent_sessions: athlete.recent_sessions || [],
        active_certificates_count: parseInt(athlete.active_certificates_count),
      },
    });
  } catch (error) {
    console.error("Error fetching athlete:", error);
    return internalError(error, "fetching athlete details");
  }
}

// Update athlete
export async function PATCH(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    // Check if athlete exists
    const [existing] = await sql`SELECT id FROM athletes WHERE id = ${id}`;
    if (!existing) {
      return notFoundError("Athlete", id);
    }

    const updateFields = [];
    const values = [];
    let paramIndex = 1;

    // Build dynamic update query
    const allowedFields = [
      "first_name",
      "last_name",
      "sport",
      "position",
      "team",
      "federation",
      "date_of_birth",
      "height_cm",
      "weight_kg",
      "nil_tier",
      "coalition_status",
      "consent_biometric",
      "consent_nil",
      "consent_trading",
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateFields.push(`${field} = $${paramIndex}`);
        values.push(body[field]);
        paramIndex++;
      }
    }

    if (updateFields.length === 0) {
      return validationError("No valid fields to update");
    }

    // Add updated_at
    updateFields.push(`updated_at = NOW()`);

    // Add id for WHERE clause
    values.push(id);

    const query = `
      UPDATE athletes 
      SET ${updateFields.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `;

    const result = await sql(query, values);

    if (result.length === 0) {
      return notFoundError("Athlete", id);
    }

    return successResponse({
      athlete: result[0],
      message: "Athlete updated successfully",
    });
  } catch (error) {
    console.error("Error updating athlete:", error);
    return internalError(error, "updating athlete");
  }
}

// Soft delete athlete
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    // Check if athlete exists
    const [existing] = await sql`SELECT id FROM athletes WHERE id = ${id}`;
    if (!existing) {
      return notFoundError("Athlete", id);
    }

    // Soft delete by updating coalition_status
    await sql`
      UPDATE athletes
      SET 
        coalition_status = 'Inactive',
        updated_at = NOW()
      WHERE id = ${id}
    `;

    return successResponse({
      message: "Athlete deactivated successfully",
      athlete_id: id,
    });
  } catch (error) {
    console.error("Athlete delete error:", error);
    return internalError(error, "deleting athlete");
  }
}
