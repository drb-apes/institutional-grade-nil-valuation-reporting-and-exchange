import sql from "@/app/api/utils/sql";
import {
  validationError,
  internalError,
  successResponse,
} from "@/app/api/utils/errorHandler";

/**
 * Athletes API - Full CRUD operations
 * GET /api/athletes - List all athletes with filtering
 * POST /api/athletes - Create new athlete
 */

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get("sport");
    const team = searchParams.get("team");
    const tier = searchParams.get("nil_tier");
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    let query = sql`
      SELECT 
        a.id,
        a.first_name,
        a.last_name,
        a.sport,
        a.position,
        a.team,
        a.federation,
        a.date_of_birth,
        a.height_cm,
        a.weight_kg,
        a.nil_tier,
        a.coalition_status,
        a.created_at,
        (
          SELECT market_value 
          FROM nil_valuations nv 
          WHERE nv.athlete_id = a.id 
          ORDER BY nv.calculated_at DESC 
          LIMIT 1
        ) as current_nil_value,
        (
          SELECT COUNT(*) 
          FROM biometric_readings br 
          WHERE br.athlete_id = a.id 
          AND br.recorded_at > NOW() - INTERVAL '7 days'
        ) as recent_readings_count
      FROM athletes a
      WHERE 1=1
    `;

    const conditions = [];
    const params = [];

    if (sport) {
      conditions.push(sql`AND a.sport = ${sport}`);
    }

    if (team) {
      conditions.push(sql`AND a.team = ${team}`);
    }

    if (tier) {
      conditions.push(sql`AND a.nil_tier = ${tier}`);
    }

    // Combine query with conditions
    const athletes = await sql`
      SELECT 
        a.id,
        a.first_name,
        a.last_name,
        a.sport,
        a.position,
        a.team,
        a.federation,
        a.date_of_birth,
        a.height_cm,
        a.weight_kg,
        a.nil_tier,
        a.coalition_status,
        a.created_at,
        (
          SELECT market_value 
          FROM nil_valuations nv 
          WHERE nv.athlete_id = a.id 
          ORDER BY nv.calculated_at DESC 
          LIMIT 1
        ) as current_nil_value,
        (
          SELECT COUNT(*) 
          FROM biometric_readings br 
          WHERE br.athlete_id = a.id 
          AND br.recorded_at > NOW() - INTERVAL '7 days'
        ) as recent_readings_count
      FROM athletes a
      WHERE 1=1
        ${sport ? sql`AND a.sport = ${sport}` : sql``}
        ${team ? sql`AND a.team = ${team}` : sql``}
        ${tier ? sql`AND a.nil_tier = ${tier}` : sql``}
      ORDER BY a.created_at DESC
      LIMIT ${limit}
      OFFSET ${offset}
    `;

    // Get total count
    const [countResult] = await sql`
      SELECT COUNT(*) as total 
      FROM athletes a
      WHERE 1=1
        ${sport ? sql`AND a.sport = ${sport}` : sql``}
        ${team ? sql`AND a.team = ${team}` : sql``}
        ${tier ? sql`AND a.nil_tier = ${tier}` : sql``}
    `;

    return successResponse({
      athletes: athletes.map((a) => ({
        ...a,
        current_nil_value: a.current_nil_value
          ? parseFloat(a.current_nil_value)
          : 0,
        recent_readings_count: parseInt(a.recent_readings_count),
      })),
      pagination: {
        total: parseInt(countResult.total),
        limit,
        offset,
        hasMore: offset + limit < parseInt(countResult.total),
      },
    });
  } catch (error) {
    console.error("Athletes list error:", error);
    return internalError(error, "fetching athletes");
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      first_name,
      last_name,
      sport,
      position,
      team,
      federation,
      date_of_birth,
      height_cm,
      weight_kg,
      nil_tier = "Tier III",
      coalition_status = "Active",
    } = body;

    // Validate required fields
    if (!first_name || !last_name || !sport) {
      return validationError(
        "Missing required fields: first_name, last_name, sport",
      );
    }

    // Insert new athlete
    const [newAthlete] = await sql`
      INSERT INTO athletes (
        first_name,
        last_name,
        sport,
        position,
        team,
        federation,
        date_of_birth,
        height_cm,
        weight_kg,
        nil_tier,
        coalition_status,
        consent_biometric,
        consent_nil,
        consent_trading
      ) VALUES (
        ${first_name},
        ${last_name},
        ${sport},
        ${position || null},
        ${team || null},
        ${federation || null},
        ${date_of_birth || null},
        ${height_cm || null},
        ${weight_kg || null},
        ${nil_tier},
        ${coalition_status},
        false,
        false,
        false
      )
      RETURNING *
    `;

    return successResponse(
      {
        athlete: newAthlete,
        message: "Athlete created successfully",
      },
      "Athlete created successfully",
    );
  } catch (error) {
    console.error("Athlete creation error:", error);
    return internalError(error, "creating athlete");
  }
}
