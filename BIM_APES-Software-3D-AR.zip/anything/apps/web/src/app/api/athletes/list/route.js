import sql from "@/app/api/utils/sql";

// List all athletes with optional filtering
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sport = searchParams.get("sport");
    const team = searchParams.get("team");
    const nil_tier = searchParams.get("nil_tier");
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    let query = "SELECT * FROM athletes WHERE 1=1";
    const params = [];
    let paramIndex = 1;

    if (sport) {
      query += ` AND sport = $${paramIndex}`;
      params.push(sport);
      paramIndex++;
    }

    if (team) {
      query += ` AND team = $${paramIndex}`;
      params.push(team);
      paramIndex++;
    }

    if (nil_tier) {
      query += ` AND nil_tier = $${paramIndex}`;
      params.push(nil_tier);
      paramIndex++;
    }

    query += ` ORDER BY created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const athletes = await sql(query, params);

    return Response.json({
      success: true,
      athletes,
      count: athletes.length,
      limit,
      offset,
    });
  } catch (error) {
    console.error("Error listing athletes:", error);
    return Response.json(
      { error: "Failed to list athletes", details: error.message },
      { status: 500 },
    );
  }
}
