"use client";

import { useState, useEffect } from "react";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Brain,
  Zap,
  Shield,
  Target,
  ArrowRight,
  RefreshCw,
} from "lucide-react";
import ARBiomechOverlay from "@/components/ARBiomechOverlay";
import BiomechFlowChart from "@/components/BiomechFlowChart";
import RiskForecastPanel from "@/components/RiskForecastPanel";
import LoadingScreen from "@/components/shared/LoadingScreen";
import ErrorScreen from "@/components/shared/ErrorScreen";
import DashboardHeader from "@/components/shared/DashboardHeader";

export default function IntelligenceDashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedAthleteId, setSelectedAthleteId] = useState("dashawn_001");
  const [athleteName, setAthleteName] = useState("Dashawn Bledsoe");

  // Intelligence state
  const [stressIntel, setStressIntel] = useState(null);
  const [fatigueIntel, setFatigueIntel] = useState(null);
  const [recoveryIntel, setRecoveryIntel] = useState(null);
  const [trainingIntel, setTrainingIntel] = useState(null);
  const [marketIntel, setMarketIntel] = useState(null);

  // Alerts aggregation
  const [allAlerts, setAllAlerts] = useState([]);

  useEffect(() => {
    loadIntelligence();
  }, [selectedAthleteId]);

  const loadIntelligence = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch all intelligence engines in parallel
      const [stressRes, fatigueRes, recoveryRes, trainingRes, marketRes] =
        await Promise.all([
          fetch("/api/intelligence/stress", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ athlete_id: selectedAthleteId }),
          }),
          fetch("/api/intelligence/fatigue", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ athlete_id: selectedAthleteId }),
          }),
          fetch("/api/intelligence/recovery", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ athlete_id: selectedAthleteId }),
          }),
          fetch("/api/intelligence/training", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ athlete_id: selectedAthleteId }),
          }),
          fetch("/api/intelligence/market", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ athlete_id: selectedAthleteId }),
          }),
        ]);

      const [stress, fatigue, recovery, training, market] = await Promise.all([
        stressRes.json(),
        fatigueRes.json(),
        recoveryRes.json(),
        trainingRes.json(),
        marketRes.json(),
      ]);

      setStressIntel(stress.stressIntelligence);
      setFatigueIntel(fatigue.fatigueIntelligence);
      setRecoveryIntel(recovery.recoveryIntelligence);
      setTrainingIntel(training.trainingIntelligence);
      setMarketIntel(market.marketIntelligence);

      // Aggregate all alerts
      const alerts = [
        ...(stress.stressIntelligence?.alerts || []).map((a) => ({
          ...a,
          source: "Stress",
        })),
        ...(fatigue.fatigueIntelligence?.alerts || []).map((a) => ({
          ...a,
          source: "Fatigue",
        })),
        ...(recovery.recoveryIntelligence?.alerts || []).map((a) => ({
          ...a,
          source: "Recovery",
        })),
        ...(training.trainingIntelligence?.alerts || []).map((a) => ({
          ...a,
          source: "Training",
        })),
        ...(market.marketIntelligence?.alerts || []).map((a) => ({
          ...a,
          source: "Market",
        })),
      ];

      // Sort by severity
      alerts.sort((a, b) => {
        const severityOrder = { critical: 0, warning: 1, info: 2 };
        return severityOrder[a.severity] - severityOrder[b.severity];
      });

      setAllAlerts(alerts);
    } catch (err) {
      console.error("Error loading intelligence:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading Intelligence Engines..." />;
  }

  if (error) {
    return (
      <ErrorScreen
        title="Error Loading Intelligence"
        message={error}
        onRetry={loadIntelligence}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421]">
      {/* Enhanced Header - MIGRATED TO SHARED COMPONENT */}
      <DashboardHeader
        icon={Brain}
        title="Intelligence Dashboard"
        description="Real-time biomechanical intelligence + market signals"
        onRefresh={loadIntelligence}
        loading={loading}
      >
        {/* Athlete Info */}
        <div className="bg-white/10 rounded-xl p-4 backdrop-blur border border-white/20">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-[#C8A882] rounded-full flex items-center justify-center text-2xl font-bold text-white">
              {athleteName
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">{athleteName}</h2>
              <p className="text-white/70">Athlete ID: {selectedAthleteId}</p>
            </div>
          </div>
        </div>
      </DashboardHeader>

      <div className="max-w-[1600px] mx-auto px-8 py-8">
        {/* Critical Alerts - Dark Theme FIXED */}
        {allAlerts.filter((a) => a.severity === "critical").length > 0 && (
          <div className="bg-gradient-to-r from-red-900/40 to-red-800/40 border border-red-500/30 rounded-xl p-6 backdrop-blur-sm mb-6">
            <div className="flex items-start gap-3">
              <AlertCircle
                className="text-red-400 flex-shrink-0 mt-0.5"
                size={24}
              />
              <div className="flex-1">
                <h3 className="font-bold text-red-300 mb-2 text-lg">
                  Critical Alerts Detected
                </h3>
                <div className="space-y-2">
                  {allAlerts
                    .filter((a) => a.severity === "critical")
                    .map((alert, idx) => (
                      <div
                        key={idx}
                        className="text-xs bg-[#1B3A57]/60 backdrop-blur-sm border border-red-500/20 p-2 rounded"
                      >
                        <div className="flex items-start justify-between mb-1">
                          <p className="font-semibold text-white">
                            [{alert.source}] {alert.message}
                          </p>
                        </div>
                        <p className="text-sm text-gray-300">
                          → {alert.recommendation}
                        </p>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Intelligence Engine Grid - keep existing */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Stress Intelligence */}
          <IntelligenceCard
            title="Stress Intelligence"
            icon={AlertCircle}
            color="#EF4444"
            score={stressIntel?.overallStressScore}
            status={
              stressIntel?.overallStressScore > 0.7
                ? "critical"
                : stressIntel?.overallStressScore > 0.4
                  ? "warning"
                  : "normal"
            }
            alerts={stressIntel?.alerts || []}
            data={[
              {
                label: "Joint Asymmetry",
                value: `${(stressIntel?.jointTorque.asymmetryScore * 100).toFixed(0)}%`,
              },
              {
                label: "GRF Symmetry",
                value: `${(stressIntel?.groundReactionForce.forceSymmetry * 100).toFixed(0)}%`,
              },
              {
                label: "HRV Stress Index",
                value: `${(stressIntel?.hrvStress.stressIndex * 100).toFixed(0)}%`,
              },
              {
                label: "Autonomic Balance",
                value: stressIntel?.hrvStress.autonomicBalance,
              },
            ]}
          />

          {/* Fatigue Intelligence */}
          <IntelligenceCard
            title="Fatigue Intelligence"
            icon={Zap}
            color="#F97316"
            score={fatigueIntel?.overallFatigueScore}
            status={
              fatigueIntel?.overallFatigueScore > 0.7
                ? "critical"
                : fatigueIntel?.overallFatigueScore > 0.4
                  ? "warning"
                  : "normal"
            }
            alerts={fatigueIntel?.alerts || []}
            data={[
              {
                label: "Fatigue Load",
                value: `${(fatigueIntel?.fatigueAccumulation.total * 100).toFixed(0)}%`,
              },
              {
                label: "Stride Shortening",
                value: `${fatigueIntel?.strideMetrics.shortening.toFixed(1)}%`,
              },
              {
                label: "Reaction Lag",
                value: `${fatigueIntel?.reactionTime.lag.toFixed(0)}ms`,
              },
              {
                label: "Hydration",
                value: `${(fatigueIntel?.hydration.level * 100).toFixed(0)}%`,
              },
            ]}
          />

          {/* Recovery Intelligence */}
          <IntelligenceCard
            title="Recovery Intelligence"
            icon={Activity}
            color="#10B981"
            score={recoveryIntel?.overallRecoveryScore}
            status={
              recoveryIntel?.overallRecoveryScore < 0.4
                ? "critical"
                : recoveryIntel?.overallRecoveryScore < 0.6
                  ? "warning"
                  : "normal"
            }
            alerts={recoveryIntel?.alerts || []}
            data={[
              {
                label: "Recovery Score",
                value: `${(recoveryIntel?.overallRecoveryScore * 100).toFixed(0)}%`,
              },
              {
                label: "Recovery Velocity",
                value: `${(recoveryIntel?.recoveryVelocity * 100).toFixed(0)}%`,
              },
              {
                label: "Sleep Debt",
                value: `${recoveryIntel?.sleep.debt.toFixed(1)} hrs`,
              },
              {
                label: "Healing Phase",
                value: recoveryIntel?.tissueRepair.healingPhase,
              },
            ]}
            inverted={true}
          />

          {/* Training Intelligence */}
          <IntelligenceCard
            title="Training Intelligence"
            icon={Shield}
            color="#3B82F6"
            score={trainingIntel?.trainingReadiness.score}
            status={
              trainingIntel?.trainingReadiness.score < 0.4
                ? "critical"
                : trainingIntel?.trainingReadiness.score < 0.6
                  ? "warning"
                  : "normal"
            }
            alerts={trainingIntel?.alerts || []}
            data={[
              {
                label: "ACWR",
                value: `${trainingIntel?.workloadRatio.ratio.toFixed(2)}`,
              },
              {
                label: "Risk Zone",
                value: trainingIntel?.workloadRatio.riskZone,
              },
              {
                label: "Readiness",
                value: trainingIntel?.trainingReadiness.recommendation,
              },
              {
                label: "Velocity Loss",
                value: `${trainingIntel?.velocity.loss.toFixed(1)}%`,
              },
            ]}
            inverted={true}
          />
        </div>

        {/* AR Biomechanical Overlay */}
        <ARBiomechOverlay
          athleteId={selectedAthleteId}
          athleteName={athleteName}
          biomechData={{
            stressLoad: stressIntel?.overallStressScore,
            fatigueSeverity: fatigueIntel?.overallFatigueScore,
            recoveryVelocity: recoveryIntel?.overallRecoveryScore,
            trainingLoad: trainingIntel?.overallLoadScore,
            techniqueDrift: trainingIntel?.techniqueDrift.overall,
          }}
        />

        {/* BiomechFlow Chart + Risk Forecast */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <BiomechFlowChart
            athleteId={selectedAthleteId}
            athleteName={athleteName}
          />
          <RiskForecastPanel athleteId={selectedAthleteId} />
        </div>

        {/* All Alerts - DARK THEME FIXED */}
        {allAlerts.length > 0 && (
          <div className="mt-6 bg-[#0D1421]/60 backdrop-blur-sm border border-[#C8A882]/20 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <AlertCircle size={24} className="text-[#C8A882]" />
              All Intelligence Alerts ({allAlerts.length})
            </h3>
            <div className="space-y-3">
              {allAlerts.map((alert, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-lg border backdrop-blur-sm transition-all hover:bg-opacity-30 ${
                    alert.severity === "critical"
                      ? "bg-red-900/20 border-red-500/30"
                      : alert.severity === "warning"
                        ? "bg-amber-900/20 border-amber-500/30"
                        : "bg-blue-900/20 border-blue-500/30"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <span
                        className={`text-xs font-bold px-2 py-1 rounded ${
                          alert.severity === "critical"
                            ? "bg-red-500/30 text-red-300"
                            : alert.severity === "warning"
                              ? "bg-amber-500/30 text-amber-300"
                              : "bg-blue-500/30 text-blue-300"
                        }`}
                      >
                        {alert.source}
                      </span>
                      <span className="ml-2 text-sm font-semibold text-white">
                        {alert.message}
                      </span>
                    </div>
                    <span
                      className={`text-xs font-bold px-2 py-1 rounded ${
                        alert.severity === "critical"
                          ? "bg-red-500/30 text-red-300"
                          : alert.severity === "warning"
                            ? "bg-amber-500/30 text-amber-300"
                            : "bg-blue-500/30 text-blue-300"
                      }`}
                    >
                      {alert.severity.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-300 flex items-center gap-2">
                    <ArrowRight size={14} />
                    {alert.recommendation}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Updated IntelligenceCard with dark theme
function IntelligenceCard({
  title,
  icon: Icon,
  color,
  score,
  status,
  alerts,
  data,
  inverted = false,
}) {
  const getStatusColor = () => {
    if (status === "critical") return "border-red-500/40 bg-red-900/10";
    if (status === "warning") return "border-yellow-500/40 bg-yellow-900/10";
    return "border-green-500/40 bg-green-900/10";
  };

  const getScoreColor = () => {
    if (inverted) {
      if (score < 0.4) return "text-red-400";
      if (score < 0.6) return "text-yellow-400";
      return "text-green-400";
    } else {
      if (score > 0.7) return "text-red-400";
      if (score > 0.4) return "text-yellow-400";
      return "text-green-400";
    }
  };

  return (
    <div
      className={`bg-[#0D1421]/60 backdrop-blur-sm rounded-xl border-2 p-6 ${getStatusColor()}`}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-lg bg-[#C8A882]/10">
            <Icon className="text-[#C8A882]" size={24} />
          </div>
          <h3 className="text-lg font-bold text-white">{title}</h3>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-400 mb-1">Score</p>
          <p className={`text-3xl font-bold ${getScoreColor()}`}>
            {(score * 100).toFixed(0)}%
          </p>
        </div>
      </div>

      {/* Data Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {data.map((item, idx) => (
          <div
            key={idx}
            className="bg-[#0D1421]/40 p-3 rounded-lg border border-[#C8A882]/10"
          >
            <p className="text-xs text-gray-400 mb-1">{item.label}</p>
            <p className="text-sm font-bold text-white">{item.value}</p>
          </div>
        ))}
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="border-t border-[#C8A882]/20 pt-3">
          <p className="text-xs font-semibold text-gray-400 mb-2">
            Alerts ({alerts.length})
          </p>
          <div className="space-y-2">
            {alerts.slice(0, 2).map((alert, idx) => (
              <div
                key={idx}
                className="text-xs bg-[#0D1421]/40 p-2 rounded border border-[#C8A882]/10"
              >
                <p className="font-semibold text-white">{alert.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
