"use client";
import { useState, useEffect } from "react";
import {
  Home,
  Users,
  Calendar,
  Eye,
  AlertTriangle,
  FileText,
  Settings,
  Search,
  ChevronDown,
  Zap,
  Heart,
  ArrowLeft,
} from "lucide-react";

export default function ConsoleLayout({ children }) {
  const [pathname, setPathname] = useState("");

  useEffect(() => {
    setPathname(window.location.pathname);
  }, []);

  const navItems = [
    { icon: Home, label: "Home", href: "/console" },
    { icon: Users, label: "Athletes", href: "/console/athletes" },
    { icon: Calendar, label: "Events", href: "/console/events" },
    { icon: Eye, label: "AR Views", href: "/console/ar-views" },
    { icon: Zap, label: "AR Engine", href: "/console/ar-engine" },
    { icon: Heart, label: "Medical", href: "/console/medical-dashboard" },
    { icon: AlertTriangle, label: "Alerts", href: "/console/alerts" },
    { icon: FileText, label: "Reports", href: "/console/reports" },
    { icon: Settings, label: "Settings", href: "/console/settings" },
  ];

  const isActive = (href) => {
    if (href === "/console") return pathname === "/console";
    return pathname?.startsWith(href);
  };

  return (
    <div className="min-h-screen bg-[#0A0F1C] text-white">
      {/* Top Bar */}
      <div className="h-16 bg-[#1B3A57] border-b border-[#2A4A68] flex items-center justify-between px-6 sticky top-0 z-50">
        <div className="flex items-center gap-6">
          <a
            href="/"
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </a>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[#C8A882] rounded flex items-center justify-center font-bold text-[#1B3A57]">
              B
            </div>
            <span className="font-bold text-lg">BIM-APES Console</span>
          </div>
          <div className="px-3 py-1 bg-[#2A4A68] rounded text-xs font-medium text-[#C8A882]">
            PRODUCTION
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search athletes, teams, events..."
              className="pl-10 pr-4 py-2 bg-[#0A0F1C] border border-[#2A4A68] rounded-lg w-72 text-sm focus:outline-none focus:border-[#C8A882]"
            />
          </div>
          <button className="flex items-center gap-2 px-3 py-2 bg-[#2A4A68] rounded-lg hover:bg-[#3A5A78] transition-colors">
            <div className="w-8 h-8 bg-[#C8A882] rounded-full flex items-center justify-center font-bold text-[#1B3A57] text-sm">
              DB
            </div>
            <span className="text-sm font-medium">Dashawn B.</span>
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex">
        {/* Left Nav */}
        <div className="w-56 bg-[#0D1421] border-r border-[#1B3A57] min-h-[calc(100vh-4rem)] sticky top-16">
          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              return (
                <a
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors no-underline ${
                    active
                      ? "bg-[#1B3A57] text-[#C8A882] font-medium"
                      : "text-gray-300 hover:bg-[#1B3A57] hover:text-white"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{item.label}</span>
                </a>
              );
            })}
          </nav>

          {/* Bottom Links */}
          <div className="p-3 border-t border-[#1B3A57] mt-4 space-y-1">
            {[
              { href: "/intelligence-dashboard", label: "Intelligence" },
              { href: "/investor-dashboard", label: "Investor View" },
              { href: "/federation-dashboard", label: "Federation" },
              { href: "/sponsor-roi-dashboard", label: "Sponsor ROI" },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="flex items-center gap-3 px-4 py-2 rounded-lg text-gray-500 hover:text-[#C8A882] hover:bg-[#1B3A57]/40 transition-colors no-underline text-xs"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-auto">{children}</div>
      </div>
    </div>
  );
}
