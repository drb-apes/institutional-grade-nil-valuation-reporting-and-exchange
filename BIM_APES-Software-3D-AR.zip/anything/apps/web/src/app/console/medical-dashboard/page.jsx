"use client";

import { useState, useEffect } from "react";
import {
  Heart,
  Activity,
  AlertTriangle,
  TrendingDown,
  Users,
  Shield,
  Zap,
  Eye,
  Brain,
  ChevronRight,
  RefreshCw,
  Download,
  Bell,
} from "lucide-react";

export default function MedicalStaffDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [criticalAlerts, setCriticalAlerts] = useState([]);
  const [athleteRiskProfiles, setAthleteRiskProfiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMedicalData();
  }, []);

  const loadMedicalData = async () => {
    setLoading(true);
    // Simulate loading
    setTimeout(() => {
      setCriticalAlerts([
        {
          id: 1,
          athlete: "Athlete #23",
          sport: "Basketball",
          type: "Spatial Collapse Prediction",
          severity: "critical",
          score: 0.87,
          recommendation: "Immediate rest required",
          timestamp: new Date(Date.now() - 5 * 60 * 1000),
        },
        {
          id: 2,
          athlete: "Athlete #15",
          sport: "Rugby",
          type: "Impact Vector Overload",
          severity: "warning",
          score: 0.68,
          recommendation: "Monitor closely, reduce contact",
          timestamp: new Date(Date.now() - 12 * 60 * 1000),
        },
        {
          id: 3,
          athlete: "Athlete #42",
          sport: "Soccer",
          type: "Joint Divergence",
          severity: "warning",
          score: 0.72,
          recommendation: "Joint stress detected - left knee",
          timestamp: new Date(Date.now() - 8 * 60 * 1000),
        },
      ]);

      setAthleteRiskProfiles([
        {
          id: "a1",
          name: "Athlete #23",
          sport: "Basketball",
          collapse_risk: 0.87,
          impact_overload: 0.45,
          joint_divergence: 0.32,
          recovery_envelope: 0.58,
          overall_risk: "critical",
        },
        {
          id: "a2",
          name: "Athlete #15",
          sport: "Rugby",
          collapse_risk: 0.42,
          impact_overload: 0.78,
          joint_divergence: 0.55,
          recovery_envelope: 0.62,
          overall_risk: "warning",
        },
        {
          id: "a3",
          name: "Athlete #42",
          sport: "Soccer",
          collapse_risk: 0.28,
          impact_overload: 0.38,
          joint_divergence: 0.72,
          recovery_envelope: 0.71,
          overall_risk: "warning",
        },
        {
          id: "a4",
          name: "Athlete #8",
          sport: "Basketball",
          collapse_risk: 0.18,
          impact_overload: 0.22,
          joint_divergence: 0.25,
          recovery_envelope: 0.88,
          overall_risk: "normal",
        },
        {
          id: "a5",
          name: "Athlete #31",
          sport: "Soccer",
          collapse_risk: 0.15,
          impact_overload: 0.19,
          joint_divergence: 0.21,
          recovery_envelope: 0.92,
          overall_risk: "normal",
        },
      ]);

      setLoading(false);
    }, 800);
  };

  const getRiskColor = (risk) => {
    if (risk === "critical") return "text-red-400 bg-red-500/20";
    if (risk === "warning") return "text-amber-400 bg-amber-500/20";
    return "text-emerald-400 bg-emerald-500/20";
  };

  const getRiskBadge = (risk) => {
    if (risk === "critical")
      return "bg-red-500/20 text-red-400 border-red-500/30";
    if (risk === "warning")
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
  };

  const getScoreColor = (score) => {
    if (score >= 0.75) return "text-red-400";
    if (score >= 0.5) return "text-amber-400";
    return "text-emerald-400";
  };

  const formatTimestamp = (date) => {
    const minutes = Math.floor((Date.now() - date.getTime()) / 60000);
    if (minutes < 1) return "Just now";
    if (minutes === 1) return "1 min ago";
    return `${minutes} mins ago`;
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
              <Heart className="w-8 h-8 text-[#C8A882]" />
              Medical Staff Dashboard
            </h1>
            <p className="text-gray-400">
              Real-time AR spatial intelligence for athlete health monitoring
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={loadMedicalData}
              className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </button>
            <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg transition-colors flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export Report
            </button>
          </div>
        </div>
      </div>

      {/* Critical Alerts Banner */}
      {criticalAlerts.filter((a) => a.severity === "critical").length > 0 && (
        <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <div className="flex-1">
              <div className="font-bold text-red-400 mb-1">
                Critical Alert: Immediate Action Required
              </div>
              <div className="text-sm text-gray-300">
                {criticalAlerts.filter((a) => a.severity === "critical").length}{" "}
                athlete(s) require immediate medical attention
              </div>
            </div>
            <button className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white font-medium rounded-lg transition-colors flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Acknowledge
            </button>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-red-500/20 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-400" />
            </div>
            <span className="text-2xl font-bold text-red-400">
              {criticalAlerts.filter((a) => a.severity === "critical").length}
            </span>
          </div>
          <div className="text-sm text-gray-400 mb-1">Critical Alerts</div>
          <div className="text-xs text-red-400">Immediate action required</div>
        </div>

        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-amber-500/20 rounded-lg">
              <Eye className="w-6 h-6 text-amber-400" />
            </div>
            <span className="text-2xl font-bold text-amber-400">
              {criticalAlerts.filter((a) => a.severity === "warning").length}
            </span>
          </div>
          <div className="text-sm text-gray-400 mb-1">Warning Alerts</div>
          <div className="text-xs text-amber-400">Monitor closely</div>
        </div>

        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-emerald-500/20 rounded-lg">
              <Shield className="w-6 h-6 text-emerald-400" />
            </div>
            <span className="text-2xl font-bold text-emerald-400">
              {
                athleteRiskProfiles.filter((a) => a.overall_risk === "normal")
                  .length
              }
            </span>
          </div>
          <div className="text-sm text-gray-400 mb-1">Safe to Play</div>
          <div className="text-xs text-emerald-400">Normal risk levels</div>
        </div>

        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-[#C8A882]/20 rounded-lg">
              <Users className="w-6 h-6 text-[#C8A882]" />
            </div>
            <span className="text-2xl font-bold text-[#C8A882]">
              {athleteRiskProfiles.length}
            </span>
          </div>
          <div className="text-sm text-gray-400 mb-1">Total Athletes</div>
          <div className="text-xs text-gray-400">Active monitoring</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 mb-6 border-b border-[#1B3A57]">
        {[
          { id: "overview", label: "Overview", icon: Activity },
          { id: "spatial_ar", label: "AR Spatial Intelligence", icon: Brain },
          { id: "alerts", label: "Active Alerts", icon: AlertTriangle },
          { id: "risk_profiles", label: "Risk Profiles", icon: TrendingDown },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-3 flex items-center gap-2 transition-colors border-b-2 ${
                activeTab === tab.id
                  ? "border-[#C8A882] text-[#C8A882]"
                  : "border-transparent text-gray-400 hover:text-gray-300"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === "overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Critical Alerts */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-[#C8A882]" />
              Recent Alerts
            </h3>
            <div className="space-y-3">
              {criticalAlerts.slice(0, 5).map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border ${
                    alert.severity === "critical"
                      ? "bg-red-500/10 border-red-500/30"
                      : "bg-amber-500/10 border-amber-500/30"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="font-bold mb-1">{alert.athlete}</div>
                      <div className="text-sm text-gray-400">
                        {alert.sport} • {alert.type}
                      </div>
                    </div>
                    <div
                      className={`text-sm font-medium ${getScoreColor(alert.score)}`}
                    >
                      {(alert.score * 100).toFixed(0)}%
                    </div>
                  </div>
                  <div className="text-sm text-gray-300 mb-2">
                    {alert.recommendation}
                  </div>
                  <div className="text-xs text-gray-500">
                    {formatTimestamp(alert.timestamp)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* High Risk Athletes */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-[#C8A882]" />
              High Risk Athletes
            </h3>
            <div className="space-y-3">
              {athleteRiskProfiles
                .filter((a) => a.overall_risk !== "normal")
                .map((athlete) => (
                  <div
                    key={athlete.id}
                    className="p-4 bg-[#1B3A57]/30 rounded-lg"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <div className="font-bold mb-1">{athlete.name}</div>
                        <div className="text-sm text-gray-400">
                          {athlete.sport}
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium border ${getRiskBadge(athlete.overall_risk)}`}
                      >
                        {athlete.overall_risk.toUpperCase()}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-gray-400">Collapse Risk:</span>{" "}
                        <span className={getScoreColor(athlete.collapse_risk)}>
                          {(athlete.collapse_risk * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-400">Impact:</span>{" "}
                        <span
                          className={getScoreColor(athlete.impact_overload)}
                        >
                          {(athlete.impact_overload * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-400">Joint Div:</span>{" "}
                        <span
                          className={getScoreColor(athlete.joint_divergence)}
                        >
                          {(athlete.joint_divergence * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-400">Recovery:</span>{" "}
                        <span
                          className={getScoreColor(
                            1 - athlete.recovery_envelope,
                          )}
                        >
                          {(athlete.recovery_envelope * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "spatial_ar" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AR Method Modules */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Brain className="w-5 h-5 text-[#C8A882]" />
              AR Medical Methods (21-24)
            </h3>
            <div className="space-y-3">
              {[
                {
                  id: 21,
                  name: "Spatial Collapse Prediction",
                  description: "Collapse-risk vectors and balance instability",
                  visual: "AR risk halo",
                  status: "active",
                },
                {
                  id: 22,
                  name: "Impact Vector Overload",
                  description: "Impact direction and magnitude tracking",
                  visual: "AR impact cones",
                  status: "active",
                },
                {
                  id: 23,
                  name: "Joint Divergence Method",
                  description: "Unsafe joint angles and torque detection",
                  visual: "AR joint warnings",
                  status: "active",
                },
                {
                  id: 24,
                  name: "Spatial Recovery Envelope",
                  description: "Return-to-baseline recovery shell",
                  visual: "AR recovery shell",
                  status: "active",
                },
              ].map((method) => (
                <div
                  key={method.id}
                  className="p-4 bg-[#1B3A57]/30 rounded-lg hover:bg-[#1B3A57]/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="font-bold mb-1">
                        #{method.id} {method.name}
                      </div>
                      <div className="text-sm text-gray-400 mb-2">
                        {method.description}
                      </div>
                      <div className="text-xs text-[#C8A882]">
                        Visual: {method.visual}
                      </div>
                    </div>
                    <span className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-400 text-xs font-medium">
                      {method.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AR Visualization Preview */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#C8A882]" />
              AR Visualization Preview
            </h3>
            <div className="aspect-video bg-gradient-to-br from-[#1B3A57] to-[#0A0F1C] rounded-lg border border-[#2A4A68] overflow-hidden">
              <div className="relative w-full h-full flex items-center justify-center">
                {/* Simulated AR overlay */}
                <div className="relative">
                  {/* Collapse risk halo */}
                  <div className="w-40 h-40 rounded-full border-4 border-red-500 opacity-40 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />

                  {/* Impact cones */}
                  <div className="absolute top-4 left-4">
                    <div className="w-16 h-16 bg-amber-500/20 border border-amber-500/50 rounded-lg flex items-center justify-center">
                      <Zap className="w-8 h-8 text-amber-400" />
                    </div>
                  </div>

                  {/* Joint warnings */}
                  <div className="absolute bottom-4 right-4">
                    <div className="w-16 h-16 bg-red-500/20 border border-red-500/50 rounded-lg flex items-center justify-center">
                      <AlertTriangle className="w-8 h-8 text-red-400" />
                    </div>
                  </div>

                  {/* Center label */}
                  <div className="text-center">
                    <div className="text-sm text-gray-400 mb-2">
                      AR Medical Overlay Active
                    </div>
                    <div className="text-xs text-gray-500">
                      Real-time spatial intelligence
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-4 p-3 bg-[#1B3A57]/30 rounded-lg">
              <div className="text-sm font-medium mb-2">
                Active AR Overlays:
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <span>Collapse Risk Halo</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <span>Impact Cones</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <span>Joint Warnings</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span>Recovery Shell</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "alerts" && (
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <div className="space-y-4">
            {criticalAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-6 rounded-lg border ${
                  alert.severity === "critical"
                    ? "bg-red-500/10 border-red-500/30"
                    : "bg-amber-500/10 border-amber-500/30"
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <AlertTriangle
                        className={`w-6 h-6 ${
                          alert.severity === "critical"
                            ? "text-red-400"
                            : "text-amber-400"
                        }`}
                      />
                      <div>
                        <div className="font-bold text-lg">{alert.athlete}</div>
                        <div className="text-sm text-gray-400">
                          {alert.sport}
                        </div>
                      </div>
                    </div>
                    <div className="text-sm mb-2">
                      <span className="text-gray-400">Alert Type:</span>{" "}
                      <span className="font-medium">{alert.type}</span>
                    </div>
                    <div className="text-sm mb-3">
                      <span className="text-gray-400">Risk Score:</span>{" "}
                      <span
                        className={`font-bold ${getScoreColor(alert.score)}`}
                      >
                        {(alert.score * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="p-3 bg-black/30 rounded-lg mb-3">
                      <div className="text-sm font-medium mb-1">
                        Recommendation:
                      </div>
                      <div className="text-sm text-gray-300">
                        {alert.recommendation}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      Detected: {formatTimestamp(alert.timestamp)}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 ml-4">
                    <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg transition-colors text-sm">
                      View AR Overlay
                    </button>
                    <button className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg transition-colors text-sm">
                      View Details
                    </button>
                    <button className="px-4 py-2 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 rounded-lg transition-colors text-sm">
                      Acknowledge
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "risk_profiles" && (
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1B3A57]">
                  <th className="text-left py-3 px-4 text-sm font-medium text-gray-400">
                    Athlete
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-gray-400">
                    Sport
                  </th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-gray-400">
                    Collapse
                  </th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-gray-400">
                    Impact
                  </th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-gray-400">
                    Joint Div
                  </th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-gray-400">
                    Recovery
                  </th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-gray-400">
                    Status
                  </th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-gray-400">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {athleteRiskProfiles.map((athlete) => (
                  <tr
                    key={athlete.id}
                    className="border-b border-[#1B3A57]/50 hover:bg-[#1B3A57]/20 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <div className="font-medium">{athlete.name}</div>
                    </td>
                    <td className="py-4 px-4 text-sm text-gray-400">
                      {athlete.sport}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`font-medium ${getScoreColor(athlete.collapse_risk)}`}
                      >
                        {(athlete.collapse_risk * 100).toFixed(0)}%
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`font-medium ${getScoreColor(athlete.impact_overload)}`}
                      >
                        {(athlete.impact_overload * 100).toFixed(0)}%
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`font-medium ${getScoreColor(athlete.joint_divergence)}`}
                      >
                        {(athlete.joint_divergence * 100).toFixed(0)}%
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`font-medium ${getScoreColor(1 - athlete.recovery_envelope)}`}
                      >
                        {(athlete.recovery_envelope * 100).toFixed(0)}%
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium border ${getRiskBadge(athlete.overall_risk)}`}
                      >
                        {athlete.overall_risk}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <button className="p-2 hover:bg-[#1B3A57] rounded transition-colors">
                        <ChevronRight className="w-4 h-4 text-gray-400" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
