"use client";

import { useState } from "react";
import {
  FileText,
  Download,
  Calendar,
  Filter,
  TrendingUp,
  Users,
  DollarSign,
  Activity,
} from "lucide-react";

export default function ReportsPage() {
  const [activeCategory, setActiveCategory] = useState("performance");

  const categories = [
    { id: "performance", label: "Performance Reports", icon: Activity },
    { id: "nil", label: "NIL Reports", icon: DollarSign },
    { id: "sponsor", label: "Sponsor ROI Reports", icon: TrendingUp },
    { id: "team", label: "Team Analytics", icon: Users },
  ];

  const reports = {
    performance: [
      {
        id: "1",
        name: "Weekly Performance Summary",
        description:
          "Comprehensive athlete performance metrics and biometric trends",
        lastGenerated: "2024-03-16",
        frequency: "Weekly",
        format: ["PDF", "Excel", "CSV"],
        athletes: 247,
        size: "4.2 MB",
      },
      {
        id: "2",
        name: "Injury Risk Assessment",
        description:
          "Predictive injury risk analysis based on biomechanical data",
        lastGenerated: "2024-03-15",
        frequency: "Daily",
        format: ["PDF", "Excel"],
        athletes: 189,
        size: "2.8 MB",
      },
      {
        id: "3",
        name: "Recovery Optimization Report",
        description: "Recovery index trends and optimization recommendations",
        lastGenerated: "2024-03-16",
        frequency: "Weekly",
        format: ["PDF", "PowerPoint"],
        athletes: 156,
        size: "5.1 MB",
      },
    ],
    nil: [
      {
        id: "4",
        name: "NIL Valuation Report",
        description: "Market-based NIL valuations and momentum analysis",
        lastGenerated: "2024-03-16",
        frequency: "Daily",
        format: ["PDF", "Excel"],
        athletes: 312,
        size: "3.7 MB",
      },
      {
        id: "5",
        name: "NIL Momentum Dashboard",
        description: "Real-time NIL momentum tracking and trend forecasting",
        lastGenerated: "2024-03-16",
        frequency: "Real-time",
        format: ["PDF", "Excel", "PowerPoint"],
        athletes: 412,
        size: "6.4 MB",
      },
    ],
    sponsor: [
      {
        id: "6",
        name: "Sponsor ROI Analysis",
        description: "Campaign performance and return on investment metrics",
        lastGenerated: "2024-03-15",
        frequency: "Monthly",
        format: ["PDF", "PowerPoint"],
        athletes: 89,
        size: "8.2 MB",
      },
      {
        id: "7",
        name: "Activation Window Report",
        description: "Optimal sponsor activation timing and opportunities",
        lastGenerated: "2024-03-16",
        frequency: "Weekly",
        format: ["PDF", "Excel"],
        athletes: 134,
        size: "3.1 MB",
      },
    ],
    team: [
      {
        id: "8",
        name: "Team Performance Overview",
        description: "Aggregate team metrics and comparative analysis",
        lastGenerated: "2024-03-16",
        frequency: "Weekly",
        format: ["PDF", "PowerPoint", "Excel"],
        athletes: 523,
        size: "12.4 MB",
      },
      {
        id: "9",
        name: "Roster Health Report",
        description: "Team-wide health status and injury risk distribution",
        lastGenerated: "2024-03-16",
        frequency: "Daily",
        format: ["PDF", "Excel"],
        athletes: 156,
        size: "4.9 MB",
      },
    ],
  };

  const activeReports = reports[activeCategory] || [];
  const ActiveIcon =
    categories.find((c) => c.id === activeCategory)?.icon || FileText;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Reports</h1>
        <p className="text-gray-400">
          Generate and export comprehensive performance, NIL, and sponsor
          analytics
        </p>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-3 mb-6 border-b border-[#1B3A57]">
        {categories.map((category) => {
          const Icon = category.icon;
          const isActive = activeCategory === category.id;
          return (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center gap-2 px-4 py-3 font-medium transition-colors ${
                isActive
                  ? "text-[#C8A882] border-b-2 border-[#C8A882]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              <Icon className="w-5 h-5" />
              {category.label}
            </button>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <button className="p-6 bg-[#0D1421] border border-[#1B3A57] rounded-lg hover:bg-[#1B3A57]/30 transition-colors text-left">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="w-5 h-5 text-[#C8A882]" />
            <h3 className="font-bold">Schedule Report</h3>
          </div>
          <p className="text-sm text-gray-400">
            Set up recurring report generation
          </p>
        </button>

        <button className="p-6 bg-[#0D1421] border border-[#1B3A57] rounded-lg hover:bg-[#1B3A57]/30 transition-colors text-left">
          <div className="flex items-center gap-3 mb-2">
            <Filter className="w-5 h-5 text-[#C8A882]" />
            <h3 className="font-bold">Custom Report</h3>
          </div>
          <p className="text-sm text-gray-400">
            Build a custom report template
          </p>
        </button>

        <button className="p-6 bg-[#0D1421] border border-[#1B3A57] rounded-lg hover:bg-[#1B3A57]/30 transition-colors text-left">
          <div className="flex items-center gap-3 mb-2">
            <Download className="w-5 h-5 text-[#C8A882]" />
            <h3 className="font-bold">Export Archive</h3>
          </div>
          <p className="text-sm text-gray-400">
            Download all historical reports
          </p>
        </button>
      </div>

      {/* Reports Grid */}
      <div className="space-y-4">
        {activeReports.map((report) => (
          <div
            key={report.id}
            className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6 hover:bg-[#1B3A57]/30 transition-colors"
          >
            <div className="flex items-start justify-between">
              {/* Left: Report Info */}
              <div className="flex items-start gap-4 flex-1">
                <div className="p-3 bg-[#1B3A57]/30 rounded-lg">
                  <FileText className="w-6 h-6 text-[#C8A882]" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold mb-2">{report.name}</h3>
                  <p className="text-sm text-gray-400 mb-4">
                    {report.description}
                  </p>

                  <div className="flex items-center gap-6 text-sm">
                    <div>
                      <span className="text-gray-400">Last Generated: </span>
                      <span className="font-medium">
                        {report.lastGenerated}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-400">Frequency: </span>
                      <span className="font-medium">{report.frequency}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Athletes: </span>
                      <span className="font-medium">{report.athletes}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Size: </span>
                      <span className="font-medium">{report.size}</span>
                    </div>
                  </div>

                  {/* Format Pills */}
                  <div className="flex items-center gap-2 mt-4">
                    <span className="text-xs text-gray-400">
                      Available formats:
                    </span>
                    {report.format.map((format) => (
                      <span
                        key={format}
                        className="px-2 py-1 bg-[#1B3A57] text-xs rounded"
                      >
                        {format}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-2">
                <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg flex items-center gap-2 transition-colors">
                  <Download className="w-4 h-4" />
                  Generate
                </button>
                <button className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg transition-colors">
                  Schedule
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Exports */}
      <div className="mt-8 bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
        <h2 className="text-xl font-bold mb-4">Recent Exports</h2>
        <div className="space-y-3">
          {[
            {
              name: "Weekly Performance Summary.pdf",
              date: "2024-03-16 14:23",
              size: "4.2 MB",
            },
            {
              name: "NIL Valuation Report.xlsx",
              date: "2024-03-16 09:15",
              size: "3.7 MB",
            },
            {
              name: "Sponsor ROI Analysis.pptx",
              date: "2024-03-15 16:42",
              size: "8.2 MB",
            },
          ].map((export_, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-4 bg-[#1B3A57]/30 rounded-lg hover:bg-[#1B3A57]/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-[#C8A882]" />
                <div>
                  <div className="font-medium">{export_.name}</div>
                  <div className="text-xs text-gray-400">
                    {export_.date} • {export_.size}
                  </div>
                </div>
              </div>
              <button className="px-3 py-1 bg-[#1B3A57] hover:bg-[#2A4A68] rounded flex items-center gap-2 transition-colors text-sm">
                <Download className="w-4 h-4" />
                Download
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
