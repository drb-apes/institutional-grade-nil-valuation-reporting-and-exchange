"use client";

import { useQuery } from "@tanstack/react-query";
import { dashboardAPI } from "@/utils/api";
import {
  TrendingUp,
  AlertTriangle,
  DollarSign,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Bell,
  Calendar,
  Users2,
  Target,
} from "lucide-react";

export default function ConsoleDashboard() {
  // Fetch real dashboard data
  const { data, isLoading, error } = useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: dashboardAPI.getSummary,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const StatCard = ({ title, value, change, icon: Icon, trend }) => (
    <div className="bg-gradient-to-br from-[#0D1421] to-[#1B3A57]/50 border border-[#C8A882]/20 rounded-xl p-6 hover:shadow-xl transition-all hover:border-[#C8A882]/40">
      <div className="flex items-center justify-between mb-4">
        <span className="text-gray-400 text-sm font-semibold tracking-wide uppercase">
          {title}
        </span>
        <div className="w-10 h-10 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
          <Icon className="w-5 h-5 text-[#C8A882]" />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <div className="text-3xl font-bold text-white">{value}</div>
        {change && (
          <div
            className={`flex items-center gap-1 text-sm font-semibold px-3 py-1 rounded-full ${
              trend === "up"
                ? "bg-emerald-500/20 text-emerald-400"
                : "bg-red-500/20 text-red-400"
            }`}
          >
            {trend === "up" ? (
              <ArrowUpRight className="w-4 h-4" />
            ) : (
              <ArrowDownRight className="w-4 h-4" />
            )}
            {change}
          </div>
        )}
      </div>
    </div>
  );

  const getSeverityColor = (severity) => {
    switch (severity) {
      case "high":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      case "medium":
        return "bg-amber-500/20 text-amber-400 border-amber-500/30";
      case "low":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <div className="relative w-16 h-16 mx-auto mb-6">
            <div className="absolute inset-0 border-4 border-[#C8A882]/20 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-[#C8A882] border-t-transparent rounded-full animate-spin"></div>
          </div>
          <p className="text-gray-400 font-medium">
            Loading Performance Intelligence...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-4" />
          <p className="text-red-400">Failed to load dashboard</p>
          <p className="text-sm text-gray-500 mt-2">{error.message}</p>
        </div>
      </div>
    );
  }

  const { metrics, liveEvents, topAlerts, nilLeaders, sponsorWindows } =
    data.data;

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">
            Performance Intelligence
          </h1>
          <p className="text-gray-400 text-lg">
            Real-time biometric intelligence, AR overlays, and NIL momentum
            tracking
          </p>
        </div>
        <button className="bg-[#C8A882] hover:bg-[#B8956A] text-white px-6 py-3 rounded-lg font-semibold transition-all shadow-lg hover:shadow-xl flex items-center gap-2">
          <Bell className="w-5 h-5" />
          View All Alerts
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Active Athletes"
          value={metrics.activeAthletes.toLocaleString()}
          icon={Users2}
        />
        <StatCard
          title="Live Events"
          value={metrics.liveEvents.toString()}
          icon={Calendar}
        />
        <StatCard
          title="Critical Alerts"
          value={metrics.criticalAlerts.toString()}
          icon={AlertTriangle}
        />
        <StatCard
          title="NIL Volume (24h)"
          value={`$${(metrics.nilVolume24h / 1000000).toFixed(1)}M`}
          icon={DollarSign}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Live Events */}
        <div className="bg-[#0D1421] border border-[#C8A882]/20 rounded-xl overflow-hidden">
          <div className="bg-gradient-to-r from-[#1B3A57] to-[#0D1421] border-b border-[#C8A882]/20 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-[#C8A882]" />
                </div>
                <h2 className="text-xl font-bold text-white">Live Events</h2>
              </div>
              <a
                href="/console/events"
                className="text-[#C8A882] hover:text-[#D4B896] text-sm font-semibold flex items-center gap-1 transition-colors"
              >
                View All <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
          <div className="p-6 space-y-3">
            {liveEvents.length > 0 ? (
              liveEvents.map((event) => (
                <div
                  key={event.id}
                  className="flex items-center justify-between p-4 bg-[#1B3A57]/20 rounded-lg hover:bg-[#1B3A57]/40 transition-all cursor-pointer border border-transparent hover:border-[#C8A882]/20"
                >
                  <div>
                    <div className="font-semibold text-white mb-1">
                      {event.name}
                    </div>
                    <div className="text-sm text-gray-400">{event.venue}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold mb-1 text-red-400 flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
                      {event.status}
                    </div>
                    <div className="text-sm text-gray-400">
                      {new Date(event.time).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-500">No live events</p>
              </div>
            )}
          </div>
        </div>

        {/* Top Risk Alerts - similar structure */}
        <div className="bg-[#0D1421] border border-[#C8A882]/20 rounded-xl overflow-hidden">
          <div className="bg-gradient-to-r from-[#1B3A57] to-[#0D1421] border-b border-[#C8A882]/20 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-[#C8A882]" />
                </div>
                <h2 className="text-xl font-bold text-white">
                  Top Risk Alerts
                </h2>
              </div>
              <a
                href="/console/alerts"
                className="text-[#C8A882] hover:text-[#D4B896] text-sm font-semibold flex items-center gap-1 transition-colors"
              >
                View All <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
          <div className="p-6 space-y-3">
            {topAlerts.slice(0, 5).map((alert) => (
              <div
                key={alert.id}
                className="flex items-center justify-between p-4 bg-[#1B3A57]/20 rounded-lg hover:bg-[#1B3A57]/40 transition-all cursor-pointer border border-transparent hover:border-[#C8A882]/20"
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-3 h-3 rounded-full ${
                      alert.severity === "high"
                        ? "bg-red-400 animate-pulse"
                        : alert.severity === "medium"
                          ? "bg-amber-400"
                          : "bg-emerald-400"
                    }`}
                  />
                  <div>
                    <div className="font-semibold text-white mb-1">
                      {alert.athlete}
                    </div>
                    <div className="text-sm text-gray-400">{alert.type}</div>
                  </div>
                </div>
                <div
                  className={`px-4 py-2 rounded-lg border ${getSeverityColor(alert.severity)} text-sm font-bold`}
                >
                  {Math.round(alert.value)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* NIL Momentum Leaders */}
        <div className="bg-[#0D1421] border border-[#C8A882]/20 rounded-xl overflow-hidden">
          <div className="bg-gradient-to-r from-[#1B3A57] to-[#0D1421] border-b border-[#C8A882]/20 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-[#C8A882]" />
                </div>
                <h2 className="text-xl font-bold text-white">
                  NIL Momentum Leaders
                </h2>
              </div>
              <a
                href="/console/athletes"
                className="text-[#C8A882] hover:text-[#D4B896] text-sm font-semibold flex items-center gap-1 transition-colors"
              >
                View All <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
          <div className="p-6 space-y-3">
            {nilLeaders.map((athlete, idx) => (
              <div
                key={athlete.id}
                className="flex items-center justify-between p-4 bg-[#1B3A57]/20 rounded-lg hover:bg-[#1B3A57]/40 transition-all cursor-pointer border border-transparent hover:border-[#C8A882]/20"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#C8A882] to-[#B8956A] rounded-lg flex items-center justify-center font-bold text-white shadow-lg">
                    {idx + 1}
                  </div>
                  <div>
                    <div className="font-semibold text-white mb-1">
                      {athlete.name}
                    </div>
                    <div className="text-sm text-gray-400">
                      ${athlete.value.toLocaleString()}
                    </div>
                  </div>
                </div>
                <div
                  className={`flex items-center gap-2 text-sm font-semibold px-3 py-1 rounded-full ${
                    athlete.trend === "long"
                      ? "bg-emerald-500/20 text-emerald-400"
                      : "bg-red-500/20 text-red-400"
                  }`}
                >
                  {athlete.trend === "long" ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {athlete.change > 0 ? "+" : ""}
                  {athlete.change.toFixed(1)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sponsor Activation Windows */}
        <div className="bg-[#0D1421] border border-[#C8A882]/20 rounded-xl overflow-hidden">
          <div className="bg-gradient-to-r from-[#1B3A57] to-[#0D1421] border-b border-[#C8A882]/20 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#C8A882]/10 rounded-lg flex items-center justify-center">
                  <Target className="w-5 h-5 text-[#C8A882]" />
                </div>
                <h2 className="text-xl font-bold text-white">
                  Sponsor Activation Windows
                </h2>
              </div>
              <a
                href="/console/reports"
                className="text-[#C8A882] hover:text-[#D4B896] text-sm font-semibold flex items-center gap-1 transition-colors"
              >
                View All <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
          <div className="p-6 space-y-3">
            {sponsorWindows.map((window, index) => (
              <div
                key={index}
                className="p-4 bg-[#1B3A57]/20 rounded-lg hover:bg-[#1B3A57]/40 transition-all cursor-pointer border border-transparent hover:border-[#C8A882]/20"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="font-semibold text-white">{window.brand}</div>
                  <div className="text-sm text-emerald-400 font-bold bg-emerald-500/20 px-3 py-1 rounded-full">
                    {window.roi}% ROI
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="text-gray-400">{window.athlete}</div>
                  <div className="text-[#C8A882] font-semibold flex items-center gap-1">
                    <Activity className="w-4 h-4" />
                    {window.window}h left
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
