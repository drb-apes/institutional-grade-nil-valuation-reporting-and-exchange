"use client";

import { useState, useEffect } from "react";
import {
  AlertTriangle,
  Filter,
  Clock,
  User,
  Activity,
  TrendingDown,
  Search,
} from "lucide-react";

export default function AlertsPage() {
  const [alerts, setAlerts] = useState([]);
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    // Simulated data - replace with real API call
    setAlerts([
      {
        id: "1",
        athlete: "LeBron James",
        team: "Los Angeles Lakers",
        type: "Fatigue Risk",
        severity: "high",
        value: "87%",
        threshold: "75%",
        message:
          "Fatigue index exceeded safe threshold. Consider substitution or rest period.",
        timestamp: "2024-03-16T19:45:00",
        event: "Lakers vs Warriors",
        status: "active",
        timeline: "3rd Quarter, 4:32 remaining",
      },
      {
        id: "2",
        athlete: "Patrick Mahomes",
        team: "Kansas City Chiefs",
        type: "Injury Risk",
        severity: "medium",
        value: "64%",
        threshold: "60%",
        message:
          "Elevated injury risk detected based on biomechanical strain patterns.",
        timestamp: "2024-03-16T18:30:00",
        event: null,
        status: "monitoring",
        timeline: "Training Session",
      },
      {
        id: "3",
        athlete: "Caitlin Clark",
        team: "Indiana Fever",
        type: "Recovery Alert",
        severity: "low",
        value: "45%",
        threshold: "70%",
        message:
          "Recovery index below optimal. Recommend extended rest period.",
        timestamp: "2024-03-16T17:15:00",
        event: null,
        status: "acknowledged",
        timeline: "Post-Game Recovery",
      },
      {
        id: "4",
        athlete: "Steph Curry",
        team: "Golden State Warriors",
        type: "NIL Momentum Spike",
        severity: "info",
        value: "+42%",
        threshold: "+25%",
        message:
          "Significant NIL momentum spike detected. Sponsor activation window open.",
        timestamp: "2024-03-16T19:50:00",
        event: "Lakers vs Warriors",
        status: "active",
        timeline: "3rd Quarter, 2:15 remaining",
      },
      {
        id: "5",
        athlete: "Victor Wembanyama",
        team: "San Antonio Spurs",
        type: "Performance Anomaly",
        severity: "medium",
        value: "Detected",
        threshold: "N/A",
        message:
          "Unusual biomechanical patterns detected in shooting motion. Review recommended.",
        timestamp: "2024-03-16T16:45:00",
        event: null,
        status: "resolved",
        timeline: "Practice Session",
      },
    ]);
  }, []);

  const getSeverityColor = (severity) => {
    switch (severity) {
      case "high":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      case "medium":
        return "bg-amber-500/20 text-amber-400 border-amber-500/30";
      case "low":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "info":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "active":
        return "bg-red-500/20 text-red-400";
      case "monitoring":
        return "bg-amber-500/20 text-amber-400";
      case "acknowledged":
        return "bg-blue-500/20 text-blue-400";
      case "resolved":
        return "bg-gray-500/20 text-gray-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000 / 60); // minutes

    if (diff < 1) return "Just now";
    if (diff < 60) return `${diff}m ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
    return `${Math.floor(diff / 1440)}d ago`;
  };

  const filteredAlerts = alerts.filter((alert) => {
    const matchesSeverity =
      filterSeverity === "all" || alert.severity === filterSeverity;
    const matchesType = filterType === "all" || alert.type === filterType;
    const matchesSearch =
      alert.athlete.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.team.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.type.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSeverity && matchesType && matchesSearch;
  });

  const alertTypes = ["all", ...new Set(alerts.map((a) => a.type))];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Alerts</h1>
        <p className="text-gray-400">
          Real-time risk monitoring and performance anomaly detection
        </p>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-[#0D1421] border border-red-500/30 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">Critical</div>
          <div className="text-2xl font-bold text-red-400">
            {alerts.filter((a) => a.severity === "high").length}
          </div>
        </div>
        <div className="bg-[#0D1421] border border-amber-500/30 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">Warning</div>
          <div className="text-2xl font-bold text-amber-400">
            {alerts.filter((a) => a.severity === "medium").length}
          </div>
        </div>
        <div className="bg-[#0D1421] border border-blue-500/30 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">Advisory</div>
          <div className="text-2xl font-bold text-blue-400">
            {alerts.filter((a) => a.severity === "low").length}
          </div>
        </div>
        <div className="bg-[#0D1421] border border-emerald-500/30 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">Info</div>
          <div className="text-2xl font-bold text-emerald-400">
            {alerts.filter((a) => a.severity === "info").length}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search athletes, teams, or alert types..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-3 bg-[#0D1421] border border-[#1B3A57] rounded-lg w-full focus:outline-none focus:border-[#C8A882]"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="px-4 py-3 bg-[#0D1421] border border-[#1B3A57] rounded-lg focus:outline-none focus:border-[#C8A882]"
          >
            <option value="all">All Severities</option>
            <option value="high">Critical</option>
            <option value="medium">Warning</option>
            <option value="low">Advisory</option>
            <option value="info">Info</option>
          </select>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-3 bg-[#0D1421] border border-[#1B3A57] rounded-lg focus:outline-none focus:border-[#C8A882]"
          >
            {alertTypes.map((type) => (
              <option key={type} value={type}>
                {type === "all" ? "All Types" : type}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.map((alert) => (
          <div
            key={alert.id}
            className={`bg-[#0D1421] border rounded-lg p-6 hover:bg-[#1B3A57]/30 transition-colors cursor-pointer ${
              alert.severity === "high"
                ? "border-red-500/30"
                : alert.severity === "medium"
                  ? "border-amber-500/30"
                  : alert.severity === "low"
                    ? "border-blue-500/30"
                    : "border-emerald-500/30"
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              {/* Left: Alert Info */}
              <div className="flex items-start gap-4 flex-1">
                <div
                  className={`p-3 rounded-lg ${getSeverityColor(alert.severity)}`}
                >
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold">{alert.type}</h3>
                    <div
                      className={`px-2 py-1 rounded text-xs font-medium ${getSeverityColor(alert.severity)}`}
                    >
                      {alert.severity.toUpperCase()}
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(alert.status)}`}
                    >
                      {alert.status.toUpperCase()}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      <span className="font-medium text-white">
                        {alert.athlete}
                      </span>
                    </div>
                    <span className="w-1 h-1 bg-gray-600 rounded-full" />
                    <span>{alert.team}</span>
                    {alert.event && (
                      <>
                        <span className="w-1 h-1 bg-gray-600 rounded-full" />
                        <span>{alert.event}</span>
                      </>
                    )}
                  </div>
                  <p className="text-gray-300 mb-3">{alert.message}</p>
                  <div className="flex items-center gap-6 text-sm">
                    <div>
                      <span className="text-gray-400">Current: </span>
                      <span className="font-bold text-white">
                        {alert.value}
                      </span>
                    </div>
                    {alert.threshold !== "N/A" && (
                      <div>
                        <span className="text-gray-400">Threshold: </span>
                        <span className="font-medium">{alert.threshold}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-gray-400">
                      <Clock className="w-4 h-4" />
                      <span>{alert.timeline}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Timestamp & Actions */}
              <div className="text-right">
                <div className="text-sm text-gray-400 mb-3">
                  {formatTimestamp(alert.timestamp)}
                </div>
                <div className="flex items-center gap-2">
                  {alert.status === "active" && (
                    <>
                      <button className="px-3 py-1 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded text-sm transition-colors">
                        Acknowledge
                      </button>
                      <button className="px-3 py-1 bg-[#1B3A57] hover:bg-[#2A4A68] rounded text-sm transition-colors">
                        View Detail
                      </button>
                    </>
                  )}
                  {alert.status === "monitoring" && (
                    <button className="px-3 py-1 bg-[#1B3A57] hover:bg-[#2A4A68] rounded text-sm transition-colors">
                      Update Status
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Timeline Indicator (for active alerts) */}
            {alert.status === "active" && (
              <div className="pt-4 border-t border-[#1B3A57]">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                  <span>Alert Timeline</span>
                  <span>Active for {formatTimestamp(alert.timestamp)}</span>
                </div>
                <div className="relative h-1 bg-[#1B3A57]/30 rounded-full overflow-hidden">
                  <div
                    className="absolute left-0 top-0 h-full bg-red-400 rounded-full animate-pulse"
                    style={{ width: "40%" }}
                  />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {filteredAlerts.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          No alerts found matching your filter criteria
        </div>
      )}
    </div>
  );
}
