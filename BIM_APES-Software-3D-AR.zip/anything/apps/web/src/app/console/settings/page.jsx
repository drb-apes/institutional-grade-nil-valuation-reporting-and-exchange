"use client";

import { useState } from "react";
import {
  Settings as SettingsIcon,
  Palette,
  Users,
  Link as LinkIcon,
  Bell,
  Shield,
} from "lucide-react";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("branding");

  const tabs = [
    { id: "branding", label: "Branding", icon: Palette },
    { id: "users", label: "Users & Roles", icon: Users },
    { id: "integrations", label: "Integrations", icon: LinkIcon },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "security", label: "Security", icon: Shield },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-gray-400">
          Configure branding, permissions, integrations, and platform
          preferences
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-3 mb-6 border-b border-[#1B3A57]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 font-medium transition-colors ${
                isActive
                  ? "text-[#C8A882] border-b-2 border-[#C8A882]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              <Icon className="w-5 h-5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === "branding" && (
        <div className="space-y-6">
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Team Colors & Logo</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Primary Color
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    defaultValue="#C8A882"
                    className="w-16 h-16 rounded-lg border border-[#1B3A57] bg-transparent cursor-pointer"
                  />
                  <input
                    type="text"
                    defaultValue="#C8A882"
                    className="flex-1 px-4 py-2 bg-[#1B3A57]/30 border border-[#1B3A57] rounded-lg focus:outline-none focus:border-[#C8A882]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Secondary Color
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    defaultValue="#1B3A57"
                    className="w-16 h-16 rounded-lg border border-[#1B3A57] bg-transparent cursor-pointer"
                  />
                  <input
                    type="text"
                    defaultValue="#1B3A57"
                    className="flex-1 px-4 py-2 bg-[#1B3A57]/30 border border-[#1B3A57] rounded-lg focus:outline-none focus:border-[#C8A882]"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Team Logo
              </label>
              <div className="flex items-center gap-4">
                <div className="w-24 h-24 bg-[#1B3A57]/30 rounded-lg flex items-center justify-center border-2 border-dashed border-[#1B3A57]">
                  <span className="text-sm text-gray-400">Logo</span>
                </div>
                <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg transition-colors">
                  Upload Logo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "users" && (
        <div className="space-y-6">
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Team Members</h2>
              <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg transition-colors">
                Invite User
              </button>
            </div>
            <div className="space-y-3">
              {[
                {
                  name: "Dashawn Bledsoe",
                  email: "dashawn@bledsoe.com",
                  role: "Owner",
                  status: "active",
                },
                {
                  name: "Coach Smith",
                  email: "coach@team.com",
                  role: "Coach",
                  status: "active",
                },
                {
                  name: "Dr. Martinez",
                  email: "martinez@team.com",
                  role: "Medical",
                  status: "active",
                },
                {
                  name: "Nike Rep",
                  email: "sponsor@nike.com",
                  role: "Sponsor",
                  status: "pending",
                },
              ].map((user, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-4 bg-[#1B3A57]/30 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#C8A882] rounded-full flex items-center justify-center font-bold text-[#1B3A57]">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-gray-400">{user.email}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="px-3 py-1 bg-[#1B3A57] rounded text-sm">
                      {user.role}
                    </div>
                    <div
                      className={`px-3 py-1 rounded text-xs ${
                        user.status === "active"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {user.status.toUpperCase()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Role Permissions</h2>
            <div className="space-y-4">
              {[
                {
                  role: "Coach",
                  permissions: [
                    "View Athletes",
                    "View Events",
                    "View Alerts",
                    "AR Views",
                  ],
                },
                {
                  role: "Medical",
                  permissions: [
                    "View Athletes",
                    "View Alerts",
                    "Generate Reports",
                  ],
                },
                {
                  role: "Sponsor",
                  permissions: ["View NIL Data", "View Reports", "AR Views"],
                },
              ].map((roleConfig, idx) => (
                <div key={idx} className="p-4 bg-[#1B3A57]/30 rounded-lg">
                  <div className="font-medium mb-3">{roleConfig.role}</div>
                  <div className="flex flex-wrap gap-2">
                    {roleConfig.permissions.map((perm, pidx) => (
                      <span
                        key={pidx}
                        className="px-3 py-1 bg-[#1B3A57] text-xs rounded"
                      >
                        {perm}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "integrations" && (
        <div className="space-y-6">
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Connected Integrations</h2>
            <div className="space-y-4">
              {[
                {
                  name: "BIM-APES AR Engine",
                  status: "connected",
                  description:
                    "Real-time AR overlays and biometric visualization",
                },
                {
                  name: "AWS Cloud Services",
                  status: "connected",
                  description: "Data storage and processing",
                },
                {
                  name: "Whoop API",
                  status: "connected",
                  description: "Wearable biometric data",
                },
                {
                  name: "Garmin Connect",
                  status: "disconnected",
                  description: "Performance tracking",
                },
                {
                  name: "Apple Watch HealthKit",
                  status: "connected",
                  description: "Heart rate and activity data",
                },
              ].map((integration, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-4 bg-[#1B3A57]/30 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        integration.status === "connected"
                          ? "bg-emerald-500/20"
                          : "bg-gray-500/20"
                      }`}
                    >
                      <LinkIcon
                        className={`w-5 h-5 ${
                          integration.status === "connected"
                            ? "text-emerald-400"
                            : "text-gray-400"
                        }`}
                      />
                    </div>
                    <div>
                      <div className="font-medium">{integration.name}</div>
                      <div className="text-sm text-gray-400">
                        {integration.description}
                      </div>
                    </div>
                  </div>
                  <button
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      integration.status === "connected"
                        ? "bg-[#1B3A57] hover:bg-[#2A4A68] text-white"
                        : "bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57]"
                    }`}
                  >
                    {integration.status === "connected"
                      ? "Configure"
                      : "Connect"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "notifications" && (
        <div className="space-y-6">
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Alert Preferences</h2>
            <div className="space-y-4">
              {[
                {
                  label: "Critical Alerts",
                  description: "High-severity injury and fatigue risks",
                  enabled: true,
                },
                {
                  label: "Performance Anomalies",
                  description: "Unusual biomechanical patterns",
                  enabled: true,
                },
                {
                  label: "NIL Momentum Spikes",
                  description: "Significant NIL value changes",
                  enabled: false,
                },
                {
                  label: "Sponsor Activation Windows",
                  description: "Optimal sponsor activation timing",
                  enabled: true,
                },
                {
                  label: "Daily Summary",
                  description: "Morning digest of key metrics",
                  enabled: true,
                },
              ].map((pref, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-4 bg-[#1B3A57]/30 rounded-lg"
                >
                  <div className="flex-1">
                    <div className="font-medium mb-1">{pref.label}</div>
                    <div className="text-sm text-gray-400">
                      {pref.description}
                    </div>
                  </div>
                  <div
                    className={`relative w-12 h-6 rounded-full transition-colors ${
                      pref.enabled ? "bg-[#C8A882]" : "bg-gray-600"
                    }`}
                  >
                    <div
                      className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        pref.enabled ? "translate-x-6" : "translate-x-0"
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "security" && (
        <div className="space-y-6">
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Security Settings</h2>
            <div className="space-y-4">
              <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">Two-Factor Authentication</div>
                  <div className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs rounded">
                    ENABLED
                  </div>
                </div>
                <p className="text-sm text-gray-400">
                  Additional security layer for account access
                </p>
              </div>

              <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">Session Timeout</div>
                  <select className="px-3 py-1 bg-[#1B3A57] rounded text-sm">
                    <option>30 minutes</option>
                    <option>1 hour</option>
                    <option>4 hours</option>
                    <option>Never</option>
                  </select>
                </div>
                <p className="text-sm text-gray-400">
                  Automatically log out after inactivity
                </p>
              </div>

              <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                <div className="font-medium mb-2">API Keys</div>
                <p className="text-sm text-gray-400 mb-3">
                  Manage API access for third-party integrations
                </p>
                <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg transition-colors">
                  Generate New Key
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
