"use client";

import { useState } from "react";
import {
  Eye,
  Settings,
  Zap,
  Activity,
  TrendingUp,
  Target,
  AlertTriangle,
  Play,
  Pause,
  Download,
  Share2,
  Maximize,
  Minimize,
  RefreshCw,
} from "lucide-react";

export default function AREnginePage() {
  const [engineStatus, setEngineStatus] = useState("active");
  const [activePreset, setActivePreset] = useState("universal_frame");
  const [overlayConfig, setOverlayConfig] = useState({
    ssi_enabled: true,
    cis_enabled: true,
    arc_enabled: true,
    exit_score_enabled: true,
    mispricing_alerts: true,
    convexity_halo: true,
    momentum_vectors: true,
    stability_badges: true,
    spread_rings: true,
  });

  const [performanceMetrics, setPerformanceMetrics] = useState({
    latency_ms: 87,
    fps: 120,
    render_quality: 98,
    data_freshness_s: 2.1,
  });

  const presets = [
    {
      id: "universal_frame",
      name: "Universal Frame",
      description: "Complete overlay with all metrics",
      icon: Maximize,
      overlays: 9,
    },
    {
      id: "trading_focus",
      name: "Trading Focus",
      description: "SSI, CIS, ARC, Exit Score only",
      icon: TrendingUp,
      overlays: 4,
    },
    {
      id: "coach_view",
      name: "Coach View",
      description: "Performance + fatigue indicators",
      icon: Activity,
      overlays: 6,
    },
    {
      id: "medical_alert",
      name: "Medical Alert",
      description: "Injury risk + recovery status",
      icon: AlertTriangle,
      overlays: 5,
    },
    {
      id: "sponsor_activation",
      name: "Sponsor Activation",
      description: "NIL momentum + brand fit",
      icon: Zap,
      overlays: 7,
    },
  ];

  const overlayToggles = [
    {
      key: "ssi_enabled",
      label: "SSI (Scalping Signal Index)",
      description: "Short-term momentum burst detection",
      color: "#FF6F00",
    },
    {
      key: "cis_enabled",
      label: "CIS (Convexity Index Score)",
      description: "Non-linear upside capture potential",
      color: "#C8A882",
    },
    {
      key: "arc_enabled",
      label: "ARC (Arbitrage Readiness Coefficient)",
      description: "Spread exploitation readiness",
      color: "#2196F3",
    },
    {
      key: "exit_score_enabled",
      label: "Exit Score",
      description: "Position exit timing signals",
      color: "#F44336",
    },
    {
      key: "mispricing_alerts",
      label: "Mispricing Alerts",
      description: "Real-time gap detection",
      color: "#4CAF50",
    },
    {
      key: "convexity_halo",
      label: "Convexity Halo",
      description: "Golden glow for high CF athletes",
      color: "#FFD700",
    },
    {
      key: "momentum_vectors",
      label: "Momentum Vectors",
      description: "Directional performance arrows",
      color: "#9C27B0",
    },
    {
      key: "stability_badges",
      label: "Stability Badges",
      description: "CLi, FAi, HRV indicators",
      color: "#00BCD4",
    },
    {
      key: "spread_rings",
      label: "Spread Rings",
      description: "TV/MV gap visualization",
      color: "#FF9800",
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">BIM-APES AR Engine</h1>
            <p className="text-gray-400">
              Real-time AR overlay configuration and monitoring
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div
              className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                engineStatus === "active"
                  ? "bg-emerald-500/20 text-emerald-400"
                  : "bg-gray-500/20 text-gray-400"
              }`}
            >
              <div
                className={`w-2 h-2 rounded-full ${
                  engineStatus === "active"
                    ? "bg-emerald-400 animate-pulse"
                    : "bg-gray-400"
                }`}
              />
              <span className="font-medium">
                {engineStatus === "active" ? "Active" : "Paused"}
              </span>
            </div>
            <button
              onClick={() =>
                setEngineStatus(engineStatus === "active" ? "paused" : "active")
              }
              className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg transition-colors flex items-center gap-2"
            >
              {engineStatus === "active" ? (
                <>
                  <Pause className="w-4 h-4" />
                  Pause Engine
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Resume Engine
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Performance Metrics */}
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#C8A882]" />
            Performance
          </h3>
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-400">Latency</span>
                <span className="font-medium text-emerald-400">
                  {performanceMetrics.latency_ms}ms
                </span>
              </div>
              <div className="w-full bg-[#1B3A57] rounded-full h-2">
                <div
                  className="bg-emerald-400 h-2 rounded-full"
                  style={{
                    width: `${100 - performanceMetrics.latency_ms / 2}%`,
                  }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-400">FPS</span>
                <span className="font-medium text-emerald-400">
                  {performanceMetrics.fps}
                </span>
              </div>
              <div className="w-full bg-[#1B3A57] rounded-full h-2">
                <div
                  className="bg-emerald-400 h-2 rounded-full"
                  style={{ width: `${(performanceMetrics.fps / 120) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-400">Render Quality</span>
                <span className="font-medium text-emerald-400">
                  {performanceMetrics.render_quality}%
                </span>
              </div>
              <div className="w-full bg-[#1B3A57] rounded-full h-2">
                <div
                  className="bg-emerald-400 h-2 rounded-full"
                  style={{ width: `${performanceMetrics.render_quality}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-400">Data Freshness</span>
                <span className="font-medium text-emerald-400">
                  {performanceMetrics.data_freshness_s}s
                </span>
              </div>
              <div className="w-full bg-[#1B3A57] rounded-full h-2">
                <div
                  className="bg-emerald-400 h-2 rounded-full"
                  style={{
                    width: `${Math.max(0, 100 - performanceMetrics.data_freshness_s * 10)}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Active Overlays */}
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Eye className="w-5 h-5 text-[#C8A882]" />
            Active Overlays
          </h3>
          <div className="space-y-2">
            {Object.entries(overlayConfig).map(([key, enabled]) => {
              if (!enabled) return null;
              const config = overlayToggles.find((t) => t.key === key);
              if (!config) return null;
              return (
                <div
                  key={key}
                  className="flex items-center justify-between p-2 bg-[#1B3A57]/30 rounded"
                >
                  <span className="text-sm">{config.label.split("(")[0]}</span>
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: config.color }}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#C8A882]" />
            Quick Actions
          </h3>
          <div className="space-y-2">
            <button className="w-full px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg text-left transition-colors flex items-center gap-2">
              <RefreshCw className="w-4 h-4" />
              <span className="text-sm">Refresh All Overlays</span>
            </button>
            <button className="w-full px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg text-left transition-colors flex items-center gap-2">
              <Download className="w-4 h-4" />
              <span className="text-sm">Export Config</span>
            </button>
            <button className="w-full px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg text-left transition-colors flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              <span className="text-sm">Share Preview</span>
            </button>
            <button className="w-full px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg text-left transition-colors flex items-center gap-2">
              <Target className="w-4 h-4" />
              <span className="text-sm">Test Mode</span>
            </button>
          </div>
        </div>
      </div>

      {/* Preset Selector */}
      <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Configuration Presets</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {presets.map((preset) => {
            const Icon = preset.icon;
            const isActive = activePreset === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => setActivePreset(preset.id)}
                className={`p-4 rounded-lg border-2 transition-all text-left ${
                  isActive
                    ? "bg-[#1B3A57] border-[#C8A882]"
                    : "bg-[#0D1421] border-[#1B3A57] hover:border-[#2A4A68]"
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Icon
                    className={`w-5 h-5 ${isActive ? "text-[#C8A882]" : "text-gray-400"}`}
                  />
                  <span className="font-bold text-sm">{preset.name}</span>
                </div>
                <p className="text-xs text-gray-400 mb-2">
                  {preset.description}
                </p>
                <div className="text-xs text-gray-500">
                  {preset.overlays} overlays
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Overlay Configuration */}
      <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6 mb-6">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#C8A882]" />
          Overlay Configuration
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {overlayToggles.map((toggle) => (
            <div
              key={toggle.key}
              className="p-4 bg-[#1B3A57]/30 rounded-lg flex items-start justify-between"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: toggle.color }}
                  />
                  <span className="font-medium text-sm">{toggle.label}</span>
                </div>
                <p className="text-xs text-gray-400">{toggle.description}</p>
              </div>
              <button
                onClick={() =>
                  setOverlayConfig((prev) => ({
                    ...prev,
                    [toggle.key]: !prev[toggle.key],
                  }))
                }
                className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ml-3 ${
                  overlayConfig[toggle.key] ? "bg-[#C8A882]" : "bg-gray-600"
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    overlayConfig[toggle.key]
                      ? "translate-x-6"
                      : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Live Preview */}
      <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Live Preview</h2>
          <div className="flex items-center gap-2">
            <button className="p-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded transition-colors">
              <Minimize className="w-4 h-4" />
            </button>
            <button className="p-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded transition-colors">
              <Maximize className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Preview Canvas */}
        <div className="relative aspect-video bg-gradient-to-br from-[#1B3A57] to-[#0A0F1C] rounded-lg overflow-hidden border border-[#2A4A68]">
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Simulated AR Overlay */}
            <div className="relative w-full h-full">
              {/* SSI Indicator */}
              {overlayConfig.ssi_enabled && (
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm rounded-lg p-3 border border-[#FF6F00]/30">
                  <div className="text-xs text-gray-400 mb-1">SSI</div>
                  <div className="text-2xl font-bold text-[#FF6F00]">0.87</div>
                  <div className="text-xs text-emerald-400">↑ Scalp Ready</div>
                </div>
              )}

              {/* CIS Indicator */}
              {overlayConfig.cis_enabled && (
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30">
                  <div className="text-xs text-gray-400 mb-1">CIS</div>
                  <div className="text-2xl font-bold text-[#C8A882]">0.92</div>
                  <div className="text-xs text-emerald-400">High Convexity</div>
                </div>
              )}

              {/* ARC Indicator */}
              {overlayConfig.arc_enabled && (
                <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-sm rounded-lg p-3 border border-[#2196F3]/30">
                  <div className="text-xs text-gray-400 mb-1">ARC</div>
                  <div className="text-2xl font-bold text-[#2196F3]">0.78</div>
                  <div className="text-xs text-amber-400">Arb Window</div>
                </div>
              )}

              {/* Exit Score */}
              {overlayConfig.exit_score_enabled && (
                <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm rounded-lg p-3 border border-[#F44336]/30">
                  <div className="text-xs text-gray-400 mb-1">Exit Score</div>
                  <div className="text-2xl font-bold text-[#F44336]">0.42</div>
                  <div className="text-xs text-gray-400">Hold Position</div>
                </div>
              )}

              {/* Convexity Halo */}
              {overlayConfig.convexity_halo && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                  <div className="w-32 h-32 rounded-full border-4 border-[#FFD700] opacity-50 animate-pulse" />
                </div>
              )}

              {/* Spread Ring */}
              {overlayConfig.spread_rings && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                  <div className="w-40 h-40 rounded-full border-2 border-[#FF9800] opacity-40" />
                </div>
              )}

              {/* Center Display */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                <div className="text-sm text-gray-400 mb-2">
                  Universal Frame Active
                </div>
                <div className="text-xs text-gray-500">
                  {
                    Object.values(overlayConfig).filter((v) => v === true)
                      .length
                  }{" "}
                  / {Object.keys(overlayConfig).length} overlays enabled
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
