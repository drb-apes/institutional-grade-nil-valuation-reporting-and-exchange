"use client";

import { useState, useEffect } from "react";
import {
  Calendar,
  Filter,
  Clock,
  Users,
  TrendingUp,
  Play,
  Eye,
  Download,
} from "lucide-react";

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    // Simulated data - replace with real API call
    setEvents([
      {
        id: "1",
        name: "Lakers vs Warriors",
        league: "NBA",
        status: "live",
        quarter: "3rd Quarter",
        timeRemaining: "4:32",
        venue: "Crypto.com Arena",
        date: "2024-03-16",
        startTime: "19:30 PST",
        athletes: 28,
        activeAlerts: 3,
        nilVolume: "$1.2M",
        viewership: "2.4M",
      },
      {
        id: "2",
        name: "Patriots vs Chiefs",
        league: "NFL",
        status: "upcoming",
        venue: "Gillette Stadium",
        date: "2024-03-16",
        startTime: "20:15 EST",
        athletes: 106,
        activeAlerts: 0,
        nilVolume: "$3.8M",
        viewership: null,
      },
      {
        id: "3",
        name: "Fever vs Liberty",
        league: "WNBA",
        status: "completed",
        finalScore: "89-76",
        venue: "Gainbridge Fieldhouse",
        date: "2024-03-15",
        startTime: "19:00 EST",
        athletes: 24,
        activeAlerts: 0,
        nilVolume: "$450K",
        viewership: "1.8M",
      },
      {
        id: "4",
        name: "49ers vs Seahawks",
        league: "NFL",
        status: "upcoming",
        venue: "Levi's Stadium",
        date: "2024-03-17",
        startTime: "13:00 PST",
        athletes: 98,
        activeAlerts: 2,
        nilVolume: "$2.9M",
        viewership: null,
      },
    ]);
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case "live":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      case "upcoming":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "completed":
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case "live":
        return "LIVE";
      case "upcoming":
        return "UPCOMING";
      case "completed":
        return "COMPLETED";
      default:
        return status.toUpperCase();
    }
  };

  const filteredEvents = events.filter((event) => {
    if (filterStatus === "all") return true;
    return event.status === filterStatus;
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Events</h1>
        <p className="text-gray-400">
          Live game tracking, performance monitoring, and AR overlay control
        </p>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-3 bg-[#0D1421] border border-[#1B3A57] rounded-lg focus:outline-none focus:border-[#C8A882]"
          >
            <option value="all">All Events</option>
            <option value="live">Live</option>
            <option value="upcoming">Upcoming</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 gap-4">
        {filteredEvents.map((event) => (
          <div
            key={event.id}
            className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6 hover:bg-[#1B3A57]/30 transition-colors cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              {/* Left: Event Info */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold">{event.name}</h3>
                  <div
                    className={`px-3 py-1 rounded border text-xs font-medium ${getStatusColor(event.status)}`}
                  >
                    {getStatusLabel(event.status)}
                  </div>
                  {event.status === "live" && (
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <Clock className="w-4 h-4" />
                      <span>
                        {event.quarter} • {event.timeRemaining}
                      </span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{event.date}</span>
                  </div>
                  <span className="w-1 h-1 bg-gray-600 rounded-full" />
                  <span>{event.startTime}</span>
                  <span className="w-1 h-1 bg-gray-600 rounded-full" />
                  <span>{event.venue}</span>
                  <span className="w-1 h-1 bg-gray-600 rounded-full" />
                  <span className="px-2 py-0.5 bg-[#1B3A57] rounded text-xs">
                    {event.league}
                  </span>
                </div>
              </div>

              {/* Right: Actions */}
              {event.status === "live" && (
                <div className="flex items-center gap-2">
                  <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg flex items-center gap-2 transition-colors">
                    <Eye className="w-4 h-4" />
                    AR View
                  </button>
                  <button className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg flex items-center gap-2 transition-colors">
                    <Play className="w-4 h-4" />
                    Timeline
                  </button>
                </div>
              )}
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-[#1B3A57]">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-[#C8A882]" />
                <div>
                  <div className="text-xs text-gray-400">Athletes</div>
                  <div className="font-bold">{event.athletes}</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {event.activeAlerts > 0 ? (
                  <>
                    <div className="w-5 h-5 flex items-center justify-center">
                      <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse" />
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">Active Alerts</div>
                      <div className="font-bold text-red-400">
                        {event.activeAlerts}
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-5 h-5 flex items-center justify-center">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full" />
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">No Alerts</div>
                      <div className="font-bold text-emerald-400">Clear</div>
                    </div>
                  </>
                )}
              </div>

              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-[#C8A882]" />
                <div>
                  <div className="text-xs text-gray-400">NIL Volume</div>
                  <div className="font-bold">{event.nilVolume}</div>
                </div>
              </div>

              {event.viewership && (
                <div className="flex items-center gap-3">
                  <Eye className="w-5 h-5 text-[#C8A882]" />
                  <div>
                    <div className="text-xs text-gray-400">Viewership</div>
                    <div className="font-bold">{event.viewership}</div>
                  </div>
                </div>
              )}
            </div>

            {/* Timeline Preview (for live events) */}
            {event.status === "live" && (
              <div className="mt-4 pt-4 border-t border-[#1B3A57]">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                  <span>Game Timeline</span>
                  <span>Key Moments</span>
                </div>
                <div className="relative h-2 bg-[#1B3A57]/30 rounded-full overflow-hidden">
                  <div
                    className="absolute left-0 top-0 h-full bg-[#C8A882] rounded-full"
                    style={{ width: "65%" }}
                  />
                  <div className="absolute left-[30%] top-0 w-2 h-2 bg-red-400 rounded-full animate-pulse" />
                  <div className="absolute left-[50%] top-0 w-2 h-2 bg-amber-400 rounded-full" />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {filteredEvents.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          No events found matching your filter criteria
        </div>
      )}
    </div>
  );
}
