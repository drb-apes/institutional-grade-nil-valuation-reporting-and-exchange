"use client";

import { useState, useEffect } from "react";
import {
  ArrowLeft,
  Download,
  Share2,
  Eye,
  TrendingUp,
  Activity,
  AlertTriangle,
  Heart,
} from "lucide-react";
import BiomechFlowChart from "@/components/BiomechFlowChart";

export default function AthleteDetailPage({ params }) {
  const [athlete, setAthlete] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    setAthlete({
      id: params.id,
      name: "LeBron James",
      team: "Los Angeles Lakers",
      sport: "Basketball",
      position: "Forward",
      number: "23",
      status: "active",
      nilTier: "Tier I",
      coalitionStatus: "Active",
      biometrics: {
        fatigue: 67,
        recovery: 82,
        heartRate: 72,
        hrv: 58,
        readiness: 88,
        strain: 14.2,
      },
      nilMetrics: {
        currentValue: "$2.4M",
        momentum: "+24%",
        engagementScore: 94,
        brandFit: "Elite",
      },
      recentAlerts: [
        {
          id: 1,
          type: "Fatigue Spike",
          severity: "medium",
          time: "2h ago",
          message: "Fatigue increased 12% in last session",
        },
        {
          id: 2,
          type: "Recovery Alert",
          severity: "low",
          time: "1d ago",
          message: "Recovery optimal, cleared for full training",
        },
      ],
    });
  }, [params.id]);

  if (!athlete) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading athlete data...</div>
      </div>
    );
  }

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "joints", label: "Joint Analysis" },
    { id: "trends", label: "Performance Trends" },
    { id: "history", label: "Session History" },
  ];

  return (
    <div>
      <div className="mb-8">
        <a
          href="/console/athletes"
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Athletes
        </a>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-[#C8A882] rounded-full flex items-center justify-center font-bold text-[#1B3A57] text-3xl">
              {athlete.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-2">{athlete.name}</h1>
              <div className="flex items-center gap-4 text-gray-400">
                <span>{athlete.team}</span>
                <span className="w-1 h-1 bg-gray-600 rounded-full" />
                <span>
                  {athlete.position} #{athlete.number}
                </span>
                <span className="w-1 h-1 bg-gray-600 rounded-full" />
                <span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded text-sm">
                  {athlete.status.toUpperCase()}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg flex items-center gap-2 transition-colors">
              <Eye className="w-4 h-4" />
              Open in AR
            </button>
            <button className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg flex items-center gap-2 transition-colors">
              <Share2 className="w-4 h-4" />
              Share
            </button>
            <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg flex items-center gap-2 transition-colors">
              <Download className="w-4 h-4" />
              Export Report
            </button>
          </div>
        </div>
      </div>

      <div className="border-b border-[#1B3A57] mb-6">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`pb-3 px-1 font-medium transition-colors ${
                activeTab === tab.id
                  ? "text-[#C8A882] border-b-2 border-[#C8A882]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === "overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6 mb-6">
              <h2 className="text-xl font-bold mb-4">BiomechFlow Capsule</h2>
              <BiomechFlowChart athleteId={athlete.id} />
            </div>

            <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Key Biometric Indices</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4 text-[#C8A882]" />
                    <span className="text-sm text-gray-400">Fatigue Index</span>
                  </div>
                  <div className="text-3xl font-bold text-amber-400">
                    {athlete.biometrics.fatigue}%
                  </div>
                  <div className="mt-2 w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-amber-400 h-2 rounded-full"
                      style={{ width: `${athlete.biometrics.fatigue}%` }}
                    />
                  </div>
                </div>

                <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-4 h-4 text-[#C8A882]" />
                    <span className="text-sm text-gray-400">
                      Recovery Index
                    </span>
                  </div>
                  <div className="text-3xl font-bold text-emerald-400">
                    {athlete.biometrics.recovery}%
                  </div>
                  <div className="mt-2 w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-emerald-400 h-2 rounded-full"
                      style={{ width: `${athlete.biometrics.recovery}%` }}
                    />
                  </div>
                </div>

                <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Heart className="w-4 h-4 text-[#C8A882]" />
                    <span className="text-sm text-gray-400">HRV</span>
                  </div>
                  <div className="text-3xl font-bold">
                    {athlete.biometrics.hrv} ms
                  </div>
                </div>

                <div className="p-4 bg-[#1B3A57]/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4 text-[#C8A882]" />
                    <span className="text-sm text-gray-400">Strain Score</span>
                  </div>
                  <div className="text-3xl font-bold">
                    {athlete.biometrics.strain}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">NIL Valuation</h2>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-400 mb-1">
                    Current Value
                  </div>
                  <div className="text-3xl font-bold text-[#C8A882]">
                    {athlete.nilMetrics.currentValue}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-400 mb-1">24h Momentum</div>
                  <div className="text-2xl font-bold text-emerald-400 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    {athlete.nilMetrics.momentum}
                  </div>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-[#1B3A57]">
                  <span className="text-sm text-gray-400">
                    Engagement Score
                  </span>
                  <span className="font-bold">
                    {athlete.nilMetrics.engagementScore}/100
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Brand Fit</span>
                  <span className="font-bold text-[#C8A882]">
                    {athlete.nilMetrics.brandFit}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Recent Alerts</h2>
              <div className="space-y-3">
                {athlete.recentAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-4 rounded-lg border ${
                      alert.severity === "high"
                        ? "bg-red-500/10 border-red-500/30"
                        : alert.severity === "medium"
                          ? "bg-amber-500/10 border-amber-500/30"
                          : "bg-emerald-500/10 border-emerald-500/30"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <AlertTriangle
                        className={`w-5 h-5 mt-0.5 ${
                          alert.severity === "high"
                            ? "text-red-400"
                            : alert.severity === "medium"
                              ? "text-amber-400"
                              : "text-emerald-400"
                        }`}
                      />
                      <div className="flex-1">
                        <div className="font-medium mb-1">{alert.type}</div>
                        <div className="text-sm text-gray-400">
                          {alert.message}
                        </div>
                        <div className="text-xs text-gray-500 mt-2">
                          {alert.time}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "joints" && (
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Joint Analysis</h2>
          <p className="text-gray-400">
            Detailed joint-by-joint biomechanical analysis coming soon...
          </p>
        </div>
      )}

      {activeTab === "trends" && (
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Performance Trends</h2>
          <p className="text-gray-400">
            Historical performance trend analysis coming soon...
          </p>
        </div>
      )}

      {activeTab === "history" && (
        <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Session History</h2>
          <p className="text-gray-400">Session history log coming soon...</p>
        </div>
      )}
    </div>
  );
}
