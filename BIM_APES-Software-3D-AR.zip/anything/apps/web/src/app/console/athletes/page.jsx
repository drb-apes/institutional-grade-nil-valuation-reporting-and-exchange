"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { athletesAPI } from "@/utils/api";
import {
  Search,
  Filter,
  TrendingUp,
  TrendingDown,
  Activity,
  AlertTriangle,
} from "lucide-react";

export default function AthletesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  // Fetch athletes with metrics
  const { data, isLoading, error } = useQuery({
    queryKey: ["athletes-metrics", filterStatus],
    queryFn: () => athletesAPI.getMetrics(null, { limit: 100 }),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const getRiskColor = (level) => {
    switch (level) {
      case "high":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      case "medium":
        return "bg-amber-500/20 text-amber-400 border-amber-500/30";
      case "low":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-emerald-500/20 text-emerald-400";
      case "injured":
        return "bg-red-500/20 text-red-400";
      case "rest":
        return "bg-amber-500/20 text-amber-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#C8A882] mx-auto mb-4"></div>
          <p className="text-gray-400">Loading athletes...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-4" />
          <p className="text-red-400">Failed to load athletes</p>
          <p className="text-sm text-gray-500 mt-2">{error.message}</p>
        </div>
      </div>
    );
  }

  const athletes = data?.athletes || [];

  // Filter athletes based on search and status
  const filteredAthletes = athletes.filter((athlete) => {
    const matchesSearch =
      !searchTerm ||
      athlete.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      athlete.team.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter =
      filterStatus === "all" ||
      athlete.status.toLowerCase() === filterStatus.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Athletes</h1>
        <p className="text-gray-400">
          Real-time biometric monitoring and performance intelligence
        </p>
      </div>

      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search athletes or teams..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-3 bg-[#0D1421] border border-[#1B3A57] rounded-lg w-full focus:outline-none focus:border-[#C8A882]"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-3 bg-[#0D1421] border border-[#1B3A57] rounded-lg focus:outline-none focus:border-[#C8A882]"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="injured">Injured</option>
            <option value="rest">Rest</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredAthletes.map((athlete) => {
          const timeAgo = athlete.lastUpdated
            ? `${Math.round((new Date() - new Date(athlete.lastUpdated)) / 60000)}m ago`
            : "No data";

          return (
            <a
              key={athlete.id}
              href={`/console/athletes/${athlete.id}`}
              className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6 hover:bg-[#1B3A57]/30 transition-colors block"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-[#C8A882] rounded-full flex items-center justify-center font-bold text-[#1B3A57] text-xl">
                    {athlete.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <div>
                    <div className="font-bold text-lg mb-1">{athlete.name}</div>
                    <div className="text-sm text-gray-400 flex items-center gap-2">
                      <span>{athlete.team}</span>
                      <span className="w-1 h-1 bg-gray-600 rounded-full" />
                      <span>{athlete.sport}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-8">
                  <div className="text-center">
                    <div className="text-xs text-gray-400 mb-1">Fatigue</div>
                    <div
                      className={`text-2xl font-bold ${
                        athlete.fatigue > 70
                          ? "text-red-400"
                          : athlete.fatigue > 40
                            ? "text-amber-400"
                            : "text-emerald-400"
                      }`}
                    >
                      {athlete.fatigue || 0}%
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-xs text-gray-400 mb-1">Recovery</div>
                    <div
                      className={`text-2xl font-bold ${
                        athlete.recovery > 70
                          ? "text-emerald-400"
                          : athlete.recovery > 40
                            ? "text-amber-400"
                            : "text-red-400"
                      }`}
                    >
                      {athlete.recovery || 0}%
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-xs text-gray-400 mb-1">
                      NIL Momentum
                    </div>
                    <div className="text-2xl font-bold text-[#C8A882] flex items-center gap-1">
                      {athlete.nilMomentum.startsWith("+") ? (
                        <TrendingUp className="w-5 h-5" />
                      ) : athlete.nilMomentum.startsWith("-") ? (
                        <TrendingDown className="w-5 h-5" />
                      ) : (
                        <Activity className="w-5 h-5" />
                      )}
                      {athlete.nilMomentum}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex flex-col gap-2">
                    <div
                      className={`px-3 py-1 rounded text-xs font-medium ${getStatusColor(athlete.status)}`}
                    >
                      {athlete.status.toUpperCase()}
                    </div>
                    <div
                      className={`px-3 py-1 rounded border text-xs font-medium ${getRiskColor(athlete.riskLevel)}`}
                    >
                      {athlete.riskLevel.toUpperCase()} RISK
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-gray-500">{timeAgo}</div>
                  </div>
                </div>
              </div>
            </a>
          );
        })}
      </div>

      {filteredAthletes.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          No athletes found matching your search criteria
        </div>
      )}
    </div>
  );
}
