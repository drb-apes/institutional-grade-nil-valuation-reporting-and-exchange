"use client";

import { useState } from "react";
import {
  Tv,
  Maximize,
  Tablet,
  Globe,
  Eye,
  Settings,
  Download,
  Share2,
} from "lucide-react";

export default function ARViewsPage() {
  const [activeMode, setActiveMode] = useState("broadcast");
  const [overlayConfig, setOverlayConfig] = useState({
    showTrendPackages: true,
    showNIL: true,
    showSponsor: true,
    showRisk: true,
    showBiomech: true,
  });

  const modes = [
    {
      id: "broadcast",
      label: "Broadcast Mode",
      icon: Tv,
      description: "Lower-third overlays for TV broadcast",
      resolution: "1920x1080",
      framerate: "60fps",
    },
    {
      id: "stadium",
      label: "Stadium Mode",
      icon: Maximize,
      description: "Jumbotron and arena displays",
      resolution: "4K UHD",
      framerate: "60fps",
    },
    {
      id: "coach",
      label: "Coach Tablet",
      icon: Tablet,
      description: "Interactive AR for coaching staff",
      resolution: "2048x1536",
      framerate: "120fps",
    },
    {
      id: "web",
      label: "Web Embed",
      icon: Globe,
      description: "Browser-based AR overlays",
      resolution: "Responsive",
      framerate: "60fps",
    },
  ];

  const activeConfig = modes.find((m) => m.id === activeMode);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">AR Views</h1>
        <p className="text-gray-400">
          Configure and control AR overlays across broadcast, stadium, and web
          surfaces
        </p>
      </div>

      {/* Mode Selector */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {modes.map((mode) => {
          const Icon = mode.icon;
          const isActive = activeMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => setActiveMode(mode.id)}
              className={`p-6 rounded-lg border-2 transition-all text-left ${
                isActive
                  ? "bg-[#1B3A57] border-[#C8A882]"
                  : "bg-[#0D1421] border-[#1B3A57] hover:border-[#2A4A68]"
              }`}
            >
              <div className="flex items-center gap-3 mb-3">
                <Icon
                  className={`w-6 h-6 ${isActive ? "text-[#C8A882]" : "text-gray-400"}`}
                />
                <h3 className="font-bold">{mode.label}</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">{mode.description}</p>
              <div className="flex items-center gap-3 text-xs text-gray-500">
                <span>{mode.resolution}</span>
                <span className="w-1 h-1 bg-gray-600 rounded-full" />
                <span>{mode.framerate}</span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Preview Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* AR Preview */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">
                Preview: {activeConfig?.label}
              </h2>
              <div className="flex items-center gap-2">
                <button className="px-3 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg flex items-center gap-2 transition-colors">
                  <Eye className="w-4 h-4" />
                  <span className="text-sm">Live Preview</span>
                </button>
              </div>
            </div>

            {/* Preview Canvas */}
            <div className="relative aspect-video bg-gradient-to-br from-[#1B3A57] to-[#0A0F1C] rounded-lg overflow-hidden border border-[#2A4A68]">
              {/* Simulated AR Overlay Preview */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 bg-[#C8A882]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Eye className="w-8 h-8 text-[#C8A882]" />
                  </div>
                  <p className="text-sm text-gray-400">AR Overlay Preview</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {activeConfig?.resolution} @ {activeConfig?.framerate}
                  </p>
                </div>
              </div>

              {/* Example Overlay Elements */}
              {activeMode === "broadcast" && overlayConfig.showNIL && (
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-gray-400 mb-1">
                        NIL Momentum
                      </div>
                      <div className="text-2xl font-bold text-[#C8A882]">
                        +24%
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400 mb-1">
                        Recovery Index
                      </div>
                      <div className="text-2xl font-bold text-emerald-400">
                        82%
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeMode === "stadium" && overlayConfig.showBiomech && (
                <div className="absolute top-6 left-6 bg-black/60 backdrop-blur-sm rounded-lg p-4 border border-[#C8A882]/30">
                  <div className="text-sm text-gray-400 mb-2">
                    BiomechFlow Live
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 border-2 border-[#C8A882] rounded-full animate-pulse" />
                    <div>
                      <div className="text-xs text-gray-500">Fatigue Index</div>
                      <div className="text-lg font-bold text-amber-400">
                        67%
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Export Options */}
            <div className="flex items-center gap-3 mt-4">
              <button className="px-4 py-2 bg-[#C8A882] hover:bg-[#D4B896] text-[#1B3A57] font-medium rounded-lg flex items-center gap-2 transition-colors">
                <Download className="w-4 h-4" />
                Export Config
              </button>
              <button className="px-4 py-2 bg-[#1B3A57] hover:bg-[#2A4A68] rounded-lg flex items-center gap-2 transition-colors">
                <Share2 className="w-4 h-4" />
                Share Preview
              </button>
            </div>
          </div>

          {/* Active Overlays */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Active Overlays</h2>
            <div className="space-y-3">
              {[
                {
                  name: "LeBron James - Fatigue Alert",
                  status: "active",
                  priority: "high",
                },
                {
                  name: "NIL Momentum Dashboard",
                  status: "active",
                  priority: "medium",
                },
                {
                  name: "Sponsor Activation: Nike",
                  status: "standby",
                  priority: "low",
                },
              ].map((overlay, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-4 bg-[#1B3A57]/30 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        overlay.status === "active"
                          ? "bg-emerald-400 animate-pulse"
                          : "bg-gray-500"
                      }`}
                    />
                    <div>
                      <div className="font-medium">{overlay.name}</div>
                      <div className="text-xs text-gray-400">
                        Priority: {overlay.priority}
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-400">
                    {overlay.status === "active" ? "Broadcasting" : "Standby"}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Overlay Configuration */}
        <div className="space-y-6">
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Settings className="w-5 h-5 text-[#C8A882]" />
              <h2 className="text-xl font-bold">Overlay Settings</h2>
            </div>

            <div className="space-y-4">
              {[
                {
                  key: "showTrendPackages",
                  label: "Trend Packages",
                  description: "Performance momentum indicators",
                },
                {
                  key: "showNIL",
                  label: "NIL Data",
                  description: "Real-time NIL valuation",
                },
                {
                  key: "showSponsor",
                  label: "Sponsor Activations",
                  description: "Brand placement and ROI",
                },
                {
                  key: "showRisk",
                  label: "Risk Alerts",
                  description: "Injury and fatigue warnings",
                },
                {
                  key: "showBiomech",
                  label: "BiomechFlow",
                  description: "Joint-level analysis",
                },
              ].map((setting) => (
                <div
                  key={setting.key}
                  className="flex items-start justify-between p-4 bg-[#1B3A57]/30 rounded-lg"
                >
                  <div className="flex-1">
                    <div className="font-medium mb-1">{setting.label}</div>
                    <div className="text-xs text-gray-400">
                      {setting.description}
                    </div>
                  </div>
                  <button
                    onClick={() =>
                      setOverlayConfig((prev) => ({
                        ...prev,
                        [setting.key]: !prev[setting.key],
                      }))
                    }
                    className={`relative w-12 h-6 rounded-full transition-colors ${
                      overlayConfig[setting.key]
                        ? "bg-[#C8A882]"
                        : "bg-gray-600"
                    }`}
                  >
                    <div
                      className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        overlayConfig[setting.key]
                          ? "translate-x-6"
                          : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Technical Specs */}
          <div className="bg-[#0D1421] border border-[#1B3A57] rounded-lg p-6">
            <h3 className="font-bold mb-4">Technical Specifications</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Resolution</span>
                <span className="font-medium">{activeConfig?.resolution}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Framerate</span>
                <span className="font-medium">{activeConfig?.framerate}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Latency</span>
                <span className="font-medium text-emerald-400">&lt;100ms</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Encoding</span>
                <span className="font-medium">H.265</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
