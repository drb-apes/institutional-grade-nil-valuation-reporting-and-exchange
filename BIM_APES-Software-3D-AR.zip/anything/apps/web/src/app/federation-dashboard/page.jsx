"use client";

import { useState, useEffect } from "react";
import {
  Globe,
  Users,
  BarChart3,
  TrendingUp,
  Target,
  RefreshCw,
  MapPin,
  Award,
  Shield,
} from "lucide-react";
import LoadingScreen from "@/components/shared/LoadingScreen";
import ErrorScreen from "@/components/shared/ErrorScreen";
import DashboardHeader from "@/components/shared/DashboardHeader";
import PillTabs from "@/components/shared/PillTabs";
import MetricCard from "@/components/shared/MetricCard";
import GlassPanel from "@/components/shared/GlassPanel";

export default function FederationDashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [athletes, setAthletes] = useState([]);
  const [selectedSport, setSelectedSport] = useState("all");
  const [selectedView, setSelectedView] = useState("overview");
  const [coalitionMetrics, setCoalitionMetrics] = useState(null);

  useEffect(() => {
    loadFederationData();
  }, [selectedSport]);

  async function loadFederationData() {
    try {
      setLoading(true);
      setError(null);

      const athletesRes = await fetch(`/api/athletes/list?limit=100`);
      const athletesData = await athletesRes.json();

      let filteredAthletes = athletesData.athletes || [];
      if (selectedSport !== "all") {
        filteredAthletes = filteredAthletes.filter(
          (a) => a.sport === selectedSport,
        );
      }

      setAthletes(filteredAthletes);

      // Calculate coalition metrics
      const metrics = calculateCoalitionMetrics(filteredAthletes);
      setCoalitionMetrics(metrics);
    } catch (err) {
      console.error("Failed to load federation data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function calculateCoalitionMetrics(athleteList) {
    const total = athleteList.length;
    const active = athleteList.filter(
      (a) => a.coalition_status === "Active",
    ).length;
    const tierBreakdown = {
      "Tier I": athleteList.filter((a) => a.nil_tier === "Tier I").length,
      "Tier II": athleteList.filter((a) => a.nil_tier === "Tier II").length,
      "Tier III": athleteList.filter((a) => a.nil_tier === "Tier III").length,
    };
    const consentRate =
      (athleteList.filter((a) => a.consent_biometric).length / total) * 100;
    const sports = [...new Set(athleteList.map((a) => a.sport))];

    return {
      total,
      active,
      tierBreakdown,
      consentRate: consentRate.toFixed(1),
      sportCount: sports.length,
      sports,
    };
  }

  const availableSports = [...new Set(athletes.map((a) => a.sport))];

  if (loading) {
    return <LoadingScreen message="Loading Federation Dashboard..." />;
  }

  if (error) {
    return (
      <ErrorScreen
        title="Error Loading Federation Data"
        message={error}
        onRetry={loadFederationData}
      />
    );
  }

  const tabs = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "athletes", label: "Athletes", icon: Users },
    { id: "coalitions", label: "Coalitions", icon: Shield },
    { id: "expansion", label: "Expansion", icon: MapPin },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421]">
      {/* Header - MIGRATED TO SHARED COMPONENT */}
      <DashboardHeader
        icon={Globe}
        title="Federation Dashboard"
        description="Coalition Management • Athlete Oversight • Global Expansion"
        onRefresh={loadFederationData}
        loading={loading}
      >
        {/* Tab Navigation - MIGRATED TO SHARED COMPONENT */}
        <PillTabs
          tabs={tabs}
          activeTab={selectedView}
          onChange={setSelectedView}
        />
      </DashboardHeader>

      {/* Sport Filter */}
      <div className="max-w-7xl mx-auto px-8 py-6">
        <div className="flex gap-3 flex-wrap">
          <button
            onClick={() => setSelectedSport("all")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedSport === "all"
                ? "bg-[#C8A882] text-white shadow-lg"
                : "bg-[#0D1421]/60 text-gray-400 hover:bg-[#0D1421]/80 hover:text-white border border-[#C8A882]/10"
            }`}
          >
            All Sports
          </button>
          {availableSports.map((sport) => (
            <button
              key={sport}
              onClick={() => setSelectedSport(sport)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                selectedSport === sport
                  ? "bg-[#C8A882] text-white shadow-lg"
                  : "bg-[#0D1421]/60 text-gray-400 hover:bg-[#0D1421]/80 hover:text-white border border-[#C8A882]/10"
              }`}
            >
              {sport}
            </button>
          ))}
        </div>
      </div>

      {/* Federation Metrics - MIGRATED TO SHARED COMPONENT */}
      <div className="max-w-7xl mx-auto px-8 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <MetricCard
            label="Total Athletes"
            value={coalitionMetrics?.total || 0}
            subtext={`${coalitionMetrics?.sportCount} sports`}
            icon={Users}
          />

          <MetricCard
            label="Active Coalition"
            value={coalitionMetrics?.active || 0}
            subtext={`${((coalitionMetrics?.active / coalitionMetrics?.total) * 100 || 0).toFixed(1)}% active`}
            icon={Shield}
          />

          <MetricCard
            label="Tier I Elite"
            value={coalitionMetrics?.tierBreakdown["Tier I"] || 0}
            subtext="Premium athletes"
            icon={Award}
          />

          <MetricCard
            label="Tier II Growth"
            value={coalitionMetrics?.tierBreakdown["Tier II"] || 0}
            subtext="Emerging talent"
            icon={TrendingUp}
          />

          <MetricCard
            label="Biometric Consent"
            value={`${coalitionMetrics?.consentRate || 0}%`}
            subtext="Data participation"
            icon={Target}
          />
        </div>

        {/* Content Views - Panels MIGRATED TO SHARED COMPONENT */}
        {selectedView === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <GlassPanel title="Sport Distribution">
              <div className="p-6 space-y-3">
                {coalitionMetrics?.sports.map((sport) => {
                  const count = athletes.filter(
                    (a) => a.sport === sport,
                  ).length;
                  const percentage = (
                    (count / coalitionMetrics.total) *
                    100
                  ).toFixed(1);
                  return (
                    <div key={sport}>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="font-medium text-gray-300">
                          {sport}
                        </span>
                        <span className="text-gray-400">
                          {count} ({percentage}%)
                        </span>
                      </div>
                      <div className="w-full bg-[#1B3A57]/30 rounded-full h-2">
                        <div
                          className="h-2 rounded-full bg-[#C8A882]"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </GlassPanel>

            <GlassPanel title="NIL Tier Distribution">
              <div className="p-6 space-y-4">
                <div className="p-4 rounded-lg bg-[#1B3A57] border border-[#C8A882]/30">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-bold text-lg text-white">
                        Tier I - Elite
                      </div>
                      <div className="text-sm text-[#C8A882]">
                        Premium biometric finance
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-[#C8A882]">
                      {coalitionMetrics?.tierBreakdown["Tier I"] || 0}
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-[#1B3A57]/40 border border-blue-400/30 backdrop-blur-sm">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-bold text-lg text-white">
                        Tier II - Growth
                      </div>
                      <div className="text-sm text-blue-400">
                        Emerging athlete assets
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-blue-400">
                      {coalitionMetrics?.tierBreakdown["Tier II"] || 0}
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-[#0D1421]/60 border border-gray-400/20 backdrop-blur-sm">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-bold text-lg text-white">
                        Tier III - Development
                      </div>
                      <div className="text-sm text-gray-400">
                        Pipeline talent
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-gray-400">
                      {coalitionMetrics?.tierBreakdown["Tier III"] || 0}
                    </div>
                  </div>
                </div>
              </div>
            </GlassPanel>
          </div>
        )}

        {/* rest of views remain similar */}
      </div>
    </div>
  );
}
