"use client";

import { useState, useEffect } from "react";
import {
  Play,
  Cast,
  Monitor,
  Tv,
  Radio,
  Zap,
  AlertCircle,
  CheckCircle,
} from "lucide-react";
import { BRAND_CLASSES } from "@/utils/brandColors";

export default function BroadcastControlDashboard() {
  const [athletes, setAthletes] = useState([]);
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [broadcastPartner, setBroadcastPartner] = useState("ESPN");
  const [packageType, setPackageType] = useState("coach_view");
  const [displayType, setDisplayType] = useState("jumbotron");
  const [loading, setLoading] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const [pushStatus, setPushStatus] = useState(null);

  // Fetch athletes on mount
  useEffect(() => {
    fetchAthletes();
  }, []);

  const fetchAthletes = async () => {
    try {
      const response = await fetch("/api/athletes/list", { method: "POST" });
      const data = await response.json();
      if (data.success) {
        setAthletes(data.athletes);
        if (data.athletes.length > 0) {
          setSelectedAthlete(data.athletes[0].id);
        }
      }
    } catch (error) {
      console.error("Failed to fetch athletes:", error);
    }
  };

  const generatePreview = async () => {
    if (!selectedAthlete) return;

    setLoading(true);
    try {
      const response = await fetch("/api/broadcast/ar-package", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete,
          broadcast_partner: broadcastPartner,
          league: "NBA", // Could be dynamic
          package_type: packageType,
          output_format: "4K",
          lighting_conditions: "bright_arena",
        }),
      });

      const data = await response.json();
      if (data.success) {
        setPreviewData(data);
      }
    } catch (error) {
      console.error("Failed to generate preview:", error);
    } finally {
      setLoading(false);
    }
  };

  const pushToStadium = async () => {
    if (!selectedAthlete) return;

    setLoading(true);
    setPushStatus("pushing");

    try {
      const response = await fetch("/api/stadium/display", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete,
          display_type: displayType,
          display_resolution: "3840x2160",
          lighting_conditions: "bright_arena",
          content_type:
            packageType === "coach_view"
              ? "performance_snapshot"
              : "sponsor_activation",
          duration_seconds: 10,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setPushStatus("success");
        setTimeout(() => setPushStatus(null), 3000);
      } else {
        setPushStatus("error");
        setTimeout(() => setPushStatus(null), 3000);
      }
    } catch (error) {
      console.error("Failed to push to stadium:", error);
      setPushStatus("error");
      setTimeout(() => setPushStatus(null), 3000);
    } finally {
      setLoading(false);
    }
  };

  const selectedAthleteData = athletes.find((a) => a.id === selectedAthlete);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#152E45] to-[#1B3A57]">
      {/* Header */}
      <div className={BRAND_CLASSES.bgHeader}>
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <Cast className="text-[#C8A882]" size={36} />
                Broadcast Control Center
              </h1>
              <p className="text-[#C8A882] mt-1">
                Multi-platform AR overlay command & control
              </p>
            </div>

            <div className="flex items-center gap-3">
              {pushStatus === "success" && (
                <div className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-lg">
                  <CheckCircle size={20} />
                  <span className="font-semibold">Pushed to Stadium</span>
                </div>
              )}
              {pushStatus === "error" && (
                <div className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg">
                  <AlertCircle size={20} />
                  <span className="font-semibold">Push Failed</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* LEFT PANEL - Configuration */}
          <div className="lg:col-span-1">
            <div className={BRAND_CLASSES.bgCard}>
              <h2 className="text-xl font-bold text-[#1B3A57] mb-4">
                Configuration
              </h2>

              {/* Athlete Selection */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1B3A57] mb-2">
                  Select Athlete
                </label>
                <select
                  value={selectedAthlete || ""}
                  onChange={(e) => setSelectedAthlete(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-[#E5E7EB] focus:border-[#C8A882] focus:ring-2 focus:ring-[#C8A882] focus:ring-opacity-20 outline-none"
                >
                  {athletes.map((athlete) => (
                    <option key={athlete.id} value={athlete.id}>
                      {athlete.first_name} {athlete.last_name} -{" "}
                      {athlete.position}
                    </option>
                  ))}
                </select>
              </div>

              {/* Broadcast Partner */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1B3A57] mb-2">
                  Broadcast Partner
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {["ESPN", "TNT", "Amazon Prime", "Apple Sports"].map(
                    (partner) => (
                      <button
                        key={partner}
                        onClick={() => setBroadcastPartner(partner)}
                        className={`px-3 py-2 rounded-lg font-semibold text-sm transition-all ${
                          broadcastPartner === partner
                            ? "bg-[#1B3A57] text-white"
                            : "bg-[#F0F4F8] text-[#1B3A57] hover:bg-[#E5E7EB]"
                        }`}
                      >
                        {partner}
                      </button>
                    ),
                  )}
                </div>
              </div>

              {/* Package Type */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1B3A57] mb-2">
                  Package Type
                </label>
                <select
                  value={packageType}
                  onChange={(e) => setPackageType(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-[#E5E7EB] focus:border-[#C8A882] focus:ring-2 focus:ring-[#C8A882] focus:ring-opacity-20 outline-none"
                >
                  <option value="coach_view">Coach Comparison View</option>
                  <option value="medical_alerts">Medical Staff Alerts</option>
                  <option value="rotation_optimizer">Rotation Optimizer</option>
                  <option value="performance_trends">Performance Trends</option>
                  <option value="sponsor_activation">Sponsor Activation</option>
                </select>
              </div>

              {/* Display Type (for stadium) */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1B3A57] mb-2">
                  Stadium Display
                </label>
                <select
                  value={displayType}
                  onChange={(e) => setDisplayType(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-[#E5E7EB] focus:border-[#C8A882] focus:ring-2 focus:ring-[#C8A882] focus:ring-opacity-20 outline-none"
                >
                  <option value="jumbotron">Jumbotron</option>
                  <option value="led_ribbon">LED Ribbon</option>
                  <option value="courtside_display">Courtside Display</option>
                  <option value="tunnel_display">Tunnel Display</option>
                </select>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <button
                  onClick={generatePreview}
                  disabled={loading}
                  className={`${BRAND_CLASSES.btnPrimary} w-full flex items-center justify-center gap-2`}
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      <span>Loading...</span>
                    </>
                  ) : (
                    <>
                      <Play size={20} />
                      <span>Generate Preview</span>
                    </>
                  )}
                </button>

                <button
                  onClick={pushToStadium}
                  disabled={loading || !previewData}
                  className={`${BRAND_CLASSES.btnSecondary} w-full flex items-center justify-center gap-2`}
                >
                  <Monitor size={20} />
                  <span>Push to Stadium</span>
                </button>
              </div>
            </div>

            {/* Quick Stats */}
            {selectedAthleteData && (
              <div className={`${BRAND_CLASSES.bgCard} mt-6`}>
                <h3 className="text-lg font-bold text-[#1B3A57] mb-3">
                  Athlete Info
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-[#6B7280]">Name:</span>
                    <span className="text-sm font-semibold text-[#1B3A57]">
                      {selectedAthleteData.first_name}{" "}
                      {selectedAthleteData.last_name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#6B7280]">Position:</span>
                    <span className="text-sm font-semibold text-[#1B3A57]">
                      {selectedAthleteData.position}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#6B7280]">Team:</span>
                    <span className="text-sm font-semibold text-[#1B3A57]">
                      {selectedAthleteData.team}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#6B7280]">NIL Tier:</span>
                    <span className={BRAND_CLASSES.badgeGold}>
                      {selectedAthleteData.nil_tier}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT PANEL - Preview */}
          <div className="lg:col-span-2">
            <div className={BRAND_CLASSES.bgCard}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-[#1B3A57]">
                  Live Preview
                </h2>
                {previewData && (
                  <span className="flex items-center gap-2 text-sm font-semibold text-green-600">
                    <Radio className="animate-pulse" size={16} />
                    Ready to Broadcast
                  </span>
                )}
              </div>

              {!previewData ? (
                <div className="bg-gradient-to-br from-[#1B3A57] to-[#2A4A68] rounded-xl p-12 flex flex-col items-center justify-center min-h-[500px]">
                  <Tv className="text-[#C8A882] opacity-40" size={120} />
                  <p className="text-white text-lg mt-4 opacity-60">
                    Configure settings and generate preview
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Preview Viewport */}
                  <div className="bg-black rounded-xl p-6 aspect-video flex items-center justify-center relative overflow-hidden">
                    {/* Simulated AR Overlay */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div
                        className="text-white text-6xl font-black mb-4"
                        style={{ textShadow: "0 0 20px rgba(0,0,0,0.8)" }}
                      >
                        {previewData.athlete_name}
                      </div>
                      <div
                        className="text-[#C8A882] text-3xl font-bold mb-8"
                        style={{ textShadow: "0 0 15px rgba(0,0,0,0.8)" }}
                      >
                        {broadcastPartner} •{" "}
                        {packageType.replace(/_/g, " ").toUpperCase()}
                      </div>

                      <div className="flex gap-8">
                        <div className="text-center">
                          <div className="text-green-400 text-5xl font-black mb-2">
                            92
                          </div>
                          <div className="text-white text-xl font-semibold">
                            READY
                          </div>
                        </div>
                        <div className="text-center">
                          <div className="text-yellow-400 text-5xl font-black mb-2">
                            88
                          </div>
                          <div className="text-white text-xl font-semibold">
                            POWER
                          </div>
                        </div>
                        <div className="text-center">
                          <div className="text-orange-400 text-5xl font-black mb-2">
                            34
                          </div>
                          <div className="text-white text-xl font-semibold">
                            FATIGUE
                          </div>
                        </div>
                      </div>

                      {packageType === "sponsor_activation" && (
                        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-[#FFD700] text-black px-8 py-4 rounded-full font-black text-2xl animate-pulse">
                          ⚡ PEAK PERFORMANCE ⚡
                        </div>
                      )}
                    </div>

                    {/* Broadcast Partner Branding */}
                    <div className="absolute top-4 right-4 bg-black/80 text-white px-4 py-2 rounded-lg font-bold">
                      {broadcastPartner}
                    </div>
                  </div>

                  {/* Technical Details */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-[#F0F4F8] rounded-lg p-4">
                      <p className="text-xs text-[#6B7280] mb-1">Format</p>
                      <p className="text-lg font-bold text-[#1B3A57]">
                        {previewData.ar_package?.broadcast_format?.resolution ||
                          "4K"}
                      </p>
                    </div>
                    <div className="bg-[#F0F4F8] rounded-lg p-4">
                      <p className="text-xs text-[#6B7280] mb-1">Lighting</p>
                      <p className="text-lg font-bold text-[#1B3A57]">
                        {previewData.lighting_conditions}
                      </p>
                    </div>
                    <div className="bg-[#F0F4F8] rounded-lg p-4">
                      <p className="text-xs text-[#6B7280] mb-1">Duration</p>
                      <p className="text-lg font-bold text-[#1B3A57]">8 sec</p>
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="bg-[#F0F4F8] rounded-lg p-4">
                    <h3 className="text-sm font-bold text-[#1B3A57] mb-3">
                      Package Metadata
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-[#6B7280]">Generated:</p>
                        <p className="font-semibold text-[#1B3A57]">
                          {new Date(
                            previewData.metadata.generated_at,
                          ).toLocaleTimeString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-[#6B7280]">Biometric Readings:</p>
                        <p className="font-semibold text-[#1B3A57]">
                          {previewData.metadata.readings_count}
                        </p>
                      </div>
                      <div>
                        <p className="text-[#6B7280]">NIL Data:</p>
                        <p className="font-semibold text-[#1B3A57]">
                          {previewData.metadata.has_valuation
                            ? "Available"
                            : "N/A"}
                        </p>
                      </div>
                      <div>
                        <p className="text-[#6B7280]">Mispricing Events:</p>
                        <p className="font-semibold text-[#1B3A57]">
                          {previewData.metadata.mispricing_events}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
