"use client";

import { useState, useEffect } from "react";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Target,
  Activity,
  BarChart3,
  AlertCircle,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
} from "lucide-react";
import LoadingScreen from "@/components/shared/LoadingScreen";
import ErrorScreen from "@/components/shared/ErrorScreen";
import DashboardHeader from "@/components/shared/DashboardHeader";
import PillTabs from "@/components/shared/PillTabs";
import MetricCard from "@/components/shared/MetricCard";
import GlassPanel from "@/components/shared/GlassPanel";

export default function InvestorDashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [portfolio, setPortfolio] = useState(null);
  const [nilValuations, setNilValuations] = useState([]);
  const [mispricingEvents, setMispricingEvents] = useState([]);
  const [tradingPositions, setTradingPositions] = useState([]);
  const [selectedView, setSelectedView] = useState("overview");

  useEffect(() => {
    loadInvestorData();
  }, []);

  async function loadInvestorData() {
    try {
      setLoading(true);
      setError(null);

      const [portfolioRes, valuationsRes, mispricingRes, positionsRes] =
        await Promise.all([
          fetch("/api/trading/portfolio/manage", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "summary" }),
          }),
          fetch("/api/athletes/list?limit=20"),
          fetch("/api/trading/detect-mispricing", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
          }),
          fetch("/api/trading/portfolio/manage", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "list_positions" }),
          }),
        ]);

      const portfolioData = await portfolioRes.json();
      const valuationsData = await valuationsRes.json();
      const mispricingData = await mispricingRes.json();
      const positionsData = await positionsRes.json();

      setPortfolio(
        portfolioData.portfolio || {
          totalValue: 0,
          totalPnL: 0,
          activePositions: 0,
          riskScore: 0,
        },
      );

      setNilValuations(valuationsData.athletes || []);
      setMispricingEvents(mispricingData.events || []);
      setTradingPositions(positionsData.positions || []);
    } catch (err) {
      console.error("Failed to load investor data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <LoadingScreen message="Loading Investor Intelligence..." />;
  }

  if (error) {
    return (
      <ErrorScreen
        title="Error Loading Investor Data"
        message={error}
        onRetry={loadInvestorData}
      />
    );
  }

  const tabs = [
    { id: "overview", label: "Portfolio", icon: BarChart3 },
    { id: "valuations", label: "Valuations", icon: DollarSign },
    { id: "trading", label: "Trading", icon: Target },
    { id: "positions", label: "Positions", icon: Activity },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D1421] via-[#1B3A57] to-[#0D1421]">
      {/* Header - MIGRATED TO SHARED COMPONENT */}
      <DashboardHeader
        icon={TrendingUp}
        title="Investor Dashboard"
        description="NIL Valuation 2.0 • Portfolio Management • Trading Intelligence"
        onRefresh={loadInvestorData}
        loading={loading}
      >
        {/* Tab Navigation - MIGRATED TO SHARED COMPONENT */}
        <PillTabs
          tabs={tabs}
          activeTab={selectedView}
          onChange={setSelectedView}
        />
      </DashboardHeader>

      {/* Portfolio Summary Cards - MIGRATED TO SHARED COMPONENT */}
      <div className="max-w-7xl mx-auto px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <MetricCard
            label="Total Value"
            value={`$${(portfolio.totalValue || 0).toLocaleString()}`}
            icon={DollarSign}
          >
            <div
              className={`flex items-center gap-1 text-sm font-semibold ${
                portfolio.totalPnL >= 0 ? "text-green-400" : "text-red-400"
              }`}
            >
              {portfolio.totalPnL >= 0 ? (
                <ArrowUpRight size={16} />
              ) : (
                <ArrowDownRight size={16} />
              )}
              ${Math.abs(portfolio.totalPnL || 0).toLocaleString()} (
              {portfolio.totalPnL >= 0 ? "+" : ""}
              {((portfolio.totalPnL / portfolio.totalValue) * 100 || 0).toFixed(
                2,
              )}
              %)
            </div>
          </MetricCard>

          <MetricCard
            label="Active Positions"
            value={portfolio.activePositions || 0}
            subtext={`${tradingPositions.filter((p) => p.status === "open").length} open trades`}
            icon={Activity}
          />

          <MetricCard
            label="Mispricing Opportunities"
            value={mispricingEvents.filter((e) => e.status === "active").length}
            subtext="Active windows detected"
            icon={AlertCircle}
          />

          <MetricCard
            label="Risk Score"
            value={`${portfolio.riskScore || 0}/100`}
            subtext={`${portfolio.riskScore > 70 ? "High" : portfolio.riskScore > 40 ? "Moderate" : "Low"} volatility`}
            icon={Target}
          />
        </div>

        {/* Content Views - Panels MIGRATED TO SHARED COMPONENT */}
        {selectedView === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <GlassPanel title="Top NIL Opportunities" icon={Eye}>
              <div className="p-6 space-y-3">
                {nilValuations.slice(0, 5).map((athlete, idx) => (
                  <div
                    key={athlete.id}
                    className="flex items-center justify-between p-4 bg-[#1B3A57]/40 hover:bg-[#1B3A57]/60 border border-[#C8A882]/10 rounded-lg transition-all cursor-pointer"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold bg-[#C8A882]">
                        {idx + 1}
                      </div>
                      <div>
                        <div className="font-semibold text-white">
                          {athlete.first_name} {athlete.last_name}
                        </div>
                        <div className="text-sm text-gray-400">
                          {athlete.sport} • {athlete.team}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-[#C8A882]">
                        {athlete.nil_tier}
                      </div>
                      <div className="text-sm text-gray-400">
                        {athlete.coalition_status}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </GlassPanel>

            <GlassPanel title="Active Mispricing Windows" icon={AlertCircle}>
              <div className="p-6 space-y-3">
                {mispricingEvents.slice(0, 5).map((event) => (
                  <div
                    key={event.id}
                    className="rounded bg-[#1B3A57]/40 hover:bg-[#1B3A57]/60 border transition-all cursor-pointer p-4"
                    style={{
                      borderColor:
                        event.direction === "long" ? "#10b981" : "#ef4444",
                    }}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-semibold text-white">
                        {event.direction === "long" ? "↑ Long" : "↓ Short"}{" "}
                        Signal
                      </div>
                      <div className="text-sm px-2 py-1 rounded bg-[#C8A882] text-white font-medium">
                        {(event.confidence * 100).toFixed(0)}% confidence
                      </div>
                    </div>
                    <div className="text-sm text-gray-400">
                      Gap: ${event.gap?.toFixed(2)} • TTL:{" "}
                      {Math.floor((event.ttl || 0) / 60)}m
                    </div>
                  </div>
                ))}
              </div>
            </GlassPanel>
          </div>
        )}

        {selectedView === "valuations" && (
          <div className="bg-[#0D1421]/60 backdrop-blur-sm rounded-xl border border-[#C8A882]/20 overflow-hidden">
            <div className="bg-gradient-to-r from-[#1B3A57] to-[#0D1421] border-b border-[#C8A882]/20 p-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <DollarSign className="text-[#C8A882]" size={20} />
                NIL Valuation Matrix
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-[#C8A882]">
                    <th className="text-left p-3 font-semibold text-white">
                      Athlete
                    </th>
                    <th className="text-left p-3 font-semibold text-white">
                      Sport
                    </th>
                    <th className="text-left p-3 font-semibold text-white">
                      Team
                    </th>
                    <th className="text-left p-3 font-semibold text-white">
                      NIL Tier
                    </th>
                    <th className="text-left p-3 font-semibold text-white">
                      Coalition
                    </th>
                    <th className="text-left p-3 font-semibold text-white">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {nilValuations.map((athlete) => (
                    <tr
                      key={athlete.id}
                      className="border-b border-[#C8A882]/10 hover:bg-[#1B3A57]/40 transition-all"
                    >
                      <td className="p-3 font-medium text-white">
                        {athlete.first_name} {athlete.last_name}
                      </td>
                      <td className="p-3 text-gray-300">{athlete.sport}</td>
                      <td className="p-3 text-gray-300">{athlete.team}</td>
                      <td className="p-3">
                        <span className="px-3 py-1 rounded-full text-sm font-medium bg-[#C8A882] text-[#0D1421]">
                          {athlete.nil_tier}
                        </span>
                      </td>
                      <td className="p-3 text-gray-300">
                        {athlete.federation || "N/A"}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-1 rounded text-sm ${
                            athlete.coalition_status === "Active"
                              ? "bg-green-500/20 text-green-400"
                              : "bg-gray-500/20 text-gray-400"
                          }`}
                        >
                          {athlete.coalition_status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {selectedView === "trading" && (
          <div className="space-y-4">
            {mispricingEvents.map((event) => (
              <div
                key={event.id}
                className="p-6 rounded-lg border-2 bg-[#0D1421]/60 backdrop-blur-sm transition-all hover:bg-[#0D1421]/80"
                style={{
                  borderColor:
                    event.direction === "long" ? "#10b981" : "#ef4444",
                }}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="text-lg font-bold text-white">
                      {event.direction === "long"
                        ? "↑ Long Signal"
                        : "↓ Short Signal"}
                    </div>
                    <div className="text-sm text-gray-400 mt-1">
                      Event Type: {event.event_type} • Detected:{" "}
                      {new Date(event.detected_at).toLocaleString()}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-[#C8A882]">
                      ${event.gap?.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-400">Gap Opportunity</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-gray-400">Confidence</div>
                    <div className="text-lg font-bold text-[#C8A882]">
                      {(event.confidence * 100).toFixed(1)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Time Remaining</div>
                    <div className="text-lg font-bold text-white">
                      {Math.floor((event.ttl || 0) / 60)}min
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Status</div>
                    <div className="text-lg font-bold capitalize text-white">
                      {event.status}
                    </div>
                  </div>
                </div>

                <button
                  className="w-full py-3 rounded-lg text-white font-bold transition-colors hover:opacity-90"
                  style={{
                    backgroundColor:
                      event.direction === "long" ? "#10b981" : "#ef4444",
                  }}
                >
                  Execute {event.direction === "long" ? "Long" : "Short"}{" "}
                  Position
                </button>
              </div>
            ))}

            {mispricingEvents.length === 0 && (
              <div className="text-center py-12 text-gray-400">
                No active trading signals at this time
              </div>
            )}
          </div>
        )}

        {selectedView === "positions" && (
          <div className="space-y-4">
            {tradingPositions
              .filter((p) => p.status === "open")
              .map((position) => (
                <div
                  key={position.id}
                  className="p-6 bg-[#0D1421]/60 backdrop-blur-sm border border-[#C8A882]/20 rounded-lg hover:bg-[#1B3A57]/40 transition-all"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <div className="text-lg font-bold capitalize text-white">
                        {position.position_type} Position
                      </div>
                      <div className="text-sm text-gray-400 mt-1">
                        Strategy: {position.strategy} • Opened:{" "}
                        {new Date(position.opened_at).toLocaleString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`text-2xl font-bold ${
                          position.pnl >= 0 ? "text-green-400" : "text-red-400"
                        }`}
                      >
                        ${position.pnl?.toFixed(2) || "0.00"}
                      </div>
                      <div className="text-sm text-gray-400">P&L</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4">
                    <div>
                      <div className="text-sm text-gray-400">Entry</div>
                      <div className="font-semibold text-white">
                        ${position.entry_price?.toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Size</div>
                      <div className="font-semibold text-white">
                        ${position.size?.toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Stop Loss</div>
                      <div className="font-semibold text-white">
                        ${position.stop_loss?.toFixed(2) || "None"}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Take Profit</div>
                      <div className="font-semibold text-white">
                        ${position.take_profit?.toFixed(2) || "None"}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

            {tradingPositions.filter((p) => p.status === "open").length ===
              0 && (
              <div className="text-center py-12 text-gray-400">
                No active positions
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
