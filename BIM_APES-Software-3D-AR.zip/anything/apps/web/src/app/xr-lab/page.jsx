"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import XRCombatVisualization from "@/components/XRCombatVisualization";

export default function XRLabPage() {
  const [selectedSport, setSelectedSport] = useState("wrestling");
  const [selectedView, setSelectedView] = useState("live");
  const [selectedAthleteId, setSelectedAthleteId] = useState(null);

  // Fetch athletes data
  const { data: athletesData, isLoading } = useQuery({
    queryKey: ["xr-athletes", selectedSport],
    queryFn: async () => {
      const response = await fetch(
        `/api/sport-specific/${selectedSport}/live-metrics`,
      );
      if (!response.ok) {
        // Fallback to sample data if API not ready
        return getSampleAthletes(selectedSport);
      }
      const data = await response.json();
      return data.athletes || getSampleAthletes(selectedSport);
    },
    refetchInterval: 5000, // Refresh every 5 seconds for live view
  });

  function getSampleAthletes(sport) {
    if (sport === "boxing") {
      return [
        {
          id: "box1",
          name: "Mike Rodriguez",
          ssi: 82,
          cis: 76,
          arc: 79,
          stress: 0.6,
          fatigue: 0.4,
          nilMomentum: 0.7,
          corner: "red",
          weightClass: "Welterweight",
          record: "24-3-0",
        },
        {
          id: "box2",
          name: "James Chen",
          ssi: 76,
          cis: 73,
          arc: 75,
          stress: 0.7,
          fatigue: 0.5,
          nilMomentum: 0.6,
          corner: "blue",
          weightClass: "Welterweight",
          record: "21-5-1",
        },
      ];
    } else if (sport === "mma") {
      return [
        {
          id: "mma1",
          name: "Alex Santos",
          ssi: 88,
          cis: 84,
          arc: 86,
          stress: 0.5,
          fatigue: 0.3,
          nilMomentum: 0.8,
          weightClass: "Lightweight",
          record: "18-2-0",
          fightingStyle: "BJJ/Striker",
        },
        {
          id: "mma2",
          name: "David Thompson",
          ssi: 79,
          cis: 77,
          arc: 80,
          stress: 0.6,
          fatigue: 0.5,
          nilMomentum: 0.65,
          weightClass: "Lightweight",
          record: "15-4-0",
          fightingStyle: "Wrestler/GnP",
        },
      ];
    } else {
      // wrestling
      return [
        {
          id: "wre1",
          name: "Carter Davis",
          ssi: 85,
          cis: 81,
          arc: 83,
          stress: 0.4,
          fatigue: 0.3,
          nilMomentum: 0.75,
          weightClass: "157 lbs",
          record: "32-5",
        },
        {
          id: "wre2",
          name: "Marcus Johnson",
          ssi: 78,
          cis: 75,
          arc: 77,
          stress: 0.6,
          fatigue: 0.5,
          nilMomentum: 0.6,
          weightClass: "165 lbs",
          record: "28-8",
        },
        {
          id: "wre3",
          name: "Ryan Martinez",
          ssi: 80,
          cis: 78,
          arc: 79,
          stress: 0.5,
          fatigue: 0.4,
          nilMomentum: 0.7,
          weightClass: "174 lbs",
          record: "30-6",
        },
        {
          id: "wre4",
          name: "Kevin Brown",
          ssi: 72,
          cis: 70,
          arc: 71,
          stress: 0.7,
          fatigue: 0.6,
          nilMomentum: 0.55,
          weightClass: "184 lbs",
          record: "24-11",
        },
      ];
    }
  }

  const selectedAthlete = selectedAthleteId
    ? athletesData?.find((a) => a.id === selectedAthleteId)
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1B3A57] via-black to-[#1B3A57]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1B3A57] to-[#152E45] border-b border-[#C8A882]/20">
        <div className="max-w-screen-2xl mx-auto px-6 py-4">
          <h1 className="text-3xl font-bold text-white mb-2">
            BIM-APES XR PERFORMANCE LAB
          </h1>
          <p className="text-gray-300 text-sm">
            Real-time 3D visualization of combat sports performance intelligence
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="max-w-screen-2xl mx-auto px-6 py-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Sport selector */}
          <div className="bg-[#1B3A57]/50 backdrop-blur-sm rounded-lg p-4 border border-[#C8A882]/20">
            <label className="block text-sm font-semibold text-[#C8A882] mb-2">
              SPORT
            </label>
            <div className="flex gap-2">
              {["wrestling", "mma", "boxing"].map((sport) => (
                <button
                  key={sport}
                  onClick={() => setSelectedSport(sport)}
                  className={`flex-1 py-2 px-4 rounded-md font-semibold transition-all ${
                    selectedSport === sport
                      ? "bg-[#C8A882] text-[#1B3A57]"
                      : "bg-[#152E45] text-gray-300 hover:bg-[#2A4A68]"
                  }`}
                >
                  {sport.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* View selector */}
          <div className="bg-[#1B3A57]/50 backdrop-blur-sm rounded-lg p-4 border border-[#C8A882]/20">
            <label className="block text-sm font-semibold text-[#C8A882] mb-2">
              VIEW MODE
            </label>
            <div className="flex gap-2">
              {["live", "replay", "playbook"].map((view) => (
                <button
                  key={view}
                  onClick={() => setSelectedView(view)}
                  className={`flex-1 py-2 px-4 rounded-md font-semibold transition-all ${
                    selectedView === view
                      ? "bg-[#C8A882] text-[#1B3A57]"
                      : "bg-[#152E45] text-gray-300 hover:bg-[#2A4A68]"
                  }`}
                >
                  {view.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Status */}
          <div className="bg-[#1B3A57]/50 backdrop-blur-sm rounded-lg p-4 border border-[#C8A882]/20">
            <label className="block text-sm font-semibold text-[#C8A882] mb-2">
              STATUS
            </label>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-white font-semibold">
                {selectedView === "live" ? "LIVE" : selectedView.toUpperCase()}
              </span>
              <span className="text-gray-400 text-sm ml-auto">
                {athletesData?.length || 0} athletes
              </span>
            </div>
          </div>
        </div>

        {/* Main visualization */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 3D Visualization (2/3 width on large screens) */}
          <div className="lg:col-span-2">
            <div className="bg-black/40 backdrop-blur-sm rounded-lg border border-[#C8A882]/20 overflow-hidden">
              <div className="h-[600px]">
                <XRCombatVisualization
                  athleteData={athletesData || []}
                  sport={selectedSport}
                />
              </div>
            </div>
          </div>

          {/* Side panel */}
          <div className="space-y-4">
            {/* Athlete detail panel */}
            <div className="bg-[#1B3A57]/50 backdrop-blur-sm rounded-lg p-4 border border-[#C8A882]/20">
              <h3 className="text-lg font-bold text-[#C8A882] mb-4">
                ATHLETE DETAILS
              </h3>

              {selectedAthlete ? (
                <div className="space-y-3">
                  <div>
                    <h4 className="text-white font-bold text-lg">
                      {selectedAthlete.name}
                    </h4>
                    <p className="text-gray-400 text-sm">
                      {selectedAthlete.weightClass} • {selectedAthlete.record}
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-[#152E45] rounded p-2 text-center">
                      <div className="text-[#C8A882] text-xs font-semibold">
                        SSI
                      </div>
                      <div className="text-white text-xl font-bold">
                        {selectedAthlete.ssi}
                      </div>
                    </div>
                    <div className="bg-[#152E45] rounded p-2 text-center">
                      <div className="text-[#C8A882] text-xs font-semibold">
                        CIS
                      </div>
                      <div className="text-white text-xl font-bold">
                        {selectedAthlete.cis}
                      </div>
                    </div>
                    <div className="bg-[#152E45] rounded p-2 text-center">
                      <div className="text-[#C8A882] text-xs font-semibold">
                        ARC
                      </div>
                      <div className="text-white text-xl font-bold">
                        {selectedAthlete.arc}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">Stress Level</span>
                        <span className="text-white">
                          {(selectedAthlete.stress * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="w-full bg-[#152E45] rounded-full h-2">
                        <div
                          className="bg-orange-500 h-2 rounded-full transition-all"
                          style={{ width: `${selectedAthlete.stress * 100}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">Fatigue</span>
                        <span className="text-white">
                          {(selectedAthlete.fatigue * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="w-full bg-[#152E45] rounded-full h-2">
                        <div
                          className="bg-red-500 h-2 rounded-full transition-all"
                          style={{ width: `${selectedAthlete.fatigue * 100}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">NIL Momentum</span>
                        <span className="text-white">
                          {(selectedAthlete.nilMomentum * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="w-full bg-[#152E45] rounded-full h-2">
                        <div
                          className="bg-[#C8A882] h-2 rounded-full transition-all"
                          style={{
                            width: `${selectedAthlete.nilMomentum * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <p>Click an athlete capsule to view details</p>
                </div>
              )}
            </div>

            {/* Quick stats */}
            <div className="bg-[#1B3A57]/50 backdrop-blur-sm rounded-lg p-4 border border-[#C8A882]/20">
              <h3 className="text-sm font-bold text-[#C8A882] mb-3">
                PERFORMANCE METRICS
              </h3>
              <div className="space-y-2 text-sm">
                {athletesData && athletesData.length > 0 ? (
                  <>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Avg SSI:</span>
                      <span className="text-white font-semibold">
                        {(
                          athletesData.reduce(
                            (sum, a) => sum + (a.ssi || 0),
                            0,
                          ) / athletesData.length
                        ).toFixed(1)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Peak SSI:</span>
                      <span className="text-white font-semibold">
                        {Math.max(...athletesData.map((a) => a.ssi || 0))}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">High Risk:</span>
                      <span className="text-white font-semibold">
                        {
                          athletesData.filter((a) => (a.fatigue || 0) > 0.6)
                            .length
                        }
                      </span>
                    </div>
                  </>
                ) : (
                  <p className="text-gray-400 text-center py-4">
                    Loading metrics...
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
