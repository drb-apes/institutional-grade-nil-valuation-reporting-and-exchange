"use client";

import { useState } from "react";
import { BRAND_COLORS } from "@/utils/brandColors";

export default function TestHarnessPage() {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);

  async function runTest(name, endpoint, body = {}) {
    setLoading(true);
    try {
      const startTime = Date.now();
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      const duration = Date.now() - startTime;

      setResults((prev) => [
        ...prev,
        {
          name,
          endpoint,
          success: response.ok,
          duration,
          data,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);

      return data;
    } catch (error) {
      setResults((prev) => [
        ...prev,
        {
          name,
          endpoint,
          success: false,
          error: error.message,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function seedDatabase() {
    await runTest("Seed 50 Athletes", "/api/database/seed-athletes", {
      count: 50,
    });
  }

  async function seedBiometrics() {
    await runTest("Seed Biometrics (48h)", "/api/database/seed-biometrics", {
      hours: 48,
      frequency: 4,
    });
  }

  async function testMethod19() {
    const athletesRes = await fetch("/api/athletes/list?limit=1");
    const athletesData = await athletesRes.json();
    const athleteId = athletesData.athletes?.[0]?.id;

    if (athleteId) {
      await runTest("Method 19: Coaching Overlay", "/api/ar/coaching/overlay", {
        athlete_id: athleteId,
      });
    } else {
      alert("No athletes found. Seed database first.");
    }
  }

  async function testMethod20() {
    const athletesRes = await fetch("/api/athletes/list?limit=1");
    const athletesData = await athletesRes.json();
    const athleteId = athletesData.athletes?.[0]?.id;

    if (athleteId) {
      await runTest(
        "Method 20: Tempo-Rhythm",
        "/api/ar/coaching/tempo-rhythm",
        { athlete_id: athleteId },
      );
    } else {
      alert("No athletes found. Seed database first.");
    }
  }

  async function testARMedicalMethods() {
    const athletesRes = await fetch("/api/athletes/list?limit=1");
    const athletesData = await athletesRes.json();
    const athleteId = athletesData.athletes?.[0]?.id;

    if (!athleteId) {
      alert("No athletes found. Seed database first.");
      return;
    }

    await runTest(
      "Method 21: Collapse Prediction",
      "/api/ar/medical/collapse-prediction",
      { athlete_id: athleteId },
    );
    await runTest(
      "Method 22: Impact Overload",
      "/api/ar/medical/impact-overload",
      { athlete_id: athleteId },
    );
    await runTest(
      "Method 23: Joint Divergence",
      "/api/ar/medical/joint-divergence",
      { athlete_id: athleteId },
    );
    await runTest(
      "Method 24: Recovery Envelope",
      "/api/ar/medical/recovery-envelope",
      { athlete_id: athleteId },
    );
  }

  async function runFullTest() {
    setResults([]);

    // Step 1: Seed database
    const athleteResult = await runTest(
      "Seed 50 Athletes",
      "/api/database/seed-athletes",
      { count: 50 },
    );

    if (!athleteResult?.success) {
      alert("Failed to seed athletes. Check console for errors.");
      return;
    }

    // Step 2: Seed biometrics
    await runTest("Seed Biometrics (48h)", "/api/database/seed-biometrics", {
      hours: 48,
      frequency: 4,
    });

    // Step 3: Get first athlete ID
    const athletesRes = await fetch("/api/athletes/list?limit=1");
    const athletesData = await athletesRes.json();
    const athleteId = athletesData.athletes?.[0]?.id;

    if (!athleteId) {
      alert("No athletes available after seeding.");
      return;
    }

    // Step 4: Test all methods
    await runTest("Method 19: Coaching Overlay", "/api/ar/coaching/overlay", {
      athlete_id: athleteId,
    });
    await runTest("Method 20: Tempo-Rhythm", "/api/ar/coaching/tempo-rhythm", {
      athlete_id: athleteId,
    });
    await runTest(
      "Method 21: Collapse Prediction",
      "/api/ar/medical/collapse-prediction",
      { athlete_id: athleteId },
    );
    await runTest(
      "Method 22: Impact Overload",
      "/api/ar/medical/impact-overload",
      { athlete_id: athleteId },
    );
    await runTest(
      "Method 23: Joint Divergence",
      "/api/ar/medical/joint-divergence",
      { athlete_id: athleteId },
    );
    await runTest(
      "Method 24: Recovery Envelope",
      "/api/ar/medical/recovery-envelope",
      { athlete_id: athleteId },
    );

    alert("✅ Full test suite complete! Check results below.");
  }

  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: BRAND_COLORS.navy.dark }}
    >
      {/* Header */}
      <div
        style={{ backgroundColor: BRAND_COLORS.navy.main }}
        className="border-b border-gray-700"
      >
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-white mb-2">
            BIM-APES Test Harness
          </h1>
          <p className="text-gray-300">
            Database Seeding • Method Validation • End-to-End Testing
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Quick Actions */}
        <div className="bg-white rounded-lg p-6 shadow-lg mb-8">
          <h3
            className="text-xl font-bold mb-4"
            style={{ color: BRAND_COLORS.navy.main }}
          >
            Quick Actions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={runFullTest}
              disabled={loading}
              className="px-6 py-4 rounded-lg text-white font-bold transition-colors disabled:opacity-50"
              style={{ backgroundColor: BRAND_COLORS.gold.main }}
            >
              🚀 Run Full Test Suite
            </button>

            <button
              onClick={seedDatabase}
              disabled={loading}
              className="px-6 py-4 rounded-lg text-white font-bold transition-colors disabled:opacity-50"
              style={{ backgroundColor: BRAND_COLORS.navy.main }}
            >
              1️⃣ Seed Athletes (50)
            </button>

            <button
              onClick={seedBiometrics}
              disabled={loading}
              className="px-6 py-4 rounded-lg text-white font-bold transition-colors disabled:opacity-50"
              style={{ backgroundColor: BRAND_COLORS.navy.main }}
            >
              2️⃣ Seed Biometrics (48h)
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <button
              onClick={testMethod19}
              disabled={loading}
              className="px-6 py-3 rounded-lg bg-blue-600 text-white font-semibold transition-colors disabled:opacity-50 hover:bg-blue-700"
            >
              Test Method 19 (Coaching)
            </button>

            <button
              onClick={testMethod20}
              disabled={loading}
              className="px-6 py-3 rounded-lg bg-blue-600 text-white font-semibold transition-colors disabled:opacity-50 hover:bg-blue-700"
            >
              Test Method 20 (Tempo)
            </button>

            <button
              onClick={testARMedicalMethods}
              disabled={loading}
              className="px-6 py-3 rounded-lg bg-green-600 text-white font-semibold transition-colors disabled:opacity-50 hover:bg-green-700"
            >
              Test AR Medical (21-24)
            </button>
          </div>
        </div>

        {/* Results */}
        <div className="bg-white rounded-lg p-6 shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h3
              className="text-xl font-bold"
              style={{ color: BRAND_COLORS.navy.main }}
            >
              Test Results ({results.length})
            </h3>
            {results.length > 0 && (
              <button
                onClick={() => setResults([])}
                className="px-4 py-2 rounded bg-gray-200 text-gray-700 font-medium hover:bg-gray-300"
              >
                Clear Results
              </button>
            )}
          </div>

          {loading && (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-gray-200 border-t-blue-600"></div>
              <div className="mt-4 text-gray-600">Running test...</div>
            </div>
          )}

          {results.length === 0 && !loading && (
            <div className="text-center py-12 text-gray-500">
              No tests run yet. Click a button above to start testing.
            </div>
          )}

          <div className="space-y-4">
            {results.map((result, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border-l-4 ${
                  result.success
                    ? "border-green-500 bg-green-50"
                    : "border-red-500 bg-red-50"
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-bold text-lg">{result.name}</div>
                    <div className="text-sm text-gray-600">
                      {result.endpoint}
                    </div>
                  </div>
                  <div className="text-right">
                    <div
                      className={`text-sm font-semibold ${result.success ? "text-green-700" : "text-red-700"}`}
                    >
                      {result.success ? "✓ SUCCESS" : "✗ FAILED"}
                    </div>
                    <div className="text-xs text-gray-500">
                      {result.timestamp}
                    </div>
                  </div>
                </div>

                {result.duration && (
                  <div className="text-sm text-gray-600 mb-2">
                    Duration: {result.duration}ms
                  </div>
                )}

                {result.error && (
                  <div className="mt-2 p-3 bg-red-100 rounded text-sm text-red-800">
                    Error: {result.error}
                  </div>
                )}

                {result.data && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-sm font-medium text-gray-700 hover:text-gray-900">
                      View Response Data
                    </summary>
                    <pre className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-x-auto">
                      {JSON.stringify(result.data, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="mt-8 bg-white rounded-lg p-6 shadow-lg">
          <h3
            className="text-xl font-bold mb-4"
            style={{ color: BRAND_COLORS.navy.main }}
          >
            Quick Links to Dashboards
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a
              href="/intelligence-dashboard"
              className="px-4 py-3 text-center rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-800 font-semibold"
            >
              Intelligence Dashboard
            </a>
            <a
              href="/coach-dashboard"
              className="px-4 py-3 text-center rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-800 font-semibold"
            >
              Coach Dashboard
            </a>
            <a
              href="/investor-dashboard"
              className="px-4 py-3 text-center rounded-lg bg-green-100 hover:bg-green-200 text-green-800 font-semibold"
            >
              Investor Dashboard
            </a>
            <a
              href="/federation-dashboard"
              className="px-4 py-3 text-center rounded-lg bg-yellow-100 hover:bg-yellow-200 text-yellow-800 font-semibold"
            >
              Federation Dashboard
            </a>
            <a
              href="/console"
              className="px-4 py-3 text-center rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold"
            >
              Console Dashboard
            </a>
            <a
              href="/console/medical-dashboard"
              className="px-4 py-3 text-center rounded-lg bg-red-100 hover:bg-red-200 text-red-800 font-semibold"
            >
              Medical Dashboard
            </a>
            <a
              href="/broadcast-control"
              className="px-4 py-3 text-center rounded-lg bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-semibold"
            >
              Broadcast Control
            </a>
            <a
              href="/console/athletes"
              className="px-4 py-3 text-center rounded-lg bg-pink-100 hover:bg-pink-200 text-pink-800 font-semibold"
            >
              Athlete Registry
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
