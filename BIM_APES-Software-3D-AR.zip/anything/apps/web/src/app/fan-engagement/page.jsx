"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Users,
  Youtube,
  ShoppingBag,
  Target,
  Zap,
  TrendingUp,
  Heart,
  Star,
  Award,
  RefreshCw,
  DollarSign,
  BarChart3,
  Activity,
  Globe,
  Trophy,
  Tv,
  Gift,
  Link,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
} from "recharts";

const NAVY = "#1B3A57";
const GOLD = "#C8A882";
const DARK = "#0D1421";
const DARK_NAVY = "#152E45";
const COLORS = [
  "#10B981",
  "#F59E0B",
  "#EF4444",
  "#60A5FA",
  "#C8A882",
  "#8B5CF6",
];

export default function FanEngagementPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedSegment, setSelectedSegment] = useState("all");

  const { data: nilData, isLoading } = useQuery({
    queryKey: ["nil-divergence-fan"],
    queryFn: async () => {
      const res = await fetch("/api/nil/divergence?limit=20");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    refetchInterval: 60000,
  });

  const summary = nilData?.summary || {};
  const athletes = nilData?.scores || [];

  // Fan segment simulation
  const fanSegments = [
    {
      id: "loyalists",
      name: "Loyalists",
      emoji: "❤️",
      color: "#EF4444",
      pct: 34,
      count: 1240,
      desc: "Long-term fans who follow regardless of performance",
      traits: [
        "High retention",
        "Merch buyers",
        "Premium subscribers",
        "Event attendees",
      ],
      nilEngagement: "Respond to milestone moments & legacy highlights",
      monetization: [
        "Season passes",
        "Signed merch",
        "Behind-the-scenes access",
        "Fan club memberships",
      ],
    },
    {
      id: "casuals",
      name: "Casuals",
      emoji: "👋",
      color: GOLD,
      pct: 45,
      count: 1640,
      desc: "Fair-weather fans who engage during peak NIL momentum",
      traits: [
        "Event-driven",
        "Social sharers",
        "Merch curious",
        "Low retention",
      ],
      nilEngagement: "Activate on viral moments & trending content",
      monetization: [
        "Game tickets",
        "Limited drops",
        "Highlight clips",
        "Challenge events",
      ],
    },
    {
      id: "hype",
      name: "Hype Fans",
      emoji: "🔥",
      color: "#F59E0B",
      pct: 21,
      count: 765,
      desc: "Momentum traders who spike on NIL bull signals",
      traits: [
        "High engagement",
        "Viral amplifiers",
        "Short attention",
        "Signal-driven",
      ],
      nilEngagement: "Boost during arbitrage and scalping windows",
      monetization: [
        "Flash sales",
        "Live auctions",
        "Boost credits",
        "Prediction markets",
      ],
    },
  ];

  const selectedSegmentData =
    selectedSegment === "all"
      ? fanSegments
      : fanSegments.filter((s) => s.id === selectedSegment);

  const engagementData = [
    { day: "Mon", loyalists: 420, casuals: 580, hype: 190 },
    { day: "Tue", loyalists: 380, casuals: 640, hype: 320 },
    { day: "Wed", loyalists: 450, casuals: 720, hype: 580 },
    { day: "Thu", loyalists: 400, casuals: 860, hype: 420 },
    { day: "Fri", loyalists: 510, casuals: 980, hype: 890 },
    { day: "Sat", loyalists: 620, casuals: 1240, hype: 1340 },
    { day: "Sun", loyalists: 580, casuals: 1100, hype: 760 },
  ];

  const pieData = fanSegments.map((s) => ({
    name: s.name,
    value: s.pct,
    color: s.color,
  }));

  const tabs = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "youtube", label: "YouTube Overlays", icon: Youtube },
    { id: "segments", label: "Fan Segments", icon: Users },
    { id: "merch", label: "Merch & Tickets", icon: ShoppingBag },
    { id: "sponsors", label: "Sponsor Integrations", icon: Target },
  ];

  const sponsorCategories = [
    {
      name: "Performance Sponsors",
      color: "#10B981",
      sponsors: [
        {
          name: "Gatorade",
          trigger: "Peak fatigue index drop",
          reward: "Recovery bundle unlock",
          roi: "340%",
        },
        {
          name: "Whoop",
          trigger: "HRV improvement milestone",
          reward: "30-day free subscription",
          roi: "280%",
        },
        {
          name: "Nike",
          trigger: "Speed index PR",
          reward: "Limited edition release",
          roi: "420%",
        },
      ],
    },
    {
      name: "Financial Sponsors",
      color: "#60A5FA",
      sponsors: [
        {
          name: "Model NIL Bank",
          trigger: "NIL milestone achieved",
          reward: "Boost credit allocation",
          roi: "510%",
        },
        {
          name: "Fidelity Youth",
          trigger: "Pro transition event",
          reward: "Account opening bonus",
          roi: "380%",
        },
        {
          name: "Coinbase",
          trigger: "Token value surge",
          reward: "Blockchain reward drop",
          roi: "290%",
        },
      ],
    },
    {
      name: "Entertainment Sponsors",
      color: "#8B5CF6",
      sponsors: [
        {
          name: "EA Sports",
          trigger: "Momentum score peak",
          reward: "Player card upgrade",
          roi: "480%",
        },
        {
          name: "Twitch",
          trigger: "Live stream milestone",
          reward: "Creator program invite",
          roi: "340%",
        },
        {
          name: "YouTube Premium",
          trigger: "Channel overlay engagement",
          reward: "Premium access pass",
          roi: "270%",
        },
      ],
    },
  ];

  if (isLoading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ backgroundColor: DARK }}
      >
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#C8A882]/20 border-t-[#C8A882] rounded-full mx-auto mb-4" />
          <p className="text-gray-400 text-sm">Loading Fan Engagement Hub...</p>
        </div>
        <style jsx global>{`
          @keyframes spin { to { transform: rotate(360deg); } }
        `}</style>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: DARK }}>
      {/* Header */}
      <div
        className="sticky top-0 z-50 border-b"
        style={{ backgroundColor: NAVY, borderColor: GOLD + "30" }}
      >
        <div className="max-w-[1400px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <a
                href="/"
                className="text-[#C8A882] hover:text-white text-sm font-medium"
              >
                ← Back
              </a>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Sparkles size={20} style={{ color: GOLD }} />
                  Fan Engagement & Monetization Hub
                </h1>
                <p className="text-xs text-[#C8A882] mt-0.5">
                  YouTube Overlays · Fan Segments · Merch Campaigns · Sponsor
                  ROI · Blockchain Rewards
                </p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-3 text-sm">
              <div className="bg-white/5 border border-white/10 rounded-lg px-4 py-2 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-medium">
                  {(3645).toLocaleString()} Total Fans
                </span>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-lg px-4 py-2 flex items-center gap-2">
                <DollarSign size={14} style={{ color: GOLD }} />
                <span className="font-medium text-[#C8A882]">
                  $1.24M Fan Revenue
                </span>
              </div>
            </div>
          </div>
          {/* Tabs */}
          <div className="flex gap-1 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all"
                  style={
                    active
                      ? { backgroundColor: GOLD + "30", color: GOLD }
                      : { color: "#9CA3AF" }
                  }
                >
                  <Icon size={14} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-6 py-8">
        {/* ── OVERVIEW ── */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* KPI Row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                {
                  label: "Loyalists",
                  value: "1,240",
                  sub: "34% of base",
                  icon: Heart,
                  color: "#EF4444",
                },
                {
                  label: "Casuals",
                  value: "1,640",
                  sub: "45% of base",
                  icon: Users,
                  color: GOLD,
                },
                {
                  label: "Hype Fans",
                  value: "765",
                  sub: "21% of base",
                  icon: Zap,
                  color: "#F59E0B",
                },
                {
                  label: "Bull Athletes",
                  value: summary.bull_count || 0,
                  sub: "NIL positive signal",
                  icon: TrendingUp,
                  color: "#10B981",
                },
              ].map((kpi, i) => {
                const Icon = kpi.icon;
                return (
                  <div
                    key={i}
                    className="rounded-xl border p-5"
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderColor: kpi.color + "30",
                    }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-xs text-gray-400 font-medium">
                        {kpi.label}
                      </p>
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: kpi.color + "20" }}
                      >
                        <Icon size={16} style={{ color: kpi.color }} />
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-white mb-1">
                      {kpi.value}
                    </p>
                    <p className="text-xs text-gray-500">{kpi.sub}</p>
                  </div>
                );
              })}
            </div>

            {/* Engagement Chart + Pie */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div
                className="lg:col-span-2 rounded-xl border p-5"
                style={{ backgroundColor: DARK_NAVY, borderColor: NAVY }}
              >
                <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                  <Activity size={16} style={{ color: GOLD }} />
                  7-Day Fan Engagement by Segment
                </h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={engagementData} barGap={2}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1B3A57" />
                      <XAxis
                        dataKey="day"
                        tick={{ fill: "#9CA3AF", fontSize: 11 }}
                      />
                      <YAxis tick={{ fill: "#9CA3AF", fontSize: 11 }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: DARK_NAVY,
                          border: `1px solid ${GOLD}30`,
                          borderRadius: 8,
                          color: "white",
                        }}
                      />
                      <Bar
                        dataKey="loyalists"
                        name="Loyalists"
                        fill="#EF4444"
                        radius={[2, 2, 0, 0]}
                      />
                      <Bar
                        dataKey="casuals"
                        name="Casuals"
                        fill={GOLD}
                        radius={[2, 2, 0, 0]}
                      />
                      <Bar
                        dataKey="hype"
                        name="Hype Fans"
                        fill="#F59E0B"
                        radius={[2, 2, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div
                className="rounded-xl border p-5"
                style={{ backgroundColor: DARK_NAVY, borderColor: NAVY }}
              >
                <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                  <Users size={16} style={{ color: GOLD }} />
                  Fan Base Composition
                </h3>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: DARK_NAVY,
                          border: `1px solid ${GOLD}30`,
                          borderRadius: 8,
                          color: "white",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2 mt-2">
                  {fanSegments.map((seg) => (
                    <div
                      key={seg.id}
                      className="flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: seg.color }}
                        />
                        <span className="text-gray-400">
                          {seg.emoji} {seg.name}
                        </span>
                      </div>
                      <span className="font-bold text-white">{seg.pct}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top NIL Momentum Triggers */}
            <div
              className="rounded-xl border overflow-hidden"
              style={{ backgroundColor: DARK_NAVY, borderColor: GOLD + "20" }}
            >
              <div
                className="p-5 border-b flex items-center gap-2"
                style={{ borderColor: GOLD + "20" }}
              >
                <Zap size={18} style={{ color: GOLD }} />
                <h3 className="font-bold text-white">
                  NIL Momentum → Fan Activation Triggers
                </h3>
              </div>
              <div
                className="grid grid-cols-1 md:grid-cols-3 divide-x"
                style={{ borderColor: NAVY }}
              >
                {[
                  {
                    trigger: "📈 Bull Signal Detected",
                    desc: "Model NIL > 65 or Market NIL spikes",
                    actions: [
                      "Push Boost Button prompt",
                      "Flash merch deal",
                      "Unlock fan challenge",
                      "Activate sponsor banner",
                    ],
                    color: "#10B981",
                  },
                  {
                    trigger: "➡️ Sideways Signal",
                    desc: "NIL within ±10 of neutral zone",
                    actions: [
                      "Show historical highlights",
                      "Engage loyalist content",
                      "Soft merch recommendation",
                      "Community poll",
                    ],
                    color: GOLD,
                  },
                  {
                    trigger: "📉 Bear Signal / Divergence",
                    desc: "Market overvalued vs Model — opportunity",
                    actions: [
                      "SHORT signal to hype fans",
                      "Value pricing on merch",
                      "Hedging overlay visible",
                      "Recovery content push",
                    ],
                    color: "#EF4444",
                  },
                ].map((item, i) => (
                  <div key={i} className="p-5" style={{ borderColor: NAVY }}>
                    <p className="font-bold text-white mb-1 text-sm">
                      {item.trigger}
                    </p>
                    <p className="text-xs text-gray-400 mb-3">{item.desc}</p>
                    <div className="space-y-1.5">
                      {item.actions.map((a, ai) => (
                        <div
                          key={ai}
                          className="flex items-start gap-2 text-xs text-gray-300"
                        >
                          <div
                            className="w-1.5 h-1.5 rounded-full mt-1 flex-shrink-0"
                            style={{ backgroundColor: item.color }}
                          />
                          {a}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── YOUTUBE OVERLAYS ── */}
        {activeTab === "youtube" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 rounded-xl bg-red-500/20">
                <Youtube size={24} className="text-red-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  YouTube Channel Overlays
                </h2>
                <p className="text-sm text-gray-400">
                  Live Momentum Meter + Divergence Bar embedded into YouTube
                  streams and highlight reels
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Overlay Preview */}
              <div
                className="rounded-xl border overflow-hidden"
                style={{ borderColor: "#EF444440", backgroundColor: DARK_NAVY }}
              >
                <div
                  className="p-4 border-b flex items-center gap-2"
                  style={{ borderColor: "#EF444420" }}
                >
                  <div className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="text-sm font-bold text-white">
                    Live Overlay Preview
                  </span>
                  <span className="text-xs text-red-400 font-semibold ml-auto">
                    ● LIVE
                  </span>
                </div>
                {/* Simulated YouTube Video */}
                <div className="relative aspect-video bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                  <div className="text-6xl opacity-20">▶</div>

                  {/* Momentum Meter — Top Left */}
                  <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg p-3 border border-white/10 w-40">
                    <p className="text-xs text-gray-400 mb-1 font-semibold uppercase tracking-wider">
                      NIL Momentum
                    </p>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500">Model</span>
                      <span className="text-xs font-bold text-emerald-400">
                        {summary.avg_model_score || 72}
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 mb-2">
                      <div
                        className="h-full rounded-full bg-emerald-400"
                        style={{ width: `${summary.avg_model_score || 72}%` }}
                      />
                    </div>
                    <p className="text-xs font-bold text-emerald-400">
                      📈 BULL
                    </p>
                  </div>

                  {/* Divergence Bar — Top Right */}
                  <div className="absolute top-4 right-4 bg-black/80 backdrop-blur-sm rounded-lg p-3 border border-white/10 w-40">
                    <p className="text-xs text-gray-400 mb-1 font-semibold uppercase tracking-wider">
                      Divergence
                    </p>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500">
                        Model vs Market
                      </span>
                    </div>
                    <div className="relative h-3 rounded-full bg-white/10 overflow-hidden mb-2">
                      <div className="absolute left-1/2 top-0 h-full w-0.5 bg-white/30" />
                      <div
                        className="absolute top-0 h-full rounded-full"
                        style={{
                          left: "50%",
                          width: "18%",
                          backgroundColor: GOLD,
                        }}
                      />
                    </div>
                    <p className="text-xs font-bold" style={{ color: GOLD }}>
                      +12 pts gap
                    </p>
                  </div>

                  {/* Bottom Sponsor Banner */}
                  <div className="absolute bottom-4 left-4 right-4 bg-black/80 backdrop-blur-sm rounded-lg p-3 border border-[#C8A882]/30 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded bg-[#C8A882] flex items-center justify-center">
                        <Zap size={12} className="text-[#1B3A57]" />
                      </div>
                      <span className="text-xs font-bold text-[#C8A882]">
                        Peak Performance Moment
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-400">
                        Sponsored by
                      </span>
                      <span className="text-xs font-bold text-white">Nike</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 grid grid-cols-2 gap-3">
                  <div className="bg-white/5 rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-white">24.8K</p>
                    <p className="text-xs text-gray-400">Live Viewers</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold" style={{ color: GOLD }}>
                      5.2%
                    </p>
                    <p className="text-xs text-gray-400">Engagement Rate</p>
                  </div>
                </div>
              </div>

              {/* Overlay Config */}
              <div className="space-y-4">
                <h3 className="font-bold text-white">Overlay Components</h3>
                {[
                  {
                    name: "Momentum Meter",
                    desc: "Live Model NIL vs Market NIL score with bull/bear indicator",
                    color: "#10B981",
                    trigger: "Auto-activates on NIL score change ≥ 5pts",
                    position: "Top-left corner",
                    active: true,
                  },
                  {
                    name: "Divergence Bar",
                    desc: "Visual gap between Model and Market NIL, signals trading opportunity",
                    color: GOLD,
                    trigger: "Activates when divergence > 10pts",
                    position: "Top-right corner",
                    active: true,
                  },
                  {
                    name: "Boost Button",
                    desc: "Fan interaction button — tap to boost athlete NIL momentum",
                    color: "#F59E0B",
                    trigger: "Available during live events",
                    position: "Right rail",
                    active: true,
                  },
                  {
                    name: "Sponsor Activation",
                    desc: "Brand moment overlay triggered by performance milestones",
                    color: "#8B5CF6",
                    trigger: "Performance PR, milestone, highlight detected",
                    position: "Bottom banner",
                    active: true,
                  },
                  {
                    name: "Fan Challenge Alert",
                    desc: "Real-time challenge prompt tied to hype fan segments",
                    color: "#EF4444",
                    trigger: "Hype fan segment engagement spike",
                    position: "Floating badge",
                    active: false,
                  },
                ].map((comp, i) => (
                  <div
                    key={i}
                    className="rounded-xl border p-4"
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderColor: comp.color + "30",
                    }}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-white text-sm">
                          {comp.name}
                        </p>
                        <p className="text-xs text-gray-400 mt-0.5">
                          {comp.desc}
                        </p>
                      </div>
                      <div
                        className={`w-10 h-5 rounded-full flex items-center transition-all ${comp.active ? "justify-end" : "justify-start"}`}
                        style={{
                          backgroundColor: comp.active
                            ? comp.color + "40"
                            : "#374151",
                        }}
                      >
                        <div
                          className="w-4 h-4 rounded-full m-0.5"
                          style={{
                            backgroundColor: comp.active
                              ? comp.color
                              : "#6B7280",
                          }}
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>📍 {comp.position}</span>
                      <span>⚡ {comp.trigger}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── FAN SEGMENTS ── */}
        {activeTab === "segments" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 rounded-xl bg-blue-500/20">
                <Users size={24} className="text-blue-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  Fan Segmentation
                </h2>
                <p className="text-sm text-gray-400">
                  Loyalists · Casuals · Hype Fans — NIL-driven audience
                  intelligence
                </p>
              </div>
            </div>

            {/* Segment Filter */}
            <div className="flex gap-2">
              {["all", "loyalists", "casuals", "hype"].map((seg) => (
                <button
                  key={seg}
                  onClick={() => setSelectedSegment(seg)}
                  className="px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize"
                  style={
                    selectedSegment === seg
                      ? { backgroundColor: GOLD, color: NAVY }
                      : {
                          backgroundColor: DARK_NAVY,
                          color: "#9CA3AF",
                          border: `1px solid ${NAVY}`,
                        }
                  }
                >
                  {seg === "all"
                    ? "All Segments"
                    : fanSegments.find((f) => f.id === seg)?.emoji +
                      " " +
                      fanSegments.find((f) => f.id === seg)?.name}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {selectedSegmentData.map((seg) => (
                <div
                  key={seg.id}
                  className="rounded-2xl border overflow-hidden"
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderColor: seg.color + "40",
                  }}
                >
                  {/* Header */}
                  <div
                    className="p-5 border-b"
                    style={{
                      borderColor: seg.color + "20",
                      background: `linear-gradient(135deg, ${seg.color}10, transparent)`,
                    }}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                        style={{ backgroundColor: seg.color + "20" }}
                      >
                        {seg.emoji}
                      </div>
                      <div>
                        <p className="font-bold text-white text-lg">
                          {seg.name}
                        </p>
                        <p className="text-xs text-gray-400">
                          {seg.count.toLocaleString()} fans · {seg.pct}% of base
                        </p>
                      </div>
                    </div>
                    {/* Donut mini */}
                    <div className="h-1.5 rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${seg.pct}%`,
                          backgroundColor: seg.color,
                        }}
                      />
                    </div>
                  </div>

                  <div className="p-5 space-y-4">
                    <p className="text-sm text-gray-300">{seg.desc}</p>

                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                        Traits
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {seg.traits.map((t, i) => (
                          <span
                            key={i}
                            className="text-xs px-2 py-1 rounded-full font-medium"
                            style={{
                              backgroundColor: seg.color + "20",
                              color: seg.color,
                            }}
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                        NIL Engagement
                      </p>
                      <p className="text-sm text-gray-300">
                        {seg.nilEngagement}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                        Monetization
                      </p>
                      <div className="space-y-1.5">
                        {seg.monetization.map((m, i) => (
                          <div
                            key={i}
                            className="flex items-center gap-2 text-xs text-gray-300"
                          >
                            <div
                              className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                              style={{ backgroundColor: seg.color }}
                            />
                            {m}
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      className="w-full py-2.5 rounded-xl text-sm font-bold transition-all"
                      style={{
                        backgroundColor: seg.color + "20",
                        color: seg.color,
                        border: `1px solid ${seg.color}40`,
                      }}
                    >
                      Activate {seg.name} Campaign
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── MERCH & TICKETS ── */}
        {activeTab === "merch" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div
                className="p-3 rounded-xl"
                style={{ backgroundColor: GOLD + "20" }}
              >
                <ShoppingBag size={24} style={{ color: GOLD }} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  Merch & Ticket Promotions
                </h2>
                <p className="text-sm text-gray-400">
                  NIL-driven campaigns triggered by biometric performance and
                  market momentum signals
                </p>
              </div>
            </div>

            {/* Revenue Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                {
                  label: "Merch Revenue",
                  value: "$84.2K",
                  sub: "Last 30 days",
                  icon: ShoppingBag,
                  color: GOLD,
                },
                {
                  label: "Ticket Sales",
                  value: "$340K",
                  sub: "Last 30 days",
                  icon: Trophy,
                  color: "#60A5FA",
                },
                {
                  label: "Campaign Lift",
                  value: "+34%",
                  sub: "vs no NIL trigger",
                  icon: TrendingUp,
                  color: "#10B981",
                },
                {
                  label: "Avg Order Value",
                  value: "$127",
                  sub: "Per fan transaction",
                  icon: DollarSign,
                  color: "#8B5CF6",
                },
              ].map((m, i) => {
                const Icon = m.icon;
                return (
                  <div
                    key={i}
                    className="rounded-xl border p-4"
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderColor: m.color + "30",
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Icon size={16} style={{ color: m.color }} />
                      <p className="text-xs text-gray-400">{m.label}</p>
                    </div>
                    <p className="text-2xl font-bold text-white">{m.value}</p>
                    <p className="text-xs text-gray-500 mt-1">{m.sub}</p>
                  </div>
                );
              })}
            </div>

            {/* NIL-Driven Campaign Types */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  name: "Bull Signal Drops",
                  emoji: "📈",
                  color: "#10B981",
                  desc: "Limited merch drops triggered when athlete Model NIL enters Bull territory",
                  examples: [
                    "Signed jersey flash sale (24h)",
                    "Custom sneaker colorway",
                    "Championship edition cap",
                  ],
                  trigger: "Model NIL Score > 65 + Market sentiment aligned",
                  conversion: "12.4%",
                  avgRevenue: "$8,400 per drop",
                },
                {
                  name: "Momentum Surge Bundles",
                  emoji: "⚡",
                  color: GOLD,
                  desc: "Bundled merch + ticket packages activated during NIL momentum spikes",
                  examples: [
                    "Game ticket + jersey bundle",
                    "Season pass + meet & greet",
                    "VIP sideline package",
                  ],
                  trigger: "NIL Momentum delta > +15 in 24h",
                  conversion: "8.7%",
                  avgRevenue: "$14,200 per surge",
                },
                {
                  name: "Recovery & Story Content",
                  emoji: "🎬",
                  color: "#60A5FA",
                  desc: "Behind-the-scenes content drops during recovery periods targeting Loyalists",
                  examples: [
                    "Day-in-the-life video access",
                    "Training documentary",
                    "Recovery journey series",
                  ],
                  trigger: "Recovery Index improving week-over-week",
                  conversion: "22.1%",
                  avgRevenue: "$3,800 per release",
                },
                {
                  name: "Divergence Arbitrage Sales",
                  emoji: "🔀",
                  color: "#8B5CF6",
                  desc: "Value pricing on merch when Market NIL overvalued vs Model NIL — capture hype fan spend",
                  examples: [
                    "Flash discount on overstock",
                    "Prediction market merch",
                    "Hype edition drops",
                  ],
                  trigger: "Market NIL > Model NIL by 15+ pts",
                  conversion: "18.9%",
                  avgRevenue: "$5,600 per campaign",
                },
              ].map((camp, i) => (
                <div
                  key={i}
                  className="rounded-2xl border overflow-hidden"
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderColor: camp.color + "30",
                  }}
                >
                  <div
                    className="p-5 border-b"
                    style={{ borderColor: camp.color + "20" }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">{camp.emoji}</span>
                      <p className="font-bold text-white">{camp.name}</p>
                    </div>
                    <p className="text-sm text-gray-400">{camp.desc}</p>
                  </div>
                  <div className="p-5 space-y-3">
                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                        Example Campaigns
                      </p>
                      {camp.examples.map((ex, ei) => (
                        <div
                          key={ei}
                          className="flex items-center gap-2 text-xs text-gray-300 mb-1"
                        >
                          <div
                            className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                            style={{ backgroundColor: camp.color }}
                          />
                          {ex}
                        </div>
                      ))}
                    </div>
                    <div
                      className="flex items-center gap-3 pt-2 border-t text-xs"
                      style={{ borderColor: NAVY }}
                    >
                      <div>
                        <span className="text-gray-500">Trigger: </span>
                        <span className="text-white">{camp.trigger}</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-center">
                      <div className="bg-white/5 rounded-lg p-2">
                        <p className="text-xs text-gray-400">Conversion</p>
                        <p
                          className="font-bold text-sm"
                          style={{ color: camp.color }}
                        >
                          {camp.conversion}
                        </p>
                      </div>
                      <div className="bg-white/5 rounded-lg p-2">
                        <p className="text-xs text-gray-400">Avg Revenue</p>
                        <p className="font-bold text-sm text-white">
                          {camp.avgRevenue}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── SPONSORS ── */}
        {activeTab === "sponsors" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 rounded-xl bg-purple-500/20">
                <Target size={24} className="text-purple-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  Sponsor Integrations
                </h2>
                <p className="text-sm text-gray-400">
                  ROI Insights · Blockchain Rewards · Performance-Linked Brand
                  Activations
                </p>
              </div>
            </div>

            {/* Sponsor Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                {
                  label: "Active Campaigns",
                  value: "9",
                  color: "#8B5CF6",
                  icon: Target,
                },
                {
                  label: "Total Sponsor ROI",
                  value: "360%",
                  color: "#10B981",
                  icon: TrendingUp,
                },
                {
                  label: "Blockchain Rewards",
                  value: "1,240",
                  color: GOLD,
                  icon: Link,
                },
                {
                  label: "Sponsor Impressions",
                  value: "4.2M",
                  color: "#60A5FA",
                  icon: Globe,
                },
              ].map((m, i) => {
                const Icon = m.icon;
                return (
                  <div
                    key={i}
                    className="rounded-xl border p-4"
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderColor: m.color + "30",
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Icon size={15} style={{ color: m.color }} />
                      <p className="text-xs text-gray-400">{m.label}</p>
                    </div>
                    <p
                      className="text-2xl font-bold"
                      style={{ color: m.color }}
                    >
                      {m.value}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Sponsor Categories */}
            {sponsorCategories.map((cat, ci) => (
              <div
                key={ci}
                className="rounded-xl border overflow-hidden"
                style={{
                  backgroundColor: DARK_NAVY,
                  borderColor: cat.color + "20",
                }}
              >
                <div
                  className="p-4 border-b flex items-center gap-2"
                  style={{ borderColor: cat.color + "20" }}
                >
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: cat.color }}
                  />
                  <h3 className="font-bold text-white">{cat.name}</h3>
                </div>
                <div className="divide-y" style={{ borderColor: NAVY }}>
                  {cat.sponsors.map((sp, si) => (
                    <div
                      key={si}
                      className="p-4 flex items-center gap-4 hover:bg-white/5 transition-colors"
                    >
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm flex-shrink-0"
                        style={{
                          backgroundColor: cat.color + "20",
                          color: cat.color,
                        }}
                      >
                        {sp.name.slice(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-white text-sm">
                          {sp.name}
                        </p>
                        <p className="text-xs text-gray-400 mt-0.5">
                          Trigger: {sp.trigger}
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Reward: {sp.reward}
                        </p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div
                          className="text-sm font-bold"
                          style={{ color: "#10B981" }}
                        >
                          {sp.roi}
                        </div>
                        <p className="text-xs text-gray-500">ROI</p>
                      </div>
                      <button
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex-shrink-0"
                        style={{
                          backgroundColor: cat.color + "20",
                          color: cat.color,
                          border: `1px solid ${cat.color}40`,
                        }}
                      >
                        Activate
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            {/* Blockchain Rewards */}
            <div
              className="rounded-xl border p-5"
              style={{ backgroundColor: DARK_NAVY, borderColor: GOLD + "30" }}
            >
              <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                <Link size={18} style={{ color: GOLD }} />
                Blockchain Reward System
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  {
                    name: "Token Earn",
                    desc: "Fans earn tokens for boosts, purchases, and engagement",
                    icon: "🪙",
                    color: GOLD,
                  },
                  {
                    name: "Coalition Certificates",
                    desc: "BLEDSOE-stamped on-chain certificates for milestone achievements",
                    icon: "📜",
                    color: "#60A5FA",
                  },
                  {
                    name: "NFT Drops",
                    desc: "Exclusive digital collectibles tied to NIL bull moments",
                    icon: "💎",
                    color: "#8B5CF6",
                  },
                ].map((item, i) => (
                  <div
                    key={i}
                    className="rounded-xl p-4 border"
                    style={{
                      borderColor: item.color + "30",
                      backgroundColor: item.color + "08",
                    }}
                  >
                    <p className="text-2xl mb-3">{item.icon}</p>
                    <p className="font-bold text-white text-sm mb-1">
                      {item.name}
                    </p>
                    <p className="text-xs text-gray-400">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
