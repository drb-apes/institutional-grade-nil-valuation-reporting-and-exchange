"use client";

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Activity,
  Database,
  Youtube,
  ShoppingBag,
  Wifi,
  AlertCircle,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  Target,
  BarChart3,
  ChevronRight,
  Globe,
  Brain,
  DollarSign,
  Users,
} from "lucide-react";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Legend,
} from "recharts";

const NAVY = "#1B3A57";
const GOLD = "#C8A882";
const DARK = "#0D1421";
const DARK_NAVY = "#152E45";

export default function NILAnalyticsPage() {
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [activeSection, setActiveSection] = useState("overview");

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["nil-divergence"],
    queryFn: async () => {
      const res = await fetch("/api/nil/divergence?limit=30");
      if (!res.ok) throw new Error("Failed to fetch NIL divergence data");
      return res.json();
    },
    refetchInterval: 60000,
  });

  const summary = data?.summary || {};
  const scores = data?.scores || [];
  const sources = data?.data_sources || {};

  // Chart data
  const sentimentChartData = [
    { name: "Bull 📈", value: summary.bull_count || 0, fill: "#10B981" },
    { name: "Sideways ➡️", value: summary.sideways_count || 0, fill: GOLD },
    { name: "Bear 📉", value: summary.bear_count || 0, fill: "#EF4444" },
  ];

  const topScores = scores.slice(0, 10);
  const radarData = selectedAthlete
    ? [
        { metric: "Model NIL", value: selectedAthlete.model_nil.score },
        { metric: "Market NIL", value: selectedAthlete.market_nil.score },
        {
          metric: "Divergence",
          value: Math.abs(selectedAthlete.divergence.value),
        },
        { metric: "Momentum", value: 65 },
        {
          metric: "Confidence",
          value:
            parseFloat(selectedAthlete.market_nil.inputs?.confidence || 0.6) *
            100,
        },
      ]
    : [];

  const nav = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "model-nil", label: "Model NIL", icon: Brain },
    { id: "market-nil", label: "Market NIL", icon: Globe },
    { id: "divergence", label: "Divergence Engine", icon: Zap },
    { id: "sources", label: "Data Sources", icon: Database },
  ];

  const SignalBadge = ({ signal }) => {
    const cfg = {
      BUY: {
        bg: "bg-emerald-500/20",
        text: "text-emerald-400",
        border: "border-emerald-500/30",
      },
      LONG: {
        bg: "bg-green-500/20",
        text: "text-green-400",
        border: "border-green-500/30",
      },
      SELL: {
        bg: "bg-red-500/20",
        text: "text-red-400",
        border: "border-red-500/30",
      },
      SHORT: {
        bg: "bg-orange-500/20",
        text: "text-orange-400",
        border: "border-orange-500/30",
      },
      HOLD: {
        bg: "bg-gray-500/20",
        text: "text-gray-400",
        border: "border-gray-500/30",
      },
    };
    const c = cfg[signal] || cfg.HOLD;
    return (
      <span
        className={`px-2 py-0.5 rounded text-xs font-bold border ${c.bg} ${c.text} ${c.border}`}
      >
        {signal}
      </span>
    );
  };

  const SentimentTag = ({ sentiment }) => {
    if (!sentiment) return null;
    return (
      <span
        className="inline-flex items-center gap-1 text-sm font-bold"
        style={{ color: sentiment.color }}
      >
        {sentiment.emoji} {sentiment.label}
      </span>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0F1C] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#C8A882]/20 border-t-[#C8A882] rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Loading NIL Divergence Engine...</p>
        </div>
        <style jsx global>{`
          @keyframes spin { to { transform: rotate(360deg); } }
          .animate-spin { animation: spin 1s linear infinite; }
        `}</style>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: DARK }}>
      {/* Header */}
      <div
        className="sticky top-0 z-50 border-b"
        style={{ backgroundColor: NAVY, borderColor: GOLD + "30" }}
      >
        <div className="max-w-[1600px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <a
                href="/"
                className="text-[#C8A882] hover:text-white text-sm font-medium transition-colors"
              >
                ← Back
              </a>
              <div>
                <h1 className="text-2xl font-bold text-white">
                  NIL Analytics System
                </h1>
                <p className="text-xs text-[#C8A882] mt-0.5">
                  Model NIL • Market NIL • Divergence Engine • Azure-Powered
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {/* Market Pulse */}
              <div className="hidden md:flex items-center gap-3 bg-white/5 border border-white/10 rounded-lg px-4 py-2">
                <div
                  className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"
                  style={{ animationDuration: "2s" }}
                />
                <span className="text-sm font-semibold text-white">
                  {summary.overall_market || "Calculating..."}
                </span>
                <span className="text-xs text-gray-400">|</span>
                <span className="text-xs text-emerald-400 font-bold">
                  {summary.buy_signals || 0} BUY
                </span>
                <span className="text-xs text-red-400 font-bold">
                  {summary.sell_signals || 0} SELL
                </span>
              </div>
              <button
                onClick={() => refetch()}
                className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              >
                <RefreshCw size={16} className="text-[#C8A882]" />
              </button>
            </div>
          </div>

          {/* Sub-Nav */}
          <div className="flex gap-1 overflow-x-auto">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                    active ? "text-white" : "text-gray-400 hover:text-gray-200"
                  }`}
                  style={
                    active ? { backgroundColor: GOLD + "30", color: GOLD } : {}
                  }
                >
                  <Icon size={14} />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-6 py-8">
        {/* ── OVERVIEW ── */}
        {activeSection === "overview" && (
          <div className="space-y-8">
            {/* Architecture Banner */}
            <div
              className="rounded-2xl border overflow-hidden"
              style={{
                borderColor: GOLD + "30",
                background: `linear-gradient(135deg, ${NAVY}, #0D1F33)`,
              }}
            >
              <div
                className="p-6 border-b"
                style={{ borderColor: GOLD + "20" }}
              >
                <h2 className="text-lg font-bold text-white mb-1">
                  NIL Analytics Architecture — Azure
                </h2>
                <p className="text-sm text-gray-400">
                  Dual-track processing: performance-based Model NIL vs
                  social/market-based Market NIL, unified through the Divergence
                  Engine
                </p>
              </div>
              {/* Architecture Visual */}
              <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
                {/* Ingestion */}
                <div className="space-y-2">
                  <p className="text-xs font-bold text-[#C8A882] uppercase tracking-wider mb-3">
                    Data Ingestion
                  </p>
                  {[
                    {
                      icon: Wifi,
                      label: "Wearables & Sensors",
                      color: "#60A5FA",
                      status: sources.wearables?.records || 0,
                    },
                    {
                      icon: Activity,
                      label: "Team Performance",
                      color: "#10B981",
                      status: sources.team_performance?.records || 0,
                    },
                    {
                      icon: Youtube,
                      label: "YouTube & Social",
                      color: "#EF4444",
                      status: sources.youtube_social?.records || 0,
                    },
                    {
                      icon: ShoppingBag,
                      label: "Merch & Tickets",
                      color: GOLD,
                      status: sources.merch_tickets?.records || 0,
                    },
                  ].map((src, i) => {
                    const Icon = src.icon;
                    return (
                      <div
                        key={i}
                        className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/10"
                      >
                        <div
                          className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: src.color + "20" }}
                        >
                          <Icon size={14} style={{ color: src.color }} />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs text-white font-medium truncate">
                            {src.label}
                          </p>
                          <p className="text-xs text-gray-500">
                            {src.status.toLocaleString()} records
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Arrow */}
                <div className="hidden md:flex justify-center">
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-px h-16 bg-gradient-to-b from-transparent via-[#C8A882] to-transparent" />
                    <ChevronRight
                      size={20}
                      className="text-[#C8A882] rotate-0"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Azure Functions
                    </p>
                  </div>
                </div>

                {/* Dual Processing */}
                <div className="space-y-3">
                  <p className="text-xs font-bold text-[#C8A882] uppercase tracking-wider mb-3">
                    NIL Processing
                  </p>
                  <div
                    className="p-3 rounded-xl border"
                    style={{
                      backgroundColor: "#10B981" + "10",
                      borderColor: "#10B981" + "40",
                    }}
                  >
                    <p className="text-xs font-bold text-emerald-400 mb-1">
                      MODEL NIL TRACK
                    </p>
                    <p className="text-xs text-gray-400">
                      Performance Analysis
                    </p>
                    <p className="text-xs text-gray-400">
                      Biometric DB → Score
                    </p>
                    <div className="mt-2 flex items-center gap-1">
                      <div
                        className="h-1.5 rounded-full bg-emerald-400 flex-1"
                        style={{ width: `${summary.avg_model_score || 0}%` }}
                      />
                      <span className="text-xs font-bold text-emerald-400">
                        {summary.avg_model_score || "--"}
                      </span>
                    </div>
                  </div>
                  <div
                    className="p-3 rounded-xl border"
                    style={{
                      backgroundColor: "#60A5FA" + "10",
                      borderColor: "#60A5FA" + "40",
                    }}
                  >
                    <p className="text-xs font-bold text-blue-400 mb-1">
                      MARKET NIL TRACK
                    </p>
                    <p className="text-xs text-gray-400">YouTube Data Ingest</p>
                    <p className="text-xs text-gray-400">Market DB → Score</p>
                    <div className="mt-2 flex items-center gap-1">
                      <div
                        className="h-1.5 rounded-full bg-blue-400 flex-1"
                        style={{ width: `${summary.avg_market_score || 0}%` }}
                      />
                      <span className="text-xs font-bold text-blue-400">
                        {summary.avg_market_score || "--"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Arrow 2 */}
                <div className="hidden md:flex justify-center">
                  <div className="flex flex-col items-center gap-1">
                    <div className="w-px h-16 bg-gradient-to-b from-transparent via-[#C8A882] to-transparent" />
                    <Zap size={20} className="text-[#C8A882]" />
                    <p className="text-xs text-gray-500 mt-1">Divergence</p>
                  </div>
                </div>

                {/* Output */}
                <div className="space-y-2">
                  <p className="text-xs font-bold text-[#C8A882] uppercase tracking-wider mb-3">
                    Output Layer
                  </p>
                  {[
                    {
                      icon: Youtube,
                      label: "Overlay Signals",
                      sub: "Momentum / Divergence Bar",
                      color: "#EF4444",
                    },
                    {
                      icon: BarChart3,
                      label: "NIL Dashboards",
                      sub: "Live analytics",
                      color: "#C8A882",
                    },
                    {
                      icon: Globe,
                      label: "REST API",
                      sub: "Endpoints + Alerts",
                      color: "#60A5FA",
                    },
                    {
                      icon: Users,
                      label: "Fan Segments",
                      sub: "Loyalists/Casuals/Hype",
                      color: "#10B981",
                    },
                    {
                      icon: ShoppingBag,
                      label: "Merch Campaigns",
                      sub: "NIL-driven promotions",
                      color: "#F59E0B",
                    },
                  ].map((out, i) => {
                    const Icon = out.icon;
                    return (
                      <div
                        key={i}
                        className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/10"
                      >
                        <Icon size={14} style={{ color: out.color }} />
                        <div>
                          <p className="text-xs text-white font-medium">
                            {out.label}
                          </p>
                          <p className="text-xs text-gray-500">{out.sub}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* KPI Row */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                {
                  label: "Total Athletes",
                  value: summary.total_athletes || 0,
                  icon: Users,
                  color: GOLD,
                },
                {
                  label: "Bull Signal",
                  value: `${summary.bull_count || 0}`,
                  icon: TrendingUp,
                  color: "#10B981",
                },
                {
                  label: "Bear Signal",
                  value: `${summary.bear_count || 0}`,
                  icon: TrendingDown,
                  color: "#EF4444",
                },
                {
                  label: "Avg Model Score",
                  value: `${summary.avg_model_score || 0}`,
                  icon: Brain,
                  color: "#10B981",
                },
                {
                  label: "Avg Market Score",
                  value: `${summary.avg_market_score || 0}`,
                  icon: Globe,
                  color: "#60A5FA",
                },
                {
                  label: "BUY Signals",
                  value: `${summary.buy_signals || 0}`,
                  icon: Zap,
                  color: "#F59E0B",
                },
              ].map((kpi, i) => {
                const Icon = kpi.icon;
                return (
                  <div
                    key={i}
                    className="rounded-xl border p-4"
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderColor: kpi.color + "30",
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-gray-400 font-medium">
                        {kpi.label}
                      </p>
                      <Icon size={14} style={{ color: kpi.color }} />
                    </div>
                    <p
                      className="text-2xl font-bold"
                      style={{ color: kpi.color }}
                    >
                      {kpi.value}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Top Divergence Opportunities */}
            {summary.top_opportunities?.length > 0 && (
              <div
                className="rounded-xl border overflow-hidden"
                style={{ backgroundColor: DARK_NAVY, borderColor: GOLD + "20" }}
              >
                <div
                  className="p-5 border-b flex items-center justify-between"
                  style={{ borderColor: GOLD + "20" }}
                >
                  <div className="flex items-center gap-2">
                    <Zap size={18} className="text-[#C8A882]" />
                    <h3 className="font-bold text-white">
                      Top Divergence Opportunities
                    </h3>
                  </div>
                  <span className="text-xs text-[#C8A882] bg-[#C8A882]/10 px-2 py-1 rounded-full">
                    {summary.top_opportunities.length} signals
                  </span>
                </div>
                <div className="divide-y" style={{ borderColor: NAVY }}>
                  {summary.top_opportunities.map((opp, i) => (
                    <div
                      key={i}
                      className="p-4 flex items-center gap-4 hover:bg-white/5 transition-colors cursor-pointer"
                      onClick={() => {
                        setSelectedAthlete(opp);
                        setActiveSection("divergence");
                      }}
                    >
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0"
                        style={{ backgroundColor: GOLD, color: NAVY }}
                      >
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-white text-sm">
                          {opp.name}
                        </p>
                        <p className="text-xs text-gray-400">
                          {opp.sport} · {opp.team}
                        </p>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <div className="text-center">
                          <p className="text-xs text-gray-500">Model</p>
                          <SentimentTag sentiment={opp.model_nil?.sentiment} />
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-gray-500">Market</p>
                          <SentimentTag sentiment={opp.market_nil?.sentiment} />
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-gray-500">Divergence</p>
                          <p
                            className={`font-bold text-sm ${opp.divergence.value > 0 ? "text-red-400" : "text-emerald-400"}`}
                          >
                            {opp.divergence.value > 0 ? "+" : ""}
                            {opp.divergence.value}
                          </p>
                        </div>
                        <SignalBadge signal={opp.divergence?.trading_signal} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── MODEL NIL ── */}
        {activeSection === "model-nil" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div
                className="p-3 rounded-xl"
                style={{ backgroundColor: "#10B981" + "20" }}
              >
                <Brain size={24} className="text-emerald-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  Model NIL — Performance Track
                </h2>
                <p className="text-sm text-gray-400">
                  Azure Functions → Performance Analysis → Biometric DB → Score
                  (Bull/Sideways/Bear)
                </p>
              </div>
            </div>

            {/* Score Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scores.slice(0, 12).map((s, i) => (
                <div
                  key={i}
                  onClick={() => {
                    setSelectedAthlete(s);
                    setActiveSection("divergence");
                  }}
                  className="rounded-xl border p-4 cursor-pointer hover:border-opacity-70 transition-all"
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderColor: s.model_nil.sentiment.color + "40",
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-white text-sm">
                        {s.name}
                      </p>
                      <p className="text-xs text-gray-400">
                        {s.sport} · {s.nil_tier}
                      </p>
                    </div>
                    <SentimentTag sentiment={s.model_nil.sentiment} />
                  </div>
                  {/* Score Bar */}
                  <div className="mb-3">
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-400">Model NIL Score</span>
                      <span className="font-bold text-white">
                        {s.model_nil.score}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${s.model_nil.score}%`,
                          backgroundColor: s.model_nil.sentiment.color,
                        }}
                      />
                    </div>
                  </div>
                  {/* Inputs */}
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-white/5 rounded-lg p-1.5">
                      <p className="text-gray-500">Biometric</p>
                      <p className="text-white font-bold">
                        {s.model_nil.inputs?.biometric_health || "--"}
                      </p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-1.5">
                      <p className="text-gray-500">Sessions</p>
                      <p className="text-white font-bold">
                        {s.model_nil.inputs?.session_count || 0}
                      </p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-1.5">
                      <p className="text-gray-500">Tier</p>
                      <p className="text-white font-bold text-[10px]">
                        {s.model_nil.inputs?.tier_premium || "--"}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── MARKET NIL ── */}
        {activeSection === "market-nil" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div
                className="p-3 rounded-xl"
                style={{ backgroundColor: "#60A5FA" + "20" }}
              >
                <Globe size={24} className="text-blue-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  Market NIL — Social & Market Track
                </h2>
                <p className="text-sm text-gray-400">
                  YouTube Data Ingest → Market NIL DB → Score
                  (Bull/Sideways/Bear)
                </p>
              </div>
            </div>

            {/* Market score grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scores.slice(0, 12).map((s, i) => (
                <div
                  key={i}
                  onClick={() => {
                    setSelectedAthlete(s);
                    setActiveSection("divergence");
                  }}
                  className="rounded-xl border p-4 cursor-pointer hover:opacity-90 transition-all"
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderColor: s.market_nil.sentiment.color + "40",
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-white text-sm">
                        {s.name}
                      </p>
                      <p className="text-xs text-gray-400">
                        {s.sport} · {s.team}
                      </p>
                    </div>
                    <SentimentTag sentiment={s.market_nil.sentiment} />
                  </div>
                  <div className="mb-3">
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-400">Market NIL Score</span>
                      <span className="font-bold text-white">
                        {s.market_nil.score}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${s.market_nil.score}%`,
                          backgroundColor: s.market_nil.sentiment.color,
                        }}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-white/5 rounded-lg p-1.5">
                      <p className="text-gray-500">Momentum</p>
                      <p
                        className={`font-bold ${(s.market_nil.inputs?.market_momentum || 0) > 0 ? "text-emerald-400" : "text-red-400"}`}
                      >
                        {(s.market_nil.inputs?.market_momentum || 0) > 0
                          ? "+"
                          : ""}
                        {Math.round(s.market_nil.inputs?.market_momentum || 0)}%
                      </p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-1.5">
                      <p className="text-gray-500">Confidence</p>
                      <p className="text-white font-bold">
                        {Math.round(
                          (s.market_nil.inputs?.confidence || 0.5) * 100,
                        )}
                        %
                      </p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-1.5">
                      <p className="text-gray-500">Events</p>
                      <p className="text-white font-bold">
                        {s.market_nil.inputs?.active_events || 0}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── DIVERGENCE ENGINE ── */}
        {activeSection === "divergence" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div
                className="p-3 rounded-xl"
                style={{ backgroundColor: GOLD + "20" }}
              >
                <Zap size={24} style={{ color: GOLD }} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">
                  NIL Divergence Engine
                </h2>
                <p className="text-sm text-gray-400">
                  Calculate Divergence between Model NIL and Market NIL →
                  Trading Signals
                </p>
              </div>
            </div>

            {/* Selected Athlete Detail */}
            {selectedAthlete && (
              <div
                className="rounded-2xl border p-6 mb-4"
                style={{ backgroundColor: DARK_NAVY, borderColor: GOLD + "40" }}
              >
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-xl font-bold text-white">
                      {selectedAthlete.name}
                    </h3>
                    <p className="text-sm text-gray-400">
                      {selectedAthlete.sport} · {selectedAthlete.nil_tier}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-center">
                      <p className="text-xs text-gray-400 mb-1">Model NIL</p>
                      <SentimentTag
                        sentiment={selectedAthlete.model_nil?.sentiment}
                      />
                    </div>
                    <div className="w-px h-8 bg-white/20" />
                    <div className="text-center">
                      <p className="text-xs text-gray-400 mb-1">Market NIL</p>
                      <SentimentTag
                        sentiment={selectedAthlete.market_nil?.sentiment}
                      />
                    </div>
                    <div className="w-px h-8 bg-white/20" />
                    <div className="text-center">
                      <p className="text-xs text-gray-400 mb-1">Signal</p>
                      <SignalBadge
                        signal={selectedAthlete.divergence?.trading_signal}
                      />
                    </div>
                  </div>
                </div>

                {/* Divergence Bar */}
                <div className="mb-6">
                  <div className="flex justify-between text-xs text-gray-400 mb-2">
                    <span>Model NIL: {selectedAthlete.model_nil?.score}</span>
                    <span>
                      Divergence:{" "}
                      {selectedAthlete.divergence?.value > 0 ? "+" : ""}
                      {selectedAthlete.divergence?.value}
                    </span>
                    <span>Market NIL: {selectedAthlete.market_nil?.score}</span>
                  </div>
                  <div className="relative h-5 rounded-full overflow-hidden bg-white/10">
                    <div
                      className="absolute left-0 top-0 h-full rounded-full"
                      style={{
                        width: `${selectedAthlete.model_nil?.score}%`,
                        backgroundColor: "#10B981",
                      }}
                    />
                    <div
                      className="absolute left-0 top-0 h-full rounded-full opacity-50"
                      style={{
                        width: `${selectedAthlete.market_nil?.score}%`,
                        backgroundColor: "#60A5FA",
                      }}
                    />
                    <div
                      className="absolute top-0 bottom-0 bg-[#C8A882]"
                      style={{
                        left: `${Math.min(selectedAthlete.model_nil?.score, selectedAthlete.market_nil?.score)}%`,
                        width: `${Math.abs(selectedAthlete.divergence?.value)}%`,
                        opacity: 0.7,
                      }}
                    />
                  </div>
                  <div className="flex justify-between mt-1 text-xs">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span className="text-gray-400">Model NIL</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: GOLD }}
                      />
                      <span className="text-gray-400">Divergence Gap</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-blue-400" />
                      <span className="text-gray-400">Market NIL</span>
                    </div>
                  </div>
                </div>

                {/* Radar */}
                {radarData.length > 0 && (
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="#1B3A57" />
                        <PolarAngleAxis
                          dataKey="metric"
                          tick={{ fill: "#9CA3AF", fontSize: 11 }}
                        />
                        <Radar
                          dataKey="value"
                          stroke={GOLD}
                          fill={GOLD}
                          fillOpacity={0.2}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>
            )}

            {/* Full Divergence Table */}
            <div
              className="rounded-xl border overflow-hidden"
              style={{ backgroundColor: DARK_NAVY, borderColor: NAVY }}
            >
              <div className="p-4 border-b" style={{ borderColor: NAVY }}>
                <h3 className="font-bold text-white">
                  All Athlete Divergence Scores
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b" style={{ borderColor: NAVY }}>
                      <th className="text-left p-3 text-xs font-semibold text-gray-400">
                        Athlete
                      </th>
                      <th className="text-center p-3 text-xs font-semibold text-gray-400">
                        Model NIL
                      </th>
                      <th className="text-center p-3 text-xs font-semibold text-gray-400">
                        Market NIL
                      </th>
                      <th className="text-center p-3 text-xs font-semibold text-gray-400">
                        Divergence
                      </th>
                      <th className="text-center p-3 text-xs font-semibold text-gray-400">
                        Type
                      </th>
                      <th className="text-center p-3 text-xs font-semibold text-gray-400">
                        Signal
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y" style={{ borderColor: NAVY }}>
                    {scores.map((s, i) => (
                      <tr
                        key={i}
                        className="hover:bg-white/5 cursor-pointer transition-colors"
                        onClick={() => setSelectedAthlete(s)}
                      >
                        <td className="p-3">
                          <p className="font-medium text-white text-xs">
                            {s.name}
                          </p>
                          <p className="text-xs text-gray-500">{s.sport}</p>
                        </td>
                        <td className="p-3 text-center">
                          <SentimentTag sentiment={s.model_nil.sentiment} />
                          <p className="text-xs text-gray-400">
                            {s.model_nil.score}
                          </p>
                        </td>
                        <td className="p-3 text-center">
                          <SentimentTag sentiment={s.market_nil.sentiment} />
                          <p className="text-xs text-gray-400">
                            {s.market_nil.score}
                          </p>
                        </td>
                        <td className="p-3 text-center">
                          <p
                            className={`font-bold text-sm ${s.divergence.value > 0 ? "text-blue-400" : "text-emerald-400"}`}
                          >
                            {s.divergence.value > 0 ? "+" : ""}
                            {s.divergence.value}
                          </p>
                        </td>
                        <td className="p-3 text-center">
                          <span
                            className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                              s.divergence.type === "overvalued"
                                ? "bg-red-500/20 text-red-400"
                                : s.divergence.type === "undervalued"
                                  ? "bg-emerald-500/20 text-emerald-400"
                                  : "bg-gray-500/20 text-gray-400"
                            }`}
                          >
                            {s.divergence.type}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <SignalBadge signal={s.divergence.trading_signal} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── DATA SOURCES ── */}
        {activeSection === "sources" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-white mb-4">
              Azure Data Ingestion Layer
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  icon: Wifi,
                  title: "Wearables & Sensors",
                  color: "#60A5FA",
                  status: sources.wearables?.status || "connected",
                  records: sources.wearables?.records || 0,
                  desc: "Whoop, Apple Watch, Garmin, Polar — real-time biometric streams at 30–60 Hz",
                  fields: [
                    "Heart Rate Variability",
                    "Strain Score",
                    "Recovery %",
                    "Sleep Quality",
                    "Respiratory Rate",
                  ],
                  azure: "Azure Event Hubs → Azure Stream Analytics",
                },
                {
                  icon: Activity,
                  title: "Team Performance Data",
                  color: "#10B981",
                  status: sources.team_performance?.status || "connected",
                  records: sources.team_performance?.records || 0,
                  desc: "Session logs, positional tracking, play-by-play stats from performance databases",
                  fields: [
                    "Session Duration",
                    "Performance Score",
                    "Sport Metrics",
                    "Consistency Index",
                    "Load Score",
                  ],
                  azure: "Azure SQL → Azure Functions → Model NIL DB",
                },
                {
                  icon: Youtube,
                  title: "YouTube & Social APIs",
                  color: "#EF4444",
                  status: sources.youtube_social?.status || "simulated",
                  records: sources.youtube_social?.records || 0,
                  desc: "YouTube Data API v3, Instagram Graph API, Twitter API — fan sentiment & engagement signals",
                  fields: [
                    "View Counts",
                    "Engagement Rate",
                    "Sentiment Score",
                    "Share Velocity",
                    "Subscriber Growth",
                  ],
                  azure:
                    "Azure API Management → YouTube Ingest → Market NIL DB",
                },
                {
                  icon: ShoppingBag,
                  title: "Merch & Ticket Sales",
                  color: GOLD,
                  status: sources.merch_tickets?.status || "simulated",
                  records: sources.merch_tickets?.records || 0,
                  desc: "Fanatics, Ticketmaster, StubHub APIs — commercial demand signals tied to NIL momentum",
                  fields: [
                    "Units Sold",
                    "Revenue",
                    "Demand Spike Index",
                    "Geographic Reach",
                    "Campaign Lift",
                  ],
                  azure: "Azure Logic Apps → Commerce DB → Market NIL Score",
                },
              ].map((src, i) => {
                const Icon = src.icon;
                const isConnected = src.status === "connected";
                return (
                  <div
                    key={i}
                    className="rounded-2xl border overflow-hidden"
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderColor: src.color + "30",
                    }}
                  >
                    <div
                      className="p-5 border-b flex items-center gap-3"
                      style={{ borderColor: src.color + "20" }}
                    >
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ backgroundColor: src.color + "20" }}
                      >
                        <Icon size={20} style={{ color: src.color }} />
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-white">{src.title}</p>
                        <p className="text-xs text-gray-400">{src.azure}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-2 h-2 rounded-full ${isConnected ? "bg-emerald-400" : "bg-amber-400"}`}
                        />
                        <span
                          className={`text-xs font-semibold ${isConnected ? "text-emerald-400" : "text-amber-400"}`}
                        >
                          {isConnected ? "Live" : "Simulated"}
                        </span>
                      </div>
                    </div>
                    <div className="p-5">
                      <p className="text-sm text-gray-400 mb-4">{src.desc}</p>
                      <div className="mb-4">
                        <div className="flex justify-between text-xs text-gray-400 mb-1">
                          <span>Records Ingested</span>
                          <span
                            className="font-bold"
                            style={{ color: src.color }}
                          >
                            {src.records.toLocaleString()}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/10">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${Math.min(100, (src.records / 5000) * 100)}%`,
                              backgroundColor: src.color,
                            }}
                          />
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        {src.fields.map((f, fi) => (
                          <div
                            key={fi}
                            className="flex items-center gap-2 text-xs text-gray-400"
                          >
                            <div
                              className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                              style={{ backgroundColor: src.color }}
                            />
                            {f}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
