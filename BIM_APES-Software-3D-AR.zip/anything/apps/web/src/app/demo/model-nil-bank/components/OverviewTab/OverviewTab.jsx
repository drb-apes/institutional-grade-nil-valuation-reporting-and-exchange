import { ValuePropositionCards } from "./ValuePropositionCards";
import { QuickImpactMetrics } from "./QuickImpactMetrics";
import { BankBenefits } from "./BankBenefits";

export function OverviewTab({ impactMetrics }) {
  return (
    <div className="space-y-6">
      <ValuePropositionCards />
      <QuickImpactMetrics impactMetrics={impactMetrics} />
      <BankBenefits />
    </div>
  );
}
