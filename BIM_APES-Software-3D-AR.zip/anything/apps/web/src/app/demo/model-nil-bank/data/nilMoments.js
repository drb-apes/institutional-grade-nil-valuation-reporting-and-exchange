export const nilMoments = [
  {
    id: 1,
    athlete: "Sarah Chen",
    sport: "Basketball",
    type: "Welcome Moment",
    timestamp: "2 hours ago",
    boosts: 45,
    image:
      "https://via.placeholder.com/400x300/1B3A57/FFFFFF?text=Welcome+Moment",
    description: "First NIL moment captured - Welcome to Model NIL!",
  },
  {
    id: 2,
    athlete: "Marcus Johnson",
    sport: "Track & Field",
    type: "First Highlight",
    timestamp: "5 hours ago",
    boosts: 127,
    image:
      "https://via.placeholder.com/400x300/C8A882/FFFFFF?text=First+Highlight",
    description: "Personal best in 100m sprint - 10.8 seconds!",
  },
  {
    id: 3,
    athlete: "Emily Rodriguez",
    sport: "Soccer",
    type: "Verified Metric",
    timestamp: "1 day ago",
    boosts: 89,
    image:
      "https://via.placeholder.com/400x300/1B3A57/FFFFFF?text=Verified+Metric",
    description: "Speed: 18.2 mph • Distance: 4.3 miles",
  },
  {
    id: 4,
    athlete: "Jordan Lee",
    sport: "Swimming",
    type: "Storyline Arc",
    timestamp: "2 days ago",
    boosts: 203,
    image:
      "https://via.placeholder.com/400x300/C8A882/FFFFFF?text=Storyline+Arc",
    description: "From beginner to regional champion - a 6-month journey",
  },
];
