const metrics = [
  { label: "Youth Participation", value: 95 },
  { label: "Parent Satisfaction", value: 88 },
  { label: "Community Engagement", value: 91 },
];

export function CommunityUpliftScore({ communityUplift }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Community Uplift Score
      </h3>
      <div className="relative">
        <div className="flex items-center justify-center">
          <div className="relative w-48 h-48">
            <svg className="transform -rotate-90 w-48 h-48">
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="16"
                fill="none"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="#C8A882"
                strokeWidth="16"
                fill="none"
                strokeDasharray={`${(communityUplift / 100) * 553} 553`}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center flex-col">
              <p className="text-5xl font-bold text-white">{communityUplift}</p>
              <p className="text-[#D4B896] text-sm">Uplift Score</p>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-6 space-y-3">
        {metrics.map((metric, idx) => (
          <div key={idx}>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-white">{metric.label}</span>
              <span className="text-[#C8A882]">{metric.value}%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-2">
              <div
                className="bg-[#C8A882] h-2 rounded-full transition-all"
                style={{ width: `${metric.value}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
