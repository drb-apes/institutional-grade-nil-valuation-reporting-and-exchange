import { NILMomentCard } from "./NILMomentCard";
import { BoostInteractionDemo } from "./BoostInteractionDemo";

export function NILMomentsTab({ nilMoments, setSelectedMoment }) {
  return (
    <div className="space-y-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-4">
          NIL Visibility Activations
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {nilMoments.map((moment) => (
            <NILMomentCard
              key={moment.id}
              moment={moment}
              onClick={setSelectedMoment}
            />
          ))}
        </div>
      </div>
      <BoostInteractionDemo />
    </div>
  );
}
