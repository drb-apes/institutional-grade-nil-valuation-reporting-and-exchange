import { Star, CheckCircle } from "lucide-react";

const moments = [
  {
    athlete: "Jordan Mitchell",
    sport: "Basketball",
    milestone: "College D1 Interest",
    bankAction: "Private Wealth Introduction Scheduled",
    date: "3 days ago",
  },
  {
    athlete: "Taylor Brooks",
    sport: "Track & Field",
    milestone: "Olympic Trial Qualifier",
    bankAction: "Financial Advisory Meeting Complete",
    date: "1 week ago",
  },
  {
    athlete: "Alex Rivera",
    sport: "Soccer",
    milestone: "Professional Contract Offer",
    bankAction: "Private Banking Account Opened",
    date: "2 weeks ago",
  },
];

export function ProReadinessMoments() {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Pro Readiness Moments
      </h3>
      <div className="space-y-4">
        {moments.map((moment, idx) => (
          <div
            key={idx}
            className="bg-white/5 rounded-lg p-6 border border-white/10"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#C8A882] to-[#D4B896] rounded-lg flex items-center justify-center">
                  <Star className="text-[#1B3A57]" size={24} />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg mb-1">
                    {moment.athlete}
                  </h4>
                  <p className="text-[#D4B896] text-sm mb-3">
                    {moment.sport} • {moment.milestone}
                  </p>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="text-green-400" size={16} />
                    <p className="text-green-400 text-sm font-medium">
                      {moment.bankAction}
                    </p>
                  </div>
                </div>
              </div>
              <span className="text-[#D4B896] text-xs whitespace-nowrap">
                {moment.date}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
