import { Shield, Users, TrendingUp } from "lucide-react";

const cards = [
  {
    icon: Shield,
    title: "Kids Always Free",
    description:
      "Bank-funded ecosystem ensures all youth athletes participate at zero cost to families.",
  },
  {
    icon: Users,
    title: "Parent-Safe Visibility",
    description:
      "Youth-safe content filters and parent-first communication controls throughout.",
  },
  {
    icon: TrendingUp,
    title: "CRA-Aligned Impact",
    description:
      "Community Reinvestment Act credit through measurable youth uplift programs.",
  },
];

export function ValuePropositionCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
          >
            <div className="w-12 h-12 bg-[#C8A882] rounded-lg flex items-center justify-center mb-4">
              <Icon className="text-[#1B3A57]" size={24} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">{card.title}</h3>
            <p className="text-[#D4B896]">{card.description}</p>
          </div>
        );
      })}
    </div>
  );
}
