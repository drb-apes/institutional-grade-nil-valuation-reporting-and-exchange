const engagementTypes = [
  { type: "Boosts", count: 5834, color: "#C8A882" },
  { type: "Votes", count: 2943, color: "#D4B896" },
  { type: "Shares", count: 1876, color: "#E8DCC8" },
  { type: "QR Scans", count: 891, color: "#C8A882" },
  { type: "Storyline Unlocks", count: 1303, color: "#D4B896" },
];

export function EngagementBreakdown({ totalEngagement }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Engagement Breakdown
      </h3>
      <div className="space-y-4">
        {engagementTypes.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-white font-medium">{item.type}</span>
            </div>
            <span className="text-[#C8A882] font-semibold">
              {item.count.toLocaleString()}
            </span>
          </div>
        ))}
      </div>
      <div className="mt-6 pt-6 border-t border-white/20">
        <div className="flex items-center justify-between">
          <span className="text-white font-bold text-lg">
            Total Engagements
          </span>
          <span className="text-[#C8A882] font-bold text-2xl">
            {totalEngagement.toLocaleString()}
          </span>
        </div>
      </div>
    </div>
  );
}
