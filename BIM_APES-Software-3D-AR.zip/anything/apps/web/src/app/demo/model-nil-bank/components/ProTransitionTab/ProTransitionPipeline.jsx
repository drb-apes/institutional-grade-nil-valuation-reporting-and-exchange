import { Trophy } from "lucide-react";

const stages = [
  { stage: "Verified Metrics", athletes: 34 },
  { stage: "College Recruitment", athletes: 18 },
  { stage: "NIL Deal Potential", athletes: 12 },
  { stage: "Pro Transition", athletes: 5 },
];

export function ProTransitionPipeline() {
  return (
    <div className="bg-gradient-to-br from-[#C8A882]/20 to-[#C8A882]/5 rounded-xl p-8 border border-[#C8A882]/30">
      <div className="flex items-start gap-6">
        <div className="w-16 h-16 bg-[#C8A882] rounded-xl flex items-center justify-center flex-shrink-0">
          <Trophy className="text-[#1B3A57]" size={32} />
        </div>
        <div className="flex-1">
          <h3 className="text-2xl font-bold text-white mb-3">
            Youth → Pro Transition Pipeline
          </h3>
          <p className="text-[#D4B896] mb-6">
            When athletes hit verified thresholds, the bank becomes their
            trusted advisory partner for professional transition.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {stages.map((stage, idx) => (
              <div key={idx} className="bg-white/10 rounded-lg p-4">
                <p className="text-[#C8A882] text-sm font-medium mb-2">
                  {stage.stage}
                </p>
                <p className="text-white text-3xl font-bold">
                  {stage.athletes}
                </p>
                <p className="text-[#D4B896] text-xs mt-2">athletes</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
