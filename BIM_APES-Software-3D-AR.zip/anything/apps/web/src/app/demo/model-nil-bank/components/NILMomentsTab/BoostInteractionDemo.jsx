const interactions = [
  {
    emoji: "👏",
    title: "Boost This Moment",
    description: "Fans tap to boost NIL moments",
    value: "+0.5 NIL Fair Value per boost",
  },
  {
    emoji: "🗳️",
    title: "Vote on Highlights",
    description: "Weekly highlight voting",
    value: "+2.0 NIL Fair Value per vote",
  },
  {
    emoji: "📱",
    title: "Share Youth-Safe Reels",
    description: "Parent-approved content sharing",
    value: "+3.0 NIL Fair Value per share",
  },
];

export function BoostInteractionDemo() {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-4">How Fans Engage</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {interactions.map((interaction, idx) => (
          <div key={idx} className="bg-white/5 rounded-lg p-6 text-center">
            <div className="text-6xl mb-4">{interaction.emoji}</div>
            <h4 className="text-white font-semibold mb-2">
              {interaction.title}
            </h4>
            <p className="text-[#D4B896] text-sm mb-4">
              {interaction.description}
            </p>
            <p className="text-[#C8A882] text-xs">{interaction.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
