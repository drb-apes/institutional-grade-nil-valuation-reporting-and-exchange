import { ProTransitionPipeline } from "./ProTransitionPipeline";
import { ProReadinessMoments } from "./ProReadinessMoments";
import { FinancialLiteracyProgram } from "./FinancialLiteracyProgram";

export function ProTransitionTab() {
  return (
    <div className="space-y-6">
      <ProTransitionPipeline />
      <ProReadinessMoments />
      <FinancialLiteracyProgram />
    </div>
  );
}
