import { Award, Heart } from "lucide-react";

export function MomentDetailModal({ moment, onClose }) {
  if (!moment) return null;

  return (
    <div
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-6"
      onClick={onClose}
    >
      <div
        className="bg-[#1B3A57] rounded-xl max-w-2xl w-full border border-[#C8A882]/30"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="aspect-video bg-gradient-to-br from-[#2A4A68] to-[#1B3A57] rounded-t-xl flex items-center justify-center">
          <img
            src={moment.image}
            alt={moment.type}
            className="w-full h-full object-cover rounded-t-xl"
          />
        </div>
        <div className="p-8">
          <div className="flex items-center gap-2 mb-4">
            <Award className="text-[#C8A882]" size={24} />
            <span className="text-[#C8A882] font-medium">{moment.type}</span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-2">
            {moment.athlete}
          </h3>
          <p className="text-[#D4B896] mb-4">{moment.sport}</p>
          <p className="text-white text-lg mb-6">{moment.description}</p>
          <div className="flex items-center justify-between pt-6 border-t border-white/20">
            <div className="flex items-center gap-3">
              <Heart className="text-[#C8A882]" size={24} />
              <span className="text-white font-semibold text-xl">
                {moment.boosts} boosts
              </span>
            </div>
            <button className="bg-[#C8A882] text-[#1B3A57] px-8 py-3 rounded-lg font-semibold hover:bg-[#D4B896] transition-colors">
              👏 Boost This Moment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
