import { CheckCircle } from "lucide-react";

const benefits = [
  "CRA-aligned community uplift with measurable impact",
  "Parent-safe brand visibility in youth sports",
  "Youth account pipeline for future customers",
  "NIL advisory positioning for private wealth",
  "Future high-net-worth client relationships",
];

export function BankBenefits() {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-4">Why Banks Win</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {benefits.map((benefit, idx) => (
          <div key={idx} className="flex items-start gap-3">
            <CheckCircle
              className="text-[#C8A882] mt-1 flex-shrink-0"
              size={20}
            />
            <p className="text-white">{benefit}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
