export function Header() {
  return (
    <header className="bg-white/10 backdrop-blur-lg border-b border-white/20">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">
              Model NIL × Bank Partnership
            </h1>
            <p className="text-[#D4B896] text-sm mt-1">
              Youth NIL Literacy & Community Impact Demo
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-xs text-[#D4B896]">90-Day Pilot</p>
              <p className="text-white font-semibold">Day 1 of 90</p>
            </div>
            <a
              href="/demo/launch-dashboard"
              className="bg-[#C8A882] text-[#1B3A57] px-6 py-2 rounded-lg font-semibold hover:bg-[#D4B896] transition-colors"
            >
              Launch Pilot
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
