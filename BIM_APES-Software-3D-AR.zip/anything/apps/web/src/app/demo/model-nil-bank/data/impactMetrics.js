export const impactMetrics = {
  youthActivated: 247,
  nilMoments: 1893,
  fanEngagement: 12847,
  parentEngagement: 534,
  communityUplift: 92,
};
