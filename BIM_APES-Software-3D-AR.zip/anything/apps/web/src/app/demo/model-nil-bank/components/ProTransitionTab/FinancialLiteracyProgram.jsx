const modules = [
  {
    module: "NIL Basics",
    topics: ["What is NIL?", "Rights & Ownership", "Youth vs Pro NIL"],
    completion: 78,
  },
  {
    module: "Money Management",
    topics: ["Budgeting", "Saving", "Tax Basics"],
    completion: 65,
  },
  {
    module: "Career Planning",
    topics: ["Pro Transition", "Contract Negotiation", "Long-term Wealth"],
    completion: 42,
  },
];

export function FinancialLiteracyProgram() {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Financial Literacy Program
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {modules.map((module, idx) => (
          <div key={idx} className="bg-white/5 rounded-lg p-6">
            <h4 className="text-white font-semibold text-lg mb-4">
              {module.module}
            </h4>
            <ul className="space-y-2 mb-4">
              {module.topics.map((topic, topicIdx) => (
                <li
                  key={topicIdx}
                  className="flex items-center gap-2 text-[#D4B896] text-sm"
                >
                  <div className="w-1.5 h-1.5 bg-[#C8A882] rounded-full" />
                  {topic}
                </li>
              ))}
            </ul>
            <div className="pt-4 border-t border-white/10">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-white">Completion</span>
                <span className="text-[#C8A882]">{module.completion}%</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div
                  className="bg-[#C8A882] h-2 rounded-full transition-all"
                  style={{ width: `${module.completion}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
