import { Heart, ArrowRight } from "lucide-react";

export function FanEngagementActivity({ activity }) {
  return (
    <div className="bg-white/5 rounded-lg p-6 border border-white/10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#C8A882] rounded-lg flex items-center justify-center">
            <Heart className="text-[#1B3A57]" size={24} />
          </div>
          <div>
            <h4 className="text-white font-semibold text-lg">
              {activity.type}
            </h4>
            <p className="text-[#D4B896] text-sm">
              {activity.votes && `${activity.votes} votes`}
              {activity.views && `${activity.views} views`}
              {activity.participants && `${activity.participants} participants`}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span
            className={`px-4 py-1 rounded-full text-sm font-medium ${
              activity.status === "active"
                ? "bg-green-500/20 text-green-400"
                : activity.status === "live"
                  ? "bg-blue-500/20 text-blue-400"
                  : "bg-orange-500/20 text-orange-400"
            }`}
          >
            {activity.status === "ending-soon"
              ? "Ending Soon"
              : activity.status.charAt(0).toUpperCase() +
                activity.status.slice(1)}
          </span>
          <ArrowRight className="text-[#C8A882]" size={20} />
        </div>
      </div>
    </div>
  );
}
