const challenges = [
  { name: "Teamwork Moment", icon: "🤝", participants: 89 },
  { name: "Resilience Moment", icon: "💪", participants: 67 },
  { name: "Precision Play", icon: "🎯", participants: 54 },
];

export function BankSponsoredChallenges() {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Bank-Sponsored Challenges
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {challenges.map((challenge, idx) => (
          <div
            key={idx}
            className="bg-gradient-to-br from-[#C8A882]/20 to-[#C8A882]/5 rounded-lg p-6 border border-[#C8A882]/30"
          >
            <div className="text-5xl mb-4">{challenge.icon}</div>
            <h4 className="text-white font-semibold text-lg mb-2">
              {challenge.name}
            </h4>
            <p className="text-[#D4B896] text-sm mb-4">
              {challenge.participants} athletes participating
            </p>
            <button className="w-full bg-[#C8A882] text-[#1B3A57] py-2 rounded-lg font-semibold hover:bg-[#D4B896] transition-colors">
              View Challenge
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
