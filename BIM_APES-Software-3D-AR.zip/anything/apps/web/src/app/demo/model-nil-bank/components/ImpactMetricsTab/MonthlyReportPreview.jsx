import { Users, Award, Heart, Shield } from "lucide-react";

const reportData = [
  {
    icon: Users,
    label: "New Athletes",
    value: "47",
    change: "↑ 12% from last month",
    changeColor: "text-green-400",
  },
  {
    icon: Award,
    label: "NIL Moments",
    value: "623",
    change: "↑ 28% from last month",
    changeColor: "text-green-400",
  },
  {
    icon: Heart,
    label: "Fan Interactions",
    value: "4.2K",
    change: "↑ 34% from last month",
    changeColor: "text-green-400",
  },
  {
    icon: Shield,
    label: "Parent Consent",
    value: "100%",
    change: "Full compliance",
    changeColor: "text-[#D4B896]",
  },
];

export function MonthlyReportPreview() {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Monthly Report Preview
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {reportData.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="bg-white/5 rounded-lg p-4">
              <Icon className="text-[#C8A882] mb-3" size={32} />
              <p className="text-[#D4B896] text-sm mb-1">{item.label}</p>
              <p className="text-white text-3xl font-bold">{item.value}</p>
              <p className={`${item.changeColor} text-xs mt-2`}>
                {item.change}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
