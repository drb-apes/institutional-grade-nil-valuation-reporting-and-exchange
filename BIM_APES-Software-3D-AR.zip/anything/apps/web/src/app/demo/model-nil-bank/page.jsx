"use client";

import { useState } from "react";
import { Header } from "./components/Header";
import { NavigationTabs } from "./components/NavigationTabs";
import { OverviewTab } from "./components/OverviewTab/OverviewTab";
import { NILMomentsTab } from "./components/NILMomentsTab/NILMomentsTab";
import { FanEngagementTab } from "./components/FanEngagementTab/FanEngagementTab";
import { ImpactMetricsTab } from "./components/ImpactMetricsTab/ImpactMetricsTab";
import { ProTransitionTab } from "./components/ProTransitionTab/ProTransitionTab";
import { MomentDetailModal } from "./components/MomentDetailModal";
import { impactMetrics } from "./data/impactMetrics";
import { nilMoments } from "./data/nilMoments";
import { fanEngagementActivities } from "./data/fanEngagementActivities";

export default function ModelNILBankDemo() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedMoment, setSelectedMoment] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1B3A57] to-[#152E45]">
      <Header />
      <NavigationTabs activeTab={activeTab} setActiveTab={setActiveTab} />

      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && (
          <OverviewTab impactMetrics={impactMetrics} />
        )}

        {activeTab === "nil-moments" && (
          <NILMomentsTab
            nilMoments={nilMoments}
            setSelectedMoment={setSelectedMoment}
          />
        )}

        {activeTab === "fan-engagement" && (
          <FanEngagementTab fanEngagementActivities={fanEngagementActivities} />
        )}

        {activeTab === "impact-metrics" && (
          <ImpactMetricsTab impactMetrics={impactMetrics} />
        )}

        {activeTab === "pro-transition" && <ProTransitionTab />}
      </div>

      <MomentDetailModal
        moment={selectedMoment}
        onClose={() => setSelectedMoment(null)}
      />
    </div>
  );
}
