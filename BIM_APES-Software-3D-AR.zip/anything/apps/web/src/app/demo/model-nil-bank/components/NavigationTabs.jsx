import { TrendingUp, Users, Heart, Award, Trophy } from "lucide-react";

const tabs = [
  { id: "overview", label: "Overview", icon: TrendingUp },
  { id: "nil-moments", label: "NIL Moments", icon: Award },
  { id: "fan-engagement", label: "Fan Engagement", icon: Heart },
  { id: "impact-metrics", label: "Impact Metrics", icon: Users },
  { id: "pro-transition", label: "Pro Transition", icon: Trophy },
];

export function NavigationTabs({ activeTab, setActiveTab }) {
  return (
    <div className="max-w-7xl mx-auto px-6 mt-6">
      <div className="flex gap-2 bg-white/10 backdrop-blur-lg rounded-lg p-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                activeTab === tab.id
                  ? "bg-[#C8A882] text-[#1B3A57]"
                  : "text-white hover:bg-white/10"
              }`}
            >
              <Icon size={18} />
              {tab.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
