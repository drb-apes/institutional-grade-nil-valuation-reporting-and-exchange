import { Award, Heart } from "lucide-react";

export function NILMomentCard({ moment, onClick }) {
  return (
    <div
      onClick={() => onClick(moment)}
      className="bg-white/5 rounded-lg overflow-hidden border border-white/10 hover:border-[#C8A882] transition-all cursor-pointer group"
    >
      <div className="aspect-video bg-gradient-to-br from-[#1B3A57] to-[#2A4A68] flex items-center justify-center">
        <img
          src={moment.image}
          alt={moment.type}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <Award className="text-[#C8A882]" size={16} />
          <span className="text-[#C8A882] text-sm font-medium">
            {moment.type}
          </span>
        </div>
        <h4 className="text-white font-semibold mb-1">{moment.athlete}</h4>
        <p className="text-[#D4B896] text-sm mb-3">{moment.sport}</p>
        <p className="text-white/80 text-sm mb-3">{moment.description}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="text-[#C8A882]" size={16} />
            <span className="text-white text-sm font-medium">
              {moment.boosts} boosts
            </span>
          </div>
          <span className="text-[#D4B896] text-xs">{moment.timestamp}</span>
        </div>
      </div>
    </div>
  );
}
