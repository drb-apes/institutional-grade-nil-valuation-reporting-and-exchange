export function QuickImpactMetrics({ impactMetrics }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
      <h3 className="text-xl font-bold text-white mb-6">
        Impact Metrics (Demo Data)
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
        <div>
          <p className="text-[#D4B896] text-sm mb-2">Youth Activated</p>
          <p className="text-4xl font-bold text-white">
            {impactMetrics.youthActivated}
          </p>
        </div>
        <div>
          <p className="text-[#D4B896] text-sm mb-2">NIL Moments</p>
          <p className="text-4xl font-bold text-white">
            {impactMetrics.nilMoments}
          </p>
        </div>
        <div>
          <p className="text-[#D4B896] text-sm mb-2">Fan Engagement</p>
          <p className="text-4xl font-bold text-white">
            {impactMetrics.fanEngagement.toLocaleString()}
          </p>
        </div>
        <div>
          <p className="text-[#D4B896] text-sm mb-2">Parents Engaged</p>
          <p className="text-4xl font-bold text-white">
            {impactMetrics.parentEngagement}
          </p>
        </div>
        <div>
          <p className="text-[#D4B896] text-sm mb-2">Community Score</p>
          <p className="text-4xl font-bold text-[#C8A882]">
            {impactMetrics.communityUplift}%
          </p>
        </div>
      </div>
    </div>
  );
}
