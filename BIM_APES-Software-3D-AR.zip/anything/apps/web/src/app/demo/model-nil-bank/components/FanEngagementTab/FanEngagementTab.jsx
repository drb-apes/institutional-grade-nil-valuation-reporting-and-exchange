import { FanEngagementActivity } from "./FanEngagementActivity";
import { BankSponsoredChallenges } from "./BankSponsoredChallenges";

export function FanEngagementTab({ fanEngagementActivities }) {
  return (
    <div className="space-y-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-6">
          Active Fan Engagement Activities
        </h3>
        <div className="space-y-4">
          {fanEngagementActivities.map((activity, idx) => (
            <FanEngagementActivity key={idx} activity={activity} />
          ))}
        </div>
      </div>
      <BankSponsoredChallenges />
    </div>
  );
}
