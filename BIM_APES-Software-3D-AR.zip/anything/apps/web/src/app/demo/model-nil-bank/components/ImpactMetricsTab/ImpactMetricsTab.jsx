import {
  NILValuationProgressionChart,
  RiskAdjustedPerformanceDashboard,
  BoostCreditsChart,
  KidFriendlyNILVisual,
  FanTippingFlow,
} from "@/components/BiomechFlowCapsule";
import { CommunityUpliftScore } from "./CommunityUpliftScore";
import { EngagementBreakdown } from "./EngagementBreakdown";
import { MonthlyReportPreview } from "./MonthlyReportPreview";

export function ImpactMetricsTab({ impactMetrics }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <NILValuationProgressionChart />
        <RiskAdjustedPerformanceDashboard />
        <BoostCreditsChart />
        <FanTippingFlow />
      </div>

      <div className="lg:col-span-2">
        <KidFriendlyNILVisual />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CommunityUpliftScore communityUplift={impactMetrics.communityUplift} />
        <EngagementBreakdown totalEngagement={impactMetrics.fanEngagement} />
      </div>

      <MonthlyReportPreview />
    </div>
  );
}
