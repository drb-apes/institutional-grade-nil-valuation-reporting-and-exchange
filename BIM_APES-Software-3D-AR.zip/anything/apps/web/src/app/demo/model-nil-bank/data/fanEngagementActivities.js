export const fanEngagementActivities = [
  { type: "Moment of the Week", votes: 342, status: "active" },
  { type: "Community Spotlight Reel", views: 1247, status: "live" },
  { type: "Fan Favorite Vote", votes: 189, status: "ending-soon" },
  { type: "Rising Star Leaderboard", participants: 56, status: "active" },
];
