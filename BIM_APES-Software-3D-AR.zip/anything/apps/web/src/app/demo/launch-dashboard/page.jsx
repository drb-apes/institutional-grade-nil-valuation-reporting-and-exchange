"use client";

import { useState, useEffect } from "react";
import {
  Rocket,
  CheckCircle,
  Clock,
  Users,
  Building2,
  MapPin,
  Map,
  CreditCard,
  ArrowRight,
  Calendar,
  Shield,
  Award,
  TrendingUp,
} from "lucide-react";
import {
  NILValuationProgressionChart,
  RiskAdjustedPerformanceDashboard,
  BoostCreditsChart,
  KidFriendlyNILVisual,
  FanTippingFlow,
} from "@/components/BiomechFlowCapsule";

export default function LaunchDashboard() {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedTier, setSelectedTier] = useState(null);
  const [billingPeriod, setBillingPeriod] = useState("annual");
  const [showCheckout, setShowCheckout] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [launchDate, setLaunchDate] = useState(null);

  const steps = [
    { id: 0, title: "Choose Your License", icon: Building2, status: "current" },
    { id: 1, title: "Select Billing", icon: CreditCard, status: "upcoming" },
    { id: 2, title: "Review & Launch", icon: Rocket, status: "upcoming" },
  ];

  const licensingTiers = [
    {
      id: "school",
      name: "School License",
      icon: Building2,
      description: "Perfect for individual schools and academies",
      features: [
        "Up to 500 student athletes",
        "Basic NIL moment capture",
        "Parent consent management",
        "Monthly impact reports",
        "Email support",
      ],
      pricing: {
        monthly: 299,
        annual: 2990,
      },
      popular: false,
    },
    {
      id: "district",
      name: "District License",
      icon: Users,
      description: "Ideal for school districts and multi-school programs",
      features: [
        "Up to 5,000 student athletes",
        "Advanced NIL analytics",
        "Multi-school dashboard",
        "Weekly impact reports",
        "Priority email support",
        "Custom branding",
      ],
      pricing: {
        monthly: 999,
        annual: 9990,
      },
      popular: true,
    },
    {
      id: "regional",
      name: "Regional License",
      icon: MapPin,
      description: "Designed for regional athletic associations",
      features: [
        "Up to 25,000 student athletes",
        "Full BiomechFlow analytics",
        "Multi-district coordination",
        "Daily impact reports",
        "Phone + email support",
        "API access",
        "White-label options",
      ],
      pricing: {
        monthly: 2499,
        annual: 24990,
      },
      popular: false,
    },
    {
      id: "statewide",
      name: "Statewide License",
      icon: Map,
      description: "Enterprise solution for state athletic associations",
      features: [
        "Unlimited student athletes",
        "Complete platform access",
        "State-wide coordination",
        "Real-time reporting",
        "Dedicated account manager",
        "Full API + webhooks",
        "Custom development",
        "On-site training",
      ],
      pricing: {
        monthly: 4999,
        annual: 49990,
      },
      popular: false,
    },
  ];

  const handleTierSelect = (tierId) => {
    setSelectedTier(tierId);
    setCurrentStep(1);
  };

  const handleBillingSelect = (period) => {
    setBillingPeriod(period);
    setCurrentStep(2);
  };

  const handleCheckout = async () => {
    if (!selectedTier) return;

    setProcessingPayment(true);

    try {
      const response = await fetch("/api/stripe/create-checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tier: selectedTier,
          billingPeriod,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create checkout session");
      }

      const data = await response.json();

      // Set launch date to today + 90 days
      const launch = new Date();
      launch.setDate(launch.getDate() + 90);
      setLaunchDate(launch);

      // For demo, simulate successful payment
      setTimeout(() => {
        setProcessingPayment(false);
        setShowCheckout(true);
      }, 2000);
    } catch (error) {
      console.error("Checkout error:", error);
      setProcessingPayment(false);
      alert("Payment processing failed. Please try again.");
    }
  };

  const selectedTierData = licensingTiers.find((t) => t.id === selectedTier);
  const selectedPrice = selectedTierData?.pricing[billingPeriod];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1B3A57] to-[#152E45]">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-lg border-b border-white/20">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">
                90-Day Launch Dashboard
              </h1>
              <p className="text-[#D4B896] text-sm mt-1">
                Model NIL × Bank Partnership Setup
              </p>
            </div>
            {launchDate && (
              <div className="bg-[#C8A882] text-[#1B3A57] px-6 py-2 rounded-lg font-semibold">
                Launch Date: {launchDate.toLocaleDateString()}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Progress Steps */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isComplete = currentStep > step.id;

              return (
                <div key={step.id} className="flex items-center flex-1">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                        isComplete
                          ? "bg-green-500"
                          : isActive
                            ? "bg-[#C8A882]"
                            : "bg-white/20"
                      }`}
                    >
                      {isComplete ? (
                        <CheckCircle className="text-white" size={24} />
                      ) : (
                        <Icon
                          className={
                            isActive ? "text-[#1B3A57]" : "text-white/50"
                          }
                          size={24}
                        />
                      )}
                    </div>
                    <div>
                      <p
                        className={`font-semibold ${isActive ? "text-white" : "text-white/60"}`}
                      >
                        {step.title}
                      </p>
                      <p className="text-xs text-[#D4B896]">
                        {isComplete
                          ? "Completed"
                          : isActive
                            ? "Current"
                            : "Upcoming"}
                      </p>
                    </div>
                  </div>
                  {idx < steps.length - 1 && (
                    <div className="flex-1 mx-4">
                      <div className="h-1 bg-white/20 rounded-full overflow-hidden">
                        <div
                          className={`h-1 transition-all ${
                            isComplete ? "bg-green-500 w-full" : "w-0"
                          }`}
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Step Content */}
        {currentStep === 0 && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">
              Choose Your License Tier
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {licensingTiers.map((tier) => {
                const Icon = tier.icon;
                return (
                  <div
                    key={tier.id}
                    onClick={() => handleTierSelect(tier.id)}
                    className={`bg-white/10 backdrop-blur-lg rounded-xl p-6 border-2 transition-all cursor-pointer hover:border-[#C8A882] ${
                      tier.popular ? "border-[#C8A882]" : "border-white/20"
                    }`}
                  >
                    {tier.popular && (
                      <div className="bg-[#C8A882] text-[#1B3A57] text-xs font-bold px-3 py-1 rounded-full inline-block mb-4">
                        MOST POPULAR
                      </div>
                    )}
                    <div className="w-12 h-12 bg-[#C8A882] rounded-lg flex items-center justify-center mb-4">
                      <Icon className="text-[#1B3A57]" size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">
                      {tier.name}
                    </h3>
                    <p className="text-[#D4B896] text-sm mb-4">
                      {tier.description}
                    </p>
                    <div className="mb-4">
                      <div className="flex items-baseline gap-2">
                        <span className="text-3xl font-bold text-white">
                          ${tier.pricing.monthly}
                        </span>
                        <span className="text-[#D4B896] text-sm">/month</span>
                      </div>
                      <p className="text-[#D4B896] text-xs mt-1">
                        or ${tier.pricing.annual}/year (save $
                        {tier.pricing.monthly * 12 - tier.pricing.annual})
                      </p>
                    </div>
                    <ul className="space-y-2 mb-6">
                      {tier.features.map((feature, idx) => (
                        <li
                          key={idx}
                          className="flex items-start gap-2 text-sm text-white"
                        >
                          <CheckCircle
                            className="text-[#C8A882] mt-0.5 flex-shrink-0"
                            size={16}
                          />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <button className="w-full bg-[#C8A882] text-[#1B3A57] py-3 rounded-lg font-semibold hover:bg-[#D4B896] transition-colors">
                      Select {tier.name}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {currentStep === 1 && selectedTierData && (
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-white mb-6">
              Select Billing Period
            </h2>
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 mb-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-white">
                    {selectedTierData.name}
                  </h3>
                  <p className="text-[#D4B896] text-sm">
                    {selectedTierData.description}
                  </p>
                </div>
                <button
                  onClick={() => setCurrentStep(0)}
                  className="text-[#C8A882] hover:text-[#D4B896] text-sm font-medium"
                >
                  Change Tier
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div
                  onClick={() => handleBillingSelect("monthly")}
                  className={`bg-white/5 rounded-lg p-6 border-2 cursor-pointer transition-all ${
                    billingPeriod === "monthly"
                      ? "border-[#C8A882]"
                      : "border-white/10"
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <Calendar className="text-[#C8A882]" size={32} />
                    {billingPeriod === "monthly" && (
                      <CheckCircle className="text-[#C8A882]" size={24} />
                    )}
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">
                    Monthly Billing
                  </h4>
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-4xl font-bold text-white">
                      ${selectedTierData.pricing.monthly}
                    </span>
                    <span className="text-[#D4B896]">/month</span>
                  </div>
                  <p className="text-[#D4B896] text-sm">
                    Flexible monthly payments
                  </p>
                </div>

                <div
                  onClick={() => handleBillingSelect("annual")}
                  className={`bg-white/5 rounded-lg p-6 border-2 cursor-pointer transition-all ${
                    billingPeriod === "annual"
                      ? "border-[#C8A882]"
                      : "border-white/10"
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <Calendar className="text-[#C8A882]" size={32} />
                    {billingPeriod === "annual" && (
                      <CheckCircle className="text-[#C8A882]" size={24} />
                    )}
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">
                    Annual Billing
                  </h4>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-4xl font-bold text-white">
                      ${selectedTierData.pricing.annual}
                    </span>
                    <span className="text-[#D4B896]">/year</span>
                  </div>
                  <div className="bg-green-500/20 text-green-400 text-xs font-bold px-3 py-1 rounded-full inline-block mb-2">
                    SAVE $
                    {selectedTierData.pricing.monthly * 12 -
                      selectedTierData.pricing.annual}
                  </div>
                  <p className="text-[#D4B896] text-sm">
                    Best value - 2 months free
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentStep === 2 && selectedTierData && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-white mb-6">
              Review & Launch Your 90-Day Pilot
            </h2>

            {!showCheckout ? (
              <>
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 mb-6">
                  <h3 className="text-xl font-bold text-white mb-4">
                    Order Summary
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between pb-4 border-b border-white/20">
                      <div>
                        <p className="text-white font-semibold">
                          {selectedTierData.name}
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          {billingPeriod === "annual" ? "Annual" : "Monthly"}{" "}
                          billing
                        </p>
                      </div>
                      <p className="text-2xl font-bold text-white">
                        ${selectedPrice}
                      </p>
                    </div>
                    <div>
                      <p className="text-white font-semibold mb-2">
                        Included Features:
                      </p>
                      <ul className="space-y-2">
                        {selectedTierData.features.map((feature, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-2 text-sm text-[#D4B896]"
                          >
                            <CheckCircle
                              className="text-[#C8A882] mt-0.5 flex-shrink-0"
                              size={16}
                            />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 mb-6">
                  <h3 className="text-xl font-bold text-white mb-4">
                    90-Day Pilot Timeline
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-[#C8A882] rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-[#1B3A57] font-bold text-sm">
                          1
                        </span>
                      </div>
                      <div>
                        <p className="text-white font-semibold">
                          Days 1-30: Onboarding
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          Setup accounts, parent consent, first NIL moments
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-[#C8A882] rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-[#1B3A57] font-bold text-sm">
                          2
                        </span>
                      </div>
                      <div>
                        <p className="text-white font-semibold">
                          Days 31-60: Engagement
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          Fan boosts, challenges, bank visibility activations
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-[#C8A882] rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-[#1B3A57] font-bold text-sm">
                          3
                        </span>
                      </div>
                      <div>
                        <p className="text-white font-semibold">
                          Days 61-90: Impact Report
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          Community uplift metrics, ROI analysis, renewal
                          decision
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="flex-1 bg-white/10 text-white py-4 rounded-lg font-semibold hover:bg-white/20 transition-colors"
                  >
                    Back to Billing
                  </button>
                  <button
                    onClick={handleCheckout}
                    disabled={processingPayment}
                    className="flex-1 bg-[#C8A882] text-[#1B3A57] py-4 rounded-lg font-semibold hover:bg-[#D4B896] transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {processingPayment ? (
                      <>
                        <div className="w-5 h-5 border-2 border-[#1B3A57] border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        Launch 90-Day Pilot
                        <Rocket size={20} />
                      </>
                    )}
                  </button>
                </div>
              </>
            ) : (
              <div className="space-y-6">
                <div className="bg-gradient-to-br from-green-500/20 to-green-500/5 rounded-xl p-8 border border-green-500/30 text-center">
                  <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="text-white" size={40} />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-2">
                    🎉 Pilot Launched Successfully!
                  </h3>
                  <p className="text-[#D4B896] text-lg mb-6">
                    Your 90-day Model NIL pilot starts today
                  </p>
                  <div className="bg-white/10 rounded-lg p-4 max-w-md mx-auto">
                    <p className="text-white font-semibold mb-1">Launch Date</p>
                    <p className="text-[#C8A882] text-2xl font-bold">
                      {launchDate &&
                        launchDate.toLocaleDateString("en-US", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                    </p>
                  </div>
                </div>

                {/* BiomechFlow Visualizations */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <NILValuationProgressionChart />
                  <RiskAdjustedPerformanceDashboard />
                  <BoostCreditsChart />
                  <FanTippingFlow />
                </div>

                <div className="lg:col-span-2">
                  <KidFriendlyNILVisual />
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                  <h3 className="text-xl font-bold text-white mb-4">
                    Next Steps
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-4 bg-white/5 rounded-lg">
                      <CheckCircle className="text-green-400" size={24} />
                      <div>
                        <p className="text-white font-semibold">
                          Confirmation email sent
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          Check your inbox for setup instructions
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-white/5 rounded-lg">
                      <Clock className="text-[#C8A882]" size={24} />
                      <div>
                        <p className="text-white font-semibold">
                          Onboarding call scheduled
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          We'll reach out within 24 hours
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-white/5 rounded-lg">
                      <Award className="text-[#C8A882]" size={24} />
                      <div>
                        <p className="text-white font-semibold">
                          Access dashboard
                        </p>
                        <p className="text-[#D4B896] text-sm">
                          Your admin panel is ready to use
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <a
                    href="/demo/model-nil-bank"
                    className="flex-1 bg-[#C8A882] text-[#1B3A57] py-4 rounded-lg font-semibold hover:bg-[#D4B896] transition-colors text-center flex items-center justify-center gap-2"
                  >
                    Go to Main Dashboard
                    <ArrowRight size={20} />
                  </a>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
