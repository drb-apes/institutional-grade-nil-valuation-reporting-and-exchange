"use client";

import { useState, useEffect } from "react";
import {
  NILValuationProgressionChart,
  RiskAdjustedPerformanceDashboard,
  BoostCreditsChart,
  KidFriendlyNILVisual,
  FanTippingFlow,
} from "@/components/BiomechFlowCapsule";
import { RefreshCw, Users, TrendingUp, Activity, Zap } from "lucide-react";

export default function BiomechCapsulesDemo() {
  const [loading, setLoading] = useState(true);
  const [athletes, setAthletes] = useState([]);
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [nilData, setNilData] = useState(null);
  const [biometricData, setBiometricData] = useState(null);
  const [fanEngagement, setFanEngagement] = useState(null);
  const [seedingData, setSeedingData] = useState(false);

  // Fetch athletes on load
  useEffect(() => {
    fetchAthletes();
  }, []);

  // Fetch athlete data when selected
  useEffect(() => {
    if (selectedAthlete) {
      fetchAthleteData(selectedAthlete.id);
    }
  }, [selectedAthlete]);

  const fetchAthletes = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/athletes?limit=10");
      const data = await response.json();

      if (data.success && data.athletes.length > 0) {
        setAthletes(data.athletes);
        setSelectedAthlete(data.athletes[0]);
      }
    } catch (error) {
      console.error("Error fetching athletes:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAthleteData = async (athleteId) => {
    try {
      // Fetch NIL data
      const nilResponse = await fetch(`/api/nil/athlete/${athleteId}?days=90`);
      const nilResult = await nilResponse.json();
      if (nilResult.success) {
        setNilData(nilResult);
      }

      // Fetch biometric data
      const bioResponse = await fetch(
        `/api/biometrics/athlete/${athleteId}?days=7`,
      );
      const bioResult = await bioResponse.json();
      if (bioResult.success) {
        setBiometricData(bioResult);
      }

      // Fetch fan engagement
      const fanResponse = await fetch(
        `/api/fan-engagement/metrics?athleteId=${athleteId}&days=30`,
      );
      const fanResult = await fanResponse.json();
      if (fanResult.success) {
        setFanEngagement(fanResult);
      }
    } catch (error) {
      console.error("Error fetching athlete data:", error);
    }
  };

  const seedDemoData = async () => {
    try {
      setSeedingData(true);
      const response = await fetch("/api/demo/seed-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ count: 10, sport: "Basketball" }),
      });

      const result = await response.json();
      if (result.success) {
        alert(
          `Successfully seeded ${result.summary.athletes} athletes with biometric and NIL data!`,
        );
        fetchAthletes();
      }
    } catch (error) {
      console.error("Error seeding data:", error);
      alert("Error seeding demo data");
    } finally {
      setSeedingData(false);
    }
  };

  const recordBoost = async () => {
    if (!selectedAthlete) return;

    try {
      await fetch("/api/fan-engagement/metrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          athlete_id: selectedAthlete.id,
          engagement_type: "boost",
          engagement_value: 1,
        }),
      });

      // Refresh engagement data
      fetchAthleteData(selectedAthlete.id);
      alert("Boost recorded!");
    } catch (error) {
      console.error("Error recording boost:", error);
    }
  };

  // Prepare chart data from API responses
  const nilChartData = nilData?.age_progression || [];

  const biometricRadarData =
    biometricData?.summary?.slice(0, 6).map((s) => ({
      metric: s.index_name || s.index_code,
      value: Math.round(s.avg_score),
      fullMark: 100,
    })) || [];

  const boostChartData = fanEngagement
    ? [
        {
          athlete:
            selectedAthlete?.first_name + " " + selectedAthlete?.last_name,
          boosts: fanEngagement.engagement_summary?.total_boosts || 0,
        },
      ]
    : [];

  const tippingFlowData = fanEngagement?.tipping_flow || {
    totalBoosts: 0,
    nilMoments: 0,
    sponsorBonuses: 0,
    athleteRewards: 0,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1B3A57] via-[#152E45] to-[#1B3A57]">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-lg border-b border-[#C8A882]/30">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                BiomechFlow Capsule Dashboard
              </h1>
              <p className="text-[#D4B896]">
                Real-time athlete analytics & NIL visualization
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={seedDemoData}
                disabled={seedingData}
                className="px-4 py-2 bg-[#C8A882] text-[#1B3A57] rounded-lg font-semibold hover:bg-[#D4B896] transition-all flex items-center gap-2 disabled:opacity-50"
              >
                <Users size={18} />
                {seedingData ? "Seeding..." : "Seed Demo Data"}
              </button>
              <button
                onClick={fetchAthletes}
                disabled={loading}
                className="px-4 py-2 bg-white/10 text-white rounded-lg font-semibold hover:bg-white/20 transition-all flex items-center gap-2"
              >
                <RefreshCw
                  size={18}
                  className={loading ? "animate-spin" : ""}
                />
                Refresh
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Athlete Selector */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">Select Athlete</h2>
            <div className="flex gap-2 items-center text-[#D4B896]">
              <Activity size={18} />
              <span>{athletes.length} Active Athletes</span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {athletes.map((athlete) => (
              <button
                key={athlete.id}
                onClick={() => setSelectedAthlete(athlete)}
                className={`p-4 rounded-lg text-left transition-all ${
                  selectedAthlete?.id === athlete.id
                    ? "bg-[#C8A882] text-[#1B3A57]"
                    : "bg-white/5 text-white hover:bg-white/10"
                }`}
              >
                <div className="font-semibold">
                  {athlete.first_name} {athlete.last_name}
                </div>
                <div className="text-sm opacity-80">{athlete.sport}</div>
                <div className="text-xs mt-1 opacity-60">
                  {athlete.nil_tier}
                </div>
              </button>
            ))}
          </div>

          {selectedAthlete && (
            <div className="mt-4 pt-4 border-t border-white/20">
              <div className="flex items-center justify-between">
                <div className="text-white">
                  <div className="text-sm text-[#D4B896] mb-1">
                    Current NIL Value
                  </div>
                  <div className="text-2xl font-bold">
                    ${selectedAthlete.current_nil_value || 0}K
                  </div>
                </div>
                <button
                  onClick={recordBoost}
                  className="px-6 py-3 bg-gradient-to-r from-[#C8A882] to-[#D4B896] text-[#1B3A57] rounded-lg font-bold hover:scale-105 transition-all flex items-center gap-2"
                >
                  <Zap size={20} fill="currentColor" />
                  Give Boost
                </button>
              </div>
            </div>
          )}
        </div>

        {/* BiomechFlow Visualizations */}
        {selectedAthlete && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* NIL Valuation Progression */}
            <div className="lg:col-span-2">
              <NILValuationProgressionChart data={nilChartData} />
            </div>

            {/* Risk-Adjusted Performance */}
            <RiskAdjustedPerformanceDashboard data={biometricRadarData} />

            {/* Kid-Friendly NIL Visual */}
            <KidFriendlyNILVisual athlete={selectedAthlete} />

            {/* Boost Credits */}
            <BoostCreditsChart data={boostChartData} />

            {/* Fan Tipping Flow */}
            <FanTippingFlow data={tippingFlowData} />
          </div>
        )}

        {!selectedAthlete && !loading && (
          <div className="text-center py-12 text-[#D4B896]">
            <TrendingUp size={48} className="mx-auto mb-4 opacity-50" />
            <p className="text-lg">
              Select an athlete to view BiomechFlow capsules
            </p>
            <p className="text-sm mt-2">Or seed demo data to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}
