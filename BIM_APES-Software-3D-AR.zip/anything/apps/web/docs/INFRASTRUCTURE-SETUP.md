# BIM-APES Infrastructure Setup Guide

## 🎯 Overview
This guide will help you deploy the complete BIM-APES system with all high-priority features:
- Sports-specific modules (Wrestling, Tennis, Football, Tactical)
- Wearables integration (Whoop, Garmin, Apple Watch)
- Trading system (Mispricing detection, Arbitrage, Scalping)
- AR overlay system

---

## 📋 Prerequisites

### Required Accounts
- ✅ Anything platform account (you're already here!)
- ⚠️ Whoop API access (for wearables)
- ⚠️ Garmin Developer account (for wearables)
- ⚠️ Apple Developer account (for HealthKit)

### Environment Variables Already Set
The following are already configured in your Anything project:
- `DATABASE_URL` - PostgreSQL connection
- `NEXT_PUBLIC_CREATE_APP_URL` - Base URL
- `AWS_*` - S3 credentials for data storage

---

## 🗄️ Database Setup

### 1. Core Schema (Already Created)
Your database already has these tables:
- `athletes`
- `biometric_readings`
- `biometric_index_definitions`
- `nil_valuations`
- `mispricing_events`
- `trading_positions`
- `performance_sessions`
- `sport_specific_metrics`

### 2. Add Wearables Table
Run this migration via the Anything console:

```sql
CREATE TABLE IF NOT EXISTS wearable_connections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  provider VARCHAR(50) NOT NULL,
  access_token TEXT,
  refresh_token TEXT,
  connected_at TIMESTAMP DEFAULT NOW(),
  last_sync_at TIMESTAMP,
  UNIQUE(athlete_id, provider)
);

CREATE INDEX idx_wearable_athlete ON wearable_connections(athlete_id);
CREATE INDEX idx_wearable_provider ON wearable_connections(provider);
```

---

## 🔌 Wearables Integration Setup

### Whoop Setup

1. **Get API Credentials**
   - Go to https://developer.whoop.com
   - Create an application
   - Note your `CLIENT_ID` and `CLIENT_SECRET`

2. **Add Environment Variables**
   In your Anything project settings, add:
   ```
   WHOOP_CLIENT_ID=your_whoop_client_id
   WHOOP_CLIENT_SECRET=your_whoop_client_secret
   ```

3. **Configure OAuth Redirect**
   Add this redirect URI in Whoop dashboard:
   ```
   https://your-app-url.anything.com/api/wearables/whoop/sync
   ```

### Garmin Setup

1. **Get API Credentials**
   - Go to https://developer.garmin.com
   - Create an application
   - Note your `CONSUMER_KEY` and `CONSUMER_SECRET`

2. **Add Environment Variables**
   ```
   GARMIN_CONSUMER_KEY=your_garmin_consumer_key
   GARMIN_CONSUMER_SECRET=your_garmin_consumer_secret
   ```

3. **Configure OAuth Callback**
   ```
   https://your-app-url.anything.com/api/wearables/garmin/sync
   ```

### Apple Watch (HealthKit)

1. **Mobile App Setup**
   - Enable HealthKit in your Expo app capabilities
   - Request these permissions:
     - Heart Rate
     - HRV
     - Active Energy
     - Steps
     - Distance

2. **Sync Endpoint**
   Mobile app will POST to:
   ```
   /api/wearables/apple-watch/sync
   ```

---

## 🧪 Testing Your Setup

### 1. Use the Test Harness

Navigate to `/test-harness` in your deployed app and run:

1. **Seed Athletes** - Creates 10 test athletes
2. **Seed Biometrics** - Generates 50 biometric readings
3. **Wrestling Module** - Tests sport-specific tracking
4. **Mispricing Detection** - Tests trading engine
5. **AR Package** - Tests overlay generation

### 2. Manual API Testing

Test each endpoint individually:

```bash
# Test NIL Valuation
curl -X POST https://your-app-url/api/nil-valuation/calculate \
  -H "Content-Type: application/json" \
  -d '{"athlete_id": "YOUR_ATHLETE_ID"}'

# Test Mispricing Detection
curl -X POST https://your-app-url/api/trading/detect-mispricing \
  -H "Content-Type: application/json" \
  -d '{"athlete_id": "YOUR_ATHLETE_ID"}'

# Test Wrestling Module
curl -X POST https://your-app-url/api/sport-specific/wrestling/performance-tracking \
  -H "Content-Type: application/json" \
  -d '{
    "athlete_id": "YOUR_ATHLETE_ID",
    "session_id": "test-session",
    "match_data": {
      "takedowns_attempted": 12,
      "takedowns_successful": 8,
      "grip_force_peak_n": 450,
      "stance_stability_score": 82,
      "explosive_power_index": 88,
      "technique_precision_pct": 76,
      "match_duration_seconds": 360
    }
  }'
```

---

## 📱 Mobile App Deployment

### iOS Setup

1. **Configure App Store Connect**
   - Create app in App Store Connect
   - Enable HealthKit capability
   - Configure push notifications (if using)

2. **Build & Submit**
   ```bash
   cd apps/mobile
   eas build --platform ios
   eas submit --platform ios
   ```

### Android Setup

1. **Configure Google Play Console**
   - Create app listing
   - Configure permissions

2. **Build & Submit**
   ```bash
   eas build --platform android
   eas submit --platform android
   ```

---

## 🚀 Production Checklist

### Pre-Launch
- [ ] All environment variables set
- [ ] Database schema migrated
- [ ] Wearable OAuth configured
- [ ] Test harness passing all tests
- [ ] Mobile app submitted to stores

### Post-Launch Monitoring
- [ ] Monitor `/api/dashboard/summary` for real-time stats
- [ ] Check mispricing event creation rate
- [ ] Verify wearable sync frequency
- [ ] Monitor biometric reading ingestion

### Performance Targets
- **API Response Time**: < 500ms (95th percentile)
- **Database Queries**: < 100ms average
- **AR Overlay Generation**: < 200ms
- **Wearable Sync**: Every 5-15 minutes

---

## 🔧 Troubleshooting

### Database Connection Issues
```bash
# Verify connection
psql $DATABASE_URL -c "SELECT COUNT(*) FROM athletes;"
```

### Wearable Sync Failing
1. Check OAuth tokens in `wearable_connections` table
2. Verify redirect URIs match exactly
3. Check API rate limits

### Trading System Not Detecting Mispricing
1. Ensure NIL valuations are being calculated
2. Check confidence threshold (default 0.75)
3. Verify gap percentage threshold (default 10%)

### AR Overlay Not Rendering
1. Check `/api/broadcast/ar-package` response
2. Verify athlete has recent biometric readings
3. Check `session_id` is active

---

## 📊 Monitoring Dashboard

Access real-time metrics at:
- **Main Console**: