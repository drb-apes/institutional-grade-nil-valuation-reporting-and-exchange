# BIM-APES Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Seed Your Database
Navigate to the **Test Harness** at `/test-harness` and click:

1. **"Run Full Test Suite"** - This will:
   - Create 50 sample athletes
   - Generate 48 hours of biometric data
   - Test all sport modules
   - Test trading system
   - Test AR overlays

### Step 2: Explore the Dashboards

Once seeded, visit these dashboards:

- **`/console`** - Main command center with real-time stats
- **`/console/athletes`** - View all athletes and their metrics
- **`/console/ar-views`** - AR overlay previews
- **`/intelligence-dashboard`** - Intelligence analytics
- **`/coach-dashboard`** - Coaching interface
- **`/investor-dashboard`** - Trading and NIL valuation

### Step 3: Test Sport-Specific Modules

From the console, click on any sport module:

- **Wrestling** - Takedown efficiency, grip force, technique precision
- **Tennis/Pickleball** - Rally intensity, spike analysis
- **American Football** - Consistency monitoring
- **Tactical Sports** (Rugby/Soccer/Basketball) - Team shape, spacing

### Step 4: Test the Trading System

1. Go to `/console/athletes` and select an athlete
2. View their NIL valuation
3. If there's a mispricing window (gap > 10%), you'll see:
   - Gap percentage
   - Direction (LONG or SHORT)
   - Confidence score
   - Time-to-live (TTL)
   - Trade recommendation

### Step 5: Connect Wearables (Optional)

To integrate real athlete data:

1. Set up environment variables (see `INFRASTRUCTURE-SETUP.md`)
2. Athletes can connect:
   - Whoop: `/api/wearables/whoop/connect`
   - Garmin: `/api/wearables/garmin/connect`
   - Apple Watch: Via mobile app

---

## 📱 Mobile App

The mobile app is located at `/apps/mobile/src/app/`

### Running Locally

```bash
cd apps/mobile
npx expo start
```

### Features
- Real-time athlete dashboard
- Biometric monitoring
- Mispricing alerts
- Sport module quick access

---

## 🧪 Testing Individual APIs

### NIL Valuation
```bash
curl -X POST https://your-app/api/nil-valuation/calculate \
  -H "Content-Type: application/json" \
  -d '{"athlete_id": "ATHLETE_ID"}'
```

### Mispricing Detection
```bash
curl -X POST https://your-app/api/trading/detect-mispricing \
  -H "Content-Type: application/json" \
  -d '{"athlete_id": "ATHLETE_ID"}'
```

### Wrestling Performance
```bash
curl -X POST https://your-app/api/sport-specific/wrestling/performance-tracking \
  -H "Content-Type: application/json" \
  -d '{
    "athlete_id": "ATHLETE_ID",
    "session_id": "session-1",
    "match_data": {
      "takedowns_attempted": 12,
      "takedowns_successful": 8,
      "grip_force_peak_n": 450,
      "stance_stability_score": 82,
      "explosive_power_index": 88,
      "technique_precision_pct": 76,
      "match_duration_seconds": 360
    }
  }'
```

---

## 🎯 Next Steps

1. **Customize Sport Modules** - Add your own sport-specific metrics
2. **Configure Wearables** - Connect real athlete devices
3. **Tune Trading Algorithms** - Adjust thresholds and strategies
4. **Design Custom AR Overlays** - Modify the AR package generator
5. **Deploy to Production** - See `INFRASTRUCTURE-SETUP.md`

---

## 📚 Documentation

- **API Endpoints**: `/apps/web/docs/BIM-APES-API-CONTRACTS.md`
- **Method Integration**: `/apps/web/docs/DASHBOARD-METHOD-INTEGRATION.md`
- **Data Library**: `/apps/web/docs/DATA-LIBRARY-GUIDE.md`
- **Full Setup**: `/apps/web/docs/INFRASTRUCTURE-SETUP.md`

---

## 🆘 Troubleshooting

**No athletes showing?**
- Run the test harness seed functions

**Mispricing not detecting?**
- Ensure NIL valuations are being calculated
- Check confidence threshold (default: 0.75)
- Verify gap percentage > 10%

**AR overlay not loading?**
- Check athlete has recent biometric readings
- Verify session_id is active

**Wearable sync failing?**
- Verify OAuth credentials
- Check redirect URIs match
- Confirm API rate limits

---

**Ready to build? Head to `/test-harness` and click "Run Full Test Suite"!** 🚀
