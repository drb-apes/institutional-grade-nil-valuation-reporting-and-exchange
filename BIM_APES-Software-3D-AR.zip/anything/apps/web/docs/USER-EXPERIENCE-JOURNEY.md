# BIM-APES Platform User Experience Journey
## Complete Web & Mobile Flow

---

## 🌐 **WEB PLATFORM EXPERIENCE**

### **Entry Point: Homepage (/**)**
**Experience:** Professional landing page
- Navy/gold BLEDSOE branding
- Multi-language selector (10 languages)
- Clear value proposition cards
- Dashboard access buttons

**User Actions:**
1. Select preferred language
2. Explore platform capabilities
3. Navigate to specific dashboard

---

### **Console Admin Dashboard (/console)**
**For:** Platform administrators, team managers

**Experience Flow:**
1. **Login** → Secure authentication
2. **Dashboard Overview:**
   - Active athletes count
   - Live events
   - Critical alerts
   - NIL volume metrics
3. **Navigation:**
   - Athletes management
   - Events tracking
   - AR/XR configuration
   - Medical monitoring
   - Reports & analytics

**Key Features:**
- Real-time data refresh (30s intervals)
- Dark theme with navy/gold accents
- Responsive grid layouts
- Quick action buttons

---

### **Intelligence Dashboard (/intelligence-dashboard)**
**For:** Coaches, medical staff, performance analysts

**Experience Flow:**
1. **Load athlete intelligence** (5 engines in parallel)
2. **View critical alerts** (if any)
3. **Review intelligence cards:**
   - Stress Intelligence
   - Fatigue Intelligence
   - Recovery Intelligence
   - Training Intelligence
   - Market Intelligence
4. **Interact with AR overlays**
5. **Analyze biomechanical flow charts**

**Data Sources:**
- Real-time biometric readings
- Historical performance data
- Market signals
- Training load metrics

**User Insights:**
- Color-coded severity (red/yellow/green)
- Percentage scores (0-100)
- Trend indicators
- Actionable recommendations

---

### **Coach Dashboard (/coach-dashboard)**
**For:** Athletic coaches, team coordinators

**Experience Flow:**
1. **Team overview** with athlete cards
2. **Performance metrics** grid
3. **Training load management**
4. **AR coaching overlays**
5. **Session planning tools**

**Real-time Features:**
- Athlete readiness scores
- Fatigue alerts
- NIL momentum tracking
- Tactical efficiency analysis

---

### **Investor Dashboard (/investor-dashboard)**
**For:** NIL investors, sponsors, coalition partners

**Experience Flow:**
1. **Portfolio Summary:**
   - Total value
   - P&L tracking
   - Active positions
   - Risk score
2. **Four View Modes:**
   - **Overview:** Top opportunities + mispricing windows
   - **Valuations:** NIL valuation matrix (all athletes)
   - **Trading:** Real-time trading signals
   - **Positions:** Active trading positions

**Investment Tools:**
- Mispricing detection (arbitrage, scalping, hedge)
- Confidence scoring (0-100%)
- Time-to-live (TTL) countdown
- Execute trade buttons

**Dark Theme Issue:** ⚠️ Currently has bg-gray-50 cards - NEEDS FIX

---

### **Federation Dashboard (/federation-dashboard)**
**For:** Sports federations, league operators

**Experience Flow:**
1. **Coalition Metrics:**
   - Total athletes across federation
   - Active coalition members
   - Tier breakdown (I, II, III)
   - Biometric consent rate
   - Sport distribution
2. **Four View Modes:**
   - **Overview:** Sport/tier distribution
   - **Athletes:** Searchable athlete list
   - **Coalitions:** Partnership management
   - **Expansion:** Global growth tracking

**Management Tools:**
- Sport filtering
- Tier classification
- Consent tracking
- Certificate issuance

**Dark Theme Issue:** ⚠️ Tier II (bg-blue-50) and Tier III (bg-gray-100) - NEEDS FIX

---

### **XR Lab (/xr-lab)**
**For:** Broadcast producers, AR/VR developers

**Experience Flow:**
1. **Start real-time stream** (select athletes)
2. **Configure broadcast displays:**
   - Jumbotron
   - Lower third
   - Sideline displays
3. **View live metrics** (SSI/CIS/ARC)
4. **Push content to stadium**
5. **Access VR documentation**

**Technical Outputs:**
- Server-Sent Events (SSE) at 30Hz
- 3D athlete positions
- Biometric overlays
- Broadcast control commands

---

### **Broadcast Control (/broadcast-control)**
**For:** Broadcast directors, stadium operators

**Experience Flow:**
1. Select athlete
2. Choose display type
3. Select content type
4. Set duration
5. Push to display
6. Monitor active broadcasts

---

## 📱 **MOBILE APP EXPERIENCE**

### **Entry: App Launch**
1. **Splash screen** (BLEDSOE branding)
2. **Auth check** (if required)
3. **Navigate to home tab**

---

### **Home Tab (/(tabs)/index)**
**Experience:**
- Medical intelligence dashboard style
- **Stats Grid:** (2x2)
  - Critical alerts
  - Athletes monitored
  - Recovery rate
  - Active sessions
- **Critical Alert Banner** (if active)
- **Athlete List** with risk pills
- **AR Methods List**
- **Pull-to-refresh**

**User Actions:**
- Tap athlete → View details
- Tap method → Learn more
- Pull down → Refresh data

---

### **Dashboard Tab (/(tabs)/dashboard)**
**Experience:**
- Platform summary view
- **Stats Grid:** (2x2)
  - Active athletes
  - Live events
  - Mispricing windows
  - NIL volume
- **Active Mispricing** list (with TTL countdown)
- **Sport Modules** grid
- **Pull-to-refresh**

**User Actions:**
- Tap mispricing card → Trade details
- Tap module → Open feature
- Pull down → Refresh data

---

### **Future Tabs (Trading & Settings)**
**Status:** Stubbed in tab navigator with `href: null`

**Planned Experience:**
- **Trading Tab:** Mobile trading interface
- **Settings Tab:** Language, preferences, notifications

---

### **Mobile Navigation Pattern**
- **Bottom tab bar** (navy bg, gold active state)
- **No headers** (screens implement own headers)
- **Safe area handling** (top notch + bottom bar)
- **Dark theme** throughout

---

## 🎯 **USER JOURNEY EXAMPLES**

### **Journey 1: Coach Monitoring Athlete Fatigue**
1. Open **Intelligence Dashboard** (web or mobile)
2. View **Fatigue Intelligence** card (red/yellow/green)
3. See critical alert: "Stride shortening detected"
4. Click **AR Biomech Overlay** → View joint-level analysis
5. Make decision: Reduce training load
6. Log decision in system

**Time:** 2-3 minutes
**Touchpoints:** Intelligence Dashboard → AR Overlay → Action

---

### **Journey 2: Investor Executing Trade**
1. Open **Investor Dashboard** (web)
2. Navigate to **Trading** tab
3. See active mispricing window:
   - Gap: $45.20
   - Confidence: 87%
   - TTL: 12 minutes
4. Review athlete metrics
5. Click **Execute Long Position**
6. Confirm trade
7. Monitor in **Positions** tab

**Time:** 3-5 minutes
**Touchpoints:** Dashboard → Trading → Execution → Confirmation

---

### **Journey 3: Federation Managing Coalition**
1. Open **Federation Dashboard** (web)
2. Filter by sport (e.g., "American Football")
3. Review tier distribution
4. Identify Tier II athlete ready for upgrade
5. Navigate to **Athletes** tab
6. Update athlete tier
7. Issue new coalition certificate

**Time:** 5-7 minutes
**Touchpoints:** Dashboard → Filter → Update → Certificate

---

### **Journey 4: Broadcast Producer Pushing Live Metrics**
1. Open **XR Lab** (web)
2. Click **Start Stream**
3. Select 3 athletes
4. Choose **Jumbotron** display
5. Select **Live Metrics** content
6. Set duration: 8 seconds
7. Push to stadium
8. Monitor live broadcast

**Time:** 1-2 minutes
**Touchpoints:** XR Lab → Stream → Configure → Push

---

## 🌍 **MULTI-LANGUAGE EXPERIENCE**

**Supported Languages:**
🇬🇧 English | 🇪🇸 Español | 🇫🇷 Français | 🇩🇪 Deutsch | 🇮🇹 Italiano | 🇵🇹 Português | 🇨🇳 中文 | 🇯🇵 日本語 | 🇸🇦 العربية | 🇷🇺 Русский

**Translation Flow:**
1. User selects language from dropdown
2. Preference saved to localStorage (web) / AsyncStorage (mobile)
3. All static text auto-translates via Google Translate
4. Dynamic content (athlete names, alerts) translates on demand
5. Translation cache prevents redundant API calls

**User Experience:**
- **Instant language switch** (no page reload)
- **Persistent preference** (saved for next visit)
- **Cached translations** (fast subsequent loads)
- **Visible in header** (language selector always accessible)

---

## ⚡ **PERFORMANCE EXPECTATIONS**

| Metric | Target | Current |
|--------|--------|---------|
| Page load | <2s | ✅ Achieved |
| API response | <500ms | ✅ Achieved |
| Translation | <200ms | ✅ Cached |
| Real-time stream | 30Hz | ✅ Achieved |
| Dashboard refresh | 30s | ✅ Auto-refresh |

---

## 📊 **DATA FLOW**

### **Web → API → Database**
```
User Action (Frontend)
  ↓
React Query / Fetch (API Client)
  ↓
Next.js API Route (/api/**)
  ↓
SQL Query (PostgreSQL)
  ↓
Database Response
  ↓
JSON Response (API)
  ↓
UI Update (Frontend)
```

### **Mobile → API → Database**
```
User Action (Expo App)
  ↓
React Query / Fetch (with BASE_URL)
  ↓
Next.js API Route (/api/**)
  ↓
SQL Query (PostgreSQL)
  ↓
Database Response
  ↓
JSON Response (API)
  ↓
UI Update (Mobile Screen)
```

### **Real-Time XR Stream**
```
Client Opens SSE Connection
  ↓
Server Starts 30Hz Loop
  ↓
Query Latest Biometrics
  ↓
Compute SSI/CIS/ARC
  ↓
Generate 3D Positions
  ↓
Send JSON Frame
  ↓
Client Receives & Renders
  ↓
(Repeat every 33ms)
```

---

## 🎨 **DESIGN SYSTEM**

### **Color Palette**
- **Primary Navy:** `#1B3A57`
- **Dark Navy:** `#152E45`
- **Deep Background:** `#0D1421`, `#0A0F1C`
- **Gold Accent:** `#C8A882`
- **Light Gold:** `#D4B896`

### **Typography**
- **Headings:** Bold, white/gold
- **Body:** Regular, gray-300/gray-400
- **Labels:** Uppercase, tracking-wide, gray-400

### **Spacing**
- **Grid:** 8px base
- **Container:** max-w-[1600px]
- **Padding:** px-8 py-8

### **Shadows**
- **Cards:** shadow-lg
- **Hover:** shadow-xl

---

## ✅ **ACCESSIBILITY**

- ✅ High contrast text (WCAG AA compliant)
- ✅ Keyboard navigation support
- ✅ Screen reader labels
- ✅ Focus indicators
- ✅ Multi-language support
- ⚠️ **TODO:** Color-blind mode
- ⚠️ **TODO:** Reduced motion preference

---

This completes the full user experience journey for both web and mobile platforms!
