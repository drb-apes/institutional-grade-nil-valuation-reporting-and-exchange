# BIM-APES Dashboard × Method Integration Map
## Complete Performance Intelligence System

**Version:** 1.0.0  
**Last Updated:** March 16, 2026  
**Status:** Production Ready

---

## Overview

The BIM-APES platform deploys **24 performance management methods** across **7 primary dashboard types**. Each dashboard consumes specific method signals based on its user persona and decision requirements.

---

## Dashboard Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     24 METHOD INTELLIGENCE ENGINE               │
│  Methods 1-10: Core Risk/Brain/Governance                      │
│  Methods 11-12: AR Spatial Drift & Capsule Behavior           │
│  Methods 13-14: Spatial Hedging                               │
│  Methods 15-16: Spatial Arbitrage                             │
│  Methods 17-18: Spatial Scalping                              │
│  Methods 19-20: Coaching Overlays                             │
│  Methods 21-24: Medical Intelligence                          │
└────────────────────┬────────────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │    Signal Routing       │
        │    (Methods 3 & 10)     │
        └────────────┬────────────┘
                     │
     ┌───────────────┼───────────────┐
     │               │               │
┌────▼────┐    ┌────▼────┐    ┌────▼────┐
│ Coach   │    │ Medical │    │ Trading │
│ Dashboard│   │Dashboard│    │Dashboard│
└─────────┘    └─────────┘    └─────────┘
     │               │               │
┌────▼────┐    ┌────▼────┐    ┌────▼────┐
│Broadcast│    │ Stadium │    │Investor │
│ Control │    │ Display │    │Syndicate│
└─────────┘    └─────────┘    └─────────┘
                     │
               ┌────▼────┐
               │Federation│
               │Expansion │
               └─────────┘
```

---

## 1. Coach Dashboard

**Location:** `/console/page.jsx` (main), `/coach-dashboard/page.jsx`

### Primary Methods Used

| Method | Purpose | Signal Type | Update Frequency |
|--------|---------|-------------|------------------|
| **3** | Hybrid AI Exit Score | Overall readiness | 5 Hz |
| **11** | Spatial Drift Detection | Posture/gait quality | 30 Hz |
| **12** | Capsule Behavior | Movement capsule stability | 30 Hz |
| **19** | Coaching Overlay | Optimal vs actual vectors | 10 Hz |
| **20** | Tempo Rhythm | Performance cadence | 10 Hz |
| **21** | Collapse Prediction | Injury risk (safety) | 30 Hz |
| **24** | Recovery Envelope | Return-to-play readiness | 5 Hz |

### Dashboard Features
- **Substitution Recommendations** (Method 3 + 21)
- **Performance Trends** (Method 11, 12, 20)
- **Coaching Cues** (Method 19 AR overlays)
- **Recovery Status** (Method 24)
- **Real-time Safety Alerts** (Method 21, 22, 23)

### API Endpoints
```javascript
// Core readiness
GET /api/dashboard/summary?athlete_id={id}

// Coaching signals
POST /api/ar/coaching/overlay
POST /api/ar/coaching/tempo-rhythm

// Recovery monitoring
POST /api/ar/medical/recovery-envelope
POST /api/intelligence/recovery
```

---

## 2. Medical Dashboard

**Location:** `/console/medical-dashboard/page.jsx`

### Primary Methods Used

| Method | Purpose | Signal Type | Update Frequency |
|--------|---------|-------------|------------------|
| **21** | Spatial Collapse Prediction | Balance instability | 30 Hz |
| **22** | Impact Vector Overload | Collision risk | 30 Hz |
| **23** | Joint Divergence | Unsafe biomechanics | 30 Hz |
| **24** | Spatial Recovery Envelope | Recovery tracking | 5 Hz |
| **1** | Adaptive Trailing Stop | Biometric drawdown | 10 Hz |
| **6** | Milestone Partial Exit | Recovery milestones | Event-driven |

### Dashboard Features
- **4 Critical Metrics** (Methods 21-24)
- **Risk Level Badges** (Critical/Warning/Safe)
- **AR Spatial Visualizations** (Halos, cones, markers, shells)
- **Alert Management** (Severity-based routing)
- **Recovery Progress Tracking** (Method 24)

### API Endpoints
```javascript
// All 4 medical methods
POST /api/ar/medical/collapse-prediction
POST /api/ar/medical/impact-overload
POST /api/ar/medical/joint-divergence
POST /api/ar/medical/recovery-envelope

// Athlete metrics
GET /api/athletes/metrics
GET /api/athletes/list

// Intelligence layers
POST /api/intelligence/fatigue
POST /api/intelligence/recovery
```

---

## 3. Trading/Intelligence Dashboard

**Location:** `/intelligence-dashboard/page.jsx`

### Primary Methods Used

| Method | Purpose | Signal Type | Update Frequency |
|--------|---------|-------------|------------------|
| **3** | Hybrid AI Weighted | Master exit score | 5 Hz |
| **10** | Distributed Multi-Manager | Consensus score | 5 Hz |
| **13** | Spatial Opponent Pressure | Distance/angle hedging | 10 Hz |
| **14** | Spatial Symmetry Hedge | Left/right imbalance | 10 Hz |
| **15** | Spatial Efficiency Arbitrage | Motion efficiency gaps | 5 Hz |
| **16** | Capsule Divergence Arbitrage | Capsule mispricing | 10 Hz |
| **17** | Micro-Drift Scalping | High-frequency posture | 60 Hz |
| **18** | Capsule Pulse Scalping | Capsule micro-pulses | 30 Hz |

### Dashboard Features
- **NIL Mispricing Windows** (Methods 15, 16)
- **Arbitrage Opportunities** (Methods 15, 16)
- **Scalping Signals** (Methods 17, 18)
- **Hedge Recommendations** (Methods 13, 14)
- **Exit Score Display** (Methods 3, 10)
- **Portfolio Management**

### API Endpoints
```javascript
// NIL valuation & mispricing
POST /api/nil-valuation/calculate
POST /api/trading/detect-mispricing

// Trading strategies
POST /api/trading/strategies/arbitrage
POST /api/trading/strategies/hedge
POST /api/trading/strategies/scalping

// Portfolio management
POST /api/trading/portfolio/manage

// Market intelligence
POST /api/intelligence/market
```

---

## 4. Broadcast Control Dashboard

**Location:** `/broadcast-control/page.jsx`

### Primary Methods Used

| Method | Purpose | Signal Type | Update Frequency |
|--------|---------|-------------|------------------|
| **3** | Hybrid AI (Overall Score) | Broadcast-ready metric | 5 Hz |
| **11** | Spatial Drift | Visual AR element | 30 Hz |
| **12** | Capsule Behavior | Visual AR element | 30 Hz |
| **19** | Coaching Overlay | Broadcast graphics | 10 Hz |
| **21** | Collapse Prediction | Safety alerts | 30 Hz |

### Dashboard Features
- **Package Type Selection** (Coach view, Medical alerts, Sponsor activation)
- **Broadcast Partner Integration** (ESPN, TNT, Amazon, Apple)
- **Live Preview** (AR overlay simulation)
- **Push to Stadium** (Direct broadcast feed)
- **Multi-format Output** (4K, HDR, SDR)

### API Endpoints
```javascript
// AR package generation
POST /api/broadcast/ar-package

// AR overlays
POST /api/ar/overlays/generate
POST /api/ar/universal-frame

// Stadium push
POST /api/stadium/display
```

---

## 5. Stadium Display System

**Location:** `/api/stadium/display/route.js`

### Primary Methods Used

| Method | Purpose | Display Type | Update Frequency |
|--------|---------|-------------|------------------|
| **3** | Performance Score | Jumbotron | 5 Hz |
| **11** | Spatial Drift | LED Ribbon | 30 Hz |
| **21** | Collapse Risk | Medical Board | 30 Hz |
| **Sponsor** | NIL Activation | Brand Displays | Event-driven |

### Display Types
- **Jumbotron** (Main scoreboard, 3840x2160)
- **LED Ribbon** (Continuous strip, 11520x270)
- **Courtside Displays** (Close-up screens, 1920x1080)
- **Tunnel Displays** (Player entry, 1080x1920)

### API Endpoints
```javascript
POST /api/stadium/display
POST /api/broadcast/ar-package
```

---

## 6. Investor Syndicate Dashboard

**Location:** (To be implemented)

### Primary Methods Used

| Method | Purpose | Signal Type | Update Frequency |
|--------|---------|-------------|------------------|
| **3** | Hybrid AI Score | Investment signal | 5 Hz |
| **10** | Distributed Multi-Manager | Risk allocation | 5 Hz |
| **15** | Efficiency Arbitrage | Value opportunities | 5 Hz |
| **16** | Capsule Divergence | Asset mispricing | 10 Hz |
| **24** | Recovery Envelope | Long-term performance | 5 Hz |

### Dashboard Features
- **NIL Valuation Curves**
- **ROI Tracking** (Sponsor-linked)
- **Portfolio Optimization**
- **Risk Exposure Metrics**
- **Coalition Engagement Scores**

### API Endpoints
```javascript
POST /api/nil-valuation/calculate
POST /api/trading/portfolio/manage
POST /api/sponsor/roi-tracking
POST /api/revenue/licensing
```

---

## 7. Federation Expansion Dashboard

**Location:** (To be implemented)

### Primary Methods Used

| Method | Purpose | Signal Type | Update Frequency |
|--------|---------|-------------|------------------|
| **3** | Hybrid AI | Club-level aggregates | 1 Hz |
| **21-24** | Medical Suite | League-wide safety | 5 Hz |
| **Coalition** | Partner Metrics | Federation ROI | Event-driven |

### Dashboard Features
- **Club Onboarding Status**
- **Federation-wide Medical Compliance**
- **Coalition Certificate Tracking**
- **Regional Performance Maps**
- **Event Integration** (Rugby World Cup, FIFA 2026, Olympic 2028)

### API Endpoints
```javascript
POST /api/coalition/activate
POST /api/certificates/issue
POST /api/milestones/track
```

---

## Signal Flow & Method Orchestration

### Methods 3 & 10: The Core Brain

**Method 3 (Hybrid AI Weighted)** is the **primary consumer** of all AR signals:

```javascript
// Inputs
const inputs = {
  // AR Spatial Signals
  spatial_drift: method11_output,
  capsule_behavior: method12_output,
  opponent_pressure: method13_output,
  symmetry_score: method14_output,
  efficiency_ratio: method15_output,
  capsule_divergence: method16_output,
  micro_drift_triggers: method17_output,
  capsule_pulse: method18_output,
  
  // Medical Signals
  collapse_risk: method21_output,
  impact_overload: method22_output,
  joint_divergence: method23_output,
  recovery_progress: method24_output,
  
  // Biometrics
  fatigue: biometric_FAi,
  recovery: biometric_RRi,
  hrv: biometric_HRVi,
  
  // Market Context
  nil_gap: valuation_gap,
  momentum: market_momentum,
};

// Output
const exit_score = hybrid_ai_model(inputs); // 0-100
```

**Method 10 (Distributed Multi-Manager)** blends outputs:

```javascript
const consensus_score = weighted_average([
  { method: 1, weight: 0.15 }, // Adaptive Trailing
  { method: 3, weight: 0.50 }, // Hybrid AI (primary)
  { method: 4, weight: 0.15 }, // Volatility Event
  { method: 6, weight: 0.20 }, // Milestone Partial
]);
```

---

## Method Availability by Sport

### Basketball
- ✅ Methods 3, 11, 12, 21, 22, 23, 24
- 🔶 Methods 13, 14 (opponent pressure limited)
- ⚡ High-frequency impact tracking (Method 22)

### MMA / Combat Sports
- ✅ Methods 3, 11, 12, 13, 21, 22, 23
- ⚡ Opponent pressure critical (Method 13)
- ⚡ Collapse prediction live (Method 21)

### Rugby / Soccer
- ✅ Methods 3, 11, 12, 14, 22, 24
- ⚡ Symmetry hedge (Method 14)
- ⚡ Impact overload (Method 22)

### Golf
- ✅ Methods 3, 11, 15, 17, 20
- ⚡ Efficiency arbitrage (Method 15)
- ⚡ Tempo rhythm (Method 20)

### Camel Racing
- ✅ Methods 3, 10, 11, 21, 24
- ⚡ Spatial drift (Method 11)
- ⚡ Recovery envelope (Method 24)

---

## Production Readiness Checklist

### ✅ Deployed (Live)
- Method 1: Adaptive Trailing Stop
- Method 3: Hybrid AI Weighted
- Method 4: Volatility Event-Driven
- Method 6: Milestone Partial Exit
- Method 10: Distributed Multi-Manager
- Method 11: AR Spatial Drift
- Method 12: AR Capsule Behavior
- Method 21: Collapse Prediction
- Method 22: Impact Overload
- Method 23: Joint Divergence
- Method 24: Recovery Envelope

### 🔶 Beta Testing
- Method 13: Opponent Pressure Hedge
- Method 14: Symmetry Hedge
- Method 17: Micro-Drift Scalping
- Method 19: Coaching Overlay

### 🟡 Development
- Method 15: Efficiency Arbitrage
- Method 16: Capsule Divergence Arbitrage
- Method 18: Capsule Pulse Scalping
- Method 20: Tempo Rhythm

### ⚠️ Reference Only
- Method 2: Pattern-Only (legacy)
- Method 7: Randomized (benchmark)

### ❌ DO NOT DEPLOY
- Method 8: Max Risk / All-In
- Method 9: Biometric Inverse Martingale

---

## Dashboard Routing Table

| Dashboard | Primary Methods | Secondary Methods | Update Hz |
|-----------|----------------|------------------|-----------|
| Coach | 3, 19, 20, 21, 24 | 11, 12 | 10 Hz |
| Medical | 21, 22, 23, 24 | 1, 6 | 30 Hz |
| Trading/Intel | 3, 10, 13-18 | 11, 12 | 5-60 Hz |
| Broadcast | 3, 11, 12, 19, 21 | All (on-demand) | 10 Hz |
| Stadium | 3, 11, 21, Sponsor | 19, 22 | 5 Hz |
| Investor | 3, 10, 15, 16, 24 | Coalition metrics | 1 Hz |
| Federation | 3, 21-24, Coalition | All (aggregated) | 1 Hz |

---

## Integration Examples

### Coach Dashboard Integration

```javascript
// Real-time coaching view
const coachingData = await Promise.all([
  fetch('/api/ar/coaching/overlay', { 
    method: 'POST', 
    body: JSON.stringify({ athlete_id }) 
  }),
  fetch('/api/ar/coaching/tempo-rhythm', { 
    method: 'POST', 
    body: JSON.stringify({ athlete_id }) 
  }),
  fetch('/api/ar/medical/collapse-prediction', { 
    method: 'POST', 
    body: JSON.stringify({ athlete_id }) 
  }),
]);

// Display optimal vs actual vectors (Method 19)
const overlay = await coachingData[0].json();
renderARCoachingLines(overlay.data.vector_deltas);

// Show tempo consistency (Method 20)
const tempo = await coachingData[1].json();
renderTempoMeter(tempo.data.rhythm_score);

// Safety check (Method 21)
const collapse = await coachingData[2].json();
if (collapse.alert.severity === 'critical') {
  triggerSubstitutionAlert();
}
```

### Trading Dashboard Integration

```javascript
// Multi-method arbitrage scan
const tradingSignals = await Promise.all([
  fetch('/api/trading/detect-mispricing', { 
    method: 'POST', 
    body: JSON.stringify({ athlete_id }) 
  }),
  fetch('/api/trading/strategies/arbitrage', { 
    method: 'POST', 
    body: JSON.stringify({ athlete_id }) 
  }),
  fetch('/api/trading/strategies/scalping', { 
    method: 'POST', 
    body: JSON.stringify({ athlete_id }) 
  }),
]);

// Method 15 + 16 (Arbitrage)
const arbitrage = await tradingSignals[1].json();
displayArbitrageOpportunities(arbitrage.opportunities);

// Method 17 + 18 (Scalping)
const scalping = await tradingSignals[2].json();
displayScalpingSignals(scalping.micro_triggers);
```

---

## Cross-Dashboard Signal Sharing

**Scenario:** Medical alert triggers coach substitution and trader hedge

```javascript
// Medical Dashboard detects collapse risk (Method 21)
const collapseAlert = {
  athlete_id: 'abc-123',
  method: 21,
  severity: 'critical',
  timestamp: '2026-03-16T14:32:00Z',
};

// Routes to:
// 1. Coach Dashboard → Substitution prompt
// 2. Trading Dashboard → Auto-hedge position
// 3. Broadcast Control → Medical staff overlay
// 4. Stadium Display → Safety alert banner

await Promise.all([
  notifyCoach(collapseAlert),
  autoHedgePosition(collapseAlert.athlete_id),
  pushToBroadcast(collapseAlert),
  updateStadiumDisplay(collapseAlert),
]);
```

---

## Performance Optimization

### Caching Strategy
- **High-frequency signals (30-60 Hz):** No cache, real-time stream
- **Medium-frequency (5-10 Hz):** 200ms cache
- **Low-frequency (1-5 Hz):** 1s cache
- **Static data:** 5min cache

### Load Balancing
- **Methods 21-24 (Medical):** Dedicated compute nodes
- **Methods 3, 10 (Core Brain):** GPU-accelerated inference
- **Methods 17-18 (Scalping):** High-frequency tick servers

---

## Next Steps

1. ✅ **Complete Medical Dashboard** (Methods 21-24)
2. 🔶 **Upgrade Intelligence Dashboard** (Add Methods 13-18)
3. 🔶 **Enhance Coach Dashboard** (Add Methods 19-20)
4. 🟡 **Build Investor Syndicate Dashboard**
5. 🟡 **Build Federation Expansion Dashboard**
6. 🟡 **WebSocket Real-Time Streaming** (30-60 Hz signals)
7. 🟡 **Mobile App Parity** (All dashboard features)

---

**© 2026 BIM-APES. All rights reserved.**
