# BIM-APES VR Prototype Setup Guide

## Overview
This guide covers the complete setup for the BIM-APES VR/XR visualization system, including Unity integration, React Three Fiber web VR, and API data streaming.

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    BIM-APES VR System                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────┐         ┌──────────────────┐        │
│  │  Unity VR App    │         │  Web VR (R3F)    │        │
│  │  (Headset)       │         │  (Browser)       │        │
│  └────────┬─────────┘         └────────┬─────────┘        │
│           │                             │                   │
│           └─────────────┬───────────────┘                   │
│                         │                                   │
│              ┌──────────▼──────────┐                        │
│              │   XR API Layer      │                        │
│              │  (SSE Streaming)    │                        │
│              └──────────┬──────────┘                        │
│                         │                                   │
│              ┌──────────▼──────────┐                        │
│              │  BIM-APES Backend   │                        │
│              │  (PostgreSQL + AI)  │                        │
│              └─────────────────────┘                        │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. API Endpoints for XR

### 2.1 Real-Time Data Stream
**Endpoint:** `GET /api/xr/universal-frame-stream`

**Query Parameters:**
- `session_id` (required): Unique session identifier
- `athlete_ids` (required): Comma-separated athlete IDs
- `hz` (optional): Update frequency (default: 30Hz)

**Response:** Server-Sent Events (SSE)

**Example:**
```javascript
const eventSource = new EventSource(
  '/api/xr/universal-frame-stream?session_id=session_123&athlete_ids=athlete_1,athlete_2&hz=30'
);

eventSource.onmessage = (event) => {
  const frame = JSON.parse(event.data);
  if (frame.type === 'xr_frame') {
    updateAthletePositions(frame.athletes);
  }
};
```

**Frame Structure:**
```json
{
  "type": "xr_frame",
  "session_id": "session_123",
  "frame_number": 42,
  "timestamp": "2026-03-18T12:00:00Z",
  "update_hz": 30,
  "athletes": [
    {
      "athlete_id": "athlete_1",
      "name": "John Doe",
      "sport": "American Football",
      "position": "QB",
      "team": "Team A",
      "nil_tier": "Tier I",
      "metrics": {
        "ssi": 82,
        "cis": 76,
        "arc": 79,
        "stress": 0.45,
        "fatigue": 0.32,
        "recovery": 0.78
      },
      "position_3d": {
        "x": 2.5,
        "y": 1.8,
        "z": -5.2,
        "rotation": { "x": 0, "y": 1.57, "z": 0 },
        "velocity": { "x": 1.2, "y": 0, "z": -0.8 }
      }
    }
  ]
}
```

### 2.2 Broadcast Control
**Endpoint:** `POST /api/xr/broadcast-control`

**Body:**
```json
{
  "action": "push",
  "athlete_id": "athlete_1",
  "display_type": "jumbotron",
  "content_type": "live_metrics",
  "duration_seconds": 10,
  "priority": "high"
}
```

### 2.3 Multi-Athlete Spatial Analytics
**Endpoint:** `POST /api/xr/multi-athlete-spatial`

**Body:**
```json
{
  "athlete_ids": ["athlete_1", "athlete_2", "athlete_3"],
  "session_id": "session_123",
  "analysis_type": "comparative",
  "sport": "American Football",
  "time_window_minutes": 5
}
```

---

## 3. Unity VR Setup

### 3.1 Prerequisites
- Unity 2022.3 LTS or newer
- Meta Quest SDK or SteamVR Plugin
- NewtonsoftJson package

### 3.2 Project Structure
```
Assets/
├── BIM_APES/
│   ├── Scripts/
│   │   ├── XRDataStreamer.cs
│   │   ├── AthleteAvatar.cs
│   │   ├── BiometricOverlay.cs
│   │   └── BroadcastController.cs
│   ├── Prefabs/
│   │   ├── AthleteAvatar.prefab
│   │   └── MetricOverlay.prefab
│   └── Scenes/
│       └── VR_Stadium.unity
```

### 3.3 XR Data Streamer (C#)
```csharp
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;

public class XRDataStreamer : MonoBehaviour
{
    private string baseUrl = "https://your-bim-apes-url.com";
    private string sessionId;
    private List<string> athleteIds;
    
    void Start()
    {
        sessionId = System.Guid.NewGuid().ToString();
        StartCoroutine(StreamXRData());
    }
    
    IEnumerator StreamXRData()
    {
        string url = $"{baseUrl}/api/xr/universal-frame-stream?" +
                    $"session_id={sessionId}&" +
                    $"athlete_ids={string.Join(",", athleteIds)}&hz=30";
        
        using (UnityEngine.Networking.UnityWebRequest www = 
               UnityEngine.Networking.UnityWebRequest.Get(url))
        {
            www.SendWebRequest();
            
            while (!www.isDone)
            {
                if (www.downloadHandler.text.Length > 0)
                {
                    ProcessFrame(www.downloadHandler.text);
                }
                yield return null;
            }
        }
    }
    
    void ProcessFrame(string data)
    {
        var frame = JsonConvert.DeserializeObject<XRFrame>(data);
        foreach (var athlete in frame.athletes)
        {
            UpdateAthleteAvatar(athlete);
        }
    }
    
    void UpdateAthleteAvatar(AthleteData athlete)
    {
        // Update 3D position, rotation, and overlay metrics
    }
}

[System.Serializable]
public class XRFrame
{
    public string type;
    public string session_id;
    public int frame_number;
    public List<AthleteData> athletes;
}

[System.Serializable]
public class AthleteData
{
    public string athlete_id;
    public string name;
    public Metrics metrics;
    public Position3D position_3d;
}

[System.Serializable]
public class Metrics
{
    public int ssi;
    public int cis;
    public int arc;
    public float stress;
    public float fatigue;
    public float recovery;
}

[System.Serializable]
public class Position3D
{
    public float x, y, z;
    public Rotation rotation;
    public Velocity velocity;
}
```

---

## 4. React Three Fiber Web VR Setup

### 4.1 Installation
```bash
npm install three @react-three/fiber @react-three/drei
```

### 4.2 Web VR Component
```jsx
'use client';

import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Text } from '@react-three/drei';
import { useEffect, useState } from 'react';

export default function WebVRViewer({ sessionId, athleteIds }) {
  const [athletes, setAthletes] = useState([]);

  useEffect(() => {
    const eventSource = new EventSource(
      `/api/xr/universal-frame-stream?session_id=${sessionId}&athlete_ids=${athleteIds.join(',')}&hz=30`
    );

    eventSource.onmessage = (event) => {
      const frame = JSON.parse(event.data);
      if (frame.type === 'xr_frame') {
        setAthletes(frame.athletes);
      }
    };

    return () => eventSource.close();
  }, [sessionId, athleteIds]);

  return (
    <Canvas style={{ width: '100%', height: '600px', background: '#0A0F1C' }}>
      <PerspectiveCamera makeDefault position={[0, 5, 15]} />
      <OrbitControls />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      
      {/* Stadium field */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[30, 50]} />
        <meshStandardMaterial color="#2a5f2a" />
      </mesh>

      {/* Athlete avatars */}
      {athletes.map((athlete) => (
        <AthleteAvatar key={athlete.athlete_id} data={athlete} />
      ))}
    </Canvas>
  );
}

function AthleteAvatar({ data }) {
  const position = [
    data.position_3d.x,
    data.position_3d.y,
    data.position_3d.z
  ];

  return (
    <group position={position}>
      {/* Avatar sphere */}
      <mesh>
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial color="#C8A882" />
      </mesh>
      
      {/* Name label */}
      <Text
        position={[0, 2, 0]}
        fontSize={0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {data.name}
      </Text>
      
      {/* Metrics overlay */}
      <Text
        position={[0, 1.5, 0]}
        fontSize={0.2}
        color="#C8A882"
        anchorX="center"
        anchorY="middle"
      >
        {`SSI: ${data.metrics.ssi} | CIS: ${data.metrics.cis} | ARC: ${data.metrics.arc}`}
      </Text>
    </group>
  );
}
```

---

## 5. Broadcast Control Panel

Create a control panel for stadium operators:

```jsx
'use client';

import { useState } from 'react';

export default function BroadcastControlPanel({ athletes }) {
  const [selectedAthlete, setSelectedAthlete] = useState(null);

  const pushToDisplay = async (displayType) => {
    if (!selectedAthlete) return;

    await fetch('/api/xr/broadcast-control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'push',
        athlete_id: selectedAthlete,
        display_type: displayType,
        content_type: 'live_metrics',
        duration_seconds: 10,
        priority: 'high'
      })
    });
  };

  return (
    <div className="bg-[#0D1421] border border-[#C8A882]/20 rounded-xl p-6">
      <h3 className="text-xl font-bold text-white mb-4">Broadcast Control</h3>
      
      <select
        value={selectedAthlete || ''}
        onChange={(e) => setSelectedAthlete(e.target.value)}
        className="w-full bg-[#152E45] border border-[#C8A882]/20 rounded-lg px-4 py-2 text-white mb-4"
      >
        <option value="">Select Athlete</option>
        {athletes.map(a => (
          <option key={a.id} value={a.id}>{a.name}</option>
        ))}
      </select>

      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => pushToDisplay('jumbotron')}
          className="bg-[#C8A882] hover:bg-[#B8956A] text-[#0D1421] font-bold py-2 px-4 rounded-lg transition-all"
        >
          Jumbotron
        </button>
        <button
          onClick={() => pushToDisplay('lower_third')}
          className="bg-[#C8A882] hover:bg-[#B8956A] text-[#0D1421] font-bold py-2 px-4 rounded-lg transition-all"
        >
          Lower Third
        </button>
        <button
          onClick={() => pushToDisplay('sideline')}
          className="bg-[#C8A882] hover:bg-[#B8956A] text-[#0D1421] font-bold py-2 px-4 rounded-lg transition-all"
        >
          Sideline
        </button>
      </div>
    </div>
  );
}
```

---

## 6. Testing the System

### 6.1 Start the Data Stream
```bash
curl "http://localhost:3000/api/xr/universal-frame-stream?session_id=test_123&athlete_ids=athlete_1,athlete_2&hz=30"
```

### 6.2 Test Broadcast Control
```bash
curl -X POST http://localhost:3000/api/xr/broadcast-control \
  -H "Content-Type: application/json" \
  -d '{
    "action": "push",
    "athlete_id": "athlete_1",
    "display_type": "jumbotron",
    "content_type": "live_metrics"
  }'
```

---

## 7. Performance Optimization

### 7.1 Unity Optimization
- Use object pooling for athlete avatars
- LOD (Level of Detail) for distant athletes
- Occlusion culling for off-screen athletes
- Limit overlay updates to 30Hz

### 7.2 Web VR Optimization
- Use React Three Fiber's `useFrame` wisely
- Implement frustum culling
- Reduce geometry complexity for mobile
- Use instancing for repeated geometries

---

## 8. Deployment Checklist

- [ ] Configure CORS for API endpoints
- [ ] Set up SSL/TLS for secure SSE streams
- [ ] Test on Meta Quest 2/3/Pro
- [ ] Test on WebXR browsers (Chrome, Edge)
- [ ] Load test with 50+ concurrent athletes
- [ ] Monitor bandwidth usage (target: <100KB/s per stream)
- [ ] Set up error logging and monitoring
- [ ] Document API rate limits

---

## Next Steps

1. Integrate motion capture data (replace mock positions)
2. Add NIL valuation overlays in VR
3. Implement VR playbook visualization
4. Build coach annotation tools
5. Add real-time trade signal overlays
