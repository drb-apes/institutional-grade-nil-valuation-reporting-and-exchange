# BIM-APES API Error Standardization

## Overview
All BIM-APES API endpoints follow a consistent error response format to ensure predictable error handling across the platform.

---

## Standard Error Response Format

```json
{
  "success": false,
  "error": "ERROR_TYPE",
  "message": "Human-readable error description",
  "details": {
    // Optional: Additional context
  },
  "timestamp": "2026-03-18T10:30:00.000Z"
}
```

---

## Error Types

| Error Type | Status Code | Description |
|------------|-------------|-------------|
| `VALIDATION_ERROR` | 400 | Request validation failed |
| `INVALID_REQUEST` | 400 | Malformed or invalid request |
| `UNAUTHORIZED` | 401 | Authentication required |
| `FORBIDDEN` | 403 | Access forbidden |
| `NOT_FOUND` | 404 | Resource not found |
| `RATE_LIMIT_EXCEEDED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Internal server error |
| `DATABASE_ERROR` | 500 | Database operation failed |
| `EXTERNAL_API_ERROR` | 502 | External service error |

---

## Usage Examples

### 1. Validation Error
```javascript
import { validationError } from '@/app/api/utils/errorHandler';

export async function POST(request) {
  const { athlete_id } = await request.json();
  
  if (!athlete_id) {
    return validationError('athlete_id is required', {
      athlete_id: 'This field is required'
    });
  }
  
  // ... rest of handler
}
```

**Response:**
```json
{
  "success": false,
  "error": "VALIDATION_ERROR",
  "message": "athlete_id is required",
  "details": {
    "fields": {
      "athlete_id": "This field is required"
    }
  },
  "timestamp": "2026-03-18T10:30:00.000Z"
}
```

---

### 2. Not Found Error
```javascript
import { notFoundError } from '@/app/api/utils/errorHandler';

export async function GET(request, { params }) {
  const athlete = await getAthleteById(params.id);
  
  if (!athlete) {
    return notFoundError('Athlete', params.id);
  }
  
  return Response.json({ athlete });
}
```

**Response:**
```json
{
  "success": false,
  "error": "NOT_FOUND",
  "message": "Athlete with identifier 'dashawn_001' not found",
  "timestamp": "2026-03-18T10:30:00.000Z"
}
```

---

### 3. Database Error
```javascript
import { databaseError } from '@/app/api/utils/errorHandler';
import sql from '@/app/api/utils/sql';

export async function POST(request) {
  try {
    const result = await sql`SELECT * FROM athletes`;
    return Response.json({ athletes: result });
  } catch (err) {
    return databaseError(err, 'fetching athletes');
  }
}
```

**Response (Production):**
```json
{
  "success": false,
  "error": "DATABASE_ERROR",
  "message": "Database error during fetching athletes",
  "timestamp": "2026-03-18T10:30:00.000Z"
}
```

**Response (Development):**
```json
{
  "success": false,
  "error": "DATABASE_ERROR",
  "message": "Database error during fetching athletes",
  "details": {
    "originalError": "column 'invalid_column' does not exist"
  },
  "timestamp": "2026-03-18T10:30:00.000Z"
}
```

---

### 4. Using Error Handling Wrapper
```javascript
import { withErrorHandling, successResponse } from '@/app/api/utils/errorHandler';
import sql from '@/app/api/utils/sql';

async function handler(request) {
  const { athlete_id } = await request.json();
  
  const intelligence = await sql`
    SELECT * FROM biometric_readings 
    WHERE athlete_id = ${athlete_id}
  `;
  
  return successResponse({ intelligence });
}

export const POST = withErrorHandling(handler);
```

---

## Success Response Format

```json
{
  "success": true,
  // ... your data fields
  "message": "Optional success message"
}
```

**Example:**
```javascript
import { successResponse } from '@/app/api/utils/errorHandler';

export async function POST(request) {
  const athlete = await createAthlete(data);
  
  return successResponse(
    { athlete },
    'Athlete created successfully'
  );
}
```

**Response:**
```json
{
  "success": true,
  "athlete": {
    "id": "...",
    "first_name": "Dashawn",
    "last_name": "Bledsoe"
  },
  "message": "Athlete created successfully"
}
```

---

## Migration Checklist

### For Existing API Routes:
- [ ] Import error handlers from `@/app/api/utils/errorHandler`
- [ ] Replace inline error responses with standard handlers
- [ ] Add validation checks with `validationError()`
- [ ] Wrap database calls with try/catch using `databaseError()`
- [ ] Use `notFoundError()` for missing resources
- [ ] Use `successResponse()` for success cases
- [ ] Test error responses match standard format

### Example Migration:

**Before:**
```javascript
export async function POST(request) {
  const { athlete_id } = await request.json();
  
  if (!athlete_id) {
    return Response.json({ error: 'Missing athlete_id' }, { status: 400 });
  }
  
  const athlete = await getAthlete(athlete_id);
  
  if (!athlete) {
    return Response.json({ error: 'Not found' }, { status: 404 });
  }
  
  return Response.json({ athlete });
}
```

**After:**
```javascript
import { validationError, notFoundError, successResponse } from '@/app/api/utils/errorHandler';

export async function POST(request) {
  const { athlete_id } = await request.json();
  
  if (!athlete_id) {
    return validationError('athlete_id is required');
  }
  
  const athlete = await getAthlete(athlete_id);
  
  if (!athlete) {
    return notFoundError('Athlete', athlete_id);
  }
  
  return successResponse({ athlete });
}
```

---

## Benefits

### 1. **Frontend Predictability**
```javascript
// Consistent error handling on frontend
const response = await fetch('/api/some-endpoint');
const data = await response.json();

if (!data.success) {
  // Always has: error, message, timestamp
  console.error(`${data.error}: ${data.message}`);
  
  if (data.details) {
    // Optional additional context
    console.debug(data.details);
  }
}
```

### 2. **Easier Debugging**
- Consistent error structure in logs
- Error type categorization
- Timestamp for all errors
- Development-only stack traces

### 3. **Better UX**
- Human-readable error messages
- Consistent error display components
- Type-specific error handling

---

## Error Handling in Dashboards

All dashboards now use `ErrorScreen` component which expects standard error format:

```javascript
if (error) {
  return (
    <ErrorScreen
      title="Error Loading Data"
      message={error}
      onRetry={loadData}
    />
  );
}
```

The API standardization ensures all API errors provide clear, actionable messages to users.
