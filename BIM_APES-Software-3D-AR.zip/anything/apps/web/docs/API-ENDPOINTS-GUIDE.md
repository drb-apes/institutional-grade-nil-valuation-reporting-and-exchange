# BIM-APES API Endpoints Guide
## Complete End-to-End Integration Reference

**Version:** 1.0.0  
**Last Updated:** March 16, 2026  
**Status:** Production Ready

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [AR Medical Intelligence Endpoints](#ar-medical-intelligence-endpoints)
3. [Athlete Management Endpoints](#athlete-management-endpoints)
4. [Intelligence & Analytics Endpoints](#intelligence--analytics-endpoints)
5. [AR Visualization Endpoints](#ar-visualization-endpoints)
6. [Trading & NIL Endpoints](#trading--nil-endpoints)
7. [Sport-Specific Endpoints](#sport-specific-endpoints)
8. [Wearable Integration Endpoints](#wearable-integration-endpoints)
9. [Frontend Integration Guide](#frontend-integration-guide)
10. [Mobile App Integration](#mobile-app-integration)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                       CLIENT APPLICATIONS                        │
│                                                                 │
│  ┌──────────────────┐          ┌──────────────────┐           │
│  │   Web Console    │          │   Mobile App     │           │
│  │  (React + Vite)  │          │   (React Native) │           │
│  └────────┬─────────┘          └────────┬─────────┘           │
│           │                              │                      │
└───────────┼──────────────────────────────┼──────────────────────┘
            │                              │
            ▼                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         API LAYER                                │
│                    (Node.js Serverless)                          │
│                                                                 │
│  /api/ar/medical/*           ← AR Medical Intelligence (21-24)  │
│  /api/athletes/*             ← Athlete Management               │
│  /api/intelligence/*         ← Analytics & Intelligence         │
│  /api/ar/*                   ← AR Visualization                 │
│  /api/trading/*              ← Trading & Mispricing             │
│  /api/sport-specific/*       ← Sport-Specific Modules           │
│  /api/wearables/*            ← Wearable Device Integration      │
│                                                                 │
└─────────────────┬───────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                    DATABASE LAYER                                │
│                  (PostgreSQL via Neon)                           │
│                                                                 │
│  • athletes                  • biometric_readings               │
│  • biometric_index_definitions                                 │
│  • nil_valuations            • mispricing_events                │
│  • performance_sessions      • sport_specific_metrics           │
│  • coalition_certificates    • trading_positions                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## AR Medical Intelligence Endpoints

### Method 21: Spatial Collapse Prediction

**Endpoint:** `POST /api/ar/medical/collapse-prediction`

**Description:** Real-time collapse risk analysis using balance instability detection and drift vectors.

**Request:**
```json
{
  "athlete_id": "uuid",
  "session_id": "uuid" // optional
}
```

**Response:**
```json
{
  "success": true,
  "method_id": 21,
  "method_name": "Spatial Collapse Prediction",
  "athlete_id": "uuid",
  "timestamp": "2026-03-16T10:30:00Z",
  "update_frequency_hz": 30,
  "data": {
    "collapse_risk_score": 0.87,
    "balance_stability": 0.13,
    "drift_vectors": { "x": 0.2, "y": 0.15, "z": 0.05 },
    "center_of_mass_offset": 0.25,
    "prediction_confidence": 0.8,
    "time_to_collapse_seconds": 45
  },
  "ar_visualization": {
    "type": "risk_halo",
    "color": "red",
    "intensity": 0.87,
    "pulse_rate_hz": 2.5,
    "radius_meters": 2.0
  },
  "alert": {
    "severity": "critical",
    "message": "Immediate rest required - collapse risk critical",
    "requires_action": true
  }
}
```

---

### Method 22: Impact Vector Overload

**Endpoint:** `POST /api/ar/medical/impact-overload`

**Description:** Tracks impact direction and magnitude to detect overload conditions.

**Request:**
```json
{
  "athlete_id": "uuid",
  "session_id": "uuid" // optional
}
```

**Response:**
```json
{
  "success": true,
  "method_id": 22,
  "method_name": "Impact Vector Overload",
  "data": {
    "impact_overload_score": 0.68,
    "total_impact_magnitude": 145.5,
    "impact_count_last_5min": 23,
    "cumulative_load": 485.2,
    "peak_impact": 9.2,
    "impact_vectors": [
      {
        "direction": { "x": 0.5, "y": -0.8, "z": 0.2 },
        "magnitude": 9.2,
        "timestamp": "2026-03-16T10:29:55Z",
        "body_zone": "torso"
      }
    ],
    "body_zones_affected": ["head", "torso", "legs"]
  },
  "ar_visualization": {
    "type": "impact_cones",
    "cones": [
      {
        "direction": { "x": 0.5, "y": -0.8, "z": 0.2 },
        "magnitude": 9.2,
        "color": "red",
        "length_meters": 2.76
      }
    ]
  }
}
```

---

### Method 23: Joint Divergence

**Endpoint:** `POST /api/ar/medical/joint-divergence`

**Description:** Detects unsafe joint angles and torque overload for injury prevention.

**Request:**
```json
{
  "athlete_id": "uuid",
  "session_id": "uuid" // optional
}
```

**Response:**
```json
{
  "success": true,
  "method_id": 23,
  "method_name": "Joint Divergence Method",
  "data": {
    "joint_divergence_score": 0.72,
    "unsafe_joints": ["left_knee", "right_ankle"],
    "joint_angles": {
      "left_knee": {
        "angle": 145.5,
        "safe_range": [0, 140],
        "is_safe": false
      }
    },
    "torque_overload": {
      "left_knee": {
        "torque": 125.5,
        "threshold": 100
      }
    },
    "asymmetry_score": 0.15,
    "injury_risk_zones": ["knee_valgus"]
  },
  "ar_visualization": {
    "type": "joint_warnings",
    "markers": [
      {
        "joint_name": "left_knee",
        "position": { "x": -0.15, "y": 0.5, "z": 0 },
        "color": "red",
        "pulse": true,
        "warning_icon": "alert_triangle"
      }
    ]
  }
}
```

---

### Method 24: Spatial Recovery Envelope

**Endpoint:** `POST /api/ar/medical/recovery-envelope`

**Description:** Monitors return-to-baseline recovery across multiple physiological systems.

**Request:**
```json
{
  "athlete_id": "uuid",
  "session_id": "uuid" // optional
}
```

**Response:**
```json
{
  "success": true,
  "method_id": 24,
  "method_name": "Spatial Recovery Envelope",
  "data": {
    "recovery_progress": 0.65,
    "baseline_metrics": {
      "HRVi": 75.0,
      "FAi": 45.0,
      "RRi": 80.0
    },
    "current_metrics": {
      "HRVi": 68.5,
      "FAi": 52.0,
      "RRi": 72.0
    },
    "envelope_breach": true,
    "breached_metrics": ["HRVi", "RRi"],
    "estimated_time_to_baseline_hours": 4.5,
    "recovery_velocity": 0.15,
    "recovery_phase": "repair"
  },
  "ar_visualization": {
    "type": "recovery_shell",
    "shell": {
      "color": "yellow",
      "opacity": 0.56,
      "radius_meters": 1.5,
      "segments": [
        { "name": "cardiovascular", "health": 0.91, "color": "green" },
        { "name": "muscular", "health": 0.48, "color": "yellow" }
      ]
    }
  }
}
```

---

## Athlete Management Endpoints

### List Athletes

**Endpoint:** `GET /api/athletes/list`

**Query Parameters:**
- `sport` (optional) - Filter by sport
- `team` (optional) - Filter by team
- `nil_tier` (optional) - Filter by NIL tier
- `limit` (default: 50) - Results per page
- `offset` (default: 0) - Pagination offset

**Response:**
```json
{
  "success": true,
  "athletes": [
    {
      "id": "uuid",
      "first_name": "John",
      "last_name": "Doe",
      "sport": "Basketball",
      "team": "Lakers",
      "nil_tier": "Tier I",
      "coalition_status": "Active"
    }
  ],
  "count": 10,
  "limit": 50,
  "offset": 0
}
```

---

### Get Athlete Metrics

**Endpoint:** `GET /api/athletes/metrics?athlete_id={uuid}`

**Response:**
```json
{
  "success": true,
  "athlete": {
    "id": "uuid",
    "name": "John Doe",
    "team": "Lakers",
    "sport": "Basketball",
    "status": "Active",
    "fatigue": 45,
    "recovery": 72,
    "hrv": 68,
    "nil_value": 125000,
    "nil_momentum": 12.5,
    "risk_level": "medium",
    "last_updated": "2026-03-16T10:00:00Z"
  }
}
```

---

### Get Multiple Athletes Metrics

**Endpoint:** `GET /api/athletes/metrics`

**Query Parameters:**
- `limit` (default: 50)
- `offset` (default: 0)

**Response:**
```json
{
  "success": true,
  "athletes": [
    {
      "id": "uuid",
      "name": "John Doe",
      "team": "Lakers",
      "sport": "Basketball",
      "fatigue": 45,
      "recovery": 72,
      "nilMomentum": "+12%",
      "riskLevel": "medium",
      "lastUpdated": "2026-03-16T10:00:00Z"
    }
  ],
  "total": 150,
  "limit": 50,
  "offset": 0
}
```

---

## Intelligence & Analytics Endpoints

### Recovery Intelligence

**Endpoint:** `POST /api/intelligence/recovery`

**Request:**
```json
{
  "athlete_id": "uuid"
}
```

**Response:** Detailed recovery analysis including sleep, HRV, muscle soreness, tissue repair.

---

### Fatigue Intelligence

**Endpoint:** `POST /api/intelligence/fatigue`

**Request:**
```json
{
  "athlete_id": "uuid"
}
```

**Response:** Central and peripheral fatigue analysis with neural and muscular factors.

---

### Training Intelligence

**Endpoint:** `POST /api/intelligence/training`

**Request:**
```json
{
  "athlete_id": "uuid"
}
```

**Response:** ACWR analysis, velocity metrics, power output, technique drift.

---

### Stress Intelligence

**Endpoint:** `POST /api/intelligence/stress`

**Request:**
```json
{
  "athlete_id": "uuid"
}
```

**Response:** Cortisol analysis, sympathetic activation, stress resilience.

---

## AR Visualization Endpoints

### Generate AR Overlays

**Endpoint:** `POST /api/ar/overlays/generate`

**Request:**
```json
{
  "athlete_id": "uuid",
  "overlay_types": ["stress", "fatigue", "recovery", "injury_risk"],
  "session_id": "uuid" // optional
}
```

**Response:**
```json
{
  "success": true,
  "athlete": {
    "id": "uuid",
    "name": "John Doe",
    "sport": "Basketball"
  },
  "timestamp": "2026-03-16T10:30:00Z",
  "overlays": {
    "stress": { /* stress overlay data */ },
    "fatigue": { /* fatigue overlay data */ },
    "recovery": { /* recovery overlay data */ },
    "injury_risk": { /* injury risk overlay data */ }
  },
  "data_quality": {
    "readings_count": 45,
    "time_window_hours": 2
  }
}
```

---

### Universal AR Frame

**Endpoint:** `POST /api/ar/universal-frame`

**Description:** Complete AR frame with all overlay types for stadium/broadcast display.

---

## Trading & NIL Endpoints

### Detect Mispricing

**Endpoint:** `POST /api/trading/detect-mispricing`

**Description:** Detects arbitrage opportunities in NIL valuation vs market price.

---

### NIL Valuation Calculation

**Endpoint:** `POST /api/nil-valuation/calculate`

**Request:**
```json
{
  "athlete_id": "uuid"
}
```

**Response:**
```json
{
  "success": true,
  "valuation": {
    "true_value": 125000,
    "market_value": 98000,
    "gap": 27000,
    "gap_percentage": 27.55,
    "direction": "long",
    "confidence": 0.87
  }
}
```

---

## Sport-Specific Endpoints

### Wrestling Performance Tracking

**Endpoint:** `POST /api/sport-specific/wrestling/performance-tracking`

---

### American Football Consistency Monitor

**Endpoint:** `POST /api/sport-specific/american-football/consistency-monitor`

---

### Racket Sports Spike Analysis

**Endpoint:** `POST /api/sport-specific/racket-sports/spike-analysis`

---

### Tactical Sports Efficiency

**Endpoint:** `POST /api/sport-specific/tactical-sports/efficiency`

---

## Wearable Integration Endpoints

### Whoop Sync

**Endpoint:** `POST /api/wearables/whoop/sync`

---

### Garmin Sync

**Endpoint:** `POST /api/wearables/garmin/sync`

---

### Apple Watch Sync

**Endpoint:** `POST /api/wearables/apple-watch/sync`

---

## Frontend Integration Guide

### Web Console Integration

**Example: Medical Dashboard**

```javascript
// Fetch AR Medical Intelligence for an athlete
const fetchMedicalIntelligence = async (athleteId) => {
  const [collapse, impact, joint, recovery] = await Promise.all([
    fetch('/api/ar/medical/collapse-prediction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ athlete_id: athleteId }),
    }),
    fetch('/api/ar/medical/impact-overload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ athlete_id: athleteId }),
    }),
    fetch('/api/ar/medical/joint-divergence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ athlete_id: athleteId }),
    }),
    fetch('/api/ar/medical/recovery-envelope', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ athlete_id: athleteId }),
    }),
  ]);

  const data = await Promise.all([
    collapse.json(),
    impact.json(),
    joint.json(),
    recovery.json(),
  ]);

  return {
    collapse: data[0],
    impact: data[1],
    joint: data[2],
    recovery: data[3],
  };
};
```

---

## Mobile App Integration

### React Native Example

```javascript
import { useEffect, useState } from 'react';

export function useAthleteMetrics() {
  const [athletes, setAthletes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/api/athletes/metrics');
        const data = await response.json();
        
        if (data.success) {
          setAthletes(data.athletes);
        }
      } catch (error) {
        console.error('Error fetching athletes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return { athletes, loading };
}
```

---

## Error Handling

All endpoints return errors in this format:

```json
{
  "success": false,
  "error": "Error message here"
}
```

**HTTP Status Codes:**
- `200` - Success
- `400` - Bad Request (missing required parameters)
- `404` - Not Found (athlete/resource not found)
- `500` - Internal Server Error

---

## Rate Limiting

- **AR Medical Endpoints:** 30 requests per second per athlete (matches 30 Hz update frequency)
- **Analytics Endpoints:** 10 requests per second
- **List Endpoints:** 100 requests per minute

---

## WebSocket Support (Future)

Real-time streaming for AR overlays will be available via WebSocket connections:

```
ws://your-domain/api/ar/stream?athlete_id={uuid}
```

---

## Testing Endpoints

Use the built-in API testing console at `/console/settings` or use tools like:
- **cURL**
- **Postman**
- **Thunder Client** (VS Code extension)

**Example cURL:**
```bash
curl -X POST https://your-domain/api/ar/medical/collapse-prediction \
  -H "Content-Type: application/json" \
  -d '{"athlete_id": "your-athlete-id"}'
```

---

## Support & Documentation

- **Full API Reference:** https://docs.bim-apes.com/api
- **24-Method Master Map:** `/docs/BIM-APES-24-METHOD-MASTER-MAP.md`
- **Technical Support:** api@bim-apes.com

---

**© 2026 BIM-APES. All rights reserved.**
