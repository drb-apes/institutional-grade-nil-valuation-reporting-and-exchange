# BIM-APES Data Library Guide

## Overview
The BIM-APES Data Library provides **role-based access** to raw data logs from S3 buckets and **live streaming endpoints** for real-time data consumption. This system supports players, teams, medical staff, coaches, and federation officials.

---

## Features

### 📦 **S3 Raw Data Pull**
- Pull historical biometric logs, performance sessions, medical records
- Role-based data filtering and access control
- Support for JSON, CSV, and Parquet formats
- Automatic audit logging
- Date range filtering

### 📡 **Live Streaming**
- Real-time data streaming at 30-60 Hz
- Private endpoint generation per user
- WebSocket and Server-Sent Events (SSE) support
- Auto-expiring access tokens (24-hour TTL)
- Multiple stream types (biometric, performance, AR medical)

---

## API Endpoints

### **1. S3 Data Pull**

#### **POST /api/data-library/s3-pull**
Pull raw data logs from S3 bucket

**Request:**
```json
{
  "user_role": "coach",
  "user_id": "user-123",
  "data_type": "biometric_logs",
  "athlete_id": "athlete-456",
  "team_id": "team-789",
  "date_range": {
    "start": "2024-01-01",
    "end": "2024-01-07"
  },
  "format": "json"
}
```

**Response:**
```json
{
  "success": true,
  "data": [...],
  "metadata": {
    "source": "s3",
    "bucket": "bim-apes-raw-data",
    "path": "raw-data/biometric_logs/athlete-456/",
    "format": "json",
    "record_count": 100,
    "pulled_at": "2024-01-08T10:00:00Z",
    "access_level": "team"
  }
}
```

#### **GET /api/data-library/s3-pull?user_role=coach&user_id=user-123**
List available datasets for a user

---

### **2. Live Stream Registration**

#### **POST /api/data-library/stream/register**
Register a private live stream endpoint

**Request:**
```json
{
  "user_role": "medical_staff",
  "user_id": "medic-123",
  "stream_type": "ar_medical_live",
  "athlete_id": "athlete-456",
  "frequency_hz": 30
}
```

**Response:**
```json
{
  "success": true,
  "stream": {
    "stream_id": "stream-medical_staff-medic-123-ar_medical_live-1234567890-abc123",
    "websocket_url": "wss://domain/api/data-library/stream/ws/{streamId}",
    "http_stream_url": "http://domain/api/data-library/stream/ws/{streamId}",
    "access_token": "eyJ...token...xyz",
    "frequency_hz": 30,
    "expires_at": "2024-01-09T10:00:00Z"
  },
  "connection_instructions": {...}
}
```

#### **GET /api/data-library/stream/register?user_role=coach&user_id=user-123**
List active streams for a user

#### **DELETE /api/data-library/stream/register**
Close a stream

**Request:**
```json
{
  "stream_id": "stream-coach-user-123-..."
}
```

---

### **3. WebSocket/SSE Streaming**

#### **GET /api/data-library/stream/ws/{streamId}**
Connect to live stream (SSE endpoint)

**Headers:**
```
Authorization: Bearer {access_token}
Accept: text/event-stream
```

**Stream Format:**
```
data: {"type":"biometric_frame","frame":1,"timestamp":"...","data":{...}}

data: {"type":"biometric_frame","frame":2,"timestamp":"...","data":{...}}
```

---

## Role-Based Access Control

### **Player**
**S3 Access:**
- `biometric_logs` - Own data only
- `performance_sessions` - Own data only
- `personal_medical` - Own data only

**Streaming:**
- `biometric_realtime` - Own stream only
- `performance_live` - Own stream only

---

### **Coach**
**S3 Access:**
- `biometric_logs` - Team data
- `performance_sessions` - Team data (read-write)
- `team_analytics` - Team data
- `session_recordings` - Team data

**Streaming:**
- `biometric_realtime` - Team stream
- `performance_live` - Team stream
- `team_session_live` - Team stream
- `ar_overlay_live` - Team stream

---

### **Medical Staff**
**S3 Access:**
- `biometric_logs` - Full patient data
- `medical_records` - Full access (read-write)
- `injury_logs` - Full access (read-write)
- `recovery_data` - Full access (read-write)
- `ar_medical_overlays` - Full access

**Streaming:**
- `biometric_realtime` - Patient stream
- `medical_alerts_live` - Alert stream
- `ar_medical_live` - AR medical stream
- `recovery_live` - Recovery stream

---

### **Team Admin**
**S3 Access:**
- `all` - Full team data (read-write-admin)

**Streaming:**
- `all_streams` - All team streams

---

### **Federation**
**S3 Access:**
- `aggregate_stats` - Federation statistics
- `compliance_reports` - Compliance data
- `coalition_data` - Coalition data

---

### **Broadcast**
**Streaming:**
- `ar_broadcast_feed` - Broadcast stream
- `stadium_feed` - Stadium stream
- `highlights_live` - Highlights stream

---

## Data Types

### **S3 Data Types**
1. **biometric_logs** - Heart rate, HRV, SpO2, respiratory rate, temperature
2. **performance_sessions** - Training sessions, duration, intensity, scores
3. **medical_records** - Medical checkups, injuries, treatments
4. **team_analytics** - Team performance, injury rates, recovery scores
5. **ar_medical_overlays** - AR medical alert overlays
6. **session_recordings** - Video/AR session recordings
7. **injury_logs** - Injury tracking and recovery data
8. **recovery_data** - Recovery protocols and progress

### **Stream Types**
1. **biometric_realtime** - Real-time biometric data (30-60 Hz)
2. **performance_live** - Live performance metrics
3. **ar_medical_live** - AR medical overlay stream
4. **team_session_live** - Team session live feed
5. **ar_overlay_live** - AR overlay broadcast
6. **medical_alerts_live** - Medical alerts stream
7. **ar_broadcast_feed** - Broadcast feed
8. **stadium_feed** - Stadium display feed
9. **highlights_live** - Live highlights stream
10. **recovery_live** - Recovery monitoring stream

---

## Usage Examples

### **Pull S3 Data (Coach)**
```javascript
const response = await fetch('/api/data-library/s3-pull', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    user_role: 'coach',
    user_id: 'coach-123',
    data_type: 'team_analytics',
    team_id: 'team-789',
    date_range: {
      start: '2024-01-01',
      end: '2024-01-07'
    }
  })
});

const data = await response.json();
console.log(data.data); // Team analytics data
```

---

### **Register Live Stream (Medical Staff)**
```javascript
const response = await fetch('/api/data-library/stream/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    user_role: 'medical_staff',
    user_id: 'medic-123',
    stream_type: 'ar_medical_live',
    athlete_id: 'athlete-456',
    frequency_hz: 30
  })
});

const { stream } = await response.json();
console.log(stream.http_stream_url); // Stream URL
console.log(stream.access_token); // Access token
```

---

### **Connect to Live Stream (SSE)**
```javascript
const eventSource = new EventSource(stream.http_stream_url, {
  headers: {
    'Authorization': `Bearer ${stream.access_token}`
  }
});

eventSource.onmessage = (event) => {
  const frame = JSON.parse(event.data);
  console.log('Frame:', frame.frame);
  console.log('Data:', frame.data);
};

eventSource.onerror = (error) => {
  console.error('Stream error:', error);
  eventSource.close();
};
```

---

## Security

### **Access Tokens**
- Auto-generated for each stream
- 24-hour expiry
- Base64-encoded (use JWT in production)
- Include user_role, user_id, stream_id

### **Role Validation**
- Every request validates role permissions
- Data filtering applied based on role
- Audit logging for all data access

### **Data Filtering**
- **Players** see redacted medical notes
- **Coaches** see restricted medical diagnoses
- **Medical Staff** see full unfiltered data

---

## Production Deployment

### **AWS S3 Integration**
```javascript
// Install AWS SDK
npm install @aws-sdk/client-s3

// Update /api/data-library/s3-pull/route.js
import { S3Client, GetObjectCommand, ListObjectsV2Command } from "@aws-sdk/client-s3";

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
  }
});
```

### **WebSocket Server**
For production WebSocket support (Next.js doesn't support WS natively):
1. Use **AWS API Gateway WebSocket APIs**
2. Use **Pusher/Ably** managed services
3. Use custom **Node.js server** with `ws` library

### **Environment Variables**
```bash
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
BIM_APES_DATA_BUCKET=bim-apes-raw-data
```

---

## Dashboard Access

Visit: **http://localhost:3000/data-library**

**Features:**
- Role selector (player, coach, medical_staff, team_admin, federation, broadcast)
- S3 data pull interface
- Live stream registration
- Active streams monitoring
- Real-time stream testing

---

## Testing

Use the test harness: **http://localhost:3000/test-harness**

Or test manually:
```bash
# 1. List available datasets
curl "http://localhost:3000/api/data-library/s3-pull?user_role=coach&user_id=user-123"

# 2. Pull S3 data
curl -X POST http://localhost:3000/api/data-library/s3-pull \
  -H "Content-Type: application/json" \
  -d '{"user_role":"coach","user_id":"user-123","data_type":"biometric_logs"}'

# 3. Register stream
curl -X POST http://localhost:3000/api/data-library/stream/register \
  -H "Content-Type: application/json" \
  -d '{"user_role":"coach","user_id":"user-123","stream_type":"biometric_realtime"}'
```

---

## Support

For questions or issues, contact: **[email protected]**
