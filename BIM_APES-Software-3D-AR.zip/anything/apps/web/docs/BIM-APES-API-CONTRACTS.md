# BIM-APES AR Engine API Contracts & Data Schemas

**Version:** 1.0.0  
**Last Updated:** March 16, 2026  
**Status:** Production Ready

---

## Table of Contents

1. [Universal Frame API](#universal-frame-api)
2. [SSI (Scalping Signal Index)](#ssi-scalping-signal-index)
3. [CIS (Convexity Index Score)](#cis-convexity-index-score)
4. [ARC (Arbitrage Readiness Coefficient)](#arc-arbitrage-readiness-coefficient)
5. [Exit Score](#exit-score)
6. [Overlay Types & Visual Schemas](#overlay-types--visual-schemas)
7. [Biometric Index Codes](#biometric-index-codes)
8. [Error Handling](#error-handling)

---

## Universal Frame API

### Endpoint
```
POST /api/ar/universal-frame
```

### Description
Generates the complete Universal AR Frame combining SSI, CIS, ARC, and Exit Score with visual overlays for real-time athlete trading intelligence.

### Request Schema

```typescript
interface UniversalFrameRequest {
  athlete_id: string;                    // UUID of athlete
  include_metrics?: string[];            // ["ssi", "cis", "arc", "exit_score", "all"]
  time_window_minutes?: number;          // Default: 60
  output_format?: "json" | "protobuf";   // Default: "json"
}
```

### Request Example

```json
{
  "athlete_id": "123e4567-e89b-12d3-a456-426614174000",
  "include_metrics": ["all"],
  "time_window_minutes": 60,
  "output_format": "json"
}
```

### Response Schema

```typescript
interface UniversalFrameResponse {
  success: boolean;
  universal_frame: {
    athlete: AthleteInfo;
    timestamp: string;                   // ISO 8601
    metrics: {
      ssi: SSI;
      cis: CIS;
      arc: ARC;
      exit_score: ExitScore;
    };
    valuation: NILValuation | null;
    overlays: Overlay[];
    metadata: FrameMetadata;
  };
}

interface AthleteInfo {
  id: string;
  name: string;
  sport: string;
  position: string | null;
  team: string | null;
  nil_tier: string;
}

interface FrameMetadata {
  readings_count: number;
  time_window_minutes: number;
  mispricing_events: number;
  open_positions: number;
  generated_at: string;                  // ISO 8601
}
```

### Response Example

```json
{
  "success": true,
  "universal_frame": {
    "athlete": {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "name": "LeBron James",
      "sport": "Basketball",
      "position": "Forward",
      "team": "Los Angeles Lakers",
      "nil_tier": "Tier I"
    },
    "timestamp": "2026-03-16T14:30:00Z",
    "metrics": {
      "ssi": { ... },
      "cis": { ... },
      "arc": { ... },
      "exit_score": { ... }
    },
    "valuation": { ... },
    "overlays": [ ... ],
    "metadata": {
      "readings_count": 47,
      "time_window_minutes": 60,
      "mispricing_events": 2,
      "open_positions": 3,
      "generated_at": "2026-03-16T14:30:05Z"
    }
  }
}
```

---

## SSI (Scalping Signal Index)

### Description
Measures short-term momentum burst potential for scalping opportunities. Combines momentum intensity, biometric volatility, event presence, and TTL urgency.

### Data Schema

```typescript
interface SSI {
  score: number;                         // 0-100
  signal: SSISignal;
  confidence: number;                    // 0-1
  components: {
    momentum: number;                    // 0-40 points
    volatility: number;                  // 0-30 points
    scalping_events: number;             // 0-20 points
    ttl_urgency: number;                 // 0-10 points
  };
  interpretation: string;
  recommended_action: string;
}

type SSISignal = 
  | "strong_scalp"    // >= 75
  | "scalp_ready"     // >= 50
  | "weak_scalp"      // >= 30
  | "no_scalp";       // < 30
```

### Calculation Formula

```
SSI = (momentum_intensity × 40) + 
      (biometric_volatility × 30) + 
      (scalping_event_multiplier) + 
      (ttl_urgency)

Where:
- momentum_intensity: from NIL valuation (0-1)
- biometric_volatility: rapid changes in PWRi, SPDi (0-1)
- scalping_event_multiplier: 10 points per event, max 20
- ttl_urgency: inverse function of TTL seconds
```

### Example Response

```json
{
  "score": 87.5,
  "signal": "strong_scalp",
  "confidence": 0.925,
  "components": {
    "momentum": 36.8,
    "volatility": 28.2,
    "scalping_events": 20,
    "ttl_urgency": 10
  },
  "interpretation": "Immediate scalp opportunity detected",
  "recommended_action": "Enter scalp position immediately"
}
```

---

## CIS (Convexity Index Score)

### Description
Measures non-linear upside capture potential. Evaluates convexity factor, performance acceleration, upside asymmetry, and sponsor activation likelihood.

### Data Schema

```typescript
interface CIS {
  score: number;                         // 0-100
  signal: CISSignal;
  components: {
    convexity_factor: number;            // 0-40 points
    acceleration: number;                // 0-30 points
    asymmetry: number;                   // 0-20 points
    sponsor_potential: number;           // 0-10 points
  };
  convexity_factor: number;              // 0-1 (raw CF from valuation)
  interpretation: string;
  recommended_action: string;
}

type CISSignal = 
  | "high_convexity"       // >= 80
  | "moderate_convexity"   // >= 60
  | "low_convexity"        // >= 40
  | "linear";              // < 40
```

### Calculation Formula

```
CIS = (convexity_factor × 40) + 
      (performance_acceleration × 30) + 
      (upside_asymmetry) + 
      (sponsor_activation_potential)

Where:
- convexity_factor: from NIL valuation (0-1)
- performance_acceleration: % of biometrics trending up (0-1)
- upside_asymmetry: gap direction alignment score (0-20)
- sponsor_activation_potential: performance spike likelihood (0-10)
```

### Example Response

```json
{
  "score": 92.3,
  "signal": "high_convexity",
  "components": {
    "convexity_factor": 37.2,
    "acceleration": 28.5,
    "asymmetry": 18.6,
    "sponsor_potential": 10
  },
  "convexity_factor": 0.93,
  "interpretation": "Exceptional convex upside potential",
  "recommended_action": "Maximize position size for convex capture"
}
```

---

## ARC (Arbitrage Readiness Coefficient)

### Description
Measures spread exploitation readiness. Evaluates spread magnitude, stability, expected close time, and arbitrage event presence.

### Data Schema

```typescript
interface ARC {
  score: number;                         // 0-100
  signal: ARCSignal;
  components: {
    spread_magnitude: number;            // 0-40 points
    spread_stability: number;            // 0-30 points
    close_time: number;                  // 0-20 points
    arb_events: number;                  // 0-10 points
  };
  spread_percentage: number;             // Absolute gap %
  confidence: number;                    // 0-1
  expected_close_minutes: number;
  interpretation: string;
  recommended_action: string;
}

type ARCSignal = 
  | "strong_arb"     // >= 75
  | "arb_ready"      // >= 50
  | "weak_arb"       // >= 30
  | "no_arb";        // < 30
```

### Calculation Formula

```
ARC = (spread_magnitude) + 
      (spread_stability) + 
      (close_time_score) + 
      (arbitrage_event_presence)

Where:
- spread_magnitude: min((gap% / 20) × 40, 40)
- spread_stability: confidence × 30
- close_time_score: inverse function of expected_close_seconds
- arbitrage_event_presence: 10 if event exists, else 0
```

### Example Response

```json
{
  "score": 78.4,
  "signal": "strong_arb",
  "components": {
    "spread_magnitude": 32.5,
    "spread_stability": 27.9,
    "close_time": 18.0,
    "arb_events": 10
  },
  "spread_percentage": 16.25,
  "confidence": 0.93,
  "expected_close_minutes": 25,
  "interpretation": "Prime arbitrage window open",
  "recommended_action": "Execute arbitrage immediately"
}
```

---

## Exit Score

### Description
Determines optimal position exit timing. Evaluates P&L status, spread closing velocity, biometric fatigue, and TTL expiration proximity.

### Data Schema

```typescript
interface ExitScore {
  score: number;                         // 0-100
  signal: ExitSignal;
  components: {
    pl_status: number;                   // 0-40 points
    closing_velocity: number;            // 0-30 points
    fatigue_pressure: number;            // 0-20 points
    ttl_pressure: number;                // 0-10 points
  };
  open_positions: number;
  interpretation: string;
  recommended_action: string;
}

type ExitSignal = 
  | "exit_now"       // >= 75
  | "prepare_exit"   // >= 50
  | "monitor"        // >= 30
  | "hold"           // < 30
  | "no_positions";  // 0 positions
```

### Calculation Formula

```
ExitScore = (pl_component) + 
            (closing_velocity) + 
            (fatigue_pressure) + 
            (ttl_pressure)

Where:
- pl_component: function of avg P&L across positions
  - Positive P&L → lower score (0-20)
  - Negative P&L → higher score (20-40)
- closing_velocity: function of gap_percentage change
- fatigue_pressure: function of FAi score
- ttl_pressure: inverse function of TTL seconds
```

### Example Response

```json
{
  "score": 42.7,
  "signal": "monitor",
  "components": {
    "pl_status": 15.2,
    "closing_velocity": 10.0,
    "fatigue_pressure": 12.5,
    "ttl_pressure": 5.0
  },
  "open_positions": 3,
  "interpretation": "Monitor closely, no immediate exit needed",
  "recommended_action": "Continue holding"
}
```

---

## Overlay Types & Visual Schemas

### Overlay Base Schema

```typescript
interface Overlay {
  id: string;
  type: OverlayType;
  position: Position;
  data?: Record<string, any>;
  visual?: VisualConfig;
}

interface Position {
  x: number;    // 0-1 (normalized screen coordinates)
  y: number;    // 0-1 (normalized screen coordinates)
}

interface VisualConfig {
  color?: string;
  glow?: boolean;
  pulse?: boolean;
  pulse_rate?: number;
  halo?: boolean;
  halo_color?: string;
  border_pulse?: boolean;
  alert?: boolean;
  warning?: boolean;
  animation?: string;
  opacity?: number;
  size?: number;
  thickness?: number;
  intensity?: number;
}
```

### Overlay Types

#### 1. Metric Card
```typescript
interface MetricCardOverlay extends Overlay {
  type: "metric_card";
  metric: {
    label: string;
    value: number;
    signal: string;
    color: string;
    trend?: "up" | "down" | "flat";
    convexity_factor?: number;
    spread_percentage?: number;
    positions_count?: number;
  };
}
```

#### 2. Value Comparison
```typescript
interface ValueComparisonOverlay extends Overlay {
  type: "value_comparison";
  data: {
    true_value: number;
    market_value: number;
    gap: number;
    direction: "long" | "short";
  };
  visual: {
    bar_width: number;
    color_gradient: boolean;
  };
}
```

#### 3. Concentric Ring
```typescript
interface ConcentricRingOverlay extends Overlay {
  type: "concentric_ring";
  data: {
    gap_percentage: number;
    direction: "long" | "short";
  };
  visual: {
    radius: number;
    thickness: number;
    color: string;
    pulse: boolean;
  };
}
```

#### 4. Radial Glow (Convexity Halo)
```typescript
interface RadialGlowOverlay extends Overlay {
  type: "radial_glow";
  visual: {
    radius: number;
    color: string;
    intensity: number;
    pulse_rate: number;
  };
}
```

#### 5. Directional Arrow (Momentum Vector)
```typescript
interface DirectionalArrowOverlay extends Overlay {
  type: "directional_arrow";
  data: {
    direction: "up" | "down";
    intensity: number;
  };
  visual: {
    size: number;
    color: string;
    animation: string;
  };
}
```

#### 6. Alert Banner
```typescript
interface AlertBannerOverlay extends Overlay {
  type: "alert_banner";
  data: {
    events: Array<{
      type: string;
      gap: number;
      ttl_seconds: number;
    }>;
  };
  visual: {
    border_color: string;
    glow: boolean;
  };
}
```

---

## Biometric Index Codes

### Primary Trading Indices

| Code | Name | Domain | Range | Description |
|------|------|--------|-------|-------------|
| **PWRi** | Power Index | Biomechanical | 0-100 | Explosive force output |
| **SPDi** | Speed Index | Performance | 0-100 | Movement velocity |
| **FAi** | Fatigue Index | Recovery | 0-100 | Cumulative fatigue load |
| **HRVi** | Heart Rate Variability Index | Vital Signals | 0-100 | Autonomic balance |
| **RRi** | Resilience Recovery Index | Recovery | 0-100 | Recovery rate |
| **CLi** | Cognitive Load Index | Cognitive | 0-100 | Mental processing strain |
| **ERi** | Endurance Rating Index | Performance | 0-100 | Sustained performance capacity |

### Composite Indices

| Code | Formula | Purpose |
|------|---------|---------|
| **ReadinessIndex** | (HRVi + RRi - FAi) / 3 | Overall readiness to perform |
| **VolatilityIndex** | σ(PWRi, SPDi) over time | Performance consistency |
| **StabilityIndex** | (100 - CLi) × (HRVi / 100) | Emotional + physical stability |

---

## NIL Valuation Schema

```typescript
interface NILValuation {
  true_value: number;                    // BIM-APES calculated fair value
  market_value: number;                  // Public market pricing
  gap: number;                           // true_value - market_value
  gap_percentage: number;                // (gap / market_value) × 100
  direction: "long" | "short";           // Trade direction
  confidence: number;                    // 0-1
  convexity_factor: number;              // 0-1 (non-linear upside)
  momentum_intensity: number;            // 0-1 (rate of change)
}
```

---

## Error Handling

### Error Response Schema

```typescript
interface ErrorResponse {
  error: string;
  details?: string;
  status: number;
}
```

### HTTP Status Codes

| Code | Description |
|------|-------------|
| **200** | Success |
| **400** | Bad Request (missing or invalid parameters) |
| **404** | Not Found (athlete not found) |
| **500** | Internal Server Error |

### Example Error Responses

```json
{
  "error": "athlete_id is required",
  "status": 400
}
```

```json
{
  "error": "Athlete not found",
  "status": 404
}
```

```json
{
  "error": "Failed to generate universal frame",
  "details": "Database connection timeout",
  "status": 500
}
```

---

## Rate Limits & Performance

### Latency Targets

| Endpoint | Target Latency | Max Latency |
|----------|---------------|-------------|
| `/api/ar/universal-frame` | < 100ms | 200ms |
| `/api/ar/overlays/generate` | < 50ms | 100ms |

### Rate Limits

- **Authenticated users:** 1000 requests/minute
- **Public endpoints:** 100 requests/minute
- **Burst allowance:** 2x sustained rate for 10 seconds

---

## Versioning

API version is specified in the URL path:

```
/api/v1/ar/universal-frame
/api/v2/ar/universal-frame
```

Current stable version: **v1** (implied when no version specified)

---

## WebSocket Streaming (Future)

For real-time overlay updates:

```javascript
const ws = new WebSocket('wss://api.bim-apes.com/stream/universal-frame');
ws.send(JSON.stringify({
  athlete_id: "123e4567-e89b-12d3-a456-426614174000",
  update_interval_ms: 1000
}));
```

---

## Authentication

All API requests require Bearer token authentication:

```
Authorization: Bearer <token>
```

Tokens are obtained via `/api/auth/token` endpoint.

---

## Contact & Support

- **Technical Documentation:** https://docs.bim-apes.com
- **API Support:** api-support@bim-apes.com
- **Emergency Contact:** +1-555-BIM-APES

---

**© 2026 BIM-APES. All rights reserved.**
