# BIM-APES 24-Method Master Map
## AR/3D Spatial Intelligence Layer Integration

**Version:** 1.0.0  
**Last Updated:** March 16, 2026  
**Status:** Production Ready

---

## Executive Summary

The BIM-APES platform deploys **24 distinct exit/position management methods** organized across **10 categories**. Methods **11-24** are **AR-native**, meaning they generate spatial metrics directly from 3D biomechanical data. Methods **1-10** are either **AR-consumers** (using AR signals as inputs) or **non-AR** (legacy/benchmark).

**Key Principle:**  
- **AR methods produce signals** → **Core Brain methods consume signals** → **Visual layer renders insights**

---

## Table of Contents

1. [Full 24-Method Index](#full-24-method-index)
2. [Method Categories Explained](#method-categories-explained)
3. [AR/3D Spatial Intelligence Layer](#ar3d-spatial-intelligence-layer)
4. [Signal Flow Architecture](#signal-flow-architecture)
5. [Sport-Specific Playbooks](#sport-specific-playbooks)
6. [Production Deployment Status](#production-deployment-status)

---

## Full 24-Method Index

| # | Method Name | Category | Primary Signal Domain | AR/3D Spatial Use |
|---|-------------|----------|----------------------|-------------------|
| **1** | Adaptive Trailing Stop | Core Risk | Biometric drawdown | Optional (AR display) |
| **2** | Pattern-Only Exit | Legacy | Price/patterns | None (non-AR) |
| **3** | Hybrid AI Weighted | Core Brain | All signals blended | **Consumes AR signals** |
| **4** | Volatility Event-Driven | Core Risk | Volatility spikes | Optional (AR alerts) |
| **5** | Operator Override | Governance | Human judgment | AR as UI surface |
| **6** | Milestone Partial Exit | Core Risk | Biometric milestones | AR to show milestones |
| **7** | Randomized Exit | Benchmark | Random timing | None |
| **8** | Max Risk / All-In Exit | Long Shot | Extreme limits | Optional (warning visuals) |
| **9** | Biometric Inverse Martingale | Long Shot | Biometric "wins" | Optional (warning visuals) |
| **10** | Distributed Multi-Manager | Governance | Multi-method blend | **Consumes AR signals** |
| **11** | AR Spatial Drift Exit | AR Native | Posture, gait, drift vectors | **Core AR method** |
| **12** | AR Capsule Behavior Exit | AR Native | Capsule wobble, jitter, offset | **Core AR method** |
| **13** | Spatial Opponent Pressure Hedge | Hedge | Distance, angles, cage/space control | **AR spatial maps** |
| **14** | Spatial Symmetry Hedge | Hedge | Left/right, front/back symmetry | **AR joint overlays** |
| **15** | Spatial Efficiency Arbitrage | Arbitrage | Useful vs wasted motion | **AR motion traces** |
| **16** | Capsule-Opponent Divergence Arbitrage | Arbitrage | Your capsule vs opponent capsule | **AR dual-capsule view** |
| **17** | Micro-Drift Scalping | Scalping | Micro-posture drift | **High-freq AR vectors** |
| **18** | Capsule Pulse Scalping | Scalping | Capsule micro-pulses | **Capsule animation** |
| **19** | Spatial Coaching Overlay | Coaching | Optimal vs actual vectors | **AR coaching lines** |
| **20** | Spatial Tempo Rhythm Method | Coaching | Rhythm, cadence, tempo | **AR tempo cues** |
| **21** | Spatial Collapse Prediction | Medical | Collapse-risk vectors | **AR risk halo** |
| **22** | Impact Vector Overload | Medical | Impact direction/magnitude | **AR impact cones** |
| **23** | Joint Divergence Method | Medical | Unsafe joint angles/torque | **AR joint warnings** |
| **24** | Spatial Recovery Envelope | Medical | Return-to-baseline envelope | **AR recovery shell** |

---

## Method Categories Explained

### Core Risk (Methods 1, 4, 6)
Standard risk management methods using biometric signals and volatility thresholds. Can optionally display AR visuals but do not generate spatial metrics.

### Core Brain (Methods 3, 10)
**AI-driven orchestration layers** that blend signals from all sources (biometrics, AR spatial, price, context) to output:
- **Exit Score** (0-100)
- **Position sizing recommendations**
- **Risk allocation**

These are the **primary consumers of AR signals**.

### Legacy (Method 2)
Traditional technical analysis exit signals. Included for baseline comparison. Not AR-integrated.

### Governance (Methods 5, 10)
Human oversight and multi-method blending. AR serves as a visual interface for operators.

### Benchmark (Method 7)
Random exit timing for control experiments. Not deployed in production.

### Long Shot (Methods 8, 9)
**Warning examples** of dangerous strategies. Included for training purposes only. **Do not deploy.**

### AR Native (Methods 11-12)
Generate **spatial drift** and **capsule behavior** metrics directly from 3D biomechanical data.

### Hedge (Methods 13-14)
Use **opponent pressure** and **symmetry divergence** from AR spatial maps to hedge risk.

### Arbitrage (Methods 15-16)
Exploit **efficiency gaps** and **capsule divergence** detected via AR motion analysis.

### Scalping (Methods 17-18)
High-frequency trading on **micro-drift** and **capsule pulse** signals from AR.

### Coaching (Methods 19-20)
Overlay **optimal movement vectors** and **tempo cues** for performance optimization.

### Medical (Methods 21-24)
**Critical safety methods** using AR spatial intelligence to predict injury risk and enforce recovery protocols.

---

## AR/3D Spatial Intelligence Layer

### Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                 3D BIOMECHANICAL SENSORS                    │
│  Motion capture, IMU arrays, force plates, video analysis   │
└─────────────────┬───────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────┐
│              AR SPATIAL INTELLIGENCE ENGINE                 │
│                                                             │
│  ┌──────────────────┐  ┌──────────────────┐              │
│  │ Drift Detection  │  │ Capsule Behavior │              │
│  │ (Methods 11, 17) │  │ (Methods 12, 18) │              │
│  └──────────────────┘  └──────────────────┘              │
│                                                             │
│  ┌──────────────────┐  ┌──────────────────┐              │
│  │ Symmetry Analysis│  │ Efficiency Calc  │              │
│  │ (Method 14)      │  │ (Method 15)      │              │
│  └──────────────────┘  └──────────────────┘              │
│                                                             │
│  ┌──────────────────┐  ┌──────────────────┐              │
│  │ Collapse Risk    │  │ Impact Vectors   │              │
│  │ (Method 21)      │  │ (Method 22)      │              │
│  └──────────────────┘  └──────────────────┘              │
│                                                             │
│  ┌──────────────────┐  ┌──────────────────┐              │
│  │ Joint Divergence │  │ Recovery Envelope│              │
│  │ (Method 23)      │  │ (Method 24)      │              │
│  └──────────────────┘  └──────────────────┘              │
│                                                             │
└─────────────────┬───────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────┐
│            SIGNAL ROUTING TO CORE BRAIN                     │
│                                                             │
│  Method 3 (Hybrid AI Weighted) ← All AR signals            │
│  Method 10 (Distributed Multi-Manager) ← Blended signals   │
│                                                             │
└─────────────────┬───────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────┐
│              AR VISUALIZATION LAYER                         │
│                                                             │
│  • Biomech Capsules (wireframe + pulse)                    │
│  • Risk Halos (collapse prediction)                        │
│  • Impact Cones (overload vectors)                         │
│  • Joint Warnings (divergence alerts)                      │
│  • Recovery Shells (return-to-baseline envelopes)          │
│  • Coaching Overlays (optimal vs actual)                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Signal Flow Architecture

### AR Signal Producers (Methods 11-24)

| Method | Output Signals | Update Frequency | Downstream Consumers |
|--------|---------------|------------------|---------------------|
| **11** | Drift vectors (x, y, z), magnitude | 30 Hz | Method 3, 10 |
| **12** | Capsule wobble, jitter, offset | 30 Hz | Method 3, 10 |
| **13** | Opponent distance, pressure angle | 10 Hz | Method 3, 10 |
| **14** | Symmetry score (0-1), divergence zones | 10 Hz | Method 3, 10 |
| **15** | Efficiency ratio (useful/wasted motion) | 5 Hz | Method 3, 10 |
| **16** | Capsule divergence (your vs opponent) | 10 Hz | Method 3, 10 |
| **17** | Micro-drift triggers (boolean + direction) | 60 Hz | Method 3, 10 |
| **18** | Capsule pulse cadence (Hz) | 30 Hz | Method 3, 10 |
| **19** | Coaching vector deltas (optimal - actual) | 10 Hz | Operator UI |
| **20** | Tempo rhythm score (0-1) | 10 Hz | Operator UI |
| **21** | Collapse risk score (0-1), balance stability | 30 Hz | Method 3, 10, Medical Alert |
| **22** | Impact magnitude, direction vectors | 30 Hz | Method 3, 10, Medical Alert |
| **23** | Joint angle safety (boolean), torque overload | 30 Hz | Method 3, 10, Medical Alert |
| **24** | Recovery progress (0-1), envelope breach | 5 Hz | Method 3, 10, Medical Alert |

### Signal Consumers (Methods 3, 10)

**Method 3: Hybrid AI Weighted**
- Ingests all AR signals plus biometrics, price, context
- Uses neural network to weight signals dynamically
- Outputs **Exit Score** (0-100)

**Method 10: Distributed Multi-Manager**
- Blends outputs from Methods 1, 3, 4, 6 plus AR signals
- Reduces idiosyncratic error
- Outputs consensus **Exit Score**

---

## Sport-Specific Playbooks

### Basketball
**AR Methods in Focus:**
- Method 21 (Collapse Prediction) — fatigue-driven ankle/knee risk
- Method 22 (Impact Overload) — landing impact vectors
- Method 23 (Joint Divergence) — knee valgus detection

**Core Brain:**
- Method 3 (Hybrid AI) with emphasis on vertical load symmetry

---

### MMA / Combat Sports
**AR Methods in Focus:**
- Method 13 (Opponent Pressure Hedge) — cage control, distance management
- Method 21 (Collapse Prediction) — balance instability pre-KO
- Method 22 (Impact Overload) — strike direction + magnitude

**Core Brain:**
- Method 10 (Distributed) blending opponent pressure + collapse risk

---

### Rugby / Soccer
**AR Methods in Focus:**
- Method 14 (Symmetry Hedge) — left/right imbalance from tackles
- Method 22 (Impact Overload) — collision vectors
- Method 24 (Recovery Envelope) — return-to-play readiness

**Core Brain:**
- Method 3 (Hybrid AI) with emphasis on impact accumulation

---

### Golf
**AR Methods in Focus:**
- Method 15 (Efficiency Arbitrage) — swing efficiency gaps
- Method 17 (Micro-Drift Scalping) — posture micro-corrections
- Method 20 (Tempo Rhythm) — swing tempo consistency

**Core Brain:**
- Method 3 (Hybrid AI) with emphasis on tempo + efficiency

---

### Camel Racing
**AR Methods in Focus:**
- Method 11 (Spatial Drift) — jockey posture drift mid-race
- Method 21 (Collapse Prediction) — dehydration-driven instability
- Method 24 (Recovery Envelope) — post-race recovery monitoring

**Core Brain:**
- Method 10 (Distributed) blending drift + collapse risk

---

## Production Deployment Status

### Deployed Methods (Live)
- ✅ Method 1: Adaptive Trailing Stop
- ✅ Method 3: Hybrid AI Weighted
- ✅ Method 4: Volatility Event-Driven
- ✅ Method 6: Milestone Partial Exit
- ✅ Method 10: Distributed Multi-Manager
- ✅ Method 11: AR Spatial Drift Exit
- ✅ Method 12: AR Capsule Behavior Exit
- ✅ Method 21: Spatial Collapse Prediction
- ✅ Method 22: Impact Vector Overload
- ✅ Method 23: Joint Divergence Method
- ✅ Method 24: Spatial Recovery Envelope

### Beta Testing
- 🔶 Method 13: Spatial Opponent Pressure Hedge
- 🔶 Method 14: Spatial Symmetry Hedge
- 🔶 Method 17: Micro-Drift Scalping
- 🔶 Method 19: Spatial Coaching Overlay

### Development
- 🟡 Method 15: Spatial Efficiency Arbitrage
- 🟡 Method 16: Capsule-Opponent Divergence Arbitrage
- 🟡 Method 18: Capsule Pulse Scalping
- 🟡 Method 20: Spatial Tempo Rhythm Method

### Reference Only (Not Deployed)
- ⚠️ Method 2: Pattern-Only Exit (legacy benchmark)
- ⚠️ Method 7: Randomized Exit (control group)
- ❌ Method 8: Max Risk / All-In Exit (WARNING: Do not deploy)
- ❌ Method 9: Biometric Inverse Martingale (WARNING: Do not deploy)

---

## API Endpoints

### AR Medical Intelligence
```
POST /api/ar/medical/collapse-prediction
POST /api/ar/medical/impact-overload
POST /api/ar/medical/joint-divergence
POST /api/ar/medical/recovery-envelope
```

### AR Trading Signals
```
POST /api/ar/trading/spatial-drift
POST /api/ar/trading/capsule-behavior
POST /api/ar/trading/opponent-pressure
POST /api/ar/trading/symmetry-analysis
```

### Core Brain Outputs
```
POST /api/ar/exit-score/hybrid-ai
POST /api/ar/exit-score/distributed-multi
```

---

## Practical Reading Guide

### For Medical Staff
Focus on **Methods 21-24**. These are your safety net. Live AR overlays show:
- **Red Halo** = Collapse risk > 75%
- **Amber Cones** = Impact overload detected
- **Red Joint Markers** = Unsafe joint angles
- **Green Shell** = Recovery on track

### For Coaches
Focus on **Methods 19-20**. These are your performance optimization tools. Live AR overlays show:
- **Blue Vector Lines** = Optimal vs actual movement
- **Tempo Pulse** = Rhythm consistency

### For Traders
Focus on **Methods 11-18** as signal sources. Route all signals through **Method 3** (Hybrid AI Weighted) for the final **Exit Score**.

### For Operators
Use **Method 5** (Operator Override) with AR as your visual interface. All other methods feed into your decision dashboard.

---

## Contact & Support

- **AR Technical Documentation:** https://docs.bim-apes.com/ar
- **Medical Safety Protocols:** medical@bim-apes.com
- **Trading Support:** trading@bim-apes.com

---

**© 2026 BIM-APES. All rights reserved.**
