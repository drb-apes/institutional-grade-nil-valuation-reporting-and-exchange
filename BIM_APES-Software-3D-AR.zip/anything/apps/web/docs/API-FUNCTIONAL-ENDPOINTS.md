# BIM-APES Functional API Endpoints

## 🎯 Complete Production-Ready System

All endpoints are **fully functional** with real database operations, Stripe integration, and comprehensive error handling.

---

## 📍 Quick Start

### 1. Seed Demo Data
```bash
POST /api/demo/seed-data
Content-Type: application/json

{
  "count": 10,
  "sport": "Basketball"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Demo data seeded successfully",
  "summary": {
    "athletes": 10,
    "sessions": 50,
    "biometrics": 300,
    "valuations": 70,
    "campaigns": 5
  }
}
```

### 2. View BiomechFlow Charts
Navigate to: `/demo/biomech-capsules`

### 3. Test Payment Flow
Navigate to: `/demo/launch-dashboard`

---

## 🏃 Athletes API

### List Athletes
```bash
GET /api/athletes?sport=Basketball&limit=20&offset=0
```

**Query Parameters:**
- `sport` (optional) - Filter by sport
- `team` (optional) - Filter by team
- `nil_tier` (optional) - Filter by NIL tier (Tier I, II, or III)
- `limit` (default: 50) - Results per page
- `offset` (default: 0) - Pagination offset

**Response:**
```json
{
  "success": true,
  "athletes": [
    {
      "id": "uuid",
      "first_name": "Sarah",
      "last_name": "Johnson",
      "sport": "Basketball",
      "position": "Guard",
      "team": "Lincoln Academy",
      "nil_tier": "Tier II",
      "current_nil_value": 125.50,
      "recent_readings_count": 42
    }
  ],
  "pagination": {
    "total": 150,
    "limit": 20,
    "offset": 0,
    "hasMore": true
  }
}
```

### Create Athlete
```bash
POST /api/athletes
Content-Type: application/json

{
  "first_name": "Jordan",
  "last_name": "Smith",
  "sport": "Basketball",
  "position": "Forward",
  "team": "Washington Prep",
  "date_of_birth": "2006-03-15",
  "height_cm": 188,
  "weight_kg": 82,
  "nil_tier": "Tier III"
}
```

### Get Athlete Details
```bash
GET /api/athletes/{id}
```

**Response includes:**
- Basic athlete info
- Latest NIL valuation
- Recent biometric readings (7 days)
- Recent performance sessions (10 most recent)
- Active certificate count

### Update Athlete
```bash
PATCH /api/athletes/{id}
Content-Type: application/json

{
  "nil_tier": "Tier II",
  "consent_biometric": true,
  "consent_nil": true
}
```

### Delete Athlete (Soft Delete)
```bash
DELETE /api/athletes/{id}
```

Sets `coalition_status` to "Inactive"

---

## 🩺 Biometrics API

### Get Athlete Biometrics
```bash
GET /api/biometrics/athlete/{id}?days=7&index=RHRi
```

**Query Parameters:**
- `days` (default: 7) - Time range
- `index` (optional) - Filter by specific index code

**Response:**
```json
{
  "success": true,
  "athlete": {
    "id": "uuid",
    "name": "Sarah Johnson"
  },
  "readings": [
    {
      "index_code": "RHRi",
      "index_name": "Resting Heart Rate Index",
      "cluster": "Cardiovascular Metrics",
      "score": 72.5,
      "baseline": 68.0,
      "trend": "stable",
      "recorded_at": "2026-04-18T10:30:00Z"
    }
  ],
  "summary": [
    {
      "index_code": "RHRi",
      "latest_score": 72.5,
      "avg_score": 70.2,
      "count": 42
    }
  ]
}
```

### Record Biometric Readings
```bash
POST /api/biometrics/athlete/{id}
Content-Type: application/json

{
  "readings": [
    {
      "index_code": "RHRi",
      "score": 72.5,
      "baseline": 68.0,
      "trend": "stable",
      "context": "morning_session"
    },
    {
      "index_code": "HRVi",
      "score": 85.2,
      "baseline": 80.0,
      "trend": "improving"
    }
  ]
}
```

**Available Index Codes:**
- `RHRi` - Resting Heart Rate Index
- `HRVi` - Heart Rate Variability Index
- `SpO2i` - Oxygen Saturation Index
- `CLi` - Cognitive Load Index
- `FAi` - Fatigue Index
- `RRi` - Respiratory Rate Index
- [100+ more indices available]

---

## 💰 NIL Valuation API

### Get NIL History & Progression
```bash
GET /api/nil/athlete/{id}?days=30
```

**Response:**
```json
{
  "success": true,
  "athlete": {
    "id": "uuid",
    "name": "Sarah Johnson",
    "nil_tier": "Tier II"
  },
  "valuations": [
    {
      "true_value": 125.50,
      "market_value": 118.30,
      "gap": 7.20,
      "gap_percentage": 5.73,
      "direction": "long",
      "confidence": 0.87,
      "calculated_at": "2026-04-18T10:00:00Z"
    }
  ],
  "age_progression": [
    { "age": 14, "model_nil": 5.2, "market_nil": 0 },
    { "age": 15, "model_nil": 12.8, "market_nil": 0 },
    { "age": 18, "model_nil": 52.3, "market_nil": 45.0 }
  ],
  "summary": {
    "total_valuations": 28,
    "latest_true_value": 125.50,
    "avg_gap": 6.42,
    "avg_confidence": 0.82
  }
}
```

### Calculate New NIL Valuation
```bash
POST /api/nil/athlete/{id}
Content-Type: application/json

{
  "market_value": 118.30,
  "performance_metrics": {},
  "social_metrics": {
    "engagement_rate": 8.5
  }
}
```

**Calculation includes:**
- Biometric data (last 24 hours)
- Performance metrics
- Social engagement
- Market momentum
- Risk-adjusted confidence

**Auto-creates mispricing event if:**
- Gap > $5 AND confidence > 0.7

---

## ⚡ Fan Engagement API

### Get Engagement Metrics
```bash
# For specific athlete
GET /api/fan-engagement/metrics?athleteId={id}&days=30

# Top athletes overall
GET /api/fan-engagement/metrics?days=30&limit=10
```

**Response (specific athlete):**
```json
{
  "success": true,
  "engagement_summary": {
    "total_boosts": 247,
    "total_replays": 89,
    "total_shares": 34,
    "total_votes": 52,
    "total_value": 422.0
  },
  "tipping_flow": {
    "total_boosts": 247,
    "nil_moments": 136,
    "sponsor_bonuses": 54,
    "athlete_rewards": 84
  }
}
```

**Response (top athletes):**
```json
{
  "success": true,
  "top_athletes": [
    {
      "id": "uuid",
      "name": "Sarah Johnson",
      "boost_count": 247,
      "total_engagements": 422,
      "total_value": 1250.50
    }
  ],
  "aggregate_tipping_flow": {
    "total_boosts": 5834,
    "nil_moments": 3209,
    "sponsor_bonuses": 1283,
    "athlete_rewards": 1984
  }
}
```

### Record Fan Engagement
```bash
POST /api/fan-engagement/metrics
Content-Type: application/json

{
  "athlete_id": "uuid",
  "engagement_type": "boost",
  "engagement_value": 1,
  "campaign_id": "uuid",  // optional
  "metadata": {}
}
```

**Engagement Types:**
- `boost` - Fan boost (worth +0.5 to NIL)
- `replay` - Replay moment (+1.0)
- `share` - Social share (+2.0)
- `vote` - Vote on highlight (+2.0)

---

## 💳 Stripe Payment API

### Create Checkout Session
```bash
POST /api/stripe/create-checkout
Content-Type: application/json

{
  "tier": "district",
  "billingPeriod": "monthly",
  "organizationName": "Lincoln School District",
  "contactEmail": "admin@lincoln.edu",
  "studentCount": 2500
}
```

**Tier Options:**
| Tier | Monthly | Annual | Students |
|------|---------|--------|----------|
| school | $299 | $2,990 | 500 |
| district | $999 | $9,990 | 5,000 |
| regional | $2,499 | $24,990 | 25,000 |
| statewide | $4,999 | $49,990 | Unlimited |

**Response (with Stripe configured):**
```json
{
  "success": true,
  "checkoutUrl": "https://checkout.stripe.com/...",
  "sessionId": "cs_live_...",
  "amount": 999.00,
  "tier": "District License",
  "billingPeriod": "monthly"
}
```

**Response (demo mode):**
```json
{
  "success": true,
  "checkoutUrl": "/demo/launch-dashboard?success=true&session_id=cs_demo_...",
  "sessionId": "cs_demo_1713445200000_district_monthly",
  "demo": true
}
```

**Order stored in database:**
- `sponsor_campaigns` table
- Status: `pending_payment` (live) or `demo_active` (demo)
- 90-day campaign duration

---

## 📊 Dashboard API

### Get Dashboard Summary
```bash
GET /api/dashboard/summary
```

**Response:**
```json
{
  "success": true,
  "data": {
    "metrics": {
      "activeAthletes": 142,
      "liveEvents": 8,
      "criticalAlerts": 3,
      "nilVolume24h": 12850
    },
    "liveEvents": [...],
    "topAlerts": [...],
    "nilLeaders": [...],
    "sponsorWindows": [...]
  }
}
```

---

## 🧪 Demo & Testing API

### Seed Demo Data
```bash
POST /api/demo/seed-data
Content-Type: application/json

{
  "count": 10,
  "sport": "Basketball"
}
```

**Creates:**
- 10 athletes
- 5 performance sessions per athlete
- 6 biometric indices per session
- 7 NIL valuations per athlete
- 5 sponsor campaigns

### Clear Demo Data
```bash
DELETE /api/demo/seed-data
```

Removes all demo data from last hour

---

## 🎨 BiomechFlow Capsule Charts

### Available Visualizations

1. **NIL Valuation Progression Chart**
   - Data source: `/api/nil/athlete/{id}`
   - Shows: Youth → Adult → Market NIL growth
   - Type: Line chart with dual lines

2. **Risk-Adjusted Performance Dashboard**
   - Data source: `/api/biometrics/athlete/{id}`
   - Shows: 6-dimension athlete profile
   - Type: Radar chart

3. **Boost Credits Chart**
   - Data source: `/api/fan-engagement/metrics`
   - Shows: Fan engagement volume by athlete
   - Type: Bar chart

4. **Kid-Friendly NIL Visual**
   - Shows: Achievement badges & storyline progress
   - Type: Gamified progress tracker

5. **Fan Tipping Flow**
   - Data source: `/api/fan-engagement/metrics`
   - Shows: Boosts → NIL Moments → Bonuses → Rewards
   - Type: Flow diagram

---

## 🚀 Live Demo Pages

### 1. BiomechFlow Capsules
**URL:** `/demo/biomech-capsules`

**Features:**
- Athlete selector
- Live data refresh
- All 5 chart types
- Real-time boost recording
- Demo data seeding

**Usage:**
1. Click "Seed Demo Data" to populate database
2. Select an athlete
3. View all BiomechFlow visualizations
4. Click "Give Boost" to record engagement
5. Watch charts update in real-time

### 2. 90-Day Launch Dashboard
**URL:** `/demo/launch-dashboard`

**Features:**
- 4 licensing tiers
- Monthly/Annual billing toggle
- Stripe checkout integration
- 90-day timeline visualization
- Success flow with all charts

**Usage:**
1. Select licensing tier
2. Choose billing period
3. Review order summary
4. Complete checkout (Stripe or demo mode)
5. View success screen with charts

### 3. Model NIL Bank
**URL:** `/demo/model-nil-bank`

**Features:**
- Youth NIL education demo
- Fan engagement showcase
- Impact metrics visualization
- Pro transition pipeline

---

## 🔒 Error Handling

All endpoints use standardized error responses:

```json
{
  "success": false,
  "error": "VALIDATION_ERROR",
  "message": "Missing required fields: first_name, last_name",
  "timestamp": "2026-04-18T10:00:00Z"
}
```

**Error Types:**
- `VALIDATION_ERROR` (400)
- `NOT_FOUND` (404)
- `UNAUTHORIZED` (401)
- `FORBIDDEN` (403)
- `DATABASE_ERROR` (500)
- `INTERNAL_ERROR` (500)

---

## ⚙️ Environment Setup

### Required Environment Variables

```bash
# Database (required)
DATABASE_URL=postgresql://...

# Stripe (optional for demo mode)
STRIPE_SECRET_KEY=sk_live_... # or sk_test_...

# App URL (auto-detected in development)
NEXT_PUBLIC_CREATE_APP_URL=https://your-domain.com
```

### Demo Mode vs Production

**Demo Mode** (no STRIPE_SECRET_KEY):
- Mock checkout sessions
- Data stored in database
- No actual payment processing
- Perfect for testing

**Production Mode** (with STRIPE_SECRET_KEY):
- Real Stripe checkout sessions
- Actual payment processing
- Webhook handling ready
- Production-ready

---

## 📈 Database Schema

### Core Tables

- `athletes` - Athlete profiles
- `biometric_readings` - Biometric data
- `nil_valuations` - NIL calculations
- `performance_sessions` - Training/competition sessions
- `sponsor_campaigns` - Licensing & campaigns
- `sponsor_activations` - Sponsor moments
- `sponsor_engagement` - Fan interactions
- `mispricing_events` - Trading opportunities
- `coalition_certificates` - Coalition assets

### Relationships

```
athletes (1) → (many) biometric_readings
athletes (1) → (many) nil_valuations
athletes (1) → (many) performance_sessions
athletes (1) → (many) sponsor_activations
sponsor_campaigns (1) → (many) sponsor_activations
sponsor_activations (1) → (many) sponsor_engagement
```

---

## 🎯 Next Steps

1. **Seed demo data:** `POST /api/demo/seed-data`
2. **View visualizations:** Visit `/demo/biomech-capsules`
3. **Test payment flow:** Visit `/demo/launch-dashboard`
4. **Read API docs:** Visit `/api/docs`
5. **Configure Stripe:** Add `STRIPE_SECRET_KEY` for production

---

## 📞 Support

For questions or issues:
- View live API docs: `/api/docs`
- Check demo pages for examples
- Review error messages (standardized format)

---

**All endpoints are production-ready with:**
✅ Real database operations  
✅ Comprehensive error handling  
✅ Input validation  
✅ Response standardization  
✅ Stripe integration (live & demo modes)  
✅ Transaction safety  
✅ Query optimization  
✅ Pagination support  
✅ Filter capabilities  
✅ Full CRUD operations  
