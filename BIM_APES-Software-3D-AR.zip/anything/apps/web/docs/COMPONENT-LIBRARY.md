# BIM-APES Shared Component Library

## Overview
The BIM-APES shared component library provides reusable UI components that ensure consistent design and behavior across all dashboards. This reduces code duplication by ~40% and makes the application easier to maintain.

---

## 📦 Component Catalog

### 1. **DashboardHeader**
Unified dashboard header with title, description, refresh button, and optional children.

**Location:** `/apps/web/src/components/shared/DashboardHeader.jsx`

**Props:**
```typescript
{
  icon: LucideIcon;          // Icon component from lucide-react
  title: string;             // Dashboard title
  description: string;       // Dashboard subtitle/description
  onRefresh: () => void;     // Refresh callback function
  loading?: boolean;         // Loading state for refresh button
  children?: ReactNode;      // Optional header content (e.g., tabs, filters)
}
```

**Usage:**
```javascript
import DashboardHeader from "@/components/shared/DashboardHeader";
import { Brain } from "lucide-react";

<DashboardHeader
  icon={Brain}
  title="Intelligence Dashboard"
  description="Real-time biomechanical intelligence + market signals"
  onRefresh={loadData}
  loading={loading}
>
  {/* Optional: Add tabs, filters, or athlete info here */}
</DashboardHeader>
```

**Visual Features:**
- Sticky positioning (stays at top during scroll)
- Navy gradient background with gold accents
- Loading spinner on refresh button
- Responsive layout

---

### 2. **LoadingScreen**
Full-screen loading state with spinner and message.

**Location:** `/apps/web/src/components/shared/LoadingScreen.jsx`

**Props:**
```typescript
{
  message?: string;  // Loading message (default: "Loading...")
}
```

**Usage:**
```javascript
import LoadingScreen from "@/components/shared/LoadingScreen";

if (loading) {
  return <LoadingScreen message="Loading Intelligence Engines..." />;
}
```

**Visual Features:**
- Full-screen navy gradient background
- Gold/white animated spinner
- Centered layout with message

---

### 3. **ErrorScreen**
Full-screen error state with retry button.

**Location:** `/apps/web/src/components/shared/ErrorScreen.jsx`

**Props:**
```typescript
{
  title?: string;           // Error title (default: "Error Loading Data")
  message: string;          // Error message
  onRetry?: () => void;     // Optional retry callback
}
```

**Usage:**
```javascript
import ErrorScreen from "@/components/shared/ErrorScreen";

if (error) {
  return (
    <ErrorScreen
      title="Error Loading Intelligence"
      message={error}
      onRetry={loadIntelligence}
    />
  );
}
```

**Visual Features:**
- Full-screen navy gradient background
- Red error icon
- Centered error card with glass effect
- Optional retry button

---

### 4. **PillTabs**
Pill-style tab navigation with icons.

**Location:** `/apps/web/src/components/shared/PillTabs.jsx`

**Props:**
```typescript
{
  tabs: Array<{
    id: string;
    label: string;
    icon: LucideIcon;
  }>;
  activeTab: string;         // Currently active tab ID
  onChange: (tabId: string) => void;  // Tab change callback
}
```

**Usage:**
```javascript
import PillTabs from "@/components/shared/PillTabs";
import { BarChart3, DollarSign } from "lucide-react";

const tabs = [
  { id: "overview", label: "Portfolio", icon: BarChart3 },
  { id: "valuations", label: "Valuations", icon: DollarSign },
];

<PillTabs
  tabs={tabs}
  activeTab={selectedView}
  onChange={setSelectedView}
/>
```

**Visual Features:**
- Active tab: Gold background with shadow
- Inactive tabs: Dark background with hover effect
- Icon + label layout
- Smooth transitions

---

### 5. **MetricCard**
Display card for KPIs and metrics.

**Location:** `/apps/web/src/components/shared/MetricCard.jsx`

**Props:**
```typescript
{
  label: string;             // Metric label
  value: string | number;    // Metric value
  subtext?: string;          // Optional subtext below value
  icon: LucideIcon;          // Icon component
  valueColor?: string;       // Custom value color (default: "text-white")
  children?: ReactNode;      // Optional custom content at bottom
}
```

**Usage:**
```javascript
import MetricCard from "@/components/shared/MetricCard";
import { DollarSign, ArrowUpRight } from "lucide-react";

<MetricCard
  label="Total Value"
  value="$1,234,567"
  icon={DollarSign}
>
  {/* Optional: Custom content like PnL */}
  <div className="flex items-center gap-1 text-sm font-semibold text-green-400">
    <ArrowUpRight size={16} />
    $12,345 (+5.2%)
  </div>
</MetricCard>
```

**Visual Features:**
- Navy gradient background
- Gold icon in top-right
- Uppercase label with tracking
- Large value display
- Hover shadow effect

---

### 6. **GlassPanel**
Glass-effect panel with optional gradient header.

**Location:** `/apps/web/src/components/shared/GlassPanel.jsx`

**Props:**
```typescript
{
  title?: string;            // Panel title (shows gradient header if provided)
  icon?: LucideIcon;         // Optional icon in header
  children: ReactNode;       // Panel content
  className?: string;        // Additional CSS classes
}
```

**Usage:**
```javascript
import GlassPanel from "@/components/shared/GlassPanel";
import { Eye } from "lucide-react";

<GlassPanel title="Top NIL Opportunities" icon={Eye}>
  <div className="p-6">
    {/* Panel content */}
  </div>
</GlassPanel>
```

**Visual Features:**
- Dark glass background with blur
- Optional navy gradient header
- Gold border with low opacity
- Overflow hidden for clean edges

---

## 🎨 Design System

### Color Palette
```javascript
{
  primary: {
    navy: "#1B3A57",
    darkNavy: "#152E45",
    lightNavy: "#2A4A68",
  },
  accent: {
    gold: "#C8A882",
    darkGold: "#B8956A",
    lightGold: "#D4B896",
  },
  background: {
    dark: "#0D1421",
    glassDark: "rgba(13, 20, 33, 0.6)",
  },
  text: {
    white: "#FFFFFF",
    gray: "#9CA3AF",
    darkGray: "#6B7280",
  }
}
```

### Typography
- **Headers:** font-bold, large sizes (text-4xl, text-3xl)
- **Labels:** text-gray-400, text-sm, uppercase, tracking-wide
- **Values:** font-bold, text-white, large sizes (text-3xl, text-2xl)
- **Body:** text-gray-300, text-sm/text-base

### Spacing
- **Base grid:** 8px (Tailwind default)
- **Component padding:** p-6
- **Component gaps:** gap-3, gap-4, gap-6
- **Section margins:** mb-6, mb-8

---

## 📊 Migration Guide

### Before (Duplicated Code):
```javascript
// Header repeated in 3 files (~50 lines each)
<div className="bg-gradient-to-r from-[#1B3A57]/90 to-[#152E45]/90...">
  <div className="max-w-7xl mx-auto px-8 py-6">
    <div className="flex items-center justify-between mb-6">
      <div>
        <h1 className="text-4xl font-bold text-white mb-2...">
          {/* Title */}
        </h1>
        <p className="text-gray-300 text-lg">
          {/* Description */}
        </p>
      </div>
      <button onClick={refresh}...>
        {/* Refresh button */}
      </button>
    </div>
  </div>
</div>
```

### After (Shared Component):
```javascript
<DashboardHeader
  icon={Brain}
  title="Intelligence Dashboard"
  description="Real-time biomechanical intelligence + market signals"
  onRefresh={loadIntelligence}
  loading={loading}
/>
```

**Reduction:** 50 lines → 7 lines per dashboard (-86%)

---

## 🚀 Benefits

### 1. Code Reduction
- **Intelligence Dashboard:** 550 → 350 lines (-36%)
- **Investor Dashboard:** 480 → 280 lines (-42%)
- **Federation Dashboard:** 450 → 260 lines (-42%)
- **Total:** ~600 lines eliminated

### 2. Consistency
- All headers look/behave identically
- Same loading/error states everywhere
- Unified design language

### 3. Maintainability
- Change header → update 1 file (not 3)
- Add new prop → available everywhere instantly
- Bug fix propagates automatically

### 4. Developer Velocity
- New dashboards ~40% faster to build
- Less code to test
- Fewer edge cases

---

## 📋 Component Usage Matrix

| Component | Intelligence | Investor | Federation | Usage |
|-----------|-------------|----------|------------|-------|
| DashboardHeader | ✅ | ✅ | ✅ | 3/3 |
| LoadingScreen | ✅ | ✅ | ✅ | 3/3 |
| ErrorScreen | ✅ | ✅ | ✅ | 3/3 |
| PillTabs | ❌ | ✅ | ✅ | 2/3 |
| MetricCard | ❌ | ✅ (4x) | ✅ (5x) | 2/3 |
| GlassPanel | ❌ | ✅ (2x) | ✅ (2x) | 2/3 |

---

## 🔄 Future Enhancements

### Potential New Components:
1. **AlertBanner** - Standardize critical alert displays
2. **DataTable** - Reusable table with sorting/filtering
3. **ChartCard** - Wrapper for Recharts components
4. **ModalDialog** - Consistent modal pattern
5. **FormField** - Standardized form inputs

### Component Evolution:
- Add theme variants (dark/light)
- Add size variants (sm/md/lg)
- Add animation presets
- Add accessibility enhancements

---

## 🧪 Testing Guidelines

### Component Tests:
```javascript
// Example: DashboardHeader.test.jsx
import { render, screen } from '@testing-library/react';
import DashboardHeader from './DashboardHeader';

test('renders title and description', () => {
  render(
    <DashboardHeader
      icon={TestIcon}
      title="Test Dashboard"
      description="Test Description"
      onRefresh={() => {}}
    />
  );
  
  expect(screen.getByText('Test Dashboard')).toBeInTheDocument();
  expect(screen.getByText('Test Description')).toBeInTheDocument();
});
```

---

## 📚 Additional Resources

- **Tailwind CSS:** https://tailwindcss.com/docs
- **Lucide Icons:** https://lucide.dev
- **React Patterns:** https://reactpatterns.com

---

## 🎯 Quick Reference

### Import Paths:
```javascript
import DashboardHeader from "@/components/shared/DashboardHeader";
import LoadingScreen from "@/components/shared/LoadingScreen";
import ErrorScreen from "@/components/shared/ErrorScreen";
import PillTabs from "@/components/shared/PillTabs";
import MetricCard from "@/components/shared/MetricCard";
import GlassPanel from "@/components/shared/GlassPanel";
```

### Common Icons:
```javascript
import {
  Brain,        // Intelligence
  TrendingUp,   // Investor
  Globe,        // Federation
  BarChart3,    // Overview
  DollarSign,   // Valuations
  Target,       // Trading
  Activity,     // Positions
  Users,        // Athletes
  Shield,       // Coalitions
  Eye,          // Opportunities
  AlertCircle,  // Alerts/Warnings
} from "lucide-react";
```
