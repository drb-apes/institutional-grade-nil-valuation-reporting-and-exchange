/**
 * BIM-APES Mobile Translation Utility
 */

import AsyncStorage from "react-native-async-storage/async-storage";

const SUPPORTED_LANGUAGES = {
  en: { name: "English", flag: "🇬🇧" },
  es: { name: "Español", flag: "🇪🇸" },
  fr: { name: "Français", flag: "🇫🇷" },
  de: { name: "Deutsch", flag: "🇩🇪" },
  it: { name: "Italiano", flag: "🇮🇹" },
  pt: { name: "Português", flag: "🇵🇹" },
  zh: { name: "中文", flag: "🇨🇳" },
  ja: { name: "日本語", flag: "🇯🇵" },
  ar: { name: "العربية", flag: "🇸🇦" },
  ru: { name: "Русский", flag: "🇷🇺" },
};

const translationCache = new Map();
const STORAGE_KEY = "@bim-apes:language";

/**
 * Translate text using Google Translate API
 */
export async function translateText(text, targetLang, sourceLang = "en") {
  if (!text || targetLang === "en") return text;

  const cacheKey = `${sourceLang}:${targetLang}:${text}`;
  if (translationCache.has(cacheKey)) {
    return translationCache.get(cacheKey);
  }

  try {
    const baseUrl = process.env.EXPO_PUBLIC_BASE_URL || "";
    const response = await fetch(
      `${baseUrl}/integrations/google-translate/language/translate/v2`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          q: text,
          target: targetLang,
          source: sourceLang,
        }).toString(),
      },
    );

    const data = await response.json();
    const translated = data.data?.translations?.[0]?.translatedText || text;

    translationCache.set(cacheKey, translated);
    return translated;
  } catch (error) {
    console.error("Translation error:", error);
    return text;
  }
}

/**
 * Translate multiple texts in batch
 */
export async function translateBatch(texts, targetLang, sourceLang = "en") {
  if (!texts?.length || targetLang === "en") return texts;

  try {
    const baseUrl = process.env.EXPO_PUBLIC_BASE_URL || "";
    const params = new URLSearchParams();
    texts.forEach((text) => params.append("q", text));
    params.append("target", targetLang);
    if (sourceLang) params.append("source", sourceLang);

    const response = await fetch(
      `${baseUrl}/integrations/google-translate/language/translate/v2`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: params.toString(),
      },
    );

    const data = await response.json();
    return data.data?.translations?.map((t) => t.translatedText) || texts;
  } catch (error) {
    console.error("Batch translation error:", error);
    return texts;
  }
}

/**
 * Get stored language preference
 */
export async function getStoredLanguage() {
  try {
    const lang = await AsyncStorage.getItem(STORAGE_KEY);
    return lang || "en";
  } catch {
    return "en";
  }
}

/**
 * Store language preference
 */
export async function setStoredLanguage(lang) {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, lang);
  } catch (error) {
    console.error("Error storing language:", error);
  }
}

export { SUPPORTED_LANGUAGES };
