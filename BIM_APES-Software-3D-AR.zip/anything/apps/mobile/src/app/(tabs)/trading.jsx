"use client";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  TrendingUp,
  TrendingDown,
  Zap,
  DollarSign,
  AlertCircle,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Activity,
  BarChart3,
} from "lucide-react-native";

const NAVY = "#1B3A57";
const GOLD = "#C8A882";
const DARK = "#0D1421";
const DARK_NAVY = "#152E45";

export default function TradingScreen() {
  const insets = useSafeAreaInsets();
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("mispricing");
  const [mispricingEvents, setMispricingEvents] = useState([]);
  const [positions, setPositions] = useState([]);
  const [portfolio, setPortfolio] = useState(null);
  const [nilLeaders, setNilLeaders] = useState([]);
  const [executing, setExecuting] = useState(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      await Promise.all([loadMispricing(), loadPositions(), loadNILLeaders()]);
    } finally {
      setLoading(false);
    }
  };

  const loadMispricing = async () => {
    try {
      const res = await fetch("/api/trading/detect-mispricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      setMispricingEvents(data.events || []);
      setPortfolio(data.portfolio_summary || null);
    } catch (e) {
      console.error("Mispricing load error:", e);
    }
  };

  const loadPositions = async () => {
    try {
      const res = await fetch("/api/trading/portfolio/manage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "list_positions" }),
      });
      const data = await res.json();
      setPositions(data.positions || []);
    } catch (e) {
      console.error("Positions load error:", e);
    }
  };

  const loadNILLeaders = async () => {
    try {
      const res = await fetch("/api/athletes/list?limit=10");
      const data = await res.json();
      setNilLeaders(data.athletes || []);
    } catch (e) {
      console.error("NIL leaders load error:", e);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadAll();
    setRefreshing(false);
  }, []);

  const executePosition = async (event) => {
    setExecuting(event.id);
    try {
      const res = await fetch("/api/trading/portfolio/manage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "open_position",
          athlete_id: event.athlete_id,
          mispricing_event_id: event.id,
          position_type: event.direction,
          strategy:
            event.event_type === "momentum_spike" ? "scalping" : "arbitrage",
          entry_price: event.gap,
          size: Math.min(event.gap * 10, 5000),
          stop_loss: event.gap * 0.85,
          take_profit: event.gap * 1.25,
        }),
      });
      const data = await res.json();
      if (data.success) {
        Alert.alert(
          "✅ Position Opened",
          `${event.direction.toUpperCase()} position executed successfully.`,
        );
        await loadAll();
      } else {
        Alert.alert("Error", data.error || "Failed to execute position");
      }
    } catch (e) {
      Alert.alert("Error", "Network error executing position");
    } finally {
      setExecuting(null);
    }
  };

  const closePosition = async (positionId) => {
    try {
      const res = await fetch("/api/trading/portfolio/manage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "close_position",
          position_id: positionId,
          exit_price: 0,
        }),
      });
      const data = await res.json();
      if (data.success) {
        Alert.alert("✅ Position Closed", "Position closed successfully.");
        await loadPositions();
      }
    } catch (e) {
      Alert.alert("Error", "Failed to close position");
    }
  };

  const tabs = [
    { id: "mispricing", label: "Signals", icon: Zap },
    { id: "positions", label: "Positions", icon: Target },
    { id: "nil", label: "NIL Leaders", icon: TrendingUp },
  ];

  const openPositions = positions.filter((p) => p.status === "open");
  const totalPnL = openPositions.reduce((sum, p) => sum + (p.pnl || 0), 0);

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: DARK,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color={GOLD} />
        <Text style={{ color: "#9CA3AF", marginTop: 16, fontSize: 14 }}>
          Loading Trading Intelligence...
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: DARK }}>
      <StatusBar style="light" />

      {/* Header */}
      <View
        style={{
          backgroundColor: NAVY,
          paddingTop: insets.top + 12,
          paddingBottom: 16,
          paddingHorizontal: 20,
          borderBottomWidth: 1,
          borderBottomColor: GOLD + "30",
        }}
      >
        <Text
          style={{
            fontSize: 22,
            fontWeight: "bold",
            color: "white",
            marginBottom: 4,
          }}
        >
          Trading Intelligence
        </Text>
        <Text style={{ fontSize: 13, color: GOLD }}>
          NIL Mispricing • Portfolio • Positions
        </Text>

        {/* Portfolio Summary Bar */}
        <View
          style={{
            flexDirection: "row",
            marginTop: 16,
            backgroundColor: DARK_NAVY,
            borderRadius: 12,
            padding: 12,
            gap: 16,
          }}
        >
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 2 }}>
              Open Positions
            </Text>
            <Text style={{ fontSize: 20, fontWeight: "bold", color: "white" }}>
              {openPositions.length}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 2 }}>
              Total P&L
            </Text>
            <Text
              style={{
                fontSize: 20,
                fontWeight: "bold",
                color: totalPnL >= 0 ? "#10B981" : "#EF4444",
              }}
            >
              {totalPnL >= 0 ? "+" : ""}${Math.abs(totalPnL).toFixed(0)}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 2 }}>
              Active Signals
            </Text>
            <Text style={{ fontSize: 20, fontWeight: "bold", color: GOLD }}>
              {mispricingEvents.filter((e) => e.status === "active").length}
            </Text>
          </View>
        </View>
      </View>

      {/* Tab Bar */}
      <View
        style={{
          flexDirection: "row",
          backgroundColor: DARK_NAVY,
          paddingHorizontal: 16,
          paddingVertical: 8,
          borderBottomWidth: 1,
          borderBottomColor: NAVY,
        }}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <TouchableOpacity
              key={tab.id}
              onPress={() => setActiveTab(tab.id)}
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 8,
                borderRadius: 8,
                backgroundColor: isActive ? GOLD + "20" : "transparent",
                gap: 6,
              }}
            >
              <Icon size={16} color={isActive ? GOLD : "#6B7280"} />
              <Text
                style={{
                  fontSize: 13,
                  fontWeight: isActive ? "700" : "500",
                  color: isActive ? GOLD : "#6B7280",
                }}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 20,
        }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={GOLD}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* MISPRICING SIGNALS */}
        {activeTab === "mispricing" && (
          <View style={{ gap: 12 }}>
            {mispricingEvents.length === 0 ? (
              <EmptyState
                icon={Zap}
                message="No active mispricing signals"
                sub="Pull down to refresh"
              />
            ) : (
              mispricingEvents.map((event) => (
                <MispricingCard
                  key={event.id}
                  event={event}
                  onExecute={() => executePosition(event)}
                  executing={executing === event.id}
                />
              ))
            )}
          </View>
        )}

        {/* OPEN POSITIONS */}
        {activeTab === "positions" && (
          <View style={{ gap: 12 }}>
            {openPositions.length === 0 ? (
              <EmptyState
                icon={Target}
                message="No open positions"
                sub="Execute a signal to open a position"
              />
            ) : (
              openPositions.map((pos) => (
                <PositionCard
                  key={pos.id}
                  position={pos}
                  onClose={() => closePosition(pos.id)}
                />
              ))
            )}

            {/* Closed Positions Summary */}
            {positions.filter((p) => p.status === "closed").length > 0 && (
              <View style={{ marginTop: 8 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "700",
                    color: "white",
                    marginBottom: 12,
                  }}
                >
                  Closed Positions
                </Text>
                {positions
                  .filter((p) => p.status === "closed")
                  .slice(0, 3)
                  .map((pos) => (
                    <ClosedPositionRow key={pos.id} position={pos} />
                  ))}
              </View>
            )}
          </View>
        )}

        {/* NIL LEADERS */}
        {activeTab === "nil" && (
          <View style={{ gap: 12 }}>
            <View
              style={{
                backgroundColor: DARK_NAVY,
                borderRadius: 12,
                padding: 16,
                borderWidth: 1,
                borderColor: GOLD + "30",
                marginBottom: 4,
              }}
            >
              <Text style={{ fontSize: 13, color: "#9CA3AF", marginBottom: 4 }}>
                NIL Valuation Engine
              </Text>
              <Text style={{ fontSize: 12, color: GOLD, lineHeight: 18 }}>
                Real-time NIL momentum tracking using BIM-APES ML • Biometric
                performance weights • Coalition exposure
              </Text>
            </View>

            {nilLeaders.map((athlete, idx) => (
              <NILLeaderCard
                key={athlete.id}
                athlete={athlete}
                rank={idx + 1}
              />
            ))}

            {nilLeaders.length === 0 && (
              <EmptyState
                icon={TrendingUp}
                message="No athlete data"
                sub="Seed database to see NIL leaders"
              />
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function MispricingCard({ event, onExecute, executing }) {
  const isLong = event.direction === "long";
  const dirColor = isLong ? "#10B981" : "#EF4444";
  const timeLeft = Math.max(
    0,
    Math.floor((new Date(event.expires_at) - new Date()) / 1000),
  );
  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  const conf = ((event.confidence || 0) * 100).toFixed(0);

  return (
    <View
      style={{
        backgroundColor: DARK_NAVY,
        borderRadius: 14,
        borderWidth: 1.5,
        borderColor: dirColor + "50",
        overflow: "hidden",
      }}
    >
      {/* Direction Banner */}
      <View
        style={{
          backgroundColor: dirColor + "20",
          paddingHorizontal: 16,
          paddingVertical: 10,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          {isLong ? (
            <ArrowUpRight size={18} color={dirColor} />
          ) : (
            <ArrowDownRight size={18} color={dirColor} />
          )}
          <Text style={{ fontSize: 15, fontWeight: "800", color: dirColor }}>
            {event.direction.toUpperCase()} SIGNAL
          </Text>
        </View>
        <View
          style={{
            backgroundColor: dirColor + "30",
            paddingHorizontal: 10,
            paddingVertical: 4,
            borderRadius: 20,
          }}
        >
          <Text style={{ fontSize: 12, fontWeight: "700", color: dirColor }}>
            {conf}% confidence
          </Text>
        </View>
      </View>

      <View style={{ padding: 16 }}>
        {/* Metrics */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            marginBottom: 16,
          }}
        >
          <MetricPill
            label="Gap"
            value={`$${(event.gap || 0).toFixed(2)}`}
            color={GOLD}
          />
          <MetricPill
            label="Type"
            value={event.event_type || "signal"}
            color="#60A5FA"
          />
          <MetricPill
            label="TTL"
            value={`${mins}m ${secs}s`}
            color={timeLeft < 120 ? "#EF4444" : "#10B981"}
            icon={
              <Clock size={10} color={timeLeft < 120 ? "#EF4444" : "#10B981"} />
            }
          />
        </View>

        {/* Execute Button */}
        <TouchableOpacity
          onPress={onExecute}
          disabled={executing || event.status !== "active"}
          style={{
            backgroundColor: event.status === "active" ? dirColor : "#374151",
            borderRadius: 10,
            paddingVertical: 13,
            alignItems: "center",
            flexDirection: "row",
            justifyContent: "center",
            gap: 8,
            opacity: executing || event.status !== "active" ? 0.6 : 1,
          }}
        >
          {executing ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <Zap size={16} color="white" />
          )}
          <Text style={{ fontSize: 14, fontWeight: "700", color: "white" }}>
            {executing
              ? "Executing..."
              : event.status !== "active"
                ? "Expired"
                : `Execute ${event.direction.toUpperCase()}`}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function PositionCard({ position, onClose }) {
  const pnl = position.pnl || 0;
  const isProfit = pnl >= 0;

  return (
    <View
      style={{
        backgroundColor: DARK_NAVY,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: isProfit ? "#10B98130" : "#EF444430",
        padding: 16,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: 12,
        }}
      >
        <View>
          <Text
            style={{
              fontSize: 15,
              fontWeight: "700",
              color: "white",
              marginBottom: 4,
              textTransform: "capitalize",
            }}
          >
            {position.position_type} • {position.strategy}
          </Text>
          <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
            {new Date(position.opened_at).toLocaleDateString()}{" "}
            {new Date(position.opened_at).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </Text>
        </View>
        <View style={{ alignItems: "flex-end" }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "800",
              color: isProfit ? "#10B981" : "#EF4444",
            }}
          >
            {isProfit ? "+" : ""}
            {pnl.toFixed(2)}
          </Text>
          <Text style={{ fontSize: 11, color: "#9CA3AF" }}>P&L</Text>
        </View>
      </View>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginBottom: 14,
        }}
      >
        <MetricPill
          label="Entry"
          value={`$${(position.entry_price || 0).toFixed(2)}`}
          color="#60A5FA"
        />
        <MetricPill
          label="Size"
          value={`$${(position.size || 0).toFixed(0)}`}
          color={GOLD}
        />
        {position.stop_loss && (
          <MetricPill
            label="Stop"
            value={`$${position.stop_loss.toFixed(2)}`}
            color="#EF4444"
          />
        )}
      </View>

      <TouchableOpacity
        onPress={onClose}
        style={{
          backgroundColor: "#374151",
          borderRadius: 10,
          paddingVertical: 10,
          alignItems: "center",
        }}
      >
        <Text style={{ fontSize: 13, fontWeight: "700", color: "#D1D5DB" }}>
          Close Position
        </Text>
      </TouchableOpacity>
    </View>
  );
}

function ClosedPositionRow({ position }) {
  const pnl = position.pnl || 0;
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: NAVY,
      }}
    >
      <View>
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: "white",
            textTransform: "capitalize",
          }}
        >
          {position.position_type} • {position.strategy}
        </Text>
        <Text style={{ fontSize: 11, color: "#6B7280" }}>
          {new Date(position.opened_at).toLocaleDateString()}
        </Text>
      </View>
      <Text
        style={{
          fontSize: 15,
          fontWeight: "700",
          color: pnl >= 0 ? "#10B981" : "#EF4444",
        }}
      >
        {pnl >= 0 ? "+" : ""}${Math.abs(pnl).toFixed(2)}
      </Text>
    </View>
  );
}

function NILLeaderCard({ athlete, rank }) {
  const tier = athlete.nil_tier || "Tier III";
  const tierColor =
    tier === "Tier I" ? GOLD : tier === "Tier II" ? "#60A5FA" : "#9CA3AF";

  return (
    <View
      style={{
        backgroundColor: DARK_NAVY,
        borderRadius: 14,
        padding: 16,
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        borderWidth: 1,
        borderColor: rank === 1 ? GOLD + "40" : NAVY,
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: rank <= 3 ? GOLD : "#374151",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Text
          style={{
            fontSize: 16,
            fontWeight: "800",
            color: rank <= 3 ? DARK : "white",
          }}
        >
          {rank}
        </Text>
      </View>

      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontSize: 15,
            fontWeight: "700",
            color: "white",
            marginBottom: 2,
          }}
        >
          {athlete.first_name} {athlete.last_name}
        </Text>
        <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
          {athlete.sport} • {athlete.team || "Independent"}
        </Text>
      </View>

      <View style={{ alignItems: "flex-end" }}>
        <View
          style={{
            backgroundColor: tierColor + "20",
            paddingHorizontal: 10,
            paddingVertical: 4,
            borderRadius: 20,
            borderWidth: 1,
            borderColor: tierColor + "40",
            marginBottom: 4,
          }}
        >
          <Text style={{ fontSize: 11, fontWeight: "700", color: tierColor }}>
            {tier}
          </Text>
        </View>
        <Text style={{ fontSize: 11, color: "#6B7280" }}>
          {athlete.coalition_status || "Active"}
        </Text>
      </View>
    </View>
  );
}

function MetricPill({ label, value, color, icon }) {
  return (
    <View
      style={{
        backgroundColor: color + "15",
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: color + "30",
        alignItems: "center",
        minWidth: 70,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 4,
          marginBottom: 2,
        }}
      >
        {icon}
        <Text style={{ fontSize: 11, fontWeight: "700", color }}>{value}</Text>
      </View>
      <Text style={{ fontSize: 10, color: "#9CA3AF" }}>{label}</Text>
    </View>
  );
}

function EmptyState({ icon: Icon, message, sub }) {
  return (
    <View
      style={{
        backgroundColor: DARK_NAVY,
        borderRadius: 16,
        padding: 40,
        alignItems: "center",
        borderWidth: 1,
        borderColor: NAVY,
      }}
    >
      <Icon size={48} color="#374151" />
      <Text
        style={{
          fontSize: 16,
          fontWeight: "600",
          color: "#D1D5DB",
          marginTop: 16,
        }}
      >
        {message}
      </Text>
      <Text style={{ fontSize: 13, color: "#6B7280", marginTop: 4 }}>
        {sub}
      </Text>
    </View>
  );
}
