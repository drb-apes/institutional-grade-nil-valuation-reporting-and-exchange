import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Heart,
  AlertTriangle,
  Activity,
  TrendingUp,
  Users,
  Eye,
  Zap,
  Shield,
  Brain,
  ArrowUpRight,
  ChevronRight,
  RefreshCw,
} from "lucide-react-native";

const NAVY = "#1B3A57";
const GOLD = "#C8A882";
const DARK = "#0D1421";
const DARK_NAVY = "#152E45";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [athletes, setAthletes] = useState([]);
  const [criticalAthletes, setCriticalAthletes] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const metricsRes = await fetch("/api/athletes/metrics?limit=15");
      if (metricsRes.ok) {
        const data = await metricsRes.json();
        const list = data.athletes || [];
        setAthletes(list);
        setCriticalAthletes(list.filter((a) => a.riskLevel === "high"));
      }
    } catch (e) {
      console.error("Home load error:", e);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, []);

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: DARK,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
        }}
      >
        <StatusBar style="light" />
        <ActivityIndicator size="large" color={GOLD} />
        <Text style={{ color: "#9CA3AF", marginTop: 16, fontSize: 14 }}>
          Loading BIM-APES Intelligence...
        </Text>
      </View>
    );
  }

  const stats = [
    { icon: Users, label: "Total", value: athletes.length, color: GOLD },
    {
      icon: AlertTriangle,
      label: "Critical",
      value: criticalAthletes.length,
      color: "#EF4444",
    },
    {
      icon: Eye,
      label: "Warning",
      value: athletes.filter((a) => a.riskLevel === "medium").length,
      color: "#F59E0B",
    },
    {
      icon: Shield,
      label: "Safe",
      value: athletes.filter((a) => a.riskLevel === "low").length,
      color: "#10B981",
    },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: DARK }}>
      <StatusBar style="light" />

      {/* Header */}
      <View
        style={{
          backgroundColor: NAVY,
          paddingTop: insets.top + 12,
          paddingBottom: 20,
          paddingHorizontal: 20,
          borderBottomWidth: 1,
          borderBottomColor: GOLD + "30",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 8,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <View
              style={{
                width: 36,
                height: 36,
                backgroundColor: GOLD,
                borderRadius: 8,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 18, fontWeight: "900", color: NAVY }}>
                B
              </Text>
            </View>
            <View>
              <Text style={{ fontSize: 20, fontWeight: "800", color: "white" }}>
                BIM-APES
              </Text>
              <Text style={{ fontSize: 10, color: GOLD, letterSpacing: 1.5 }}>
                BLEDSOE INTELLIGENCE
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={onRefresh} style={{ padding: 6 }}>
            <RefreshCw size={20} color={GOLD} />
          </TouchableOpacity>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <View
            style={{
              width: 8,
              height: 8,
              borderRadius: 4,
              backgroundColor: "#10B981",
            }}
          />
          <Text style={{ fontSize: 12, color: "#10B981", fontWeight: "600" }}>
            LIVE — Medical Intelligence Active
          </Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={GOLD}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Stats Grid */}
        <View style={{ padding: 16, gap: 12 }}>
          <View style={{ flexDirection: "row", gap: 12 }}>
            {stats.slice(0, 2).map((stat, i) => {
              const Icon = stat.icon;
              return (
                <View
                  key={i}
                  style={{
                    flex: 1,
                    backgroundColor: DARK_NAVY,
                    borderRadius: 14,
                    padding: 16,
                    borderWidth: 1,
                    borderColor: stat.color + "30",
                  }}
                >
                  <View
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 10,
                      backgroundColor: stat.color + "20",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: 10,
                    }}
                  >
                    <Icon size={20} color={stat.color} />
                  </View>
                  <Text
                    style={{
                      fontSize: 28,
                      fontWeight: "800",
                      color: stat.color,
                      marginBottom: 2,
                    }}
                  >
                    {stat.value}
                  </Text>
                  <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                    {stat.label}
                  </Text>
                </View>
              );
            })}
          </View>
          <View style={{ flexDirection: "row", gap: 12 }}>
            {stats.slice(2).map((stat, i) => {
              const Icon = stat.icon;
              return (
                <View
                  key={i}
                  style={{
                    flex: 1,
                    backgroundColor: DARK_NAVY,
                    borderRadius: 14,
                    padding: 16,
                    borderWidth: 1,
                    borderColor: stat.color + "30",
                  }}
                >
                  <View
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 10,
                      backgroundColor: stat.color + "20",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: 10,
                    }}
                  >
                    <Icon size={20} color={stat.color} />
                  </View>
                  <Text
                    style={{
                      fontSize: 28,
                      fontWeight: "800",
                      color: stat.color,
                      marginBottom: 2,
                    }}
                  >
                    {stat.value}
                  </Text>
                  <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                    {stat.label}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Critical Alert Banner */}
        {criticalAthletes.length > 0 && (
          <View style={{ paddingHorizontal: 16, marginBottom: 8 }}>
            <View
              style={{
                backgroundColor: "#7F1D1D",
                borderRadius: 14,
                padding: 16,
                borderWidth: 1,
                borderColor: "#991B1B",
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
              }}
            >
              <View
                style={{
                  backgroundColor: "#EF444430",
                  borderRadius: 10,
                  padding: 8,
                }}
              >
                <AlertTriangle size={22} color="#EF4444" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: "700",
                    color: "#FCA5A5",
                    marginBottom: 2,
                  }}
                >
                  {criticalAthletes.length} Critical Alert
                  {criticalAthletes.length > 1 ? "s" : ""}
                </Text>
                <Text style={{ fontSize: 12, color: "#FCA5A5", opacity: 0.8 }}>
                  {criticalAthletes
                    .slice(0, 2)
                    .map((a) => a.name)
                    .join(", ")}{" "}
                  require attention
                </Text>
              </View>
              <ArrowUpRight size={18} color="#FCA5A5" />
            </View>
          </View>
        )}

        {/* AR Medical Methods */}
        <View
          style={{ paddingHorizontal: 16, paddingTop: 20, marginBottom: 8 }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "700",
              color: "white",
              marginBottom: 12,
            }}
          >
            AR Medical Methods
          </Text>
          <View
            style={{
              backgroundColor: DARK_NAVY,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: NAVY,
              overflow: "hidden",
            }}
          >
            {[
              {
                id: 21,
                name: "Spatial Collapse Prediction",
                desc: "Collapse-risk vectors & balance instability",
                color: "#EF4444",
                icon: Heart,
              },
              {
                id: 22,
                name: "Impact Vector Overload",
                desc: "Impact direction & magnitude tracking",
                color: "#F59E0B",
                icon: Zap,
              },
              {
                id: 23,
                name: "Joint Divergence Method",
                desc: "Unsafe joint angles & torque detection",
                color: "#60A5FA",
                icon: Activity,
              },
              {
                id: 24,
                name: "Spatial Recovery Envelope",
                desc: "Return-to-baseline recovery shell",
                color: "#10B981",
                icon: Shield,
              },
            ].map((method, idx) => {
              const Icon = method.icon;
              return (
                <View
                  key={method.id}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: 16,
                    paddingVertical: 14,
                    borderBottomWidth: idx < 3 ? 1 : 0,
                    borderBottomColor: NAVY,
                  }}
                >
                  <View
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 10,
                      backgroundColor: method.color + "20",
                      alignItems: "center",
                      justifyContent: "center",
                      marginRight: 12,
                    }}
                  >
                    <Icon size={18} color={method.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 13,
                        fontWeight: "600",
                        color: "white",
                        marginBottom: 2,
                      }}
                    >
                      #{method.id} {method.name}
                    </Text>
                    <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                      {method.desc}
                    </Text>
                  </View>
                  <View
                    style={{
                      backgroundColor: "#10B98120",
                      paddingHorizontal: 8,
                      paddingVertical: 3,
                      borderRadius: 20,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 10,
                        fontWeight: "600",
                        color: "#10B981",
                      }}
                    >
                      ACTIVE
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* Athletes List */}
        <View style={{ paddingHorizontal: 16, paddingTop: 20 }}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <Text style={{ fontSize: 18, fontWeight: "700", color: "white" }}>
              Active Athletes
            </Text>
            <Text style={{ fontSize: 13, color: GOLD }}>
              {athletes.length} total
            </Text>
          </View>

          {athletes.length === 0 ? (
            <View
              style={{
                backgroundColor: DARK_NAVY,
                borderRadius: 14,
                padding: 32,
                alignItems: "center",
                borderWidth: 1,
                borderColor: NAVY,
              }}
            >
              <Users size={48} color="#374151" />
              <Text
                style={{
                  fontSize: 16,
                  color: "#9CA3AF",
                  marginTop: 16,
                  fontWeight: "500",
                }}
              >
                No athletes in database
              </Text>
              <Text
                style={{
                  fontSize: 13,
                  color: "#6B7280",
                  marginTop: 4,
                  textAlign: "center",
                }}
              >
                Go to Settings → Seed 20 Demo Athletes
              </Text>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {athletes.map((athlete, idx) => {
                const riskColor =
                  athlete.riskLevel === "high"
                    ? "#EF4444"
                    : athlete.riskLevel === "medium"
                      ? "#F59E0B"
                      : "#10B981";
                const initials = athlete.name
                  ? athlete.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .slice(0, 2)
                  : "?";
                return (
                  <TouchableOpacity
                    key={athlete.id || idx}
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderRadius: 12,
                      padding: 14,
                      flexDirection: "row",
                      alignItems: "center",
                      borderWidth: 1,
                      borderColor: riskColor + "20",
                      gap: 12,
                    }}
                  >
                    <View
                      style={{
                        width: 44,
                        height: 44,
                        borderRadius: 22,
                        backgroundColor: GOLD,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text
                        style={{ fontSize: 15, fontWeight: "800", color: NAVY }}
                      >
                        {initials}
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontSize: 14,
                          fontWeight: "700",
                          color: "white",
                          marginBottom: 2,
                        }}
                      >
                        {athlete.name}
                      </Text>
                      <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                        {athlete.team} • {athlete.sport}
                      </Text>
                    </View>
                    <View style={{ alignItems: "flex-end", gap: 4 }}>
                      <View
                        style={{
                          backgroundColor: riskColor + "20",
                          paddingHorizontal: 8,
                          paddingVertical: 3,
                          borderRadius: 20,
                          borderWidth: 1,
                          borderColor: riskColor + "40",
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 10,
                            fontWeight: "700",
                            color: riskColor,
                          }}
                        >
                          {athlete.riskLevel?.toUpperCase() || "N/A"}
                        </Text>
                      </View>
                      {athlete.fatigue !== null && (
                        <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                          F:{" "}
                          <Text
                            style={{
                              color:
                                athlete.fatigue > 60 ? "#EF4444" : "#10B981",
                              fontWeight: "600",
                            }}
                          >
                            {athlete.fatigue}%
                          </Text>
                        </Text>
                      )}
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>

        {/* Intelligence Engines Quick Access */}
        <View
          style={{ paddingHorizontal: 16, paddingTop: 24, paddingBottom: 8 }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "700",
              color: "white",
              marginBottom: 12,
            }}
          >
            Intelligence Engines
          </Text>
          <View style={{ gap: 10 }}>
            {[
              {
                icon: AlertTriangle,
                label: "Stress Intelligence",
                sub: "Joint torque, asymmetry, HRV",
                color: "#EF4444",
              },
              {
                icon: Zap,
                label: "Fatigue Intelligence",
                sub: "ACWR, stride analysis, hydration",
                color: "#F59E0B",
              },
              {
                icon: Activity,
                label: "Recovery Intelligence",
                sub: "Sleep, HRV, tissue repair",
                color: "#10B981",
              },
              {
                icon: Brain,
                label: "Training Intelligence",
                sub: "Velocity loss, technique drift",
                color: "#60A5FA",
              },
            ].map((engine, idx) => {
              const Icon = engine.icon;
              return (
                <TouchableOpacity
                  key={idx}
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderRadius: 12,
                    padding: 14,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 12,
                    borderWidth: 1,
                    borderColor: engine.color + "20",
                  }}
                >
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 10,
                      backgroundColor: engine.color + "20",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon size={20} color={engine.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "600",
                        color: "white",
                        marginBottom: 2,
                      }}
                    >
                      {engine.label}
                    </Text>
                    <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                      {engine.sub}
                    </Text>
                  </View>
                  <ChevronRight size={16} color="#374151" />
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
