import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Linking,
} from "react-native";
import { useState } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  Settings,
  User,
  Bell,
  Shield,
  Link2,
  Database,
  ChevronRight,
  Info,
  LogOut,
  RefreshCw,
  Activity,
  Globe,
  Moon,
  Zap,
  Heart,
} from "lucide-react-native";

const NAVY = "#1B3A57";
const GOLD = "#C8A882";
const DARK = "#0D1421";
const DARK_NAVY = "#152E45";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState({
    criticalAlerts: true,
    nilMomentum: true,
    tradingSignals: false,
    weeklyReport: true,
  });
  const [darkMode, setDarkMode] = useState(true);
  const [biometricSync, setBiometricSync] = useState(true);
  const [liveStream, setLiveStream] = useState(false);
  const [seedingData, setSeedingData] = useState(false);

  const seedDatabase = async () => {
    setSeedingData(true);
    try {
      const res = await fetch("/api/database/seed-athletes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ count: 20 }),
      });
      const data = await res.json();
      if (data.success) {
        Alert.alert(
          "✅ Success",
          `Seeded ${data.count} demo athletes into the database.`,
        );
      } else {
        Alert.alert("Error", data.error || "Failed to seed data");
      }
    } catch (e) {
      Alert.alert("Error", "Network error seeding database");
    } finally {
      setSeedingData(false);
    }
  };

  const seedBiometrics = async () => {
    setSeedingData(true);
    try {
      const res = await fetch("/api/database/seed-biometrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hours: 24, frequency: 4 }),
      });
      const data = await res.json();
      if (data.success) {
        Alert.alert(
          "✅ Success",
          `Generated ${data.count} biometric readings (24h of data).`,
        );
      } else {
        Alert.alert("Error", data.error || "Failed to seed biometrics");
      }
    } catch (e) {
      Alert.alert("Error", "Network error seeding biometrics");
    } finally {
      setSeedingData(false);
    }
  };

  const integrations = [
    { name: "Whoop", icon: Heart, status: "connected", color: "#EF4444" },
    {
      name: "Apple Watch",
      icon: Activity,
      status: "connected",
      color: "#60A5FA",
    },
    {
      name: "Garmin Connect",
      icon: Activity,
      status: "disconnected",
      color: "#9CA3AF",
    },
    {
      name: "AWS S3 Data Library",
      icon: Database,
      status: "connected",
      color: "#F59E0B",
    },
  ];

  const profile = {
    name: "Dashawn Bledsoe",
    role: "Platform Owner",
    email: "dashawn@bledsoe.com",
    plan: "Enterprise",
    athletes: "Unlimited",
  };

  const Section = ({ title, children }) => (
    <View style={{ marginBottom: 24 }}>
      <Text
        style={{
          fontSize: 12,
          fontWeight: "700",
          color: GOLD,
          letterSpacing: 1,
          textTransform: "uppercase",
          marginBottom: 8,
          paddingHorizontal: 4,
        }}
      >
        {title}
      </Text>
      <View
        style={{
          backgroundColor: DARK_NAVY,
          borderRadius: 14,
          borderWidth: 1,
          borderColor: NAVY,
          overflow: "hidden",
        }}
      >
        {children}
      </View>
    </View>
  );

  const SettingRow = ({
    icon: Icon,
    label,
    sub,
    value,
    onPress,
    isSwitch,
    switchValue,
    onToggle,
    color = GOLD,
    last = false,
  }) => (
    <TouchableOpacity
      onPress={isSwitch ? undefined : onPress}
      disabled={isSwitch}
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 14,
        borderBottomWidth: last ? 0 : 1,
        borderBottomColor: NAVY,
      }}
    >
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 10,
          backgroundColor: color + "20",
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        }}
      >
        <Icon size={18} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
          {label}
        </Text>
        {sub && (
          <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 1 }}>
            {sub}
          </Text>
        )}
      </View>
      {isSwitch ? (
        <Switch
          value={switchValue}
          onValueChange={onToggle}
          trackColor={{ false: "#374151", true: GOLD + "60" }}
          thumbColor={switchValue ? GOLD : "#6B7280"}
        />
      ) : value ? (
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 13, color: "#9CA3AF" }}>{value}</Text>
          <ChevronRight size={16} color="#374151" />
        </View>
      ) : (
        <ChevronRight size={16} color="#374151" />
      )}
    </TouchableOpacity>
  );

  return (
    <View style={{ flex: 1, backgroundColor: DARK }}>
      <StatusBar style="light" />

      {/* Header */}
      <View
        style={{
          backgroundColor: NAVY,
          paddingTop: insets.top + 12,
          paddingBottom: 20,
          paddingHorizontal: 20,
          borderBottomWidth: 1,
          borderBottomColor: GOLD + "30",
        }}
      >
        <Text
          style={{
            fontSize: 22,
            fontWeight: "bold",
            color: "white",
            marginBottom: 4,
          }}
        >
          Settings
        </Text>
        <Text style={{ fontSize: 13, color: GOLD }}>
          BIM-APES Platform Configuration
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 24,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Card */}
        <View
          style={{
            backgroundColor: DARK_NAVY,
            borderRadius: 16,
            padding: 20,
            borderWidth: 1,
            borderColor: GOLD + "30",
            marginBottom: 24,
            flexDirection: "row",
            alignItems: "center",
            gap: 16,
          }}
        >
          <View
            style={{
              width: 56,
              height: 56,
              borderRadius: 28,
              backgroundColor: GOLD,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 22, fontWeight: "800", color: NAVY }}>
              {profile.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 17,
                fontWeight: "700",
                color: "white",
                marginBottom: 2,
              }}
            >
              {profile.name}
            </Text>
            <Text style={{ fontSize: 13, color: GOLD, marginBottom: 2 }}>
              {profile.role}
            </Text>
            <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
              {profile.email}
            </Text>
          </View>
          <View
            style={{
              backgroundColor: GOLD + "20",
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: GOLD + "40",
            }}
          >
            <Text style={{ fontSize: 11, fontWeight: "700", color: GOLD }}>
              {profile.plan}
            </Text>
          </View>
        </View>

        {/* Notifications */}
        <Section title="Notifications">
          <SettingRow
            icon={Bell}
            label="Critical Alerts"
            sub="Injury & fatigue emergencies"
            isSwitch
            switchValue={notifications.criticalAlerts}
            onToggle={(v) =>
              setNotifications((prev) => ({ ...prev, criticalAlerts: v }))
            }
            color="#EF4444"
          />
          <SettingRow
            icon={Zap}
            label="NIL Momentum Spikes"
            sub="Significant NIL value changes"
            isSwitch
            switchValue={notifications.nilMomentum}
            onToggle={(v) =>
              setNotifications((prev) => ({ ...prev, nilMomentum: v }))
            }
            color={GOLD}
          />
          <SettingRow
            icon={Activity}
            label="Trading Signals"
            sub="Mispricing & opportunity alerts"
            isSwitch
            switchValue={notifications.tradingSignals}
            onToggle={(v) =>
              setNotifications((prev) => ({ ...prev, tradingSignals: v }))
            }
            color="#60A5FA"
          />
          <SettingRow
            icon={Info}
            label="Weekly Report"
            sub="Performance digest every Monday"
            isSwitch
            switchValue={notifications.weeklyReport}
            onToggle={(v) =>
              setNotifications((prev) => ({ ...prev, weeklyReport: v }))
            }
            color="#10B981"
            last
          />
        </Section>

        {/* Data & Sync */}
        <Section title="Data & Sync">
          <SettingRow
            icon={Heart}
            label="Biometric Auto-Sync"
            sub="Real-time wearable data"
            isSwitch
            switchValue={biometricSync}
            onToggle={setBiometricSync}
            color="#EF4444"
          />
          <SettingRow
            icon={Activity}
            label="Live Stream Mode"
            sub="High-frequency data (30Hz)"
            isSwitch
            switchValue={liveStream}
            onToggle={setLiveStream}
            color="#F59E0B"
            last
          />
        </Section>

        {/* Integrations */}
        <Section title="Wearable Integrations">
          {integrations.map((integration, idx) => {
            const Icon = integration.icon;
            return (
              <TouchableOpacity
                key={integration.name}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  borderBottomWidth: idx < integrations.length - 1 ? 1 : 0,
                  borderBottomColor: NAVY,
                }}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    backgroundColor: integration.color + "20",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 12,
                  }}
                >
                  <Icon size={18} color={integration.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{ fontSize: 15, fontWeight: "600", color: "white" }}
                  >
                    {integration.name}
                  </Text>
                </View>
                <View
                  style={{
                    backgroundColor:
                      integration.status === "connected"
                        ? "#10B98120"
                        : "#37414120",
                    paddingHorizontal: 10,
                    paddingVertical: 4,
                    borderRadius: 20,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 11,
                      fontWeight: "600",
                      color:
                        integration.status === "connected"
                          ? "#10B981"
                          : "#9CA3AF",
                    }}
                  >
                    {integration.status === "connected"
                      ? "Connected"
                      : "Disconnected"}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </Section>

        {/* Developer / Demo Tools */}
        <Section title="Developer Tools">
          <TouchableOpacity
            onPress={seedDatabase}
            disabled={seedingData}
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 14,
              borderBottomWidth: 1,
              borderBottomColor: NAVY,
              opacity: seedingData ? 0.5 : 1,
            }}
          >
            <View
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                backgroundColor: "#10B98120",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <Database size={18} color="#10B981" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
                Seed 25 Demo Athletes
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 1 }}>
                Populates database with sample data
              </Text>
            </View>
            {seedingData ? (
              <Activity size={16} color={GOLD} />
            ) : (
              <ChevronRight size={16} color="#374151" />
            )}
          </TouchableOpacity>

          <TouchableOpacity
            onPress={seedBiometrics}
            disabled={seedingData}
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 14,
              borderBottomWidth: 1,
              borderBottomColor: NAVY,
              opacity: seedingData ? 0.5 : 1,
            }}
          >
            <View
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                backgroundColor: "#60A5FA20",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <Activity size={18} color="#60A5FA" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
                Seed 48h Biometric Data
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 1 }}>
                Generates readings + NIL Divergence scores
              </Text>
            </View>
            <ChevronRight size={16} color="#374151" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() =>
              Linking.openURL(
                process.env.EXPO_PUBLIC_BASE_URL + "/nil-analytics",
              )
            }
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 14,
              borderBottomWidth: 1,
              borderBottomColor: NAVY,
            }}
          >
            <View
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                backgroundColor: "#60A5FA20",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <Globe size={18} color="#60A5FA" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
                NIL Analytics System
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 1 }}>
                Model NIL + Market NIL + Divergence Engine
              </Text>
            </View>
            <ChevronRight size={16} color="#374151" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() =>
              Linking.openURL(
                process.env.EXPO_PUBLIC_BASE_URL + "/fan-engagement",
              )
            }
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 14,
              borderBottomWidth: 1,
              borderBottomColor: NAVY,
            }}
          >
            <View
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                backgroundColor: "#EF444420",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <Zap size={18} color="#EF4444" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
                Fan Engagement Hub
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 1 }}>
                YouTube overlays, segments, merch, sponsors
              </Text>
            </View>
            <ChevronRight size={16} color="#374151" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() =>
              Linking.openURL(process.env.EXPO_PUBLIC_BASE_URL + "/console")
            }
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 14,
            }}
          >
            <View
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                backgroundColor: GOLD + "20",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 12,
              }}
            >
              <Globe size={18} color={GOLD} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
                Open Web Console
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 1 }}>
                Full desktop dashboard with all 11 views
              </Text>
            </View>
            <ChevronRight size={16} color="#374151" />
          </TouchableOpacity>
        </Section>

        {/* Azure NIL Architecture Banner */}
        <View
          style={{
            backgroundColor: NAVY,
            borderRadius: 16,
            padding: 20,
            borderWidth: 1,
            borderColor: GOLD + "30",
            marginBottom: 24,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 10,
              marginBottom: 12,
            }}
          >
            <Zap size={20} color={GOLD} />
            <Text style={{ fontSize: 15, fontWeight: "800", color: "white" }}>
              Azure NIL Analytics
            </Text>
          </View>
          <View style={{ gap: 8 }}>
            {[
              {
                label: "Wearables & Sensors",
                sub: "Event Hubs → Stream Analytics",
                color: "#60A5FA",
              },
              {
                label: "Model NIL Track",
                sub: "Performance DB → Bull/Sideways/Bear",
                color: "#10B981",
              },
              {
                label: "Market NIL Track",
                sub: "YouTube + Social → Market Score",
                color: "#EF4444",
              },
              {
                label: "Divergence Engine",
                sub: "Model vs Market → BUY/SELL/HOLD",
                color: GOLD,
              },
              {
                label: "Fan Engagement",
                sub: "Segments + Overlays + Merch + Sponsors",
                color: "#8B5CF6",
              },
            ].map((item, i) => (
              <View
                key={i}
                style={{ flexDirection: "row", alignItems: "center", gap: 10 }}
              >
                <View
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: 3,
                    backgroundColor: item.color,
                  }}
                />
                <Text style={{ fontSize: 13, color: "white", flex: 1 }}>
                  {item.label}
                </Text>
                <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                  {item.sub}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* About */}
        <Section title="About">
          <SettingRow
            icon={Shield}
            label="BIM-APES Version"
            value="2.0.0"
            color="#60A5FA"
          />
          <SettingRow
            icon={Info}
            label="Platform"
            value="Enterprise"
            color={GOLD}
          />
          <SettingRow
            icon={Database}
            label="Database"
            value="PostgreSQL"
            color="#10B981"
            last
          />
        </Section>

        {/* Legal */}
        <View style={{ alignItems: "center", paddingBottom: 8 }}>
          <Text
            style={{
              fontSize: 11,
              color: "#6B7280",
              textAlign: "center",
              lineHeight: 18,
            }}
          >
            BIM-APES by Bledsoe Investment Management{"\n"}
            Biometric Intelligence & NIL Valuation Platform{"\n"}© 2026 All
            Rights Reserved
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
