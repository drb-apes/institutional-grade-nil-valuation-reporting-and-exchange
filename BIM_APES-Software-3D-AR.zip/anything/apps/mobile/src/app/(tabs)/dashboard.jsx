import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from "react-native";
import { useState, useEffect, useCallback } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  Activity,
  TrendingUp,
  Zap,
  AlertTriangle,
  DollarSign,
  Target,
  BarChart3,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
} from "lucide-react-native";

const NAVY = "#1B3A57";
const GOLD = "#C8A882";
const DARK = "#0D1421";
const DARK_NAVY = "#152E45";

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [summary, setSummary] = useState(null);
  const [liveEvents, setLiveEvents] = useState([]);
  const [topAlerts, setTopAlerts] = useState([]);
  const [nilLeaders, setNilLeaders] = useState([]);
  const [sponsorWindows, setSponsorWindows] = useState([]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch("/api/dashboard/summary");
      if (!response.ok) throw new Error("Failed to fetch");
      const data = await response.json();
      if (data.success) {
        setSummary(data.data?.metrics || {});
        setLiveEvents(data.data?.liveEvents || []);
        setTopAlerts(data.data?.topAlerts || []);
        setNilLeaders(data.data?.nilLeaders || []);
        setSponsorWindows(data.data?.sponsorWindows || []);
      }
    } catch (error) {
      console.error("Dashboard fetch error:", error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchDashboardData();
    setRefreshing(false);
  }, []);

  const tabs = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "alerts", label: "Alerts", icon: AlertTriangle },
    { id: "nil", label: "NIL", icon: DollarSign },
    { id: "sponsors", label: "Sponsors", icon: Target },
  ];

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: DARK,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
        }}
      >
        <StatusBar style="light" />
        <ActivityIndicator size="large" color={GOLD} />
        <Text style={{ color: "#9CA3AF", marginTop: 16, fontSize: 14 }}>
          Loading Dashboard...
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: DARK }}>
      <StatusBar style="light" />

      {/* Header */}
      <View
        style={{
          backgroundColor: NAVY,
          paddingTop: insets.top + 12,
          paddingBottom: 16,
          paddingHorizontal: 20,
          borderBottomWidth: 1,
          borderBottomColor: GOLD + "30",
        }}
      >
        <Text
          style={{
            fontSize: 22,
            fontWeight: "800",
            color: "white",
            marginBottom: 4,
          }}
        >
          Analytics Dashboard
        </Text>
        <Text style={{ fontSize: 13, color: GOLD }}>
          Performance • NIL • Alerts • Sponsors
        </Text>

        {/* Summary Strip */}
        <View
          style={{
            flexDirection: "row",
            marginTop: 16,
            backgroundColor: DARK_NAVY,
            borderRadius: 12,
            padding: 12,
            gap: 8,
          }}
        >
          {[
            {
              label: "Athletes",
              value: summary?.activeAthletes || 0,
              color: GOLD,
            },
            {
              label: "Live Events",
              value: summary?.liveEvents || 0,
              color: "#10B981",
            },
            {
              label: "Alerts",
              value: summary?.criticalAlerts || 0,
              color: "#EF4444",
            },
            {
              label: "NIL Vol",
              value: `$${Math.round((summary?.nilVolume24h || 0) / 1000)}K`,
              color: "#60A5FA",
            },
          ].map((item, i) => (
            <View key={i} style={{ flex: 1, alignItems: "center" }}>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "800",
                  color: item.color,
                  marginBottom: 2,
                }}
              >
                {item.value}
              </Text>
              <Text style={{ fontSize: 10, color: "#9CA3AF" }}>
                {item.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Tab Bar */}
      <View
        style={{
          flexDirection: "row",
          backgroundColor: DARK_NAVY,
          paddingHorizontal: 12,
          paddingVertical: 8,
          borderBottomWidth: 1,
          borderBottomColor: NAVY,
        }}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <TouchableOpacity
              key={tab.id}
              onPress={() => setActiveTab(tab.id)}
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 8,
                borderRadius: 8,
                backgroundColor: isActive ? GOLD + "20" : "transparent",
                gap: 4,
              }}
            >
              <Icon size={14} color={isActive ? GOLD : "#6B7280"} />
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: isActive ? "700" : "500",
                  color: isActive ? GOLD : "#6B7280",
                }}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 20,
        }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={GOLD}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <View style={{ gap: 16 }}>
            {/* Live Events */}
            <View
              style={{
                backgroundColor: DARK_NAVY,
                borderRadius: 14,
                borderWidth: 1,
                borderColor: NAVY,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  borderBottomWidth: 1,
                  borderBottomColor: NAVY,
                  backgroundColor: NAVY + "60",
                }}
              >
                <Calendar size={18} color={GOLD} style={{ marginRight: 8 }} />
                <Text
                  style={{ fontSize: 15, fontWeight: "700", color: "white" }}
                >
                  Live Events
                </Text>
              </View>
              {liveEvents.length === 0 ? (
                <View style={{ padding: 24, alignItems: "center" }}>
                  <Text style={{ fontSize: 13, color: "#6B7280" }}>
                    No live events right now
                  </Text>
                </View>
              ) : (
                liveEvents.map((event, idx) => (
                  <View
                    key={event.id || idx}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      paddingHorizontal: 16,
                      paddingVertical: 12,
                      borderBottomWidth: idx < liveEvents.length - 1 ? 1 : 0,
                      borderBottomColor: NAVY,
                    }}
                  >
                    <View
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: 4,
                        backgroundColor: "#EF4444",
                        marginRight: 12,
                      }}
                    />
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontSize: 13,
                          fontWeight: "600",
                          color: "white",
                          marginBottom: 2,
                        }}
                      >
                        {event.name}
                      </Text>
                      <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                        {event.venue}
                      </Text>
                    </View>
                    <Text
                      style={{
                        fontSize: 11,
                        color: "#EF4444",
                        fontWeight: "600",
                      }}
                    >
                      {event.status}
                    </Text>
                  </View>
                ))
              )}
            </View>

            {/* Sport Modules */}
            <View
              style={{
                backgroundColor: DARK_NAVY,
                borderRadius: 14,
                borderWidth: 1,
                borderColor: NAVY,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  borderBottomWidth: 1,
                  borderBottomColor: NAVY,
                  backgroundColor: NAVY + "60",
                }}
              >
                <Activity size={18} color={GOLD} style={{ marginRight: 8 }} />
                <Text
                  style={{ fontSize: 15, fontWeight: "700", color: "white" }}
                >
                  Sport Intelligence Modules
                </Text>
              </View>
              {[
                {
                  emoji: "🤼",
                  name: "Wrestling",
                  sub: "Takedown efficiency, explosive power",
                },
                {
                  emoji: "🎾",
                  name: "Tennis/Pickleball",
                  sub: "Rally intensity, spike analysis",
                },
                {
                  emoji: "🏈",
                  name: "American Football",
                  sub: "Session consistency monitoring",
                },
                {
                  emoji: "⚽",
                  name: "Tactical Sports",
                  sub: "Team shape, spacing efficiency",
                },
                {
                  emoji: "🥊",
                  name: "Boxing/MMA",
                  sub: "Impact vectors, strike accuracy",
                },
              ].map((module, idx) => (
                <View
                  key={idx}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    borderBottomWidth: idx < 4 ? 1 : 0,
                    borderBottomColor: NAVY,
                  }}
                >
                  <Text style={{ fontSize: 22, marginRight: 12 }}>
                    {module.emoji}
                  </Text>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "600",
                        color: "white",
                        marginBottom: 2,
                      }}
                    >
                      {module.name}
                    </Text>
                    <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                      {module.sub}
                    </Text>
                  </View>
                  <View
                    style={{
                      backgroundColor: "#10B98120",
                      paddingHorizontal: 8,
                      paddingVertical: 3,
                      borderRadius: 20,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 10,
                        fontWeight: "600",
                        color: "#10B981",
                      }}
                    >
                      ON
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* ALERTS TAB */}
        {activeTab === "alerts" && (
          <View style={{ gap: 12 }}>
            {topAlerts.length === 0 ? (
              <View
                style={{
                  backgroundColor: DARK_NAVY,
                  borderRadius: 14,
                  padding: 32,
                  alignItems: "center",
                  borderWidth: 1,
                  borderColor: NAVY,
                }}
              >
                <AlertTriangle size={48} color="#374151" />
                <Text style={{ fontSize: 16, color: "#9CA3AF", marginTop: 16 }}>
                  No active alerts
                </Text>
              </View>
            ) : (
              topAlerts.map((alert, idx) => {
                const sevColor =
                  alert.severity === "high"
                    ? "#EF4444"
                    : alert.severity === "medium"
                      ? "#F59E0B"
                      : "#10B981";
                return (
                  <View
                    key={alert.id || idx}
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderRadius: 14,
                      padding: 16,
                      borderWidth: 1,
                      borderLeftWidth: 4,
                      borderColor: sevColor + "40",
                      borderLeftColor: sevColor,
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        marginBottom: 8,
                      }}
                    >
                      <View style={{ flex: 1 }}>
                        <Text
                          style={{
                            fontSize: 15,
                            fontWeight: "700",
                            color: "white",
                            marginBottom: 2,
                          }}
                        >
                          {alert.athlete}
                        </Text>
                        <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                          {alert.team} • {alert.type}
                        </Text>
                      </View>
                      <View
                        style={{
                          backgroundColor: sevColor + "20",
                          paddingHorizontal: 10,
                          paddingVertical: 4,
                          borderRadius: 20,
                          borderWidth: 1,
                          borderColor: sevColor + "40",
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 11,
                            fontWeight: "700",
                            color: sevColor,
                          }}
                        >
                          {alert.severity?.toUpperCase()}
                        </Text>
                      </View>
                    </View>
                    <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                      Score:{" "}
                      <Text style={{ color: sevColor, fontWeight: "600" }}>
                        {Math.round(alert.value || 0)}
                      </Text>
                    </Text>
                  </View>
                );
              })
            )}
          </View>
        )}

        {/* NIL TAB */}
        {activeTab === "nil" && (
          <View style={{ gap: 12 }}>
            <View
              style={{
                backgroundColor: DARK_NAVY,
                borderRadius: 14,
                padding: 16,
                borderWidth: 1,
                borderColor: GOLD + "30",
              }}
            >
              <Text style={{ fontSize: 12, color: GOLD, lineHeight: 18 }}>
                Real-time NIL valuation powered by BIM-APES ML •
                Performance-weighted scoring • Coalition exposure multipliers
              </Text>
            </View>
            {nilLeaders.length === 0 ? (
              <View
                style={{
                  backgroundColor: DARK_NAVY,
                  borderRadius: 14,
                  padding: 32,
                  alignItems: "center",
                  borderWidth: 1,
                  borderColor: NAVY,
                }}
              >
                <DollarSign size={48} color="#374151" />
                <Text style={{ fontSize: 16, color: "#9CA3AF", marginTop: 16 }}>
                  No NIL data yet
                </Text>
              </View>
            ) : (
              nilLeaders.map((leader, idx) => {
                const isLong = leader.trend === "long";
                return (
                  <View
                    key={leader.id || idx}
                    style={{
                      backgroundColor: DARK_NAVY,
                      borderRadius: 14,
                      padding: 16,
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 14,
                      borderWidth: 1,
                      borderColor: idx === 0 ? GOLD + "40" : NAVY,
                    }}
                  >
                    <View
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 20,
                        backgroundColor: idx < 3 ? GOLD : "#374151",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 16,
                          fontWeight: "800",
                          color: idx < 3 ? NAVY : "white",
                        }}
                      >
                        {idx + 1}
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontSize: 15,
                          fontWeight: "700",
                          color: "white",
                          marginBottom: 2,
                        }}
                      >
                        {leader.name}
                      </Text>
                      <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                        ${(leader.value || 0).toLocaleString()} value
                      </Text>
                    </View>
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        backgroundColor: isLong ? "#10B98120" : "#EF444420",
                        paddingHorizontal: 10,
                        paddingVertical: 5,
                        borderRadius: 20,
                        gap: 4,
                      }}
                    >
                      {isLong ? (
                        <ArrowUpRight size={14} color="#10B981" />
                      ) : (
                        <ArrowDownRight size={14} color="#EF4444" />
                      )}
                      <Text
                        style={{
                          fontSize: 12,
                          fontWeight: "700",
                          color: isLong ? "#10B981" : "#EF4444",
                        }}
                      >
                        {isLong ? "+" : ""}
                        {(leader.change || 0).toFixed(1)}%
                      </Text>
                    </View>
                  </View>
                );
              })
            )}
          </View>
        )}

        {/* SPONSORS TAB */}
        {activeTab === "sponsors" && (
          <View style={{ gap: 12 }}>
            {sponsorWindows.length === 0 ? (
              <View
                style={{
                  backgroundColor: DARK_NAVY,
                  borderRadius: 14,
                  padding: 32,
                  alignItems: "center",
                  borderWidth: 1,
                  borderColor: NAVY,
                }}
              >
                <Target size={48} color="#374151" />
                <Text style={{ fontSize: 16, color: "#9CA3AF", marginTop: 16 }}>
                  No active sponsor windows
                </Text>
              </View>
            ) : (
              sponsorWindows.map((win, idx) => (
                <View
                  key={idx}
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderRadius: 14,
                    padding: 16,
                    borderWidth: 1,
                    borderColor: GOLD + "20",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      marginBottom: 10,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: "700",
                        color: "white",
                      }}
                    >
                      {win.brand}
                    </Text>
                    <View
                      style={{
                        backgroundColor: "#10B98120",
                        paddingHorizontal: 10,
                        paddingVertical: 4,
                        borderRadius: 20,
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 12,
                          fontWeight: "700",
                          color: "#10B981",
                        }}
                      >
                        {win.roi}% ROI
                      </Text>
                    </View>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                    }}
                  >
                    <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                      Athlete:{" "}
                      <Text style={{ color: "white", fontWeight: "600" }}>
                        {win.athlete}
                      </Text>
                    </Text>
                    <Text
                      style={{ fontSize: 12, color: GOLD, fontWeight: "600" }}
                    >
                      {Math.round(win.window || 0)}h left
                    </Text>
                  </View>
                </View>
              ))
            )}

            {/* Activation features */}
            <Text
              style={{
                fontSize: 16,
                fontWeight: "700",
                color: "white",
                marginTop: 8,
              }}
            >
              Activation Features
            </Text>
            {[
              {
                icon: Zap,
                label: "Momentum Surge",
                sub: "Fan boost triggers auto-activation",
                color: GOLD,
              },
              {
                icon: Activity,
                label: "Performance Link",
                sub: "Branding tied to biometric events",
                color: "#60A5FA",
              },
              {
                icon: TrendingUp,
                label: "ROI Tracking",
                sub: "Real-time engagement & conversion",
                color: "#10B981",
              },
              {
                icon: Users,
                label: "Multi-Channel",
                sub: "AR, broadcast, stadium, social",
                color: "#F59E0B",
              },
            ].map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <View
                  key={idx}
                  style={{
                    backgroundColor: DARK_NAVY,
                    borderRadius: 12,
                    padding: 14,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 12,
                    borderWidth: 1,
                    borderColor: feature.color + "20",
                  }}
                >
                  <View
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 10,
                      backgroundColor: feature.color + "20",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon size={18} color={feature.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "600",
                        color: "white",
                        marginBottom: 2,
                      }}
                    >
                      {feature.label}
                    </Text>
                    <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                      {feature.sub}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </View>
  );
}
