export const BRAND_COLORS = {
  navy: "#1B3A57",
  darkNavy: "#152E45",
  lightNavy: "#2A4A68",
  gold: "#C8A882",
  darkGold: "#B8956A",
  lightGold: "#D4B896",
  white: "#FFFFFF",
  offWhite: "#F9F9F9",
  gray: "#6B7280",
  lightGray: "#E5E7EB",
  error: "#EF4444",
  success: "#10B981",
  warning: "#F59E0B",
};

export const BRAND_CLASSES = {
  btnPrimary:
    "bg-[#1B3A57] text-white px-4 py-2 rounded font-medium hover:bg-[#2A4A68] transition-colors",
  btnSecondary:
    "bg-[#C8A882] text-white px-4 py-2 rounded font-medium hover:bg-[#B8956A] transition-colors",
  btnOutline:
    "border-2 border-[#1B3A57] text-[#1B3A57] px-4 py-2 rounded font-medium hover:bg-[#F9F9F9] transition-colors",
  card: "bg-white shadow-sm border border-gray-100 rounded-lg overflow-hidden",
  header: "bg-[#1B3A57] text-white p-4 flex items-center justify-between",
  label: "text-xs font-bold text-[#1B3A57] uppercase tracking-wider mb-1 block",
  value: "text-sm text-gray-900 font-medium",
  divider: "h-[1px] bg-[#C8A882] my-4 w-full opacity-50",
};

export const LOGOS = {
  nilMarket:
    "https://dtvoeevhaseb5.cloudfront.net/user-uploads/714085ec-8a5a-42f5-b284-65660aa0fa40.png",
  bledsoe:
    "https://create-flux-file-upload-production.s3.amazonaws.com/user-uploads/bf7ed693-8159-40d5-a117-d63414d20b91.png",
};
