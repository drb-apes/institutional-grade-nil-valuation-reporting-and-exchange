"use client";
import React, { useState } from "react";
import { LOGOS } from "@/utils/brandColors";
import { CheckCircle2, ChevronRight, AlertCircle, Loader } from "lucide-react";

const SPORTS = [
  "Basketball",
  "Football",
  "Soccer",
  "Track & Field",
  "Swimming",
  "Wrestling",
  "Tennis",
  "Baseball",
  "Softball",
  "Volleyball",
  "Cross Country",
  "Golf",
  "Lacrosse",
  "Rugby",
  "Boxing / MMA",
  "Gymnastics",
  "Other",
];

const ARCHETYPES = [
  "Elite Performer",
  "Developing Talent",
  "Specialist",
  "Multi-Sport Athlete",
];

const AGE_RANGES = ["13–15", "16–17", "18–21", "22–25", "26+"];

const STEPS = ["Your Info", "Sport & Role", "Confirm"];

export default function SurveyLandingPage() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [form, setForm] = useState({
    first_name: "",
    age_range: "",
    sport: "",
    archetype: "",
    consistency_index: 80,
    thirty_day_interest: true,
  });

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const canNext = () => {
    if (step === 0) return form.first_name.trim() && form.age_range;
    if (step === 1) return form.sport && form.archetype;
    return true;
  };

  const handleNext = () => {
    if (step < STEPS.length - 1) setStep((s) => s + 1);
  };

  const handleBack = () => setStep((s) => s - 1);

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/bot/intake", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error(`Server error ${res.status}`);
      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
      } else {
        setError("Something went wrong. Please try again.");
      }
    } catch (err) {
      console.error(err);
      setError("Unable to submit. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6F9] font-sans">
      {/* Header */}
      <header className="bg-[#1B3A57] shadow-xl">
        <div className="max-w-2xl mx-auto px-6 py-4 flex items-center justify-between">
          <img
            src={LOGOS.nilMarket}
            alt="NIL Financial Literacy"
            className="h-10 object-contain bg-white rounded px-2 py-1 max-w-[160px]"
          />
          <img
            src={LOGOS.bledsoe}
            alt="Bledsoe Investment Management"
            className="h-5 opacity-75 hidden sm:block"
          />
        </div>
      </header>

      {/* Gold accent bar */}
      <div className="h-1 bg-gradient-to-r from-[#C8A882] via-[#D4B896] to-[#C8A882]" />

      {/* Hero */}
      <div className="bg-[#1B3A57] pb-12 pt-8 px-6 text-white text-center">
        <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#C8A882] mb-2">
          Educational Pilot Program
        </p>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-3">
          Athlete Intake Survey
        </h1>
        <p className="text-white/70 text-sm max-w-md mx-auto leading-relaxed">
          Complete this brief survey to enroll in the NIL Financial Literacy
          30‑Day Performance Window. Non‑commercial and research‑based.
        </p>
      </div>

      {/* Card */}
      <main className="flex-1 flex items-start justify-center px-4 -mt-6 pb-16">
        <div className="w-full max-w-lg">
          {submitted ? (
            /* ── Success State ── */
            <div className="bg-white rounded-2xl shadow-lg p-10 text-center border border-gray-100">
              <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-5">
                <CheckCircle2 size={32} className="text-green-500" />
              </div>
              <h2 className="text-2xl font-bold text-[#1B3A57] mb-2">
                You're Enrolled!
              </h2>
              <p className="text-gray-500 text-sm mb-6 leading-relaxed">
                Welcome to the 30‑Day NRC Window,{" "}
                <strong>{form.first_name}</strong>. Your intake has been
                recorded. A program coordinator will follow up with next steps.
              </p>
              <div className="bg-[#F4F6F9] rounded-xl p-4 text-left text-sm text-gray-600 space-y-2 mb-6">
                <div className="flex justify-between">
                  <span className="font-medium text-gray-400">Sport</span>
                  <span className="font-semibold text-[#1B3A57]">
                    {form.sport}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-400">Archetype</span>
                  <span className="font-semibold text-[#1B3A57]">
                    {form.archetype}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-400">Age Range</span>
                  <span className="font-semibold text-[#1B3A57]">
                    {form.age_range}
                  </span>
                </div>
              </div>
              <a
                href="/bot"
                className="inline-block w-full bg-[#1B3A57] text-white font-bold py-3 px-6 rounded-xl hover:bg-[#2A4A68] transition-colors text-sm"
              >
                Continue to Assistant Bot →
              </a>
            </div>
          ) : (
            /* ── Survey Card ── */
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              {/* Progress Bar */}
              <div className="flex border-b border-gray-100">
                {STEPS.map((label, i) => (
                  <div
                    key={label}
                    className={`flex-1 py-3 text-center text-[10px] font-bold uppercase tracking-widest transition-colors ${
                      i === step
                        ? "text-[#1B3A57] border-b-2 border-[#C8A882] bg-amber-50/40"
                        : i < step
                          ? "text-green-500 bg-green-50/30"
                          : "text-gray-300"
                    }`}
                  >
                    {i < step ? "✓ " : `${i + 1}. `}
                    {label}
                  </div>
                ))}
              </div>

              <div className="p-8">
                {/* ── Step 0: Your Info ── */}
                {step === 0 && (
                  <div className="space-y-5">
                    <div>
                      <h2 className="text-xl font-bold text-[#1B3A57] mb-1">
                        Let's get started
                      </h2>
                      <p className="text-gray-400 text-sm">
                        Basic info to set up your profile.
                      </p>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                        First Name *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Jordan"
                        value={form.first_name}
                        onChange={(e) => update("first_name", e.target.value)}
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#1B3A57]/30 focus:border-[#1B3A57] transition"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                        Age Range *
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {AGE_RANGES.map((r) => (
                          <button
                            key={r}
                            onClick={() => update("age_range", r)}
                            className={`px-4 py-2 rounded-lg text-sm font-semibold border transition-all ${
                              form.age_range === r
                                ? "bg-[#1B3A57] text-white border-[#1B3A57]"
                                : "bg-white text-gray-500 border-gray-200 hover:border-[#1B3A57] hover:text-[#1B3A57]"
                            }`}
                          >
                            {r}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                        Interested in the 30-Day NRC Window?
                      </label>
                      <div className="flex gap-3">
                        {["Yes", "No"].map((opt) => (
                          <button
                            key={opt}
                            onClick={() =>
                              update("thirty_day_interest", opt === "Yes")
                            }
                            className={`flex-1 py-2 rounded-lg text-sm font-semibold border transition-all ${
                              form.thirty_day_interest === (opt === "Yes")
                                ? "bg-[#1B3A57] text-white border-[#1B3A57]"
                                : "bg-white text-gray-500 border-gray-200 hover:border-[#1B3A57]"
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* ── Step 1: Sport & Role ── */}
                {step === 1 && (
                  <div className="space-y-5">
                    <div>
                      <h2 className="text-xl font-bold text-[#1B3A57] mb-1">
                        Sport & Archetype
                      </h2>
                      <p className="text-gray-400 text-sm">
                        Tell us about your athletic background.
                      </p>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                        Primary Sport *
                      </label>
                      <div className="grid grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                        {SPORTS.map((s) => (
                          <button
                            key={s}
                            onClick={() => update("sport", s)}
                            className={`px-3 py-2 rounded-lg text-xs font-semibold border text-left transition-all ${
                              form.sport === s
                                ? "bg-[#1B3A57] text-white border-[#1B3A57]"
                                : "bg-white text-gray-500 border-gray-200 hover:border-[#1B3A57] hover:text-[#1B3A57]"
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                        Athlete Archetype *
                      </label>
                      <div className="space-y-2">
                        {ARCHETYPES.map((a) => (
                          <button
                            key={a}
                            onClick={() => update("archetype", a)}
                            className={`w-full px-4 py-2.5 rounded-lg text-sm font-semibold border text-left transition-all ${
                              form.archetype === a
                                ? "bg-[#1B3A57] text-white border-[#1B3A57]"
                                : "bg-white text-gray-500 border-gray-200 hover:border-[#1B3A57] hover:text-[#1B3A57]"
                            }`}
                          >
                            {a}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                        Consistency Target:{" "}
                        <span className="text-[#C8A882]">
                          {form.consistency_index}
                        </span>
                      </label>
                      <input
                        type="range"
                        min={50}
                        max={100}
                        value={form.consistency_index}
                        onChange={(e) =>
                          update("consistency_index", parseInt(e.target.value))
                        }
                        className="w-full accent-[#1B3A57]"
                      />
                      <div className="flex justify-between text-[10px] text-gray-300 mt-1">
                        <span>50</span>
                        <span>100</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* ── Step 2: Confirm ── */}
                {step === 2 && (
                  <div className="space-y-5">
                    <div>
                      <h2 className="text-xl font-bold text-[#1B3A57] mb-1">
                        Review & Submit
                      </h2>
                      <p className="text-gray-400 text-sm">
                        Confirm your information before enrolling.
                      </p>
                    </div>
                    <div className="bg-[#F4F6F9] rounded-xl divide-y divide-gray-200 border border-gray-100">
                      {[
                        ["First Name", form.first_name],
                        ["Age Range", form.age_range],
                        ["Sport", form.sport],
                        ["Archetype", form.archetype],
                        ["Consistency Target", `${form.consistency_index}`],
                        [
                          "30-Day Interest",
                          form.thirty_day_interest ? "Yes" : "No",
                        ],
                      ].map(([label, value]) => (
                        <div
                          key={label}
                          className="flex justify-between items-center px-4 py-3"
                        >
                          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                            {label}
                          </span>
                          <span className="text-sm font-semibold text-[#1B3A57]">
                            {value}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="bg-amber-50 border border-[#C8A882]/40 rounded-xl px-4 py-3 text-xs text-amber-700 leading-relaxed">
                      <strong>Program Notice:</strong> This survey is
                      non‑commercial and research‑based. No financial
                      compensation is provided or implied.
                    </div>
                    {error && (
                      <div className="flex items-center gap-2 text-red-500 text-xs bg-red-50 border border-red-100 rounded-xl px-4 py-3">
                        <AlertCircle size={14} />
                        {error}
                      </div>
                    )}
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex gap-3 mt-8">
                  {step > 0 && (
                    <button
                      onClick={handleBack}
                      className="flex-1 py-3 rounded-xl text-sm font-bold text-[#1B3A57] border border-[#1B3A57]/20 hover:bg-gray-50 transition"
                    >
                      ← Back
                    </button>
                  )}
                  {step < STEPS.length - 1 ? (
                    <button
                      onClick={handleNext}
                      disabled={!canNext()}
                      className="flex-1 py-3 rounded-xl text-sm font-bold text-white bg-[#1B3A57] hover:bg-[#2A4A68] transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      Next <ChevronRight size={16} />
                    </button>
                  ) : (
                    <button
                      onClick={handleSubmit}
                      disabled={loading}
                      className="flex-1 py-3 rounded-xl text-sm font-bold text-white bg-[#C8A882] hover:bg-[#B8956A] transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {loading ? (
                        <>
                          <Loader
                            size={16}
                            style={{ animation: "spin 1s linear infinite" }}
                          />{" "}
                          Submitting…
                        </>
                      ) : (
                        "Submit Survey →"
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Subtle footer note */}
          <p className="text-center text-[10px] text-gray-400 mt-6">
            &copy; 2026 NIL Performance Market&trade; &mdash; Powered by Bledsoe
            Investment Management. All activity is educational and
            research‑based.
          </p>
        </div>
      </main>
      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
