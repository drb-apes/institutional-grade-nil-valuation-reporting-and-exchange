import React, { useState, useEffect } from "react";
import { BRAND_CLASSES, LOGOS, BRAND_COLORS } from "@/utils/brandColors";
import {
  Users,
  AlertCircle,
  CheckCircle2,
  Clock,
  ChevronRight,
  Search,
  Filter,
  MoreVertical,
  Activity,
  FileText,
} from "lucide-react";

const CaseCard = ({ caseData, onAction }) => {
  const severityColors = {
    HIGH: "bg-red-100 text-red-700",
    MEDIUM: "bg-amber-100 text-amber-700",
    LOW: "bg-blue-100 text-blue-700",
  };

  return (
    <div className={BRAND_CLASSES.card + " p-4 mb-4"}>
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-2">
          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${severityColors[caseData.severity]}`}
          >
            {caseData.severity}
          </span>
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            Case #{caseData.id}
          </span>
        </div>
        <button className="text-gray-400 hover:text-gray-600">
          <MoreVertical size={16} />
        </button>
      </div>

      <h4 className="text-sm font-bold text-[#1B3A57] mb-1">
        {caseData.athlete_name}
      </h4>
      <p className="text-xs text-gray-500 mb-4">{caseData.reason}</p>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <span className={BRAND_CLASSES.label}>Sport</span>
          <span className={BRAND_CLASSES.value}>{caseData.sport}</span>
        </div>
        <div>
          <span className={BRAND_CLASSES.label}>Archetype</span>
          <span className={BRAND_CLASSES.value}>{caseData.archetype}</span>
        </div>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
        <div className="flex items-center gap-1 text-[10px] font-bold text-gray-400">
          <Clock size={10} />
          {new Date(caseData.created_at).toLocaleDateString()}
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => onAction("VIEW", caseData)}
            className="text-[10px] font-bold text-[#1B3A57] hover:underline"
          >
            Open Case
          </button>
          <button
            onClick={() => onAction("ASSIGN", caseData)}
            className="text-[10px] font-bold text-[#C8A882] hover:underline"
          >
            Assign Task
          </button>
        </div>
      </div>
    </div>
  );
};

export default function StaffDashboard() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchCase] = useState("");

  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    try {
      const res = await fetch("/api/bot/cases");
      const data = await res.json();
      if (data.success) {
        setCases(data.cases);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = (type, data) => {
    console.log(`Action ${type} on case`, data);
    // Future implementation: modals for case details and task assignment
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9] flex flex-col font-sans">
      {/* Sidebar (Desktop) / Top Nav (Mobile) */}
      <header className="bg-[#1B3A57] text-white p-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-4">
          <img
            src={LOGOS.nilMarket}
            alt="NIL"
            className="h-8 object-contain bg-white p-1 rounded max-w-[120px]"
          />
          <h1 className="text-lg font-bold tracking-tight">Staff Console</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden md:flex bg-[#2A4A68] rounded-full px-3 py-1 items-center gap-2">
            <Search size={14} className="text-white/50" />
            <input
              type="text"
              placeholder="Search athletes..."
              className="bg-transparent text-xs outline-none text-white placeholder:text-white/30"
            />
          </div>
          <img src={LOGOS.bledsoe} alt="Bledsoe" className="h-4 opacity-70" />
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row">
        {/* Navigation Sidebar */}
        <nav className="w-full md:w-64 bg-white border-r border-gray-200 p-4 space-y-1">
          <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-3 mb-2">
            Main Menu
          </div>
          <button className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-[#1B3A57] bg-gray-50 rounded-lg">
            <Activity size={18} /> Dashboard
          </button>
          <button className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 rounded-lg">
            <Users size={18} /> Athletes
          </button>
          <button className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 rounded-lg">
            <Clock size={18} /> Recent Tasks
          </button>
          <div className={BRAND_CLASSES.divider}></div>
          <button className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 rounded-lg">
            <FileText size={18} /> Program Reports
          </button>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl font-bold text-[#1B3A57]">
                NIL Performance Market™ Intake
              </h2>
              <p className="text-sm text-gray-500">
                Manage educational pilot workflows and athlete cases.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                className={
                  BRAND_CLASSES.btnOutline +
                  " flex items-center gap-2 py-1.5 px-3 text-xs"
                }
              >
                <Filter size={14} /> Filter
              </button>
              <button
                className={
                  BRAND_CLASSES.btnPrimary +
                  " flex items-center gap-2 py-1.5 px-3 text-xs"
                }
              >
                Download Summary
              </button>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 block">
                Active Cases
              </span>
              <span className="text-2xl font-bold text-[#1B3A57]">
                {cases.length}
              </span>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 block">
                Pending Review
              </span>
              <span className="text-2xl font-bold text-amber-500">12</span>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 block">
                Avg Consistency
              </span>
              <span className="text-2xl font-bold text-green-500">84%</span>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 block">
                Completed 30-Day
              </span>
              <span className="text-2xl font-bold text-[#C8A882]">48</span>
            </div>
          </div>

          {/* Case Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? (
              <div className="col-span-full py-12 text-center text-gray-400">
                Loading cases...
              </div>
            ) : cases.length === 0 ? (
              <div className="col-span-full py-12 text-center text-gray-400">
                No active cases found.
              </div>
            ) : (
              cases.map((c) => (
                <CaseCard key={c.id} caseData={c} onAction={handleAction} />
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
