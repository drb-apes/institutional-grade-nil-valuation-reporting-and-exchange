import React, { useState, useEffect, useRef, useCallback } from "react";
import { BRAND_CLASSES, LOGOS, BRAND_COLORS } from "@/utils/brandColors";
import {
  Send,
  User,
  Bot,
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  FileText,
  BarChart3,
  Info,
} from "lucide-react";
import { useUpload } from "@/utils/useUpload";

const BotMessage = ({ type, content, buttons, onButtonClick }) => {
  const isUser = type === "user";
  return (
    <div
      className={`flex w-full mb-4 ${isUser ? "justify-end" : "justify-start"}`}
    >
      <div
        className={`flex max-w-[80%] ${isUser ? "flex-row-reverse" : "flex-row"} items-end gap-2`}
      >
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${isUser ? "bg-[#C8A882]" : "bg-[#1B3A57]"}`}
        >
          {isUser ? (
            <User size={16} color="white" />
          ) : (
            <Bot size={16} color="white" />
          )}
        </div>
        <div className="flex flex-col gap-2">
          <div
            className={`p-3 rounded-2xl shadow-sm ${isUser ? "bg-[#1B3A57] text-white rounded-br-none" : "bg-white border border-gray-200 text-gray-800 rounded-bl-none"}`}
          >
            <p className="text-sm whitespace-pre-wrap">{content}</p>
          </div>
          {buttons && buttons.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {buttons.map((btn, idx) => (
                <button
                  key={idx}
                  onClick={() => onButtonClick(btn)}
                  className="bg-white border border-[#1B3A57] text-[#1B3A57] px-3 py-1.5 rounded-full text-xs font-semibold hover:bg-[#1B3A57] hover:text-white transition-all shadow-sm"
                >
                  {btn.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const SurveyForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    first_name: "",
    age_range: "",
    sport: "",
    archetype: "",
    consistency_index: 85,
    thirty_day_interest: true,
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="p-4 bg-white rounded-xl border border-gray-100 shadow-lg space-y-4 max-w-sm"
    >
      <h3 className="text-lg font-bold text-[#1B3A57]">
        Athlete Intake Survey
      </h3>
      <div>
        <label className={BRAND_CLASSES.label}>First Name</label>
        <input
          type="text"
          required
          className="w-full border p-2 rounded text-sm"
          value={formData.first_name}
          onChange={(e) =>
            setFormData({ ...formData, first_name: e.target.value })
          }
        />
      </div>
      <div>
        <label className={BRAND_CLASSES.label}>Sport</label>
        <input
          type="text"
          className="w-full border p-2 rounded text-sm"
          value={formData.sport}
          onChange={(e) => setFormData({ ...formData, sport: e.target.value })}
        />
      </div>
      <div>
        <label className={BRAND_CLASSES.label}>Archetype</label>
        <select
          className="w-full border p-2 rounded text-sm"
          value={formData.archetype}
          onChange={(e) =>
            setFormData({ ...formData, archetype: e.target.value })
          }
        >
          <option value="">Select...</option>
          <option value="Elite Performer">Elite Performer</option>
          <option value="Developing Talent">Developing Talent</option>
          <option value="Specialist">Specialist</option>
        </select>
      </div>
      <button type="submit" className={BRAND_CLASSES.btnPrimary + " w-full"}>
        Complete Survey
      </button>
    </form>
  );
};

const CheckInForm = ({ onSubmit, athleteId }) => {
  const [upload, { loading }] = useUpload();
  const [formData, setFormData] = useState({
    week_number: 1,
    screenshot_url: "",
    effort_rating: 8,
    notes: "",
  });

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const { url } = await upload({ file });
      if (url) setFormData({ ...formData, screenshot_url: url });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ ...formData, athlete_id: athleteId });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="p-4 bg-white rounded-xl border border-gray-100 shadow-lg space-y-4 max-w-sm"
    >
      <h3 className="text-lg font-bold text-[#1B3A57]">Weekly NRC Check-In</h3>
      <div>
        <label className={BRAND_CLASSES.label}>NRC Screenshot</label>
        <input type="file" onChange={handleFileChange} className="text-xs" />
        {formData.screenshot_url && (
          <p className="text-xs text-green-600 mt-1">Uploaded!</p>
        )}
      </div>
      <div>
        <label className={BRAND_CLASSES.label}>Effort Rating (1-10)</label>
        <input
          type="range"
          min="1"
          max="10"
          value={formData.effort_rating}
          onChange={(e) =>
            setFormData({
              ...formData,
              effort_rating: parseInt(e.target.value),
            })
          }
          className="w-full"
        />
        <span className="text-xs text-gray-500">
          Value: {formData.effort_rating}
        </span>
      </div>
      <div>
        <label className={BRAND_CLASSES.label}>Notes</label>
        <textarea
          className="w-full border p-2 rounded text-sm"
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="How did training feel?"
        />
      </div>
      <button
        type="submit"
        disabled={loading || !formData.screenshot_url}
        className={BRAND_CLASSES.btnPrimary + " w-full disabled:opacity-50"}
      >
        {loading ? "Uploading..." : "Submit Check-In"}
      </button>
    </form>
  );
};

export default function NILPerformanceMarketBot() {
  const [messages, setMessages] = useState([]);
  const [showSurvey, setShowSurvey] = useState(false);
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [athlete, setAthlete] = useState(null);
  const chatEndRef = useRef(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, showSurvey, showCheckIn]);

  useEffect(() => {
    // Initial Welcome Message
    setMessages([
      {
        type: "bot",
        content:
          "Hello, I’m the NIL Performance Market™ Assistant.\nI support the educational NIL Performance Market™ pilot by coordinating surveys, weekly check‑ins, and performance literacy workflows.\nAll communication is non‑commercial and research‑based.",
        buttons: [
          { label: "Open Athlete Survey", action: "START_SURVEY" },
          { label: "View Program Overview", action: "VIEW_INFO" },
          { label: "Contact Program Lead", action: "CONTACT" },
        ],
      },
    ]);
  }, []);

  const handleButtonClick = (btn) => {
    setMessages((prev) => [...prev, { type: "user", content: btn.label }]);

    if (btn.action === "START_SURVEY") {
      setShowSurvey(true);
    } else if (btn.action === "VIEW_INFO") {
      setMessages((prev) => [
        ...prev,
        {
          type: "bot",
          content:
            "This program focuses on literacy and consistency. We track performance milestones to help athletes understand their value in the modern market landscape.",
        },
      ]);
    } else if (btn.action === "SUBMIT_CHECKIN") {
      setShowCheckIn(true);
    } else if (btn.action === "VIEW_SUMMARY") {
      setMessages((prev) => [
        ...prev,
        {
          type: "bot",
          content:
            "Your final report will be generated soon. Great job on completing the 30-Day Window!",
        },
      ]);
    }
  };

  const handleSurveySubmit = async (data) => {
    setShowSurvey(false);
    try {
      const res = await fetch("/api/bot/intake", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (result.success) {
        setAthlete(result.athlete);
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content: `Welcome to the 30‑Day NRC Window, ${result.athlete.first_name}!\nYour goal is consistency, not speed.\nComplete your first session when ready.`,
            buttons: [
              { label: "View Getting Started Guide", action: "VIEW_INFO" },
              { label: "Submit Week 1 Check-In", action: "SUBMIT_CHECKIN" },
            ],
          },
        ]);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleCheckInSubmit = async (data) => {
    setShowCheckIn(false);
    try {
      const res = await fetch("/api/bot/checkin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (result.success) {
        setMessages((prev) => [
          ...prev,
          {
            type: "bot",
            content:
              "Week 1 complete! Upload your NRC screenshot to stay on track.\n\nYour 30-Day Window progress is forming. You're halfway to the midpoint milestone.",
            buttons: [
              { label: "View 30-Day Summary", action: "VIEW_SUMMARY" },
              { label: "Submit Week 2 Check-In", action: "SUBMIT_CHECKIN" },
            ],
          },
        ]);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const [inputText, setInputText] = useState("");

  const handleSendInput = () => {
    if (!inputText.trim()) return;
    const userText = inputText.toLowerCase();
    setMessages((prev) => [...prev, { type: "user", content: inputText }]);
    setInputText("");

    let botResponse =
      "I'm sorry, I'm only trained to handle program-specific workflows. For other inquiries, please contact the Program Lead.";

    if (userText.includes("nil deal") || userText.includes("contract")) {
      botResponse =
        "This program does not provide or facilitate NIL deals. All activities are educational and research‑based.";
    } else if (
      userText.includes("money") ||
      userText.includes("payment") ||
      userText.includes("compensation")
    ) {
      botResponse =
        "This program does not involve financial compensation or financial advice.";
    } else if (userText.includes("sponsor") || userText.includes("endorse")) {
      botResponse =
        "This program is not sponsored or endorsed by any commercial entity.";
    } else if (userText.includes("predict") || userText.includes("future")) {
      botResponse =
        "Performance outcomes cannot be predicted. This program focuses on literacy and consistency.";
    }

    setTimeout(() => {
      setMessages((prev) => [...prev, { type: "bot", content: botResponse }]);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      {/* Header */}
      <header className="bg-[#1B3A57] p-4 flex items-center justify-between sticky top-0 z-10 shadow-md">
        <div className="flex items-center gap-3">
          <img
            src={LOGOS.nilMarket}
            alt="Logo"
            className="h-10 object-contain rounded bg-white p-1 max-w-[140px]"
          />
          <div>
            <h1 className="text-white text-lg font-bold tracking-tight">
              NIL Performance Market™
            </h1>
            <p className="text-white/70 text-[10px] uppercase font-bold tracking-widest">
              Assistant Bot
            </p>
          </div>
        </div>
        <img src={LOGOS.bledsoe} alt="Bledsoe" className="h-6 opacity-80" />
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 max-w-2xl mx-auto w-full">
        {messages.map((msg, i) => (
          <BotMessage key={i} {...msg} onButtonClick={handleButtonClick} />
        ))}
        {showSurvey && <SurveyForm onSubmit={handleSurveySubmit} />}
        {showCheckIn && (
          <CheckInForm onSubmit={handleCheckInSubmit} athleteId={athlete?.id} />
        )}
        <div ref={chatEndRef} />
      </main>

      {/* Input Bar (Simulated) */}
      <footer className="p-4 bg-white border-t border-gray-200">
        <div className="max-w-2xl mx-auto flex gap-2">
          <input
            type="text"
            className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm text-gray-800 focus:outline-none"
            placeholder="Reply to NIL Performance Market™ Assistant..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendInput()}
          />
          <button
            onClick={handleSendInput}
            className="bg-[#1B3A57] text-white p-2 rounded-full shadow-sm hover:bg-[#2A4A68] transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
      </footer>
    </div>
  );
}
