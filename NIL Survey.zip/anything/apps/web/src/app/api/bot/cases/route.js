import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const cases = await sql`
      SELECT 
        c.*, 
        a.first_name as athlete_name, 
        a.sport, 
        a.archetype, 
        a.consistency_index 
      FROM cases c
      JOIN athletes a ON c.athlete_id = a.id
      ORDER BY c.created_at DESC
    `;

    return Response.json({ success: true, cases });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
