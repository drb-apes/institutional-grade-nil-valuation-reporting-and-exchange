import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { athlete_id, week_number, screenshot_url, effort_rating, notes } =
      body;

    if (!athlete_id || !screenshot_url) {
      return Response.json(
        { error: "Athlete ID and screenshot are required" },
        { status: 400 },
      );
    }

    const [checkIn] = await sql`
      INSERT INTO check_ins (athlete_id, week_number, screenshot_url, effort_rating, notes)
      VALUES (${athlete_id}, ${week_number}, ${screenshot_url}, ${effort_rating}, ${notes})
      RETURNING *
    `;

    // Notify staff of check-in (simulated by creating a task or updating the case)
    const [existingCase] = await sql`
      SELECT id FROM cases WHERE athlete_id = ${athlete_id} AND status = 'OPEN' LIMIT 1
    `;

    if (existingCase) {
      await sql`
        INSERT INTO tasks (case_id, description, status)
        VALUES (${existingCase.id}, ${`Review weekly NRC check-in for athlete ID ${athlete_id}`}, 'PENDING')
      `;
    }

    return Response.json({ success: true, checkIn });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
