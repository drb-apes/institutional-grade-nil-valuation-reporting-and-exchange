import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      first_name,
      age_range,
      sport,
      archetype,
      consistency_index,
      thirty_day_interest,
    } = body;

    if (!first_name) {
      return Response.json(
        { error: "First name is required" },
        { status: 400 },
      );
    }

    const [athlete] = await sql`
      INSERT INTO athletes (first_name, age_range, sport, archetype, consistency_index, thirty_day_interest)
      VALUES (${first_name}, ${age_range}, ${sport}, ${archetype}, ${consistency_index}, ${thirty_day_interest})
      RETURNING *
    `;

    // Automatically create a "New Intake" case for staff review
    const [newCase] = await sql`
      INSERT INTO cases (athlete_id, reason, severity)
      VALUES (${athlete.id}, 'New NIL Performance Market educational intake', 'MEDIUM')
      RETURNING *
    `;

    return Response.json({ success: true, athlete, case_id: newCase.id });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
